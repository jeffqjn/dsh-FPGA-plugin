# FPGA 工作流 · Win7 移植包（dsh-fpga-workflow 0.12.0）

把开发机上的「FPGA 工作流」插件搬到 Win7 的 DSH：侧栏底部一个按钮，点开是全链路目录，每个阶段加载文件后一键开始运行。

## 包里有什么

```text
dsh-fpga-workflow-0.12.0/
  dsh-fpga-workflow-0.12.0.tgz   # 插件本体（npm 包，无第三方依赖）
  install.ps1                   # 安装脚本（PowerShell 2.0 语法、纯 ASCII）
  README-Win7.md                # 本文件
  SHA256SUMS.txt                # 校验值
  skills/                       # 11 个 FPGA skill（可选，见第 3 步）
    task-validation/
    req-spec-gen-1.6.0/req-spec-gen/
    req-spec-consistency-check/
    fpga-architecture-design/
    fpga-simulation-specification/
    standalone-lint/standalone_lint/
    fpga-git/
    xilinx-skill-main/plugins/xilinx-suite/skills/xilinx-suite/
    待完善/fpga-verification-plan/  fpga-test-specification/  fpga-coverage-trace/
```

`skills/` 按**原目录结构**保留：`xilinx-suite` 和三个「待完善」skill 都靠嵌套路径区分，别把它们拍平。

## 前置条件

- Windows 7 SP1 + PowerShell 2.0（脚本只用 2.0 语法）。
- 目标机器上已装 DSH，且 `dsh` 命令在 PATH 里。
- 插件本身不需要 Node 构建、不需要联网、不需要额外 Python 包。
- **skill 脚本**需要 Python **3.8.10**（补丁版本也必须一致），默认找 `C:\Python38\python.exe`，其他位置设 `FPGA_PYTHON38`。

## 三步安装

### 1. 装插件

**方式 A：图形界面（不用命令行）**

1. 解压这个 zip。
2. 打开 DSH：设置 → 插件 → **添加插件**。
3. 在输入框里填**插件目录**，即解压出来的：

   ```text
   ...\dsh-fpga-workflow-0.12.0\plugin
   ```

   注意是 `plugin` 这一层（里面有 `package.json`、`index.js`、`client.js`），**不要**填 `...\dsh-fpga-workflow-0.12.0` 这一层，也不要填 `.tgz`。
4. 点「安装」，然后重启 DSH 或对本页 `Ctrl+F5`。

「安装源」下拉只影响从 registry 取包，选本地目录时无所谓。

**方式 B：install.ps1（PowerShell 2.0）**

在解压出来的目录里执行：

```bat
powershell -ExecutionPolicy Bypass -File install.ps1 -Profile desktop
```

脚本只做一件事：调用 `dsh plugin --profile <profile> add <tgz>`，然后打印后续步骤。它不会手改 profile 文件。

**方式 C：手动命令行**

```bat
dsh plugin --profile desktop add "D:\port\dsh-fpga-workflow-0.12.0.tgz"
```

如果这台机器能连 registry，且包已经发布，也可以直接用包名（不必带 tgz）：

```bat
dsh plugin --profile desktop add dsh-fpga-workflow
```

### 2. 让技能被扫到

插件按顺序找，**取第一个存在的目录**：

1. profile 的 `cordis.patch.yml` 里 `id: fpga-workflow` 那行的 `config.root`
2. 环境变量 `FPGA_WORKFLOW_ROOT`
3. `%DSH_HOME%\fpga-workflow`
4. DSH 进程的当前目录

最省事的做法是把包里的 `skills\` 整个复制到 `%DSH_HOME%\fpga-workflow`（默认是 `C:\Users\<你>\.dsh\fpga-workflow`），**不用改任何配置**。

想固定到别的位置，就在 profile 的 `cordis.patch.yml` 里加：

```yaml
- id: fpga-workflow
  config:
    root: 'D:/fpga/skills'
```

（tgz 里自带的 `root` 是开发机路径，在新机器上不存在会被自动跳过，不用管它。）

### 3. 刷新并确认

重启 DSH，或对网页按 `Ctrl+F5`。打开后：

- 侧栏底部设置按钮旁出现 **「FPGA 工作流」**；点开是 FPGA 研制工作台（左边八阶段、中间 Skill、右边详情），点「返回对话」或再点入口回主界面。
- 新会话的技能清单里能看到 `task-validation`、`req-spec-gen`、`standalone-lint`、`xilinx-suite` 等 11 项。
- 宿主日志有一行 `[dsh-fpga-workflow] registered N FPGA workflow skills from ...`。

## 用法

1. 左栏选阶段，中栏选 Skill（三个「待完善」Skill 有标识，未接入的规划能力显示为灰色条目）。
2. 右栏按输入角色添加资料：任务书、FEIP 包、规格书、架构包、验证计划……页内浏览、系统选目录、粘贴绝对路径都行。
3. 先「预览指令」核对，再「开始运行」发到页头选定的会话；没有会话时会写入草稿并提示按回车。
4. 跑完到「产物」里登记实际输出，点下游按钮「带入 …」把路径填进下一阶段的输入。
5. 「运行记录」回看每次提交、目标会话和状态，能直接跳回对话。

## 升级 / 卸载

- 升级：用新版本的 tgz 再跑一次 `dsh plugin --profile desktop add <新tgz>`，然后 `Ctrl+F5`。
- 卸载：在插件管理界面移除 `dsh-fpga-workflow`，或用 `dsh plugin --help` 里的 remove 子命令；卸载不影响 `%DSH_HOME%\fpga-workflow` 里的技能文件。

## 兼容性

- 界面半区依赖与 DSH `0.2.2-rc.1` 同代的槽位：`main`（keyed）、`sidebar.footer.action`，以及 `ctx.get('uiWorkspace')` / `ctx.get('sessions')`。
- 更老的 DSH 上不会报错，但只有**宿主半区**生效：技能照样注册、照样能用 `skill` 工具加载，只是没有侧栏按钮和工作台页面。
- 插件代码只用标准 Node 内置模块与浏览器原生 API（无编译、无第三方依赖），Win7 上的 DSH 只要能加载该版本的插件即可运行。

## 排错

| 现象 | 处理 |
| --- | --- |
| 侧栏没有按钮 | 先 `Ctrl+F5`；再看 DSH 版本是否有 `sidebar.footer.action` 槽位；插件管理里确认 `dsh-fpga-workflow` 已启用 |
| 有按钮但技能清单为空 | 检查第 2 步的四个路径是否存在、目录里有没有 `SKILL.md`；看日志里那行 registered 的数量 |
| 点「开始运行」提示会话服务不可用 | 当前 DSH 没有 `sessions`/`uiWorkspace` 客户端服务；改用「复制指令」粘到输入框 |
| 运行报 `PYTHON_RUNTIME_MISMATCH` | skill 侧的解释器不是 3.8.10，设置 `FPGA_PYTHON38` 指向正确的 python.exe |
| 文件浏览报「无法列出该目录」 | 该 DSH 的目录浏览后端不可用，改用「系统选目录」或直接粘贴绝对路径 |
















