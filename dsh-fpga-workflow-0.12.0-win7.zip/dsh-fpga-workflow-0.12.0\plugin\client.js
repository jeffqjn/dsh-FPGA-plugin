// Browser half of dsh-fpga-workflow — the FPGA development workbench.
//
// The workbench answers four questions at a glance: which phase we are in,
// which inputs the selected skill needs, where the engineer must confirm, and
// how a produced artifact hands over to the next phase.
//
// Layout: the Harness sidebar stays native. The keyed `main` panel hosts a
// three-column page (phase rail | skills of the phase | skill detail) plus a
// header with the project, the target Session and the run records. Every visible
// string is Chinese with English accents; styling uses only --dsw-alias-* tokens
// so light/dark themes and the host font come for free.
//
// State lives in this browser (localStorage) keyed by project; a project is a
// working directory the engineer picks. Nothing here fabricates execution
// status: a run is "submitted" until the Host Session snapshot says it runs.
window.__ModuleLoader__.load({
  id: 'dsh-fpga-workflow',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    const PANEL_KEY = 'fpga-workflow';
    const STYLE_ID = 'dsh-fpga-workflow';
    const STORAGE_KEY = 'dsh-fpga-workflow:v2';
    const HUD_KEY = 'dsh-fpga-workflow:hud';
    const PYTHON_NOTE = '（目标环境 Windows 7 SP1 / PowerShell 2.0 / Python 3.8.10）';

    // ------------------------------------------------------------------ data

    const STATUS = {
      ready: { label: '已收录', tone: 'ok' },
      draft: { label: '待完善', tone: 'warn' },
      vendor: { label: '随包工具链', tone: 'brand' },
      planned: { label: '未接入', tone: 'muted' }
    };

    const PHASES = [
      {
        id: '01',
        title: '需求分析',
        en: 'Requirement',
        skills: ['task-validation', 'req-spec-gen', 'req-spec-consistency-check'],
        planned: []
      },
      {
        id: '02',
        title: '设计',
        en: 'Design',
        skills: ['fpga-architecture-design', 'fpga-rtl-generator'],
        planned: ['概要设计报告', '概要设计检查', 'FMEA / FMECA', 'XDC / SDC 约束']
      },
      {
        id: '03',
        title: '仿真验证计划',
        en: 'Simulation plan',
        skills: ['fpga-simulation-specification'],
        planned: ['不可测试项检查']
      },
      {
        id: '04',
        title: 'TB 编制及仿真',
        en: 'Testbench',
        skills: [],
        planned: ['Testbench 生成', '仿真执行', '覆盖率采集与报告']
      },
      {
        id: '05',
        title: '综合布局布线',
        en: 'Implementation',
        skills: ['xilinx-suite'],
        planned: []
      },
      {
        id: '06',
        title: '设计确认',
        en: 'Design confirmation',
        skills: ['test-spec-generator', 'test-spec-gen'],
        planned: []
      },
      {
        id: '07',
        title: '第三方验证',
        en: 'Third-party',
        skills: ['fpga-spec-code-consistency', 'standalone-lint'],
        planned: ['送测结果及问题复查']
      },
      {
        id: '08',
        title: '验收交付',
        en: 'Acceptance',
        skills: [],
        planned: ['研制总结', '验收交付资料']
      },
      {
        id: 'common',
        title: '跨阶段能力',
        en: 'Cross-phase',
        skills: ['fpga-coverage-trace', 'fpga-git'],
        planned: ['技术要素检查', '变更影响与文档同步', '配置和缺陷台账']
      }
    ];

    const SKILLS = {
      'task-validation': {
        title: '任务书审查',
        dir: 'task-validation',
        entry: 'scripts/cli.py',
        status: 'ready',
        modes: ['分块审查'],
        desc: '分块审查 FPGA 研制任务书（2.3.1 起支持子 Agent 并行局部审查），闭环问题并处理工程师确认的补充信息；确认后产出 FEIP 交接包、需求清单与初版架构。',
        inputs: [
          { id: 'taskbook', label: '研制任务书', kind: 'file', exts: ['.docx', '.txt', '.md'], required: true, hint: 'DOCX，或保留章节/表格顺序的 TXT / MD' },
          { id: 'attach', label: '配套附件', kind: 'any', multi: true, hint: '协议、插图、补充材料；未读附件会登记为问题' }
        ],
        outputs: ['审查报告与问题清单', '初版架构（四视图）', 'taskbook-reviewed FEIP 包'],
        confirm: ['缺项是否批准暂缓', '本版未明确项清单', '工程师提出生成请求并确认后生成正式包'],
        artifactTypes: ['FEIP 交接包', '审查报告', '初版架构'],
        starter: '请分块审查我加载的任务书，按问题闭环推进，到我确认时再停下。',
        next: [{ to: 'req-spec-gen', as: 'feip' }]
      },
      'req-spec-gen': {
        title: '需求规格编制',
        dir: 'req-spec-gen-1.6.0/req-spec-gen',
        entry: 'scripts/cli.py',
        status: 'ready',
        modes: ['需求规格编制'],
        desc: '由 taskbook-reviewed 交接包生成需求规格说明 DOCX / Markdown，并输出双向需求追溯与生成检查报告；1.6.0 新版按附录 C/D 逐项判定 24 条技术要素（18 通用 + 6 专用）。',
        inputs: [
          { id: 'feip', label: '任务书基线包', kind: 'dir', required: true, hint: '完整 taskbook-reviewed 目录' }
        ],
        sub: '项目模板与文档结构在 skill 根目录内预配置（references/ 与 templates/），无需每次加载。',
        outputs: ['reqspec-draft 包', '需求规格说明 DOCX / MD', '双向追溯与生成检查报告'],
        confirm: ['规格说明元信息', '候选发布前复核差异与就绪度'],
        artifactTypes: ['reqspec-draft', '需求规格说明'],
        starter: '请用我加载的 taskbook-reviewed 包生成需求规格说明。',
        next: [{ to: 'req-spec-consistency-check', as: 'spec' }]
      },
      'req-spec-consistency-check': {
        title: '规格一致性检查',
        dir: 'req-spec-consistency-check',
        entry: 'scripts/cli.py',
        status: 'ready',
        modes: ['文文检查', '基线对照'],
        desc: '检查规格说明自身的文文一致性；需要对照任务书基线时走「基线对照」，产出带证据的报告、ICD 与就绪度资料。',
        inputs: [
          { id: 'spec', label: '需求规格书', kind: 'file', exts: ['.docx', '.md', '.txt'], required: true },
          { id: 'baseline', label: '任务书基线包', kind: 'dir', hint: '「基线对照」模式必需；「文文检查」可不填' }
        ],
        outputs: ['带证据的一致性报告', 'icd.json / engineering_preflight.json', 'reqspec-reviewed 包（对照闭环后）'],
        confirm: ['问题清单逐条处置', '候选发布确认'],
        artifactTypes: ['一致性报告', 'reqspec-reviewed', 'ICD'],
        starter: '请检查我加载的规格说明的前后矛盾和口径不一致。',
        next: [
          { to: 'fpga-architecture-design', as: 'reqspec' },
          { to: 'fpga-simulation-specification', as: 'reqpkg' }
        ]
      },
      'fpga-architecture-design': {
        title: '架构设计',
        dir: 'fpga-architecture-design',
        entry: 'scripts/cli.py',
        status: 'ready',
        modes: ['新建架构', '继承式增量设计'],
        desc: '先整理继承代码与结构说明为可查询的现状基线，再按批准范围完成目标架构与文档交接 JSON；不替代需求批准或真实验证。',
        inputs: [
          { id: 'reqspec', label: 'reqspec-reviewed 需求包', kind: 'dir', required: true },
          { id: 'legacy', label: '继承工程与结构说明', kind: 'any', multi: true, hint: '继承式设计必需；先整理为现状基线' }
        ],
        outputs: ['architecture.json', 'verification_input.json', '架构说明文档'],
        confirm: ['批准生成范围', '架构冻结确认（两次决定分别记录）'],
        artifactTypes: ['架构交接包', 'architecture.json'],
        starter: '请基于我加载的需求包做架构设计，先给出调整范围等我批准。',
        next: [{ to: 'fpga-simulation-specification', as: 'archpkg' }]
      },
      'fpga-simulation-specification': {
        title: '仿真验证细则',
        dir: 'fpga-simulation-specification',
        entry: 'scripts/workflow.py',
        status: 'ready',
        modes: ['义务计划', '仿真细则', '覆盖迭代'],
        desc: '逐条评估原子需求，生成可修改、可确认的仿真义务计划，再展开仿真细则与覆盖追溯，并按回归证据迭代。',
        inputs: [
          { id: 'reqpkg', label: '一致性需求包', kind: 'dir', required: true },
          { id: 'archpkg', label: '架构交接包', kind: 'dir', required: true },
          { id: 'evidence', label: '回归证据', kind: 'any', multi: true, hint: '覆盖迭代时提供；没有匹配证据时显示「待执行」' }
        ],
        outputs: ['obligation_plan.json', '仿真验证义务计划.md', '仿真细则与覆盖追溯'],
        confirm: ['义务计划评审确认', '覆盖迭代阈值与不适用项'],
        artifactTypes: ['仿真义务计划', '仿真细则'],
        starter: '请用我加载的需求包与架构包生成仿真验证义务计划给我评审。',
        next: []
      },
      'xilinx-suite': {
        title: 'Xilinx 全工具链',
        dir: 'xilinx-skill-main/plugins/xilinx-suite/skills/xilinx-suite',
        entry: 'references/（按阶段加载）',
        status: 'vendor',
        modeGroups: [
                  {
                            "id": "hardware",
                            "label": "硬件设计（Vivado）",
                            "multi": true,
                            "options": [
                                      "创建 Vivado 工程与 Block Design（工程骨架、BD、IP 集成）",
                                      "配置 PS（DDR、MIO、时钟、中断）",
                                      "编写 IO 引脚约束（管脚分配、电平标准）",
                                      "编写时序约束（时钟、false path、multicycle）",
                                      "跑综合与实现（synth / impl 通过，定位失败项）",
                                      "生成比特流（.bit 产出与下载）",
                                      "导出硬件 XSA（给 Vitis 与 PetaLinux 使用）"
                            ]
                  },
                  {
                            "id": "software",
                            "label": "软件开发（Vitis / PetaLinux）",
                            "multi": true,
                            "options": [
                                      "Vitis HLS：把 C/C++ 算法综合成 RTL IP 核",
                                      "Vitis 裸机 / RTOS：建 Platform、Domain、Application，写 XSCT 脚本",
                                      "PetaLinux：建工程与 BSP 配置",
                                      "PetaLinux：定制内核、rootfs 与启动镜像",
                                      "gRPC 服务端 / 客户端：ZMQ 迁移到 gRPC、udmabuf + AXI DMA"
                            ]
                  },
                  {
                            "id": "diagnosis",
                            "label": "诊断与资料",
                            "multi": true,
                            "options": [
                                      "Vivado QA：扫描工程，列出器件、顶层、IP、BD、XDC、日志与产物",
                                      "Warning / Error 诊断：分类去重，给原因、影响与修改建议",
                                      "时序分析：WNS/WHS、覆盖情况、违例路径与候选根因",
                                      "查官方文档编号：UG / PG / DS 的用途与对应章节"
                            ]
                  },
                  {
                            "id": "build",
                            "label": "整体流程",
                            "multi": true,
                            "options": [
                                      "从零到一：HLS → Vivado → Vitis / PetaLinux 全链路搭建"
                            ]
                  }
        ],
        desc: 'Vivado 工程与 Block Design、IP 与 XDC、综合实现与时序、Vitis HLS、PetaLinux，以及 Vivado 日志与质量诊断。',
        sub: '每一项都是一个可直接交付的动作；可跨组多选，全不选时由 skill 按你的描述自动判断。',
        inputs: [{ id: 'project', label: '工程 / RTL / 约束 / 日志', kind: 'any', multi: true, required: true }],
        outputs: ['工程脚本', '构建结果（比特流 / 镜像）', '诊断报告'],
        confirm: ['工具版本与器件支持', '破坏性操作前确认'],
        artifactTypes: ['工程产物', '诊断报告'],
        starter: '请看我加载的 Vivado 工程或日志，先判定阶段，再给诊断和下一步命令。',
        next: []
      },
      'test-spec-generator': {
        title: '确认测试细则',
        dir: 'test-spec-generator',
        entry: 'scripts/feip_input.py',
        status: 'ready',
        modes: ['任务书入口', '规格说明入口'],
        desc: '从 taskbook-reviewed 或 reqspec-reviewed 的 FEIP 数据包生成表格化确认测试细则、RTM 与覆盖报告；只有仿真义务计划需要设计师确认。',
        sub: '入口由包清单自动识别；不生成 RTL、不执行测试、不替代真实执行结果。',
        inputs: [
          { id: 'feip', label: '上游 FEIP 数据包', kind: 'any', required: true, hint: 'taskbook-reviewed 目录 / reqspec-reviewed 目录 / 独立 reqspec.json' }
        ],
        outputs: ['仿真义务计划 + 设计师评审稿', 'verification_plan.json / test_specification.json', '表格版确认测试细则、RTM.csv、coverage_report.json'],
        confirm: ['仿真义务计划逐项确认（唯一人工卡点）', '缺口与未完成范围'],
        artifactTypes: ['确认测试细则', '仿真义务计划', '覆盖报告'],
        starter: '用我加载的 FEIP 数据包生成确认测试计划与表格化细则，先出仿真义务计划评审稿。',
        next: [{ to: 'fpga-coverage-trace', as: 'testspec' }]
      },
      'test-spec-gen': {
        title: '确认测试计划与报告',
        dir: 'test-spec-gen',
        entry: 'scripts/cli.py',
        status: 'ready',
        modes: ['计划 + 报告', '仅计划', '仅报告'],
        desc: '用 test_specification 数据包加 FEIP 包，按 1-58 / 1-59 模板生成确认测试计划与报告的 DOCX、Markdown、缺口清单与产保要素自检表；不填实测结果。',
        sub: '只按槽位锚点写入，九道校验门全过才发布；结果项一律写 -。',
        inputs: [
          { id: 'spec', label: '确认测试细则数据包', kind: 'dir', required: true, hint: '含 test_specification.json（可带 verification_plan.json / coverage_report.json / RTM.csv）' },
          { id: 'feip', label: '上游 FEIP 包', kind: 'dir', required: true, hint: 'taskbook-reviewed 或 reqspec-reviewed 包目录' }
        ],
        outputs: ['确认测试计划 DOCX / MD', '确认测试报告 DOCX / MD', '缺口清单与产保要素自检表'],
        confirm: ['九道校验门与 C 类不变量零违例', '不符合项必须进缺口清单'],
        artifactTypes: ['确认测试计划', '确认测试报告', '缺口清单'],
        starter: '用我加载的细则数据包与 FEIP 包生成确认测试计划与报告，先 inspect 再出文档。',
        next: []
      },
      'fpga-spec-code-consistency': {
        title: '文实一致性检查',
        dir: 'fpga-spec-code-consistency',
        entry: 'scripts/cli.py',
        status: 'ready',
        modeGroups: [
          { id: 'engine', label: '工程读取', options: ['直接读取工程', '自建工程读取'] },
          { id: 'gaps', label: '证据缺口', options: ['询问设计师', '忽略本次'] }
        ],
        desc: '对照需求规格说明与实际 RTL、Vivado 或 Libero 工程，提取代码架构并逐条核验功能、接口、性能与时钟复位需求，交付带原文与实现证据的文实一致性报告。',
        sub: '只读检查：不修改 RTL，不重新综合或实现；证据不足时先列缺口再询问。',
        inputs: [
          { id: 'spec', label: '需求规格说明', kind: 'file', exts: ['.docx', '.md', '.txt'], required: true, hint: 'DOCX，或 UTF-8 的 Markdown / TXT' },
          { id: 'project', label: '待检查的工程或 RTL', kind: 'dir', required: true, hint: 'Vivado / Libero 工程目录，或 RTL 源码目录' },
          { id: 'evidence', label: '已有仿真或实现报告', kind: 'any', multi: true, hint: '可选；用于补充当前版本的实现证据' }
        ],
        outputs: ['文实一致性报告 report.md', '证据索引 report-evidence.md / report.json', '证据缺口与待澄清清单'],
        confirm: ['选择「直接读取工程」还是「自建工程读取」', '证据缺口的询问或本次忽略范围', '差异与待澄清条款的处置'],
        artifactTypes: ['文实一致性报告', '证据缺口清单'],
        starter: '用我加载的规格书与工程做文实一致性检查，先列出证据缺口再逐条核验。',
        next: []
      },
      'standalone-lint': {
        title: 'RTL 编码规则检查',
        dir: 'standalone-lint/standalone_lint',
        entry: 'scripts/standalone_lint_workflow.py',
        status: 'ready',
        modes: ['只读检查'],
        desc: '只读审查 Verilog / SystemVerilog / VHDL 的编码规则，一个文件一个子代理，交付检查报告与文件 × 规则矩阵。',
        inputs: [
          { id: 'rtl', label: 'RTL 目录', kind: 'dir', required: true }
        ],
        outputs: ['检查报告', '文件 × 规则矩阵'],
        confirm: ['不修改代码；发现项由工程师决定是否修订'],
        artifactTypes: ['检查报告'],
        starter: '请对我加载的 RTL 目录做编码规则检查，只读、不改代码。',
        next: []
      },
      'fpga-rtl-generator': {
        title: 'RTL 代码生成',
        dir: 'fpga-rtl-generator',
        entry: 'scripts/cli.py',
        status: 'ready',
        modes: ['架构选根', '直接需求'],
        desc: '按冻结的架构包生成设计师选定模块及其 RTL 子树，或按明确需求生成 Verilog-2001；支持模块级并行、断点续跑与强制编码规则快速检查。',
        sub: '模块 UID 写在「补充要求」里；运行目录与交付目录必须是架构包之外的新目录。',
        inputs: [
          { id: 'package', label: '冻结架构包', kind: 'dir', hint: '架构选根时填写（arch-frozen / architecture.json 所在目录）' },
          { id: 'existing', label: '现有 RTL / 约束', kind: 'dir', hint: '可选；复用或继承代码时提供' }
        ],
        outputs: ['RTL 子树（Verilog-2001）', '模块规格、WaveJSON / SVG、参考模型', '源码清单、强制 lint 结果、delivery.json'],
        confirm: ['模块 UID 与授权范围', '外部依赖与复用边界', 'lint 违反项的修复依据'],
        artifactTypes: ['RTL 源码', '模块规格', 'lint 报告'],
        starter: '按冻结架构包生成选定模块的 RTL：先 prepare，再逐模块 plan → reference → rtl → lint。',
        next: [{ to: 'standalone-lint', as: 'rtl' }]
      },
      'fpga-coverage-trace': {
        title: '覆盖追溯',
        dir: '待完善/fpga-coverage-trace',
        entry: 'scripts/build_coverage.py',
        status: 'draft',
        modes: ['追溯覆盖率'],
        desc: '检查需求、验证义务、测试细则与执行结果的追溯完整性，生成 RTM.csv 与覆盖报告；识别未规划或未覆盖项。',
        inputs: [
          { id: 'requirements', label: 'requirements.json', kind: 'file', exts: ['.json'], required: true },
          { id: 'plan', label: 'verification_plan.json', kind: 'file', exts: ['.json'], required: true },
          { id: 'testspec', label: 'test_specification.json', kind: 'file', exts: ['.json'], required: true },
          { id: 'results', label: 'execution_results.json', kind: 'file', exts: ['.json'], hint: '可选；没有执行结果时覆盖率显示「待执行」' }
        ],
        outputs: ['RTM.csv', '覆盖报告'],
        confirm: ['覆盖口径与分母确认'],
        artifactTypes: ['RTM / 覆盖报告'],
        starter: '请用我加载的三件套计算需求到测试的追溯覆盖率，列出未覆盖项。',
        next: []
      },
      'fpga-git': {
        title: 'Git 里程碑',
        dir: 'fpga-git',
        entry: 'scripts/repo_check.py',
        status: 'ready',
        modes: ['仓库审计', '提交', '分支与合并'],
        desc: '在离线机器上用本地 Git 管理建库、RTL 与约束变更、提交、分支、合并与回退；不配置远端、不做发布。',
        inputs: [{ id: 'repo', label: '工程仓库目录', kind: 'dir', required: true }],
        outputs: ['仓库审计结果', '提交 / 标签记录'],
        confirm: ['提交内容与分支', '回退与合并前确认'],
        artifactTypes: ['提交记录'],
        starter: '请审计我加载的仓库当前状态，再按我的要求提交或建里程碑。',
        next: []
      }
    };

    // Every skill carries its own name so prompt builders and per-skill input
    // buckets never depend on the caller remembering the map key.
    Object.keys(SKILLS).forEach(function (name) {
      SKILLS[name].name = name;
    });

    // Versions recorded when this bundle is packaged; skills that do not declare
    // a version stay empty and the UI says 未标版本 instead of inventing one.
    const SKILL_VERSIONS = {
      'task-validation': '2.3.1',
      'req-spec-gen': '1.6.0',
      'req-spec-consistency-check': '2.0.0',
      'fpga-architecture-design': '',
      'fpga-rtl-generator': '',
      'fpga-simulation-specification': '',
      'standalone-lint': '',
      'fpga-spec-code-consistency': '',
      'test-spec-generator': '',
      'test-spec-gen': '1.0.0',
      'fpga-coverage-trace': '',
      'fpga-git': '',
      'xilinx-suite': ''
    };

    // Short intros distilled from each skill's own README (tagline + first paragraph).
    const SKILL_INTROS = {
      "fpga-rtl-generator": { tagline: "把冻结的 FPGA 架构包（或一份明确需求）变成设计师选定模块的 Verilog-2001 RTL 子树，含模块规格、波形与强制规则自检", intro: "两条入口：架构选根用 fpga-architecture-design 的冻结交接包，设计师选定模块 UID，脚本按实例清单展开并核对授权范围；直接需求入口把要求整理成请求与模块范围。生成按模块的 plan → reference → rtl → lint 推进，支持子 Agent 并行、断点续跑和强制编码规则快速检查，最后 publish 汇总交付。", points: ["两条入口：架构选根（按实例清单展开、核对授权范围）或直接需求（接口说清即可开工）", "按模块推进：plan → reference → rtl → lint，逐阶段验收，不一次吐大文件", "并行与续跑：独立模块可分子 Agent，中断后重新 next 核对已写文件续跑", "强制规则快速检查：92 条分 8 批，每份新 RTL 全覆盖，证据不足记 unverified", "交付可核对：delivery.json 逐项列出 RTL、规格、波形、参考模型、testbench、lint 与依赖映射"] },
      "fpga-architecture-design": { tagline: "把 FEIP 需求、ICD 与继承代码整理成可评审、可追溯的 FPGA 架构模型与文档交接 JSON", intro: "本 Skill 服务于 FPGA 架构设计阶段：输入是同版 reqspec-reviewed FEIP 发布包（reqspec.json、icd.json 及原文证据），以及可选的继承代码与结构说明；输出是绑定本轮输入摘要的 architecture.json、预算与规则记录、六份 DRAFT 报告、分功能架构图，以及给文档、详细设计、验证的下游交接 JSON。它只做架构判断、模型冻结与结构检查，不替代需求批准、RTL 实现或真实验证结果。" },
      "fpga-coverage-trace": { tagline: "把 FPGA 需求、验证义务、测试细则与执行结果连成可核查的 RTM 与覆盖报告", intro: "本 skill 读取 requirements.json、verificationplan.json 与 testspecification.json，可选读取 executionresults.json，在核对计划批准修订号与指纹后计算规划覆盖、细则追溯覆盖和执行通过覆盖，产出 coveragereport.json 与 RTM.csv。" },
      "fpga-git": { tagline: "让 FPGA 工程师在一台离线的 Windows 7 电脑上，用本地 Git 仓库完成建库、提交、分支、合并、回退与里程碑标记", intro: "fpga-git 解决“离线 Windows 7 机器上的 FPGA 工程怎么进 Git”这一具体问题：哪些输入必须跟踪、暂存前查什么、提交信息怎么写、冲突与回退怎么处理。输入是一个本机 FPGA 项目目录，输出是该目录 .git 里的提交、分支、注释标签，以及向用户报告的提交 ID。它不配置远端，不执行 fetch、pull、push，也不做发布或跨电脑传输。" },
      "fpga-simulation-specification": { tagline: "让 FPGA 验证工程师把同版结构化交付包，变成可评审的仿真义务计划、可执行的仿真细则与覆盖追溯", intro: "它解决的是“需求已经有了、仿真用例却没人能说清覆盖了什么”的问题：把每一条有效原子需求逐条评估成仿真义务、观察点、通过依据和必测覆盖项，而不是直接把需求原文抄成用例标题。输入固定为需求包（reqspec.json + icd.json）和架构包（verificationinput.json + architecture.json）两份同版结构化交付包；产出是可回写批注的 仿真验证义务计划.md、仿真验证细则.md 与 simulationrtm.csv。" },
      "fpga-spec-code-consistency": { tagline: "把 FPGA 需求规格书逐条对照实际 RTL 实现，交付带规格原文与实现证据的文实一致性报告。", intro: "它解决的是“规格书写了什么、代码到底实现了什么”之间的逐条核对问题。输入是一份需求规格书（DOCX、UTF-8 Markdown 或 UTF-8 TXT）加上 Vivado 工程、Libero 工程或一组 RTL 源码，输出是设计师可直接处理的主报告、逐条证据文件和结构化 JSON。Python 3.8.10 标准库负责抽取、校验与渲染，语义判断由宿主模型完成。" },
      "req-spec-consistency-check": { tagline: "帮 FPGA 需求规格说明的审查者查出规格书自相矛盾、口径不一与不可验证条款，并按原文证据出具问题清单", intro: "本 skill 处理两类任务：对一份规格书做单文档文文一致性检查，找出前后矛盾、口径不一、歧义、缺项和不合理要求；或对照 taskbook-reviewed FEIP 任务书基线，逐条核对偏离、遗漏与新增，并同步补全工程模型、导出 draft ICD、预检架构输入。产出是带原文定位的 Markdown 报告和 JSON 模型，写入新目录而不是改写你的文档。" },
      "req-spec-gen": { tagline: "把 taskbook-reviewed 的 FEIP 交接包装配成 FPGA 需求规格说明 DOCX、Markdown、双向追溯和生成检查报告。", intro: "本 skill 读取上游 taskbook-reviewed 的 FEIP 1.0.0 统一 JSON 交接包，由执行 Agent 完成语义编制，脚本再从同一冻结模型确定性装配 Markdown 与 DOCX，并输出 A.1 逆向、A.2 正向追溯和生成检查报告。它不重新抽取任务书，也不做一致性终审——终审由 req-spec-consistency-check 负责。" },
      "standalone-lint": { tagline: "让 FPGA 工程师用一次只读、非交互的审计，拿到 Verilog、SystemVerilog 与 VHDL 混合工程的编码规则合规结论", intro: "standalone-lint 面向“代码已经写好、只想确认是否符合编码约定”的场景：输入是现成的源码目录或文件清单，输出是 Markdown 审计报告与问题卡，全部写入工程内的两个固定目录。它按文件建立“文件 × 规则”矩阵，一个子 Agent 只负责一个文件，最后统一校验覆盖并合并报告。它不修改 RTL、不编译、不仿真、不综合，也不推进任何设计流程节点，不读取需求规格或架构契约。" },
      "test-spec-gen": { tagline: "把确认测试细则与 FEIP 包，按 1-58/1-59 模板生成可评审交付的《FPGA 确认测试计划》与《确认测试报告》", intro: "本技能只消费上游交付物：test_specification 家族产物（test_specification.json 必需，verification_plan.json、coverage_report.json、RTM.csv 建议）与一个 FEIP 包。按受控模板生成 DOCX 与 Markdown，附缺口清单与产保要素自检表；不重新抽取任务书、不重排验证义务、不填任何实测结果。", points: ["一份输入出两份文档：计划先出、报告再出，报告附录 F 的 4 项检查对象来自计划", "只按槽位锚点写入：锚点缺失就报 TEMPLATE_ANCHOR_MISSING 并停止，不猜块位置", "九道校验门全过才发布：锚点、占位、标题、编号、完备、摘要、可重开、输入未变、确定性", "产保要素程序自检：附录 E/F 输出符合/不符合/不适用/待实测，不符合必进缺口清单", "不填实测结果：结果项一律写 -，只交付可评审的计划与报告"] },
      "test-spec-generator": { tagline: "让验证工程师把已冻结的 FEIP 数据包，变成可直接上板执行的表格化确认测试细则、RTM 与覆盖报告", intro: "本 Skill 服务 FPGA 确认测试阶段：输入是 taskbook-reviewed 或 reqspec-reviewed 的 FEIP 数据包（也接受独立 reqspec.json），入口由包清单自动识别；输出仿真义务计划与评审稿、verification_plan.json、test_specification.json、表格版确认测试细则、RTM.csv 与覆盖报告。只有仿真义务计划需要设计师确认，其余计划与细则自主迭代到覆盖 100%；不生成 RTL、不执行测试。" , points: ["两条入口自动识别：任务书包或规格说明包，按清单判断，不需要人工选模式", "可执行的表格：每条测试项落到输入设置、观察点、记录与判据，测试员拿表即可执行", "追溯闭环：需求 → 验证义务 → 测试项 → 判据 → 覆盖报告，断链点名到 UID", "只有一处人工确认：仿真义务计划经设计师评审，其余计划与细则自主迭代到 100%", "缺口不掩盖：资料用尽仍缺的项标未完成范围与受影响 UID，不判定为通过"] },
      "task-validation": { tagline: "把一份 FPGA 研制任务书分块审到可闭环，再在用户明确确认后交付 FEIP 交接包与需求清单", intro: "输入是 FPGA 研制任务书（DOCX，或保留章节与表格顺序的 TXT/MD）以及用户明确提供的附件；输出先是一轮可复核的审查（reviewstate.json、taskbookreview.md），用户确认本版未明确项之后才是 FEIP 交接包与需求清单。它只负责任务书一侧的完备性审查、缺项暂缓、初版架构与交接包生成，不写需求规格说明，也不产出 RTL、仿真或测试结果。" },
      "xilinx-suite": { tagline: "让 Xilinx 工程师用一段 Prompt 得到可运行的 Vivado / Vitis HLS / Vitis Unified / PetaLinux 脚本，并对已有 Vivado 工程做证据驱动的质量诊断。", intro: "xilinx-suite 是一个覆盖 Xilinx（AMD）工具链的 Agent Skill：它按 SKILL.md 的路由表判断你处于哪个阶段，读取对应参考指南，然后生成完整可运行的 Tcl / XDC / XSCT / shell 脚本，并给出运行命令与预期产物。输入是一段自然语言需求（含器件、版本、设计目标），或者一个已有的 Vivado 工程目录、日志与时序报告；输出是脚本文件，或一份包含证据、风险、原因与建议的机器可读 JSON。" }
    };

    // --------------------------------------------------------------- storage

    const PROJECT_DEFAULT = 'default';
    const PROJECT_DEFAULT_LABEL = '未指定项目';

    function emptyData() {
      return { inputs: {}, runs: [], artifacts: [], selection: {}, modes: {}, extras: {}, target: '' };
    }

    function loadPersisted() {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw === null) return null;
        const parsed = JSON.parse(raw);
        if (parsed === null || typeof parsed !== 'object') return null;
        return parsed;
      } catch (error) {
        return null;
      }
    }

    const persisted = loadPersisted();

    const store = {
      current: persisted !== null && typeof persisted.current === 'string' ? persisted.current : PROJECT_DEFAULT,
      projects: [],
      ui: {
        phase: '01',
        skill: '',
        modal: null,
        picker: null,
        preview: null,
        form: null,
        toast: ''
      }
    };

    if (persisted !== null && Array.isArray(persisted.projects) && persisted.projects.length > 0) {
      store.projects = persisted.projects.map(function (project) {
        return {
          id: String(project.id),
          label: String(project.label || project.path || PROJECT_DEFAULT_LABEL),
          path: typeof project.path === 'string' ? project.path : '',
          data: Object.assign(emptyData(), project.data || {})
        };
      });
    }
    if (store.projects.length === 0) {
      store.projects = [{ id: PROJECT_DEFAULT, label: PROJECT_DEFAULT_LABEL, path: '', data: emptyData() }];
      store.current = PROJECT_DEFAULT;
    }
    if (!store.projects.some(function (project) { return project.id === store.current; })) {
      store.current = store.projects[0].id;
    }

    // Floating-card position and collapsed state survive reloads.
    (function restoreHud() {
      try {
        const raw = window.localStorage.getItem(HUD_KEY);
        if (raw === null) return;
        const saved = JSON.parse(raw);
        if (saved === null || typeof saved !== "object") return;
        const pos = saved.pos;
        if (pos !== undefined && pos !== null && Number.isFinite(pos.x) && Number.isFinite(pos.y)) {
          store.ui.hudPos = { x: pos.x, y: pos.y };
        }
        store.ui.hudCollapsed = saved.collapsed === true;
      } catch (error) {
        // A blocked storage read only costs the remembered position.
      }
    })();

    function project() {
      return store.projects.find(function (p) { return p.id === store.current; }) || store.projects[0];
    }

    function persist() {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
          current: store.current,
          projects: store.projects.map(function (p) {
            return { id: p.id, label: p.label, path: p.path, data: p.data };
          })
        }));
      } catch (error) {
        // A blocked storage write only costs persistence.
      }
    }

    const watchers = new Set();

    function notify() {
      watchers.forEach(function (fn) { fn(); });
    }

    function commit() {
      persist();
      notify();
    }

    function useStore() {
      const pair = React.useState(0);
      const set = pair[1];
      React.useEffect(function () {
        const fn = function () { set(function (n) { return n + 1; }); };
        watchers.add(fn);
        return function () { watchers.delete(fn); };
      }, []);
      return store;
    }

    // ------------------------------------------------------------- services

    let runtime = null;
    let open = false;
    const opening = new Set();

    function setOpen(next) {
      if (open === next) return;
      open = next;
      opening.forEach(function (fn) { fn(next); });
    }

    function useOpen() {
      const pair = React.useState(open);
      const set = pair[1];
      React.useEffect(function () {
        const fn = function (next) { set(next); };
        opening.add(fn);
        set(open);
        return function () { opening.delete(fn); };
      }, []);
      return pair[0];
    }

    function service(name) {
      try {
        if (runtime === null || typeof runtime.get !== 'function') return undefined;
        return runtime.get(name);
      } catch (error) {
        return undefined;
      }
    }

    function selectPanel(panel) {
      try {
        const layout = service('layout');
        if (layout !== undefined && typeof layout.selectPanel === 'function') {
          layout.selectPanel(panel);
          return true;
        }
      } catch (error) {
        // A rejected key preserves the current selection.
      }
      return false;
    }

    function leave() {
      setOpen(false);
      selectPanel(null);
    }

    function enter() {
      if (selectPanel(PANEL_KEY)) setOpen(true);
    }

    // ------------------------------------------------------------- sessions

    function sessionState() {
      return store.sessions || null;
    }

    function sessionIds() {
      const state = sessionState();
      if (state !== null && Array.isArray(state.ids)) return state.ids;
      const sessions = service('sessions');
      if (sessions === undefined) return [];
      try {
        const snapshot = sessions.list !== undefined && typeof sessions.list.getSnapshot === 'function'
          ? sessions.list.getSnapshot()
          : null;
        if (snapshot !== null && Array.isArray(snapshot.ids)) return snapshot.ids;
      } catch (error) {
        // Empty list is the honest answer here.
      }
      return [];
    }

    function sessionTitle(state, id) {
      try {
        const summary = state !== null && state.byId !== undefined ? state.byId[id] : undefined;
        if (summary !== undefined && summary !== null) {
          const candidate = summary.title || summary.name || summary.agentTitle;
          if (typeof candidate === 'string' && candidate.trim() !== '') return candidate.trim();
        }
      } catch (error) {
        // Fall back to the identity.
      }
      return String(id).slice(0, 8);
    }

    function resolveTarget() {
      const ids = sessionIds();
      const data = project().data;
      if (data.target !== '' && ids.indexOf(data.target) !== -1) return data.target;
      const sessions = service('sessions');
      if (sessions !== undefined && typeof sessions.retainInfo === 'function') {
        for (let i = 0; i < ids.length && i < 12; i += 1) {
          try {
            const info = sessions.retainInfo(ids[i]).getSnapshot();
            if (info !== undefined && info !== null && info.referenceCount > 0) return ids[i];
          } catch (error) {
            // Probe only.
          }
        }
      }
      return ids.length > 0 ? ids[0] : '';
    }

    // ---------------------------------------------------------------- model

    function skillOf(name) {
      return SKILLS[name] !== undefined ? SKILLS[name] : null;
    }

    function phaseOf(id) {
      return PHASES.find(function (p) { return p.id === id; }) || PHASES[0];
    }

    function phaseOfSkill(name) {
      return PHASES.find(function (p) { return p.skills.indexOf(name) !== -1; }) || PHASES[0];
    }

    function selectionFor(data, phase) {
      const chosen = data.selection[phase.id];
      if (chosen !== undefined && phase.skills.indexOf(chosen) !== -1) return chosen;
      return phase.skills.length > 0 ? phase.skills[0] : '';
    }

    function inputsOf(data, skillName, roleId) {
      const forSkill = data.inputs[skillName] || (data.inputs[skillName] = {});
      return forSkill[roleId] || (forSkill[roleId] = []);
    }

    function addInput(skillName, roleId, path) {
      const clean = String(path || '').trim();
      if (clean === '') return;
      const list = inputsOf(project().data, skillName, roleId);
      if (list.indexOf(clean) === -1) list.push(clean);
      commit();
    }

    function removeInput(skillName, roleId, path) {
      const list = inputsOf(project().data, skillName, roleId);
      const index = list.indexOf(path);
      if (index !== -1) list.splice(index, 1);
      commit();
    }

    function requiredMissing(skill, data) {
      const missing = [];
      skill.inputs.forEach(function (role) {
        if (role.required !== true) return;
        if (inputsOf(data, skill.name, role.id).length === 0) missing.push(role.label);
      });
      return missing;
    }

    // ------------------------------------------------------------- prompt

    function pad(value) {
      return String(value).padStart(2, '0');
    }

    function newRunId() {
      const now = new Date();
      return 'R' + now.getFullYear() + pad(now.getMonth() + 1) + pad(now.getDate()) +
        '-' + pad(now.getHours()) + pad(now.getMinutes()) + pad(now.getSeconds()) +
        '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
    }

    /**
     * A skill can declare one exclusive mode (`modes`) or several independent
     * choice groups (`modeGroups`). Both collapse to one text fragment that the
     * prompt, the run record and the detail page share.
     */
    function extrasOf(data, name) {
      const map = data.extras !== null && typeof data.extras === 'object' ? data.extras : {};
      const value = map[name];
      return typeof value === 'string' ? value.trim() : '';
    }

    function setExtras(name, value) {
      const data = project().data;
      if (data.extras === null || typeof data.extras !== 'object') data.extras = {};
      data.extras[name] = value;
      commit();
    }

    function modeSelection(data, skill) {
      const stored = data.modes[skill.name];
      if (Array.isArray(skill.modeGroups) && skill.modeGroups.length > 0) {
        const values = {};
        const parts = [];
        skill.modeGroups.forEach(function (group) {
          const raw = stored !== null && typeof stored === 'object' ? stored[group.id] : undefined;
          if (group.multi === true) {
            const picked = Array.isArray(raw) ? raw.filter(function (item) { return group.options.indexOf(item) !== -1; }) : [];
            values[group.id] = picked;
            if (picked.length > 0) parts.push((group.label ? group.label + '：' : '') + picked.join('、'));
            return;
          }
          const value = group.options.indexOf(raw) !== -1 ? raw : group.options[0];
          values[group.id] = value;
          parts.push(group.label ? group.label + '：' + value : value);
        });
        return { text: parts.length > 0 ? parts.join('；') : '按任务自动判断', values: values };
      }
      const options = Array.isArray(skill.modes) ? skill.modes : [];
      const single = options.indexOf(stored) !== -1 ? stored : options[0];
      return { text: single || '', values: { mode: single || '' } };
    }

    function modeOf(data, skill) {
      return modeSelection(data, skill).text;
    }

    /**
     * The one prompt builder: preview, copy and run all call it, so the three
     * paths can never drift apart.
     */
    function buildPrompt(skill, phase, data, runId) {
      const mode = modeOf(data, skill);
      const list = [];
      list.push('请使用 $' + skill.name + ' 执行「' + phase.title + ' · ' + skill.title + '」（' + mode + '）。');
      list.push('');
      list.push('项目：' + project().label);
      list.push('运行编号：' + runId);
      list.push('');
      list.push('输入：');
      let given = 0;
      skill.inputs.forEach(function (role) {
        const paths = inputsOf(data, skill.name, role.id);
        if (paths.length === 0) {
          if (role.required === true) list.push('- ' + role.label + '：（未提供，请先向我确认）');
          return;
        }
        paths.forEach(function (path) {
          given += 1;
          list.push('- ' + role.label + '：' + path);
        });
      });
      if (given === 0) list.push('- （本次未加载任何资料）');
      list.push('');
      list.push(skill.starter);
      const extra = extrasOf(data, skill.name);
      if (extra !== '') {
        list.push('');
        list.push('补充要求：');
        list.push(extra);
      }
      if (skill.entry.indexOf('references/') === 0) {
        list.push('入口：' + skill.dir + '\\' + skill.entry + '（按所选参考文档执行）');
      } else {
        list.push('入口命令：' + skill.dir + '\\' + skill.entry + PYTHON_NOTE);
      }
      list.push('请依据该 Skill 的 SKILL.md 与参考文档执行，保留原文位置、问题差异和版本关系。');
      list.push('到达需要我确认的环节时，请在本会话列出待确认项并停下，等我决定；只登记本次实际生成且经校验的输出路径与状态。');
      return list.join('\n');
    }

    // ------------------------------------------------------------------ run

    function pushRun(record) {
      const data = project().data;
      data.runs.unshift(record);
      if (data.runs.length > 60) data.runs.length = 60;
      commit();
    }

    function patchRun(id, patch) {
      const run = project().data.runs.find(function (item) { return item.id === id; });
      if (run === undefined) return false;
      Object.assign(run, patch);
      commit();
      return true;
    }

    async function runSkill(skill) {
      const phase = phaseOfSkill(skill.name);
      const data = project().data;
      const runId = newRunId();
      const prompt = buildPrompt(skill, phase, data, runId);
      const sessionId = resolveTarget();
      const sessionLabel = sessionId === '' ? '（无可用会话）' : sessionTitle(sessionState(), sessionId);
      const record = {
        id: runId,
        skill: skill.name,
        skillTitle: skill.title,
        phase: phase.id,
        sessionId: sessionId,
        sessionLabel: sessionLabel,
        at: new Date().toISOString(),
        status: 'submitting',
        message: '',
        prompt: prompt,
        mode: modeOf(data, skill),
        inputs: JSON.parse(JSON.stringify(data.inputs[skill.name] || {}))
      };
      pushRun(record);

      const sessions = service('sessions');
      const ui = service('uiWorkspace');

      try {
        if (sessions === undefined || typeof sessions.retain !== 'function' || sessionId === '') {
          if (ui === undefined || typeof ui.startSession !== 'function') {
            throw new Error('会话服务不可用：请用「复制指令」贴到输入框。');
          }
          ui.startSession(undefined, { prompt: prompt, whenDraftExists: 'append' });
          patchRun(runId, { status: 'draft', message: '已写入新会话草稿，按回车发送。' });
          return;
        }

        const reference = sessions.retain(sessionId, { source: 'controllerOperation' });
        try {
          await reference.ready;
          const result = await reference.binding.session.prompt([{ type: 'text', text: prompt }], 'queue');
          if (result !== undefined && result !== null && result.ok === false) {
            const failure = result.error !== undefined && result.error !== null ? result.error : {};
            throw new Error(failure.message || failure.code || '发送失败');
          }
        } finally {
          reference.release();
        }

        patchRun(runId, { status: 'submitted', message: '已提交，正在切到会话。' });
        try {
          if (ui !== undefined && typeof ui.openSession === 'function') ui.openSession(sessionId);
        } catch (error) {
          // The turn already started; a failed jump only costs navigation.
        }
        leave();
      } catch (error) {
        const message = error !== undefined && error !== null && error.message !== undefined
          ? String(error.message)
          : String(error);
        patchRun(runId, { status: 'failed', message: message });
      }
    }

    // ------------------------------------------------------------- artifacts

    function artifactOf(skillName) {
      return project().data.artifacts.filter(function (item) { return item.skill === skillName; });
    }

    function handoffTargets(skillName) {
      const skill = skillOf(skillName);
      return skill !== null && Array.isArray(skill.next) ? skill.next : [];
    }

    function applyHandoff(artifact, target) {
      const data = project().data;
      const targetSkill = skillOf(target.to);
      if (targetSkill === null) return;
      const role = targetSkill.inputs.find(function (item) { return item.id === target.as; });
      if (role === undefined) return;
      const list = inputsOf(data, target.to, target.as);
      if (list.indexOf(artifact.path) === -1) list.push(artifact.path);
      const phase = phaseOfSkill(target.to);
      data.selection[phase.id] = target.to;
      store.ui.page = 'phase:' + phase.id;
      store.ui.skill = target.to;
      store.ui.toast = '已带入 ' + targetSkill.title + ' 的「' + role.label + '」，请核对后开始运行。';
      commit();
    }

    function registerArtifact(form) {
      const data = project().data;
      data.artifacts.unshift({
        id: 'A' + Date.now().toString(36).toUpperCase(),
        skill: form.skill,
        type: form.type,
        path: form.path.trim(),
        revision: form.revision.trim() || 'unknown',
        reviewState: form.reviewState,
        source: form.source,
        createdAt: new Date().toISOString(),
        runId: form.runId || ''
      });
      store.ui.form = null;
      store.ui.toast = '产物已登记，可在下游 Skill 的「可引用上游产物」里带入。';
      commit();
    }

    // --------------------------------------------------------------- picker

    function looksLikeDir(name) {
      return !/\.[A-Za-z0-9]{1,8}$/.test(name);
    }

    function sortEntries(entries) {
      return entries.slice().sort(function (a, b) {
        const da = looksLikeDir(a.name) ? 0 : 1;
        const db = looksLikeDir(b.name) ? 0 : 1;
        if (da !== db) return da - db;
        return a.name.localeCompare(b.name, 'zh-Hans-CN');
      });
    }

    function winPath(value) {
      return String(value === undefined || value === null ? '' : value).replace(/\//g, '\\').replace(/\\+$/, '').toLowerCase();
    }

    function isUnderBase(base, path) {
      if (base === '') return false;
      const b = winPath(base);
      const p = winPath(path);
      if (b === '') return false;
      return p === b || p.indexOf(b + '\\') === 0;
    }

    async function listPath(path) {
      const picker = store.ui.picker;
      if (picker === null) return;
      // The chosen workspace is the base: browsing never climbs above it.
      if (picker.base && picker.base !== '' && path !== undefined && path !== null && !isUnderBase(picker.base, path)) {
        path = picker.base;
      }
      picker.loading = true;
      picker.error = '';
      notify();
      try {
        const ui = service('uiWorkspace');
        if (ui === undefined || typeof ui.listDirectory !== 'function') {
          throw new Error('目录浏览不可用，请在下方直接输入绝对路径。');
        }
        const listing = await ui.listDirectory(path);
        picker.listing = listing;
        picker.path = listing !== null && listing.path ? listing.path : path;
        picker.loading = false;
      } catch (error) {
        picker.loading = false;
        picker.error = '无法列出该目录：' + (error && error.message ? error.message : String(error));
      }
      notify();
    }

    function openPicker(skill, role) {
      const existing = inputsOf(project().data, skill.name, role.id);
      const base = String(project().path || '');
      // Open inside the chosen workspace: reuse the last input only when it sits
      // under the base, otherwise start at the base itself.
      const last = existing.length > 0 ? existing[existing.length - 1] : '';
      const start = base !== '' ? (isUnderBase(base, last) ? last : base) : last;
      store.ui.picker = {
        skill: skill.name,
        role: role.id,
        roleLabel: role.label,
        kind: role.kind,
        base: base,
        path: start,
        listing: null,
        loading: false,
        error: '',
        manual: ''
      };
      notify();
      listPath(start === '' ? undefined : start);
    }

    function closePicker() {
      store.ui.picker = null;
      notify();
    }

    // --------------------------------------------------------------- icons

    function svg(children, size, viewBox) {
      return h('svg', {
        width: size, height: size, viewBox: viewBox || '0 0 24 24',
        fill: 'none', 'aria-hidden': 'true', focusable: 'false'
      }, children);
    }

    function chipIcon(size) {
      return svg([
        h('path', { key: 'b', d: 'M7.2 7.2h9.6v9.6H7.2z', stroke: 'currentColor', strokeWidth: 1.6, strokeLinejoin: 'round' }),
        h('path', {
          key: 'p',
          d: 'M9.6 3.4v3.8M12 3.4v3.8M14.4 3.4v3.8M9.6 16.8v3.8M12 16.8v3.8M14.4 16.8v3.8M3.4 9.6h3.8M3.4 12h3.8M3.4 14.4h3.8M16.8 9.6h3.8M16.8 12h3.8M16.8 14.4h3.8',
          stroke: 'currentColor', strokeWidth: 1.4, strokeLinecap: 'round'
        }),
        h('path', { key: 'w', d: 'M9.4 13.4l1.5-2.8 1.6 3.4 1.4-2.6', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })
      ], size);
    }

    function backIcon(size) {
      return svg([
        h('path', { key: 'a', d: 'M14.5 5.5 8 12l6.5 6.5', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' }),
        h('path', { key: 'b', d: 'M8.4 12H20', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' })
      ], size);
    }

    function folderIcon(size) {
      return svg([
        h('path', {
          key: 'a',
          d: 'M3.4 7.2a1.8 1.8 0 0 1 1.8-1.8h3.4l2 2.4h7a1.8 1.8 0 0 1 1.8 1.8v7.6a1.8 1.8 0 0 1-1.8 1.8H5.2a1.8 1.8 0 0 1-1.8-1.8Z',
          stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round'
        })
      ], size);
    }

    function fileIcon(size) {
      return svg([
        h('path', { key: 'a', d: 'M6.5 3.6h6.6l4.4 4.4v12.4H6.5Z', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { key: 'b', d: 'M13.1 3.6v4.5h4.4', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' })
      ], size);
    }

    function plusIcon(size) {
      return svg([h('path', { key: 'a', d: 'M12 5.2v13.6M5.2 12h13.6', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' })], size);
    }

    function gripIcon(size) {
      return svg([
        h('circle', { key: 'a', cx: 9, cy: 7, r: 1.15, fill: 'currentColor' }),
        h('circle', { key: 'b', cx: 15, cy: 7, r: 1.15, fill: 'currentColor' }),
        h('circle', { key: 'c', cx: 9, cy: 12, r: 1.15, fill: 'currentColor' }),
        h('circle', { key: 'd', cx: 15, cy: 12, r: 1.15, fill: 'currentColor' }),
        h('circle', { key: 'e', cx: 9, cy: 17, r: 1.15, fill: 'currentColor' }),
        h('circle', { key: 'f', cx: 15, cy: 17, r: 1.15, fill: 'currentColor' })
      ], size);
    }
    function closeIcon(size) {
      return svg([h('path', { key: 'a', d: 'M6.4 6.4l11.2 11.2M17.6 6.4 6.4 17.6', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' })], size);
    }

    function playIcon(size) {
      return svg([h('path', { key: 'a', d: 'M8.2 5.6 18 12l-9.8 6.4Z', fill: 'currentColor' })], size);
    }

    function copyIcon(size) {
      return svg([
        h('rect', { key: 'a', x: 9, y: 9, width: 10.5, height: 10.5, rx: 2.2, stroke: 'currentColor', strokeWidth: 1.5 }),
        h('path', { key: 'b', d: 'M15 6.6V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h.6', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })
      ], size);
    }

    function checkIcon(size) {
      return svg([h('path', { key: 'a', d: 'm5 12.5 4.4 4.4L19 7.2', stroke: 'currentColor', strokeWidth: 1.9, strokeLinecap: 'round', strokeLinejoin: 'round' })], size);
    }

    function listIcon(size) {
      return svg([
        h('path', { key: 'a', d: 'M8.5 7h11M8.5 12h11M8.5 17h11', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round' }),
        h('path', { key: 'b', d: 'M4.4 7h.2M4.4 12h.2M4.4 17h.2', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' })
      ], size);
    }

    function boxIcon(size) {
      return svg([
        h('path', { key: 'a', d: 'M4.2 8.4 12 4.4l7.8 4-7.8 4Z', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { key: 'b', d: 'M4.2 8.4v7.2l7.8 4 7.8-4V8.4', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { key: 'c', d: 'M12 12.4v7.2', stroke: 'currentColor', strokeWidth: 1.5 })
      ], size);
    }

    function bookIcon(size) {
      return svg([
        h('path', { key: 'a', d: 'M5 5.2h5.2a2 2 0 0 1 2 2v11a2 2 0 0 0-2-2H5Z', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { key: 'b', d: 'M19 5.2h-5.2a2 2 0 0 0-2 2v11a2 2 0 0 1 2-2H19Z', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' })
      ], size);
    }

    // ------------------------------------------------------------- components

    function WorkflowEntry(props) {
      const isOpen = useOpen();
      const wide = props === undefined || props.wide === undefined ? true : props.wide !== false;
      return h('button', {
        type: 'button',
        className: 'w-entry' + (isOpen ? ' is-open' : '') + (wide ? '' : ' is-rail'),
        title: isOpen ? '回到对话' : '打开 FPGA 研制工作台',
        'aria-label': isOpen ? '回到对话' : '打开 FPGA 研制工作台',
        'aria-pressed': isOpen ? 'true' : 'false',
        onClick: function (event) {
          event.preventDefault();
          event.stopPropagation();
          if (isOpen) leave();
          else enter();
        }
      }, h('span', { className: 'w-entry-ico' }, chipIcon(20)), wide ? h('span', { className: 'w-entry-label' }, 'FPGA 工作流') : null);
    }

    function Badge(props) {
      const meta = STATUS[props.status] === undefined ? STATUS.ready : STATUS[props.status];
      return h('span', { className: 'w-badge w-badge--' + meta.tone }, props.label || meta.label);
    }

    // Route state: one page at a time (a phase, the cross-phase list, artifacts
    // or the knowledge base). Only the skill per phase is persisted.
    if (store.ui.page === undefined) store.ui.page = 'phase:' + (store.ui.phase || '01');

    function clockIcon(size) {
      return svg([
        h('circle', { key: 'a', cx: 12, cy: 12, r: 8.4, stroke: 'currentColor', strokeWidth: 1.5 }),
        h('path', { key: 'b', d: 'M12 7.6V12l3 2', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })
      ], size);
    }

    function layersIcon(size) {
      return svg([
        h('path', { key: 'a', d: 'M12 4.2 20 8.4l-8 4.2-8-4.2Z', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { key: 'b', d: 'm4.6 12.2 7.4 3.9 7.4-3.9', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { key: 'c', d: 'm4.6 15.8 7.4 3.9 7.4-3.9', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' })
      ], size);
    }

    function NavItem(props) {
      const active = props.active === true;
      return h('li', null,
        h('button', {
          type: 'button',
          className: 'w-nav-row' + (active ? ' is-active' : ''),
          'aria-current': active ? 'page' : undefined,
          onClick: props.onSelect
        },
          props.no !== undefined
            ? h('span', { className: 'w-nav-no' }, props.no)
            : h('span', { className: 'w-nav-ico' }, props.icon),
          h('span', { className: 'w-nav-text' }, props.label)
        )
      );
    }

    const PHASE_NOTES = {
      '01': '任务书进入、需求冻结与规格一致性，一条链走完再进架构。',
      '02': '从冻结需求到目标架构与文档交接，先批准范围再设计。',
      '03': '逐条原子需求展开仿真义务，评审确认后再出细则。',
      '04': 'Testbench、仿真执行与覆盖率采集；当前目录还没有独立入口。',
      '05': 'Vivado 工程、实现与时序，按任务判定子流程。',
      '06': '从 FEIP 数据包生成确认测试计划与表格化细则，只有仿真义务计划需要设计师确认。',
      '07': '文实一致性检查与只读编码规则检查，配套送测问题复查。',
      '08': '研制总结与验收交付资料；尚无独立入口。',
      'common': '贯穿全程的追溯与版本管理。'
    };

    function SkillRow(props) {
      const skill = props.skill;
      const meta = STATUS[skill.status] === undefined ? STATUS.ready : STATUS[skill.status];
      return h('li', { className: 'w-row-item' },
        h('button', { type: 'button', className: 'w-skill-row', onClick: props.onOpen },
          h('span', { className: 'w-skill-row-no' }, props.no),
          h('span', { className: 'w-skill-row-body' },
            h('span', { className: 'w-skill-row-title' },
              skill.title,
              props.last ? h('span', { className: 'w-tag-soft' }, '上次') : null
            ),
            h('span', { className: 'w-skill-row-desc' }, skill.desc),
            h('span', { className: 'w-skill-row-meta' },
              '产物 · ' + skill.outputs[0] + (props.version ? ' · v' + props.version : ''))
          ),
          h('span', { className: 'w-muted' }, meta.label)
        )
      );
    }

    function PhasePage(props) {
      const phase = props.phase;
      return h('div', { className: 'w-page' },
        h('h2', { className: 'w-h2' }, phase.title),
        h('p', { className: 'w-lead' }, PHASE_NOTES[phase.id] || ''),
        h('ul', { className: 'w-rows' },
          phase.skills.map(function (name, index) {
            return h(SkillRow, {
              key: name,
              skill: SKILLS[name],
              version: SKILL_VERSIONS[name] || '',
              no: String(index + 1).padStart(2, '0'),
              last: props.lastSkill === name,
              onOpen: function () { props.onOpen(name); }
            });
          }),
          phase.planned.map(function (label) {
            return h('li', { key: label, className: 'w-row-item' },
              h('div', { className: 'w-skill-row is-static' },
                h('span', { className: 'w-skill-row-no' }, '--'),
                h('span', { className: 'w-skill-row-body' },
                  h('span', { className: 'w-skill-row-title' }, label),
                  h('span', { className: 'w-skill-row-desc' }, '规划能力，暂无独立入口')
                ),
                h('span', { className: 'w-muted' }, '未接入')
              )
            );
          })
        )
      );
    }

    function RoleRow(props) {
      const role = props.role;
      const paths = props.paths;
      const exts = Array.isArray(role.exts) ? role.exts : [];
      const hasPaths = paths.length > 0;
      const mismatched = exts.length === 0 ? 0 : paths.filter(function (path) {
        const lower = path.toLowerCase();
        return !exts.some(function (ext) { return lower.endsWith(ext); });
      }).length;
      return h('div', { className: 'w-role' },
        h('div', { className: 'w-role-head' },
          h('span', { className: 'w-role-label' }, role.label),
          role.required === true ? h('span', { className: 'w-required' }, '必填') : h('span', { className: 'w-optional' }, '可选'),
          role.multi === true ? h('span', { className: 'w-tag' }, '可多选') : null,
          hasPaths
            ? h('button', {
              type: 'button',
              className: 'w-btn w-btn--add',
              onClick: props.onAdd,
              title: role.kind === 'dir' ? '继续添加目录' : '继续添加文件或目录'
            }, plusIcon(13), h('span', null, role.kind === 'dir' ? '添加目录' : '添加文件'))
            : null
        ),
        role.hint ? h('p', { className: 'w-role-hint' }, role.hint) : null,
        mismatched > 0
          ? h('p', { className: 'w-role-warn' }, '有 ' + mismatched + ' 项扩展名不在建议范围（' + exts.join(' / ') + '）；仍可提交，格式由 Skill 校验。')
          : null,
        hasPaths
          ? h('ul', { className: 'w-chips' }, paths.map(function (path) {
            return h('li', { key: path, className: 'w-chip' },
              h('span', { className: 'w-chip-ico' }, role.kind === 'dir' ? folderIcon(13) : fileIcon(13)),
              h('span', { className: 'w-chip-text', title: path }, path),
              h('button', {
                type: 'button',
                className: 'w-chip-x',
                'aria-label': '移除 ' + path,
                onClick: function () { props.onRemove(path); }
              }, closeIcon(11))
            );
          }))
          : h('button', {
            type: 'button',
            className: 'w-role-add',
            onClick: props.onAdd
          },
            plusIcon(15),
            h('span', null, role.kind === 'dir' ? '选择目录' : '选择文件'),
            h('span', { className: 'w-role-add-hint' }, role.kind === 'dir' ? '浏览本机目录' : '浏览或粘贴路径')
          )
      );
    }

    function SkillDetail(props) {
      const skill = props.skill;
      const phase = props.phase;
      const data = props.data;
      const linked = props.artifacts;
      const run = props.latestRun;
      const mode = modeOf(data, skill);
      const intro = SKILL_INTROS[skill.name] || null;
      const missing = requiredMissing(skill, data);
      const meta = STATUS[skill.status] === undefined ? STATUS.ready : STATUS[skill.status];

      return h('div', { className: 'w-page' },
        h('button', { type: 'button', className: 'w-back-link', onClick: props.onBack }, '‹ ' + phase.title),
        h('div', { className: 'w-h2-row' },
          h('h2', { className: 'w-h2' }, skill.title),
          h('div', { className: 'w-h2-side' },
            h('span', {
              className: 'w-ver' + (SKILL_VERSIONS[skill.name] ? '' : ' is-empty'),
              title: SKILL_VERSIONS[skill.name] ? '打包时记录的 skill 版本' : '该 skill 未声明版本'
            }, SKILL_VERSIONS[skill.name] ? 'v' + SKILL_VERSIONS[skill.name] : '未标版本'),
            h('span', { className: 'w-muted' }, meta.label)
          )
        ),
        h('p', { className: 'w-lead' }, skill.desc),
        h('p', { className: 'w-mono-line' }, '$' + skill.name + '  ·  ' + skill.dir + '\\' + skill.entry),
        h('p', { className: 'w-note' }, skill.status === 'draft'
          ? '待完善：确认该 Skill 已注册且输入齐全后再运行；批准与校验仍由 Skill 执行。'
          : '注册状态未确认（本页按目录配置显示）；输入完整性由 Skill 校验。'),
        intro !== null
          ? h('section', { className: 'w-intro' },
            h('p', { className: 'w-intro-tag' }, intro.tagline),
            h('p', { className: 'w-intro-text' }, intro.intro),
            Array.isArray(intro.points) && intro.points.length > 0
              ? h('ul', { className: 'w-intro-points' }, intro.points.map(function (point) {
                return h('li', { key: point }, point);
              }))
              : null
          )
          : null,
        skill.sub ? h('p', { className: 'w-note' }, skill.sub) : null,

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '执行模式'),
          (Array.isArray(skill.modeGroups) && skill.modeGroups.length > 0
            ? skill.modeGroups
            : [{ id: 'mode', label: '', options: Array.isArray(skill.modes) ? skill.modes : [] }]
          ).map(function (group) {
            const picked = modeSelection(data, skill).values[group.id];
            if (group.multi === true) {
              return h('div', { key: group.id, className: 'w-mode-group' },
                group.label ? h('span', { className: 'w-mode-label' }, group.label) : null,
                h('div', { className: 'w-check-grid' }, group.options.map(function (item) {
                  const on = Array.isArray(picked) && picked.indexOf(item) !== -1;
                  return h('label', { key: item, className: 'w-check' + (on ? ' is-on' : '') },
                    h('input', {
                      type: 'checkbox',
                      checked: on,
                      onChange: function () {
                        const stored = data.modes[skill.name];
                        const base = stored !== null && typeof stored === 'object' ? stored : {};
                        const current = Array.isArray(base[group.id]) ? base[group.id].slice() : [];
                        const index = current.indexOf(item);
                        if (index === -1) current.push(item); else current.splice(index, 1);
                        const next = Object.assign({}, base);
                        next[group.id] = current;
                        data.modes[skill.name] = next;
                        commit();
                      }
                    }),
                    h('span', null, item)
                  );
                }))
              );
            }
            return h('label', { key: group.id, className: 'w-mode-row' },
              group.label ? h('span', { className: 'w-mode-label' }, group.label) : null,
              h('select', {
                className: 'w-select',
                value: picked,
                onChange: function (event) {
                  const stored = data.modes[skill.name];
                  if (Array.isArray(skill.modeGroups) && skill.modeGroups.length > 0) {
                    const next = Object.assign({}, stored !== null && typeof stored === 'object' ? stored : {});
                    next[group.id] = event.target.value;
                    data.modes[skill.name] = next;
                  } else {
                    data.modes[skill.name] = event.target.value;
                  }
                  commit();
                }
              }, group.options.map(function (item) { return h('option', { key: item, value: item }, item); }))
            );
          })
        ),

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '补充要求（可选）'),
          h('textarea', {
            className: 'w-textarea',
            rows: 3,
            placeholder: '用一句话补充你的具体要求，例如：比特流只要 impl_1；时序分析先看 WNS 最差 10 条；PS 配置沿用上次工程。',
            value: extrasOf(data, skill.name),
            onChange: function (event) { setExtras(skill.name, event.target.value); }
          })
        ),

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '输入资料'),
          skill.inputs.map(function (role) {
            return h(RoleRow, {
              key: role.id,
              role: role,
              paths: inputsOf(data, skill.name, role.id),
              onAdd: function () { openPicker(skill, role); },
              onRemove: function (path) { removeInput(skill.name, role.id, path); }
            });
          })
        ),

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '可引用的上游产物'),
          linked.length === 0
            ? h('p', { className: 'w-note' }, '暂无已登记的上游产物。可在「产物与交接」登记，或从上游 Skill 带入。')
            : h('ul', { className: 'w-rows w-rows--tight' }, linked.map(function (artifact) {
              return h('li', { key: artifact.id, className: 'w-row-item w-row-item--inline' },
                h('span', { className: 'w-inline-main' },
                  h('span', { className: 'w-inline-title' }, artifact.type),
                  h('span', { className: 'w-mono-line w-mono-line--inline', title: artifact.path }, artifact.path)
                ),
                h('button', {
                  type: 'button',
                  className: 'w-btn w-btn--tiny',
                  onClick: function () { props.onHandoff(artifact); }
                }, '带入')
              );
            }))
        ),

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '预期产物'),
          h('ul', { className: 'w-plain-list' }, skill.outputs.map(function (item) {
            return h('li', { key: item }, item);
          }))
        ),

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '人工确认'),
          h('ul', { className: 'w-plain-list w-plain-list--warn' }, skill.confirm.map(function (item) {
            return h('li', { key: item }, item);
          }))
        ),

        h('div', { className: 'w-block' },
          h('div', { className: 'w-block-title' }, '知识引用'),
          h('p', { className: 'w-note' }, '待连接。接入后在这里选择本次运行要引用的规范或经验条目。')
        ),

        run !== undefined && run !== null
          ? h('div', { className: 'w-block' },
            h('div', { className: 'w-block-title' }, '最近一次运行'),
            h('p', { className: 'w-run-line' },
              h('span', { className: 'w-mono-line w-mono-line--inline' }, run.id),
              h('span', null, run.statusText),
              h('span', { className: 'w-muted' }, run.atText)
            ),
            run.message ? h('p', { className: 'w-note' }, run.message) : null
          )
          : null,

        h('div', { className: 'w-action-bar' },
          h('p', { className: 'w-note w-note--inline' }, missing.length > 0
            ? '还缺必填资料：' + missing.join('、')
            : '指令会带上以上路径，发送到页头选定的会话。'),
          h('div', { className: 'w-actions' },
            h('button', {
              type: 'button',
              className: 'w-btn w-btn--solid',
              onClick: props.onRun,
              disabled: missing.length > 0 || (run !== undefined && run !== null && run.status === 'submitting'),
              title: missing.length === 0 ? '生成指令并发送到所选会话' : '请先补齐必填资料'
            }, playIcon(13), h('span', null, '开始运行')),
            h('button', { type: 'button', className: 'w-btn', onClick: props.onPreview }, h('span', null, '预览指令')),
            h('button', { type: 'button', className: 'w-btn', onClick: props.onCopy }, copyIcon(13), h('span', null, '复制指令'))
          )
        )
      );
    }

    function Picker(props) {
      const picker = props.picker;
      const listing = picker.listing;
      const entries = listing !== null && Array.isArray(listing.entries) ? sortEntries(listing.entries) : [];
      const crumbs = listing !== null && Array.isArray(listing.crumbs) ? listing.crumbs : [];
      const skill = skillOf(picker.skill);
      const role = skill.inputs.find(function (item) { return item.id === picker.role; });
      const paths = inputsOf(project().data, picker.skill, picker.role);
      const base = picker.base || '';
      const baseName = base === '' ? '' : base.replace(/[\\/]+$/, '').split(/[\\/]/).filter(Boolean).pop();
      const shownCrumbs = base === '' ? crumbs : crumbs.filter(function (crumb) { return isUnderBase(base, crumb.path); });

      function commitManual() {
        const value = String(picker.manual || '').trim();
        if (value === '') return;
        addInput(picker.skill, picker.role, value);
        picker.manual = '';
        notify();
      }

      return h('div', { className: 'w-overlay', role: 'dialog', 'aria-modal': 'true', 'aria-label': '选择输入资料' },
        h('div', { className: 'w-modal w-modal--picker' },
          h('header', { className: 'w-modal-head' },
            h('div', null,
              h('h3', { className: 'w-modal-title' }, '添加资料 · ' + (role !== undefined ? role.label : '')),
              h('p', { className: 'w-modal-sub' }, skill.title + '：' + (role !== undefined ? role.hint || (role.kind === 'dir' ? '选择目录' : '选择文件') : ''))
            ),
            h('button', { type: 'button', className: 'w-icon-btn', 'aria-label': '关闭', onClick: props.onClose }, closeIcon(16))
          ),
          h('div', { className: 'w-modal-bar' },
            h('input', {
              className: 'w-input',
              autoFocus: true,
              placeholder: picker.kind === 'dir' ? '粘贴目录完整路径，回车加入' : '粘贴文件完整路径，回车加入',
              value: picker.manual,
              onChange: function (event) { picker.manual = event.target.value; notify(); },
              onKeyDown: function (event) {
                if (event.key !== 'Enter') return;
                event.preventDefault();
                commitManual();
              }
            }),
            h('button', { type: 'button', className: 'w-btn w-btn--tiny', onClick: commitManual }, plusIcon(12), h('span', null, '加入')),
            h('button', {
              type: 'button',
              className: 'w-btn w-btn--tiny',
              onClick: function () {
                const ui = service('uiWorkspace');
                if (ui === undefined || typeof ui.pickDirectory !== 'function') {
                  picker.error = '这个 DSH 版本没有目录选择器；请直接粘贴完整路径。';
                  notify();
                  return;
                }
                Promise.resolve(ui.pickDirectory()).then(function (picked) {
                  if (typeof picked !== 'string' || picked === '') return;
                  if (picker.kind === 'dir') {
                    addInput(picker.skill, picker.role, picked);
                    listPath(picked);
                    return;
                  }
                  // The system chooser only returns directories: drop the folder
                  // into the path field so the operator can finish the file name.
                  picker.manual = /[\\/]$/.test(picked) ? picked : picked + '\\';
                  notify();
                  listPath(picked);
                }, function (error) {
                  picker.error = '选择目录失败：' + String(error && error.message ? error.message : error);
                  notify();
                });
              },
              title: '用系统选择框定位目录'
            }, folderIcon(13), h('span', null, '选目录'))
          ),
          base !== ''
            ? h('p', { className: 'w-tip w-tip--base' }, '基础路径：' + base + '（选择范围以工作区为起点，不能越出工作区）')
            : null,
          h('p', { className: 'w-tip' }, picker.kind === 'dir'
            ? '点目录进入，点「＋」加入该目录；也可以直接粘贴完整路径。'
            : '点文件即加入，点目录进入；系统「选目录」只用于定位，之后在输入框补全文件名。'),
          h('div', { className: 'w-crumbs' },
            h('button', {
              type: 'button',
              className: 'w-crumb' + (base !== '' ? ' w-crumb--base' : ''),
              title: base === '' ? '从主目录开始浏览' : '回到工作区基础路径：' + base,
              onClick: function () { listPath(base === '' ? undefined : base); }
            }, base === '' ? '主目录' : '工作区 · ' + baseName),
            shownCrumbs.map(function (crumb) {
              return h('button', { key: crumb.path, type: 'button', className: 'w-crumb', onClick: function () { listPath(crumb.path); } }, crumb.name);
            }),
            h('span', { className: 'w-crumb-path', title: picker.path }, picker.path)
          ),
          h('div', { className: 'w-list' },
            picker.loading ? h('p', { className: 'w-list-note' }, '读取中…') : null,
            picker.error !== '' ? h('p', { className: 'w-list-note w-list-note--error' }, picker.error) : null,
            entries.length === 0 && !picker.loading ? h('p', { className: 'w-list-note' }, '这个目录没有可显示的子项。') : null,
            entries.map(function (entry) {
              const isDir = looksLikeDir(entry.name);
              return h('div', { key: entry.path, className: 'w-row' },
                h('button', {
                  type: 'button',
                  className: 'w-row-main',
                  onClick: function () {
                    if (isDir) listPath(entry.path);
                    else addInput(picker.skill, picker.role, entry.path);
                  },
                  title: isDir ? '打开目录' : '加入资料'
                },
                  h('span', { className: 'w-row-ico' }, isDir ? folderIcon(15) : fileIcon(15)),
                  h('span', { className: 'w-row-name' }, entry.name)
                ),
                h('button', {
                  type: 'button',
                  className: 'w-icon-btn',
                  'aria-label': '加入 ' + entry.name,
                  title: '加入本次资料',
                  onClick: function () { addInput(picker.skill, picker.role, entry.path); }
                }, plusIcon(14))
              );
            })
          ),
          h('footer', { className: 'w-modal-foot' },
            h('div', { className: 'w-foot-selected' },
              h('span', { className: 'w-foot-label' }, '已选 ' + paths.length + ' 项'),
              paths.map(function (path) {
                return h('span', { key: path, className: 'w-chip' },
                  h('span', { className: 'w-chip-text', title: path }, path),
                  h('button', { type: 'button', className: 'w-chip-x', 'aria-label': '移除', onClick: function () { removeInput(picker.skill, picker.role, path); } }, closeIcon(11))
                );
              })
            ),
            h('div', { className: 'w-foot-actions' },
              h('button', { type: 'button', className: 'w-btn w-btn--tiny', onClick: function () { addInput(picker.skill, picker.role, picker.path); } }, plusIcon(12), h('span', null, '加入当前目录')),
              h('button', { type: 'button', className: 'w-btn w-btn--solid', onClick: props.onClose }, '完成')
            )
          )
        )
      );
    }

    function PreviewModal(props) {
      return h('div', { className: 'w-overlay', role: 'dialog', 'aria-modal': 'true', 'aria-label': '预览指令' },
        h('div', { className: 'w-modal w-modal--preview' },
          h('header', { className: 'w-modal-head' },
            h('div', null,
              h('h3', { className: 'w-modal-title' }, '预览指令'),
              h('p', { className: 'w-modal-sub' }, '与「开始运行」「复制指令」使用同一个生成函数。')
            ),
            h('button', { type: 'button', className: 'w-icon-btn', 'aria-label': '关闭', onClick: props.onClose }, closeIcon(16))
          ),
          h('pre', { className: 'w-pre' }, props.text),
          h('footer', { className: 'w-modal-foot w-modal-foot--end' },
            h('button', { type: 'button', className: 'w-btn', onClick: props.onCopy }, copyIcon(13), h('span', null, '复制')),
            h('button', { type: 'button', className: 'w-btn w-btn--solid', onClick: props.onRun, disabled: props.disabled }, playIcon(13), h('span', null, '开始运行')),
            h('button', { type: 'button', className: 'w-btn w-btn--ghost', onClick: props.onClose }, '关闭')
          )
        )
      );
    }

    function RunsModal(props) {
      const runs = props.runs;
      return h('div', { className: 'w-overlay', role: 'dialog', 'aria-modal': 'true', 'aria-label': '运行记录' },
        h('div', { className: 'w-modal w-modal--wide' },
          h('header', { className: 'w-modal-head' },
            h('div', null,
              h('h3', { className: 'w-modal-title' }, '运行记录'),
              h('p', { className: 'w-modal-sub' }, '只记录实际发起的提交；执行状态以会话快照为依据，读取不到时显示「见会话」。')
            ),
            h('button', { type: 'button', className: 'w-icon-btn', 'aria-label': '关闭', onClick: props.onClose }, closeIcon(16))
          ),
          runs.length === 0
            ? h('p', { className: 'w-list-note' }, '还没有运行记录。')
            : h('div', { className: 'w-table' },
              h('div', { className: 'w-tr w-tr--head' },
                h('span', null, 'Skill'), h('span', null, '目标会话'), h('span', null, '发起时间'), h('span', null, '状态'), h('span', null, '操作')
              ),
              runs.map(function (run) {
                return h('div', { key: run.id, className: 'w-tr' },
                  h('span', { className: 'w-td' },
                    h('span', { className: 'w-td-main' }, run.skillTitle || run.skill),
                    h('span', { className: 'w-td-sub' }, run.id + ' · ' + (run.mode || ''))
                  ),
                  h('span', { className: 'w-td', title: run.sessionId }, run.sessionLabel || '—'),
                  h('span', { className: 'w-td' }, run.atText || ''),
                  h('span', { className: 'w-td' }, h(Badge, { status: run.statusTone, label: run.statusText })),
                  h('span', { className: 'w-td w-td--actions' },
                    run.sessionId !== ''
                      ? h('button', {
                        type: 'button',
                        className: 'w-btn w-btn--tiny',
                        onClick: function () { props.onOpenSession(run.sessionId); }
                      }, '打开会话')
                      : null,
                    h('button', {
                      type: 'button',
                      className: 'w-btn w-btn--tiny',
                      onClick: function () { props.onShowPrompt(run); }
                    }, '查看指令')
                  )
                );
              })
            ),
          h('footer', { className: 'w-modal-foot w-modal-foot--end' },
            h('button', { type: 'button', className: 'w-btn w-btn--ghost', onClick: props.onClose }, '关闭')
          )
        )
      );
    }

    function RegisterCard(props) {
      const form = props.form;
      const skill = skillOf(form.skill);
      return h('div', { className: 'w-card w-card--form' },
        h('div', { className: 'w-card-head' }, h('span', null, '登记产物')),
        h('div', { className: 'w-form' },
          h('div', { className: 'w-form-row' },
            h('span', { className: 'w-form-label' }, 'Skill'),
            h('select', {
              className: 'w-select',
              value: form.skill,
              onChange: function (event) { props.onForm({ skill: event.target.value, type: skillOf(event.target.value).artifactTypes[0] }); }
            }, Object.keys(SKILLS).map(function (name) {
              return h('option', { key: name, value: name }, SKILLS[name].title);
            }))
          ),
          skill !== null ? h('div', { className: 'w-form-row' },
            h('span', { className: 'w-form-label' }, '类型'),
            h('select', {
              className: 'w-select',
              value: form.type,
              onChange: function (event) { props.onForm({ type: event.target.value }); }
            }, skill.artifactTypes.map(function (type) {
              return h('option', { key: type, value: type }, type);
            }))
          ) : null,
          h('div', { className: 'w-form-row' },
            h('span', { className: 'w-form-label' }, '路径'),
            h('input', {
              className: 'w-input',
              placeholder: '实际输出路径',
              value: form.path,
              onChange: function (event) { props.onForm({ path: event.target.value }); }
            }),
            h('button', {
              type: 'button',
              className: 'w-btn w-btn--tiny',
              onClick: function () {
                const ui = service('uiWorkspace');
                if (ui === undefined || typeof ui.pickDirectory !== 'function') return;
                Promise.resolve(ui.pickDirectory()).then(function (picked) {
                  if (typeof picked === 'string' && picked !== '') props.onForm({ path: picked });
                }, function () {});
              }
            }, folderIcon(13), h('span', null, '选择'))
          ),
          h('div', { className: 'w-form-row' },
            h('span', { className: 'w-form-label' }, '版本'),
            h('input', {
              className: 'w-input',
              placeholder: 'revision / 指纹（可留空）',
              value: form.revision,
              onChange: function (event) { props.onForm({ revision: event.target.value }); }
            }),
            h('select', {
              className: 'w-select',
              value: form.reviewState,
              onChange: function (event) { props.onForm({ reviewState: event.target.value }); }
            },
              h('option', { value: 'draft' }, 'draft'),
              h('option', { value: 'candidate' }, 'candidate'),
              h('option', { value: 'released' }, 'released'),
              h('option', { value: 'unknown' }, 'unknown')
            )
          ),
          h('div', { className: 'w-form-row w-form-row--end' },
            h('button', { type: 'button', className: 'w-btn w-btn--ghost', onClick: props.onCancel }, '取消'),
            h('button', {
              type: 'button',
              className: 'w-btn w-btn--solid',
              disabled: String(form.path).trim() === '',
              onClick: props.onRegister
            }, '登记')
          )
        )
      );
    }

    function ArtifactsPage(props) {
      const artifacts = props.artifacts;
      return h('div', { className: 'w-page' },
        h('div', { className: 'w-h2-row' },
          h('h2', { className: 'w-h2' }, '产物与交接'),
          h('button', { type: 'button', className: 'w-btn w-btn--solid', onClick: props.onOpenRegister }, '登记产物')
        ),
        h('p', { className: 'w-lead' }, '登记实际生成的产物；「带入下游」只修改本次拟运行的输入，下一步仍由你发起。'),
        props.form !== null
          ? h(RegisterCard, {
            form: props.form,
            onForm: props.onForm,
            onCancel: props.onCancelRegister,
            onRegister: props.onRegister
          })
          : null,
        h('div', { className: 'w-card' },
          h('div', { className: 'w-card-head' },
            h('span', null, '产物'),
            h('span', { className: 'w-muted' }, artifacts.length + ' 项')
          ),
          artifacts.length === 0
            ? h('div', { className: 'w-card-empty' }, '还没有登记产物。点右上角「登记产物」把实际输出记下来，就能带入下一阶段。')
            : artifacts.map(function (artifact) {
              const targets = handoffTargets(artifact.skill);
              const owner = skillOf(artifact.skill);
              return h('div', { key: artifact.id, className: 'w-card-row' },
                h('div', { className: 'w-card-main' },
                  h('div', { className: 'w-row-title' }, artifact.type),
                  h('div', { className: 'w-mono-line' }, artifact.path),
                  h('div', { className: 'w-muted' }, (owner !== null ? owner.title : artifact.skill) + ' · ' + artifact.reviewState + ' · ' + artifact.revision)
                ),
                h('div', { className: 'w-row-actions' },
                  targets.map(function (target) {
                    const downstream = skillOf(target.to);
                    return h('button', {
                      key: target.to,
                      type: 'button',
                      className: 'w-btn w-btn--tiny',
                      onClick: function () { props.onHandoff(artifact, target); }
                    }, '带入 ' + (downstream !== null ? downstream.title : target.to));
                  }),
                  h('button', {
                    type: 'button',
                    className: 'w-btn w-btn--tiny w-btn--danger',
                    onClick: function () { props.onDelete(artifact); }
                  }, '删除')
                )
              );
            })
        )
      );
    }

    function KnowledgePage() {
      const sources = [
        { title: '工程规范与模板', text: '接口与时钟复位规范、文档模板、编码规则' },
        { title: '项目经验与问题复盘', text: '历史问题、根因与处置记录' },
        { title: '成熟 IP 与复用资料', text: 'IP 手册、参数与集成示例' }
      ];
      return h('div', { className: 'w-page' },
        h('h2', { className: 'w-h2' }, '知识库'),
        h('p', { className: 'w-lead' }, '接入后，在技能详情中查找资料并选入本次运行的上下文。'),
        h('div', { className: 'w-card' },
          h('div', { className: 'w-card-head' },
            h('span', null, '知识源'),
            h('span', { className: 'w-muted' }, '未接入')
          ),
          sources.map(function (source) {
            return h('div', { key: source.title, className: 'w-card-row' },
              h('div', { className: 'w-card-main' },
                h('div', { className: 'w-row-title' }, source.title),
                h('div', { className: 'w-muted' }, source.text)
              ),
              h('span', { className: 'w-muted' }, '待连接')
            );
          }),
          h('p', { className: 'w-card-note' }, '引用记录保留来源、版本与定位，随本次运行保存。')
        )
      );
    }

    // ------------------------------------------------------------- status

    const RUN_TONE = {
      submitting: { text: '提交中', tone: 'brand' },
      submitted: { text: '已提交', tone: 'ok' },
      running: { text: '执行中', tone: 'brand' },
      ended: { text: '已结束（见会话）', tone: 'idle' },
      draft: { text: '已写入草稿', tone: 'warn' },
      failed: { text: '提交失败', tone: 'error' }
    };

    function decorateRun(run) {
      const meta = RUN_TONE[run.status] || RUN_TONE.submitted;
      let atText = run.at;
      try {
        const date = new Date(run.at);
        atText = date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) +
          ' ' + pad(date.getHours()) + ':' + pad(date.getMinutes());
      } catch (error) {
        atText = String(run.at);
      }
      return Object.assign({}, run, { statusText: meta.text, statusTone: meta.tone, atText: atText });
    }

    // ------------------------------------------------------------ workbench

    function Workbench(props) {
      const state = useStore();
      const data = project().data;
      const sessions = readSessionState(props);
      store.sessions = sessions;

      const page = typeof store.ui.page === 'string' && store.ui.page !== '' ? store.ui.page : 'phase:01';
      if (store.ui.page !== page) store.ui.page = page;
      const kind = page.indexOf('phase:') === 0 ? 'phase' : page;
      const phaseId = kind === 'phase' ? page.slice(6) : (kind === 'common' ? 'common' : '');
      const phase = phaseId !== '' ? phaseOf(phaseId) : null;
      const skillName = typeof store.ui.skill === 'string' ? store.ui.skill : '';
      const skill = skillName !== '' ? skillOf(skillName) : null;

      const runs = data.runs.map(decorateRun);
      const activeRuns = runs.filter(function (run) {
        return run.status === 'submitted' || run.status === 'running';
      });
      const bumpElapsed = React.useState(0)[1];
      React.useEffect(function () {
        if (activeRuns.length === 0) return undefined;
        const timer = window.setInterval(function () { bumpElapsed(function (n) { return n + 1; }); }, 1000);
        return function () { window.clearInterval(timer); };
      }, [activeRuns.length]);
      const latestRun = skill !== null
        ? runs.find(function (run) { return run.skill === skill.name; })
        : undefined;

      React.useEffect(function () {
        setOpen(true);
        const onKeyDown = function (event) {
          if (event.key !== 'Escape' || event.defaultPrevented) return;
          if (store.ui.modal !== null) {
            event.preventDefault();
            store.ui.modal = null;
            notify();
            return;
          }
          if (store.ui.picker !== null) {
            event.preventDefault();
            closePicker();
            return;
          }
          if (store.ui.preview !== null) {
            event.preventDefault();
            store.ui.preview = null;
            notify();
            return;
          }
          if (store.ui.skill !== '') {
            event.preventDefault();
            store.ui.skill = '';
            notify();
            return;
          }
          event.preventDefault();
          leave();
        };
        window.addEventListener('keydown', onKeyDown, true);
        return function () {
          window.removeEventListener('keydown', onKeyDown, true);
          setOpen(false);
        };
      }, []);

      // Execution status has one honest source: the retained Session snapshot.
      React.useEffect(function () {
        const tick = function () {
          const sessionsService = service('sessions');
          if (sessionsService === undefined || typeof sessionsService.binding !== 'function') return;
          let changed = false;
          project().data.runs.forEach(function (run) {
            if (run.status !== 'submitted' && run.status !== 'running') return;
            try {
              const binding = sessionsService.binding(run.sessionId);
              if (binding === undefined) return;
              const snapshot = binding.session.getSnapshot();
              if (snapshot === undefined || snapshot === null) return;
              if (snapshot.running === true && run.status !== 'running') {
                run.status = 'running';
                changed = true;
              } else if (snapshot.running !== true && run.status === 'running') {
                run.status = 'ended';
                changed = true;
              }
            } catch (error) {
              // Unknown state stays "submitted"; the row links to the Session.
            }
          });
          if (changed) commit();
        };
        const timer = window.setInterval(tick, 4000);
        return function () { window.clearInterval(timer); };
      }, []);

      function go(next) {
        store.ui.page = next;
        store.ui.skill = '';
        commit();
      }

      function openSkill(name) {
        store.ui.skill = name;
        if (phase !== null) data.selection[phase.id] = name;
        commit();
      }

      function backToPhase() {
        store.ui.skill = '';
        commit();
      }

      function pickProject() {
        const ui = service('uiWorkspace');
        if (ui === undefined || typeof ui.pickDirectory !== 'function') return;
        Promise.resolve(ui.pickDirectory()).then(function (picked) {
          if (typeof picked !== 'string' || picked === '') return;
          const id = picked.toLowerCase();
          if (!store.projects.some(function (p) { return p.id === id; })) {
            store.projects.push({ id: id, label: picked, path: picked, data: emptyData() });
          }
          store.current = id;
          store.ui.page = 'phase:01';
          store.ui.skill = '';
          commit();
        }, function () {});
      }

      function copyText(text) {
        try {
          if (window.navigator.clipboard && typeof window.navigator.clipboard.writeText === 'function') {
            window.navigator.clipboard.writeText(text).then(function () {}, function () {});
            return true;
          }
        } catch (error) {
          // Fall through.
        }
        try {
          const area = document.createElement('textarea');
          area.value = text;
          area.readOnly = true;
          area.style.position = 'fixed';
          area.style.opacity = '0';
          document.body.appendChild(area);
          area.select();
          document.execCommand('copy');
          area.remove();
          return true;
        } catch (error) {
          return false;
        }
      }

      const auto = resolveTarget();
      let content = null;
      if (kind === 'knowledge') {
        content = h(KnowledgePage, null);
      } else if (kind === 'artifacts') {
        content = h(ArtifactsPage, {
          artifacts: data.artifacts,
          form: store.ui.form,
          onOpenRegister: function () {
            const name = phase !== null && phase.skills.length > 0 ? phase.skills[0] : 'task-validation';
            store.ui.form = {
              skill: name,
              type: (skillOf(name) || SKILLS['task-validation']).artifactTypes[0],
              path: '',
              revision: '',
              reviewState: 'draft'
            };
            notify();
          },
          onForm: function (patch) {
            store.ui.form = Object.assign({}, store.ui.form, patch);
            notify();
          },
          onCancelRegister: function () { store.ui.form = null; notify(); },
          onRegister: function () { registerArtifact(store.ui.form); },
          onDelete: function (artifact) {
            const index = data.artifacts.indexOf(artifact);
            if (index !== -1) data.artifacts.splice(index, 1);
            commit();
          },
          onHandoff: function (artifact, target) { applyHandoff(artifact, target); }
        });
      } else if (skill !== null) {
        content = h(SkillDetail, {
          skill: skill,
          phase: phaseOfSkill(skill.name),
          data: data,
          artifacts: data.artifacts.filter(function (artifact) {
            const owner = skillOf(artifact.skill);
            if (owner === null || !Array.isArray(owner.next)) return false;
            return owner.next.some(function (target) { return target.to === skill.name; });
          }),
          latestRun: latestRun,
          onBack: backToPhase,
          onRun: function () { runSkill(skill); },
          onPreview: function () {
            store.ui.preview = buildPrompt(skill, phaseOfSkill(skill.name), data, newRunId());
            notify();
          },
          onCopy: function () {
            const ok = copyText(buildPrompt(skill, phaseOfSkill(skill.name), data, newRunId()));
            store.ui.toast = ok ? '指令已复制' : '复制失败，请用「预览指令」手动复制';
            notify();
            window.setTimeout(function () { store.ui.toast = ''; notify(); }, 2000);
          },
          onHandoff: function (artifact) {
            const targets = handoffTargets(artifact.skill);
            if (targets.length > 0) applyHandoff(artifact, targets[0]);
          }
        });
      } else if (phase !== null) {
        content = h(PhasePage, {
          phase: phase,
          lastSkill: data.selection[phase.id] || '',
          onOpen: openSkill
        });
      }

      return h('section', { className: 'w-root', 'aria-label': 'FPGA 研制工作台' },
        h('div', { className: 'w-bg', 'aria-hidden': 'true' }),
        h('header', { className: 'w-head' },
          h('p', { className: 'w-crumb' }, 'DeepSeek Harness', h('span', null, '/'), 'FPGA 工作流'),
          h('div', { className: 'w-title-row' },
            h('h1', { className: 'w-h1' }, 'FPGA 研制工作台'),
            h('div', { className: 'w-title-tools' },
              activeRuns.length > 0
                ? h('div', { className: 'w-status is-active' },
                  h('span', { className: 'w-status-spin', 'aria-hidden': 'true' }),
                  h('span', { className: 'w-status-text' }, activeRuns.length > 1 ? activeRuns.length + ' 个任务执行中' : '正在执行'),
                  h('span', { className: 'w-status-skill', title: activeRuns[0].skillTitle || activeRuns[0].skill }, activeRuns[0].skillTitle || activeRuns[0].skill),
                  h('span', { className: 'w-status-time' }, elapsedOf(activeRuns[0].at)),
                  activeRuns[0].sessionId !== ''
                    ? h('button', {
                      type: 'button',
                      className: 'w-status-link',
                      onClick: function () {
                        const ui = service('uiWorkspace');
                        if (ui !== undefined && typeof ui.openSession === 'function') ui.openSession(activeRuns[0].sessionId);
                      }
                    }, '打开会话')
                    : null
                )
                : h('div', { className: 'w-status is-idle' },
                  h('span', { className: 'w-status-dot', 'aria-hidden': 'true' }),
                  h('span', { className: 'w-status-text' }, '空闲'),
                  data.runs.length > 0
                    ? h('span', { className: 'w-status-skill' }, '最近 · ' + (data.runs[0].skillTitle || data.runs[0].skill))
                    : null
                ),
              h('button', { type: 'button', className: 'w-btn w-btn--ghost', onClick: leave, title: '返回对话（Esc）' },
                backIcon(15), h('span', null, '返回对话'))
            )
          ),
          h('div', { className: 'w-project-row' },
            h('div', { className: 'w-project-main' },
              h('span', { className: 'w-project-name', title: project().path || '' }, project().label),
              h('span', { className: 'w-pill' }, project().path === '' ? '演示项目' : '本地项目')
            ),
            h('button', {
              type: 'button',
              className: 'w-workspace-btn' + (project().path === '' ? ' is-primary' : ''),
              onClick: pickProject,
              title: project().path === '' ? '选择一个目录作为本次研制的工作区' : '更换本次研制的工作区'
            }, folderIcon(14), h('span', null, project().path === '' ? '选择工作区' : '更换工作区'))
          )
        ),
        h('div', { className: 'w-body' },
          h('nav', { className: 'w-nav', 'aria-label': '研制流程' },
            h('div', { className: 'w-nav-label' }, '研制流程'),
            h('ul', { className: 'w-nav-list' }, PHASES.filter(function (item) {
              return item.id !== 'common';
            }).map(function (item) {
              return h(NavItem, {
                key: item.id,
                no: item.id,
                label: item.title,
                active: kind === 'phase' && page === 'phase:' + item.id,
                onSelect: function () { go('phase:' + item.id); }
              });
            })),
            h('div', { className: 'w-nav-sep' }),
            h('div', { className: 'w-nav-label' }, '项目资源'),
            h('ul', { className: 'w-nav-list' },
              h(NavItem, {
                key: 'common',
                icon: layersIcon(17),
                label: '跨阶段能力',
                active: kind === 'common',
                onSelect: function () { go('common'); }
              }),
              h(NavItem, {
                key: 'artifacts',
                icon: boxIcon(17),
                label: '产物与交接',
                active: kind === 'artifacts',
                onSelect: function () { go('artifacts'); }
              }),
              h(NavItem, {
                key: 'knowledge',
                icon: bookIcon(17),
                label: '知识库',
                active: kind === 'knowledge',
                onSelect: function () { go('knowledge'); }
              })
            )
          ),
          h('main', { className: 'w-main' },
            h('div', { className: 'w-main-inner' },
              h('div', { className: 'w-main-head' },
                h('label', { className: 'w-session' },
                  h('span', null, '运行到'),
                  h('select', {
                    className: 'w-select',
                    value: data.target !== '' && sessionIds().indexOf(data.target) !== -1 ? data.target : '',
                    onChange: function (event) { data.target = event.target.value; commit(); },
                    title: '提交时把指令发送到这个会话'
                  },
                    h('option', { value: '' }, auto === '' ? '自动（无可用会话）' : '自动（' + sessionTitle(sessions, auto) + '）'),
                    sessionIds().slice(0, 12).map(function (id) {
                      return h('option', { key: id, value: id }, sessionTitle(sessions, id));
                    })
                  )
                ),
                h('div', { className: 'w-head-tools' },
                  data.target !== '' && sessionIds().indexOf(data.target) === -1
                    ? h('span', { className: 'w-stale', title: '原目标会话已失效，提交时会回退到自动目标' }, '已失效')
                    : null,
                  h('button', {
                    type: 'button',
                    className: 'w-text-btn',
                    onClick: function () { store.ui.modal = 'runs'; notify(); }
                  }, clockIcon(15), h('span', null, '运行记录'))
                )
              ),
              content
            )
          )
        ),
        state.ui.toast !== '' ? h('div', { className: 'w-toast', role: 'status' }, state.ui.toast) : null,
        store.ui.picker !== null ? h(Picker, { picker: store.ui.picker, onClose: closePicker }) : null,
        store.ui.preview !== null
          ? h(PreviewModal, {
            text: store.ui.preview,
            disabled: skill === null || requiredMissing(skill, data).length > 0,
            onClose: function () { store.ui.preview = null; notify(); },
            onCopy: function () {
              copyText(store.ui.preview);
              store.ui.toast = '指令已复制';
              notify();
            },
            onRun: function () {
              store.ui.preview = null;
              notify();
              if (skill !== null) runSkill(skill);
            }
          })
          : null,
        store.ui.modal === 'runs'
          ? h(RunsModal, {
            runs: runs,
            onClose: function () { store.ui.modal = null; notify(); },
            onOpenSession: function (id) {
              const ui = service('uiWorkspace');
              if (ui !== undefined && typeof ui.openSession === 'function') ui.openSession(id);
              leave();
            },
            onShowPrompt: function (run) {
              store.ui.preview = run.prompt;
              store.ui.modal = null;
              notify();
            }
          })
          : null
      );
    }

    function readSessionState(props) {
      if (props === undefined || props === null || typeof props.useSessions !== 'function') return null;
      try {
        const value = props.useSessions(function (state) { return state; });
        if (value !== undefined && value !== null && Array.isArray(value.ids)) return value;
      } catch (error) {
        return null;
      }
      return null;
    }

    // ------------------------------------------------------------- task hud

    function elapsedOf(iso) {
      const start = Date.parse(iso);
      if (isNaN(start)) return '';
      const total = Math.max(0, Math.floor((Date.now() - start) / 1000));
      const hours = Math.floor(total / 3600);
      const minutes = Math.floor((total % 3600) / 60);
      const seconds = total % 60;
      const pad2 = function (value) { return String(value).padStart(2, '0'); };
      return hours > 0 ? hours + ':' + pad2(minutes) + ':' + pad2(seconds) : pad2(minutes) + ':' + pad2(seconds);
    }

    function saveHud() {
      try {
        window.localStorage.setItem(HUD_KEY, JSON.stringify({
          pos: store.ui.hudPos === undefined || store.ui.hudPos === null ? null : store.ui.hudPos,
          collapsed: store.ui.hudCollapsed === true
        }));
      } catch (error) {
        // Position is a convenience; losing it costs nothing.
      }
    }

    /**
     * Floating task card (shell.overlay). It shares the workbench's wafer
     * backdrop and shows the runs this workbench started that are still in
     * flight. It is draggable by its header and can collapse into a pill;
     * "executing" only ever comes from the retained Session snapshot.
     */
    function TaskHud(props) {
      useStore();
      const panelOpen = useOpen();
      const sessions = readSessionState(props);
      if (sessions !== null) store.sessions = sessions;

      const data = project().data;
      const active = data.runs.filter(function (run) {
        return run.status === 'submitted' || run.status === 'running';
      });

      const cardRef = React.useRef(null);
      const dragRef = React.useRef(null);
      const movedRef = React.useRef(false);
      const setTick = React.useState(0)[1];

      React.useEffect(function () {
        if (active.length === 0) return undefined;
        const timer = window.setInterval(function () { setTick(function (n) { return n + 1; }); }, 1000);
        return function () { window.clearInterval(timer); };
      }, [active.length]);

      React.useEffect(function () {
        const poll = function () {
          const pending = project().data.runs.some(function (run) {
            return run.status === 'submitted' || run.status === 'running';
          });
          if (!pending) return;
          const sessionsService = service('sessions');
          if (sessionsService === undefined || typeof sessionsService.binding !== 'function') return;
          let changed = false;
          project().data.runs.forEach(function (run) {
            if (run.status !== 'submitted' && run.status !== 'running') return;
            try {
              const binding = sessionsService.binding(run.sessionId);
              if (binding === undefined) return;
              const snapshot = binding.session.getSnapshot();
              if (snapshot === undefined || snapshot === null) return;
              if (snapshot.running === true && run.status !== 'running') {
                run.status = 'running';
                changed = true;
              } else if (snapshot.running !== true && run.status === 'running') {
                run.status = 'ended';
                changed = true;
              }
            } catch (error) {
              // Unknown stays submitted; the card still links to the Session.
            }
          });
          if (changed) commit();
        };
        const timer = window.setInterval(poll, 4000);
        return function () { window.clearInterval(timer); };
      }, []);

      // Keep a dragged card inside the frame when the window changes size.
      React.useEffect(function () {
        const onResize = function () {
          const pos = store.ui.hudPos;
          const el = cardRef.current;
          if (pos === undefined || pos === null || el === null || el === undefined) return;
          const width = el.offsetWidth || 320;
          const height = el.offsetHeight || 120;
          const x = Math.max(8, Math.min(window.innerWidth - width - 8, pos.x));
          const y = Math.max(8, Math.min(window.innerHeight - height - 8, pos.y));
          if (x === pos.x && y === pos.y) return;
          store.ui.hudPos = { x: x, y: y };
          saveHud();
          notify();
        };
        window.addEventListener('resize', onResize);
        return function () { window.removeEventListener('resize', onResize); };
      }, []);

      const idle = active.length === 0;
      const latest = data.runs.length > 0 ? decorateRun(data.runs[0]) : null;
      const collapsed = store.ui.hudCollapsed === true;
      const pos = store.ui.hudPos === undefined ? null : store.ui.hudPos;
      const style = pos === null ? undefined : { left: pos.x + 'px', top: pos.y + 'px', right: 'auto', bottom: 'auto' };
      const shift = panelOpen ? ' is-workbench' : '';

      function beginDrag(event) {
        if (event.button !== undefined && event.button !== 0) return;
        const el = cardRef.current;
        if (el === null || el === undefined) return;
        const rect = el.getBoundingClientRect();
        dragRef.current = {
          dx: event.clientX - rect.left,
          dy: event.clientY - rect.top,
          startX: event.clientX,
          startY: event.clientY,
          left: rect.left,
          top: rect.top,
          moved: false
        };
        // No pointer capture here: capturing on the wrapper retargets the
        // subsequent click to the wrapper, so the pill could never be expanded.
        window.addEventListener('pointermove', onDragMove);
        window.addEventListener('pointerup', endDrag);
        window.addEventListener('pointercancel', cancelDrag);
        window.addEventListener('blur', cancelDrag);
      }

      function onDragMove(event) {
        const drag = dragRef.current;
        const el = cardRef.current;
        if (drag === null || el === null || el === undefined) return;
        if (Math.abs(event.clientX - drag.startX) > 3 || Math.abs(event.clientY - drag.startY) > 3) drag.moved = true;
        const width = el.offsetWidth || 320;
        const height = el.offsetHeight || 120;
        const left = Math.max(8, Math.min(window.innerWidth - width - 8, event.clientX - drag.dx));
        const top = Math.max(8, Math.min(window.innerHeight - height - 8, event.clientY - drag.dy));
        drag.left = left;
        drag.top = top;
        el.style.left = left + 'px';
        el.style.top = top + 'px';
        el.style.right = 'auto';
        el.style.bottom = 'auto';
      }

      function detachDrag() {
        window.removeEventListener('pointermove', onDragMove);
        window.removeEventListener('pointerup', endDrag);
        window.removeEventListener('pointercancel', cancelDrag);
        window.removeEventListener('blur', cancelDrag);
      }

      function cancelDrag() {
        dragRef.current = null;
        movedRef.current = false;
        detachDrag();
      }

      function endDrag() {
        const drag = dragRef.current;
        dragRef.current = null;
        detachDrag();
        if (drag === null) return;
        if (!drag.moved) {
          // A press without movement is a click: expand here instead of relying
          // on the click event, which pointer handling can retarget.
          movedRef.current = false;
          if (store.ui.hudCollapsed === true) expand();
          return;
        }
        movedRef.current = true;
        window.setTimeout(function () { movedRef.current = false; }, 0);
        store.ui.hudPos = { x: Math.round(drag.left), y: Math.round(drag.top) };
        saveHud();
        notify();
      }

      function expand() {
        if (movedRef.current) return;
        store.ui.hudCollapsed = false;
        saveHud();
        notify();
      }

      function collapse() {
        store.ui.hudCollapsed = true;
        saveHud();
        notify();
      }

      const activeRows = active.slice(0, 3).map(function (run) {
        const meta = RUN_TONE[run.status] || RUN_TONE.submitted;
        const phase = phaseOf(run.phase);
        return h('li', { key: run.id, className: 'w-hud-item' },
          h('div', { className: 'w-hud-main' },
            h('span', { className: 'w-hud-skill' }, run.skillTitle || run.skill),
            h('span', { className: 'w-hud-meta' },
              h('span', null, phase !== undefined ? phase.title : ''),
              h('span', { className: 'w-hud-sep', 'aria-hidden': 'true' }),
              h('span', null, meta.text),
              h('span', { className: 'w-hud-sep', 'aria-hidden': 'true' }),
              h('span', null, elapsedOf(run.at))
            ),
            h('span', { className: 'w-hud-session' }, run.sessionLabel || '—')
          ),
          h('div', { className: 'w-hud-actions' },
            run.sessionId !== ''
              ? h('button', {
                type: 'button',
                className: 'w-hud-btn w-hud-btn--primary',
                onClick: function () {
                  const ui = service('uiWorkspace');
                  if (ui !== undefined && typeof ui.openSession === 'function') ui.openSession(run.sessionId);
                }
              }, '打开会话')
              : null,
            h('button', {
              type: 'button',
              className: 'w-hud-btn',
              onClick: function () { enter(); }
            }, '工作台')
          )
        );
      });

      if (collapsed) {
        return h('div', { ref: cardRef, className: 'w-hud w-hud--pill' + shift, style: style },
          h('button', {
            type: 'button',
            className: 'w-hud-pill' + (idle ? ' is-idle' : ''),
            onPointerDown: beginDrag,
            onClick: expand,
            title: '拖拽移动，点击展开'
          },
            idle
              ? h('span', { className: 'w-hud-dot', 'aria-hidden': 'true' })
              : h('span', { className: 'w-hud-spin', 'aria-hidden': 'true' }),
            h('span', { className: 'w-hud-pill-text' }, idle ? '空闲' : active.length + ' 个任务执行中'),
            h('span', { className: 'w-hud-grip', 'aria-hidden': 'true' }, gripIcon(14))
          )
        );
      }

      return h('div', { ref: cardRef, className: 'w-hud' + (idle ? ' is-idle' : '') + shift, style: style, role: 'status', 'aria-live': 'polite' },
        h('div', { className: 'w-hud-progress' + (idle ? ' is-idle' : ''), 'aria-hidden': 'true' }),
        h('div', { className: 'w-hud-head', onPointerDown: beginDrag, title: '按住拖动' },
          h('span', { className: 'w-hud-badge' + (idle ? ' is-idle' : '') },
            idle
              ? h('span', { className: 'w-hud-dot', 'aria-hidden': 'true' })
              : h('span', { className: 'w-hud-spin', 'aria-hidden': 'true' })),
          h('span', { className: 'w-hud-title' }, idle ? '空闲' : (active.length > 1 ? '正在执行 · ' + active.length + ' 个任务' : '正在执行')),
          h('span', { className: 'w-hud-grip', 'aria-hidden': 'true' }, gripIcon(14)),
          h('button', {
            type: 'button',
            className: 'w-hud-icon',
            'aria-label': '收起',
            title: '收起',
            onPointerDown: function (event) { event.stopPropagation(); },
            onClick: collapse
          }, closeIcon(13))
        ),
        idle
          ? h('div', { className: 'w-hud-idle' },
            h('p', { className: 'w-hud-idle-text' }, '当前没有执行中的任务'),
            latest !== null
              ? h('div', { className: 'w-hud-latest' },
                h('span', { className: 'w-hud-latest-label' }, '最近一次'),
                h('div', { className: 'w-hud-latest-main' },
                  h('div', { className: 'w-hud-main' },
                    h('span', { className: 'w-hud-skill' }, latest.skillTitle || latest.skill),
                    h('span', { className: 'w-hud-meta' },
                      h('span', null, phaseOf(latest.phase).title),
                      h('span', { className: 'w-hud-sep', 'aria-hidden': 'true' }),
                      h('span', null, latest.statusText),
                      h('span', { className: 'w-hud-sep', 'aria-hidden': 'true' }),
                      h('span', null, latest.atText || '')
                    )
                  ),
                  latest.sessionId !== ''
                    ? h('button', {
                      type: 'button',
                      className: 'w-hud-btn',
                      onClick: function () {
                        const ui = service('uiWorkspace');
                        if (ui !== undefined && typeof ui.openSession === 'function') ui.openSession(latest.sessionId);
                      }
                    }, '打开会话')
                    : null
                )
              )
              : h('p', { className: 'w-hud-idle-sub' }, '发起任务后，这里会显示进度、用时和跳转入口。')
          )
          : h('ul', { className: 'w-hud-list' }, activeRows),
        !idle && active.length > 3
          ? h('p', { className: 'w-hud-more' }, '另有 ' + (active.length - 3) + ' 个任务在执行')
          : null,
        idle
          ? h('div', { className: 'w-hud-foot' },
            h('button', {
              type: 'button',
              className: 'w-hud-btn w-hud-btn--primary',
              onClick: function () { enter(); }
            }, '打开工作台')
          )
          : null
      );
    }

    // --------------------------------------------------------------- styles

    const CSS = `
:root{--w-bg-image:url("data:image/webp;base64,UklGRhDvAABXRUJQVlA4IATvAAAwfAOdASp4BRQDPlUqkkcjoqImopOZGNAKiWlu119nv+DxHvX37rkA+tfaPNC2P6COO/+7+1HXs7V/x/2k9wv8p/vX7Yf5n1x4r3p/or/rn/wPiiyv8gXhmaEH1f/ueif+iZ+pTtBO9/uuqcpPoCRzl3/3XsAcZe0QUfP9rx4/uf/G9RfTFcr9Tf/+kXix9/n3dI/O//nWNzeu981P5X//9E/pr/vW7r8zfn0+mX/q9P16qvRc///2rf9l0gH//9tnpx4q/on+Z90Xnb+de8Jta/wOS/4H/I8zv65+u/6/+T9qH9r+2vjP+w/1XoC/q3zd++p+B+zf/K8Cjav9d/8P9J7BHsf9f/7f+L9hr87zO/iP9X7AP88/qv/W/vfnm+F59+/63sA/03/Q+sB/pfuV6Y/0T/a//j/gfBB/Pf8d/4P8p/n+vh9ob94hQL/A7nVJJRy/iwPLD2y8ps6pJKNzbLymzpgW9TvHD59KtFdOmDFgE2X8dSpSmGJI2TrVgr/vBfJg//ekXjR/4B3a1Nu/d+qEgMb8R6unUss5QhvuJ9FuD7/ETTs4rUD7JJRxRSqeiCewaD9rPjxpVSV9/mZ6G+vjPacpzwM/78qVG94JzU+GQzbmX/DGTju9f//7d1p+/nAf//R2D/+OIOt9NTT0EJU/R1O51QOAo0PgRj+XVsRzcqcdBgi23uyV3ATVI4v9p03AV9BT6ncKOXlWwvQxegpv6bZeU2dUkfGlJUVMeXWqXozHYeHGw36jzn/2Ph+y+GxwkEm3+JtOWL4Paj/HSUiCBAPklvhm9XQdcE00KcUs04Ggf5bxU879A6DUUri6pxpiQLN9AshfkD7b6FcjHX5NOwiIU9svKbOscDh3JAFkqpVUo5GwM/7Jbu/OfeE0tEF/oJOx//k02///CXKqqBEvdZsXcWtui7GJCMl7/80IQxdHmrWmuYsREDMUjJRH5vcbzOBRe/lbauipxzDrfX4Ti+GlKc2Rin9G5ae0Vfe/0BGO2GxNEP4/+CT4w2X/xRuiFPbLyi/bl3jtvBpKlxqFfzrK1+2nPzB2jdUNbEAZeJ7a39clyocsDnTojIw9Yu7HORXA/P1lFkAJli4aOH4JK7Ai1sx+4S56kX+k0dANYOLYeYiWzgYahXbPQlzhLJnNl/wcjn4OMDR0Otl5Taot8wGJ3Ro3Nsug4kXnfWdhhLlOCoo1jhBDwLOlUy6NZMtNLBvJxd72e7VZ+HvOwHkNSSe1dd6sertSTI7STM7f00MC32ens5bjlSIzlA1YOI/F75VpIwXYjU0xjUFl9DQTvidKn4SmSem2XlNnVKhc++B3JAFl7lFxyfXrxWLUtU9sxZi0WqvEOywy5udsX+tkD9xW4e9yZkko3RdbwRHtknLfnuKLz+Yqy26mphGFmdsQPhw8wc26OSO+27wX8QT6cpLqkeNirU/qAM/m3Fr5UTAErZhCrYTeJbLsAx/wHwrq+8pbP8/91gdUpsSQqNCNx69p6dKjzDqMy1svKL9l45PsqnSfPEcPbjVEdE64hHqAd+ttWhIzxZOD6aO5Hw1dZ23lHpsFBNl5+FLJ5ektCoaXL56RfpbVlmEl97BuqZM7o9WPzBTqAHDbLExjO1gt0MCODDj7ozlMUkCZggGgxh3JUHBKUGdVMiAigrO6xt7oxeWdBHNUlFLqeTfA6TZ1SM/VhVclym9kqdGv41E1G6hjzolgiiaqYYRfcL9E1HDv7n/rDAfVAupgKycHrxW9ZVYBC5lhFcsD1KiNRF9VBwJFd9ks8kmRnE9E/T2FxeVzIHnxNMB/AARYMafw3xd3GhxcncAL4A0/TKqbGhk0rmIY4XlNCDezJndsJpVSia90BvQKMyPaD2E02kyerF1P61K2wDPfERN7KMoiFRstIgtnuKfDZQds7g1C/eOILFR6WzcL45yA833B2WSlM6l0Wgxsgp0XmhD3nBAlyyjQ2QsdfTy2v3qTiYJnqdqaIiYj2WpZYBaxqhWhoRJHRFBkyU1msGZvqKErsc6r77K9UhnXLERNUdl8w6EYa5vFIR3/YRo3f+l2FWFlzzf6lYHVUrtpSY5eqEAnX0nA9+MHQp66lGephrMTOGOVuqQyO4u8hoXWTp11QAWeXEsP97NULwoBvY1GWP3vkAbcn+UNpQEQ7xuK/7RkeZ5wZyIGHfyKUhVZYkBNL+iRfu4QWg2q2BnVPNpm9PpYAGxEReuzoCcU5PhbQnZga2SJR42W8LAZgoU6OU54Gfpda1W+zz06Ub0nS1/01h8OgpvZKnKRSdIhAeyABLCGUWzrSF+vT9Rm8WtFFSFluannxCJ4zEd6pKAy7bevbsNfXbcA8hbZ0I8B3THV5LPfHQcZGhVpMyxshC/RHhJx8BqAEjG5hYyOy/FrmZos5PgFhsVgpthHaaqFPc5qhXgF6tz/Q6Gvso/oRgUYMBww/kKMh3/fVlnspTM0O1Z4u05e0wIi4R5XwWwlCaJqJqVoaEwYS+v+Mfijpq+QzvGyieSdJkx9Z62HdnnTYtR8UF+nFrnLSmCOOr4JdwRMNJLSMpOZYJyfAGQj/fMFGhtF7yyfPQ8zuJdzQLqpts+YXuS8ZBEoSZg+ROE0U3gQYFxgkY3wRMcYXiG/PFSoppm1vw/jRxmxoIERgSGMK3tt1biGKwHsL3KuoloU2N4J0jP0wvKbOqSSiXipMFCWv1amjPacJKdzIQyX/P+xgbzkVLMATz5DdWDQYaKTX8gZH1NhBp64WstLE7kG2QJ2MiW1LSiQKPKzmipatKcU0okbt47YtFVATo5OlPb8oBA8htVX/Yz/A8Fx3rLDnwPB5PEx8WRBjCiiqxNg3U2rFEYwxpU7zn51Dh3OwPmaIF1bv2EuTrpVUo3Hr2hQl6GjkKhJjX9We6jbMMjaeVs8WLfOJig63JLFg+An5I6OFgCzd15Ek2ksMT3Oqs1h9ONMQWFa6W3IdrDum6RD1rnLSgw0OjL9ORr2gLRFNd1zkV26v+sdykLr/YgxoHz8jhdRISkgbezdA5MwuTahaLbN7JYBz1CUG3C+SVGeE3D/XGL84QsqSk81eTA0OA6UxyqycGItqF6vrsM64/fe9F/oKe7T/OwXqZHRnxpkF6M6IHTF75vO5BWvFS3YGf1uFHcyE05jqTrZt0pTDlIaIsxOGZhfS+R/1QF7t9vKocxlLRyvav5KDB7G0MushPSoFGR9WcTgdw2HwznFy3k3NV8Myr8zN77OIfDZf8DUZRYsvmlh5XaozHbVCROS+0/PJo2v7X4DT6mixQ+PoLRaAOXtfVngyBtYJRfslym/gGAgEc7VLjhyyEMBgGP6Nw0ITEKGEvYVKTESVaOi5vEXocSMLTQjUHhm64dmrrCl3ZXj8EVmIsRC1cM3PEFneKK5X2CBzh+oFrrN4uqCI2mIzk76TD28HnvV8y+w/HArm3yHCRWU/pOQxXDfZ8raUjnEuKBPAmu5vf8270ESB3n2CyQnwEcj6Cn+dI73/EpsknqnGz3/VFN7KJqPQZg5es1atT22TEEmlOlmrf+asCZVJEKd6K5RHKF6SwdDy+XNbtUnJaa4DSSUsVHpgm82fNHLBmv8OZ7HnAHdZkEBWuPZq2XG/p3dMcnErvYOp63nXe0kG58z0s99obm4dumPekubzpWp0jRxndJTQNT1yfqLrD0rdEK7d7cB6G9UDPPBgOm6QerBBNGnSqTr9FoGgUq0l1hy0PDVT1GMZK9dxok+aX5ahFBk3WlrG5LjfiRHSv/jzWJYX6ad39K6yzIIoKd3j9o6gGT6sKcAxoT6HGZ3ZZCJfvhYXuKj1TY9CO7m6ngHCA6UkmTSwU0P9lAXNtSLPF2LqhypiDeDANKFsVaL0/yj/3coGEj/Oy2bcjyw/mW0ZGiTAjhN7iUbp3Ro4cfa78jVQdCHNUFGY0qxspPkvoo7uBXdHYexdafLKeAbcY2F3zU6lFvASPXbDBiwVSzCPHAM/vASFzkGrl00THCp3O+LvQHiCGgMNhFDIoMPfmxd089eEuodmX5r9TrBEGmPzT72E6w4vlMiD5xY/FghvHlZnBJvIDxNVx+EGNgXJGzXIMtFTRZ9ISeyV83kD7Ea362DgqpVUlHtaVX0UvTnsN1kTqwFJfiUbJS/IVTzkQVBXOoWv89oZnDllJNVsS3PCnVqAknJDEyv7PXmyF91xynSl53cSO3YZbZMqAyJ8MzJbpcS5w4GomJ+GFKW9pkzUJqEyLym3fNAdmcSXWiNX4kbETW8HMQZuJLMpZpBsJk23ZCvaGWsONRFZhFBHxIcfmWmA9UikwzXSdajsX09LeNem2wJIqnKnRuiX4KRr6HUJjvWT3TKWoeNsVCl4O7JGqhSTvrX4R1RX8o3D3hIyK8i24V53EuMNyBW/c6J1Nj7YALm8uf2roCNgIJSqHtV4MpAocxxAgzRpBaCQ74Mvd1weJgiz1KWVMofe0i9LjsJJEa5bCZH8NrjAXTNuYnt70U37qz1AZWnuVdAOlj4eeA8rRr71z/HOQqws9pibwhU1PeymSVaY/7UEBCGz+PN+EEAunyirRMcieFaemAEOserZJgp+pGDXbQ32SDMnv/iUVaIFkktj8fSOTbQ1kes2ieWEG4TN4FmQO426UgztzwmrLpb6ylwkNT3qSI1q3UegdjQV1If0pGIogjLWf/wC8RWIEtvLCPkjjv0QwrX4J02t28EITXqKEwjmnLzuR+vR/R69p6dUAYELywz1mqdfKYS5ttvk5vPAYBpHxtDduA4A/lRNcvHO7wBxsoFOFoUGytgJ4PJXNA6EY3b8qf4cNtiQvOYxaRksTaXdtj2UT2BJ0yukMFlrU7GdQzS0ObRKU0PRUlkTSc60XlZ22oQasL5+BdzSKYlHrOvhOvfQmoZ76brUYhCFdi8FkkyRwuc/SF0gL+Il+LEmcqfd/o4sH3FGVIn2ntl45yRGFAiudUDOfA17/U4Pw6Z30fevMvvdauUNN1vrYF29DZX8p+nf4+3Vc+9DnRjJruWP2ft6br9UzHvr1n7ZlKXUPapHwOX/H6/3PByKRElbfG7mCQmfIIbcyHO+jaBw/eGCOzuFNU3707/aKGRRA/gneqMAAHgsZ4vHa5apCu0JXqXqi7g1cUGuJoHgiGMu91ze98LQgyysMv+LtPVW7CHNzLOlHwEj7279hc9VVWFsFRZiqWH+hjuQXxZvaMyByldzXA1t+gdOpsluWPaANbLjgLnmP59AZlsyCI8Itg4Lohy+86GKQ3ESmLFNonMTh+OEtCtvKrUR/0b2VcDJ/Uvwi9IyQPTTtJbE1ZZ1oKndIBYKrjGZJVrCfcg5m2Y/KK2ymLs9xrbfCumw9wcTOlYve6Mbm2Z569J+Q7RwUl5QhF/ZWi/II9qADIl8HJ+i5vdpead5xYZwOoxOVO7VuN7TQNnvNp3pYGcUcK0HLHP97yyZtMWJC3SJgSTeJ+DfjSG47oFzPSRu7DpIerpS9XIpuhd78/YwyBS5X7/Mbp+OdgWtOcvqQeuqr2g9hc46M+pZE5BjXvv0CivQkkCbc1QM5s8pPXHztaF4AKeV/KsaThWCWfVVc8Q4cI6zGB0vkC38MSitAvaEWNYpQAc10AWXQIQFhJ093SAcdJA53CsnYrDQsTv3fNh91sMo5aPFbQElDm5LFOC08rGDgml+TKZdwtQsSPVVdM7XLhQOPwdNe6sGdvtZMvVqVWyIDtUrRUdE6FagwIYzV+ccK1Tc7agHtt3k5EufYRjGvDJhTxPqcdfqy6fFLIXE9N7235wnXvvLmZtyuSo7VlubukBHjqYqrjUa2lmqwWVcjW2DT3I17XAF8C4iaV2wK4Xp3z28Lb0dHZfJI2qabXY29sS5gHoS5Dr69MDH+6aNmCKK3NK+PFeStgf98HskPOYEYCGAemhxv/D+pl+pM4iROnqJKa/uHFgLMs/A5s0ZSbpanpqovpjGZCfPcHirHkl4p/R7k2HTQdhIaX+25k1+aTnqQe9gbrH6OA+rmDjDE2LAVsfMzTAAr4g6qjWv5xCajV8nedXXOZwswOhtKjvRfTBuicETA6Oai2XzwjYHTopJmb5GXYnwNVKolrk8pZjKgZSOqpBJ2gFLVXpkdkgCzLV/kVQ93AYVPgc77tRipqv0j6MIzr536lZ34Jl87xCYHCg+2q0j/6UHwnKEc6+29vz1dwf72khb7ksNWbc9nPMH3iVzj06tlOIGI8mwN/EXuZ00DQzxo5zGX6o9NRLC9y8e8mLLHB490Jkct+9kfTRYaZvAEyYxiskuGz7wYOTtzkIA0EpiYS+mn9tauTnk8msRdi11SmPUBJpntp6q3YR8pNFf2m64o1LkPFUmDdltBwnKsutFcF5NbsPDLK9C4XZD21alSk/JFW9UOk8LFupVkgRq7lIuP+t6bB2+fRx4IshsbqCEX1suGZIR61LbKh6SMYyMYeH0pJ+AgyCX+SAqb9leYkEQiH3cdGCVUbpnPtg+zT0068gQsB6eI4infboTxu6pOAcsOheFklI7p3sAaeG6DIpaADj//PqYrjaqTyijhEmlNKy5Vngsr8ziGZoYFYImQGOgRZZ+ZbdfLqDlCxmHs6m60Ltvmif/riRd/vVXdfKKoOc07Y8vo9PP2TYqovbRnDLIp76eoniGrq15r5chnL0nyaJ2TvQomiDKQ8orbPJ7lrA780HlFcAwxQ2y0oVIdP5Kf64EeD2Swusy0w8tbhko1liI09E4Wjfaw1SM3GXSHekvYkvyQsiJuBTcdwW9TUcjOVLZ0Ulsfub/EFWCMoqfCjpR4mMtzXKfQdEWUaU2PFpnISPnFmwaHY/81yOcp6wEQl9iXIK8hF0EVjdL7LtB5RW0gsvKhMq8YcvkB+CEGZYiIASn2mH2hyhn/fV7utIyqBJID5GV5r/pdwKIYq4keOmkbkdWmghaRAK878jlnpXWNK136ujJIohX4P8qpcGPNWxl4TnRT6SNhCT1184sdMkEET4Xgg9dzjWXlnFpOC5MWZJs17QeViw9NO5oLsLLyoYV1gOCadQoR6Ud/swAGCaEe/zoOdpJEfHXpPDPNRsRNn7ktOmNx3gEsYA2kb17UrZxAd/04Hz0LQoDFbtHufDfierJJnHLJHG7apSFveBLFgkjfY88SEfUSlkmc56o0eMbiRiMmHcl9KBpaUEy3mehe7OpA4r1XtB5XzJcp7ZKtApw8rSDTK+JiO+FdTGj5gZvk5CsafWT0tXYtW+/59jNmhD8qFwbZomJZ+xn6EtZNNw+Gw/1Ff/XPu65QbG4fYtqQyMWl/Ca2a8MuAK03IOUdg9cV7lq9Iye/QuVhOUbJ/LqJ0M/T+B399dWOApXk7oPLJdzzOqvAkIJBJ4l9LynkyTFivaD2OXRLnm+vbX9W/LpZLsdgZU3TJKL8g2Tai1sgjG0HFM3W6LqQhRpHa7HBrUgDSb7JIhrWI1UsA+Wiz8LCVFq6XStX/NvxNtvJGwexR2NiYpK4bxnG0bXy6zqBlvRkM5fGdrVzVwMjpoN+dCdG9maTHzZIVyW1xhejCnK9oY+EuBjXiCL9MKCVpawIDGVyk5roZA6fYGg6XeEcqgqeRi64/ptkpwHOU5TDLPYQfsUWS8PeZ034R0t8XpHQzZFYkbSihAwIuJWTz0JImYIQJLNdU5uZh28fCqW4UvjlYG5q9WEQkI0pwOIIE3H8dAY5RK0LjRTDqOnWoip4WW5kUWgGLHYvJa34ja4Af42hixXtB7cZDqQmGrCrCrCyXCKka+UwzAoPOFrdIjeljr1ZfG72X9FabyI+d+9ZB91DuFGMufN5MT5+pgAm3onKLNS4hPyxH18582KF0xK+Vli4/p39hf/enBMYQoB9owryqd1H8JjIuhxzlQ0MeI/iHlmOsa31vMo5Y19CkqLYKPAKK2jVlG5tkqo15AjRsXB9qlkugJzfSZCpqh5F/SuNEuuv9DCRC3WpqvQU0U1PJ4uQR5t+cj1Q7S6vcOnMOei8VFaGAbx8XcFG6qvFpkzGCyJi8l1bdhqgGNfExiSaLp68l/FHLxp7KBiiX9Lp3H4EKlY32O64R7FOBYCdeQZjVEgUVtlFaNh7ZKstoPKxYeeFetnM+NW6Pu/rH1IMiGdaK8WqRGM3CpmSDtjfjvfUULchCgFmMQjONs6RQNe3BEoBlE4rUr/bDd2qiO7LeTbkCTDZ5M1gI7Ai9aAvIz3fN3hqpLacFSVVdIxjzzeO1DRofRbI7DMyQsMM/iLLPYHsE/AGd45eNPzQ7i2D19e0HlFbZ4Gf2ZO/+u9onNILMwYX3IhC1SRnE51YtO0mCw30YcwT/4mGFVWizSzJ1WBYksc40YB9dr8c10S6mWCWBJ+WCeeL7pHVWOLfZ1cr2aE6LYAyhOAzn6J2tL6dFOyDmFFfMIdhojkBrp/9/txJQz8OQ1wy2OeTEmpe4Q35d/Vt80jGXLIdujljX3oKJmop3Sajmg9heU2RxDIBRW0gslwlxeEVZFJbbgrNcvVTcHZsG2Dpwdzvzsxn/XgAaBzIGOMIoHdPCEixMFfkBlfvtIxY+D2Yt8c27ELiv36YxdXiWfWWFS0CL69DLOyikDdlD7hKkAWqX2lCTvT3rhUiB1Dl8TZ1TuQB8FKNeNd/rm2XuSQlIIpurq07j4t431tbrEFafnPZkE5e8Au7BSoc6R4xq0H3WkM9SDoIHQGfVw7bZ54x9PT86tRZEpaFGV4GF5wfoo9SqFNYGUsmis2RmNTrLRGAPWxUgm+DlI2oYGRlbLkB0ux0QkOwUiCCXSZ6pJKN1FreGCL+REyvhZqOjPaed9vn0BSrFE8EyxRgDEIXwq6S3Qfl6uW2TBdvlodp0KvZ3pHCz15+kVd3qZQ1DJwTnDCUual+Ilx7UoofJ6D7IwDAPD0Xl23e7MmaRRwAaPscQ99MFdTtP2dufmzHBAYEWiPzFjeBPAWwBWsRxJJSVFPbLymgpVsvLwaUt5AgrafO5KYg4hOx/CHnI3WAhEjhgeZpKfakNYTArLMtgv8/PELyZrp9ZBMcBkCld0ls3AVbdInaLGB72/UHmlKMnO7MYUqm63yL+6y2EOBtmEbJ8cawQI4oh0Iyk+WauSf00TNj4N4ecXm3RsDAJa2BXM+sLmrPqXLhrULVp6slPFMoODQ9rGdn7P7BNcIdPvguAJ61/aW854t12Q8TcD1O45kNWDjcQeYyH6yuMQ5/93McwlLo/WRxoHFJTC1MrT5sNHPd4sQVWyPjEuxrabpod4bofTElJmEPkJIFGxucMmGIcAWjVe0Hl48osJoX02fVfGlnwU9tjksbuwsKdzvHiW7BJ/dXplgb8GzPg3cy95mWextSxvyQO2ghfh1G8YthVuCzPsox82YF03Hj0W37r3yFRrnXoPyhSBGYekvhoqJrHLjipU8WO7Na0OJb6MkOY/y0PxvryF0eVqvaDy1Y37qd7FjzYa16YHr7D2d7YrrAn0ivzQ98Lk0mmPxiRt/pFDOJu6eMz9PpnZiAsZgns0p9AtUaZ4wYvk6oqlTWEa3phwcMAA/v1/hJ1zBUPlkp1wrhltnkdNnWLPkq0Qs6AmWsyYTn/o7NzgWRUlVrfU8xvwnyhbWtZFMNuRn8xogS/jkCBFU8w02cDAYwHXpOwVOFgLP/xWb1rlAs3MZ2ZVyuv9IkZa2aqPxrUrM9jXaki6JpCQP65lBzr6yuMF5iMg3bpdXeLPxDDDn+/dU/Q8+abdOXk86d+80oH3OxP2c26oSomXi0c0IZslVuSMP62FHZUjbfEXa6fPT0lBRdvPvtv/prHpyn5ecd/zGMC8xFDrllWN4kk4Ssr2WnsO2xyfthbH+MH2l+UT/0ecS/41FJaqs8b0dNWqUK3fsplS14nogUFAUy0Eu8ddgsoUS75Bn1dwia8tEcnDJo1htvteVobw3IiyTKK8Ty/bir9LpYvBcp7RhPP5NLffCkmIPncvxUNn8r1+cM51ehDhSQ4Wv7WnbGXYrPM2rZZu/74xdpy/FdyEe/8vxciBCeLZrzjQ+neJegnUBF5xn+5Oq03FtWlipKIfsl0FOoJ74cuAUq2bEIIeD7btgCOPGXbnpGhurwD5hSQvnOzlS/4utxcvTV2Qo3iE91/tl/AI/jj5zPJ7Z4D0ccdk2pGvN1eksNHB88sQhfbyzAzqRr+45wRfD8XTc5vfWQkKd9EyiudCULdC/FXajlvQ50RVllnJRqzL7JfCOMAYx9GSVhZIWy2zvfSDyg191MZq00jsXlQ1zxdJOi6ZlD1YlXMY68eyehPVagTkAtgRFCTQPE3FXK7oZ6nFiN3FzVAstEf9KCDtBIt0EheAeX2mimZzVMEvLHSr5xkBYVCVjLCdA/QaLBEc7yTyMkJ5SWhHNDTJ+H5uz3zZCw4wbHCVc/dolqK8ybPvekjop91+1ZR1JO7qjlKZGRa91671ZhX6wFWDXjDj1UmsZIj+YMuaXHJWzJz9LE3uAZY4aAZXVv1pjNz8GQqRMXX+kSMtbNTY8j0webWuCNhVlPc+8yNCzxQ4dGYXdoa0fVdiUWPFdoaCnksmny7RjdCCFY6/pPUi9v10aM/LczXfzrKarYooSnq/WfGh35U+PbOspqoHRlRGCknFMPHsSawOazBZiIGmLwJVNp5r9Mv/+f/I6JbmPR/IEAD0BGXc/opzk96SDDaIEUyWSuDz01RDg4JwU/Wkbim6NpdVKlVyZoi1/hr4vuC78HAs5+0ceHBgIH3YeRzXxTm9zrjeXszosErhJxcq+/RP/siqAg4Yc6BsrufiLlbBOThYmU+qpEVyybu9BKXuNZGqbuqVysqL3YJ9SkLvhqHnzk3WI0R4zg1LuJJFhQ7nFHJMDmRwE8Lg3KsoBoCJBhi3ErRzGkj7tl2HrY9vYjlsaQFmMSpCP4FoG/sRx9ACJsUxKfF9quuWCDDSt595cvMT3lPTVC05zZ1ANlKMdPkvvbcDTV+VQ/L3kAlOI2h/lwuQoXs6JEqJJMlqW96nhnzcqs3DQbM3VIMlWj+OdYdgheKSCKVIOOo8HxFh1W7jwEX02jKtEUBbTW90m/PgFR+6LCGUmqf7z91Sp+6rUCgOaAPlrGB2Xbmtu2+A5GUUYFFmPDp3yoWfTXEyN3asjdh3U6VqvG3VS6AyM9iiXA3FSRfq4sbS2jmcaF6RIQW6SJVrwEkUVfOBlZ/p+MruWXInrJafiYv9b8zAPPSBEWkBiA7r+ITKK6Td4FxP104aBawY7IDhSy3ZaycyFe93rKo47Wo68UYyrA98fsZocqeC5CMDQnvAkBmQlkq3XgiKPZhrKFtYfzdsEWD9v4qODarrGJzYG5wkkhzhNoA9pZgvAE3kjMbVj5a0tW+Es76vk8fi482onpoRCoq3dR7TpVfdnkn/tnLRvPBvyI8GNF+wT5HAg/t5XeO83O29/mv6a1DN1Ctqd5jyiaFWvmWQ6mHrY8TIGeV577F/k4F/9LibWbmP+mt6BxWcnCApPhDQyjLEOLmMZOrma2TyIXdv5Pl8+G3Nf9DMyPqc/o9wLsEYd4LVoOgxBI/fD/KIbseTTaOVZ15EveJcfx+pMDuhz8tSdCh6r3OFeu/mS1q6mr/BPSSBXy8f/B8H4TsUBGEuYVT079EIbl1Peg5oD8sAuFlUrScy2FD7ZQK1iFPYba9JQ6BDg8YNdXu2SqyV1czcTIGbQMR+KfHzc+zih5RUDHaviomBzikCQ2BEcgj7/HFSON7ZOtM49kiApxe0yKXDemhF8EtAyYFU7JabbKRiFugLPt85qxieife11yCoaM4lPQkVz7t07dHV8MrdjkJ3m4SBEr6BEFkxPHL/0wP4K0YADXyzjNiPV6V9iyOdt1xFU85FWfEU2MQuALMY155iNQbAa/FiE9kP86YVNPmu+T1nX1M2oeihVRmoW8iMr1QIjVLjxCzt0BFVwBBykz3rhDDBPxPdQqdtpGou/76skZZqmO1sfKG+1UyL4poGCAkgzKvjllH58Ganz1yRcQv8zl8xs8pH8AHGGUiHKRHbfALJI/D7PuSMasNinO7rlAYkisAdhfTht5MnJY5SAZej+lo+v1iuTrakoIdVpFSrROeHTkqc1f7C8EGvOvrpfnJ7yMwORXpUUFm3M4fQPE7Dv0Cy/UQJHFuVNiuoVhnmhiRCiIu2fkIG4KifPd5ILB/s77XJy4xotXWWwDUoN96mXb9KA8W1+UriqLRjQlIh76S595zR6vHlxL7gi++UIkhjefoSGwdOSOVEPA4EXgbTfz3ChiYANrZx74gE1abZiDkUg8/mtVMjE48IUZJbTZPqhIUpEeSKzr4tKRLM4L83lNSMyL4iJU/TDmh6VxTPAR743gYOCyGoLUoVkf068RX1l7ZWsrdHQEm0dIzDAeH1gALqDBIuAte+IDLI2nfMzZNWEOYWlmuXPUOMkFEHMO3CEOxqG5XZDhCldDWSW9u3lPTZO/RxsZsauQf4CH9aWN1mJ9PWt0kHrovrnLlnbTnER+2rZ+FP/C7je/zt7xphEXffdnWfTz80GL8hSFIETgZIiH2kTrCghJhZyana0MpV0KDR96NS2WnRUftgckvMptZTcBTPPw/bA7QWmliCTXRBa5RdnhCyyWjSGDUgA1Wu+wBmhmFu+hbH6bUvRdEYYkyCxslnP1dt5gdCaeTUv4TZZdZLGJMkHDqcYNLevnDT/wEo5HXtPCrvzqUxulMFUe9tZiwEnK7U3FoJlzPZL2SfkmhknDVBK6ITnZf0inYP+23s1H2WvuvAwwPC9M9jYRo75Z6aPC3nnhf0bWVzOn4nagRZ6/S4dpx2am1+XwbGAFMRtGQz2ANTv/wmPj/aBRnsCJ7IVkvp+66ufDxczz8SasDfNYkn5V+ZfFXlHNxzzJeZg/DZr9g5Ad+uoMneRPnPnNTH7X3G5HGg5ed9uq8NAUMS2iwoCBhDseyYh9aXuAnnztUx8NRW9sDkLz0kFKFssjSJsMcwJ3D6aqWbSPIxoeyoOItK5sZmSa2Yrp0H15RDO60URRO8cvgiqnDZruw1LTaHYZS/35nYlvLtUvxh3PRLR09YYueAZyr7TvVKTEp3kFx2nOyJEeQuTzxNX1z1DebGaYfh2Qp1OAAfPe83wynhlEmT0XrbKStYZNp+IcjW/Al9QSh65Ta0bM9NQf6CyqLzegghzNaUwAUptKX+g8gSDTUtmd7vQASyuFmYZsOQr1U30OHjtembGXPfJEhLO2BGWWATLA5Q7cgNgYCkU4E3HZGjHICku6C2ojHxesfiEnCvVHntxHCeZuhVPs+G0sDtce5B8K6nEyvVgw6RSmLKTjtqXRbIVeVFfu2uKijoptnN4tRYun2e9dWR1HfTk8nw8KZ5/GNsqZHJk++gL/onS8CY9sXk5B22u3lIgyE4GliE7mj4z33/EHlLli1LlWsPvHOO1XPgDwW/0SUAcyJeWcKPbpKwV8hIo+a2r38rdXKKWSrMdxSi5vkFntXfwZRQVm7fXqefwOrO8kKbt6uiPgryqzoWpolwPfdh9QKUOyCaYTDzEzlwnNU/o/7B8MYWdZZGFY+Ojxndbf4wB9Xhiiaw/Dj38Tkaj+OAcq/d7Amf9CsDfS2VpidPbkQ36gRUuIBUXReA8I91W2RUgveSVlOiNvip/QnYnivhjDOBDyDiN4ZT6hVL9Ebzb2ehmsZDSpAgSqDGA59z9FcqK5kX6eYXC3X94OTVmCkbEna+dMqap729L9bf2Qu3RZDqy51KJDS6/KWbpmwlnX5xhoZf6majisd1btTUBzdXQphLHiaLcT7Vd7zbdX/Y4AU67wisrrZ4J1voPSnO1G0Xvrwf7fofwv1hyi2JCIcoMvBexuiACi678ZAD3JvQKV7u7G0XQyfCuu+TX1Y9xnGJtr9jqk914oKvlDblw5/rxpOp9Q7KXjChq2W2pFX4dGTEaU1rjWtW679UsXK18Md2cXyE2+uovHOyDlnQhzzhKwTmbi9yvXCGzxscasAKSHcEVmmtYMOT8155MqB48Oi/zL3JTdV1N5g2/nJIT22v6Xh/fxKdKmd/MTyqyS+wFE/I66NK/GBYpxzncWyKIaBhTCUxDSazMBOQL3W4/yfgxjQfq7egI4zQyXpcGkhGqR8Hk8BMAxDdgSy5IHomXp384OyEJJSW/lWqqRb5k2u9cmLIV80dkdWh7yHwyLF5QqWXblHaPQ2e9TgU2b7hKC/B2hGif+erD+PITbsKujYYGRF9bCO2591RuOP4jxOl5tosf4HLdSMgYHSYAT7PZ7BH55nvUjk35WiQ+4utmrb6z1bZ2ZCLJQqfubLbxRE0cfkLtxHLdhS4qzwlOP5/erlGSWqs1XmaB951dZNAGHyo5P6lxsmhQ6R/y4pfdn2/xjtAGdgrPutYkDil3SiBmCcICQztyDdFh3DT6xvj5vnYJdgo+QnHnLjrM+8zkifsikQm5jrw99C5wah1LZ9kEzRmfRKLua3MGCtLhXYfJfJ02btBQN5I7ld2YKcb/wfK13xP9Jsg3LWRbQ19Nt1/Hf+gca5mZblc+9BrkjzxnGh0JAhoobYrVxxTrUR1a46tSAEPOrLhYFyrc3Ruii5x9dE+sxmm5myu3hExs31rSG4iRGqesN62XOb/UMgjOH4iDalS59VulFNTPITkps3VXN3iksxuQANhURP3PAi21vqqdxZQaEAQRl0/UnP2mO+WQCN9hsJRFxc44wjGWKe+u6sNCXSSBts6USSb7vy5pSGwR2qzQRA9o6ml53fEQZRtIP+moP3NNjwGKkamtDlgg4xTXRjifDdMAXU9WVy+LSseydr2wJMyO4HYFfgKkqZZoEWrGI4Drp//IJhNcyShnt3n/S4QiA8GXNkGE6vMV+tAnUHtUol1eQDntFGGk0fSgQbWPoGzvX0R0v8m+0eChBfS9z7vj5xh7Nsj6EjOfsWYSfOxOHQnSTIrz+Bj9eE4VLsWVRr0wfjJfbWw6RNoG5E0vC85Z+qX5KHNSADA14TjbjKPT8SZMAdSDjyUcrCJenVNbcAdTK4sJQ4+6HTnCc5mnzZ7Umyk/vuvbQdkp6CfE/ovMScQufANJTvSgD7Bb32IT5fftLVuPxDnBKTSqsFMK0UU19Ib5Ic4gBg9SDeBrYBd6kMWIeOptmzmCT66FdLyCjL29mm5CCVtXZ6PMyHxJvljJjwJFZz2wyAadIEpl9xPoJb10++9K5W4BmK7ntxPxCEkLeKKOT4aJowWyqMsv1W0HXUU/04/fjalx8ecP105hhG348qk84D2KP3C+AaVxh+eEjyTlDpPt7J1DkNl4ZyMhrz9erZorJExC0240scnZR4pLUbvTfA01r+gpb+UbdzLveV5Re7TdxVSjRjeT/n9KAsrdtljoEjx0r5RRYcK2/8q3HGPva9VwDZBKqh4UapQO2N6ft1UHx1BLlFWe9f8gQ52+4Peeew7mUzQjDp1r2w7drhm91K+t4WtHi/KbHtIZu7LxZ7OoMfQaDKzLWeat/7/4EL/8y/MMKuYY/X/EQ2DerIPKWzY1USvWjf4eVg+5JroiFWHyE0DP3esukF1n4EnAi+2tRwrRCoXnaMrISQrQBnVLwMUunx7+0YAPzMLjICmpVghgQGVCjupJR6ZpWWJe3SV1KCRjZeOOy3u/yATiC7e1qhxO09OH9Y+3AimhGuclHdVStG/lVcMs2KTusl2rt8QWM0AIw0wC1Eaj6TjQvan7Uz4o7A6WMQgfsRc1uwsbH6UbdHpjc9RK3zV/XBbNhUDiPfds1alxvvpdi83WrKJ0bxwhVfUnWinNAevGWmoZ33tj/ZRbi+GqcmMkHVV8u3LFS2CNq3zsmX+8zfkuRTTbrvszXh5GuQD3r5OvI2KnDYsxO5r+LQ30baHVxIKZ6CIp+6+bp9owudhBs2GcXexeze0odlR2zPNQzwwClDJW8+RNK9k52HaytX7VuCyfSG+rRiNjErLHU/BRYC8YPbLhl4nJUXRXX3rvTmbiJLKDqYWbWbSB9nd2bJIjYcYEM2lNOsC8t5ZrCLHqUrD84A+cdWmqoP2ht1TvUXj6QrCoqjBI4s7nSQz547geVINgkkoiLFzygKiZ/udt7Nu7ywTzmQxk/T+ZW7SnBBKGeabkmi5MLgGdmYmhypCaQ5gQgfhsBt46beB6Oc8/B/7zHIwp5IcDQEaj4NhKw55FGHu1N2BugBwa0kX1bPgyhMUe8hUQBITGsoyiPMwHbbu3JE7RmKlV4vTHUpWVXGf9jbCgqKm/93J//dlTJUh0sVsFu8HqZRNZXTkwbD4QNjszLfki13mboqBQ4u4oWMnP2KVkftbXuHcD4Q3UCYz9nl/txW/kQ+RiKDRFopD+YjnBWDL/wP0kXElp9Sw1sA8Y702AlVjhZ6wF7e810TFqEk8eLzaodJCCV6XxTssxWqzKv0BrtYHYdzhBk0JcXz4a5QQ7NF565b7DHtR+HnJ8htr4EqXLmo8Kcx20SSfnYfWLSMg4jXfVrPaX3LJoS5tA4c0HrDS7KtbsumsJs7HN7WrLzxmCZsCLCvOM0WF1Q2A5O5gP1gPRDBV3CsVQzvaIi8W3z47pd7/uyz/e7Hj8YzgOCYDEDxsrKqj3CxpsRR79YU/50CSMEqxRJiyfv6W7L8GvcLMStwBoH1hJwb/7QTtdyM8jqowSRjM2e9QT39Qk57NtYzk9yhcXGHvOSMTnVW17AwlG0+wfLtEfvSU+Y9LS46bZy7WJUX7vr2YVUGTL2BnaWvpkDRRB43x0+yD6GKR4yIaYDU/V18JC6WCduTzPv9KAJeLKUq8qJ3cHskZS7oWgpMABQWzl58LafNJjUfm9kHkay3lg4xIEVm3OTpL4mxsIANgT3StRlP+Evul7H52DtJMupynYNVU9U5BfQ7pn9yV3MYaOy4brJNge81JXEPX/Pzz7i/lgD4RQCea7giwSeX2t7NIzkkJF8EWny2r7K+Ti89BiIEnufFXF1bmNfi7j9i4JYq4tORVYXobak6pRn3vleK2U0jnEVMqkcz3ahugR/FtFrgSryknsW3FPnC/rwSAVLslXzBcgwfTQMcFIt3vFw6rDUK4b52eVtQIK3SQgEOoskSWJO701/SQTF0vd1symxokJpcjEMsxBMlUJa+VBp/PoxNpNCouUzo6fEVAhIMDzgH8++IeOX9MY2qyKcIEvN3wpastqKnd6x7PAyjsHvFVq5YUd1JaoaHs9W0FHmq9wFKZgUp1A4EMAWwtQMWkH+XorJhpZnBieBritsIE0YRk3RfblNGCT95zrF8Xzsy+ymt/XeNG0A6kiuA9fDJx3XagjBAV6lV6t5DjJ1H+msT9DNFyV/SCOixbdyzuuVhp2KaXrrEcxeaSj05px0qQ94pNWV+iR9PglIV4ETO1vPuseTpABs2/wekZx6R+qt745qwlr40DoQCWy60Rh1jdYlSU9tgSEeo5JXKfHU/1kExC/e/gM7yTr+t0W1ibAOWE9lgdZr13og0C28rPInupdB0zi+zYqd3tCD023/0hw6ueERJo8hllULnA5ijVJmC79w6z7H4618TrfJ2tT1mtJQvun1HnSZ6KU/KH+OaF2zS+IRGzwqBa+bkOI53jlxLup1blR255RdFsC2g2RCSMgo3rRJgtwRFPPs2Z4298VK/Lx9DW0bM0CNZ1KKT6vIyRMURYssansQGd4q37p4r8KyLUv/1bxnzrI0rn5GzISTSd+xgQvxGNmK8DaMBmN+EDuPfoTg2F+39pSmEjkznkw5ELF8lNLJSuFk7ngOw2HgdNfNvRR2Qm/1EAkCMN+OrQuwoShVU2lv/15DxaRS7Ue9fv1wDD5l9PjiagfIXEfs6hOzbg0pDROQHrJ1Oz78bBiDIWyVeb3mDGMCBwHd4drfZRZJq7ADsEhVwYWD3uBHsUy3ViJWSe4pM6Q4gJL5AABMSCsl1Q7BQREax/TNJLSIKqyRxGgH3mwXxpitttN/f1c3t/Gl1PSPDLOx2ChGe7RZdSqaooFYVYGLD1DuA21P6p8T/Tysuh2RbwDl2qGjmKWF2CndIU6SN1z+KXPd4QRNUedBklnCe6CfAGOQe4j/jTBza26dbMId3DenyOtUk2Iv7Hs7uM0Zxb/x/cDBtWNy1UXl7wctWKiX1HlWyIpETFE3YbxbMPKpIZgp/FuYr2RcAsw4FNUGocyOWb/FaqRYS6KxjFrl2uBMUlM9FGCwk0bPd8R7JOUotTxegSgcCsgkHm8g4FX12l0AVy9/xT4DZ06aBVMZ6ClEABhRVRbzxCdpgJz+VYwc7tTKNPJThO6Mq9UpVCV6KJ1qqQ3UB/RWabcmebUo+XbvX35BA6/D5syKORNRxcoLRFCQF6JJtJnf3gW/krAmtPRneGMSJK3JVYUV2U4FqAFrsP16NkkxYdtoDaG/YFxtLz4M7M9FzJ51elHn2koqRXIaJMn45Oue8ylw5BRiZIz7onODoaEVDmukEGxOUNY6eh8RdePH7/CbgLYAiF3an0pVsfUWzANUNW32iKz2/AxU2/xi62S8opmFiR1Q6XL58PcR4CnUNSzJ6EY1ivGTaVTaaD9auqbdCNa9XYZjpaat0y3j4lWJVbuGaae2fwaeq1JJXIqQ5eD8Hi0W53CHGzCqdFPsfKNGmYk7C1jQtM+txGGO5jYv/hvVsReRb2BhJIUOA4jTEXJ+b8VhK17o0gY7y0DRxgNqdjHVAb2c2Qu6J5F/ean70WPvxmChXANSF9N2ujl9hrlqCLzyUx44Cd0UXto/KZaUBGxTc+tXm/lh8uE4kPZAqSs/kVHJaWOv6+3+zU0QIjTftiHeKyo8ylSvd6u6t5F24Lh8mD/MMD8yJwKNoRUXMN6AvQzEogt9K02ZPc1xN9xIlwle/Ibr0Npw+4/18A/zLW8wTWQGQx7aq47qVzgkp9eFhf49OvjFjaRBSnUl4Zm4hmBmZxjU5X2+KoxQhAJh+oVAY1y1mk+Txu2mD4btfPmcBDq8oFKgAMXtTSKQPS1QmSJ7my16uKdLovJ8ibLjtI9HoDLzDcpgFAaJTxz6/DGrpm38mOgwoXNy8C/j5YRytvCeqSnOYbr3dpA2BA83Vv3zqfH3HVaTmLn2Bu12MIuvCRBAQLsyAtknDr1a2qwXmWaPehk/+4CmdgswxFIzztxTXeoqbIe+cG8CtC9NtWGR4EThhypRwe5vTKbEKXvs0qJog2K4pVHwcOaRXgqrF2S2gkK5NslGsseqZwO+fKqtBzyxUUdMWDo/UdUszJzcgkt5kJFZCOjrxUoEAHnVEqFcG1+sakEV+xVvspoJ7V7/4sZJp/svFi4JcHHN3Hpd7Ck7qYNK2Qs82DfTWFAwkK8kUZlqJ4A9hXHGnn7K5K42GIAGx+6HjLcO6Gyel5UF8h3+R9W350IzoXAs3Rbo1mccIPATYvrpBXa2wIZTRFn6qFWA9J3XpNTt/Jn5MXBhRQaPBq+x711F1qHkKZ7SjAWpjjqrUvxCWQs4bh5D+QJQ3VmHccJ1vyn9iQrmCRJeJ0A7DcgSLZ5qFY154Kvoyx4GqmDFQp/Pqy5UydP+f3ZwmeY5xkn9iqE5DblJ+2m4/ypyFA5JgnCv1+cAaCwv/gqzKdJ+MhfyeCCYyw7zDts9/lNtlVOyCaExoA5UBXK8ne0AxIBOlTRIriaZIoVqqyk/zEVfuGBlBsHZtUAQ34VWG+FMQSqAS2lJkdKn5hDs46oaWc1xenQmK1UVHh6wpuUffw3cVwk1J2LdaQ4fi1i9NKeqxjvIyrEa3BragvUM93hbW+BhHsgJzsbxz2ozrVY7mW0Tkz/2caMVF2WYcl9fC1bpgWlG11FaI5gYl9mo9zGzuCnx9J0Hiud1+eXKj3fxDg4c0UR+4mpQRGSizc5Jta1wUm170Ln9NH84KvkydWzrCky6mNFc4vRqw0U2p/LLzu3kRhHJy43sY/dNGlJ48fuBsH0D02z2nwZoMgO8boT5XGw4iCWYh860A1S2xNZM8fRtqT/lgPZK2JANUHTVN0WQXbJrBcCaBmW61H7IZF/Pgav9qZbkBrobGzRRAq7pthgDWHEvZp7OwyyVB94/x3Hqz1rE75mWe9KioFp5mH1DHBIFVUbUkAbutzl6DEGu6y6Xtu++q4cEpUMgMuXKsIIcepJGs9UQo20ktvUbF/UY5kuBgSZB6tc+1TwtNUV9gt4Tc8uk5kdYo0te/tdQO2Kn6Hr30qUBmJpU6M9s2IpEO2mvg3z5rLZUSuVG3dHpemqqaR/TiVtvyu9dM2qf3UIjSALfpOHAZLQTLJ/qL9cvr8tRpgYoGw0h7laFPF5OdruBQ+WEvk0ge4XVI61lp1xGonrZhhju3hy0UqPZzhwezlUWLKlh5T57Qxu583IRlvSFWxuXACCz1B7gHUoF59tojTZ05ytpcdV1MHVmat5QkUv2sQ0TIGnPnP5446BP4CqJNsAyfQROQoWnTRRg58iWAAliKsk1hYQBmE/wARCgfH0OLqNsMO89mYMSay2/4Lhjma1CJNU4u5UNE0B33yVe2f5dS4OENEp9FaNaUTAWGPmffAFBTlSOBdItLly2ydiv7XuEQBiBNVqUcc7Rl9yDAmghiPbS5BsDvwhXMqkrIjadVxqba1B+k8SCKdOKH+hNljcyhkZoD+27kYoDvHjwSss8qi2VJyaEYy4qcyYWowBDyfi/YmUaF1R2hAxIig10olZbu3Xc8pL7NS8sp7UeUAZux/CfX/2OGRb/e9ebGW4kxgeHybsG12UPLv9frqpenymKYxzyxqhdJqxNQLwghR/M4sIPX272HnoqDNHjOHfp91W9UGBvp+/gcQs81qnMWrY+lz7jcsKbkHHlw5XGnKJ6vB3yGlUYgW7/FTICPGGBcwnBM2SHT2bnhTHJg6vd0WZMerYDK+ACGrVYC/bHwxQL1506ybHs43L1YUKByjFXhoCpQBoQn29H5LGxWt9RVk3b1LxKbc/+KOrEjA9BfxUKkjZJFWz9y8ergRnuIX3PwTQR2xZF2aJfed3z5fcXUe/C2LytnDBfSVzuvOcEFkA7oOb2pWgMSZ2dpUrk//aFGdzxk/DJiOU9JkAtO5dhKq65n/LkYUIellxyWWWc0FzmXzvDJ585ePiSf9J+TcHfGw3XJDzn6rhQAuEc/ZiPsTqPTqKmGtPtf8vk6oUFdoslex7qcZVNSCI0/UDuPvZhs1NLPdyP2O5pHMVCa2Nn+fCIYRDwiJ+jrEIOvAIlWfgro2+HmN8EQafBXggxN+JSQTnmry9s5EBvjARwlWaEvumfgKtjGv6nBn7YwY/ShLT/PrFzEkegFry0WiKqK1nsejRZLuvhVM+xUq6UzU+ZMH3MxIwY5bDlMxh9bDuVFWkN3axkaW8UQswY/twiTuGes4mc9q1JL+3vCw2ulhj5+muaXRCCaij1DXOKqOaruXo2u2pACqgTRJFX9DlRhH6HROJi38v9tmeQSen8ugDyJGZfov9GeArWXU13NBsonIDCzOnNJDaTbc5LBuFdPjHeEjFJ27ojB3058Kl4x3SITlBTyAjT6pJHNWNr8hXlzIIXIYVkiXKSSpM2bXEa3glD3uAgPT8FmcEV+42QVEcq7zYz8BCjnP72E+u8Gtb8g4vOUZTh1kJvHX+PBXpA9P0hHNgGvSsPs6pKdGIwrH1sdlxGUpmVCmrM4JnmTcLd66ClRhiTdGp9QR1hl9+cJm/y+Q+l6oAK4GRbA7Co/BaViP/+pF54UN57L1j5TIoga0zpOv0oKnXrPiJCoS8Hi62fuWPZocuVw4e0ZX4+YcoAs1scXcIc1Z70tTSfOKnvhHsgjTHCzPGv5WURGGldYMjM/cw2od6Do4IFM6E9ssPI2+pNNPOR1Ss4zoWM2wWEfNGsGDgYcUQJ9Xh2zCTZK3UngQusb6BnQrcxvdMuPiLDN2GcxAiJS7Nn5EniwQO+8LMvessefVwfHpyfnZP/SrE0RV8xFQsi0SueXrX2x0Cenv+cw4CWv1T+dH2e9Y0Mg0fLMOI5ZMD+Av2Lmv0sgM1XkPa49DDR1w/vbgZbqfZ4VmSUviemHeupRgJn5RAd5WgKFukiJPet4KYqZFB0Oh4hSYd/fTVfA8hXCTs1i7LaFpQSognDLQse+x3XLG4igrI2gP9UoiAbPqXxLX0cW+VjlcsR2ROeERh3zQv+ygtmca6FBYxgd/mhZDMnoCvTji+we9oB+keZW3T+KBd0bRfEI0GsoJCepbN1r67oFZ4xyddTkuGzoVVcj8PSJjWT3Es7VM/b1MHW129lko69JpcBLEHazdSvyJoY87ZYVpTzpahcj4bW8Az+b64WAJKCYn3DwPTkpeypFmr2Tof7YueUve5C/rI6s/gQTEelGB9TscAh5Sd+YUV0jKEg1jEewzw2vevlZZZuqOwU+GbHbFrQDIQ7MrN7QzwkWedtow4Tl9vhFu7fgK5whbEMfUipfY4xiPF6Gv6UplycC99+mZva3c9ZJYc4D/iD/vo5BRd5VlXuLfpzzoFowwtIIg/AJcdeMcDMFRaGjcCEfKgGkyJkKEcF4zr2393hkxRd8DelmmgTkWD37EI+OdiXHDqAZmcZPsKFnuNHIruOKpFTAH9Q3wLTek4ohxBMhHqfwU12AMW8n3CxlyMVrFU8OIxh2FeGSpB1upTuF0BiF5E/KBuR5pzrkXP5wWQ4QObtqnetILuLsn7cGG9ZaaSkDqo32jk+BdkB0KYoCLL53XiH9HDNuZWcxULBeVm6aZft8/P8y4tNel+t/ifCzllNv+WyZJ4MgX02GO7HMBdIXRyk7RgpxkaEs/kUn+6nzws41JVcoRvHPbSmyczgnvhkZ7/gNdi+uqM7Re6gAtdqq/Zn5cdl7vgaxOP2BGSDlthziJBoQqFpABjDgEx3o5FzXHahhRNebmxu4jeeKOAzqqbx53D3ucZsNZnTF326S92k4pCRspzo7OEajRP7ciLiCFPWIXwc8T8yf4ZHU6HCLry0dL4A9+SflPkewHpKZn41V77+b09cbQi8BoQZ7MupCgM5htA52q6UaOno8I0IHVra0+iVJ/s3kYK+0p8sN1ubZd2KY5v+HsFAK0DFkQlEwFZr4h3lxtBIpoXT3gY/ECHwEimKL4R72d/HotvNRWPZKGTcjCqleP3a7Yu37pu/MzF69ksXyQLGSRg0y/itgaTL6KA+qg4z+GU7GQVcdftXpPfTn6lTGnElOzuXW0Wp3oZjsMUDz8nwe8lZXjjmXT1XyrGtRUMoC2CR+UJyDqpf0O2ifP68K9FettAJC1hCPy53I4OD0LWx0sl46Olcf2qNbWJgmazD9YecC1ctqaSKb3PamQtFjiSGKJZWuCVLVwB1ndU/Ak/MMfhF/f3r2SwFHDXC6nZeHjSmFgAZ7PSiIvF+YhjFY3qEupQewKBL3OXH2J/o3haEfgd1iSRzajHFTzNZD8LDCkSH1n+JTMGzyvIW4bYBtroDVEbk4Fv1FNc72m+QXQzH8V1oLZnrnVWzE3RnCZA4981mrbRYrYVC1FVXg0U7Ex1xVOw0EFae18jkUvon1K2Dn3MTFp0GEse4tSZ0dZfBVqGjMx0HKgf52Pk4MFOGhH5zRZ4LPbPtaAl8Pn3Zi5YFxyu0R/n9XssWppazQZq+XM0RjlG/EL0o81yLR2d7xDKP/h0RtqLK80hWavluUVcVf7nNI3tVywqrikzZrzoJCRsxw+Gq9JkliGWCr6rgrTDJW0tclRiZmUCLtDK8WRdMOLbdr0SJQsOtMISVXYVR1CGB28T9kbGRsxE6K3ROBa34HWwdJLrRY19Nw4AbI7aPScyWFocS/6ullu2DiiiNCRpKTXIx8WGbCHvac1xrwoxma6ems8vCOMJHSOrRVL/JDtiEe9Q6+KrnJrMzHHqs03mN38X2GaNQ3nkVVHOtp+Gqrg+mzaa3nZzSHtIhY2K2qFzIY0YIgGHYL7Zcj+NBxWLRrdT9uByqTUUPQioTGW3ttD59o+QX7zpW3At6koWIvdtyBLbJDZ9QbiHjIg/PhDLoRde6twSdigSl4cJyw9UpBW50Ow0Wh2YUO1h8UUveB1QP3J1aUhH8azrNeezygxk48Klu3IQG5jr3AOdBK7WndsHJts039sJT23zy2ZGO52PfzdGmLYT81dtcn39nXcamUb1d7VD/ypl0UAtkAcvwqtyRdmqtOrccsMrP/BPNtr3u9Zcfta6YyCeYOfAUez6uuPQm819bVVHJ69lielfoj8aqQ1q4Bb65/iXKnuAbqqX46Hb+5g17qWINK8XlQb3IdtQNo92XgJxcYf43dgYlYIhGgLTvgOZq+fLUITkZXvAKIReY2mcfgnU1Lp3r7EajRZqB4LP1U5HtuXlSdO5otSLFnFrZnvtIIvBo6ANa+NmECZyyb0VgUke20ZNfNFdsuMLiBfXMtdjzyI5AWdm9BDU3iq27w0MoXCBgYL/zYRLvT2Y0sT1uSmLXp2y8L4FjRahSmrT6JachN59BseAcMbHkPDR1uGoN/+Xykk9Rl1bwdX2X8tT57q19oRtQFVqS6tcdZXq2PgftQmNQy9WEj5vy1RAvFT+Q43pieS9OtelCkYgzOUloRMAcLMldqkJGQsaTxA0Ukf8IL0aeYlJfhomI29Hd78DUe+nFyPFII3BBevxmNls/7YikvFFR/XwElHor1SWCBhPLI25eqpn+m2OMq7I11Vhk2p4zvm6A7ECBL64tF+P67IKxdy+/Wm99nR/lqxVkLc0u+gqWd63zRrOpZlLx5FlmoSyA+hgzoQSv3WWO5M3sPSP33OstajiwkxYBHLXln/3u6OohcusvrRJr2WjFgP5b5YG7ioq0mrhStUQ5Ubr7hL6x3Bs7EVJnBa2h+2O7SbQWXW+5OypjSseZtcBCZIO+dO5nfy/Fjx9nHh1oEsTBt9ZxmadbQCck4dEuKi3eL/UoUn5xClXCoCbI6RR2rFT62BbapEOjD6q1bpSSlkb2bEzic5R5Vo8XOUZg6new821tKcz/9YKVFmVIH+hFfn3DAYcDxXky+ofX7uq5xmjfLDZm6/D5Go0Xq7pY29kS4odzItyQX7zVQn2XPjbQ6NtTZx4PTwSCEXnLuiBF+z4BV4HgV1487O0I7fXP82SCYzHDExGHdSX7S0N21WouLZZ+lzILEbVlIo+rJPh1cXZH/yv2NZZXy6HiszgX6XPB6YlFCADueliUQkTbcjiCFHsByg0PcVlW04F/MdCtRP01DjTz9MoXbMln+qj8YKQ51XqCBJONbt6L7A4BEF+bxnp+a/UA8KfJkfsrKfKUizVlGWAo03Zg2Msy2DiMRYVXIhooyUlu3FPRDYyM/u81j9Hi/mmD7hzMoASQ0zjsBULtCDRxgyDZGh2dMQbVDUsGhtfj9XmGqetX24h9yqttGRKNP9dicNRV+XR5gOeJWXYjgyarz6/IrzAKwSJSlvd7U+bY/y16N57+ew9sS5+MBte/0zf35gZpMXKaJWp5xBOcpjMwJXWzsOP12QhKD20D97JtEm//IofVjqNRO+Ioyd+9tJeaQd7QG02/eGNG1P96rex/XWjn7iRTTfoScLbrSm+shif9IGWhRtC2anphyap0zkuZ3CxgRXOQtwsI3C+P0Hlu7/jl+mf5/weaAbjkVuFHz+EQAwHot28czWN0HFgLuQsIzz1iOSOojrPQqMnjMfQjECOsOTb7MQGo7X25ebteLjuXpcd5v8i8EdjpeBvQtYS85AJ6jwfSwrGu5PuOe6NrpiIC2AptKvyg3klJOpxD3WTqjT5l22hDUuY+6fyMS6xjMYNWT7oJNG9chn/l989EFOo1cWXgXujTItB1J1DDsUe3Ug2X/6twu21dVjTay2Waw9qEgkFLT0HazuM2gg9YGG90xNtW7iDhvTaW0V0HdKmXWCjCezd8M+nsDs9x1P37adScSbTQQqCDx48lAsUsNMzIM4beqNiiu6QYLsHtBSKj1QICCIM+gCTo548CAJYJILtAhm7hntz5VBW1EhDzLDPPEH/UzyWBCIj59KC/mZ/CtR3AqpWm9032nFODR7OJw8GQNxwR9ox2txzUrzRUEA4cR+yq5H8ZA30R+f6yTbzxOvYi8UpMcDirEVqcXhq0n2AaB/WquWign55Xf+lyI+dSB83pPk5R4QDHRbkzrdiT3KYZXdWAGoH3DCi0nefy48LyyrAmrBiPv2gfDTsTu0m5D+BBjEsTv6rZI2iSW6Mn7gQ4qJCqZd7n0rNwXVwcrSltByhkE+v6W7HUA59VYizQdEvqeB3VidiBUjsjqEUfradiQPHyzcXdL18pQRvlzcugdh403UhtuT8/SuqSGD93zLJBrXLW5qaLWo7wiidApJkGthv/WfKutY/dGOelFCWztaMUgcTAa30X0TZoku/8licN7R6snEQ77/rSqzmykT0pgQMJd7Y1uyoDotHU+TP2zxuzSEdNJo5EOlB0wsau7vGw/dApQUVQ+BrBjEVcgkI12AZbBE7Af4a4BhCJKc6kYW1yaD3iEtyfGu564YwrTsTAq4Iaw1e7iU88MIHqAjVLkmnEnSUC0tHmQcg0TcxSb/fnVruxEiCUZbIjrojUJorMsqlo6TBIabdVbaiFdgDiqqNACvh3JLQQmextprSlggtst22ANM4PXpVX7HtWyX+UpP6qt69OYqTySLPNzbKE3p1hcecwciaIVdTpbFOJRq1ARpqsd2sS4lqsIidc8UVcdS6N2Zuc0gwl4RiVFmk1XkIjnH6mdZHYxYnWP6Ahq90ioujQOrX/xWBMM+YgjMrw3vdNj6ilao8v9RF04pyh6WFusRdIS+hB777wRl9faAHAyWE4/Q4SkymoujjYNwDfTWOOpujy3zOyuCWAAqKQRUxgXN0pEzeyGOOZmoQUW/00Jqf0ALS5CrJd1nUVcydVduiIJAZsFf7UHZDG2rjw+0QEtgXkeLOsbD/Vm7GuXvYFaz9culIA+Wi5NugnBuVsLNYyVDtQvC9aqsbCt4LT82aHZQ+5p2VH6CSDkZ65OQFcC0dl4+/W6PJ3N0lL/8qnlzEnvvCYrPgWJut7EbzEN6Q4nHbqFRB7I8k6FX8nc2V3FQIrSd8+7Gx1VJFudPXs2waC4YCr1TXWnitE51zsDLTDvXfztLZhWnAmNTVzBh/Na1+vVlv+7zoG1/O0NjE7cOxmHwkOaFV8r1M7RN7YH/45IUrAfLWvX2BZ6bcXtgOGaLKtPvoWKUlA0b5F72HElktWwns6UPix6Z4F23gXdQmw91x8NRCIsgfaVSoPPG9Zo4PtOP5kC7xIbWl8uYV2RGpPVtt8CKi01dFjrBGtarfY+pzym1FwHdFkGt1wJAOZq+PYXMOIvR2ruu+eiiy0iGBls1JPetiF78BhhmoS3a6hvqpquyHYQhhhAluChYwN7hQDQMRJsCGv3yv0RZ8LvxFqfmur5YLxR+sFrSKBj0B1yc2LbJ/M0vAaOyJPANt3DopQuuACRnnrgpGqZqZWirHUA+g5EI60V0ImdlSuijX+L2FgeOwj4s3tUmi+F60eNk8xoYeoN8GiJXfAkSwksJHGKCoGuQld9O2xx/1ougSzALcDMeW/KgajoQVM7YRPk+pqohCKCpIHbw8sJDc8mXWAxO5h37hzJc7A8wTcGDcX0HQv4JLltZR3J5kcbrOXUT9GYtqCC/l8L1zUNJywwoT58P5ASCrqNeNEh72UDTDSgykn52Y8o09CjuXToyDboEHOtgTQ29TK6+wOBxMNtuV/5Mxorzf0NDR81EszvyM2tfCndaJTYJEDG2t0A6Gd30tC5EvCoRK782dBepJ8qSB2wx0dlI7xonGaKGRcXFWbxdaC39ka5TwCRHV3QAzMxWZxhu74OJcRcsqp/U0xqkC5p0xbl69SSOgi+xuiibbIe810MFHqIXj33XaAhlSCwXoB9pJAJ1h6gTCoa/6VVg5cJ/JGvia2NjhG3QGMyhX0xFTsFw99kOK9gw6b2+m4nqvK3ewHV4vpkKNfDM0NaUR30n7cA3vw0O3MOi/H7XfgOtgXwmi6HdYmnTzhMqx+rOMr/Ao78yPrw6iinY12C57Tl5B7UeXtmZ7+1n+wYuqcuS6KfocUXhyvM/VjBgCPhFGUFlVesYeRk6julIXdpizciB1n7d6jLtpkboXd9R5chmcplhXsLR1rn9o2LICsflEQUxf5Lxz35h/bdBtS2ftNAUqjrczGr4YHgFSp5hn/TQuQVhA821S0EAFq1iVI7MZ+nGPl1ar6RLI2IlcxeCaUTZvYs0ZXheKPMWNhdhnMcW9WENCX9IgLe9UxiyCkiBFeNLkeKCG5rV2LiV/5wMOme3Cno2NCc/sr+gzJesthxG3WWjwzEojjN/hlkl8vw+w+ZKqRaTE9b8wR1mnq9bBu/qt9IVwZlaZuyr/JC+YuAUwyu9l8VyQjDyGDAiw1aLEBiaFD7oFEzy0vPfxOUAz1Z4L+ZYpxz/URhjj231U3cGMDvX3HZMdm+eOKYmnFKBpV4sWD4PU9AokKSvaMDqEXICuW9rCB84jYQBoFB6S9oN16gQr//lUHwRhG0p3rzDIHOZ0ycjfgh24fW2sfhrKbyVOGh0qqEv/YbZa5Bm6VQu6GBXfZIx8BA4dDBda3emAvIYDQKPxICpn2nyCmn+lBrJn20k8DhbFC2bJZLmdAfKiUz65D4zIy9aPrrr595xIiOyyiwdGv9WcsT2hhHYkhXe2/vIGb3C+cr1Y1oJvVNSWCb/3VZgiTQOSM+/Axmo+IBwbanaZiR/MsbVn7SUVq9WyfQTcu5si1i18UFSQIWrJAMd0Be1ZrBgGSxstU7HR6jPUxv5tNPJHvw64+a6Fp1zvRju+2bwlEkNOuf0sOCOacSxx1QLxW18/r4BZsKXDIrhRWcxafSjPlVqdaPgaXhpv1on9ZCynVZXbTD9iJEam1EMosJiZeo9um8qGTDmfNYmvIkms9nlILzwFun/vCWpBzb2itvlqcTdbihhAEOkweXuu2iLmXJlyYiUmSdw0Cdu4hwWSG/tAuvUgJh0lE/OkXzktwXkrQ99x9q4O6+di8S4W+elp++7F9+LiTXVskx1veHsfpo3DSuP0jVTb7x/diRPkPvkJqW74E/0S2IdEip699/je+LPVnsgpoROeda/pmuMu4unNCq33x5kSyVQcC2Wt84KYpCKm/6VTx/wK/Nx/vk2baoN2eEnAjGMxtqfUdyP9TKFsEMyV1lSmaCB3YnFooNlNzsvUz9vRZiNLRLT0wOXr0FtZpVZqThf5T8vkf9BVScyKmWY0BOKAuq7/UL2ChssD6ZCoNaZKD7kW6yvkB0fSzxAu9xa8Kjxo7GRCxVbMmCcglOho/gFcmRoaeQRvdKpBWy2//i5CYi+iA1eLgCxd+S+/G0kgRqcPu+VP+BKUryn8zWCM9guYsqRLV9jTz2D21RmX8XZua8ys+bSKt4DngQHGU/PaAacSlETTz78eojKgSE+FQYNFCyDNYa+ro2TqbXgBQA89wAvXTSNTUy71PqpWGCPJpQmbP5tmJBXOdRq0X2LiA3ceBj2BUp3WYR1I9j31Wkg/ilhf7W3n7AdXkcXvL3UByZm5DT2c+3ktoBMl2P+PQh+92tJ00DC63JBP40g0SH549ygFUkRCAUjKpvwNAtU1sF/2Qz1dlmfY/P6GhaL/NOLuPhdMsS0GXGBNnSI+E+NJdqszZMyAE6/HVH/4N+BZA2/QhNJqImuQbaE5KyJfaZTRyCgLoU4H22K4bQok+3Lgaiwo7y2UJem7cRV1jxSrCW5WsEimDi8tMY9KQ/dmw3l+tqUwpu2erQm7DD21X8D0UWqNJwqmbrjG/gDyGiMigXSbtp3exN7BPON63YC+lTWjleOoepZqyGqivOVwjSv0257vp0J31xDjpH8lRtCE5OivxwdmmBH5YVhYGleHqVRM4h0frxxWPjPARbSLTEGqzEh/kYdtHUf6rCJ9WEvIlT5c4iDR8mDDkGXrIt03iKFSrrIpxGSPc8ICpiomKRNgrT2e7uMxgmagwOnRnbqJ8uLfYhxNsVhVUrkvvOICZzVAPPXdGcDvwYt04FPSDxOBHUI6/tocqrwqsQyXJldNEG5y0grR8+snfjekh9aDUIpf8EBLD1P97lvDhHlI4FSEq2mnpnXgGMt9am/I1Lb0dhPPl0KFnJNi22n4YmK4SwzS5sF0PLT7ejfCROluts5KYvzqSMcNhkQLEqcH4mrc8zVBWzDgf3aT0rhL708IiHbz94Z4bbqp1VWBkEW2nYtQpGuzh/NTVyzGxSJbyk7vdWcD16Tuc4q267Q/taeKXOKsH18JYZDJSqfYUiUQLAU6sO7pxaDEP/nylRxKUr/b7CygzGT7+GCqEPJsCWgRK+wwQZmvK8omHPgRNm4yHiES52itE+fSi645k1/2UVnikXaJhTy2PilZo3bCXSsrAd7M30zQK1j69xFJV0vmjPN3LGOEpw/pNI63yoa2vZM0PCRLmptx3jwah/RieFpIgkPa/tZWqXZzuzpugL6jIROnJo1OWcDrDs/xA8lOL/TlY7ksa72znqlkzGe/rysbp3LcwXG710WdgSsTjeqniQa/YOPLFeY923CYRfo35xJ5K81wOBHygzorKzfSpkSpQ1IZmVVcBvBrXIxUrYT2z43o5SUCpgtoxMi77si3kQuNNGPi4K16fimX2DNSzGb/CzQzIadsZ4Nvp0kPjf0ynTn5kRv+n9KMQAiGSvU74f84XkKuI4E9CkakRCfCR1/97Iokz/IEHc9eTzgUuNRuJrCK2M7Ymui2ptN/YjKOx2daSt4h4LyyIHbKl1HjDCXltKfplTiilAZl2U4j+fui7Z/g1v4ns52MMfeZx3WnRBLrXcI6ACXdIfLKiNUsjHgEXscbh6izk3z4phHf10vr/rGyK2Oc+UK/9fiaJiSddut4kF1l/ouF5D8P4hSpkiSTZ8uMw2Ej3TVgnbSSBh5osFotJDKOAj8rH0CFGHjmVc8e++9WMUAtkjsavYfgf83kfVC61GHratfPOJlUPmBd8eKIiFp8g+Yqg7b4A//Ni8hfFzbfGtqkaUCEtjEzneiyTJTZvwjbpPUNQDM3Yos766uv7lzhgrAaCbThszTgltMGc92HrA4wzA3IjZGGEyEEp1T3ABJL6XmhYR7qX7Gvp12kP9QWlMZ09zV38azPHvmXz8LpjZ9fkzlpdKq9g5mOnv3JWyq1u+LgjpZEEoO21SIMN3OTpk6qq1E9kOWcW+Icajk5vP+zUi159jtrbvJcyD5mD4xI6/aZnLAYigF5TRKPCeeT1O99RCZASMj/sNumL4FRcsik1Lf4BH0FLFYl7IRG4BaR02qIjdOCt2yF7UWv8BdsV0H8n4tAqQiO3zr7NRGo7Vc8N/dPxRes6kjQd5opA9GWdAYYktCZzBrwBXFDUXGCEhth2iATh7K/5FFxFMEST43LFW9xUzgKfslBcBav3x75b7QUm1uczFVle8/0WarUpDSNTHn1CKshnlzVuu/7bmCMisM9qudaqdzM/JZ/r0XLJWAJpzeuE/ok1kMWyiKWj7o6R+aRIjCwNwv/UUIA/UQKMm0XwV0/LOKyt5Zwb8vp60SQGBBvYBi1uuYmM9HMNRUMHG3yLWskaq4qKUoO9Vo3zxl3fP+UZdZuVYtjx26vVNN5P7vlu2uHTrCpn+yvCbbiA6liQWK7cFHxWKf1vVWml4YG6BXh1hGwCP8iOu4Wd+Wx3zRx9aVQ0JB/Pg5gSR251b3OdhQ76Wc0UOrg+ySpR6Og+4Kz/4P4I3yAdGTCKYIzrFR6P3/mdrYCsf/tTHTgVRNaT8bAnBVUP7pP3bXBOlluh+VPQPsPj8UdzfBo1Pi+ifReS280oQYT4DdNJcT9Zu+kXVpGZri6XUeUg+FH5rZwdD2FCSXBzFIqiXkBeTQ5mfrLyOz6+L4UK8OkOMWjWpwjjILsgD83L4zQMpRmk/UydajoJ3pQ21D7aAcV6vDW8AP2pTpQmNXgem0d5qUVl7/MsdQoeL1GRK8IfkIeou+XZiPuHwl1It1OQgKp+B2r2Q1iOj6fudhhuWFj1fOY1tOOBDmav+frtVP1gXbpXzIEZasm6Wbq3br6YLhiXdzufat0fb7ddaW5B0aPia4FNMli0qqAzD4jgI2XbMiIgIAHAXgOIgm19CrlvKmMSjsWDSZ/ei3stBh3ZQqs4qgUIcpZ9m8RuqO21DMTNaMA+wwz/9dllTyD5rL0kvmXVdsFm8KIg3U42gG6GO0A/pGFeVVq3sAFi/E0Amhjj1ZkXPcg4W/81zgGDMAGuqFS65XYokuTybw1P9xoHaF822rwQvfKy/J4M4Cp6II5LN1EPyU6ZPrLoF+JYL0XGsiVPUWmME9dLq5Ezkek93fivHmf3cDiRfq7DpkqR0McmcLKf7rGJ6TKFRnUIuoEKTV3+9OsNrZwQsN18rH5jGSUGScFwV4JbXJ75Dkg4GNSh3ekkget4NzYoYifTAGO6ZPgDdJKoPaCFEjanEXTTldCmo3XSqtzOkyPCx39zcaiwscmOjXXZktwiXmFmlvy6KjAKous9TckyM8rk7ivHF+6Wn+9lapLQvpgGzBPK/QLewhpYjtoBaB9P8de23kyOUnfQE/ozr+dA2JKxaUk4RGuj48YUoECJngm3XVxB3nnnMEFvYEhnmJUhmG+I0s/UWuse3XKTX7JlO9nz+uoRcAynbbTA7b6WhtyDX67/M0/rs93BIsXoowsvTve/L5KO7qzn8KjJmYcFtBTOurbC2rc4DbfIQm2CfJzQAI4u3SurixyiS6f3epS5oQ3wbPg10naiixp3qIEKUMvWbPU0f4xvAKOLZS5qdVD03vCWOqxeRSfEVTrWcBlVfVFVHpzirUuH6uczxsE5Qf+OGee0givDYQ/8Cs+uqXTRtni+PyvLkEBzwDh9Ix0CrLTGs/fp3sqV+VyBQI+ZSH1HX8x/Y5AyhuLKep2E29e/7C9hfa+ewrqE2WupVuOlEBO3mppQvcT+bU76399aScQHyulWwMkSkJY7ivB8Tghr/UxIbwEmUWZVZ/2z5iDAnDJiJO/BMVIuIchxrXYP/xEUSnCkbH+KrajZrF1acEc2RchEkULeMnfMo1pmJCOHtfyg1Smve5BFQCER0A+vY5RC9HYvOH8hhIQfY75Px3OwImly+CXrvFNDQELCVy4lreqc4H46lUhb91Nph/xAauO7gc4pB83DfdcXtjN0gm5N0Bbrywf6u+bQVsGbLmEGsu9mbIu+uebCk+8wWBdZqYTb0Kgx3NhPtsOwwTqz0s7U4ItuEEA1YBG0MTamMTu2H9B28nQK730yfMce4rWSz7qT41B8AH5h8/ZTZNI2RzxJf7ndlzrOqxB+Yse8BP05Rm/JZrGkbn6dAjFzP62peRWMUnvsRReCDuU845y9w0t01H7vzWC7BehvegwDpsFSbfHkomW/NCkPzRAo5aKegIRHicTHlNY8BCAEk7bq5Ab1t0LOPNFQ1zUBI+kEaM6ZJd2RZ5fVe2gYcMjaEZdE+GoXhgBuEs8+QhWl7ZGSPJu3ntiD5Ad/DUVwlw7karRfd9o7OrEZYk5qGJubd9E8QPLpW7I9KDiVyljjBgfREa+Y+9+rTgjbsW0ZmXFYaV19IFCQ28Xjzioff1HYhsrO5AxZDNUQv5vr5XZifJSUa+mzcaZn/Ic+T9xxwAirXbllcvuJTIpxDHJlioy6gSutkW8rouYOyMUHIeQ17sEEwYE0x5J7i1qZa5GPkxLmKoSbr+aPsuOy6NkYh7t4HVc545yWyrY3pvLrcwab8+GV6SMaFLnIzo6eDLnsxT7IxhVjP1ox/HQBny7rRP9mDvOB7VVNHacxcchysPlaVkTq1m4bEjnv3o5RlEP60uEmdBDkmBWV/64zgla3wF1jxhlzGRr48ErufV3Kbyr5bhC8/ZmwdnAKudvDFiBtT2CqZCl5cuM5zevnR5r6OnYZlraM/rVcDAutAP49TUxGCicCfBYJrGhVbIcX95sWbB+FSDJ/EIN1yEZJDE69h5QtOcirwARncLD0Ac9DVpudCVbbu/httfZj26XSU/zmsUPVDyutW2+XmN2QjlF1eYuttKYrzlfvtjnYOE569ToeQNoCbP1SPw94/J0+nPyaAZrP92bhALLlzMIo1Z5c1nIqLv/lGFPvdJzp5t01vML06Uiv7bx3xTvR2WCi1pcU1ZwhDym7XUtyeQlJkgtevfqyQ/l0YvtK0n38o3pwRYadJLnLhIfwesXYGE34i1XF6ne+5XfuCsNEg9vcK4CLk7BdAARKk0KbLZAlyPfrzXSSEX+DfvwYB77GKv9QsPkq9/6xuV92rywlj0K/MTi3hQ2eJ4Mix2b926shwtqiVu9w7utiDuHYCfVC1xWTNgSZhtoN4bDplprmzKqzze44djf1cb56HJdLxSrOWt506Hrh2Wylk+pSpYqQHM3srXg4buev6au4/nlqb7ga1fHwWjlmR0J63ASrHCQV4MZm2MteIaDsqMWqIkz5VrXVHXnILMUke2oTV0eZ7ghZf29lRv2Ee7kXQiyJMOfSZgd5B+45A1sUSeDeNQlKKqQYgw5Up4PIW4WXSXkT46F6a0RcxoJ2cmB/y5q1Nf2LyrmUaw7f9bDFMMA+mZrUH7KUvcx6jLIoe5FKvBDGhJ6d2+Wt/UOHRB1qs3X/1c1xqj0exI1xvmo0JwQAlriaL4fpc/ShdXjpcBxyLfuAN3GFi6djbYXDttKEGx/k7wi/D/u3fyo35MonIzCde21/I5n4f+yw26G7j5oCfh2ivBOvM/76qtD4cbOlW5askhwNRBaNCk6ygv5Knnr7V+HBO+2VNNO1uLxYWPWnbIbjBvewGLyDClSA51mc3D95Effz9R7afS+aAYNNZr6mHP0G66G68USO8Ckoc+h4bCNFnU/JZteaod/NHXxEqo8wfvH2E2RY5s9dKtErxlyhncuJmlqyBj5WCt4iQt43daxQwZJ3bjwI3aVsFfDrDnDIirAMiSr+rMnkbeJFw0hjlUrKcn3O0/RD5zm8NvJj5rr//zGJHu/sTjNXY1LFTljMiPPYIOPiOVndNrZ/HF/BsFfnu8Z2K7e5oUrhdKJ6zoJ9JeqfD1os6cKWicJGW7OpSJ+pAhVlYZGTXYzPphIO48Bw5exMgN4AS9rb+dbQa6Mq6oL+l3sgIapxskyKa8rlx+6i5rBe+foONVDsAoY6jOTYdwVeCir6x/caScCC9HGOyMWwi5B/q8cPMzCr8IPaNAnuYWmc6GZtUHeqhpIsSK1HxiUW86DKeYAjzRtQiR4BZWGVOJo/9qf6gjn8dKcGRiYJuGuDnPdbZzk8R8tjBxXGcEsLBORVahBDZDn4LUC9Tbenvf8ziqQ4y9d7WPbWYXoPNT6ZgawnBeev/uqcBWzXmrgUMRAgyY+Bk70SL+3fETQtHfHLEmoGqqjf0eaBf2MbQkDCYYvWuFsboi/4igipvSq6n1pMEnj6mvg0lcafrlyxsM2NTM/yMEhN31PVgi9hjBoSNDFk0nRH7XJVlRuUC01oqEzO0X7WGhP0RJMs/bQnNN/kDdJvaJdRX3RDvbe/Wkf2yVehKUR5UUxnftiHb+WCZAMwBSvCQQ8KcZVUFWJYhj/WeroX788BY62JZ2CZmsVNBPwB7s4vPtWzso/EVgdRav+PrSUSFiZt/O6My3Eb4MlNXidm5Q7GRX2wkPyfTzyyQIeOjfkC1EK/Pnm3hP+NIZf/1rd2sl1JLAx2O9n8XE8O935mHCTz8j4SHipoplKkdQF/MFYUWloGRmVO8jyQVwsfPwOyVPSp2dlQ7QzA5gyPUB8fUbnHcta2MosuKLaCiJ8Lig+hIgtKphfKhbnT1mN2SjwOKHM0cqOZaBVVYzlv8vexxq5jaAAnQh6wa0YyVKm5AFAeg6cqNqLW4SebEIBjp3msSNCO5+k8kR6plZSIbxcOU/+WluhAkx9IjDF/MP3Q5RdeDGh1rKXtngSxWkfu5b2vWn7bhgF36HBOFRaulduD0amx/T3bo33+4xHSDhKUxEjvPxUXtcaFk1+ltDOjdqaxVWUpptjT9HyFseuMPuJBAxNVB7sDdfJWAgPFdRekZV+m3CIMJ4QCs/bfFvbm0YioWpiEeSzFQAbq2tM+M5OlSpx/4vqfBxZ3OnK9/3/z+JHyAYL7TIZ/mTXUcBhFOn2A50G7ZeJYebETDLSwh5FvtDUt2M96v8J1srSNGqeJ+pGFMtESLXEnMzU2rSMOlbt9Zp7wSZGQnHU223U3QK0PcJRbTzf5655pMAZZXMwjRFyqOGZUmEjJJJGSW01WfuRMHZY4EkHw3l2OIcGKLQNGdwRyEj+oHneH7vxc4+xE2amSHqmYD5CVNJ/8EZHMQjIhCeHm6lDwD4Fu1V/iQxcs71i317ScBUNn4P4UkX9NteH5DRncx0mMMvSAq9dv7yS0vULAdfSb356Z0TSpesdLT6LRE6T0XWApLwO7pSS4IYYUAgrU+NypII5IMC3bK/RYShLtj1e+pXRIIflWc9DPrGW3Gx8O7A+OseVR+tcNl1MgUB3ePwAhzXsYQOBSG6pVZjUBR1xJxe/LYW6g47N1+hCN5GWFMK0ByzDNFKgnP6DrzIoJgFmQtCBdXa9a0U9Tp8yY2LeUfrOZMJiWVEIWNm3FR21L57UnYgCl+sS4GWs0caO689eprqGAOeHfXzufIvNBv/uUN9EiWmRve1058UG1qlWCgExwif1/IRndShRnx7tITeR7jnwy+4Kcuo91FPIlNhONT2XiZX/IBxZZ1BkUmNSANgq1V0cfJwJ729RrGxJQAFKHLjrcFQ4SgArBpjlzpH/kpJrR4iSJVx2+holhLod9tXpvkkv5VzY9zt6wCrde6cafYSzDvykbkhcnVI+cdA9oJ6JB1Cn/AAvwY2/LNX594vWgt51Jhb9JG35gkyq+46fo9PyAE2btl/xc5S8wst54a7neCFIuC3FrxV88SAafSOkK1w/pui+h56Ib/0mzi3PijB3qeqfuQsjoK9TjA3ese5thjSYqYPIKRKyoM7c3jm1OITAbu6KIbqPVN8vBlfg8qYDe1WFxZZPXUsEV7m3oqrtC3n1nnrFTcVX6xy+0LYTAYi5SDQ07c8U7Iq6LZyCKX2XpB5FcyvC6mbR5cRpDJhPtZWaJY/jYpR3FBkm0s0V1bC6N6rY48bpE3gjajgmwmTdMjfhB4U/FYTSHMH7MD5LWvzCI5LpLMvkxJsxf/i4tvzfS/1vn+Id9gaYr9tbQf/G3Y+fjOdkFBjSLmCTtPV/CU2NyNXMeiW+ptoOZGmBEqMrtu297w32Tw2IswwTbEcefGZJHFgsSALzz8P+PrhTNgaXgNOF/9/QejQrD3px15vyMYLQ6/6iJKa8CTUPiS5J3nSohX1rJeBIpBvfutwVTaSNZfNUt172KpFmtBNuM9jGk3bwVYvKqhTNAGb7MXPxX+3LwLXuClncSxJBvgBMBHuUlmzRvRgJ5qogbqVcxHuAswZ/Z6nEy4k4+puKpUIZlHAd80p+wUqXKvG2yQmyAVPM0qV5wWDzRMrQuP8g5BsPTdNt30p2LmyM3zsqML9ppG9eLuJUwQh4jqPITePRdJ8qNZdOCr7bjdMXt5jNp5Z0w+9wvwBbHPQifrCmOgVvYYE3yDo8lodj9kKyye2YBXUOBl+iDiFzTAdi4cxl/2BA7DJv2GLiPWJ7S8ecjc9maheOtP8mMtj1vTKhqwzuAJXjq4jfdCf+Qn71Mf4j/lPWRBzCoP7QKFI1pMq8ZhV8uJdhlf8TGSOsB2hHnGMpvDJEkQfx54rQpHcpZoBEhuxOB/8hMNSn+acyRFqwo02OukQMDTQS/6VAL9jkaFhzOG41uSeJ9d4tNqnRsF1UytQg+e0FZM1e8+N6ipoefMxugL4iZKtqbQyS1SDPCTB0S792pNpMPnM3UtZapdlvb0YgAVwXQkda2wIibaaawuUZ/h/lhM+EyOYFMxfKfsu+hxQz/V7CdT+7CWIICRHZuXDXi3GpfN2m1SGu5TUBsg8pXay3FC9V0WYAFW2rncy3UCcZHG5WIMSSDb0mU+b+uJozMPnh7O6tpeyNwWwrkeZAALEHbcqKFtPmr19Fh4Ogz6df9uW6BVnth4B7Q2Y41LnQu9WjQYFx+gxPDWl/Op7zPCdPbb/HSSMfgdIIam+efaAV0EEJGSjMAsvk5FxnpP2OjJ9vnWqH6A3UIFGHmP8c1BddZlmlpZJuBl6NDxRJyqLWcBzyM3Izx9gxAvprk5kUT/qdJM44Q7oibppAwBaCPAgLCjgeUaBarxeta0EX4L/uB4CqMLju/zV80deYTMUwBbrHW7wa2txD3LWI7CdPdmJXGfCCqRFgYBst1u8q/edS8gkpsq7fSkxLhRPVLoo3bnbV5fmy8Hd/qcRV5MXsc0T9iWCzwWt6g7DHd1Vvff9KL5WNY1qH9VvDfjWMhSq+PWte32hAOWiLn5PH5r6NpCkgWdLTneM12pyNUed8VWpiFOkPwEnErwqxnmzL9RTorjW9jUCEzY4edXzfJeRcZGyAOUSKyR3Rp47HltwuOHSWXDsZQksjeAr08ol5pjs1JzoqNR6xEdWqfYUdQbtyKq18fVDECLdF0p9bce/izD15HG5kCwb12uohFqAA5kEzVRvIG5WD7rdBoE6I8bAT9GImE8Zpl4AuQdK601rOsta/ZjsfVzyWzZFOQZGXrHk5yF3yQ4+k5Uc7po+D1SykZAYXV/XrC/rcZc/vKhbOl+6tSbT4zcMpJDFnMp3N0MmtbNUC0vF+YqaeZ9hrM4PuaGAgLD6oOLrg3w3GubLVGShiRIEdjO6XzrbdgSOY6lmgppV31zSwIKmrq4leO8ZxeecY4v9VpLpQiW1OTaHsxXb0Dks2i3RCoSAVl6wDFkMQ7KILebfJj/VMQyfILifKgsPPUlBsGM4zzz4rN7CNQmglwBke/I6S2E2IgseH3cm/ftYpyESfxPXDOreIfLPDza77R9945EZ5+FbjhaEH56ftEkVegOFCwp6E1USKrVrSp8UuUIrRcDS53l9oy+bJBZbS+zfYsWfrzlW6M0cugNmIGOh0SuStudX8Dipoh4L/5s73zqEZLsafoC9MZgqbs8rFqc3SNWmWo2535Bj4Gso+4waTMMDbn8isRhf+3k2Sn6f6m/sVFN9fNGMXMsKLxlhlyxNwgb2hvzqNfVqiNKgVM4SNoN2rndvcCZcslWSTQW/QrYschgHtBbQ9QV5tq3/Nlhb3QEE3ygx4yhuQ87fL7v90Qn+3ilM7y8le10yag/P1FP4SxBNObKYXG0B/TtAabT1JJCbmAfco8UtgFJjSC0c2Ha+YWVX3JWy/Va+nst1Es/XxCG+GTuzn5Z0yYTg/rhiAMlgoO8+v1maVhOl14/pOTovUniNShp0KULLwO1iAyMMzsClLogsImDjen6BX1LqOMa5R2F6T5O6E4x9vQzxu6LrdQdkl/lug0hn22JTLW7/XQScBWGo7aPmxQQIJtVzUeq6HAvYrauNWL3hXc8630TLLBxYgKsDGqtUiouKU9xOlp2sNpt7ABW1Meyfe5AZOUUhYo5Wwfbh/35m019cg2Xf4ic90gJTHeC+UAbRJJi+7jStK00ekooXuGgVT2hxjJUBeAQQIzvDhMMnrI8ex/vinCsHuafJQw6X18q+jNE7mrVZjPsl31uRNwjUPw+LY2DTsloRsbc6wL9UZwSEuTpVMxGSODSCZqeb+crZwCTB6xkutXQvJJZxmu3lk8AJaJc26mSlUbT7w5RBl1iSiv/nJ35HHzvS0LVu48aAiKMj4IcXxj87v3HDUJvlENakYPTcH+41qCqkfl5Af0xWp8N1Th1ZkpkUUz7C1JqHD6C0RpKINzdWIpyXkj/hZxXyPNYuFQ5AcqImj++83xxTrfLa6N3/bfWOuJ/tsRoc/IUYYJfba/f+4WoBkn7h0kTp9/JDFZL0HlLVJCKa4s/YqqWJWU4WCUGSAttIVk8zdMztr+DZ9m+4PT1d/rUEO1GQjYsOoRbmKPVNq6bS7INmK9gSANyw7RZSWoDLDYUkEjJgHsTxGGlRc2PKYH9Fd5OYBYzBi7C58R011NN1kYs04Fl7bE1o72GAegSnJcwu6RRWJuN4k1FwxrmecYatQBzYOcSa46fZDVgnI8Zz3uY0eN1TZ8DzR+QkR31a53KKf6JzNJ9+v26K4nfbE7e9bJSiXIUAyDA7jm7IeabTpsDrmxOKQqUc3+bqQ9OJTW2WWXZLYNjmvz5IfPi69YF1BuH5/kkGszJ7N3Z/y0azWPzrsX7z3yuf43DiAvvGKC73ibKC7jkpymTylx7mV5z5L5BNhWtozbkGkB1oOsJetoDWTSnwU5BbvuQtUCJVqZehvqo9eIOxIOa9giMzdJQ6ghTALFG6THRwu2ZP/iTo6gt2//r4n9yJH6ltHnllNghccg2UoQeMOus0UZUf0Bv/718MlOnV3VY7KIIAr6fxYsIJDTgB2zLcamQLZVD8mMuzWBUCKIKhZ9wOWLgAtkbeCSy030Vqt+HNpoYQ0wwxjO6VC5Yn0B8TKJJKYGitGg5wF/OyTxXr/Ijenl2KpeMY1A2Td5DEe+dhHZHtxDgNMk7KtwVS0AmeSxxaqM3aIuA5w8tVgYS3t/IIyXjl8jlwJIvRr46Hr1joxAyaxYKU2FlYtVKgh/c5FqMNXHs8+bzhLxQyreUdiYFITRvN3z7AwPS6Z0mBsCS4UP7f2Z9yxX4q/8J24E+YLNx3yb4GQno+93HBbuy69p9JsW42QwskTpmtcNxWACy/25JtOEUhp4/anMkjE66MD98JQGOnXTz2T8creTh+ybxZdjXLpX4QzvaIw9xiotQdagUARATEBlsoBti9LgggKwLesykPAtx6S/7R3oZf2Mm9/Qqe/ppL3mOQ3p+lFslgKC+EP0848adyN4A5kCJfc7jsxVs3/tNyx5eJyGG7PuZMJukXLLQDNgopZKR0XkZqi+NFKqu5keOLjvOXRRAaPp6svM9qnOwSiirz3JEElcD76/ad86sRNXL5h5kV9+OOjYBl3GvKiGfmMn/tF/5WBVUa2YX7T0kszZCaWNjkMabiIMRzkUri1sXnlaCgnamZsh54NxzaJEFU1wgrXIQYmKVGevbnSxRyw9InzirqLaT3gf5LU/NQ4YTBBDTY87wuduMSq0o5tB2+MVAJgDaNiCuYTuQ30DzGcgkuhGKJFefLhBvOZgBezGfTUPjN/2VrZKkVnV6v+ToSmbQUt9WbvL/C8YBvIV5OhIrf7y51vaO4Cyh6w/EQ4nNrAuf0RikJXGn9MYQVpI8ZrxJAMXtImgMoaZbpfobdQEiFysZapSDVOxoMXv3laojSJUXdnroKGCD4sBrSgNy8Bi/5VyN5TvKSnguL50uwGOcLLvamSfDK17PY8P33/02/Jssp1UZnzacxhPaQGuJKsvBbGU1G3Rl4mz47y8J6M9UPCUcfhVzQXDGINvEgbEXbnfmZGypzzHA5tyQoolb5EYqflGaQeToTP7NeELklsT0Kp8GN7sBkKEl3rhGqrr3qIdb4jqXu+WDcKWwKZNsjwnQbhfHokHYITX6yE2NCCJYLgudXRZbwE6cigokG9Wr9cK6D2MyXn61oUVmPybw4uYFAn0ZvNpZwCVSlOnehRjulC0PZinSZROiib3LuuwK85KNDh0S3+AX7pUjDPkOaGlTE3VkTW1SUvrsoVa+5DMWMqHLSDNDsiCnfg1C3pDGHWHqx4xOYSCCX35xYEtI1wnMAxB1ykCS4h0bptI0xjxXZg3FBpkLp9wJulZkaRVbiGHrwgacEaQGtVtKCpaYLzrArltYkM2P7Uj6Ahfi2/Cqd+jtnO/ZBM9Hb6rLumOa/6uyaobBCw7hhvgViPUoC4s6P41p0hyCOlDCtr+bQzIoeiD0qmK17DE2NzgmgWly/SpQ9PsPMQKNWm0lO/vC0YoLrqb3CNYwZJGCuc9c2b0DsQrDhHuNc+LYOrDVlAVBMCPrzBkriu+lcD2tgs8ACCJpCrN6sZ3i6q/ha2JmozKkWaJqSc56n3fbxFKnjcyPhWh5hzuAoSc0HIQSHx2mwYyne1GuB1vIc21IWn4Fzj9VbwFiJ9L0ozMwKSxM8qLv9lsJP32dc5ryXichVXWyR4ocAHRGzPF28cVZO1+RT/I8YmriOjW8Fegml+IPkqawWXfn5zBzA3KoHrf0jAeAkdVC+ks5pchWruTu82kHrRJb6ayhRzN/JogucDAUuumVwNFvccCjLee/4LjiMwShVHA1WNgs0kRUve53gR1gDODAUtOKzKVQboAtkHmM51hBROMHo2+1obg1s2BdJAItXGUpdbgeMhfGzA+fsthYTzfff61FDn8uNM6AupWBsXUG86eJBttic3vm59n6I/KgaALgblnhFB4yk7AzqUHehvacPOtA8RRe6pRa/MbseKZ6m+tYCS3Zj28dNqsEHw+/txwjpvj2RjU2FQmNeS82Tab8e1ymhX1WWtDW6oIr3gwSh2hw54kTbGpl1eIBuhCSM0hcWwV4VvTb1O9y4sigrbmgFdzmaThN2tgJwxUhTNINHwIJvmBTbQfVCa5C1ggX2C/SeThidihEOWRrtuwsndtikFq0C8xTTWpw3r1qxGWJN+2UZkqCoXAcImvKlHJG9+p3MVpM4oVcbflS1bocX1BlLeNXx9ioq6gzgHw2V1jKPRWP8GFWYzUfmfc5T/zaLk9LUGGtFYw6KlHwYGybqRcjvpFwRkcwypVUHNgbLtsm3Y1TFr5MXWMl9yrXpOlrnsJs/HCs+ntYxTS8F2ibwaY62liODNa6SR0mCNxe+9e0UnjkyzgjrBPInklW1z0UpWAmhe9qQWT3lzPvGY8tg/wM4ZL3zZCxENMmQJ8sj2EmQpSvyogRMOg0ktrFoUTufDgplDUcxQDqTqWmIxBJy1VZbjl9eRJdAiWh1zYM7jGVTuxCGqc+il4RrYUmHPimnhiE4dYvIKzINntBTpdIjY42dbgqaKHG9Ltsy2i/P3aJhPyFG42zLe1V/ia8XCriyeZWru7Txb8ZD5RPTYs8cW1/xDZYy2lVmh5V6S7JxpVYKSVmrFWjGiFxo8/inidnxvt7BULSkhu6T5/nHr3d3NXDKikcFx1P+Tik6FEWuFq/rRmUwtvwM/QyxB4T0A3qPTn/uBjdArIi1tFzppq6RHWz6MszrH/LyvDtLXLG8Q10lXrYzJ/EqO34WokkAF1AlfMOeFCzp01VOzzBZuIZfgd2za+XtStdJ2rMjLYJ+XUqqxCE/uSYh3AfG0jdzjst2DZ8ONZbrUD5BHprRet6OFWDIAhzFHSg0gEUL0fHGNp+PRVURwexDh40yIYjqc3qroXymNmohZDKCMqyf6I4eZTe4u9N1EQnaH8MVDWsVT0isNHtufT6Fi0sYP27/u3+y/GtQizmUclNvno0kJRTBQsVOOntyIlND3dlNr4b6JWVR0+pwOPZy2LN7ckBvTBrpI5h5AhlgV1U9DXKc3d50jqXLtgPSkMHmQL2joATuiaMQyaDcIBaAQvP3/xNRT4Vo1J14iBbaXBhpyYxzq9IoaQCFffJD3BEPobav5we2hl+lki+08d50afkIp3pkdEYU0NIQc7vfKeXQImLrFCxnM8JitwydRWRVe2dKVZZSRN70JoV6P5cAgDibKhKIYzSMVFRVmyiEEqCk/A/h/UdSVTHxQpqwZAvngVPQOcHD0MwN8dXYhijcbDSXlIvNwHFg2TunzfC3ulw795/7rT+R3+UuEJtdkXMvnS9s7/LG8K+qhRuJri37ijeaE1+wGUXOXXRwtMUg0yEbm2BH7nXWD+2nU6x5uCVnestgb038OcCnl+wjyZElvf9lqVI8jN4H8QCnH5IJw/MeBX99/7NHRMdE7Mr1oCaZdsWDomZ36OqcqI4K+uBVYvZST+hHX/tb+GTerlKXiSaniAPZXG838NpUzsruoTfMcMTD1o5bZXoY9p7O+VM4m/yeTGAhjToqZqQOd6xIZaW2Eyr7Jbi1erByGxz3fQMj9GwOJhkVN7yk/TBoGIwo0TV9AhddPj/65uKvC0vSOCXzYfL1lHbx9I34m9+cYxGMpEwhST/RMuYGM3HHQv/5xJccws1Mas8cWSVUGxeF6FgA9JvMGDGM+r5uEbekRuCUpt5eSdtTtTLST4AV4YZaEIXN7yEuLAgJs5OwTzW8lAvJSE3VmZXh2vLxQoN/U9uccYQluRwuE/ZpAQz2MnQA6ElnutiJUcKwbLAVGQWMlqhYqOe9Jf8yniJnttzpMzvfDXXtqmpTr2yWuMCDkbOP4CyRlHBeXDvHL/WEixHvnagwRh0tWsS8C4r0Y9rxRu4Nyrhbs1/MoQnNZQcN0P88nJ2O/+CmgXnW/POKYP9+LxSDMUBgAgy7we2fzrTgB8eGFSl+ktErlLk62uGksFf+K5gln3GvgbREpQt+KFqnSxu+hfR3haS6NxAQPJhCCkzFKvnclsEH634J08Jhzlle5BLwNtqBGQV/376TLa+mZVWUJ0KosTZSWdp1syf8MjNfz0OxThGdBlEeWublYPjIjsfLP7HYzDkqggz8fijpD9OSJRJNxT3d4ApgopIWb4nXuCOB1jBaMJMuR5/rcrl8L6JtM7F+Uwu6Lqjbck1B7DLKRHpbijnD27crVwxffuYyblbGFaHBJAM698iSW/rl40MyZgCgzDybQWfcquNFuzDKY0KnmiEuO1AItxL217Xr4gtuD47QJ2TaqR6ix57SZd130i6YUKSRv2D3NJw36B/mLDhDmgprgCZFi/Aph8Ye5P3SiBWkjc5iSbPz8SBllSxdrRjiRnrKu6DpfXPu9n+ch1Ct7a7BaUCK6rh4APu38vCAgKuOpendD5DRCum/zkAZVCNJyqeRweyZmJl6YbeHR3hToKmuo/Uxbwkf/FZuhmd0WrPQI9p2kdhFYyf07nKgN7q1nbdPG2VL6p47X4wt1nwfhq17w2Y4s/Nc3AkFJ0SxEu7GOo4wHsWUHP6zWZi02UZxLgl7ERCOKy4QIvgr+J8t2vgHm2C4t0PxAjzcG31er7ccJ290DeLzsPGbXIWXvH/uQdNgXnv4rDWUE1UbOMBFNzLeJNHOaKuVheKz+6N+PGgv2ceWnAax1mMpbOGq+SFvlQ/+aPLyM9FTf3HusjalLCTsHoLtnRMOuas0kjaas5fW9G+pKS68bF2KMwaDbSyrhsxMlaYbQsEmBrb3kD3sxNnid4IhIaBBQZnyx5CX7ySWORh6p1ofZO+XO1dJfvCJwmvEyux8vwhmTS70FLfP6oIa7avaOvgxdnVQ5rIpIYta5b1bfMs+skuDa4nTpQt39M42YHUWEooSHnXnI6a5RVByUzf67xBFA5E7apv1Y+mysQOgt16/jBPGLfu2UqlO4zU60pTj/XAVcYbewHatjyPA4d8ro1VuyE2zKD1xK3aYf8MCxozCvnQieE4+LcNUzj+Dzkaxu4VX+Rugod1SGB6/o+xD6Mnu+dAuYip7QfzHSCewyy+KNaETBW5ilFq34QvTqVRXwyB1pb91rZHHs41xR65KZAu3BRh3yDw4iq1udW5OCiSlmWccY5lCfRa9zNlNch7fyOicd0HHeg+O2Wb+NQf0uouG8HjxyTMmO3cW0m9ggi6Up6iZofQwtEkVRLFRNPlnkRZ5e6x5KjPbFL/CyqnQqwnnpU/rgB1rf+cFl+w5Kq5ZlyRc/n4iDivGwSdajjs4YsGe8WS9ON+U7yFRRLN/+X5r8oNAkhk0mXVOLZ9qKhLn1UaZ8xeVyR5d1nkIpFydbPoAG66wQsHiKm0c95FipqPWQeciujy+X6I2pU5WLny9jQfwXC6aBKBNfNORGX1980KXJZljfTPgO75FNou6ZmoJkVclCmAAzo8LU0L3C0hA4MFIVyXJL3HSydmimb2vF+8pvbnd9EiRsLDcz0o0KYXltyc1Ora8nkxN/JHuN6VSp8Gtk6JM1K40yo8vC5Zx+uW/Wxk+TDB6u/kRWrAGQbPjEM1CeIQ+RSa5AUNuTal6WK2szFAGNObm582fO0BxxKMKk7r2wvc2LxFUc4D9wnMobhvDerzcJb8SyoDofO01J3lsfkmChlmF1XABp4DiAATCEvg0bArb6wb5bj3mR6DHLRJ6XlHBVZTDbAb2R8Zl9ZxKuqc+ckslYXRXsSGX2wTCSl68wlRN1ptkXdId0OwXJeWe8+OSGdS26qVDH19TvVEMHa1BG6R6tTIOoafJ/QPJrIYSrIRYc4gWHR86k1rXBjmopvU4X5JyC2psRiPqfqoSuf0p9wbZuqWTI1Yq6LrigwL/q8mQyLSkjwSzEvBoO0h1qfwSystZvH5yksXuMnb3q8vZnSElaA4fMceLN2z0OFKhh0H9SSMKOb8dQCmuw8tWuEzgQYbUC5VKTQZi5ax2ZeLw13Bc/0y8/hLKN0oKvZazIB3KUEJOo4ZCLwfqeVOaHyTUs9mauug4BIXjHdxvH5yv+EY8uEz7Q8PwwFIHDfh1x062DgaUrgd+PT1shigrtY11NqFCXXE+3gOrWI86V92lFlUROJtWcLXvHmoNWq1lqoP2A8e/JTRyXWBPMptwWuRYEJfPW528bn6hTMrlDnLGkI6Na1ojJaaqMeAdCnGz9u+qo7Lyz8dGn7TYUkEHp4mEIF7azpTLpLmHs8fVea+4GdDcYLJKjN6hj/wIAbDHSLRSHvN4Gn5TsnWPLYg3RARoUmXRN2HdjiaU1u3ffj1hmC9E8Kojgcuktg7hcApoEJseqvJLxiHseNHp4E39M91gFMwWEBYcw519tSy7jcwbf9exczGC7CMutQW/h5RqIDiPRh3vKLJPIftVrXI9bAcVRi+zBhfvHEMfM+Ko6GgmDojoIMB8bNRgyA4gH5ZG5dG20lvwejrdbTLnuwGxRAL4VP/+wIqDyr5PCfoLSlh4LlHLTfK2a3YllTiLeErFHXJarz6r3M79CmNQaHEe1Q6q89DhnhbQMMu1lOCsxFPKXgChTS6KLMiBrwXat5J0awGe2cOwIIWx9X8pfFlnNbvUl+r3u2A3ntfrwMBsbdrJxoPS0NnB0KtrNMDerf0+qJzQgLjReHyzlLdB6KraDLd32I0+3jN69OsJLk3cTW1dmjVB6PtQcBR4ovPKYhoJdZpZCxd0HOY5B/soV+lgHMzETIzwGWCs2UPxMiZJAy6kLGvVUodZsl4v2B0JL79q3FseI2W+dJlg6I167Q//YDXiV5iWukdUftOz2f8UpUhO8qBRcccAGVISukP5R5SDBDlt42j6UJPf9rMImkmzxR0krkL5ekxyIGsM1czeWxgsZ22uIeX0rS4eiEFiDsWp0gtNdPyV+lV6eqnuVnl793QH3NFzbjevlb3Sv6roJbePAs1SGbeHcPPDRO18/KmorM18z4Umi32evnQiYqEPaLjhEVMm9gzcPBgXOs0okOZ1fYKF9Wj9o86+Tjn+hy9pWGPSGhw8iN8qDvIy1LJl8tpttInxP4uayZOpqJcfIvd3WBmiGKj7rpbVdJdHOE5Y7/cDNNLXKpiM6jK3YcD477M/0/ndBthCLrH2Ptszuao+9WEFltBhcdtlx6fEgLAQpmm190Bn7y9GIgTEwv6N2TM+5hkeIi2ISY3GBoYAYFlcHwiht1GMNn+gsd21QQ59krAfQl3Z4ry5Dl2cKGb4rXNepEVJDo+9grNxCHHmHg5yK+JqMyWdlp15zH85muXRVs1QT0qryliIYjw9pQdpzGxKa5XB1Pd/851cwqXRxyACzcDHncvd5G8eQY+Dh94vN7YEeYWYG5Qfbwle18oHyIqibtFTS2XFgI5K5TqUqErLdE88Bw+HZfkejnafjgl3RRZD+J/Az4JIJBBtvIlm61UZ/vqSmhnSUHYHwPT/8IFH0ZQXV8iHLLbN/gtFAs987IUokMo+7kiJLylud3DOdL+imGnBhiPyMcCEe77+bNB7mhK5Md4hZmgZ2hyCRd97cBJdoN4ihlrdfBAAKLISACQguWJvbo9rCjfrh/ZsEeVYi9bhgVd6CMN/aDfiEfvm/xr8klricxlh9sqg+b7ln0bWEpJ65iHqnsCG6DyBJFtn2O+OjN+QOrtI1yx+P75KbYoAIwI5/G2YS0RiQmh+1xwisoEitN/4wFUzWQBrBO1juywnv+tYVOz89kqk+h1xN8enyoC5u1J1zHH5JsMcmxdjV+n9ZTbrUJSINPoZhiB5N3+vxxq7JO/scf9BvICEhv9mz+XdbjsMcVLGDOyLn9nUS43gx7G5xaXqndmiCBbI6XU1Yd9e7g6osEaZASiBp6XSdU6qqE0IyS10DXHZLbPySjLLrKArK8ikPRmJq2Qt6/6HCORpy7wi/QmeIj6MBIZ1iD8diAh5dpAGQo1+jvFSpR9t5flrY3XzaAraq4noGUiY9/nvnsSYHYiCnP073Fet1uQqJRwZ28eqeQQTTFOObdcGuMBAOsHSzCQEGxbjdoNMKYpeiYWG+QgHMfm55XnhiVygoHGIvFFdsGI30Z8U4LIpzNmHTLStWaOV1E6WmNwR4uiFZrhGQCytEhSbOVcuKIRfkyoHofG16zNKqkS3Snu2psZpBebgrbLUqoIu9ytNQE9zvFxbz6FjCS6Fedu2Cnzkjcl1vmcsvY3qEdtVefRMaEbwEnjczXNOMk563CQ+X+M3pr71BinxLdvp1YwGdQb5gnbeoFoSSC3Xucs+JhrbFzIEQqAVOxYknGdfDJzoTvYrL9KDJmAigDizHparIQ6VVrqIspdKx+A6rTUasJ9GcAfUr1NkA5iwKTYe4NHOkoSMPb2VSu8UdqeDEJ5Cq3dBmice67ITiUqWTeTxUb/ua+8tVBngmxqkF4OJBVnKf2CEeCKtx9ACzGMmKVaERWqtAXPg03/zJALZk9Yqco2nlAOOTBLBZNSUQvf0+uH5XGcALKVT2P3pxYE1Fa6yPFb2GF5JFy0QAa75Gcz5jLgtD5ly+tBpA3/QcW5nJw72zyg+kxMhlAOw9OchG8/um4q0+8aXyXqMBFA+8+NDGTFT9tRyCMDbybWwtCszHXase/w6frIMHDv1/wEqePwbORguUDgUYkv69VbRfMfjZ4C+qdVpOPz1dI6lxpGNLdyoRl8IWQk7/mdPpHzknxY7xKOOTV6BsjkozLA2+MWn5nQA9ubIfuuPMe8Mw4WXsRGAQH7jDxo+LTACmEufRpH83uWYxDSAZd0VYMh0BmKTgI4vMkVKOpCrimrxdZi9j5kBALcWnpUMX1khf7+fwdPCQXCW3PHBgfVIJsjxBFtudHN8lajojM3cB3B53npVy/wK8zyS0Ap7o2mzp6nuJ0sqA5HwfKHcL8ae4Q/o+Yuo+PUlnYuOvlb09OFKrAiYlwT21qRbJMtMQDrKy+5kDBZL9nhha8loSyVf5d+upvOW4hpW68+zrHPb55paNwaK8su9VOQo7UCoiceY49Z5CtUDHuATbiAVpBtXQJ2x8gr5LF3/pIZpwHSKxvz9RzcUwc4F1IBsAAws+ps9LEP5MiVJWgZa3sxjBoRwv983PKM2WFdQ5s3xeSiyur+KkTiuIInaHPMgKlO0IDWiSxIhav9guCVcyHMk6eILwOFHRvGpbinYZk12ZV45wT6wIKhcMd6brUawvabn35F7pN267JYxPMqKiQgcoPw8//wjVw+lKSBBdvTe+xWNr3pz6wqwOAvOKPufdooUXSNo+EgMFRn/dqdIpd2rZ2qwqrXi2sszGv735UQEFPNWHiA2/UVDpxJnkJ7PldUS+y24uDYAP40qSCdAIC7WAeA1CGsEJsmnFSos/IuzsGn31+do8Kz71rmE7Mfb68vQUrhDqe1ENAapWYlkl+cs9/Z7htyeKgosVX0bWF0HfgyT9SMvobzQipECwdTBpQBM4WrhTjkOaZYvgR8vTJcdvcou04bxROa19AOcMJkTdDcZV6gUnCoyXF7vViNcVlQMev+oLpb0abggO44qYkncmkLYWW6C1JHq2Ar0a/v6egF/QGcZZfbiyAy7QVPlwkHqUyKtXEQYkCa4kBptAFFb0RROxpB+ZzPY9JybEwwOLrPhCz4KVGmM1w92upEfPKnyrWS2Cu8VoHGMdSFWhVLGdofmrNPutwQWx0sVffY3v8eopFllV3PPCnvVtxE6VpsRfbnSyrQWxsZ4uhwfj4I//fcoe8bsCMkqnrh1ywXiIn/GiiOHkZJ5C3t6lTFrMAinRZXl2eObZfDc59PdVURCaRIuhscWQw+C04HuEq/4AcMAN/yVl1MCpO3bpl7pjG0eYD8pJ4IujzJljSrLNCNWl555rirYZQR0giXmy+AlQyRfOvXuI+m9Ilnd4+NOua24mXhgedaPTJ7FBX2ULOPlVsLd5sjaeCSvHlG8A1lIpbticAM9NvW7hhwlW02LtuCr0yHolWqd/cZfPhRv4tbp1HRDyp+9DvweAHxWw34LllRrPmQZYme0kYzqPb1KzmuJN4SQhw0mYsNElarsZjx8/mnKIzdH7HecvfNGK+bnm5AitQ8p1FRY1cNg3XAohqOIXR/0Tju2CwUGF+wlLyH9uDbNdu+WmFC1wnE0JysDUIQniZHlPnR8Hwu9ltJKqKwKvNHUzavYbDG994ivNrvAiaxOJyYYBwIox9LwVFUMjpWWI4Z80ItQM8rHqO4Ub7EFaiuO1r1NykOlxONXYq4PpQkTq4tP/xlnlV+5rcOoM2iudh80TOmhGKyEvH5LxnlTl1STuDrK/yV36tZcpEuSeWrIjsBl63zvI7Qgb5GfjIpfow46FbGTObV4xJZXDT+YJ4EdcxHyesJF7KR14iBGHCbpgwC+jlEL9GiJjp/skMS1qUgXSeg6lqD0D9KwYS1R+bz7cBNZSUuQ1z8lcx4EIlTsp/EvCapPLb15kF4/rC8GKCzUPlqsAw3BcCRhQqT+isjzD9xDeYnGK5AGhYgU53iwd24lj6orOrHTVZkc5vfDjmEHyFVN4fVuiK1oLgdsbEds6tgKA0L45iFGRyZCHNfD43hhMiL4TL5apOIZLp7T+oCbFgMSKCFZfE/7fxc6bZNzqX3HJ1Ghgcq7yKDqEggr+5BfcOLuAiVZqWRX+ogugpo5R1VEofIBq4+886CGJFcFw/lkqpPLhyQT/+/DhTnSL4ytk+M4gh6PuWn0I8jiB+jIQ4Eovnuv58hGa5cYohIoaRw9nS/eV7QOkLhm0RflQozAEtiHgASXpL8z5YHP9rOK8XoyMpB301dSZO0nZP5if6a8aBawYy98LvqgKuBYxBMemWckloWd5s55mKpCjzdLb8d5rIlnVo+wcPQpHBrGE46D2CrYILw8QOXMdE++Cvvv7I9sfqqE/0ZWK3A6SVY/sWdT94dWhlmKP3wZ4xKcIaSVbEZMhoSxZAkr9C/k4VMvo4FULzABXca9CYAARkH2CLAEASgIA1Kcm6P62iLsAdTGpp4VT+yfIbyMF8mCClFx0VORvapMx870EOq9Sp66SzgRdPq7hBhowrKeiS4gzGsBU/Cc71cfa6InTWZTm29azjim1ItmeZUmueO1M8YBIq3kDWkKN1s6BHUI5/TxxJigkWWNcX9sdIxj2TnJFLejz4IE3IsQ+m6qVfaqirqWmzpX3mysDq8A0UOLaJ+2l2pferG0/KIRLV+pKtdSQG2OrY56h5O7b9EVJ4vu/kp2aQMymDdjkmpWhbbREDxq02Fs+hgCq1uPaR+Oha9DwqXjy/HqFqNFhasfYWclR5oyMf8pzsIsVe6bJPZ8cH0x7+2n826gAuIJKW/TIK0SqszRpFdb2rhnx5f+rezoM0kIi9k8w0KZOieVtX5TeEkJivD2vWviGnHCVzlTT5AMIAau8NxfG3vO9cj0CjRqSPy3Zr0I/J0qW59tJ6iMX+WA6unhpTmQ7q8gVfrveGDIzczlHVn5fTs59Z4C0mr4cnxJ7f4nnziRRNbkW5QZsVGZEisFEIgTHirr/VW+lI7T3P5TwxtB7QHMWM70Q6Q0FJ6I3BKd3i72UZl51mHhVGeS0ci1RokTeubf1aS+nHo8tW4uOa6PO0d67MfiVDcGizIhKhgxeT5HQ53dZE9VaZrt6nMmXWpZvyqRbdf53+NugUMR/ITvfyq+oO9F/ljciFWzCGYUaSc5BcH3Jt0vATXbGOD3vhtHwATFDvEluf0t3scO6XBFzKjOeXlipoeKUNyCzjmb+6e03mxlk4/eqSSL/l/bOX7w6K7Lkb+tqYvq/ms4hguPIamOHp0CKM2uRcpxWLzXiG2mfo0o8oDBBlD0H3zu4+5LaAqcUZemuR6kpfv2gKGAF/jTH4hK0oiAYZ3N09uZblEc/0tkaL8Y3cxbS3WzMaVgR9jRU7vnaEt3JyBE5NdpMAfRvmFKfjpfGWk6kZ0gKIZ0YU8O058gsqek1vMBSw/zjeJxBalsRZvSdNrn1aZRuvkiD8BgE5I3WInP3Hi09cGTnQj6MtNGWOanFI5dDgY3gR4+R1Iy/m4ntLjmQG35scTjgr8pn9cDEAkijyGPogfUcdwkJK9c09L5RUN3aX7zn1sJACQEFZBHEuEIzx5sVs8GFx8JDRh4f/F7GsJiQMVeC6SC6Osc1tkhLNLbO9lN0cvycaFZ50r+wneLanmycmC2094XT5qz7FciO8ax0KnItUJuKA6TGYqYG8XFe5Cq84rc8fqigptVtgfJJgg1w4RXpD+BK1WATdeGGEYXKuyL82qhPZRMcQfdz4GmhnZ/bBf7C5xt7rPWKdBOIycVvZFPxn0c7Qa7tpz5wm7e9PPG+Ra3apR3rnojZKpNrFf6vQTauyXBydrpxba1BYhRckCeWGaB12lTSvQmU8vsyOEsuTDbAbloG12LI5CRt6chmg/huP0h/10hLIURzwxbqQRor9ltPaD42tU2U13QbZG4ZskfECygk2un/CQwsmMxP7HeB1hmTp3g1/eKyEDIz5xaIzR3aUzN7w+Cj3vxIvaPG/UODX9HkwhPM39z00TBU+w4OhWISDT8WYJjsXx4R18VrRtT98S7CgOcHH3L9GIL9GjTEqvu6PnpxTPo2YS6Efc34UD9AqWStQdSk66lwJ2PkMDmv5jNYqgrkmLDJIRhOmJl+MOKFzM6qqxRgnQ45rqNJdzmd0W8dLj/RtYzQr5mpOlXdShhL6u8YU4c0aq3oadXa38CZClN0CA/azrKzKbAYVGkWuX7gzLsDXRLAwlAArrJjoAAAkOCQAJieNh8NNN7bWqJBj6buzlTXM/2vKv7tiq4ge0mPVlWpnK7S9fJFyexiLmCKQkQtd+P5r5PRJV8h68a5VZyjtE9znDRQIsEC3WKaYRogSu/G7hB4iZfjg8zDIy2cMVj8YvBeUGPPSbb3rHM1HAcM/iwNV/Tsbnzj+iN4yvCX6DpNmAgWrehdVNdRvJ1OloJ5eEOmLYoFbbttjNxHk7OU/FJJW9yPp+AHGsrc4LeXn1WBjYRujy+dW/icfMfbPfvAJgmhQ+VUcI0j6aPGqIHUgU4liKlHfJnrb8gBzGDxFvOurW7afXshcYqEtFM4tWTprSGmq0UMcem5Aj6jxWlp2F2fqM13tnAh2IIZ1KxBui7bIjWgJAwz0i3brnGp2lRWTcKbxap+pkFmG28kvyuK7jzjT4WsewxFLaFBULQ+R/0w5cqVoH4jTjtqYsUzAGUTYzLc2hEEJyNgHankZ2vuT2DaK6uc8AldIoXyWjc6cBzNGGVjFWyp91uAQyS35vkgSuWxJpk1iKUEXy7+9CDtf9lIjrMSoBtKvmzH15Ll0aWDrb1EAfWB5CxnOt3A+1XPgjQInqqCdJcTMqlkXj8DvLXOmCJ35HzeJf3q6gfgbAIEvB3H16t5tPBziQsII54oEU7JtPy0UeuIZlnIgtaUc3lYdbVOY69dFjbLcY6LA5E9F1Jt5YU2ubp9vjtKjyY6ebgbg20XOBM4nrC6lHR2lnbTjvlt9bgPZjDPWd6viR3lqlKWOQi/tqS+AbcE7QQP/qInvi8Vl9CteaGChWeE0WW2s6fvFFTw54zmwz1bkBmDtorBSYSLnAUJp8xttwnuUx3Sf5d1wiREMoZ49O23/jYwdQDUzpeSKf6t8sXnJRf8uDmZ5j8cvoBB8FbMmkclS9DY9z+H/jYvwgKQG2ZoZqwCKyx8Pkwvs+JfAGjInlyDB2H6S68d/ZTMZZlQqwG1PBhvDwFyQEf3ZTKUigLMdmHjCBbtQLpIp2KjaJbRgRXRAa9POZWSTnSR9eFFa+tgIEWbgvWY4N5ehifBa23PZLpFo65XcfcbJZgycgdGjvYUd+wGnk3pYSrPjmxby7xI/gnPbKhbBML9wPsQ/wJub7/AqsA925fwmNXDPjPJTjSZh1SkXtVWjpKBKzlgzdgrjL9WZO5UsmgeX0X3mQmIFBhPEGmpHmUl21yKMKqNO4zj+Jc4ElF8U/wLBa6TRLgZRlN9Tc4YqpWialS5alnWAfhSMSNiF52IDKCzHE/HSWdt7X6Vmpe/nmCdFSJii8+20onVoPOEHfgGBwjQFrQrx0mcd3MmTLgMSStemLPj5g1g4u6FOBEwptj82SUYhnqWPREP8RBILDjwVhkcIbylioCP9oNpv2rY1jxARpzPawd404vP8zNhndwFd0pDSQvj9axGqDlKsI0WW90i5qRmAxJqy/HUrE5toAw6gPUfGWO12b65JPIlljFIEhoMxorgnVZhNWSb1IjggG/wceGjxqupNJOfhNq0M0zalAhQ4wL/y4QZB1bKdaOXqHDWdZYJ2QMk5GtxKoa/nMRwcJLDigjg5x74oWwzSqTAsq65CEiqCtMKTG6iIe+v8RLVyCTdeG7bZzYOTl7W5hOolXHLi2RapqyyWCQEe+6HYiw0i7kLUw4b/4H6g9BaHgq/kCIfqHLevbGWcnNvRdnuELG4Z6X/qUcBeVQG42dzRmqC731Pc6UpLWHwHpUBN99Klz0WD4yq1WGBtjW/Q9qc9Ah+gpodHT4oWIoiowFN5ejux1oVE+EEQF0w6cDC18l4AAAEoYAAAcVZrhRAAtZ0zWhyRqJWIkcrmmPUDda59jpbGKPRarbB/1PIYZjogfDoTqm8vNO/lhbjeEpbHd527D9vpgjij+y2OZiNRSYMXqfveMqzS75v5WBrqCvQNOGG9+LNyukk9G6IvjknFt9GCoND9dcGDejBzolkm/aDINPVYB1xKkJ/JbK6RIFhDKTASa6GiSw7VUVqsvy+B5ph/vmyA6K1x1ZDfr+1V5encDBOVA+LE/6YNXLUhLul5MPHYgxR9pBZs4zMCTzPNSfSY6DsiaOdHdBKwldLwUGoEuviwIv9jroMHqunDlyuv19aHMHFafycMJZSQsMPa1Sv6gm1+kAEba2YIomLvawbabfeljxJ5TWzYxTUIJTnAvz6BXlExMsg0/7NB+1+vB97kQ23Jdh4NqJ6faaXhZn+KEIAvew3oa4HKXT4j/QNmgE3T3xjERnizw5q95ihPqGML0MIDVutbsbhNQKPh3cI3J+b1w10FqDq/M8ilIzmpO7eeoXza75aU2q3l+yFVrXuKGJDxiTuXNzinJEHEu7XZPYWilGEGNZfJ2ZvUPXkZl7AyDGLDLFx94ItoB++6jZA5b8pQnbItd8FwXVWIx7iJkciLF+cO4llqkmmm8hMhh8bqCT4nTaVkzWNhUN7vQBKWrHOptDRP1SewHJCBA/xbp+kUvcQELl2hy1uFQ7+WWx3SwzUsMOM/pUwMYB906yYxc0HZQT5+zQocaQfGQzkS1Lami8KpRieyPLGCId9KpPJ8rTWYTIHN3SMWELa9LIgJ9zvvjoTvFuR54/yMZ3LAgSJwyQcyIKHi61jfLm5Sx3+AUAtwzJd6ZOP3ELte4pmFj/owqakkgSAXgL09dTmauR7Z6lKK7Hf0rF+op3IGuXmAq5eRiPSJ5HZWrCPjfYkxxZ7O91E9549PtWJ9EMr/QwYsa1KJ1KYspL94iRB2/plX1FZoq5e+hGbWpXuey4n7IFQk0QaLkujwNvqpOps5aedlRIZqWzNxhXgaxQXwtjJlLeH+2z7AvVPT0f1y2Exk+xcRgmECEB79KRYrcDbVZQHTrrVkLkLdpt3kLwwB+ZvFtlP2+GUDcZTYrwL0+wlf7TBnefMrzXZc8OZQYYHXkqFXgXjgKOUixN9oPLzstqFv5R31MrbQXgyVMSRvoN4rmizhSyedIYsGZwdXZXsir2Sg1fNodVr/nRoNaaKp4/8ao4iUiV2N6nEsne+Fc++QlR53VpfiD0BBXwmBW1Mtz6gKjAysZYHsr8DkLpLtkrhAHMf7QBjbj3U7hRiljb+m83pD31vIEsNQNQNvOKLSJDg7d3SC3tlm+5MZw2htedZ3+o3DXgO3K+NJFk9iPP/YfZgnEc7fG5pF1wC9BASNWG2urgIhjeNsfWXG4+owGYzoWv5kB3VjqYv7iE9XQX/ObVyAxJ+S32bDw9nxhXVoPU3vRWi/ez+PVFGSM0T60MnxZy9QkZI303kQeBikNxmKnweT+6g8s6Rvny131UizgKJ7Q0Um7xE0O5Kri3WPXrvR3EudazIICgKCMzpPNkcDFSmTSuy0S5fFalKM+i4R8yAvz7U7ymnEy0JPRHe5hOp5ktxFiMfBKR870pPN3JPEygJi7yp8NfIVLbnj5ZBnPsdmyYXfRevnkwk5TZQmExQ+lHFPF+n+ZXrEMam3rNFGFEC1BO8ZZiItpMzgkOS53l/nsMsZHQHiixY5fZgAAAjRdAS1w3Cmuiq+DXKntwwswg5OoHlQO97jrwvy4LjH/9LnUMP7O1LJzEcl13gEPZn+oTo291ekm1egL/VzOyAunLMTt+7yR5jFxBtQhcemPobWat6NiIeMMAvOiAVuDvA+GUzLMV1nCEZuj/sLac+Z92NTWXEfBB6ZZQ5aFxKXAW7B/x6DOQXkT4W/hbivF+Y0MbMfM9tT7snmnkuYmKM8A6RvZJf8NleOH3RRcwDq7EpOB7K+Ts5SfSj2FjS73NvzAngXmpa7BrOWIC1Snwlv2DI78dJ91ObiWhZMH1WDoe+0BUXAHhxqgCYxL6pqjU6qVHXW0GbvErhjjS5XDUm68QX6R+I0NBSp5Kvh2Tfa479LaEZ1JoqiCkKJyr3T0fPU2sCVJxbA3qYLzZiLnDO6QAQsZ19mlVUW4GK1TRvIDdy2DMS6f6MvRrdxGdvjUHhY4ObAfhI8Gy0wJ0Zsdtm7U43/EwTecvxQ/dnBdOjtJFE21uiAslBsJp8wLP00u/3y99rosD9FgZq9qxkT8eLWIQMyVCBd2NEnuuhKDq55R8bsU3FymDZ/kb2qi9OHGwWVDfUqQ6Z+EG2/LIkIC2QQpb/9WFMbDmZ99D2TS7/OE4MkYAZHPt3wqehtAYSfqOSlk2+FNBECQxOGVutm1iJ7AMBLHyMkj1H3b6uqctLhq09jH/qf6TMb/l9mQr+X0/9z29Gwq987Q8TCNAtx2w0ne6Y0z3k8BsYn0gU8Hhwy6p5V5bX7KEwFLH4m7Cw/39lmPW3f7fEgRO9TiQSqKDzqMkxN66l8jALBRfmeq41tOb4ntWxVhSvQzC+tz6rEBPdMSM24SeSpmqH5f04i80hd2PB+MYlRvwpo/9311HNd5MOpIUvYsw+zNAKClifygKn1dLJjkPOcMoz2dEWoE6DdGDo38jaGyq5HoNAClJhDjbfO7CNae7yykg0x2LS/sXxhTOoWy9GSv/b7NUmqkvhU0IsDbBYDN6Hgi+lkUq6o3/2gphY5NIgoVJrACzEThFOCmN121sdcfSXJkxDeTlZZedKsiwmYBlr4DoD88w/oGC4e2sGA1FrJML8TfoWTWtcUmQgWgr8uHXe5YuDyp+iLN/C57e7z5cZUHTfSRC5YuLeJZYs0X+n0exe+PFfkxynSg46G62WXu9ruOtJ6xM7Vt3t0X9UPbHofRYnqj+afQ7X91wTnPpMUqQRJCt5Ec7UqTzxtFnWR7EM5OTwymQFQWr4VOlzSJHq80a8QLEyN5NL1xBH5wH+fVnUP50nfSSUeNXTGWz+SFX9fHcmaRB4JwNwTpgacuJ5kgzrnT+54HZsoSYlYqBiTwezBSkFJBoSyNh/4DIhANvzvhRc7ebGQnW35damua/SkkxsLtfB9QaDTrK7xwC67qQRnzM7C8xLN87MOK8Zs++TSR139ea640gNE2dA9yQqPl7Rxuc8wTFdUA9Ui+IqEAmfNCCWSQF4GbJEOZuJKSjsdagN4sHkFEu1+PyYmInLPGQfNqs6ArG7biPWKi3pC7892rNAPk2XviCiaJHbzjVtlhCogIDMqmu8rO5EntFj3K2+egZBtoVCTP536yUEruHrk08V+J+TUKlFab77MqBWGhiyGxw4Z2tNHSeK4uPcZE2Bkp4K6wAAAM6ECmmsAAPXVKJWYHbZRbVG1xcKj9UT9Om56Tu1sE8ooyZG0sn6F9ByeTMmuw7hrCMvpeyIsH6PyF08CyfDEq8a4kGh8Qk7j4e1LLvBmAFBlWaoejKLCqKJwXWFdRIjaOouZpX5YV/LfvwV7WFghwcBh5LE1vokZNEo+1P0jF5zKbHwvMkro8j4g7lnqcJO8elxpm4vhbfHY/jKsC8j50d6HdWnGJXF1pyem+9s+O0KLCU3DmE/bQbKtuAjYpgtUyKyKbEgiZj1q82LUTFnt2Mop/03wvr8fDwjff4CPqrUfSolQDzuXL9I54OIZeY70HQAK1OSOTvxkIAAItvPGFAOm7noqRstponVj4qnRjbQ3gMckp9mKvh8ZwpiGTMuhK4S/JHHU+zYwfIlAQYByjMn4V63JyhwgW0QCRg426FtanaOza+jkwnmSw1Irif0w55Bb2tH7A9w4qx6tw8kBdzaBHq4+v6Gy6FgOapS+ICrOYLHLW4Q93qJKq5q5htZvePSoUvh1as7JgUu7q5PqOfQ4JyZDScUeN15ZBXJrCWOUuot0S4BftuK3l0rSEP5+CxMVoZIrmI6jJebmCY+Tc0Weu/eb6+tyEBNbk/IyfLMG2NdDltYx+uN/ybO8JVn3updHfOqLFLi433BKQOcHcc45Gt6nG0Mj7wUfxUIfdnKwV8xGcORy5jTIT/Oo4on+NBVmsuES3Uf/MFss3GSXvPFMnPFv6rS8nqnbtqJL2zH4bNwrDf0vM0I9phHdIU5WTyKeJnahtMqIe6hCGRhkHGersEP45qWDtvEuxj+GuXKiSneI56SaheOqbR35wv/AYqZF35kyzw26AwGQcDk7VBRMgVjbnWvSXqOeE+LXAMsfhVM0uPe2bdjVCsxqLP+pOl2yqXsbhRd3/ZfE//W4kEpaGOHS16N0o1VsZ2+ExcUF4nHEtCn55Pgcc+yK+H1eUzEA2xxh6kp+E5SRlRrV57/TbattRqXr89gy08nKrnZGrZRwIV6/xdxKEUY7B/LgdHS5vo4oSzHPwTUnnHY2Sby7vKShZwiJlbLtJ+WuaJfK3d8auwg1CSYj1MI7DZG1ewji1R0w1ZGvNY7nsVYasroKZA8uhVhMYx+GlRDm2C2KfuvmmCBv0RNL2qLcs9tnwzkcpogmBPLzS+FquOvnKKsOvQD1/kSq6THKAJya9A8bXcCm3cB8oF91hLPDlIC5HGKPMdNw9R4fvYRjHfZWbstL/WylZ5Jl9bIWcMDvbkAAsHNz5+Ukx0MwM7IfviiOEYina47q7VI6QHv6XIi5TXLmLbasZuhYL8Gs8qypvIyp5Sj6ls5ahqCRn6I7UswEkw3G6N2DNOgmktZehwNZo9UXp4fUMwEJcs6097n6etQCa55tph1VKSVbrgpGzYk6XVQTaEaws081bFnQa7fh3TF8JbZv3QRsnrofeCeuvp6jPMYTm+y5+O6SspwnqFC2D2+PUNuxU1cBalomMRvDahvfXoS9or5kAsCCt5sfZET00ukat8KB2rqKKDtHRaB1O3890wXzJYX4dkF1V8UZOF7mdM3NWZH9CkRJLXULyAuy5Q0bo8dA/g+3b2yCmQhSy8fk/AANi6gydwAkZerm2mxu8+TeaN/0ggkfZKirmDEO3YA4GaTOB3MvPVbTuvfIcTMuHx0rpI2sXQcra8nWmo3Dn/DXHy8CZYd3UCRxzh75azXurTh36ZsyuClyRdlCrwosbDJd+TMCO2bqhTcrIOD8V4TNP+acbAYsqy/73JaPVwVoh0wvRNP3fq0lfaLi+OyjVUYCyaWsFrSHiRBCTHMJmA3tEnKddrjZFf1TA4OvfI2UzdvbbbQq4E2dMbGnMPDRNpclJdYfmOmyTC5beXFbe04toDRZPOQcrEnt3z+QUf/IaWaBTuNT902ZNhe7+BjsNe/r/8dvbq4hQaEQRFxRr69meH1IO8/X8h4J4ht3VtfLGbdRs6VF7lwKbI9leN0zPszX8kqfIEZTkk8+dbmtLh4ldYgKOyaSDVFUWp+Uxzat4Y08fpusVzTsvdILqpdmiQ8yEMXAmMNY8sAOEqqb8x2x9JYw03PGbKT2RtNlBtWkJcQLY224D+70HO7uwIGqXCruC3lzVr0qloeTx5JZZbkT4rQUU9cjFlh0qyCB7GioTUOV98VXRtID1lVNsDCArjDn5gbBTJKoNGHvVRO1YrhEm29aqM16+o0lxVw/KG+DNI7ZceTIvvGYjD4n38U80Gc4ywme/XS7VJ3ZtawuzmlCVSHJJ6ZesbETMo+g2AAp84Z3kwJZBqJuyfdhMPspdODvqa3yvRqwtGbsE8882D+F7vK01ZvcDBHFO8GR72UEj6m2ggfWbRI3BMyb4KWBKxOb1a2i4uv6YF6eazQeF8iYDZzZLb+Un1KEWP90sdJLn1NblCa7Ho/LIrqE4oJZOmk3wr/HJY4uh8tol4cwJQ0VavqA6qCjh/8q/kvPOKl1ImiT4ienYHvtdSL0ScJg0T/55o+axgK4FJYMatcXtLoaLXH6ewjzGw4t/VtygzKlQXWWNqXLf+lvTcifOCVCnltAA5Tj8G91bpMkl0OK/ylxpjANyu0zoNiVoNZE+jtv6IEj4KHS0PKPUFekgtlaVkW302wjUkd1cqTiZiPOpmG4bUG+p3Z+8K9aLnZITjSpR/V4R9iBVcCiFgbxYbD8NygDGG4wuaqqOFu856K4BFAsWVZ3QT4mJ4RohyuAthpZzFT4XZSGlLAkIXeTPyIlpGt19KFGioakOVSozBuGzLjO/j6MxsdB80AYChjFxHyR0Z284hfTRovCe463kK+6GFwMyliO7GemoCLlUCagD7nJTX6ZEdUFQcq3Jo6WmxeWErVJANuvyr0XiQLQVTJt8NKk9zykja7rT2xdeROfKPVvodzvAjKjMZKaoULTOzNxTi8qrdnMF00qiRRfYNfZM0aKdSoItlr60s0XiqO47LUrEeUsVhmC22iPy7qwFEK89wpVPPrLBzTnLbKq/x2Vh58JkJZpKMovoCa55c1aPBU4pFXK2DXKhSxtwLMED1q+a35Mtdn3ob8Bf81jwQTMBzLHX8YsdFtmJladYIYzXc+M2wQX0JWk+EgiYWZSt3DqWyOGDH21h95P7IMLrQ8B9ycguc1uvsGE037VivLsuz7cW0+sEbaovevPKFqUgpgzfGqO+VMPGhAFv1tICzkSAsHiwABSrBcNR6MsCv8zfmvz+85DbML7ATxt38rh858YlTkU2c5ktaN9qfcuf++zVRwsS2Kdp77rVsBygRs/xWyEDyw9PMBF+tIeGoivwarrOONpThfz7qbRqp6Pgia2uedPEWbeRwYVvtC57zlT9tUGDgOJmol8MH+3NBaOwVG+0UNbZUx8u0D9zXOsGqzbKXfSv5bNB9WNN958GHJaAhK8cDs6Wwq32B9fJqinA3KSV57rY8j5XVtYSm6WCGwB2nIosfYyX9bboSxchdcsQpaQujL3ndDlVLtfEOTnmpBVHu232IBsawy9w0PcgZiCN2al5DO3MZGLgJsQb5bat3QN8oIZdE27h9y/7MKSZirhtnOdLP8XWH3cuFSPbnn0haJ/p3U0mdwTRC5FZhoHyB/zk86tjRSKyOz3fx5eeLAfMqdB0dkqjCzQ16oBkk6Lb3FNICuPxAbWq8i3nLKplqWqhSi2jjj6WN7wsBbqSyqpZ0bpl/wVi4dMp2ytB5w2x6lGjLnCgj4U4dO9AxxHiyuXTOW0FhRvNHbU9QlTnAyJWf3lKct9FpnCWmNoMIsPu2g2ZZC9N+QpsRCU9WULIyz04AkfnFzDdQ+T6W6vYR8vB1/Hg8HKJd8EDyZ1hp+idC+pisdsSw3ROBusWHM742OVTmwiWC6mYpkSnex2XIWX8jXM730uerN1mIGmEEO1UmmzQyGdrkbAEG+TW28Ply6t0O3mBhMjfa3WHYu87zJYxq7/K6ws+Fj0mR0+Rp1m4H0RmR3tW28iRo+8N8jqNb8BBPNrPd42HpqlPYc9wcVlYNp+/PRBp0QAjt6K1Y1kJ+me7qQfhBztXDDrqfMl6fZKQtg6/6VWCAAvLnnLFLczo6lX5v8xQ7XV0BN0jnbIK8gFcW5FWwHbqbEyh4FbhH6STZZR3v1gjAyRK1+4BykxQOvYgX4wZXCZq2/kngP340vghl6wrmaMyX+S7JdUYL29u/a8/mdrVTVurzQdl8FMU0S8UotsLdcfrxyg/WmaR0Slo0J9C743fq1xZA83VBx5kfeQZIkEre7CHXcItIXx+jsVsCJvjo9upg28Nv3GoQXnopgxof74mZTafj7u7Z842eQQhNPEgj7nX/abXfZ57LUWWrjFVi4FUDv6PEvqBnfXOuYK3wwQulQU3XZZlq782/T4k2qPvqmfbiMdp2Wiy/7+8syxfkzYkUtfc/YU+N+T9qC/SBLc8BcPb32ZNIXv1wi1B22Bp62MKcGvCFAG9Dbhk45MGWIql1X93DyK+HkjnBUgUJ6ite9Ge82gJMocygOtOQrdPZHRM8vh8DKahgII7J+0MkBr1bhRAVAfbsra7PZeUNjMWPBYbAFPp9Lz+7PcGZ94FEpLtuPADKMsafv7g9oSV+e2eXGWqcfjBQxyMFADR0lOOCWq92gBsdd3SGeYECGSxXvFJF90gpntxw1Xh+C1oy32vWAu2hCn8+0Fl+shxbTRz/2QjAWVOLo4hPE9Snv+ThU35dDairRCVHvyEr6yXr9ljZFcNgNDY6Ck/2SmAKWZbfokV7fW1Mb7+bGwW77yW7cNsAmUEzSwf8CCchH/sArZG+8/bb/DjZx+T/fU2ViMXXjlw5Pppf/WlwCJ/Ymcy9BNnE4Yn0SxZDbFpSlHIlbyGB8V/N9OBbhmcR8t/FYly7QPaAHgDDvLyTCfTrhgaBrDmG31JEjrFa+pWAduYLRHLdFh33SZgndnhwc73ZswXLs4raR3AzmP90W3ahCHv5E/N0W+Gu2afLjLbx4+XnhS9OpbTcTEleSkf53UYExdzKOeQolAUDoHiM3wKLPssvXm9kxRSwmuZm8M7QAhDMM3/kEYAD8JWvFUUp9evF1uMZlmPxBcqvIgL7nXLOfT2k2jEiAneJm++iL3PHLQrr2Tw6QHDG92pjGPCAK3apd9K4a/2b76A3hWFNauza0XOPVpG0T5eaCYaAA8tjCcUYsc+EIiVujvkXyEeAf8ISg8IaURsWFJSWn2brXmcYzmU64LAAhrgVsuATDZs0sMncodpEDI2ahAYK8fDlbS8Evp4AZxVWkvSWeDZjqaDD5M7Z0grGo0mWCj93kL93rj1ZZ4ssaMarAFPiJ+5FwfeyLWPD5OKKs8dWcst+IW9JLYLLhQnnMYLk/OnaU5Gv10gNY1c8hVASyt0UnBnEnSgntZMEZpdUBbjskPIqDGc7CR+prpoGOnWjeytX8MHITbNxZ7PzYN4kftRCu3MyBo2E6Jv3BWF058nvThZVj7r4IWdd4COltbqYUPq+o7AhBIwy8lQNuRp+d4+cD07WK/X3y8knSEEtO2QPHaDT0ipZKnh1B7kDmSHsApv2MhTOGfrOlqLzHdCg1hqS64Gf4RrvnHAKuv2STB02qOFh/VwPUEU5q83oYNbbAuqNrBFik8JMbDqiXchlXHV0XR6lzH4oS2EqMd+6KfFATGiviTq8xMmWTko7IPUvUCsr5F00iZPfA8zx+VY2g+gnbXxIY1G0LwgvfmRXnjhNbVWU4wG2I1u35zD4et9gy4suBkm0yjDOOOffoM2jcHGM+E8wwVdZQeRsQPo423mN/G6TpT5SlpRXBmGM5x2KdY87u59BvmGhdxzS8yS2LGYI7/otskJW4xEITMLGvnFvtLl/Ho8vNdl/MuCraz0N3BT9tB+k3snXTWysyMPDoCpEE89480ebxt/sogUMinnhFV0xZ3YY9mUR3+aMZHMOnhG1heFy8CRFN0RzXju+hSFlQTGQoq3I8Kn5dpvkMPMmOIFGgS5uyOBeakwMYtBKZNy6AvVLdB6bdbn9Ty/L07W9ypxxCEAzsZxUYS2mmNUmk0UfusSpNljFq5wtL0yvusbK2PaI6u3/okW3WiJArK9F8RsVkd8pkx7huKNvtBFdXDyCc6JdKwQ/ySrTIW7IFLUjL1MyxoD8MsZtWj5mpzvw6X9jt7S4WMeS8aABUk5xQ1Mtwhlf8F/3E/ciRQYnEpymQneSulfy06dvexUdeMg9x/0ZQ/qpP+vnuLTwcpv8GOkxSuvzxX+FCtsYcgOprAWTFLy46E1meAAGzHwkXnr70s6qjlNZIQ46U04KrT2Gi75mnTXcW/jOH/t7oXolKuqv+lJM37/yV3yxOx4lTqqGdF6R/QjIgP4fAjve5typhwzASvMjAVh54tgHFaW6i+QSxrfc1Yh41FLS7/Cbr7QzOf3HF8qk0wV/U70E4k8j0A9owJsnWKk59b1g5JFizbWYUlElmTIRHwZoM6WLQr44aTPEeRzrWN8d5XN80jA/n6/8nt5ctDM+X5lyEqZag+iZcz/O1lSR7YBZmp0U/eaVamz34Qf8/Zl2EnfqWsiwf/NHadlmP98ZlsmGBACR7gnxe2HMP4jUvo9RAxYfYIsYP/1O6Oa4QINzsWiSA7OkcUttECMFMomqfP4wzlymwxEDXBuvvKiF0ieA4ZGiYMBVt5jiHYagwRKsDCjQZIjh0O+I2rPychIJ+CvaQfRPqgOYblafsWyCOFDiVePmYmytcLfqkxRauOLsm6t3nyEYkeOr3TNPZ+meha/+oTXq7/EVYtz7DYkEAk/fuHqonH3vg1if/pBZcbZ+aB3IE5FrP/mDgemfIpjYM63ofODpPRFWJr8nauPJvG4y9AkDueulSwmDaE2w08ZE9XMaM3Bs9QJMWQdR89ODEGj3ipiAwZKyB7ysABNe8I7Lzde0g3Inb2cPSPkGyR3sC7orfX63KLiAc1OOexFx5X+84lbvkjnYwvjHZ5maqgxw5LYXlPmWR3nBgCmDiXYnEW0n63zkSxVdkpwUj76Jpx7x1hAdZZlOdRMZGhNuroQs/agejCVYXrU7aPb6VFeHEqifUJXU51CCbDtMkuttJuHpi0Nru2iJcYD9gptUIcuUyOQkgqMzEoPswBmGWp3FhI0nvb62I1TX0FmVthHN6KPnxZ5LTs1J1GoCB7bIzoD+r9nqdinbeLhMF1eD9BKAbboRAuyThI8MHS5E8+/RwfzaRL4ajedvSpuAYxugleoSsNXy/c2xNQK9Hfie2q1b6viWOVCRHCARCmWGn15uCrnUJIfRxppj8HOBH555lY2MUShRaJpbv3IZItRjPmi58nDK8acPw/B5uus6AhXhXI+WmaZXRlLIPLefiPm0mXMvAje6aUsZY3xSi3JcEeZLMV8RHhsMUMntEJEFPiHW/iHrxwDONBW94QUm4truMCl7iUktOZQaM5VQfcJvpdYj5aq6ihN+YvYSiviERgNNW4VlJWTzrFPiXg0LF0rIDpWhrp2ZgnmRVstbmpu4DgJjOXfztPFpzysk+k68tuPVI+FqHuz3396G+Q5aPWglpMfnFAleELhCly5TO1t/r4B+Flv9XfFO+hiimh2r45fr2qkQrKIX5uqDzRFyJzseEuNxQXmilRKO52L9iR8VOse1SIDPj6yXGTDjSbCyOEpSXU79AOWCZOZzn+RnittYEOAPUmw1yVrCgAma8rofzTBdIV9ptgfFVMbsgjda8fIAAAzmzZpSlmAJ8S4FA3/nOi2N653JIqnEU2PxNZjXboQCfTP+/mEETYa/wCHsoNL5V4zQ7Qa6icEov/vm0aOicNysazTWgrYbEZ4Qv5NFUHgqxTN3q0uVOMKNIkqmY0GqVGQyI+DbdE5kMJorFu337uGxfPg1NcMfQne7KMvTTq/KVRhRco1VsxOvZpgOn/iM41BTNDu8bQX21II+spvGQsVBiS5s3Pvl7+TfLKdmx6sQRKvzTsK0ELSJLZyfJIWeNRdRvLmCxAK5qWfw5LMSEEn4BY7m49TLrafo0cjMfifUONoSvHsztJyVwDEvRQWUkla5pAqq+yxpOyl8tlbp5G7qsJcI/d9drlUjHml7hz91xr4c7IiKQOoocPc++NWJZ7gJbsqUzlmUGkeMQUS2fWXFoT2xMstoe1fceuhqzRyxgpuIkBQk5HU9S6J1l+pcXl41ggSu1nrN5Xt/3u8D4ihnjfpPLDLzBVjVPdfBWJ71dDXJsbQg6MXqkOUxjBddq7hIqWIP0x6oZQhsfLY2i71+EBFdmopArkYTSHeqElP2ofKkV/ii4GhWkazoKKB3OL0zRNRIoGFr++shJA7o+6IIFqJWSH2WT+KyqpieMLCdXUIXILnOtndErawINKy5Jc0W64P49UxGICPPrZDdO5eXP+jjD3O3MH6+ZHs3CYE98cd1TpVaVFhKTA/Rc+j95aCd496dkwMe6x1F04AYg/j5sgVX+/L6TgDl8zJnv+XdTRuARSZTp/yoIq6Z1ZpoihbhqEGhYQ/yOmR9gduVLqlXzBBz0ZTd2Wqtd3p7NeQIatyaw/CUvp3hUYW+vm04erI1bTVDWDUcKGEU6s2UV8jxsSWxv4I6YFSjuH6SKNEoVEps0s+KCIOVbpCbblHbZJaZc3JBo00EgL1i3Z0AgyfumsypwnuA1xFVIzcZk5tzFb69sIa6VBb7HnQPPJa3qa37M01dvh+adSXFbelmBqk7ytYT7GH1Lx+neccPg2DXcV4rcs06lC5vJ1YeZMzxRyzX8fLSRmTJKaT9I5x7tUBMZqI8xdAI2hauSUMqf6C0dzUnr0reOIX2ngdrdW/AOZWTK/MBI8TymhcCnerkVAyhuVoAD4QqhOmtVsKniMLqtrbBUM1ChVRx1s08BSwje0C1VzbUeU26wVEVzlp7JkM/kLl6SkZqfIUQHmUdAlTLRQabov+AdJPQJ5Q7LxvOZc58GBIyoeZpnfB+yxf/k+Q1JX21pNTDPTKLLtew/GILT1IP0Ch/2FSP4oIXyABTVgc9xLf8sYt0sdHdAj4F48TZp0fIuxwPw5sK5Ea5aXISqRgUKlywxkzldnxVodYSWuwOKEgW1dOUwm5ormsPm1rMHyOpawIOTSFtB3/QtKt6FJxC4CVIfQnjdPeUoBht2jqhi5chqa16AePhM8uDY1yNz0OqQkjzAAE5ep5GlfViZPNboGnCiIkSDZLkiP8t7TUx7/yVkyX75MIdIDUE7kwyqSV9vDULC57F3/fcw+0BFdjb32HQ88XrZ0FmJl0DPwCnvSxx/PPo5hGX+LDgSF/bIPIWoZiyZz9eTTJdzQHq846HqYBJKCL3sVgO3rTmA4Q/tt6GENlHPEW27fyWrGmZZOoZWziDSaHH1PgnsyVskANOUPw1Y0ArahRsdpghko98JXxgwuRFhiTvXztDHSDCzuW5hFa/HjoJ2/HAqZO39dFy2he1zqXNxpNeQMaDVSSVG6NR3aVEosuErDnUuJf4+nKATjInNB4JSysxmv83N3I14Wpq2o79oAIkzoiuqKwWsxduHD/1RLU1Aqaq+MgLq7DUxOP8c8xua3OZfmojeRsA3I8BjuK4M4Ae1yfhUOeVI3OzHDUGQ6ewjmss21KB74VglD0t7Uj+FDTVLZvRIvzwsUstm18wfDWooyqqvH8pbKFLqzKZOrI+zQrF0njT1ssLHW0IMQ1KkqlddnLXjBaSTaQy82a0xOaHinhvU1eLmHRRUQwsU7HrRy4OnPep4O/xeauRz4MDMmQg75ixf2IImg+/YC24nj5dJ5cfwZ2Eysx0d3n6BwfpEuQLFStcnXWs5XiM1WIy5w+Qbcm7nDGkf4Etl0+Ewi8I4PfHks+dSVcenXudF1M7y67F+0/YBRYCcZFKQyv1N7Bku6xHDP6uqv5nNyEm0ukVVTy8y+YLpZQ5wvShapz5oxBg2luT5lWw8oeZgbswzj40j4ISUeOsPwSzWsr6F7T7JyQKVQ/2XCT4oCrXkIt4EBO22D9f3YgOLxIY4oPxtBQZgosbuCn6/QSxs6llxuV7L8fsavLxZDhz/YMXqhh6pJVaN5SC0jrXcgrHk94fdNcXNV6kql69GcjCVdE0jqIGcaVGsD55qOLPu8QgbgsV6IbqvvVezLzCH+0CR344O3Q9ADij2qEKIGZDy+qP+DkNqSuYOM5sOA8whyyaGw9g7HfvNbaYPzNw267gNpBaAHIs79Bvx+G5ESKS64qNBWtMPVf1UzBZH/zmrS5lfXNIEIE7nI+ELho4NlYgyaY1uKd9VQ8e2jUHLx3L/FYe6AQKebW7EPgm8sNOfxi9w3m/FF3oIwZYylHzsUEmz/pcdV0mnFfPs2cBFqDaCuBPrSdlM1boB9DSA8316J7bAR11MvG+1ERsHG9+fSFW6ezG+dDzRPPEyBqOy2U+iMJwEdj4LelTwFTvvGSlerLL3+omF6uWxdCqgA/HL+3nuFONgx7h8tMm7+Kb8zry3HOmZPArzycy/9xssoi2oOb14NYyYsvgCslAF6SgaLaAHvheHpfCIQYZwx9BEUYO+CJY/Sor1W1FOwPJgLk9DxoL+vYkbBEF+VF4ZOB5Ecd5ev6TymtXD2fWOLNSRFtk5wbSqhQJbL82UDbfNyBTZtk8ev//lzLC6WCRgyM+/GJ3RDoMAcooR5qzQDC0/ZMQ0d37ZtPxKkjUN9w2xUVyvaYYMeyPLiLqrJKq8z6VkVDeG0sydoFG1Wx/xuowNtJjGLrrhelRjnG6oiOqCwzJ3OvLBglH7Q+KIKZRJRzByvIvsgLUxDbs5mqVK4x6rdRIpPMPm77NwbcHS3HPrdUTOpvZt2Q7BHDyoyqaflj3VjLWb3/LQJUpYyX6WDq2ZwMNs6AdkWqgWZR/9ZFUWFdkBc2WiV8pXrfCZdOyOZHs4HGQdDsGbwBEw6xBLRzlIaTdv3Upc1UFN/pFqrKoKWRmY4/Mw1uKQfE9eIhDOl3GQU96bgAp7obI5mmpSI6k+TlkZY8b/XVStxFS64EixIm5QthRCK/wqRrqD8UuKNRRLnL/P4sa15n/SnPe9esC10n1usGFqwaYuWW202T9q1vD38uGpLYVI7pPV4C5tGqc1twVQtAhkEjD0fDPOCgHxAeCU/BvEyJOBYNzJMp7i7f9qGmHS5YcAQERDFojksWxbjPHaaGcTO1B0oB4jkji9uapswSY+NpPiX1sTJkUL2x+MAFup2FBpbOozbG0BznhpBS00zFOI0Xl8+usWVk2l1ZVcDQVH4rzEJkczZaTsiMU3f4qiw9qLB5bi2iGxfbZ6D9pURaQjnX44IGcRdFZlNe/PhmdSuOLCDnwI8P90YDc2jK6Xl/qjONxUGtGqZ53RlbN5KQVhj94RKAH0k55PmvSdipMovSHfzdTFUV5k1FXtEW3fm8slJoIO6VG0iRwziF/KRVTrHvqrO2mcgWRivAfcmvW7P8TPl4Yklmp9rbmIteCaqKX2mLLIYpGovxUTF2crc15XG1NywBs3hrloj3EZGaK3UC5s2O5jM+1uX2BwuprsXh3ly5jkMgycMhYr0AruZCA+grRrzfKdZ5l8dmE5qMzEZlxFa+BmW4ywG1+J4PdqpxjsLbWydPQxRCP4r02wlmvqMFiCZhfhUjybZN6TpKdrvulUXQKVbd1BBqCT3ge0VqEi0bkXwhTTn+Oq/H1WA+IpnVGu8cZSk5tfZ4moz93pkNkao0x4WMvvhm/LK5P0DEdWIk2ZrpDkbId5QiufVaQYeZwBtQ9gmV/Ays5/b5ow3bubAGdevcIX8RYbKIEvW65iVIwmOPbXzmmq9wHPOuPelrQFNfv5X3xx6w5LyGnGGdvq3mRSPJYAZYcG+8HInFX0loeIWD9RzlplsAjJMS/0w5n/h1hTo3DEPZNCe1pSUxKPw4M2605wHuUjkWmP8EZBotci4I6zV7z378tVLxeMy21GEH2yq2xNTjNNqo1/+fhZOYIzj8h6fBe60QXmJYF6D2VsD03N0QZVPES1p5F7Ihyls+CMgBHaYPFfouTWTE7Y7xpyS7yrJiMs35h3M/SPL7G802kRGyJOddxvYGfm78RjDtWjMvhwVHpmYhMfm167JuFsdveNowmlqXC623rBns7iaIBHW7VXJz3ohiy3gf6xpY+Oswu3ShBOh1hnxTuxyR5kUy9uvchU1tj2XNkmPHc44WlxKSuIqFbu/FiysDbDMBQXAWvGCu7shoECjGpH2UJR+pA9FMmlWs62St43OEGCV9TllaIYaBDaawuAzI2OQKOE0dVVzaiZniSqv8ufakJFIA5iSfarMePel8Ht+y4GMdK9BtxzONUhXAgPv0vWB7ioooDs4qAS53qd2mywMpIhlP/jWUFu3PyQsN2yLff+3Y+HKS6NIBVQVa+V0oEKc+ihX2BRYbLqUrU2yUfHuJxvEWtN9NuzZ8tSr7yXmiULDcgaOfZ/pRedhD7l1nFiHO6IpqiXS0VmdM14H9jEqh2nHwaTPl1h/NkEUjGk0Wo9vlDvFHq1ityz+uARo8q+qSMGegJKBFX9ZkpUPIYjqhvEpTdjX5lOiwpuy5ALWpKdmwHTzb5aTQ3uDpz0L7+YYGDsHNqaq0x2TTr3oLt9MgX9lPNMYf9QuvRJvw5X1asYPr7LZu4lUFMF0TGGA5LH/oZhKT7/SiFs1i42CvJQAlGIL3o/iv+GwpSDm+HEgS3gLMmSKOSe5S3yo3VOorNOXsJfkKC698pR+JhPeBijOkUa+buVzoLJtRAiOVM4UapzhPsK1Kh3Gj/8/w3gGYfWcO/QVLCejcWPre86NmC5L+sRsDVuCdGowR+ykuXZBCSqhiXLBcULYcEQZxs9Y42jxJeGYYW5o4ccHIoAEdKvowwvComLlI05kRvBsImA4FfNDQFFjyzNTuVQDIJD1IgNNXDf9VgSzVKzoG/LJEm7R5gI5gvYblPFJaes3X1kT3l7pQeLFw6aNh7Zd1lcGfeKubUAmPR081Zzcn5ikluhsKHOT0SyMkARiwdm5pCi0Le8yBPfl4oGHAAaaQHbdGRWQ5VqIjv4CTInCsD/gAFgyx2zFSFQBOMf4kGpX4SydAI0f5b3QAof8rc89ObqTmwypa10drdbgyZCddNXOCjTmCbKoHN7Z2UyDHoNlzb7OW6aNnX+eoP2ZtiNHxe3Xl6LntLomlVL9zfgV2uDbZtfVwbRLWvEJZnHD045fjfVz2+9K9/vBYGpWKdMR3zpea/SFuKg+7IcZycPRKi4NUn0X5h1N8A/sOiKNviJjvaSWTipEU19J+glo3aEvXOFw6AhBBU65Vh9+u2OszdRFXBQVE5LVZnpgipo4khOU6QtKer/OEP2LZrzVTZ2us50c4+XK/Vg5HU8KHPCwob/CKWTo9SuAiXyqw/BR40cZe6c3HBmIJO++yI0tDK53EuRu2V6CSY4sr9GyPhyPcH0JZio9r4OC5kFDlEecAhtnp0az7YhCSxsEPeb1OMG4+Wu3FrlB9vDXg8gsq1IgfreSbzgPaRSKF6DsdVznVhQX+Ebftgfm49XVBIMC2hWcTXNs2vEAXRP8O4grs8QqPB4dTz/H/1apyK4orqYNHByrm+6P0xtvBOb6VLJWm20fcY+Mla3NSaFFc6Z1o4vsl88+q/mgDiwjVsHCGQj/0T9A2W0V3WLoBQUkJKxGTzkEjmpUPwcJDjwNh058H/dyxCxgqzPvQ8EZXTqa1X4cjD7YOxHqr3tA4dOv9m0QLyqK1KCjWXEp1m+NBcOHXMasS4DOl4PY2bdz0rdOMWscTc1rOVkR0TptqxZ8zZV2k42+0ftE5XwRsXDJhsKS3q+8FjQwH0/FwwjjJPADjclyOoXkWriyR1LrSdj7cdaP0FoTm8R6zZLHczUvUSu9JZGMtMaoIh+GbtYXyKJwN9jPOPDauZgqD0Q9njLWp28iVXPIqQkPO18TuuostSayV7m4fLARl785yBgqdteSg91DnTIrDOePGLKM9qul17k4yelH3+q8wdkwQ4vhXcoNTiF16l67Wets5DSm0waGe5w9XHEJhgDlxm76vWjm2Vz8eslxnr1IAi3yVSCQ1aX3MFEIVRZ+4vzq5rz6XYTnOSVK7G5XKGXX8KDCEteIXjTFZlD9APYX6qAdGItf++mcL82a8IxpOxFAPc4TJhjcRpledDx1BqYRqBkkE3uL0Yv4DCwbuPnzbtRteS55+XHSGt4DOizusA5SJJkn+dfvLFrfTlxxtdhgW7mmkjkgfILWNWU0AqOVJ/MubnBGXhyb9uBhFTJAMIZnuR2VIsLP8WT2snCdoYDVWyihqACB3JcaG4mlVYmdZ93yz+zGd6LkmJdj4T+kPM2QZ/96JXElBZQxrcqyiXTquPQcg7DVZVfH1XtmwhpLsJw16hZRFMVMRCXBd1NZ/BaxZqJ6FBD30KY0xWYirr4mQDEzP1K8HAxn5HKpesSrz2eIv3WKjE87+BcLFEVUmRlNy7WiV+gA2m/tljwnrxlyyVPXZIhbkb6O5u9IWC4D+OBR0l+dO3ri1oGt30k8bEY6vyrEce5tLmx/xhttvq4X+0J/OfUfgF2LjgPkWco1KUw289GCsY/biwULRElO+MOi5s+hf9wGV5cmUMfm192tc3d0S4iICEIC2ycyDZEonCA2XDfSBhihEZ/qPxNpTucpq9zmx97wcs0ckWwMKY0GXCw97hcPX5s8qz0Sonmrv217pxu5DnhUxw6Rvxzss0WziGMSSIfPVu1s0v2gfZk392NmnlnbcTr6s/wBZtcG2ZTam8RSkaJtc1vlW50cjl5JYPT6Ly2ZR4W3eAnLAUfnF1VnCSQQU6T+ewxEYPotJJrhtS4WPrG7fHI4mPNdPnVtCMIhL3/j9OvzNZjKUw/nkIL//oJ2V7R2b84c5H9MUKChY41N9/li37AXH63h4lbd3zeTD5jKsLujCHofjrspgetG9T1Hbn+4akD2yDSU3LkKX7L2EMldoY5SeVVNLo1NR952KEBjKfhhZl6ozZKh2kge0+0RAYgZ4R4TOH5yJ26NDYe0NAFe/naHsfet3LN1m1euF47+RA2QdxOyz/KehGhtnIUhiYM8Rk5h1K4EwttNeVclbO9RlXD6OM9rXXNqi3yUSbMKIIBikXNKnfovlB1wmaJHSW5bo95USoI1e5aNIbB2XlFfmtNz6apAreYEcCJPg4ZUByCVdEWQxbm7wW3liXUYcgzztj4+0vmX6ccBxqXKt9uUB0sGjWTq2wA4hvklLNKz9kLYN1PZE5gjYsFC+iO+3XhJIcuR43nijAzXTzxNC5jXyoqa5RAl0sgYQHfMf2bcf6SA4lCmHdFn4r6oey748YGxaW/ShcZxrer5JijkZ0N0L87V/ADBTWtCdYM7uYPJ5zGpQNC/fGujIvC0AJqH1xHIHQtxbBD2XB3B2HCmgb3YgStOAGSSqpMmh5xCpswCGEAklbtuIo/ODVv4Xvh1A0pm9pHWqawSmpByTSaqfPGf1Cl2jkR9YFEkKw1ZsyB6rUnRh2PpugFwTwKsppV5KxolxJy8Kx8ROzY9KPBYxuIyYHqjtmcc6MV30BWg/JFO9gbOqOy2euOMng3vz7TmezVKD8C3XPfWynyY6ou+KeuO6yyLEF2vPUxMXNOVgmx/st3wX8rAuQUfTUw8P57PTP4eF5nRU0ih1Cz6oJDMd0ZcePlmhSFGVwEaQ9bhLcP6JIdDBOh1/5kkKS526vsIdqqbx5AFRqdru1IQ31zetv6mtArIFSacIkW9Xn0t+58jhTG/bnfzvWJr12HLpDWKj2k7s6wC8aVjJ9x3jUoCHdXsCMc+FLOhMH85S+2CRc1fHlF4NAc3Dhhd8n2l56vGOkLG5cJ0g5ZIZghKegalQggYzEHN4EMtkhi1kXB+0AJmFAltml7Jf6MjrKSd4rYoxiCQs+Nb801y/3uayZYjyRzEr1GCOMFor5IQGB/zKUgIMRI6a132UYW7wlSWVkB0z/4MAejPK1r3GzHAMZdWckxYdmZepJ1SH9bk0pV5mmAxtVdSXUOGawOZ0ykfLbGfk0X2d4lrvqEQmX/2ICgSb82eAvvVJEBERk2hVrpZUBiRTkjxcvbcX+sZ6yCgXluBKepTZQpbX1sWFUsPyDqnZiJDbMbJJdnzK0toE6Zyx6wzV3ktqMp6DhFw/g/ZDn3YMzBeVcM9CtHbLr4pX6Hwlx7iY9dbIKt/djyCCWi3TAFOKZKJ+yYZtE4PxcShGzE+gghxdWXLt6T6879JV6I/+TNrZKg8SLYSQRCKuhihl6XMHoHfLes8mzcTtMvYLCwBtPUa9vHuXVIgP8hOiiGtdzTm3eYaPPnP4XoluD9+GcG6Z1zb0ARtp0lrfhSt96NtQdijtdWjiJyTyPt5EGGOwQbE+JuoDdYg6YtgiU6eQWAS3oVfAoWAdK4b1vJhwB96hrofmUwDPvQXD8MwRW5KYE/hHb7KIZI83F6cv/Z5T+O/Jcr2CDBwpZhYVaGmwhomzhmOgDqcuKtqGieQiY3Cupd1ww/ciZygRXqs8cpxtGj16KAdEQFCkJ5TbvqR5CrKydIGb8Tm1wJf/QRnYUA/FUuMyKhuh7b+0c5c8QwwwHsPFZLzhNR4fkOjd2ay6u1pSV/XYDpUgdiL0pZME2Ckr+BaVV6qGjm0MlbqcaKXfH9Y9+JmjpvBNmxAn2jYUBohXjx4MvQFboDhTimj7RzBtl2r8ZhebDWu9y50YLE+kw42SiMoONbm2RfJDf+HeL5kP2U1/+aO1mcdF5kYTuhPIhop8Guw8AXaI4qc1h32SYrXqdxb15vydn+e4QngbPUAMCFVyZZU2Qz8Qd2ykMS7op3xcLB7/2bigHyrkZ5bsg6SJi5tFliI5eTvwPkBKBVB3jM0VW9YKdaafcinNj3bn1zULc7i8j299AQLB0JYwcKEKSbdiuJFe77d3D3zGTCxpHBUDZdXPGSPLHHHqsK2b5Cu4rQA9OjIUrgoPKFl/1wyFLW8FBdfyc5I9xI79ELmIqU/77suAo1IAUpwlGkVRXvme93zdOW0cjCUHP1aoz8rwbqOUuOXp06hS/e9bpek0JOdbq9Nq9QnbsyHFbzae3SC89ivHpO2BydyhlVb9bW4iCXcxUaT98vYguHbN157Z8am1XlY+5YZeIH9sJ+cOGQO1qlyqFKZHZsOcl80Aq3iYIeF8eXVlMIRxdFGD/TfZi/KU0qKsoIgExtEqtxR3kWZFGGF2bJHu5MWOSLHG4coEZRFEaa7xR4+8gTYEwLGL2y0eE5vFZXRD5RipOJocBh4+g6p6AMDThOlhljxwahtnFMOSRmj0tOZbORj5HbOvMgsedUMmIvyqOZ/nOz0W9vcgp/V5G22KHISRowaCrGp2jG505jsFUZZC5QnWOVQ7DDBSiNM9b2PN47DdT4XacpwjWElvC5ZOO5BfxqZDGA3U360z0yGpQmAJOE8qjjKy8kPdkRXdAVO/AIn4q6VtYzsglH20n2RehwZukiLI5Dz5xmmpywG94WG8ZRbS1Ly0P/tOBhHy+V37gB6yvpEjNTDmOphmFJLjpufTaAIgB2I8lMRX16oEYWrC4qiwDX5EZIW0cF7+AABc9V8SlfyxxEyterBztz0++SMELmyyX7CooAvp7TfeAAXJ1UTLiPqUCvySr64/LEdZdnrT2yw3lePAfJj20akVRgWywHJTYH3r6ciSILjPa9xRnyaR30iLKi7FuvxQUDv/j/A8IKHzTRT0AjJ3hDRGU/LG3Qv9UhIW45iuCYWTesO4hZLKBDT8aV7PqkB43DkEOMR446cyMulgDd7dCGA2GZGa8Y0I1P87BSbStgJG7FPocbPbUJ5v/eBsJvvmCz8bA5nJ3ganV5NagvMQ0ABORI6nC+8SXZh/rl81gqqut584ZkC1/vKf2gk92dZ8ZKQB+JngTKn4jp3ETj8eqC28bZkzfRhwPqAKd0EvHuSd3T0mgzn/GPO0HCsJwuPnQWjo6IeausVAs74r3HSoqESCgfaQS7hBWYrCQqb6aeexAMrKEOtxPR5OSDpA1ECcAmUlDXa5vynLt4xHr0rNKQzHjqvo6pXRM5C/l+8P5UGwkgg8cup5bJieP6etm+ne0UNlV2xHnr5KNriIhLoa6JbCxS8iqRjxLf2dqTs6IKcFCBxRssQbAaqAOtdENPvl6MKliq5bCXZqhc8du/99mXCz3ULjvCugzFFo1eloQ4J+Z9IcV8o9aDcv0yo+8PKyYHE+ejZv9wfPYMeeaw/lE2UzVD9BFYKCjg7K8CNz8cOcdRvZ9bQ2N8vBxm/wWsmJ9FXh+klM/oVFO/Yzd5l4BkXyQms6svx6MtLWilOXaJ/lmUiqKe68Itsk6JGMYKkWJD+ErcTv1EaYx3QTF2d26YMcFQM7KQEFpOCjv2yWAu2zS1juL1OPU2K1prpM8+T/0lKJTBBG+IDgtcpic7POldBgolkx1cceD1Z/p4oeOcVf0DC/kNLsKAj+CMl8OSQMKgM9ZKggAABOcWFiXcHt0XGL3SbrSIF0Y01qxNDC/uffFdlqjvuIIWJ99LZAqYrJ+2/1eSBoCp0Przq0FW+YqdKZHY5dgKe4MG1SUoWyn/xi7g1M2SQexrjT3Tw6uam/DV51EFH8FUO+ztQljMWEu6sHy62C0V/ATLkUDYhZ6tcMGMtOKvnmM/C76ofls2PSw5nO8I5jPoEZ5gnoyUyTg4OzkzK0TqUf5JwAwz/OoJqbSHuyhSaGi9AFfNrnyg/JAHB/47OpXKDVBnWDiW7JVRnF4XFp/ILGtZKna20NJMR7+5PBGsnMiPyrwd819wMK+CRvOssAlhPGX/0vQV3eGcwdV4feMAFLJ7FQNnFzwcorOAsWtG9J5kGC2mFArp1Dr11TVxRglbMJBtZHh6dy7CsXJiGXtzS2YerK8Ayt0sx/qeQQXGuq7WR9SIqzgjNZ7hUcZMm0blZPBw0KidedXiqYqXVP/ds6GMv8rh6xIU9MzpUj+kOQSRNp40Kgr9A/hgoK21Fcff8HQ1FJ29cvU4GlZ+JiIq/AoXTrre/xqJzORg6fS3FBZHhfCI73LzKqvzY6voSVdi59paaLIi4+o2abs4m21a37ftZbA44FiSRQnogij5w5HLb/szXBygCf+ITFxn/tQHEwPq04IXJ8sp2ajWZ7ogL2faTNHCjSrEX2xO1b6uCtoFjt9t9ViuPu3s+pstB7D4Z08byIuiEIYzqZ0JhIf1n+JO7dwOMC1x4W8JTdOi1Zair45YZrtSsBclaf/4yLoocwhduyiPUpHlvuL3HfTQfgh4tbD/hi26sBQHcYVPJe8e7RByrbDE42zTF6VNHBHIhLJaztonN6CPWcDvp+HczQPyCss9ZfEBNz2jy3LPCIUiytjnk+b1glUfPE/T3J7daH+sqh7VI3XPddGeElOoiUcPsPsPMvH75oAQBAWItb8BpaHULqGPl+KckB9envS5s1GSLZwebSsjr4xdkuxN7fCGKAVOCBWjH026nUffaGRhnZgcnhEoPo9gfWBgFFHN4DZKz6l55+t3ti05oZ6EehJBKIdr0FIW5+bTxmNDkymPuTeE9OgyGJuXPDOA7020xKjbbOeomc0Y7Q+Bt8nTL1I0n4DQNIGvmPkTv7BCjf+TNeRFr2aztV7h/rJDaGQEUPC6J1V5mciD8Yv1Ea+cDtYy5tdDtSQHQuNv8ongFZnFoMgOPNHJJOoWOnSnhHRZKhqXCHwpXy8dWyvngymemaFYgo7V3cxvtafmjR6Y15bNBp2FmXQJ4GBMFFN2Ch8maep1TEuBtT/QqURAITlH/pwUROkH7OH0ox50va8eMNliQW/RGfqAbI2OmJphzscymYngElLWg0acri19UKGXKiTUMgbrJIXeKjXzRpC1l1BF5fq+MdnGbzeukNtk7G8kVtn0FDon3OJB9AykP7B9AyKssJ337LCKMVREY4H/Q35GNLxrfiT8oEsAW8emsTic+BJ67/iF7xOdDfEyxLjYLXaTMIde6BiyWuGZMpByiXbBaK7sLoMR+nOf3qfzZTKWfnkeKNSiMZ/3oBph+fZcVyARHTW8STjX+lY06yanPhjPRpJgdWRcVnaOXY97CuNikGP3ZHo42E1wKnshEChkpkCrxT63Kjl5+whMpGMffyRC4wblqbhx/eWo4OT0EHLkfRtoIES6a5R4T7Cck/JTPErAvWIDLmpWh8FmaGRXFSdXGdqoDLYCxDQQCCRscocNj01ID2zYBtBH4HyUV3lV8xgn6MoqgErwIzpq43WshsbD7I9W6FFTPXa360NMArtj54shinzQAvSSpYR5B80SivO/lvtLTHPyyJ7isUAS2tVAEPRxfRQCxF8iMQ/JTDGO13PK7ovo5a324ZOi2a6lWV8O2G8B06iOGgZqwoGjLGJdeA9q6uh7tYQwCsp6RaJKG2ceRrmzN6GlNi9IlnFFxHu8ij4A54poRIRWyrMTs8TB8XT9ZEJSuRHrg1QKE0zV3B2FUURQGPO+nWz7PPaapsuqKhi1wiqkECYGNAqLavYeJAe77VbMxLXdN69tao6ARyDHxFn8CL2JqmZJfsUvYxoK4TsUP239Zk3AePrRc2Xwe5tGiYw364OvfMQjZyEdssy8ooPTkgCUDoV3I+vAK2WB02uVLybTPaldjCUT1Wj7/vi79qfNniHJj19lXb5AuvvfXW4woxwWTDC6XOTR0J9ZpIqa6ONtNQNElC4YTQH9CT1FMiWk9B/lF4gG5vaLdOXyG4zbifRUR/Ju9UwlqMdscxm6ZggeZaKvcSfvutVx7UURarXJkXLhgltGNJpvQ0+NessvUUxSW9O+YH6UEsffG9N1V+hEBztYoWoOMA6cb04moW3Lzms9WsFWz/WSKlSwaCtqf/YnG5v7yXpaxpNxDQi4VbUCXJeRlufKGgiXGD5g3z2WGULoP43u94pMLbvcyLmScfdSZCTU2tMuTNUvidTkWm/QEY7NgR6pRLPEwgmZvfsgjHWc8DsEcqXrZ6cFrACplj5m/KQOyHE+x4NzSjFV+hdMFQzXlknSQ6wwMDB+l45tSrtU5ihyhVO5deDPE2A3RS6syHlHR+6QfUDVVD2g8CTK164lrhUBM4sGr9qqTL2BRBJmArCBmxE9jP9gjoH8TFlRp/6M67ILR2cWUBQcC1x6zfDZ3X9CA5JrEgErh9TdMLot0+cNOZCWDk9e6IUFkSPPSme182nmGVeo7/azyao6KzeBQHdXSPE2W3TYSm5uo5HCXVEXmVk+fuUr7dSRHy7az6DGgSf4Wvql02wlDXevDfTQ2ActG4XAiPmH5HFjHxMW7bfbpTKbjLq6DWqmqt/546eH+kwXbkGCShQ6UlSafr3lYKL1jDEG6dccmj5dTYZ+DaJVbin6tK09bik0FoCOV63i7ukIxbDpTjgzOfDFDSBYdy0QzxFQj74P4ia3YwT68nNy56r+4EeYEVxnhiBcq5oUZuWylLzQgGZu5xvVNR2dBekgSWjPuYhMuroJkjO1GgBx/9sg8FNxZk9q/QFeotRH6NRPNpBpFxZSbtnb57cjzqaY0gNLUdqb/ltyX5XJjrrAKpjH59Ax8EYjvfmzZc2aqCMRDXYRiSP98yYsgAd6Lrq05JDdQ7NvXKjkpZPB5m96Q56nmjPBTM6fC0mD+OfG0IxuaSM3+eXYIRU+a5dcV7eJknamYM8NG8MvXIbsuS9tUjpVeE3vope0JqEDkideVpnzmsNbSNanDmYyjAGXGSHbyuIeiim6keKRzE2sxvGcdHNMRZTRvj2P8A4b+97zDjwnts8WqcsAHNOPu2y6tiCNepvpLRZ6SL6JCg/AAdqk1IEBMxz288c448xCvMYXx9pzebxrKuf84ITGa6kRXL9ye+mYTr73s0q57OJLQ1hqht7JUHYtofgC4SsqTUD7+YRrCZ2wacSCQtpJ0rirDAvXAqkyouy0kYrq+TeXtDPqYf1VBVftVobmxpZHB/KW+9i42+I4Jnpz8+EBWz0eOY+w8g9bObpQqHdiRl5Uav4iPaDYIv5WUgo1RCRyZah07Vz/xIlhCl3Uud1L5jkgJ8svLmi/zh1X9OvuULtDl9WeUFwSm8U+TUm0Slmbdx/XX9YsOi6cYFU0IQPlg0kSXYp1ksuHBwW6VTXqAqDSXOByhOOgPmxflROAFgJdMvuvw6koa8YyXUeupPDBi0jFOqrefEPhOEW5imB5kBeNUT3KW0L8NGZnZuu8LFombxEzUbEVtx2n+BsHN/8Lb9wjNJomTknJCX5Z2JMd9D9ry5yHk5zWTOzbvXIEiHS6hLOfcQj1N0jDJHrjt1m60ygFLpvpEt0/Rry9o4+ia1HNeEyMgQCi4u1qrEsxHdAMIFEQjp57ea1wvkpZNmnGIQTTTAFjA7juZ1rM234/LKkc0JNxgRwE/yNtPSk3uJxp3O0M1/QkxEDEP7PQjnjJV/EcXvDYs93fwkriR9wmJAr3DWk0IBtO4V0QSUCz+Vko4AKEOsgK5+adEyuA1oh+VKJ8Es5MjYGd1f0kLnbQdbB9w2pYBN9OaMFRBI3DBK3EjRfKBKnrj/nsMM2nz8+uFFyYhY/63DFV1r8rKtsWW2nZ2dQH6XwEyWwbLtu2Mzi27ub6OpCtVYyf2wZQ1lnnZrdA4i/wriDhkQaSmve9lgEtO4qZJMwm+GQWeqdZmEdSZz+HL+le4lEDQk2XkS9Ogbtww5RMRpwV+I7tXKnyTAAwSRFa591SOB5OjApN78IJPvQydpdV0aAIrc9VcemcD1N/fKzqacAiX9BSTlodtcMgNCUxAIz+3ooL0vvy2zb7Z+FhUmvC+Qx0E3gT42hwJlrTwzHITTgFZjRiAC73mpGWsQaneeBjqAu4X8f6scAssot3DDveYaevEjK/IOeboO4vCO8KJBOTQuAHFDknlC/WkebuhQiiD1VySGb2xc40gFjMzRooBfnLEa15Wo0QPGQFp3E1mrjo8VWWp7f4UUpAn1nZAnMrS0VLAABXAFE+hi7Mp7yiPBWHcHrRJmbcEahL2HG+p27XTLT0vm5gfS+wVgYDS+SQh15YfELZnYjxXJ+QlIM1q5NLxMXminz5c0aVn02JIQXh6vnYm4t73d3+gIn8G/sev6h4H/9ZdW4i1spDWYlZmij9WzkHSFiGxsVlDh+FYuPwhfklvqAZBUlZwC2HJU36OV3G17HGcOYGChxNX2bYOX/80WZEMV3vOthOWcYl+LtMXsgsQYs/4eKCRbtLWO7Q3C8RBkMvDRtHFgm20MNu3ry7qRihqInPAklzCddJ/1BJx2NXB5qL4wfC5pOA/CRgbobPNWc842oAAA=")}
.w-entry{display:flex;align-items:center;gap:10px;width:100%;max-width:100%;min-height:40px;padding:8px 10px;border:0;border-radius:12px;background:transparent;color:var(--dsw-alias-label-primary);font-weight:500;font-size:14px;line-height:20px;font-family:inherit;text-align:left;cursor:pointer;box-sizing:border-box;transition:background-color .12s ease,color .12s ease}
.w-entry:hover{background:var(--dsw-alias-bg-layer-2)}
.w-entry:active{transform:scale(.985)}
.w-entry:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}
.w-entry.is-open{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-brand-primary)}
.w-entry-ico{display:inline-flex;flex:none;align-items:center;justify-content:center;width:20px;height:20px;color:var(--dsw-alias-label-secondary)}
.w-entry.is-open .w-entry-ico{color:var(--dsw-alias-brand-primary)}
.w-entry-label{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-entry.is-rail{width:40px;height:40px;min-height:40px;justify-content:center;padding:0}
.w-entry.is-rail .w-entry-label{display:none}

.w-root{position:relative;display:flex;flex-direction:column;height:100%;min-height:0;min-width:0;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);box-sizing:border-box;font-size:13px;line-height:20px;overflow:hidden}
.w-bg{position:absolute;inset:0;z-index:0;pointer-events:none;background-image:var(--w-bg-image);background-size:cover;background-position:right center;background-repeat:no-repeat}
.w-bg:after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,color-mix(in srgb,var(--dsw-alias-bg-base) 96%,transparent) 0%,color-mix(in srgb,var(--dsw-alias-bg-base) 92%,transparent) 45%,color-mix(in srgb,var(--dsw-alias-bg-base) 82%,transparent) 100%)}
body[data-ds-dark-theme] .w-bg:after{background:linear-gradient(90deg,color-mix(in srgb,var(--dsw-alias-bg-base) 95%,transparent) 0%,color-mix(in srgb,var(--dsw-alias-bg-base) 88%,transparent) 45%,color-mix(in srgb,var(--dsw-alias-bg-base) 66%,transparent) 100%)}
.w-head{position:relative;z-index:2;flex:none;padding:20px 36px 22px;border-bottom:1px solid var(--dsw-alias-border-l1);background:linear-gradient(90deg,var(--dsw-alias-bg-base) 0%,color-mix(in srgb,var(--dsw-alias-bg-base) 90%,transparent) 48%,color-mix(in srgb,var(--dsw-alias-bg-base) 58%,transparent) 100%)}
body[data-ds-dark-theme] .w-head{background:linear-gradient(90deg,var(--dsw-alias-bg-base) 0%,color-mix(in srgb,var(--dsw-alias-bg-base) 84%,transparent) 48%,color-mix(in srgb,var(--dsw-alias-bg-base) 32%,transparent) 100%)}
.w-crumb{margin:0;display:flex;align-items:center;gap:8px;font-size:11.5px;line-height:16px;color:var(--dsw-alias-label-secondary)}
.w-crumb span{opacity:.45}
.w-title-row{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-top:8px}
.w-title-tools{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:flex-end}
.w-status{display:inline-flex;align-items:center;gap:8px;height:32px;max-width:min(560px,100%);padding:0 12px;border-radius:999px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;white-space:nowrap}
.w-status.is-active{border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 32%,var(--dsw-alias-border-l1));background:color-mix(in srgb,var(--dsw-alias-brand-primary) 10%,transparent);color:var(--dsw-alias-label-primary)}
.w-status.is-idle{border-style:dashed;opacity:.9}
.w-status-spin{width:11px;height:11px;flex:none;border-radius:50%;border:2px solid color-mix(in srgb,var(--dsw-alias-brand-primary) 28%,transparent);border-top-color:var(--dsw-alias-brand-primary);animation:w-hud-spin .9s linear infinite}
.w-status-dot{width:7px;height:7px;flex:none;border-radius:50%;background:var(--dsw-alias-state-idle-primary)}
.w-status-text{flex:none;font-weight:600}
.w-status-skill{min-width:0;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-status-time{flex:none;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-secondary)}
.w-status-link{flex:none;border:0;background:transparent;padding:0;color:var(--dsw-alias-brand-primary);font:inherit;font-size:11.5px;cursor:pointer;text-decoration:underline;text-underline-offset:2px}
.w-h1{margin:0;font-size:26px;line-height:34px;font-weight:600;letter-spacing:-.015em}
.w-project-row{display:flex;align-items:center;gap:10px;margin-top:10px;min-width:0;flex-wrap:wrap}
.w-project-main{display:flex;align-items:center;gap:10px;min-width:0}
.w-workspace-btn{display:inline-flex;align-items:center;gap:7px;height:32px;padding:0 14px;border-radius:9px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font-size:12.5px;font-weight:500;font-family:inherit;cursor:pointer;white-space:nowrap}
.w-workspace-btn:hover{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-label-secondary)}
.w-workspace-btn:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}
.w-workspace-btn.is-primary{border-color:transparent;background:color-mix(in srgb,var(--dsw-alias-brand-primary) 16%,transparent);color:var(--dsw-alias-brand-primary);font-weight:600}
.w-workspace-btn.is-primary:hover{background:color-mix(in srgb,var(--dsw-alias-brand-primary) 26%,transparent)}
.w-project-name{max-width:min(60ch,52vw);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;line-height:20px;color:var(--dsw-alias-label-secondary)}
.w-pill{flex:none;font-size:11px;line-height:18px;padding:0 9px;border-radius:999px;border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary)}
.w-link{border:0;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:11.5px;cursor:pointer;padding:0 2px;text-decoration:underline;text-underline-offset:2px}
.w-link:hover{color:var(--dsw-alias-label-primary)}

.w-body{position:relative;z-index:1;flex:1 1 auto;min-height:0;display:grid;grid-template-columns:252px minmax(0,1fr)}
.w-nav{min-height:0;overflow:auto;padding:18px 12px 24px;border-right:1px solid var(--dsw-alias-border-l1)}
.w-nav-label{padding:0 12px 8px;font-size:11.5px;line-height:16px;color:var(--dsw-alias-label-secondary)}
.w-nav-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}
.w-nav-row{display:flex;align-items:center;gap:14px;width:100%;padding:9px 12px;border:0;border-radius:10px;background:transparent;color:inherit;font-weight:400;font-size:14px;line-height:20px;font-family:inherit;text-align:left;cursor:pointer;transition:background-color .12s ease,color .12s ease}
.w-nav-row:hover{background:var(--dsw-alias-bg-layer-1)}
.w-nav-row:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}
.w-nav-row.is-active{background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-base)}
.w-nav-no{flex:none;width:18px;font:11.5px/20px ui-monospace,Consolas,monospace;opacity:.55}
.w-nav-row.is-active .w-nav-no{opacity:.7}
.w-nav-ico{display:inline-flex;flex:none;width:18px;justify-content:center;opacity:.8}
.w-nav-text{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-nav-sep{height:1px;margin:16px 12px;background:var(--dsw-alias-border-l1)}

.w-main{min-height:0;overflow:auto;padding:22px 36px 56px}
.w-main-inner{max-width:900px}
.w-main-head{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:30px}
.w-session{display:inline-flex;align-items:center;gap:10px;font-size:12.5px;color:var(--dsw-alias-label-secondary)}
.w-head-tools{display:flex;align-items:center;gap:10px}
.w-mode-group{display:flex;flex-direction:column;gap:7px}
.w-check-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:6px}
.w-check{display:flex;align-items:flex-start;gap:7px;padding:6px 9px;border-radius:8px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);font-size:11.5px;line-height:16px;color:var(--dsw-alias-label-secondary);cursor:pointer}
.w-check:hover{border-color:var(--dsw-alias-label-secondary)}
.w-check.is-on{border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 45%,var(--dsw-alias-border-l1));background:color-mix(in srgb,var(--dsw-alias-brand-primary) 8%,transparent);color:var(--dsw-alias-label-primary)}
.w-check input{margin:1px 0 0;accent-color:var(--dsw-alias-brand-primary);flex:none}
.w-mode-row{display:flex;align-items:center;gap:10px}
.w-mode-label{flex:none;min-width:68px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.w-textarea{width:100%;min-height:68px;resize:vertical;padding:9px 11px;border-radius:9px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-family:inherit;font-size:12.5px;line-height:19px;box-sizing:border-box}
.w-textarea:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}
.w-select{height:34px;min-width:150px;max-width:260px;padding:0 10px;border-radius:9px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font-size:13px;line-height:20px;font-family:inherit;cursor:pointer}
.w-select:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px}
.w-text-btn{display:inline-flex;align-items:center;gap:6px;padding:5px 8px;border:0;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary);font-size:12.5px;line-height:20px;font-family:inherit;cursor:pointer}
.w-text-btn:hover{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary)}
.w-stale{font-size:10.5px;line-height:16px;padding:0 6px;border-radius:999px;color:var(--dsw-alias-state-warn-primary);border:1px solid color-mix(in srgb,var(--dsw-alias-state-warn-primary) 40%,transparent);white-space:nowrap}

.w-page{max-width:900px}
.w-h2{margin:0;font-size:20px;line-height:28px;font-weight:600;letter-spacing:-.01em}
.w-h2-row{display:flex;align-items:baseline;justify-content:space-between;gap:16px}
.w-h2-side{display:flex;align-items:center;gap:8px;flex:none}
.w-ver{font:11px/16px ui-monospace,Consolas,monospace;padding:1px 6px;border-radius:6px;border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary)}
.w-ver.is-empty{border-style:dashed;opacity:.7}
.w-lead{margin:8px 0 0;font-size:13px;line-height:21px;color:var(--dsw-alias-label-secondary);max-width:76ch}
.w-note{margin:8px 0 0;font-size:11.5px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.w-note--inline{margin:0;max-width:52ch}
.w-muted{flex:none;font-size:12px;line-height:20px;color:var(--dsw-alias-label-secondary);white-space:nowrap}
.w-mono-line{margin:10px 0 0;font:11.5px/18px ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--dsw-alias-label-secondary);overflow-wrap:anywhere}
.w-mono-line--inline{margin:0;flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-back-link{align-self:flex-start;margin:0 0 14px;padding:0;border:0;background:transparent;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;font-family:inherit;cursor:pointer}
.w-back-link:hover{color:var(--dsw-alias-label-primary)}

.w-rows{list-style:none;margin:22px 0 0;padding:0;border-top:1px solid var(--dsw-alias-border-l1)}
.w-rows--tight{margin-top:0;border-top:0}
.w-row-item{border-bottom:1px solid var(--dsw-alias-border-l1)}
.w-row-item--inline{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 2px;border-bottom:1px solid var(--dsw-alias-border-l1)}
.w-skill-row{display:grid;grid-template-columns:34px minmax(0,1fr) auto;align-items:start;gap:14px;width:100%;padding:18px 8px;border:0;border-radius:8px;background:transparent;color:inherit;font:inherit;text-align:left;cursor:pointer;transition:background-color .12s ease}
.w-skill-row:hover{background:var(--dsw-alias-bg-layer-1)}
.w-skill-row:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}
.w-skill-row.is-static{cursor:default;opacity:.7}
.w-skill-row.is-static:hover{background:transparent}
.w-skill-row-no{font:11.5px/22px ui-monospace,Consolas,monospace;color:var(--dsw-alias-label-secondary);padding-top:1px}
.w-skill-row-body{display:flex;flex-direction:column;gap:4px;min-width:0}
.w-skill-row-title{display:flex;align-items:center;gap:8px;font-size:15px;line-height:22px;font-weight:500}
.w-skill-row-desc{font-size:12.5px;line-height:19px;color:var(--dsw-alias-label-secondary);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.w-skill-row-meta{font-size:11.5px;line-height:17px;color:var(--dsw-alias-label-secondary);opacity:.85}
.w-tag-soft{font-size:10px;line-height:16px;padding:0 6px;border-radius:999px;border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);font-weight:400}

.w-block{display:flex;flex-direction:column;gap:12px;margin-top:30px}
.w-intro{margin:10px 0 4px;padding:11px 13px;border-radius:11px;border:1px solid var(--dsw-alias-border-l1);border-left:3px solid var(--dsw-alias-brand-primary);background:color-mix(in srgb,var(--dsw-alias-brand-primary) 6%,transparent)}
.w-intro-tag{margin:0 0 5px;font-size:13px;line-height:19px;font-weight:600;color:var(--dsw-alias-label-primary)}
.w-intro-text{margin:0;font-size:12px;line-height:19px;color:var(--dsw-alias-label-secondary)}
.w-intro-points{margin:8px 0 0;padding:0;list-style:none;display:flex;flex-direction:column;gap:4px}
.w-intro-points li{position:relative;padding-left:13px;font-size:11.5px;line-height:17px;color:var(--dsw-alias-label-secondary)}
.w-intro-points li:before{content:'';position:absolute;left:2px;top:7px;width:4px;height:4px;border-radius:50%;background:var(--dsw-alias-brand-primary)}
.w-block-title{font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.w-plain-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px;font-size:13px;line-height:20px}
.w-plain-list li{display:flex;gap:9px;color:var(--dsw-alias-label-secondary)}
.w-plain-list li:before{content:'·';opacity:.55}
.w-plain-list--warn li:before{color:var(--dsw-alias-state-warn-primary);opacity:1}

.w-role{display:flex;flex-direction:column;gap:6px;padding:14px 16px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-layer-1)}
.w-role-head{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
.w-role-label{font-size:13px;line-height:20px;font-weight:500}
.w-required,.w-optional,.w-tag{font-size:10px;line-height:15px;padding:0 6px;border-radius:999px;border:1px solid transparent}
.w-required{color:var(--dsw-alias-state-error-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 26%,transparent)}
.w-optional{color:var(--dsw-alias-label-secondary);border-color:var(--dsw-alias-border-l1)}
.w-tag{color:var(--dsw-alias-label-secondary);border-color:var(--dsw-alias-border-l1)}
.w-role-head .w-btn{margin-left:auto}
.w-role-hint{margin:0;font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary)}
.w-role-warn{margin:0;font-size:11px;line-height:16px;color:var(--dsw-alias-state-warn-primary)}
.w-role-add{align-self:flex-start;display:inline-flex;align-items:center;gap:8px;height:34px;margin-top:4px;padding:0 14px 0 12px;border-radius:9px;border:1px solid color-mix(in srgb,var(--dsw-alias-brand-primary) 32%,var(--dsw-alias-border-l1));background:color-mix(in srgb,var(--dsw-alias-brand-primary) 7%,transparent);color:var(--dsw-alias-brand-primary);font-weight:500;font-size:12.5px;line-height:18px;font-family:inherit;cursor:pointer;transition:background-color .12s ease,border-color .12s ease}
.w-role-add:hover{background:color-mix(in srgb,var(--dsw-alias-brand-primary) 15%,transparent);border-color:var(--dsw-alias-brand-primary)}
.w-role-add:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}
.w-role-add-hint{font-weight:400;font-size:11px;color:var(--dsw-alias-label-secondary)}

.w-chips{list-style:none;margin:4px 0 0;padding:0;display:flex;flex-direction:column;gap:5px}
.w-chip{display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:3px 5px 3px 8px;border-radius:8px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);font-size:11.5px;line-height:18px}
.w-chip-ico{display:inline-flex;flex:none;color:var(--dsw-alias-label-secondary)}
.w-chip-text{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-chip-x{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;flex:none;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer;padding:0}
.w-chip-x:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-state-error-primary)}

.w-card{border:1px solid var(--dsw-alias-border-l1);border-radius:14px;background:var(--dsw-alias-bg-layer-1);overflow:hidden;margin-top:22px}
.w-card--form{margin-top:16px}
.w-card-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 20px;border-bottom:1px solid var(--dsw-alias-border-l1);font-size:14px;line-height:20px;font-weight:600}
.w-card-row{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:16px 20px;border-bottom:1px solid var(--dsw-alias-border-l1)}
.w-card-row:last-child{border-bottom:0}
.w-card-note{margin:0;padding:14px 20px;border-top:1px solid var(--dsw-alias-border-l1);font-size:11.5px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.w-card-empty{padding:28px 20px;font-size:12.5px;line-height:20px;color:var(--dsw-alias-label-secondary)}
.w-card-main{min-width:0;display:flex;flex-direction:column;gap:3px}
.w-row-title{font-size:14px;line-height:21px;font-weight:500}
.w-row-actions{display:flex;align-items:center;gap:6px;flex-wrap:wrap;justify-content:flex-end;flex:none}
.w-inline-main{min-width:0;display:flex;flex-direction:column;gap:2px}
.w-inline-title{font-size:12.5px;line-height:19px;font-weight:500}

.w-form{display:flex;flex-direction:column;gap:10px;padding:16px 20px 18px}
.w-form-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.w-form-row--end{justify-content:flex-end;margin-top:2px}
.w-form-label{flex:none;width:42px;font-size:11.5px;color:var(--dsw-alias-label-secondary)}
.w-input{flex:1 1 200px;min-width:0;height:34px;padding:0 10px;border-radius:9px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-size:12.5px;line-height:20px;font-family:inherit}
.w-input:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px}

.w-btn{display:inline-flex;align-items:center;gap:6px;height:34px;padding:0 13px;border-radius:9px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font-weight:500;font-size:12.5px;line-height:18px;font-family:inherit;cursor:pointer;white-space:nowrap;transition:background-color .12s ease,opacity .12s ease}
.w-btn:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2)}
.w-btn:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px}
.w-btn:disabled{opacity:.5;cursor:default}
.w-btn--solid{border-color:transparent;background:var(--dsw-alias-brand-primary);color:#fff}
.w-btn--solid:hover:not(:disabled){filter:brightness(1.06)}
.w-btn--ghost{border-color:transparent;background:transparent;color:var(--dsw-alias-label-secondary)}
.w-btn--ghost:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}
.w-btn--tiny{height:26px;padding:0 9px;font-size:11.5px;border-radius:7px}
.w-btn--add{height:28px;padding:0 10px;font-size:11.5px;border-radius:7px;border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 30%,var(--dsw-alias-border-l1));color:var(--dsw-alias-brand-primary);background:transparent}
.w-btn--danger{color:var(--dsw-alias-state-error-primary)}
.w-icon-btn{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;flex:none;border:0;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer;padding:0}
.w-icon-btn:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}

.w-action-bar{position:sticky;bottom:0;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-top:34px;padding:16px 0 18px;border-top:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base)}
.w-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.w-run-line{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0;font-size:12px;color:var(--dsw-alias-label-secondary)}
.w-toast{position:absolute;left:50%;bottom:20px;transform:translateX(-50%);z-index:60;padding:8px 16px;border-radius:999px;background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-base);font-size:12px;box-shadow:0 8px 24px rgba(0,0,0,.18)}

.w-hud{position:fixed;right:20px;bottom:20px;z-index:45;width:340px;max-width:calc(100vw - 24px);border-radius:16px;overflow:hidden;color:var(--dsw-alias-label-primary);pointer-events:auto;border:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 66%,transparent);background-color:var(--dsw-alias-bg-overlay);background-image:linear-gradient(180deg,color-mix(in srgb,var(--dsw-alias-bg-overlay) 90%,transparent) 0%,color-mix(in srgb,var(--dsw-alias-bg-overlay) 97%,transparent) 100%),var(--w-bg-image);background-size:auto,cover;background-position:0 0,right center;background-repeat:no-repeat,no-repeat;box-shadow:0 26px 60px rgba(0,0,0,.34),0 8px 20px rgba(0,0,0,.18),inset 0 1px 0 color-mix(in srgb,#fff 9%,transparent);backdrop-filter:blur(18px) saturate(135%)}
.w-hud.is-workbench{bottom:92px}
.w-hud-progress{height:3px;background:color-mix(in srgb,var(--dsw-alias-brand-primary) 14%,transparent);overflow:hidden}
.w-hud-progress:after{content:'';display:block;height:100%;width:38%;background:linear-gradient(90deg,transparent,var(--dsw-alias-brand-primary),transparent);animation:w-hud-flow 1.5s ease-in-out infinite}
@keyframes w-hud-flow{0%{transform:translateX(-110%)}100%{transform:translateX(320%)}}
.w-hud-head{display:flex;align-items:center;gap:9px;padding:11px 12px 9px;cursor:grab;user-select:none;touch-action:none}
.w-hud-head:active{cursor:grabbing}
.w-hud-badge{display:grid;place-items:center;width:22px;height:22px;flex:none;border-radius:7px;background:color-mix(in srgb,var(--dsw-alias-brand-primary) 15%,transparent);color:var(--dsw-alias-brand-primary)}
.w-hud-spin{width:10px;height:10px;border-radius:50%;border:2px solid color-mix(in srgb,var(--dsw-alias-brand-primary) 28%,transparent);border-top-color:var(--dsw-alias-brand-primary);animation:w-hud-spin .9s linear infinite}
@keyframes w-hud-spin{to{transform:rotate(360deg)}}
.w-hud-title{flex:1 1 auto;min-width:0;font-size:12.5px;line-height:18px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.w-hud-grip{flex:none;color:var(--dsw-alias-label-secondary);opacity:.45}
.w-hud-icon{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;flex:none;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer;padding:0}
.w-hud-icon:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}
.w-hud-list{list-style:none;margin:0;padding:0 10px 10px;display:flex;flex-direction:column;gap:6px}
.w-hud-item{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;border-radius:11px;border:1px solid color-mix(in srgb,var(--dsw-alias-border-l1) 80%,transparent);background:color-mix(in srgb,var(--dsw-alias-bg-layer-1) 78%,transparent)}
.w-hud-main{display:flex;flex-direction:column;gap:2px;min-width:0}
.w-hud-skill{font-size:12.5px;line-height:18px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.w-hud-meta{display:flex;align-items:center;gap:5px;font-size:10.5px;line-height:15px;color:var(--dsw-alias-label-secondary);white-space:nowrap}
.w-hud-sep{width:3px;height:3px;border-radius:50%;background:currentColor;opacity:.45}
.w-hud-session{font-size:10px;line-height:14px;color:var(--dsw-alias-label-secondary);opacity:.75;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-hud-actions{display:flex;flex-direction:column;gap:4px;flex:none}
.w-hud-btn{height:24px;padding:0 8px;border-radius:7px;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);font-weight:500;font-size:11px;line-height:16px;font-family:inherit;cursor:pointer;white-space:nowrap}
.w-hud-btn:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2)}
.w-hud-btn--primary{border-color:transparent;background:color-mix(in srgb,var(--dsw-alias-brand-primary) 16%,transparent);color:var(--dsw-alias-brand-primary)}
.w-hud-btn--primary:hover{background:color-mix(in srgb,var(--dsw-alias-brand-primary) 24%,transparent);color:var(--dsw-alias-brand-primary)}
.w-hud-more{margin:0;padding:0 12px 10px;font-size:10.5px;line-height:15px;color:var(--dsw-alias-label-secondary)}
.w-hud--pill{width:auto;padding:0;border:0;background:none;box-shadow:none;overflow:visible;backdrop-filter:none}
.w-hud-pill{display:inline-flex;align-items:center;gap:8px;height:36px;padding:0 12px;border-radius:999px;border:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 70%,transparent);background-color:var(--dsw-alias-bg-overlay);background-image:linear-gradient(180deg,color-mix(in srgb,var(--dsw-alias-bg-overlay) 88%,transparent),color-mix(in srgb,var(--dsw-alias-bg-overlay) 96%,transparent)),var(--w-bg-image);background-size:auto,cover;background-position:0 0,right center;background-repeat:no-repeat,no-repeat;color:var(--dsw-alias-label-primary);font-weight:500;font-size:12px;line-height:18px;font-family:inherit;cursor:grab;touch-action:none;box-shadow:0 14px 34px rgba(0,0,0,.26),inset 0 1px 0 color-mix(in srgb,#fff 8%,transparent);backdrop-filter:blur(14px) saturate(130%)}
.w-hud-pill:active{cursor:grabbing}
.w-hud-pill-text{white-space:nowrap}
.w-hud.is-idle{box-shadow:0 18px 44px rgba(0,0,0,.24),0 6px 16px rgba(0,0,0,.14),inset 0 1px 0 color-mix(in srgb,#fff 7%,transparent)}
.w-hud.is-idle .w-hud-badge{background:color-mix(in srgb,var(--dsw-alias-state-idle-primary) 16%,transparent);color:var(--dsw-alias-state-idle-primary)}
.w-hud-progress.is-idle{background:color-mix(in srgb,var(--dsw-alias-border-l1) 70%,transparent)}
.w-hud-progress.is-idle:after{display:none}
.w-hud-dot{width:7px;height:7px;border-radius:50%;background:var(--dsw-alias-state-idle-primary);flex:none}
.w-hud-idle{display:flex;flex-direction:column;gap:9px;padding:2px 12px 4px}
.w-hud-idle-text{margin:0;font-size:11.5px;line-height:17px;color:var(--dsw-alias-label-secondary)}
.w-hud-idle-sub{margin:0;font-size:10.5px;line-height:16px;color:var(--dsw-alias-label-secondary);opacity:.8}
.w-hud-latest{display:flex;flex-direction:column;gap:5px;padding:8px 9px;border-radius:11px;border:1px solid color-mix(in srgb,var(--dsw-alias-border-l1) 80%,transparent);background:color-mix(in srgb,var(--dsw-alias-bg-layer-1) 70%,transparent)}
.w-hud-latest-label{font-size:10px;line-height:14px;color:var(--dsw-alias-label-secondary);opacity:.8}
.w-hud-latest-main{display:flex;align-items:center;justify-content:space-between;gap:8px}
.w-hud-foot{display:flex;justify-content:flex-end;padding:0 12px 12px}
.w-hud-pill.is-idle .w-hud-pill-text{color:var(--dsw-alias-label-secondary)}
@media (prefers-reduced-motion:reduce){.w-hud-spin{animation-duration:2.4s}.w-hud-progress:after{animation:none;width:100%;opacity:.35}}
@supports not (color: color-mix(in srgb, #000, #fff)) {
.w-bg{opacity:.22}
.w-bg:after{background:none}
.w-head{background:var(--dsw-alias-bg-base)}
.w-phase.is-active{background:var(--dsw-alias-bg-layer-2)}
.w-role-add,.w-btn--add,.w-hud-btn--primary{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l1);color:var(--dsw-alias-brand-primary)}
.w-badge--ok,.w-badge--warn,.w-badge--brand,.w-badge--error{background:var(--dsw-alias-bg-layer-2);border-color:transparent}
.w-hud{background-image:none;border-color:var(--dsw-alias-border-l1)}
.w-intro{background:var(--dsw-alias-bg-layer-1)}
.w-check.is-on{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l2)}
.w-status.is-active{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l1)}
.w-workspace-btn.is-primary{background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-brand-primary)}
.w-status-spin{border-color:var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-brand-primary)}
.w-hud-pill{background-image:none}
.w-hud-badge{background:var(--dsw-alias-bg-layer-2)}
.w-hud-item,.w-hud-latest{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-border-l1)}
.w-hud-progress,.w-hud-progress.is-idle{background:var(--dsw-alias-bg-layer-2)}
.w-stale{border-color:var(--dsw-alias-border-l1)}
.w-overlay{background:rgba(0,0,0,.30)}
}



.w-overlay{position:absolute;inset:0;z-index:50;display:flex;align-items:center;justify-content:center;padding:32px;background:color-mix(in srgb,var(--dsw-alias-label-primary) 26%,transparent)}
.w-modal{display:flex;flex-direction:column;width:min(560px,100%);max-height:min(700px,100%);border-radius:16px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-overlay);box-shadow:0 28px 70px rgba(0,0,0,.28);overflow:hidden}
.w-modal--picker{width:min(720px,100%)}
.w-modal--preview{width:min(680px,100%)}
.w-modal--wide{width:min(880px,100%)}
.w-modal-head{flex:none;display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:20px 22px 14px}
.w-modal-title{margin:0;font-size:15px;line-height:22px;font-weight:600}
.w-modal-sub{margin:4px 0 0;font-size:11.5px;line-height:17px;color:var(--dsw-alias-label-secondary)}
.w-modal-bar{flex:none;display:flex;align-items:center;gap:8px;padding:0 22px 12px;flex-wrap:wrap}
.w-modal-body{flex:1 1 auto;min-height:0;overflow:auto;padding:16px 22px;display:flex;flex-direction:column;gap:14px}
.w-modal-foot{flex:none;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 22px;border-top:1px solid var(--dsw-alias-border-l1);flex-wrap:wrap}
.w-modal-foot--end{justify-content:flex-end}
.w-tip{margin:0 22px 10px;font-size:11px;line-height:17px;color:var(--dsw-alias-label-secondary)}
.w-input{flex:1 1 200px;min-width:0;height:34px;padding:0 10px;border-radius:9px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-size:12.5px;line-height:20px;font-family:inherit}
.w-input:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px}
.w-crumbs{flex:none;display:flex;align-items:center;gap:2px;padding:0 22px 10px;flex-wrap:wrap;font-size:11.5px}
.w-crumb{border:0;background:transparent;color:var(--dsw-alias-brand-primary);font:inherit;cursor:pointer;padding:1px 5px;border-radius:6px}
.w-crumb:hover{background:var(--dsw-alias-bg-layer-2)}
.w-crumb--base{font-weight:600;color:var(--dsw-alias-brand-primary)}
.w-tip--base{color:var(--dsw-alias-label-secondary);opacity:.85}
.w-crumb-path{margin-left:auto;max-width:52%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-secondary);direction:rtl;text-align:left}
.w-list{flex:1 1 auto;min-height:140px;overflow:auto;padding:0 14px 8px}
.w-list-note{margin:10px 8px;font-size:11.5px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.w-list-note--error{color:var(--dsw-alias-state-error-primary)}
.w-row{display:flex;align-items:center;gap:4px;border-radius:9px}
.w-row:hover{background:var(--dsw-alias-bg-layer-1)}
.w-row-main{display:flex;align-items:center;gap:10px;flex:1 1 auto;min-width:0;padding:9px 8px;border:0;border-radius:9px;background:transparent;color:var(--dsw-alias-label-primary);font-size:13px;line-height:20px;font-family:inherit;text-align:left;cursor:pointer}
.w-row-ico{display:inline-flex;flex:none;color:var(--dsw-alias-label-secondary)}
.w-row-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-foot-selected{display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-width:0;flex:1 1 auto}
.w-foot-label{font-size:11px;color:var(--dsw-alias-label-secondary);white-space:nowrap}
.w-foot-actions{display:flex;align-items:center;gap:8px;flex:none}
.w-pre{margin:0;flex:1 1 auto;min-height:0;overflow:auto;padding:16px 22px;font:12px/19px ui-monospace,Consolas,monospace;white-space:pre-wrap;word-break:break-word;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary)}

.w-table{display:flex;flex-direction:column;min-height:0;overflow:auto}
.w-tr{display:grid;grid-template-columns:1.3fr 1fr .8fr .9fr 1fr;gap:12px;padding:13px 22px;border-bottom:1px solid var(--dsw-alias-border-l1);align-items:center;font-size:12px}
.w-tr--head{position:sticky;top:0;background:var(--dsw-alias-bg-layer-1);font-weight:600;color:var(--dsw-alias-label-secondary)}
.w-td{min-width:0;display:flex;flex-direction:column;gap:2px}
.w-td-main{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500;font-size:12.5px}
.w-td-sub{font-size:10.5px;color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.w-td--actions{flex-direction:row;gap:6px;flex-wrap:wrap}
.w-badge{flex:none;font-size:10.5px;line-height:16px;padding:0 7px;border-radius:999px;border:1px solid transparent;white-space:nowrap;align-self:flex-start}
.w-badge--ok{color:var(--dsw-alias-state-success-primary);background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 12%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 26%,transparent)}
.w-badge--warn{color:var(--dsw-alias-state-warn-primary);background:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 13%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 26%,transparent)}
.w-badge--brand{color:var(--dsw-alias-brand-primary);background:color-mix(in srgb,var(--dsw-alias-brand-primary) 12%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 24%,transparent)}
.w-badge--muted{color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l1)}
.w-badge--idle{color:var(--dsw-alias-state-idle-primary);background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l1)}
.w-badge--error{color:var(--dsw-alias-state-error-primary);background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 12%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 26%,transparent)}

@media (max-width:1100px){
  .w-head{padding:18px 24px 20px}
  .w-main{padding:20px 24px 40px}
  .w-body{grid-template-columns:220px minmax(0,1fr)}
}
@media (max-width:820px){
  .w-head{padding:16px 16px 18px}
  .w-h1{font-size:22px;line-height:30px}
  .w-body{grid-template-columns:1fr;grid-template-rows:auto 1fr}
  .w-nav{border-right:0;border-bottom:1px solid var(--dsw-alias-border-l1);padding:12px;max-height:34vh}
  .w-nav-list{flex-direction:row;flex-wrap:wrap}
  .w-nav-list li{flex:1 1 46%}
  .w-nav-label{padding:2px 8px 6px}
  .w-nav-sep{display:none}
  .w-main{padding:16px 16px 40px}
  .w-main-head{margin-bottom:20px;flex-wrap:wrap;gap:10px}
  .w-skill-row{grid-template-columns:28px minmax(0,1fr);padding:14px 4px}
  .w-muted{grid-column:2;justify-self:start}
  .w-tr{grid-template-columns:1fr 1fr;gap:6px}
  .w-tr--head{display:none}
  .w-overlay{padding:12px}
}
@media (prefers-reduced-motion:reduce){.w-entry:active{transform:none}}
`;

    // ----------------------------------------------------------------- apply

    function installStyles() {
      if (document.querySelector('style[data-plugin-css="' + STYLE_ID + '"]') !== null) return;
      const style = document.createElement('style');
      style.dataset.plugin = STYLE_ID;
      style.dataset.pluginCss = STYLE_ID;
      style.textContent = CSS;
      document.head.appendChild(style);
      return function () { style.remove(); };
    }

    function apply(ctx) {
      runtime = ctx;
      ctx.effect(installStyles, 'dsh-fpga-workflow: styles');
      ctx.slots.inject('main', function () {
        return ctx.slots.register({ name: 'main', key: PANEL_KEY }, Workbench);
      });
      ctx.slots.inject('sidebar.footer.action', function () {
        return ctx.slots.register({
          name: 'sidebar.footer.action',
          id: PANEL_KEY,
          order: 20,
          label: function () { return 'FPGA 工作流'; }
        }, WorkflowEntry);
      });
      // Frame-wide floating card: visible from any surface while a run started by
      // the workbench is still in flight.
      ctx.slots.inject('shell.overlay', function () {
        return ctx.slots.register({ name: 'shell.overlay', id: 'fpga-task-hud', order: 40 }, TaskHud);
      });
    }

    return { inject: ['slots'], apply: apply };
  }
});
