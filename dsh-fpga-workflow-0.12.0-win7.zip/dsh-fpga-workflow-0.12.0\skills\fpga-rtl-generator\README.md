<div align="center">
  <h1>fpga-rtl-generator</h1>
  <p><strong>把冻结的 FPGA 架构包（或一份明确需求）变成设计师选定模块的 Verilog-2001 RTL 子树，含模块规格、波形与强制规则自检</strong></p>
  <p>Python 3.8.10 · Windows 7 SP1 离线 · 标准库 + 本机 iverilog 可选 · 支持模块级并行与断点续跑</p>
  <p><a href="README_EN.md">English</a> · <a href="#快速开始">快速开始</a> · <a href="#触发与适用范围">触发边界</a> · <a href="#输入输出与工作流">输入输出</a></p>
</div>

本 Skill 提供两条入口：**架构选根**——用同版 `fpga-architecture-design` 冻结交接包，设计师选定模块 UID，脚本按实例清单展开该模块及后代并核对授权范围；**直接需求**——把要求整理成一份直接请求与模块范围，适合没有架构包、但端口与行为已经说清的场景。生成过程按模块的 `plan → reference → rtl → lint` 推进，支持子 Agent 并行、断点续跑和强制编码规则快速检查。

## 快速开始

```text
请使用 fpga-rtl-generator skill 按冻结架构包生成 RTL。
输入：<arch-frozen 包目录>；模块 UID：<m0001 或模块名>
输出：<rtl-delivery 目录>，含 RTL 子树、模块规格、WaveJSON/SVG、源码清单、强制 lint 结果与 delivery.json
```

最短路径：`doctor` → `prepare` 冻结输入与规则快照 → 反复 `next` / `accept` 推进各阶段 → `publish` 汇总交付。

## 触发与适用范围

**适合使用**

- 架构已冻结，需要按实例层级生成某个模块及其子树的 RTL。
- 没有架构包，但需求、端口、位宽、时钟复位与逐周期行为已经明确。
- 需要模块级并行加速，或中断后从工作目录续跑。
- 交付前需要一轮**强制规则**快速检查（92 条规则分 8 批）。

**不适合使用**

- 需求或接口还有会改变可观测行为的歧义——先澄清。
- 想要架构级判断或需求终审：那是上游 Skill 的职责。
- 想要推荐类/高阶代码审查：快速检查只覆盖强制规则，推荐类不进这一轮。

## 输入输出与工作流

| 阶段 | 做什么 | 产出 |
| --- | --- | --- |
| 0 核验 | `doctor` 检查 Python、架构校验器、规则库与 iverilog | 环境结论 |
| 1 冻结 | `prepare` 冻结输入、任务与强制规则快照，明确范围、复用与外部依赖 | 运行目录与任务队列 |
| 2 逐模块推进 | 持续 `next`，按 `plan → reference → rtl → lint` 执行；独立模块可派子 Agent，主 Agent 审核后 `accept` | 模块规格、参考模型、RTL、规则结果 |
| 3 快速 lint | 每份新 RTL 覆盖全部强制规则，默认 92 条分 8 批；证据不足记 `unverified`，确认违反先核对依据再在契约范围修复（`accept --replace`） | lint 矩阵与结论 |
| 4 交付 | `publish` 汇总子树，检查 `index.md` 与 `delivery.json`：RTL、同名规格、WaveJSON、SVG、参考模型、按需 testbench、源码清单、强制 lint、依赖映射 | 完整交付包 |

`review_required` 表示有失败或未完成的强制检查，或本地展开失败；报告只记录实际执行过的检查。

## 常用命令

```powershell
python scripts\cli.py doctor
python scripts\cli.py prepare --request <selection.json> --package <arch-frozen> --run <rtl-run>
python scripts\cli.py next --run <rtl-run> --limit 8
python scripts\cli.py accept --run <rtl-run> --job m0001 --stage rtl
python scripts\cli.py lint-status --run <rtl-run>
python scripts\cli.py publish --run <rtl-run> --output <rtl-delivery>
```

`scripts\run.ps1` 是 PowerShell 入口（需设置 `FPGA_PYTHON38`）。运行目录与交付目录都要用新目录，写在冻结架构包外部。

## 功能要点

- **两条入口**：架构选根（按实例清单展开、核对授权范围）或直接需求（端口/行为说清即可开工）。
- **按模块推进**：每个模块走 `plan → reference → rtl → lint`，产物可逐阶段验收，不一次吐大文件。
- **并行与续跑**：独立模块可分子 Agent，默认先派一个验证派发与回收，再按宿主槽位加；中断后重新 `next` 核对已写文件续跑。
- **强制规则快速检查**：92 条规则分 8 批，每份新 RTL 全覆盖；证据不足记 `unverified`，不猜通过。
- **交付可核对**：`delivery.json` 逐项列出 RTL、规格、波形、参考模型、testbench、lint 与依赖映射，缺什么一目了然。

## 更多文档

- 输入与命令细节：[`references/runtime.md`](references/runtime.md)
- 各阶段文件名与字段：[`references/stages.md`](references/stages.md)
- 工作流与边界：`SKILL.md`
