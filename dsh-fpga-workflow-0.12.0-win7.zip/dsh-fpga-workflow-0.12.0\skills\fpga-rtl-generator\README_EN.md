<div align="center">
  <h1>fpga-rtl-generator</h1>
  <p><strong>Turn a frozen FPGA architecture package (or an explicit requirement) into a Verilog-2001 RTL subtree for the modules the designer selects, with module specs, waveforms and a mandatory-rule check</strong></p>
  <p>Python 3.8.10 · offline on Windows 7 SP1 · standard library (+ optional local iverilog) · module-level parallelism and resume</p>
  <p><a href="README.md">中文</a> · <a href="#quick-start">Quick Start</a> · <a href="#when-to-use">When to use</a> · <a href="#inputs-outputs-and-workflow">Inputs &amp; outputs</a></p>
</div>

The skill offers two entries. **Architecture selection**: from a frozen `fpga-architecture-design` hand-off package, the designer picks module UIDs and the scripts expand the instance tree and check the authorised scope. **Direct requirement**: a written request with explicit ports, widths, clocks and behaviour, for cases without an architecture package. Generation proceeds per module as `plan → reference → rtl → lint`, with sub-agent parallelism, resume after interruption and a fast mandatory-rule check.

## Quick Start

```text
Use the fpga-rtl-generator skill to generate RTL from the frozen architecture package.
Input: <arch-frozen package dir>; module UID: <m0001 or module name>
Output: <rtl-delivery dir> with the RTL subtree, module specs, WaveJSON/SVG, source list, mandatory lint results and delivery.json
```

Shortest path: `doctor` → `prepare` (freeze inputs and rule snapshot) → loop `next` / `accept` → `publish`.

## When to use

**Use it when**

- The architecture is frozen and RTL for one module and its descendants must be generated.
- No architecture package exists, but requirements, ports, widths, clocks/resets and cycle behaviour are explicit.
- Module-level parallelism or resume from the working directory is needed.
- A fast **mandatory-rule** pass is required before delivery (92 rules in 8 batches).

**Do not use it when**

- Requirements or interfaces still have ambiguities that change observable behaviour — clarify first.
- Architecture judgement or requirement sign-off is needed; that belongs to upstream skills.
- Recommended or advanced code review is wanted; the fast pass covers mandatory rules only.

## Inputs, outputs and workflow

| Stage | What happens | Output |
| --- | --- | --- |
| 0 Validate | `doctor` checks Python, the architecture validator, the rule library and iverilog | Environment verdict |
| 1 Freeze | `prepare` freezes inputs, tasks and the mandatory-rule snapshot; scope, reuse and external dependencies are stated | Run directory and task queue |
| 2 Per-module | Repeated `next`, then `plan → reference → rtl → lint`; independent modules can go to sub-agents, the main agent reviews and runs `accept` | Module specs, reference model, RTL, rule results |
| 3 Fast lint | Every new RTL file covers all mandatory rules, 92 rules in 8 batches; missing evidence is `unverified`; confirmed violations are verified then fixed within the contract (`accept --replace`) | Lint matrix and verdict |
| 4 Deliver | `publish` merges the subtree and checks `index.md` / `delivery.json`: RTL, specs, WaveJSON, SVG, reference model, optional testbench, source list, mandatory lint, dependency map | Complete delivery |

`review_required` means failed or unfinished mandatory checks, or a local expansion failure; reports only record checks that actually ran.

## Commands

```powershell
python scripts\cli.py doctor
python scripts\cli.py prepare --request <selection.json> --package <arch-frozen> --run <rtl-run>
python scripts\cli.py next --run <rtl-run> --limit 8
python scripts\cli.py accept --run <rtl-run> --job m0001 --stage rtl
python scripts\cli.py lint-status --run <rtl-run>
python scripts\cli.py publish --run <rtl-run> --output <rtl-delivery>
```

`scripts\run.ps1` is the PowerShell entry (set `FPGA_PYTHON38`). Both the run directory and the delivery directory must be new directories outside the frozen package.

## Highlights

- **Two entries** — architecture selection (instance-tree expansion with scope check) or direct requirement.
- **Per-module stages** — `plan → reference → rtl → lint`, accepted one stage at a time instead of one huge dump.
- **Parallel and resumable** — independent modules can use sub-agents; after an interruption, re-run `next` and reconcile written files.
- **Fast mandatory-rule check** — 92 rules in 8 batches covering every new file; `unverified` instead of guessing a pass.
- **Checkable delivery** — `delivery.json` lists RTL, specs, waveforms, reference model, testbench, lint and dependency map.

## More

- Inputs and commands: [`references/runtime.md`](references/runtime.md)
- Stage files and fields: [`references/stages.md`](references/stages.md)
- Workflow and boundaries: `SKILL.md`
