"""Validate stage artifacts and render offline module specifications."""

import ast
import html
import re
from pathlib import Path

from inputs import IDENTIFIER, dump, index, load, require


def source_lines(path):
    return path.read_text(encoding='utf-8-sig').splitlines()


def require_text(value, label):
    require(isinstance(value, str) and value.strip(), 'Expected non-empty ' + label)


def render_wave(title, wavejson, path):
    lanes = wavejson.get('signal')
    require(isinstance(lanes, list) and lanes, 'WaveJSON requires signal lanes')
    require(set(wavejson) == {'signal'}, 'Offline SVG renderer supports the WaveJSON signal subset')
    index(lanes, 'name')
    start, step, row = 180, 28, 32
    cycles = max(len(lane['wave']) for lane in lanes)
    require(0 < cycles <= 160, 'Use shorter, separate timing scenarios (1-160 cycles)')
    width, height = start + (cycles + 1) * step, 44 + len(lanes) * row
    esc = html.escape
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="{}" height="{}" viewBox="0 0 {} {}">'.format(
        width, height, width, height), '<rect width="100%" height="100%" fill="white"/>',
        '<g fill="#17283c" font-family="sans-serif" font-size="13">',
        '<text x="10" y="18">{}</text>'.format(esc(title))]
    for cycle in range(cycles + 1):
        x = start + step * cycle
        parts.append('<path d="M{} 25V{}" stroke="#dce4ee"/>'.format(x, height - 6))
    for number, lane in enumerate(lanes):
        require(set(lane) <= {'name', 'wave', 'data'}, 'Unsupported WaveJSON lane attribute')
        name, wave = lane['name'], lane['wave']
        require_text(name, 'waveform signal name')
        require(re.fullmatch(r'[01xzpPnN=2-9][01xzpPnN=2-9.]*', wave),
                'Unsupported WaveJSON symbols in ' + name)
        raw_labels = lane.get('data', [])
        labels = raw_labels.split() if isinstance(raw_labels, str) else raw_labels
        require(isinstance(labels, list) and all(isinstance(label, str) for label in labels),
                'WaveJSON data must be strings')
        require(len(labels) == sum(symbol in '=23456789' for symbol in wave),
                'WaveJSON bus data count does not match marked segments in ' + name)
        label_iterator = iter(labels)
        y = 47 + row * number
        parts.append('<text x="10" y="{}">{}</text>'.format(y + 4, esc(name)))
        prior_symbol = None
        prior_end = None
        for cycle, token in enumerate(wave):
            symbol = prior_symbol if token == '.' else token
            x = start + cycle * step
            if symbol in 'pPnN':
                begin = y + 7 if symbol in 'nN' else y - 7
                end = 2 * y - begin
                data = 'M{} {}H{}V{}H{}'.format(x, begin, x + step // 2, end, x + step)
            elif symbol in '01xz':
                begin = end = {'0': y + 7, '1': y - 7, 'x': y, 'z': y}[symbol]
                data = 'M{} {}H{}'.format(x, begin, x + step)
                if symbol == 'x':
                    parts.append('<path d="M{} {}l{} 14m{} 0l{} -14" stroke="#9c4550"/>'.format(
                        x, y - 7, step, -step, step))
            else:
                begin = end = y
                data = 'M{} {}h{}m{} 14h{}'.format(x, y - 7, step, -step, step)
                if token != '.':
                    parts.append('<text x="{}" y="{}" font-size="10">{}</text>'.format(
                        x + 3, y + 3, esc(next(label_iterator))))
            if prior_end is not None and prior_end != begin:
                data += 'M{} {}V{}'.format(x, prior_end, begin)
            parts.append('<path d="{}" stroke="#295784" fill="none"/>'.format(data))
            prior_symbol, prior_end = symbol, end
    path.write_text('\n'.join(parts + ['</g></svg>']) + '\n', encoding='utf-8')


def validate_spec(spec, job):
    name = job['name']
    require(spec['name'] == name and spec['rtl_path'] == 'rtl/' + name + '.v',
            'Specification name and path must match the assigned HDL module')
    require(spec['target'] == 'rtl' and spec['rtl_dialect'] == 'verilog', 'Use Verilog-2001')
    ports = spec['interfaces']['ports']
    require(isinstance(ports, list) and ports, 'Module must specify its interface ports')
    port_index = index(ports, 'name')
    for port in ports:
        require(IDENTIFIER.fullmatch(port['name']), 'Invalid port identifier')
        require(port['direction'] in ('input', 'output', 'inout'), 'Invalid port direction')
        width = port['width']
        require(type(width) is int and width > 0 or isinstance(width, str) and width.strip(),
                'Specify a positive or symbolic port width')
        require_text(port.get('description'), 'port description')
    design = spec.get('design_requirements', {})
    require(isinstance(design, dict), 'design_requirements must be an object')
    if job['architecture'] is None:
        require(design.get('confirmed_by_user') is True, 'Direct request requires confirmed requirements')
        require_text(design.get('confirmation_notes'), 'direct confirmation notes')
    for key in ('clock', 'reset'):
        require(key in spec and (spec[key] is None or isinstance(spec[key], dict)),
                'Specify {} objects or explicit null for combinational designs'.format(key))
        if spec[key] is not None:
            port = port_index.get(spec[key]['name'])
            require(port and port['direction'] == 'input', key + ' must name an input port')
    for key in ('behavior', 'constraints', 'corner_cases', 'verification_cases'):
        require(isinstance(spec[key], list) and (key == 'constraints' or spec[key]), 'Missing ' + key)
        for item in spec[key]:
            require_text(item, key)
    diagrams = spec['timing_diagrams']
    require(isinstance(diagrams, list) and diagrams, 'Specify at least one timing diagram')
    for identifier, diagram in index(diagrams, 'id').items():
        require(IDENTIFIER.fullmatch(identifier), 'Invalid timing diagram ID')
        for key in ('title', 'scenario', 'description'):
            require_text(diagram.get(key), 'timing diagram ' + key)


def render_spec(spec, root):
    name = spec['name']
    root.mkdir(parents=True, exist_ok=True)
    lines = ['# ' + name + ' 模块规格', '', 'RTL `rtl/' + name + '.v`', '', '## 接口', '',
             '| 端口 | 方向 | 位宽 | 说明 |', '|---|---|---|---|']
    for port in spec['interfaces']['ports']:
        values = (port['name'], port['direction'], port['width'], port['description'])
        lines.append('| ' + ' | '.join(str(value).replace('|', '&#124;').replace('\n', ' ')
                                      for value in values) + ' |')
    for label, key in [('时钟', 'clock'), ('复位', 'reset')]:
        lines.extend(['', '## ' + label, '', str(spec[key]) if spec[key] is not None else '不适用'])
    for label, key in [('逐周期行为', 'behavior'), ('约束', 'constraints'), ('边界情况', 'corner_cases'),
                       ('验证场景', 'verification_cases')]:
        lines.extend(['', '## ' + label, ''] + ['- ' + item for item in spec[key]])
    lines.extend(['', '## 时序图', ''])
    for diagram in spec['timing_diagrams']:
        scenario = name + '_' + diagram['id']
        waves = root / 'waveforms'
        waves.mkdir(exist_ok=True)
        dump(waves / (scenario + '.json5'), diagram['wavejson'])
        render_wave(diagram['title'], diagram['wavejson'], waves / (scenario + '.svg'))
        lines.extend(['### ' + diagram['title'], '', diagram['scenario'], diagram['description'], '',
                      '![%s](waveforms/%s.svg)' % (diagram['title'], scenario), '',
                      '[WaveJSON](waveforms/%s.json5)' % scenario, ''])
    (root / (name + '_spec.md')).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def validate_reference(directory):
    source = directory / 'reference.py'
    tree = ast.parse(source.read_text(encoding='utf-8-sig'), filename=str(source), feature_version=(3, 8))
    require(any(isinstance(node, (ast.FunctionDef, ast.ClassDef)) for node in tree.body),
            'Reference model needs a function or class entry point')
    if (directory / 'vectors.json').exists():
        require(load(directory / 'vectors.json'), 'Test vectors cannot be empty')


def validate_lint(rule_list, result, source):
    require(isinstance(result, list), 'Lint result must be an array')
    expected = set(index(rule_list, 'id'))
    actual = index(result, 'rule_id')
    require(expected == set(actual), 'Lint result must cover exactly the assigned mandatory rules')
    lines = source_lines(source)
    for item in result:
        status = item['status']
        require(status in ('pass', 'fail', 'not_applicable', 'unverified'), 'Invalid rule outcome')
        require_text(item.get('evidence'), 'rule result evidence or reason')
        if status == 'fail':
            number = item.get('line')
            require(type(number) is int and 0 < number <= len(lines), 'Fail needs a valid RTL line')
            snippet = item.get('snippet')
            require(isinstance(snippet, str) and snippet.strip() and snippet in lines[number - 1],
                    'Fail snippet does not match cited RTL line')


def check_module_shell(path, module, child_specs):
    # Lightweight sanity check. Icarus elaboration, when available, remains a separate tool result.
    source = path.read_text(encoding='utf-8-sig')
    source = re.sub(r'/\*.*?\*/|//[^\r\n]*|"(?:\\.|[^"\\])*"', ' ', source, flags=re.DOTALL)
    require(re.findall(r'\bmodule\s+([A-Za-z_]\w*)', source) == [module['name']]
            and len(re.findall(r'\bendmodule\b', source)) == 1, 'Expected exactly the assigned module')
    for child, child_spec in child_specs:
        pattern = r'\b{}\b(?:\s*\#\s*\(([^;]*?)\))?\s+{}\s*\(([^;]*)\)\s*;'.format(
            re.escape(child['name']), re.escape(child['instance']))
        match = re.search(pattern, source)
        require(match is not None, 'Missing planned instance ' + child['instance'])
        if child_spec is not None:
            expected = {p['name'] for p in child_spec['interfaces']['ports']}
            require(expected == set(child['connections']), 'Incomplete child port contract for ' + child['instance'])
        for section, values in zip(('parameters', 'connections'), match.groups()):
            actual = named_bindings(values or '')
            expected = {key: re.sub(r'\s+', '', value) for key, value in child[section].items()}
            require(actual == expected, 'Instance {} differs from its planned {}'.format(child['instance'], section))


def named_bindings(text):
    """Parse the assigned instance's named associations, including nested expressions."""
    bindings = {}
    text = text.strip()
    while text:
        header = re.match(r'\.\s*([A-Za-z_]\w*)\s*\(', text)
        require(header is not None, 'Instance bindings must use explicit named associations')
        key = header.group(1)
        require(key not in bindings, 'Duplicate instance association: ' + key)
        start = header.end()
        depth = 1
        for end in range(start, len(text)):
            depth += (text[end] == '(') - (text[end] == ')')
            if depth == 0:
                break
        require(depth == 0, 'Unterminated named association: ' + key)
        bindings[key] = re.sub(r'\s+', '', text[start:end])
        text = text[end + 1:].lstrip()
        if text:
            require(text.startswith(',') and text[1:].strip(), 'Malformed instance associations')
            text = text[1:].lstrip()
    return bindings
