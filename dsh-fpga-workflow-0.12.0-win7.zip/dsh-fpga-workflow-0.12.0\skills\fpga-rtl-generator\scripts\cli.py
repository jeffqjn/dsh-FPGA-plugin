"""Offline coordinator for the FPGA RTL generation skill."""

import argparse
import contextlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from artifacts import check_module_shell, render_spec, validate_lint, validate_reference, validate_spec
from inputs import (DEFAULT_ARCH, DEFAULT_RULES, WORKSPACE, build_tasks, dump, index, inside, load,
                    read_architecture, require, rule_batches, sha)


RUNTIME = (3, 8, 10)
STAGES = ('plan', 'reference', 'rtl')
DEFAULT_VG = WORKSPACE / 'verilog-generator-main' / 'verilog-generator-main'


@contextlib.contextmanager
def new_directory(destination):
    require(not destination.exists(), 'Output already exists: ' + str(destination))
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.rtl-', dir=str(destination.parent)) as scratch:
        stage = Path(scratch) / 'data'
        stage.mkdir()
        yield stage
        stage.rename(destination)


@contextlib.contextmanager
def coordinator_lock(run):
    lock = run / '.coordinator.lock'
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise ValueError('Coordinator lock exists. Check its PID before clearing a stale lock: ' + str(lock))
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(str(os.getpid()) + '\n')
        yield
    finally:
        lock.unlink()


def file_hashes(directory):
    return {path.relative_to(directory).as_posix(): sha(path)
            for path in sorted(directory.rglob('*')) if path.is_file()}


def prepare(args):
    request_path = Path(args.request).resolve()
    request = load(request_path)
    architecture = digest = None
    if args.package:
        require(request['contract'] == 'FPGA-RTL-SELECTION/1.0.0', 'Wrong selection contract')
        package = Path(args.package).resolve()
        require(package not in Path(args.run).resolve().parents,
                'Write the RTL run outside the architecture package')
        architecture, digest = read_architecture(package, request, Path(args.arch_skill).resolve())
    else:
        require(request['contract'] == 'FPGA-RTL-REQUEST/1.0.0', 'Wrong direct request contract')
    tasks, sources = build_tasks(request, request_path.parent, architecture)
    rules_path = Path(args.rules).resolve()
    rule_bytes = rules_path.read_bytes()
    batches = rule_batches(rule_bytes.decode('utf-8-sig'), args.batch_rules, args.batch_bytes)
    keys = ['l{:03d}'.format(i) for i in range(1, len(batches) + 1)]
    run = Path(args.run).resolve()
    with new_directory(run) as stage:
        frozen = stage / 'inputs'
        frozen.mkdir()
        dump(frozen / 'request.json', request)
        (frozen / 'RTL_Coding_Rule.md').write_bytes(rule_bytes)
        (frozen / 'tasks').mkdir()
        (frozen / 'rules').mkdir()
        (stage / 'work').mkdir()
        for task in tasks:
            dump(frozen / 'tasks' / (task['job'] + '.json'), task)
        for key, batch in zip(keys, batches):
            dump(frozen / 'rules' / (key + '.json'), batch)
        for relative, source in sources.items():
            target = frozen / 'dependencies' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(source), str(target))
        if architecture is not None:
            (frozen / 'architecture_package.json').write_bytes((package / 'package.json').read_bytes())
            require(sha(frozen / 'architecture_package.json') == digest, 'Architecture package changed')
        dump(stage / 'run.json', dict(contract='FPGA-RTL-RUN/1.0.0', root=request['root'],
                                     project_top=request.get('project_top'), package_sha256=digest,
                                     jobs=[t['job'] for t in tasks], batches=keys,
                                     mandatory_rule_count=sum(map(len, batches)),
                                     input_hashes=file_hashes(frozen)))
    return {'run': str(run), 'modules': len(tasks), 'mandatory_rule_count': sum(map(len, batches)),
            'lint_batch_count': len(batches)}


class Run:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.info = load(self.root / 'run.json')
        self.inputs = self.root / 'inputs'
        require(self.info['contract'] == 'FPGA-RTL-RUN/1.0.0', 'Unsupported RTL run')
        require(file_hashes(self.inputs) == self.info['input_hashes'], 'Frozen RTL inputs changed')
        self.jobs = {job: load(self.task_path(job)) for job in self.info['jobs']}
        self.generated = [job for job, task in self.jobs.items() if task['mode'] == 'generate']
        self.active = self.root / 'accepted'
        self.lint_root = self.root / 'lint'
        self.checked = {}

    def task_path(self, job):
        return inside(self.inputs / 'tasks', job + '.json')

    def batch_path(self, batch):
        require(batch in self.info['batches'], 'Unknown lint batch: ' + str(batch))
        return self.inputs / 'rules' / (batch + '.json')

    def current(self, job, stage):
        key = (job, stage)
        if key in self.checked:
            return self.checked[key]
        pointer = self.active / job / (stage + '.json')
        if not pointer.is_file():
            self.checked[key] = None
            return None
        receipt = load(pointer)
        path = inside(pointer.parent, receipt['path'])
        require(file_hashes(path) == receipt['hashes'], 'Accepted artifacts changed: ' + str(path))
        self.checked[key] = path
        return path

    def source(self, job):
        return self.current(job, 'rtl') / (self.jobs[job]['name'] + '.v')

    def lint_revision(self, job):
        return self.lint_root / job / sha(self.source(job))

    def prerequisites(self, job, stage):
        if stage == 'plan':
            return all(self.current(child['job'], 'plan') is not None
                       for child in self.jobs[job]['children'] if child['mode'] == 'generate')
        previous = STAGES[STAGES.index(stage) - 1]
        return self.current(job, previous) is not None

    def task_arguments(self, job, action, work, **extra):
        task = self.jobs[job]
        return dict(job=job, name=task['name'], action=action, task=str(self.task_path(job)),
                    work=str(work), **extra)

    def queue(self, limit):
        ready = []
        lint_ready = []
        for job in self.generated:
            for stage in STAGES:
                if self.current(job, stage) is None:
                    if self.prerequisites(job, stage):
                        work = self.root / 'work' / job / stage
                        child_plans = []
                        if stage == 'plan':
                            for child in self.jobs[job]['children']:
                                if child['mode'] == 'generate':
                                    child_plans.append(str(self.current(child['job'], 'plan') / 'spec.json'))
                        dependencies = dict(child_specs=sorted(set(child_plans))) if stage == 'plan' else {}
                        if stage != 'plan':
                            dependencies['plan'] = str(self.current(job, 'plan'))
                        if stage == 'rtl':
                            dependencies['reference'] = str(self.current(job, 'reference'))
                        ready.append(self.task_arguments(job, stage, work, **dependencies))
                    break
            else:
                if len(lint_ready) == limit:
                    continue
                revision = self.lint_revision(job)
                source = str(self.source(job))
                for batch in self.info['batches']:
                    if not (revision / (batch + '.json')).is_file():
                        lint_ready.append(self.task_arguments(
                            job, 'lint', self.root / 'work' / job / 'lint' / revision.name / (batch + '.json'),
                            batch=batch, rules=str(self.batch_path(batch)), source=source,
                            source_sha256=revision.name))
                        if len(lint_ready) >= limit:
                            break
            if len(ready) == limit:
                break
        return {'ready': (ready + lint_ready)[:limit]}

    def child_specs(self, job):
        for child in self.jobs[job]['children']:
            if child['mode'] == 'generate':
                spec = load(self.current(child['job'], 'plan') / 'spec.json')
            else:
                spec = child['interface']
            yield child, spec

    def validate_stage(self, stage, job, path):
        task = self.jobs[job]
        if stage == 'plan':
            requirements = load(path / 'requirements.json')
            plan = load(path / 'codegen_plan.json')
            require(isinstance(requirements, dict) and requirements.get('requirements'),
                    'Requirements must record the confirmed design obligations')
            require(isinstance(plan, dict) and plan.get('steps'), 'Generation plan requires steps')
            spec = load(path / 'spec.json')
            validate_spec(spec, task)
            direct_children = list(self.child_specs(job))
            for child, child_spec in direct_children:
                require(set(child['connections']) == {p['name'] for p in child_spec['interfaces']['ports']},
                        'Scope manifest must bind every port of ' + child['instance'])
            render_spec(spec, path / 'spec')
        elif stage == 'reference':
            validate_reference(path)
        else:
            check_module_shell(path / (task['name'] + '.v'), task, self.child_specs(job))
            testbench = path / ('tb_' + task['name'] + '.v')
            if testbench.exists():
                check_module_shell(testbench, {'name': 'tb_' + task['name']}, [])

    def accept(self, args):
        job, stage = args.job, args.stage
        require(job in self.generated, 'Unknown generation job: ' + job)
        if stage == 'lint':
            return self.accept_lint(args)
        require(args.batch is None, '--batch only applies to lint')
        require(self.prerequisites(job, stage), 'Stage dependencies have not been accepted')
        prior = self.current(job, stage)
        require(not args.replace or stage == 'rtl' and prior is not None,
                '--replace is for a previously accepted RTL stage')
        require(prior is None or args.replace, 'Stage already accepted')
        work = self.root / 'work' / job / stage
        name = self.jobs[job]['name']
        mandatory, optional = {
            'plan': (('requirements.json', 'codegen_plan.json', 'spec.json'), ()),
            'reference': (('reference.py',), ('vectors.json',)),
            'rtl': ((name + '.v',), ('tb_' + name + '.v',)),
        }[stage]
        for filename in mandatory:
            require((work / filename).is_file(), 'Missing stage output: ' + str(work / filename))
        parent = self.active / job
        parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.' + stage + '-', dir=str(parent)) as temp:
            scratch = Path(temp)
            output = scratch / 'data'
            output.mkdir()
            for filename in mandatory + optional:
                if (work / filename).is_file():
                    shutil.copyfile(str(inside(work, filename)), str(output / filename))
            self.validate_stage(stage, job, output)
            hashes = file_hashes(output)
            dest = parent / (stage + '-' + scratch.name.lstrip('.'))
            output.rename(dest)
            dump(scratch / 'receipt.json', {'path': dest.name, 'hashes': hashes})
            os.replace(str(scratch / 'receipt.json'), str(parent / (stage + '.json')))
        return {'job': job, 'accepted': stage, 'path': str(dest)}

    def accept_lint(self, args):
        job, batch = args.job, args.batch
        require(not args.replace and self.current(job, 'rtl') is not None,
                'Lint requires accepted RTL and does not take --replace')
        rules = load(self.batch_path(batch))
        revision = self.lint_revision(job)
        target = revision / (batch + '.json')
        require(not target.exists(), 'Lint batch already accepted for this source revision')
        candidate = self.root / 'work' / job / 'lint' / revision.name / (batch + '.json')
        result = load(candidate)
        validate_lint(rules, result, self.source(job))
        revision.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=str(revision)) as temp:
            scratch = Path(temp) / 'result.json'
            dump(scratch, result)
            scratch.rename(target)
        return {'job': job, 'accepted': 'lint', 'batch': batch}

    def lint_report(self):
        all_rules = {batch: load(self.batch_path(batch)) for batch in self.info['batches']}
        result = {}
        for job in self.generated:
            rows, missing = [], []
            revision = self.lint_revision(job) if self.current(job, 'rtl') is not None else None
            for batch, rules in all_rules.items():
                path = revision / (batch + '.json') if revision is not None else None
                if path is not None and path.is_file():
                    batch_result = load(path)
                    validate_lint(rules, batch_result, self.source(job))
                    rows.extend(batch_result)
                else:
                    missing.extend(rule['id'] for rule in rules)
            result[job] = {'source_sha256': revision.name if revision else None, 'missing': missing, 'results': rows}
        counts = dict.fromkeys(('pass', 'fail', 'not_applicable', 'unverified'), 0)
        for item in result.values():
            for row in item['results']:
                counts[row['status']] += 1
        missing = sum(len(i['missing']) for i in result.values())
        status = 'fail' if counts['fail'] else ('incomplete' if missing or counts['unverified'] else 'pass')
        return dict(status=status, counts=counts, missing=missing, jobs=result,
                    rule_source_sha256=self.info['input_hashes']['RTL_Coding_Rule.md'],
                    rules=[dict(id=r['id'], title=r['title'], source_line=r['source_line'])
                           for batch in all_rules.values() for r in batch])


def publish(run, args):
    for job in run.generated:
        for stage in STAGES:
            require(run.current(job, stage) is not None, 'Incomplete stage: ' + job + ' ' + stage)
    lint = run.lint_report()
    require(lint['missing'] == 0 or args.partial_lint, 'Complete lint batches or use --partial-lint for review only')
    destination = Path(args.output).resolve()
    require(run.root not in destination.parents, 'Write the final bundle outside the run directory')
    with new_directory(destination) as bundle:
        for name in ('rtl', 'reports', 'models', 'tb', 'spec'):
            (bundle / name).mkdir()
        if (run.inputs / 'dependencies').is_dir():
            shutil.copytree(str(run.inputs / 'dependencies'), str(bundle / 'dependencies'))
        source_order = []
        bench_names = []
        for job, task in run.jobs.items():
            source_order.extend(task['sources'])
            if job not in run.generated:
                continue
            name = task['name']
            rtl_path = 'rtl/' + name + '.v'
            source_order.append(rtl_path)
            shutil.copyfile(str(run.source(job)), str(bundle / rtl_path))
            rtl_dir = run.current(job, 'rtl')
            bench = rtl_dir / ('tb_' + name + '.v')
            if bench.is_file():
                shutil.copyfile(str(bench), str(bundle / 'tb' / bench.name))
                bench_names.append(bench.name)
            plan = run.current(job, 'plan')
            spec = bundle / 'spec' / name
            shutil.copytree(str(plan / 'spec'), str(spec))
            for filename in ('spec.json', 'requirements.json', 'codegen_plan.json'):
                shutil.copyfile(str(plan / filename), str(spec / filename))
            shutil.copytree(str(run.current(job, 'reference')), str(bundle / 'models' / name))
        source_order = list(dict.fromkeys(source_order))
        (bundle / 'files.f').write_text(''.join(p + '\n' for p in source_order if p.endswith('.v')),
                                        encoding='utf-8')
        dump(bundle / 'reports' / 'mandatory_lint.json', lint)
        check = elaborate(bundle, run, args.iverilog, args.include_dir)
        vg = original_gate(bundle, run, args)
        status = ('review_required' if lint['status'] != 'pass' or check['status'] in ('fail', 'tool_error')
                  or vg['status'] in ('fail', 'tool_error')
                  else 'generated')
        manifest = dict(contract='FPGA-RTL-DELIVERY/1.0.0', status=status, root=run.info['root'],
                        project_top=run.info['project_top'], package_sha256=run.info['package_sha256'],
                        modules=[{k: task[k] for k in ('uid', 'name', 'mode', 'children', 'sources', 'dependency')}
                                 for task in run.jobs.values()], source_order=source_order,
                        requirement_trace={task['uid']: task['architecture']['requirements']
                                           for task in run.jobs.values() if task['architecture'] is not None},
                        testbenches=bench_names, checks=dict(mandatory_lint=lint['status'],
                                                            iverilog_elaboration=check,
                                                            original_vg_gate=vg,
                                                            simulation='not_run', synthesis='not_run'))
        lines = ['# RTL 生成交付', '', '- 状态 `{}`'.format(status),
                 '- 根模块 UID `{}`'.format(run.info['root']),
                 '- 强制规则检查 `{}`，缺少 {} 项'.format(lint['status'], lint['missing']),
                 '- Icarus Verilog 展开 `{}`'.format(check['status']),
                 '- 原 VG 严格门禁 `{}`'.format(vg['status']),
                 '- 仿真和综合未执行', '', '## 生成模块', '']
        for job in run.generated:
            name = run.jobs[job]['name']
            lines.append('- [{}](spec/{}/{}_spec.md)'.format(name, name, name))
        lines.extend(['', '[完整检查记录](reports/mandatory_lint.json)', '', '[交付清单](delivery.json)'])
        (bundle / 'index.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
        manifest['artifacts'] = file_hashes(bundle)
        dump(bundle / 'delivery.json', manifest)
    return {'output': str(destination), 'status': status, 'checks': manifest['checks']}


def top_task(run):
    return next(task for task in run.jobs.values() if task['uid'] == run.info['root'])


def run_tool(command, directory, report, timeout=120):
    try:
        proc = subprocess.run(command, cwd=str(directory), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=timeout,
                              creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except (OSError, subprocess.TimeoutExpired) as exc:
        report.write_text(str(exc) + '\n', encoding='utf-8')
        return None, str(exc)
    log = b'\n'.join(output for output in (proc.stdout, proc.stderr) if output).decode('utf-8', errors='replace')
    report.write_text(log or 'Exit code {}\n'.format(proc.returncode), encoding='utf-8')
    return proc.returncode, log


def elaborate(bundle, run, command, include_dirs):
    if not command:
        return {'status': 'not_run', 'reason': 'Icarus elaboration was not requested'}
    externals = [task['name'] for task in run.jobs.values() if task['mode'] == 'external']
    if externals:
        return {'status': 'not_run', 'reason': 'External definitions required', 'modules': externals}
    root = top_task(run)
    includes = ['-I' + str(inside(bundle, item)) for item in include_dirs]
    report = 'reports/iverilog.log'
    sources = (bundle / 'files.f').read_text(encoding='utf-8').splitlines() if (bundle / 'files.f').is_file() else []
    argv = [command, '-g2001', '-Wall', '-tnull', '-s', root['name']] + includes
    file_args = sources if len(subprocess.list2cmdline(argv + sources)) < 24000 else ['-f', 'files.f']
    code, log = run_tool(argv + file_args, bundle, bundle / report)
    if code is None or code < 0 or code >= 0xC0000000:
        status = 'tool_error'
    else:
        status = 'fail' if code or log.strip() else 'pass'
    return dict(status=status, exit_code=code, report=report)


def original_gate(bundle, run, args):
    if not args.vg_python:
        return {'status': 'not_run', 'reason': 'Original VG runtime requires a separate Python >=3.10'}
    script = (Path(args.vg_root).resolve() / 'scripts' / 'python' / 'validation' /
              'generated_deliverable_gate.py')
    contract = {}
    specs = []
    for job in run.generated:
        spec = load(run.current(job, 'plan') / 'spec.json')
        specs.append(spec)
        for item in spec.get('design_requirements', {}).get('parameter_constraints', []):
            previous = contract.setdefault(item['id'], item)
            require(previous == item, 'Incompatible VG parameter constraint IDs across modules')
    root = top_task(run)['name']
    root_spec = dict(next(spec for spec in specs if spec['name'] == root), modules=specs)
    root_spec['design_requirements'] = dict(root_spec.get('design_requirements', {}),
                                           parameter_constraints=list(contract.values()))
    spec_path = 'reports/vg_spec.json'
    report_path = 'reports/vg_gate.json'
    dump(bundle / spec_path, root_spec)
    code, _ = run_tool([args.vg_python, str(script), 'rtl', '--spec', spec_path,
                        '--json', report_path, '--markdown', 'reports/vg_gate.md'],
                       bundle, bundle / 'reports' / 'vg_gate.log')
    report = bundle / report_path
    status = 'tool_error'
    if code in (0, 1) and report.is_file():
        evidence = load(report)
        if evidence.get('version') == 3 and type(evidence.get('delivery_ready')) is bool:
            status = 'pass' if code == 0 and evidence['delivery_ready'] else 'fail'
    return dict(status=status, exit_code=code, report=report_path if report.is_file() else None,
                log='reports/vg_gate.log')


def parser():
    root = argparse.ArgumentParser(description=__doc__)
    commands = root.add_subparsers(dest='action', required=True)
    commands.add_parser('doctor')
    setup = commands.add_parser('prepare')
    setup.add_argument('--request', required=True)
    setup.add_argument('--run', required=True)
    setup.add_argument('--package')
    setup.add_argument('--arch-skill', default=str(DEFAULT_ARCH))
    setup.add_argument('--rules', default=str(DEFAULT_RULES))
    setup.add_argument('--batch-rules', type=int)
    setup.add_argument('--batch-bytes', type=int, default=8192)
    queue = commands.add_parser('next')
    queue.add_argument('--run', required=True)
    queue.add_argument('--limit', type=int, default=8)
    status = commands.add_parser('lint-status')
    status.add_argument('--run', required=True)
    accept = commands.add_parser('accept')
    accept.add_argument('--run', required=True)
    accept.add_argument('--job', required=True)
    accept.add_argument('--stage', choices=STAGES + ('lint',), required=True)
    accept.add_argument('--batch')
    accept.add_argument('--replace', action='store_true')
    delivery = commands.add_parser('publish')
    delivery.add_argument('--run', required=True)
    delivery.add_argument('--output', required=True)
    delivery.add_argument('--iverilog')
    delivery.add_argument('--include-dir', action='append', default=[])
    delivery.add_argument('--vg-python')
    delivery.add_argument('--vg-root', default=str(DEFAULT_VG))
    delivery.add_argument('--partial-lint', action='store_true')
    return root


def execute(args):
    if args.action == 'doctor':
        return {'python': sys.version.split()[0], 'platform': sys.platform,
                'architecture_validator': (DEFAULT_ARCH / 'scripts' / 'archlib.py').is_file(),
                'default_rules': DEFAULT_RULES.is_file(), 'iverilog': shutil.which('iverilog')}
    if args.action == 'prepare':
        require((args.batch_rules is None or args.batch_rules > 0) and args.batch_bytes > 0,
                'Rule batch limits must be positive')
        return prepare(args)
    run = Run(args.run)
    if args.action == 'next':
        require(args.limit > 0, 'Task count must be positive')
        return run.queue(args.limit)
    if args.action == 'lint-status':
        lint = run.lint_report()
        summary = {key: lint[key] for key in ('status', 'counts', 'missing')}
        summary['jobs'] = {job: dict(missing=len(item['missing']),
                                    failed_rules=[row['rule_id'] for row in item['results'] if row['status'] == 'fail'],
                                    accepted_batches=str(run.lint_root / job / item['source_sha256'])
                                    if item['source_sha256'] else None)
                           for job, item in lint['jobs'].items()}
        return summary
    with coordinator_lock(run.root):
        return run.accept(args) if args.action == 'accept' else publish(run, args)


def main():
    args = parser().parse_args()
    try:
        require(sys.version_info[:3] == RUNTIME, 'Requires Python 3.8.10, got ' + sys.version.split()[0])
        result = execute(args)
    except (ValueError, OSError, KeyError, TypeError, ImportError, SyntaxError, subprocess.TimeoutExpired) as exc:
        print('FPGA_RTL_ERROR: ' + str(exc), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False))
    print('FPGA_RTL_OK:' + args.action)
    return 0


if __name__ == '__main__':
    sys.exit(main())
