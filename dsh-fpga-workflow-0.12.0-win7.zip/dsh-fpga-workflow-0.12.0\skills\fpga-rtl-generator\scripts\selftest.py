"""Exercise the coordinator with isolated fixtures, without making model calls."""

import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch

import cli
from inputs import DEFAULT_ARCH, dump, load, sha


class WorkflowTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='fpga-rtl-test-')
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.run = self.root / 'run'
        self.request = self.root / 'request.json'

    def command(self, *args):
        return cli.execute(cli.parser().parse_args([str(arg) for arg in args]))

    def prepare(self, request, *extra):
        dump(self.request, request)
        return self.command('prepare', '--request', self.request, '--run', self.run, *extra)

    def queue(self):
        return self.command('next', '--run', self.run)['ready']

    def accept(self, task, *extra):
        args = ['--batch', task['batch']] if task['action'] == 'lint' else []
        return self.command('accept', '--run', self.run, '--job', task['job'], '--stage', task['action'],
                            *args, *extra)

    def work(self, task, bad_binding=False):
        path = Path(task['work'])
        if task['action'] == 'lint':
            path.parent.mkdir(parents=True, exist_ok=True)
            dump(path, [{'rule_id': rule['id'], 'status': 'unverified', 'evidence': 'coordinator fixture'}
                        for rule in load(Path(task['rules']))])
            return
        path.mkdir(parents=True, exist_ok=True)
        name = task['name']
        if task['action'] == 'plan':
            dump(path / 'requirements.json', {'requirements': ['Combinational pass-through']})
            dump(path / 'codegen_plan.json', {'steps': ['Bind scalar ports']})
            dump(path / 'spec.json', dict(
                name=name, target='rtl', rtl_dialect='verilog', rtl_path='rtl/' + name + '.v',
                design_requirements=dict(confirmed_by_user=True, confirmation_notes='test fixture'),
                interfaces={'ports': [dict(name='i_data', direction='input', width=1, description='Input'),
                                      dict(name='o_data', direction='output', width=1, description='Output')]},
                clock=None, reset=None, behavior=['Pass through'], constraints=[], corner_cases=['Zero'],
                verification_cases=['Zero appears at output'], timing_diagrams=[dict(
                    id='transfer', title='Transfer', scenario='Scalar stimulus', description='Combinational',
                    wavejson={'signal': [{'name': 'i_data', 'wave': '01.0'}]})]))
        elif task['action'] == 'reference':
            (path / 'reference.py').write_text('def evaluate(value):\n    return value\n', encoding='utf-8')
        else:
            card = load(Path(task['task']))
            body = ['module {}(input wire i_data, output wire o_data);'.format(name)]
            if card['children']:
                body.append('wire middle;')
                for number, child in enumerate(card['children']):
                    inputs = ('middle' if bad_binding else 'i_data') if number == 0 else 'middle'
                    output = 'middle' if number == 0 else 'o_data'
                    body.append('{} {}(.i_data({}), .o_data({}));'.format(child['name'], child['instance'], inputs, output))
            else:
                body.append('assign o_data = i_data;')
            (path / (name + '.v')).write_text('\n'.join(body + ['endmodule', '']), encoding='utf-8')

    def finish(self):
        while self.queue():
            for task in self.queue():
                self.work(task)
                self.accept(task)

    @staticmethod
    def request_spec():
        return dict(contract='FPGA-RTL-REQUEST/1.0.0', root='root', project_top='root', modules=[
            dict(uid='root', name='passthrough', mode='generate', requirements='Wire two stages', children=[
                dict(module='first', instance='u_first', parameters={}, connections=dict(i_data='i_data', o_data='middle')),
                dict(module='second', instance='u_second', parameters={}, connections=dict(i_data='middle', o_data='o_data'))]),
            dict(uid='first', name='first_stage', mode='generate', requirements='Pass signal'),
            dict(uid='second', name='second_stage', mode='generate', requirements='Pass signal')])

    def test_direct_resume_revision_and_publish(self):
        prepared = self.prepare(self.request_spec())
        self.assertEqual(prepared['mandatory_rule_count'], 92)
        self.assertEqual(prepared['lint_batch_count'], 8)
        first, second = self.queue()
        self.work(first)
        # A candidate appears again after a session interruption until the coordinator accepts it.
        self.assertEqual(self.queue()[0], first)
        self.accept(first)
        self.assertEqual([task['action'] for task in self.queue()], ['reference', 'plan'])
        self.work(second)
        self.accept(second)
        self.assertEqual(len(self.queue()), 3)
        self.finish()
        run = cli.Run(self.run)
        root_job = next(job for job, task in run.jobs.items() if task['uid'] == 'root')
        task = {'job': root_job, 'name': 'passthrough', 'action': 'rtl', 'task': str(run.task_path(root_job)),
                'work': str(self.run / 'work' / root_job / 'rtl')}
        self.work(task, bad_binding=True)
        with self.assertRaisesRegex(ValueError, 'planned connections'):
            self.accept(task, '--replace')
        self.work(task)
        candidate = Path(task['work']) / 'passthrough.v'
        with candidate.open('a', encoding='utf-8') as stream:
            stream.write('// revised\n')
        self.accept(task, '--replace')
        summary = self.command('lint-status', '--run', self.run)
        self.assertEqual(summary['jobs'][root_job]['missing'], 92)
        self.assertEqual(summary['missing'], 92)
        batches = self.queue()
        self.assertEqual(len(batches), 8)
        self.assertTrue(all(batch['job'] == root_job and batch['action'] == 'lint' for batch in batches))
        self.assertEqual(len({batch['work'] for batch in batches}), 8)
        rule_groups = [load(Path(batch['rules'])) for batch in batches]
        self.assertEqual([len(rules) for rules in rule_groups], [12] * 4 + [11] * 4)
        self.assertEqual(len({rule['id'] for group in rule_groups for rule in group}), 92)
        self.assertTrue(all(Path(batch['rules']).stat().st_size <= 8192 for batch in batches))
        self.work(batches[-1])
        self.accept(batches[-1])
        self.assertEqual(self.queue(), batches[:-1])
        with self.assertRaisesRegex(ValueError, 'Complete lint'):
            self.command('publish', '--run', self.run, '--output', self.root / 'early')
        self.finish()
        bundle = self.root / 'bundle'
        check = self.command('publish', '--run', self.run, '--output', bundle)
        self.assertEqual(check['status'], 'review_required')
        self.assertEqual(check['checks']['iverilog_elaboration']['status'], 'not_run')
        receipt = load(bundle / 'delivery.json')
        self.assertEqual(receipt['source_order'], ['rtl/first_stage.v', 'rtl/second_stage.v', 'rtl/passthrough.v'])
        self.assertEqual(len(receipt['modules']), 3)
        self.assertEqual(load(bundle / 'reports' / 'mandatory_lint.json')['counts']['unverified'], 92 * 3)
        ET.parse(bundle / 'spec' / 'passthrough' / 'waveforms' / 'passthrough_transfer.svg')

    def test_architecture_handoff_and_digest(self):
        scripts = str(DEFAULT_ARCH / 'scripts')
        sys.path.insert(0, scripts)
        try:
            import archlib
        finally:
            sys.path.pop(0)
        architecture = self.root / 'arch'
        architecture.mkdir()
        request = self.request_spec()
        handoff = architecture / 'detailed_design_input.json'
        dump(handoff, dict(contract='FPGA-ARCH-HANDOFF/1.0.0', target={}, interfaces=[], clocks=[], resets=[],
                           effective_requirements=[dict(requirement_uid='R1', revision_uid='R1-v3')],
                           modules=[dict(uid=item['uid'], clock_refs=[], reset_refs=[], issue_refs=[],
                                         requirement_refs=['R1']) for item in request['modules']]))
        manifest = architecture / 'package.json'
        review = architecture / 'review.json'
        dump(review, {'allowed_scope': 'Selected subtree'})
        dump(manifest, dict(artifacts={handoff.name: sha(handoff), review.name: sha(review)}))
        request['contract'] = 'FPGA-RTL-SELECTION/1.0.0'
        request['package_sha256'] = '0' * 64
        with patch.object(archlib, 'validate_package', return_value={'status': 'FROZEN', 'synthetic': False}) as validator:
            with self.assertRaisesRegex(ValueError, 'SHA-256'):
                self.prepare(request, '--package', architecture)
            validator.assert_not_called()
            request['package_sha256'] = sha(manifest)
            self.prepare(request, '--package', architecture)
            validator.assert_called_once_with(architecture)
        self.finish()
        bundle = self.root / 'archive-bundle'
        self.command('publish', '--run', self.run, '--output', bundle)
        receipt = load(bundle / 'delivery.json')
        self.assertEqual(receipt['requirement_trace']['root'][0]['revision_uid'], 'R1-v3')
        self.assertEqual(receipt['package_sha256'], sha(manifest))

    def test_tool_crash_is_not_an_rtl_failure(self):
        from types import SimpleNamespace

        (self.root / 'reports').mkdir()
        state = SimpleNamespace(jobs={'m0001': {'uid': 'root', 'name': 'passthrough', 'mode': 'generate'}},
                                info={'root': 'root'})
        result = SimpleNamespace(returncode=0xC0000005, stdout=b'', stderr=b'')
        with patch.object(cli.subprocess, 'run', return_value=result):
            status = cli.elaborate(self.root, state, 'iverilog', [])
        self.assertEqual(status['status'], 'tool_error')
        self.assertIn('3221225477', (self.root / status['report']).read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
