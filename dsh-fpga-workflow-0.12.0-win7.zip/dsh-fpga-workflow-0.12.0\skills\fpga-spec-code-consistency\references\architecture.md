# 代码架构提取

## 直接读取工程

```json
{
  "mode": "existing_project",
  "project": "D:/project/design.xpr"
}
```

Vivado 只读打开原工程，再通过 Vivado 的 `save_project_as` 在本轮输出目录生成可写副本供 RTL 展开。保留原工程源文件记录和展开时使用的副本路径。从工程读取生效的综合源清单、顶层、器件、文件库、包含路径、宏和 generic，展开后记录实例、工具能提供的属性、顶层端口、网络及端点。结果可能包含原语和网表对象。按需求保留关键实例，并回查源文件核实对应模块、参数应用、端口位宽和时序行为。

Libero 传入 `.prjx`。工具在副本中打开工程、建立层级并尝试导出当前根 SmartDesign 的摘要。已知根组件名时可在配置填写 `component_hint`，另行导出该组件的 Tcl 描述。该字段只选定要导出的组件。根节点以工程内的激活配置为准，核实后才把它写入架构结论。读取摘要、组件导出、生成 HDL 和原始 RTL，补齐相关实例及连线。Libero 2021.1 的组件导出按单个组件使用，跨目录链接、无生成文件或封闭 IP 要显式登记。工具目录中的工程副本与原工程相对链接需要比对，尤其是指向项目目录之外的源文件。

纯 HDL 的 Libero 工程可能没有 SmartDesign 摘要。此时从工程已有的生成配置或综合文件清单核对激活顶层及源集，结合 RTL 取证。无法确认激活根节点时，记录待核实的顶层，保留源码能独立支撑的检查结论。

## 自建工程读取

先用 `inventory` 扫描候选文件，从构建 Tcl、文件清单和源码恢复实际源集、顶层、宏、包含路径、库和参数。读取构建脚本内容来整理配置。用明确的设计顶层向下追踪，排除同名备选实现和未生效的生成文件。若多个候选顶层会改变检查范围，先落实配置选择。

```json
{
  "mode": "temporary_project",
  "source_root": "D:/project/rtl",
  "top": "fpga_top",
  "top_basis": "build.f 声明的综合顶层",
  "configuration_basis": "源码清单沿用 build.f，未发现 TIMEOUT_CYCLES 顶层覆盖，按源码默认值展开",
  "sources": [
    {"path": "pkg/common_pkg.sv", "role": "design"},
    {"path": "fpga_top.sv", "role": "design"},
    {"path": "sub/decoder.vhd", "role": "design", "library": "work", "file_type": "VHDL 2008"},
    {"path": "tb/top_tb.sv", "role": "simulation"}
  ],
  "include_dirs": ["include"],
  "defines": ["MODE=1"],
  "generics": []
}
```

源路径和包含目录相对于 `source_root`。其他配置路径相对于配置 JSON 所在目录。XDC/SDC 若需要参与展开，使用 `constraint` 源集。可选 `tool` 指定工具路径，`timeout_seconds` 默认 600 秒。临时工程可选 `part` 复现构建脚本中的器件环境，缺省时由本机 Vivado 选用已安装器件。器件仅服务于展开。用工具确认哪些器件相关 IP 或原语无法解析，并记录其影响。

## 提取结果与源码补查

`architecture_evidence.json` 包含运行模式、工具、输入配置、观察到的配置、限制和带行号的 `records`。Vivado 成功完成展开和导出时为 `elaborated`，局部缺口保存在 `limits`。展开失败时，`diagnostics` 保留 Vivado 日志中的错误及原始行号。已知顶层和设计源集时，`source_hierarchy` 给出 Verilog/SystemVerilog 实例候选、源码行和找不到定义的模块。先从这些候选查相关路径，逐个确认条件编译、generate 分支、数组范围和连线。Libero 的结果为工程导出和配套源码的证据集合。以 `tool_export` 引用可核对的导出文本行。

从顶层或外部事件出发，从实例端点下钻到参数、状态机、计数器、条件分支和输出。源码补查沿实际实例连接解释信号传播，尚未确定的生成条件保留为条件。按实例路径记录同一模块的不同配置。封闭 IP 以可见端口、已知配置、可信的外部行为证据为止。报告保留已确认结构，未解析对象写入架构限制及关联条目。

原工程里的约束、现有综合和实现报告可作为独立证据。核对报告所属代码版本、构建配置、分析阶段及测量条件。临时 RTL 展开本身只覆盖选定配置的结构和源码可推导的行为。
