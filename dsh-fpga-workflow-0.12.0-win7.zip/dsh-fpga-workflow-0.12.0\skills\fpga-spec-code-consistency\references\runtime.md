# Windows 7 与 DeepSeek Harness 运行接口

目标机使用 Windows 7 SP1、Python **3.8.10** 和 PowerShell **2.0**。Python 脚本只用标准库。可直接交付整个 Skill 目录，Harness 使用已有命令执行接口调用，不需要另装 Python 包或 Node 运行脚本。

如果 Harness 支持可执行文件和参数数组，直接调用实际的 Python 路径，并将 `-B`、`scripts/cli.py`、动作及参数逐项传入。也可以使用 PowerShell 2.0 包装器。下面是命令形式示例，路径按实际部署替换。

DeepSeek Harness 0.2.2-rc.3 的 headless 工具将 PowerShell 执行暴露为 `pwsh`。调用时传入 `command` 和用于显示用途的 `description`。其他版本以宿主实际公布的工具和参数为准。

```powershell
$env:FPGA_PYTHON38 = 'C:\Python38\python.exe'
$env:FPGA_VIVADO = 'C:\Xilinx\Vivado\2019.2\bin\vivado.bat'
& 'D:\skills\fpga-spec-code-consistency\scripts\run.ps1' doctor
```

`FPGA_LIBERO` 可指定本机 `libero.exe`。工具优先取架构配置的 `tool`，然后是环境变量，最后查 PATH。PowerShell 包装器是 ASCII，JSON、Markdown 和文本输入采用 UTF-8。旧工具出现路径问题时，先缩短输出路径，使用本机短的普通目录；对中文路径的支持以目标机实际工具结果为准。

| 动作 | 参数 | 产物 |
|---|---|---|
| `doctor` | 无 | 本次 Python 与系统版本、工具路径发现结果 |
| `prepare` | `--input` 规格文件 `--output` 新目录 | `structure.json`，标准输出包含规格文件 SHA-256 |
| `inventory` | `--root` 源码目录 `--output` 新 JSON 路径 | 源码、约束、仿真文件和构建文件候选清单 |
| `source-view` | `--input` 源码文件 `--output` 新文件 | 与证据校验器解码一致的 UTF-8 阅读副本，保留原行号和源摘要 |
| `architecture` | `--config` 配置 JSON `--output` 新目录 | `architecture_evidence.json`、可取得的工具导出及日志，标准输出包含工程证据 SHA-256 |
| `check` | `--structure` 结构 JSON `--architecture` 工程证据 JSON `--review` 审查模型 JSON | 与出报告相同的校验，无需输出目录。通过时返回条目和原文元素数量 |
| `report` | `--structure` 结构 JSON `--architecture` 工程证据 JSON `--review` 审查模型 JSON `--output` 新目录 | `report.md`（设计师主报告）、`report-evidence.md`（逐条证据）、`report.json` |

每次调用同时核对退出码和 `FPGA_SPEC_CODE_OK:<action>`，以及返回路径内的本轮产物。CLI 成功表示动作完成。工程提取的 `status` 和需求判定分开读取，`partial` 或 `unavailable` 时按受影响条目留出证据缺口。保留工具运行目录供复核，临时工程也在该目录内。

## 仅文件工具时的复用和交接

由能运行工具的执行方确认规格和 HDL 版本，以及工程证据采集配置，再提供 `structure.json`、`architecture_evidence.json` 和后者的 SHA-256。审查模型采用 `structure.json` 中的 `source.sha256` 与提供的工程证据摘要。逐项回查当前源码。工程证据中的 `source_hierarchy` 是候选位置索引。

宿主读取非 UTF-8 源码失败时，执行方可以用 `source-view` 提供阅读副本，审查模型的证据路径及行号仍指向原文件。模型提交后执行方先运行 `check`，据此修正引文和清点，再运行 `report`。

在 Win7 SP1 64 位目标机可从 Vivado 2019.2、Libero SoC 2021.1 验证。以本机工具能打开目标工程、能展开关键 RTL、能使用所需设备和 IP 库为准。验收时各跑一套原 Vivado 工程、原 Libero 工程和无原工程的源码，并通过 Harness 打开两种报告，核对条目和源文件位置。
