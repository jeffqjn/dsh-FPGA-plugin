import argparse
import json
from pathlib import Path
import platform
import sys
import zipfile
from xml.etree.ElementTree import ParseError

from architecture import collect, inventory, tool_path
from extract import extract
from report import publish, validate
from support import digest, existing, inside, load, read_source, require, save


def arguments():
    parser = argparse.ArgumentParser(description="FPGA specification and implementation review")
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("doctor")
    for name, inputs in (
        ("prepare", ("input",)), ("inventory", ("root",)), ("source-view", ("input",)),
        ("architecture", ("config",)), ("check", ("structure", "architecture", "review")),
        ("report", ("structure", "architecture", "review")),
    ):
        command = commands.add_parser(name)
        for argument in inputs + (() if name == "check" else ("output",)):
            command.add_argument("--" + argument, required=True, type=Path)
    return parser.parse_args()


def execute(args):
    cwd = Path.cwd()
    if args.action == "doctor":
        tools = {name: tool_path(name, None, cwd) for name in ("vivado", "libero")}
        return {"python": sys.version.split()[0], "os": platform.platform(),
                "tools": {name: str(path) if path else None for name, path in tools.items()}}
    if args.action == "check":
        result = validate(args.structure.resolve(), args.architecture.resolve(), args.review.resolve())
        return {"requirements": len(result["requirements"]), "elements": len(result["inventory"]),
                "counts": result["counts"]}
    output = args.output.resolve()
    require(not output.exists(), "输出路径须为新路径 " + str(output))
    if args.action == "source-view":
        source = existing(args.input, cwd)
        sha = digest(source)
        view = read_source(source)
        require(sha == digest(source), "源码在读取期间变化 " + str(source))
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x", encoding="utf-8", newline="") as stream:
            stream.write(view)
        return {"source": str(source), "view": str(output), "sha256": sha}
    if args.action == "prepare":
        source = existing(args.input, cwd)
        sha = digest(source)
        archive = extract(source, "specification", "artifact:specification")
        require(sha == digest(source), "需求规格在抽取期间变化")
        output.mkdir(parents=True)
        path = output / "structure.json"
        save(path, {"source": {"name": source.name, "sha256": sha}, "archive": archive})
        return {"structure": str(path), "elements": len(archive["elements"]), "sha256": sha}
    if args.action == "inventory":
        root = existing(args.root, cwd, directory=True)
        require(not inside(output, root), "清单须输出到源码目录之外")
        files = inventory(root)
        output.parent.mkdir(parents=True, exist_ok=True)
        save(output, {"root": str(root), "files": files})
        return {"inventory": str(output), "files": len(files)}
    if args.action == "architecture":
        config_path = existing(args.config, cwd)
        result = collect(load(config_path), config_path.parent, output)
        path = output / "architecture_evidence.json"
        return {"architecture": str(path), "sha256": digest(path), "status": result["status"]}
    require(args.action == "report", "未知操作")
    counts = publish(args.structure.resolve(), args.architecture.resolve(), args.review.resolve(), output)
    return {"report": str(output / "report.md"), "evidence": str(output / "report-evidence.md"),
            "json": str(output / "report.json"), "counts": counts}


def main():
    args = arguments()
    try:
        require(sys.version_info[:3] == (3, 8, 10), "PYTHON_RUNTIME_MISMATCH: Python 3.8.10 is required")
        result = execute(args)
    except (OSError, ValueError, KeyError, TypeError, ParseError, zipfile.BadZipFile) as error:
        print(json.dumps({"action": args.action, "error": str(error)}, ensure_ascii=True), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=True))
    print("FPGA_SPEC_CODE_OK:" + args.action)
    return 0


if __name__ == "__main__":
    sys.exit(main())
