"""附录C/D固定技术要素检查表：要素行取自模板，是否适用/是否符合由执行Agent按冻结来源判定。"""
import json
import re

from .base import SKILL, Failure, load, require
from . import template_layout


ASSET = SKILL / "assets/assurance/技术要素检查表.json"
CONTRACT = "reqspec-assurance-checklist/1.0"
SECTIONS = ("C", "D")
# 模板把“是否适用/是否符合/检查结果”三列合并为“设计师检查要点”分组表头。
GROUP_LABEL = "设计师检查要点"
APPLICABILITY = ("适用", "不适用", "不涉及")
CONFORMITY = ("符合", "不符合", "待确认")
NOT_CONFORMED = "—"
# 判定行：< !-- assurance-item:{"key":"C1","applicable":"适用",...} -- >
CONTROL = re.compile(r"^<!--\s*assurance-item:(\{.*\})\s*-->$")
RESULT_COLUMN = "检查结果（落实文件、章节号和内容简述）"
SIGNOFF_COLUMNS = ("配置项级软件产品保证工程师验证结果",)
NOTES = {
    "C": "本表按1-52模板通用技术要素清单生成，共{table}项；“检查项”“落实文件”两列取自模板，"
         "“是否适用”“是否符合”“检查结果”按冻结交接包逐项判定并列出所在章节。"
         "“配置项级软件产品保证工程师验证结果”由配置项级产保工程师签署。",
    "D": "本表按1-52模板专用技术要素清单生成，共{table}项；“检查项”“落实文件”两列取自模板，"
         "“是否适用”“是否符合”“检查结果”按冻结交接包逐项判定并列出所在章节。"
         "“配置项级软件产品保证工程师验证结果”由配置项级产保工程师签署。",
}


def checklist():
    data = load(ASSET)
    require(data.get("contract") == CONTRACT, "ASSURANCE_CHECKLIST_CONTRACT_INVALID: " + str(ASSET))
    require(data.get("group_label") == GROUP_LABEL, "ASSURANCE_GROUP_LABEL_CHANGED: " + str(data.get("group_label")))
    sections = data.get("sections") or {}
    for number in SECTIONS:
        entry = sections.get(number)
        require(isinstance(entry, dict), "ASSURANCE_CHECKLIST_SECTION_MISSING: 附录" + number)
        rows = entry.get("rows")
        require(isinstance(rows, list) and rows, "ASSURANCE_CHECKLIST_EMPTY: 附录" + number)
        for row in rows:
            require(all(isinstance(row.get(field), str) and row[field].strip() for field in ("category", "name", "item", "document")),
                    "ASSURANCE_CHECKLIST_ROW_INVALID: 附录" + number + " " + str(row.get("name")))
            require(isinstance(row.get("checkpoint", ""), str), "ASSURANCE_CHECKLIST_ROW_INVALID: 附录" + number + " " + str(row.get("name")))
    return sections


def items(number):
    """Stable item keys C1..C18 / D1..D6 in template order."""
    return [(number + str(index), row) for index, row in enumerate(checklist()[number]["rows"], 1)]


def plan_sections(model):
    return next((v["sections"] for v in model["document_views"] if v["role"] == "writer_plan"), [])


def judgements(section):
    """Parse the Agent's per-item judgement lines; free prose is not accepted here."""
    number = section["number"]
    known = {key for key, _ in items(number)}
    result = {}
    for paragraph in section["paragraphs"]:
        line = paragraph.strip()
        if not line:
            continue
        match = CONTROL.match(line)
        require(match is not None,
                "ASSURANCE_SECTION_PROSE_NOT_ALLOWED: 附录" + number
                + " 只接受逐项判定行 <!-- assurance-item:{...} -->，不接受自写段落：" + line[:40])
        try:
            payload = json.loads(match.group(1))
        except ValueError as error:
            raise Failure("ASSURANCE_ITEM_INVALID: 附录" + number + " " + str(error))
        require(isinstance(payload, dict), "ASSURANCE_ITEM_INVALID: 附录" + number)
        key = payload.get("key")
        require(key in known, "ASSURANCE_ITEM_UNKNOWN_KEY: " + str(key))
        require(key not in result, "ASSURANCE_ITEM_DUPLICATE_KEY: " + str(key))
        applicable, conform = payload.get("applicable"), payload.get("conform")
        require(applicable in APPLICABILITY, "ASSURANCE_ITEM_APPLICABILITY_INVALID: " + str(key) + " " + str(applicable))
        cited = payload.get("sections") or []
        require(isinstance(cited, list) and all(isinstance(value, str) and value.strip() for value in cited),
                "ASSURANCE_ITEM_SECTIONS_INVALID: " + str(key))
        text = payload.get("result")
        require(isinstance(text, str) and text.strip(), "ASSURANCE_ITEM_RESULT_REQUIRED: " + str(key))
        if applicable == "适用":
            require(conform in CONFORMITY, "ASSURANCE_ITEM_CONFORMITY_INVALID: " + str(key) + " " + str(conform))
            require(bool(cited), "ASSURANCE_ITEM_SECTIONS_REQUIRED: " + str(key))
        else:
            require(conform == NOT_CONFORMED, "ASSURANCE_ITEM_CONFORMITY_MUST_BE_DASH: " + str(key))
        result[key] = {"applicable": applicable, "conform": conform, "sections": list(cited), "result": text.strip()}
    return result


def _cite(key, entry, status):
    for number in entry["sections"]:
        require(number in status and number not in SECTIONS,
                "ASSURANCE_SECTION_UNKNOWN: " + key + " 引用不存在的章节 " + number)
        if entry["conform"] == "符合":
            require(status[number] == "present",
                    "ASSURANCE_SECTION_NOT_SUBSTANTIVE: " + key + " " + number
                    + " 的系统状态为" + str(status[number]) + "，不能作为“符合”的依据")
    # 章节号统一由脚本补在检查结果前；原文已以章节号开头时不重复。
    prefix = "、".join(entry["sections"])
    text = entry["result"]
    return prefix + "：" + text if prefix and not text.startswith(prefix) else text


def column_values(number, columns, section, model):
    """Fill every cell except the product-assurance sign-off column."""
    supported = set(template_layout.ASSURANCE_COLUMNS)
    require(set(columns) <= supported, "ASSURANCE_COLUMNS_UNSUPPORTED: " + str(sorted(set(columns) - supported)))
    judged = judgements(section)
    status = {item["number"]: item["status"] for item in plan_sections(model)}
    rows = []
    for index, (key, row) in enumerate(items(number), 1):
        entry = judged.get(key)
        if entry is None:
            cells = {"是否适用": "待确认", "是否符合": NOT_CONFORMED, RESULT_COLUMN: "未提交本项判定，见生成检查报告。"}
        else:
            cells = {"是否适用": entry["applicable"], "是否符合": entry["conform"], RESULT_COLUMN: _cite(key, entry, status)}
        values = dict.fromkeys(SIGNOFF_COLUMNS, "")
        values.update({"序号": index, "要素类别": row["category"], "要素名称": row["name"], "检查项": row["item"],
                       "落实文件": row["document"]})
        values.update(cells)
        rows.append([values[column] for column in columns])
    return rows


def counts(model):
    """Tally used by the generation report."""
    tally = {name: 0 for name in APPLICABILITY}
    tally.update({name: 0 for name in CONFORMITY})
    tally["未提交"] = 0
    for section in plan_sections(model):
        if section["number"] not in SECTIONS:
            continue
        judged = judgements(section)
        for key, _ in items(section["number"]):
            entry = judged.get(key)
            if entry is None:
                tally["未提交"] += 1
                continue
            tally[entry["applicable"]] += 1
            if entry["applicable"] == "适用":
                tally[entry["conform"]] += 1
    return tally


def warnings(model):
    if not template_layout.enabled(model):
        return []
    notes = []
    for section in plan_sections(model):
        if section["number"] not in SECTIONS:
            continue
        judged = judgements(section)
        for key, row in items(section["number"]):
            entry = judged.get(key)
            if entry is None:
                notes.append("附录" + section["number"] + " " + row["name"] + "（" + key + "）：未提交判定。")
            elif entry["conform"] in ("不符合", "待确认"):
                notes.append("附录" + section["number"] + " " + row["name"] + "（" + key + "）："
                             + entry["conform"] + "；" + entry["result"])
    return notes


def note(number):
    total = len(checklist()[number]["rows"])
    return NOTES[number].replace("{table}", str(total))
