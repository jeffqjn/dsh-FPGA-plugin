"""Deterministic checks complement (never replace) Agent semantic judgments."""
import copy
import re
from decimal import Decimal
from pathlib import Path

from . import contract
from .base import Failure, gate, load, now, require, schema_model, uid

def inherited_model(attempt):
    manifest_path = Path(attempt) / "inherited/package.json"
    if not manifest_path.exists():
        return None
    manifest = load(manifest_path)
    art = next(a for a in manifest["artifacts"] if a["uid"] == manifest["model_artifact_uid"])
    return load(Path(attempt) / "inherited" / art["path"])

def ensure_frozen(model, attempt, info):
    parent = inherited_model(attempt)
    require(model["protocol"]["run_uid"] == info["run_uid"], "RUN_ID_CHANGED")
    if parent:
        require(model["source_baseline"] == parent["source_baseline"], "SOURCE_BASELINE_MUTATED")
        if info["kind"] == "writer":
            require(all(model[key] == parent[key] for key in ("requirements", "analysis", "verification", "acronyms")),
                    "WRITER_NORMATIVE_BASELINE_CHANGED: writer may organize the frozen model, not revise engineering facts or identifiers")
            for field, old in parent["basic_info"].items():
                if old["status"] == "present":
                    require(model["basic_info"][field] == old, "WRITER_NORMATIVE_BASELINE_CHANGED: basic_info/" + field)
        prior_constraints = {c["uid"]: c for c in parent["analysis"]["constraints"]}
        current = {c["uid"]: c for c in model["analysis"]["constraints"]}
        require(all(current.get(k) == v for k, v in prior_constraints.items()), "HISTORICAL_CONSTRAINT_MUTATED: create a new UID for changed content")
        source_revs = {r["uid"]: [v for v in r["revisions"] if v["basis"] == "source"] for r in parent["requirements"]}
        current_reqs = {r["uid"]: r for r in model["requirements"]}
        for req_uid, revisions in source_revs.items():
            require(req_uid in current_reqs and all(v in current_reqs[req_uid]["revisions"] for v in revisions), "SOURCE_LEDGER_LOST: " + req_uid)
        archives = {a["uid"]: a for a in model["document_archive"]}
        require(all(archives.get(a["uid"]) == a for a in parent["document_archive"] if a["role"] != "specification"), "SOURCE_ARCHIVE_MUTATED")
    for relative in info.get("extracted_archives", []):
        frozen = load(Path(attempt) / relative)
        current = next((a for a in model["document_archive"] if a["uid"] == frozen["uid"]), None)
        require(current == frozen, "ARCHIVE_FACTS_MUTATED: annotations belong in provenance/inventory, not extracted text")
        if frozen["extraction_status"] != "complete":
            require(any(i["type"] == "EXTRACTION_INCOMPLETE" and i["status"] == "open" and i["blocking"] for i in model["consistency"]["issues"]),
                    "PARTIAL_EXTRACTION: requires an open blocking EXTRACTION_INCOMPLETE issue; provide a verified text transcript and prepare again")
    all_elements = {e["uid"]: e for a in model["document_archive"] for e in a["elements"]}
    evidence = {e["uid"]: e for e in model["consistency"]["evidence"]}
    for item in model["spec_items"]:
        require(item["element_refs"] and all(r in all_elements for r in item["element_refs"]), "SPEC_ITEM_WITHOUT_ACTUAL_EVIDENCE")
    for inv in model["completeness"]["content_inventory"]:
        require(inv["disposition"] != "pending" or any(g["blocking_for"] for g in model["completeness"]["gaps"]), "PENDING_CONTENT_WITHOUT_ENGINEERING_GAP")
        if inv["normative"] is True:
            require(inv["disposition"] not in ("descriptive_only", "historical"), "NORMATIVE_CONTENT_DISCARDED")
    for entry in model["consistency"]["provenance"]:
        require(entry["field_path"].startswith("/") or entry["field_path"] == "", "INVALID_JSON_POINTER")
    if info.get("user_decisions_artifact_uid"):
        user_records = load(Path(attempt) / "inputs/user_decisions.json")
        require(isinstance(user_records, list), "USER_DECISIONS_INPUT: expected array of full decision records")
    else:
        user_records = []
    inherited_decisions = parent["consistency"]["decisions"] if parent else []
    history_file = Path(attempt) / "inputs/previous_state.json"
    if history_file.exists():
        inherited_decisions += load(history_file).get("decisions", [])
    for decision in model["consistency"]["decisions"]:
        if decision not in inherited_decisions:
            require(decision in user_records, "UNSUPPORTED_DECISION: supply exact user decision record with prepare --decisions")
            require(any(evidence.get(e, {}).get("artifact_uid") == info.get("user_decisions_artifact_uid") for e in decision["user_evidence_refs"]), "DECISION_EVIDENCE_NOT_BOUND")
    # No conflicting active approvals for the same object/field unless explicitly superseded.
    approvals = [d for d in model["consistency"]["decisions"] if d["status"] == "active" and d["kind"] == "approve_change"]
    for index, one in enumerate(approvals):
        for two in approvals[index + 1:]:
            overlap = {o["uid"] for o in one["object_refs"]} & {o["uid"] for o in two["object_refs"]}
            if overlap and set(one["field_paths"]) & set(two["field_paths"]):
                superseded = one["uid"] in two["supersedes"] and two["before"] == one["after"] or two["uid"] in one["supersedes"] and one["before"] == two["after"]
                require(superseded or one["after"] == two["after"], "CONFLICTING_ACTIVE_APPROVALS: explicitly supersede the previous decision")

def merge_previous(model, attempt):
    path = Path(attempt) / "inputs/previous_state.json"
    if not path.exists():
        return
    previous = load(path)
    require(previous.get("baseline_uid") == model["protocol"]["baseline_uid"], "HISTORY_BASELINE_MISMATCH")
    old = {i["stable_key"]: i for i in previous["issues"]}
    new = {i["stable_key"]: i for i in model["consistency"]["issues"]}
    require(len(new) == len(model["consistency"]["issues"]), "DUPLICATE_STABLE_KEY")
    require(set(old).issubset(new), "HISTORY_ISSUE_OMITTED: explicitly recheck and close each prior issue")
    model["consistency"]["round"] = previous["round"] + 1
    for key, issue in new.items():
        if key not in old:
            continue
        prior = old[key]
        require(issue["uid"] == prior["uid"] and issue["display_id"] == prior["display_id"], "ISSUE_ID_CHANGED")
        require(issue["history"][:len(prior["history"])] == prior["history"], "ISSUE_HISTORY_TRUNCATED")
        if prior["evidence_fingerprint"] != issue["evidence_fingerprint"] and issue["status"] in ("ignored", "confirmed"):
            decisions = [d for d in model["consistency"]["decisions"] if d["status"] == "active" and d["uid"] in issue["decision_refs"]]
            if not any(d["target_fingerprint"] == issue["evidence_fingerprint"] for d in decisions):
                issue["history"].append({"round": model["consistency"]["round"], "at": now(), "from_status": issue["status"], "to_status": "open", "reason": "内容指纹变化，旧处置不自动适用", "decision_refs": []})
                issue["status"] = "open"
        issue["first_seen_round"] = prior["first_seen_round"]
        issue["last_seen_round"] = model["consistency"]["round"]

def source_quality(model):
    require(model["source_baseline"]["atomic_requirements"], "EMPTY_BASELINE: Agent must identify all actual source obligations")
    assessments(model, "taskbook")
    require(model["consistency"]["decisions"] == [], "TASKBOOK_CANNOT_APPROVE_SOURCE_CHANGES: update source input instead")
    require(len([v for v in model["document_views"] if v["role"] == "writer_plan"]) == 1, "TASKBOOK_WRITER_HANDOFF_PLAN_REQUIRED")
    plan = next(v for v in model["document_views"] if v["role"] == "writer_plan")
    placed = [r for s in plan["sections"] for r in s["primary_requirement_refs"]]
    deferred = {r for s in plan["sections"] if s["handling"] in ("deferred", "manual") for r in s["cross_requirement_refs"]}
    active = {r["uid"] for r in model["requirements"] if r["lifecycle"] == "active"}
    require(len(placed) == len(set(placed)) and set(placed).isdisjoint(deferred) and set(placed) | deferred == active,
            "WRITER_HANDOFF_REQUIREMENT_PLACEMENT: each active obligation needs exactly one main or deferred/manual placement")
    for atom in model["source_baseline"]["atomic_requirements"]:
        require(atom["semantic"]["evidence_refs"], "SOURCE_ATOM_EVIDENCE_MISSING")
    for req in model["requirements"]:
        for tp in model["verification"]["source_test_points"]:
            if tp["completeness"] == "complete":
                require(all(isinstance(tp.get(k), str) and tp[k].strip() for k in ("object", "purpose", "stimulus", "procedure", "expected_result", "pass_criteria"))
                        and tp["requirement_refs"] and not tp["missing_fields"],
                        "TEST_POINT_INCOMPLETE: completeness=complete contradicts required stimulus/procedure/criteria fields: " + tp["uid"])
        tests = [tp for tp in model["verification"]["source_test_points"] if req["uid"] in tp["requirement_refs"] and tp["completeness"] == "complete"]
        activities = [o for o in model["verification"]["obligations"] if o["requirement_uid"] == req["uid"] and o["criterion_refs"]]
        if not tests and not activities:
            require(any(i["blocking"] and i["status"] == "open" and i["type"] in ("UNCOVERED_REQUIREMENT", "INSUFFICIENT_TEST_TYPES") and any(o["uid"] == req["uid"] for o in i["object_refs"]) for i in model["consistency"]["issues"]),
                    "SOURCE_COVERAGE_GAP_REQUIRES_ISSUE: " + req["uid"])
    local = gate(model)["local"]
    model["source_baseline"]["status"] = local
    model["source_baseline"]["upstream_issue_refs"] = [i["uid"] for i in model["consistency"]["issues"]]
    gate(model)

def revision_checks(model):
    decisions = {d["uid"]: d for d in model["consistency"]["decisions"] if d["status"] == "active"}
    prefix = model["basic_info"]["numbering_prefix"]
    categories = {"function": "FREQ", "interface": "IREQ", "performance": "PREQ", "safety": "SREQ", "reliability": "RREQ"}
    for req in model["requirements"]:
        versions = {v["uid"]: v for v in req["revisions"]}
        ordinals = [v["ordinal"] for v in versions.values()]
        require(len(ordinals) == len(set(ordinals)), "DUPLICATE_REVISION_ORDINAL")
        for rev in versions.values():
            prior_uid = rev["supersedes_revision_uid"]
            require(prior_uid is None or prior_uid in versions and versions[prior_uid]["ordinal"] < rev["ordinal"], "REVISION_CHAIN_INVALID")
            if rev["basis"] == "approved_change":
                approvals = [decisions[d] for d in rev["decision_refs"] if d in decisions and decisions[d]["kind"] == "approve_change"]
                require(any(any(o["uid"] == req["uid"] for o in d["object_refs"]) and d["after"] == rev["semantic"] and (
                    d["operation"] == "add" and not req["source_atomic_refs"] and prior_uid is None or
                    d["operation"] == "modify" and prior_uid is not None and d["before"] == versions[prior_uid]["semantic"]) for d in approvals), "CHANGE_BEFORE_AFTER_OR_TARGET_INVALID")
        if not req["source_atomic_refs"]:
            require(any(v["basis"] == "approved_change" and any(d in decisions and decisions[d]["operation"] == "add" for d in v["decision_refs"]) for v in versions.values()), "NEW_REQUIREMENT_WITHOUT_APPROVED_ADD")
        if req["lifecycle"] == "deleted_approved":
            require(any(d in decisions and decisions[d]["kind"] == "approve_change" and decisions[d]["operation"] == "delete" and any(o["uid"] == req["uid"] for o in decisions[d]["object_refs"]) and any(decisions[d]["before"] == v["semantic"] for v in versions.values()) for d in req["decision_refs"]), "DELETION_WRONG_TARGET_OR_BEFORE")
        if req["normalized_id"] and req["effective_revision_uid"]:
            sem = versions[req["effective_revision_uid"]]["semantic"]
            expected_attributes = "".join(a for a in "KNMR" if a in sem["attributes"])
            match = re.fullmatch(r"(.+)-(FREQ|IREQ|PREQ|SREQ|RREQ|OREQ)-([1-9][0-9]*)(?:-([KNMR]+))?", req["normalized_id"])
            require(match is not None and (match.group(4) or "") == expected_attributes and match.group(2) == categories.get(req["category"], "OREQ"), "NORMALIZED_ID_CATEGORY_OR_ATTRIBUTES_INVALID")
            if prefix["status"] == "present":
                require(match.group(1) == prefix["value"], "NORMALIZED_ID_PREFIX_INVALID")
    for c in model["analysis"]["constraints"]:
        value = c["value"]
        if c["operator"] == "range":
            require(value is not None and value["kind"] == "interval", "INTERVAL_VALUE_REQUIRED")
            low, high = value["lower"], value["upper"]
            require(low is not None or high is not None, "INTERVAL_BOTH_BOUNDS_UNKNOWN")
            if low and high:
                require(low["unit"] == high["unit"] and low["dimension"] == high["dimension"], "INTERVAL_BOUND_UNITS_DIFFER: normalize explicitly")
                require(Decimal(low["decimal"]) <= Decimal(high["decimal"]), "INTERVAL_REVERSED")
                if Decimal(low["decimal"]) == Decimal(high["decimal"]):
                    require(value["lower_inclusive"] and value["upper_inclusive"], "EMPTY_OPEN_INTERVAL")
        if c["operator"] == "in":
            require(value is not None and value["kind"] == "enumeration", "ENUMERATION_VALUE_REQUIRED")
        require(c["normalized"] is None or bool(c["normalization_basis"]), "NORMALIZATION_BASIS_REQUIRED")

def checker_quality(model):
    assessments(model, "checker")
    spec_archives = [a for a in model["document_archive"] if a["role"] == "specification"]
    require(len(spec_archives) == 1, "CURRENT_SPECIFICATION_ARCHIVE_REQUIRED")
    from .realization import reconcile_realization
    reconcile_realization(model)
    for req in model["requirements"]:
        if req["effective_alignment"] != "complete" and req["lifecycle"] == "active":
            require(any(any(o["uid"] == req["uid"] for o in issue["object_refs"]) and issue["type"] in ("REQ_MISSING", "REQ_PARTIAL", "DEVIATION", "MAPPING_UNRESOLVED") for issue in model["consistency"]["issues"]),
                    "UNREALIZED_REQUIREMENT_WITHOUT_ISSUE: " + req["uid"])
    for item in model["spec_items"]:
        if not item["source_atomic_refs"]:
            require(any(d["status"] == "active" and d["kind"] == "approve_change" and d["operation"] == "add" and any(o["uid"] == item["uid"] or o["uid"] in [r["uid"] for r in model["requirements"] if item["uid"] in r["spec_item_refs"]] for o in d["object_refs"]) for d in model["consistency"]["decisions"]) or
                    any(i["type"] == "NEW_KEY" and i["status"] == "open" and any(o["uid"] == item["uid"] for o in i["object_refs"]) for i in model["consistency"]["issues"]), "UNAPPROVED_NEW_SPEC_ITEM")
    for issue in model["consistency"]["issues"]:
        if issue["status"] == "ignored":
            require(issue["waivable"] and issue["type"] not in ("INPUT_INVALID", "BASELINE_MISMATCH", "EXTRACTION_INCOMPLETE", "REFERENCE_INVALID", "MAPPING_UNRESOLVED", "NEW_KEY", "INTERNAL_CONFLICT"), "ISSUE_NOT_WAIVABLE")
            target_uids = {o["uid"] for o in issue["object_refs"]}
            require(any(d["status"] == "active" and d["kind"] == "waive_issue" and d["uid"] in issue["decision_refs"]
                        and issue["uid"] in d["issue_refs"] and d["target_fingerprint"] == issue["evidence_fingerprint"]
                        and target_uids.issubset({o["uid"] for o in d["object_refs"]})
                        and set(issue["field_paths"]).issubset(d["field_paths"])
                        for d in model["consistency"]["decisions"]), "WAIVER_SCOPE_OR_FINGERPRINT_INVALID")
    from .base import effective
    effective(model)
    return gate(model)

def assessments(model, stage):
    from .base import SCHEMAS
    entries = [x["payload"] for x in model["extensions"] if x["namespace"] == "feip.assessments.v1" and x["payload"].get("stage") == stage]
    require(len(entries) == 1, "RULE_ASSESSMENTS_REQUIRED: " + stage)
    schema = load(SCHEMAS / "assessments.schema.json")
    errors = contract.validate_schema(entries[0], schema)
    require(not errors, "RULE_ASSESSMENTS_SCHEMA_INVALID: " + str(errors))
    expected = set(["STR-{0:03d}".format(i) for i in range(1, 11)] + ["REQ-{0:03d}".format(i) for i in range(1, 9)] +
        ["CON-{0:03d}".format(i) for i in range(1, 7)] + ["TST-{0:03d}".format(i) for i in range(1, 7)]) if stage == "taskbook" else set([
        "INP-001", "INP-002", "EXT-001", "MAP-001", "REQ-001", "REQ-002", "REQ-003", "SIG-001", "TST-001", "IDN-001", "SAF-001", "CLK-001", "CON-001", "CLR-001", "NTC-001"])
    records = entries[0]["rules"]
    require(len(records) == len(expected) and {r["rule_id"] for r in records} == expected, "RULE_ASSESSMENTS_INCOMPLETE")
    evidence = {e["uid"] for e in model["consistency"]["evidence"]}
    issues = {i["uid"] for i in model["consistency"]["issues"]}
    for row in records:
        require(set(row["evidence_refs"]).issubset(evidence) and set(row["issue_refs"]).issubset(issues), "ASSESSMENT_REFERENCE_INVALID")
        require(row["rationale"].strip() and row["rationale"] != "待Agent检查", "ASSESSMENT_RATIONALE_REQUIRED")
        if row["status"] in ("fail", "unknown"):
            require(row["issue_refs"], "FAILING_OR_UNKNOWN_RULE_WITHOUT_ISSUE: " + row["rule_id"])
        else:
            require(row["evidence_refs"], "PASS_OR_NA_RULE_WITHOUT_EVIDENCE: " + row["rule_id"])

def state(model):
    return {"contract": "feip-review-state/1.0", "baseline_uid": model["protocol"]["baseline_uid"], "round": model["consistency"]["round"],
        "issues": copy.deepcopy(model["consistency"]["issues"]), "decisions": copy.deepcopy(model["consistency"]["decisions"]),
        "identities": [{"requirement_uid": r["uid"], "spec_item_refs": r["spec_item_refs"]} for r in model["requirements"]]}

def report(model, title):
    gates = model["consistency"]["gates"]
    lines = ["# " + title, "", "- FEIP：1.0.0", "- 门禁：" + gates["overall"], "- 含批准差异/豁免：" + str(gates["has_exceptions"]),
        "- 轮次：" + str(model["consistency"]["round"]), "- 交付状态：" + gates["delivery_state"], "", "## 待办事项", ""]
    lines += ["- {0}：{1}（required={2}, status={3}）".format(t["uid"], t["description"], t["required"], t["status"]) for t in model["consistency"]["todos"]] or ["无待办事项。"]
    lines += ["", "## 问题及闭环", ""]
    for issue in model["consistency"]["issues"]:
        lines += ["### {0} {1}".format(issue["display_id"], issue["summary"]), "", "- 类型/状态：" + issue["type"] + " / " + issue["status"],
            "- 依据：" + ", ".join(issue["basis_refs"]), "- 当前证据：" + ", ".join(issue["current_refs"]), "- 影响：" + issue["impact"], "- 建议：" + issue["suggestion"], ""]
    lines += ["## 源/有效需求落实", ""]
    lines += ["- {0}：{1}/{2}，rate={3}".format(m["name"], m["covered"], m["total"], m["rate"]) for m in model["traceability"]["metrics"]]
    lines += ["", "## 逐项规则判断", "", "| 阶段 | 规则 | 状态 | 判断依据 | 证据 | 问题 |", "| --- | --- | --- | --- | --- | --- |"]
    for ext in model["extensions"]:
        if ext["namespace"] == "feip.assessments.v1":
            for row in ext["payload"]["rules"]:
                values = (ext["payload"]["stage"], row["rule_id"], row["status"], row["rationale"], ",".join(row["evidence_refs"]), ",".join(row["issue_refs"]))
                lines.append("| " + " | ".join(str(v).replace("|", "\\|").replace("\n", "<br>") for v in values) + " |")
    lines += ["", "## 当前有效要求与分析", ""]
    for req in model["requirements"]:
        lines += ["- {0} / {1}：{2}，B0={3}，B1={4}".format(req["uid"], req["normalized_id"], req["title"], req["source_alignment"], req["effective_alignment"])]
    lines += ["", "## 批准差异和豁免", ""]
    lines += ["- {0} {1}/{2}：{3}；确认人：{4}；用户原话：{5}".format(d["uid"], d["kind"], d["operation"], d["reason"], d["actor"], d["user_quote"]) for d in model["consistency"]["decisions"]] or ["无。"]
    lines += ["", "## 下游输入可用性", ""]
    lines += ["- {0}：{1}；{2}".format(k, v["readiness"], v["reason"]) for k, v in model["views"].items()]
    lines += ["", "## 完整性与限制", ""]
    lines += ["- " + g["description"] for g in model["completeness"]["gaps"]] or ["无已登记工程缺口；此结论取决于Agent对已提供资料的语义审查。"]
    lines += ["", "## 非阻断留痕", ""]
    lines += ["- " + n["description"] for n in model["consistency"]["notices"]] or ["无。"]
    lines += ["", "## 结论边界", "", "结构和确定性检查不代替语义审查；PASS不代表架构输入自动ready，也不代表已完成仿真或确认测试。", ""]
    return "\n".join(lines)
