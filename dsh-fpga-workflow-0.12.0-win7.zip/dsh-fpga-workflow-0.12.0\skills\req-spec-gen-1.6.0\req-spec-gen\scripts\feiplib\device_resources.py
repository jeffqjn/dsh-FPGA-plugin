"""User-maintained device catalog, exact task selection, and per-run snapshots."""
import re
from pathlib import Path

from .base import SKILL, digest, load, require, save, text, verify_inputs


CATALOG_PATH = SKILL / "assets/device_resources/器件资源库.md"
COLUMNS = ("器件型号", "封装", "速度等级", "质量等级", "逻辑资源门数", "IO管脚数量", "有无在轨维护需求", "不满足项的应对措施")
CAPTION = "表5.1.1-1 器件资源信息表"


def cells(line):
    line = line.strip()
    line = line[1:] if line.startswith("|") else line
    line = line[:-1] if line.endswith("|") else line
    return [s.strip().replace("\\|", "|") for s in re.split(r"(?<!\\)\|", line)]


def read(path=None):
    path = Path(path) if path is not None else CATALOG_PATH
    require(path.is_file(), "DEVICE_CATALOG_MISSING: " + str(path))
    content = path.read_text(encoding="utf-8-sig")
    lines = content.splitlines()
    starts = [i for i, line in enumerate(lines) if line.strip().startswith("|") and tuple(cells(line)) == COLUMNS]
    require(len(starts) == 1, "DEVICE_CATALOG_HEADER_INVALID: keep exactly one eight-column table in " + str(path))
    records = {}
    for line in lines[starts[0] + 1:]:
        if not line.strip().startswith("|"):
            break
        row = cells(line)
        require(len(row) == len(COLUMNS), "DEVICE_CATALOG_ROW_WIDTH_INVALID: " + line)
        if all(re.fullmatch(r":?-{3,}:?", c) for c in row):
            continue
        require(bool(row[0]), "DEVICE_CATALOG_MODEL_EMPTY")
        key = row[0].strip().casefold()
        require(key not in records, "DEVICE_CATALOG_DUPLICATE_MODEL: use one unique full part number per row: " + row[0])
        records[key] = row
    return records


def selected_model(model):
    value = model["basic_info"]["chip_model"]
    return value["value"].strip() if value["status"] == "present" and isinstance(value["value"], str) else ""


def selection(model, catalog):
    name = selected_model(model)
    return name, catalog.get(name.casefold()) if name else None


def warnings(model, catalog):
    name, row = selection(model, catalog)
    if not name:
        return ["5.1.1：任务未明确选用的器件型号，不能从资源库自行选择器件。"]
    if row is None:
        return ["5.1.1：器件资源库未找到任务选型“" + name + "”，请配置 assets/device_resources/器件资源库.md 中的完整型号。"]
    notes = []
    for column, value in zip(COLUMNS, row):
        if not value or "【请配置" in value or value.startswith(("待确认", "待配置", "未知")):
            notes.append("5.1.1：" + row[0] + "的“" + column + "”尚未完成配置。")
    require(row[6] in ("有", "无", "待确认", "待配置", "未知", "") or "【请配置" in row[6],
            "DEVICE_CATALOG_MAINTENANCE_VALUE_INVALID: use 有/无/待确认: " + row[0])
    return notes


def table_rows(model, catalog):
    name, row = selection(model, catalog)
    if row is None:
        return [[name or "待确认"] + ["待确认"] * (len(COLUMNS) - 1)]
    return [[value if value else "待确认" for value in row]]


def freeze(attempt):
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    require(info["kind"] == "writer", "GENERATE_REQUIRES_WRITER_ATTEMPT")
    require(not (attempt / "inputs/agent_model.json").exists(), "ATTEMPT_ALREADY_CONSUMED: prepare a fresh attempt")
    catalog = read()
    folder = attempt / "inputs/device_resources"
    require(not folder.exists(), "DEVICE_CATALOG_SNAPSHOT_EXISTS: prepare a fresh attempt")
    folder.mkdir(parents=True)
    target = folder / "器件资源库.md"
    # Retain the user's complete catalog, rather than only the selected row.
    text(target, CATALOG_PATH.read_text(encoding="utf-8-sig"))
    require(read(target) == catalog, "DEVICE_CATALOG_CHANGED_DURING_READ: retry with a fresh attempt")
    manifest = folder / "manifest.json"
    save(manifest, {"contract": "reqspec-device-resources/1.0", "file": target.name, "sha256": digest(target)})
    for path in (target, manifest):
        info["input_bindings"].append({"path": path.relative_to(attempt).as_posix(), "sha256": digest(path)})
    info["original_inputs"].append({"path": str(CATALOG_PATH.resolve()), "sha256": digest(CATALOG_PATH)})
    save(attempt / "attempt.json", info)
    return catalog


def frozen(package):
    folder = Path(package) / "inputs/device_resources"
    manifest = load(folder / "manifest.json")
    require(manifest.get("contract") == "reqspec-device-resources/1.0" and manifest.get("file") == "器件资源库.md", "DEVICE_CATALOG_MANIFEST_INVALID")
    path = folder / manifest["file"]
    require(path.is_file() and digest(path) == manifest["sha256"], "DEVICE_CATALOG_SNAPSHOT_CHANGED")
    return read(path)
