"""Synthetic device selection, resource fields, title and snapshot regression tests."""
import copy

from .base import Failure, digest, fact, save, text
from .device_resources import COLUMNS, frozen, read, selection, table_rows, warnings
from .render import render


def run_tests(seed, root):
    path = root / "synthetic-device-catalog.md"
    first = ["DEMO-FPGA-A-256-1", "DEMO-BGA256", "-1", "测试质量A", "10万等效门（虚构）", "100", "有", "不满足项：演示项；应对措施：演示措施"]
    second = ["DEMO-FPGA-B-400-2", "DEMO-BGA400", "-2", "测试质量B", "20万等效门（虚构）", "200", "无", "无不满足项"]

    def write(rows):
        content = "| " + " | ".join(COLUMNS) + " |\n| " + " | ".join("---" for _ in COLUMNS) + " |\n"
        content += "".join("| " + " | ".join(v.replace("|", "\\|") for v in row) + " |\n" for row in rows)
        text(path, content)

    def rejects(code, action):
        try:
            action()
        except Failure as exc:
            assert code in str(exc), str(exc)
        else:
            raise AssertionError("expected failure: " + code)

    write([first, second])
    catalog = read(path)
    model = copy.deepcopy(seed)
    model["basic_info"]["chip_model"] = fact(" demo-fpga-b-400-2 ")
    original = copy.deepcopy(model)
    assert selection(model, catalog)[1] == second
    assert table_rows(model, catalog) == [second] and not warnings(model, catalog)
    assert model == original
    results = ["device-exact-selection-preserves-all-eight-configured-fields"]

    sections = [s for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"]]
    next(s for s in sections if s["number"] == "5.1.1")["title"] = "需求来源"
    md = render(model, device_catalog=catalog)
    resources = md.split("#### 5.1.1 器件资源", 1)[1].split("#### 5.1.2", 1)[0]
    assert "DEMO-FPGA-B-400-2" in resources and "DEMO-FPGA-A-256-1" not in resources
    assert "DEMO-BGA400" in resources and "测试质量B" in resources and "200" in resources
    assert resources.count("| 器件型号 |") == 1 and "#### 5.1.1 需求来源" not in md
    results.append("legacy-section-title-normalized-and-only-selected-device-rendered-once")

    model["basic_info"]["chip_model"] = fact("DEMO-FPGA")
    assert selection(model, catalog)[1] is None and warnings(model, catalog)
    assert table_rows(model, catalog)[0] == ["DEMO-FPGA"] + ["待确认"] * 7
    model["basic_info"]["chip_model"] = fact()
    assert warnings(model, catalog) and selection(model, catalog)[1] is None
    results.append("unknown-or-prefix-only-selection-never-uses-first-or-similar-device")

    write([first, first])
    rejects("DEVICE_CATALOG_DUPLICATE_MODEL", lambda: read(path))
    write([first[:-1]])
    rejects("DEVICE_CATALOG_ROW_WIDTH_INVALID", lambda: read(path))
    results.append("duplicate-model-and-damaged-table-rejected")

    incomplete = list(second)
    incomplete[2] = ""
    write([incomplete])
    model["basic_info"]["chip_model"] = fact(second[0])
    notes = warnings(model, read(path))
    assert any("速度等级" in n for n in notes) and table_rows(model, read(path))[0][2] == "待确认"
    results.append("incomplete-device-field-reported-without-guessing-grade")

    escaped = list(first)
    escaped[-1] = "项A|项B"
    write([escaped])
    assert read(path)[first[0].casefold()][-1] == "项A|项B"
    results.append("escaped-pipe-in-user-countermeasure-preserved")

    folder = root / "device-snapshot-test/inputs/device_resources"
    folder.mkdir(parents=True)
    target = folder / "器件资源库.md"
    text(target, path.read_text(encoding="utf-8"))
    save(folder / "manifest.json", {"contract": "reqspec-device-resources/1.0", "file": target.name, "sha256": digest(target)})
    assert frozen(folder.parents[1]) == read(path)
    text(target, "changed")
    rejects("DEVICE_CATALOG_SNAPSHOT_CHANGED", lambda: frozen(folder.parents[1]))
    results.append("device-catalog-snapshot-hash-validated")
    return results
