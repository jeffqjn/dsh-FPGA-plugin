"""Observable preservation and rejection tests for report projections."""
import copy
import io
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from .docx_writer import build, verify, table_layout
from .source_tables import source_table, markdown_table
from .source_test_points import exact_row
from .render import table_row, render_table, requirement_text, flatten


def run_tests(seed, root):
    from docx import Document
    from docx.oxml.ns import qn
    data = build('# 标题\n\n## 1 正文\n\n保持≤10 ms，0xAA，64000bps。\n\n| 字段 | 值 |\n| --- | --- |\n| 长度 | 512字节<br>441字节 |\n\n## 2 宽表\n\n| A | B | C | D | E | F | G |\n| --- | --- | --- | --- | --- | --- | --- |\n| 1 | 2 | 3 | 4 | 5 | 6 | 7 |\n', seed)
    doc = Document(io.BytesIO(data))
    alltext = '\n'.join(p.text for p in doc.paragraphs) + '\n'.join(c.text for t in doc.tables for r in t.rows for c in r.cells)
    assert '≤10 ms' in alltext and '0xAA' in alltext and '64000bps' in alltext and '512字节\n441字节' in alltext
    assert len(doc.tables) == 2 and all(t.rows[0]._tr.xpath('./w:trPr/w:tblHeader') for t in doc.tables)
    assert not any(s.page_width > s.page_height for s in doc.sections)
    wide_md = '# 标题\n\n## 1 管脚\n\n表1\n\n| 序号 | 信号名称 | 信号标识 | 信号方向 | 管脚分配 | 电平标准 | 初始化状态 | 备注 |\n| --- | --- | --- | --- | --- | --- | --- | --- |\n| 1 | SYSCLK | SYSCLK | 输入 | JRTAX2000（鉴定件/正样件）：AD13；A3PE3000（电性件）：AG25 | LVCMOS33 | 待确认 | — |\n\n## 2 正文\n\n后续内容。'
    long_row = '| 1 | SYSCLK | SYSCLK | 输入 | JRTAX2000（鉴定件/正样件）：AD13；A3PE3000（电性件）：AG25 | LVCMOS33 | 待确认 | — |'
    wide_md = wide_md.replace(long_row, '\n'.join([long_row] * 5))
    wide_doc = Document(io.BytesIO(build(wide_md, seed)))
    assert len(wide_doc.sections) == 3 and wide_doc.sections[1].page_width > wide_doc.sections[1].page_height
    assert wide_doc.sections[0].different_first_page_header_footer
    assert not any(s.different_first_page_header_footer for s in list(wide_doc.sections)[1:])
    body = list(wide_doc.element.body)
    table_index = next(n for n, el in enumerate(body) if el.tag == qn('w:tbl'))
    assert ''.join(body[table_index - 1].itertext()).startswith('表1')
    assert '管脚' in ''.join(body[table_index - 2].itertext())
    assert body[table_index - 3].xpath('./w:pPr/w:sectPr')
    wide, weights = table_layout([['序号', '信号名称', '信号标识', '信号方向', '管脚分配', '电平标准', '初始化状态', '备注']] + [['1', 'SYSCLK', 'SYSCLK', '输入', 'X' * 100, 'LVCMOS33', '待确认', '—']] * 5)
    assert wide and weights[4] > weights[7] * 4
    for table in doc.tables:
        assert all(c.width > 0 for c in table.columns)
    results = ['docx-preserves-quantities-multiline-cells-wide-sections-and-repeat-headers']
    path = Path(root) / 'projection.docx'
    path.write_bytes(data)
    md = '# 标题\n\n## 1 正文\n\n保持≤10 ms，0xAA，64000bps。\n\n| 字段 | 值 |\n| --- | --- |\n| 长度 | 512字节<br>441字节 |\n\n## 2 宽表\n\n| A | B | C | D | E | F | G |\n| --- | --- | --- | --- | --- | --- | --- |\n| 1 | 2 | 3 | 4 | 5 | 6 | 7 |\n'
    verify(path, md, seed)
    output = io.BytesIO()
    with ZipFile(io.BytesIO(data)) as original, ZipFile(output, 'w', ZIP_DEFLATED) as changed:
        for name in original.namelist():
            part = original.read(name)
            if name == 'word/document.xml':
                part = part.replace(b'64000bps', b'64001bps')
            changed.writestr(name, part)
    path.write_bytes(output.getvalue())
    try:
        verify(path, md, seed)
    except ValueError as exc:
        assert 'WRITER_DOCX_MODEL_MISMATCH' in str(exc)
    else:
        raise AssertionError('DOCX tampering accepted')
    results.append('docx-rehashed-numeric-tamper-rejected-by-canonical-ooxml-comparison')
    element = {'uid': 'element:test', 'kind': 'table', 'read_status': 'complete', 'cells': [
        {'row': 0, 'column': 0, 'row_span': 1, 'column_span': 1, 'text': '地址'},
        {'row': 0, 'column': 1, 'row_span': 1, 'column_span': 1, 'text': '值'},
        {'row': 1, 'column': 0, 'row_span': 1, 'column_span': 1, 'text': "8'd16"},
        {'row': 1, 'column': 1, 'row_span': 1, 'column_span': 1, 'text': '0xAA'}]}
    statement = '\n'.join('col={0};row_span={1};col_span={2}: {3}'.format(c['column'], c['row_span'], c['column_span'], c['text']) for c in element['cells'])
    model = {'consistency': {'evidence': [{'uid': 'evidence:table', 'artifact_uid': 'artifact:source', 'element_uid': 'element:test', 'row': None, 'column': None}]},
             'document_archive': [{'artifact_uid': 'artifact:source', 'elements': [element]}]}
    semantic = {'statement': statement, 'evidence_refs': ['evidence:table']}
    before = copy.deepcopy(model)
    assert "8'd16" in '\n'.join(markdown_table(source_table(semantic, model))) and model == before
    semantic['statement'] = statement.replace('0xAA', '0xAB')
    try:
        source_table(semantic, model)
    except ValueError:
        pass
    else:
        raise AssertionError('mismatching source table accepted')
    results.append('source-table-address-and-value-preserved-and-stale-evidence-rejected')
    point = {'source_id': '1', 'object': '复位'}
    table = {'cells': [{'row': 1, 'column': 0, 'row_span': 1, 'text': '1'},
                       {'row': 1, 'column': 1, 'row_span': 1, 'text': '复位'}]}
    assert exact_row(point, table) == 1
    assert exact_row({'source_id': '1', 'object': '时钟'}, table) is None
    table['cells'] += [dict(c, row=2) for c in table['cells']]
    assert exact_row(point, table) is None
    results.append('test-point-exact-id-and-object-required-ambiguous-rows-rejected')
    obj = {'header': {'name': 'CLK'}, 'pins': [{'device_uid': 'device:a', 'pin': 'AD13'}, {'device_uid': 'device:b', 'pin': 'AG25'}], 'direction': 'input'}
    registry = {'device:a': {'model': 'DEVICE_A'}, 'device:b': {'model': 'DEVICE_B'}}
    cells = table_row(obj, 1, ['信号标识', '信号方向', '管脚分配'], {}, registry)
    assert cells == ['CLK', '输入', ['DEVICE_A：AD13', 'DEVICE_B：AG25']]
    results.append('signal-display-preserves-device-to-pin-pairing-without-machine-uids')
    registry['signal:test'] = obj
    registry['signal:missing'] = dict(obj, pins=[{'device_uid': 'device:b', 'pin': 'ZZ9'}])
    table = {'caption': '表1', 'columns': ['信号标识', '信号方向', '管脚分配'],
             'row_object_refs': [{'uid': 'signal:test'}, {'uid': 'signal:missing'}]}
    frozen = copy.deepcopy(table)
    rendered = '\n'.join(render_table(table, {'number': '5.2'}, {}, registry, {}))
    assert '| 信号标识 | 信号方向 | 管脚分配<br>DEVICE_A | 管脚分配<br>DEVICE_B |' in rendered
    assert '| CLK | 输入 | AD13 | AG25 |' in rendered
    assert '| CLK | 输入 | 待确认 | ZZ9 |' in rendered and table == frozen
    results.append('pin-columns-split-by-device-uid-with-missing-pin-left-pending')
    req = copy.deepcopy(seed['requirements'][0])
    req['title'] = '与CPU间UART接口协议——原子义务1'
    source = copy.deepcopy(req)
    text = '\n'.join(requirement_text(req, flatten(seed), seed))
    sem = next(r['semantic'] for r in req['revisions'] if r['uid'] == req['effective_revision_uid'])
    assert sem['statement'] in text and '〔' + req['normalized_id'] + '〕' in text
    assert '**' not in text and req['title'] not in text and req == source
    assert not doc.styles['Title'].element.xpath('./w:pPr/w:pBdr')
    results.append('atomic-trace-tags-preserve-full-obligation-without-repeated-headings')
    return results
