"""Python 3.8 compatible DOCX projection of the canonical Markdown report."""
import io
import re
from datetime import datetime
from zipfile import ZipFile


def dependencies():
    try:
        import docx
        import lxml
        return {'python-docx': docx.__version__, 'lxml': lxml.__version__}
    except ImportError as exc:
        raise ValueError('DOCX_DEPENDENCY_MISSING: run scripts/install_dependencies.py with Python 3.8.10: ' + str(exc))


def split_row(line):
    return [x.strip().replace('\\|', '|') for x in re.split(r'(?<!\\)\|', line.strip().strip('|'))]


def text_width(value):
    return sum(2 if ord(c) > 255 else 1 for c in value)


def table_layout(rows):
    """Reserve width for populated engineering fields, not empty remark cells."""
    headers = rows[0]
    lengths = [max(text_width(row[n]) if n < len(row) else 0 for row in rows) for n in range(len(headers))]
    wide = len(headers) >= 7 and len(rows) > 4 and sum(lengths) > 80
    weights = [1.0] * len(headers)
    if len(headers) >= 4:
        for n, name in enumerate(headers):
            if name == '序号':
                weights[n] = 0.45
            elif '管脚分配' in name:
                weights[n] = 1.5 if sum('管脚分配' in c for c in headers) > 1 else 3.8
            elif name in ('信号名称', '信号标识'):
                weights[n] = 1.7
            elif name in ('信号方向', '信号位宽'):
                weights[n] = 0.7
            elif any(k in name for k in ('说明', '要求项', '描述', '措施', '需求规格说明', '输入文件')):
                weights[n] = 2.2
            elif name == '备注':
                weights[n] = 0.6 if lengths[n] <= 6 else 1.8
        if headers[0] != '序号' and lengths[0] > 45:
            weights[0] = 2.6
    return wide, weights


def inline(paragraph, value):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    value = re.sub(r'<br\s*/?>', '\n', value, flags=re.I)
    value = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', value)
    for index, part in enumerate(re.split(r'\*\*(.*?)\*\*', value)):
        run = paragraph.add_run(re.sub(r'`([^`]+)`', r'\1', part))
        run.bold = bool(index % 2)
        run.font.name = 'Times New Roman'
        run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), '宋体')


def field(paragraph, instruction, display='1'):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    run = paragraph.add_run()._r
    for kind, text in [('begin', None), ('instr', instruction), ('separate', None), ('text', display), ('end', None)]:
        if kind in ('begin', 'separate', 'end'):
            el = OxmlElement('w:fldChar')
            el.set(qn('w:fldCharType'), kind)
        elif kind == 'instr':
            el = OxmlElement('w:instrText')
            el.set(qn('xml:space'), 'preserve')
            el.text = ' ' + text + ' '
        else:
            el = OxmlElement('w:t')
            el.text = text
        run.append(el)


def function_figure(doc, rows):
    from docx.enum.table import WD_ALIGN_VERTICAL
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt

    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
    table.style = 'Table Grid'
    table.autofit = False
    section = doc.sections[-1]
    width = (section.page_width - section.left_margin - section.right_margin) // len(rows[0])
    for col in table.columns:
        col.width = width
    spacing = OxmlElement('w:tblCellSpacing')
    spacing.set(qn('w:w'), '70')
    spacing.set(qn('w:type'), 'dxa')
    table._tbl.tblPr.insert_element_before(spacing, 'w:tblBorders', 'w:tblLayout', 'w:tblLook')
    for index, (row, values) in enumerate(zip(table.rows, rows)):
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for cell in row.cells:
            cell.width = width
        if index == 0:
            cells = [row.cells[0].merge(row.cells[-1])] if len(values) > 1 else [row.cells[0]]
        else:
            cells = row.cells
        for cell, value in zip(cells, values):
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = 0
            p.paragraph_format.space_before = p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.keep_with_next = len(rows) <= 7 or index in (0, len(rows) - 1)
            inline(p, value)
            p.runs[-1].bold = index == 0
            p.runs[-1].font.size = Pt(10 if index == 0 else 9)
            shade = OxmlElement('w:shd')
            shade.set(qn('w:fill'), 'E4EBF2' if index == 0 else 'F4F6F8')
            cell._tc.get_or_add_tcPr().append(shade)


def build(markdown, model):
    dependencies()
    from docx import Document
    from docx.enum.section import WD_ORIENT, WD_SECTION_START
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor
    from .template_layout import enabled, producer_version, follows_function_example, FIGURE_MARKER, FIGURE_CAPTION, TRACE_COLUMNS, ASSURANCE_COLUMNS
    from .assurance import GROUP_LABEL
    use_template = enabled(model)
    review_layout = producer_version(model) >= (1, 5, 2)
    use_function_example = follows_function_example(model)
    toc_depth = 4 if use_template else 2
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin, section.bottom_margin = Cm(2.5), Cm(2)
    section.left_margin, section.right_margin = Cm(2.5), Cm(2)
    section.header_distance, section.footer_distance = Cm(1.1), Cm(1)
    for name, size, east, bold in [('Normal', 10.5, '宋体', False), ('Title', 22, '黑体', True),
                                  ('Heading 1', 14, '黑体', True), ('Heading 2', 12, '黑体', True),
                                  ('Heading 3', 11, '黑体', True), ('Heading 4', 10.5, '黑体', True),
                                  ('Caption', 10.5, '宋体', False)]:
        style = doc.styles[name]
        style.font.name, style.font.size = 'Times New Roman', Pt(size)
        style.font.bold, style.font.color.rgb = bold, RGBColor(0, 0, 0)
        style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), east)
        for attribute in ('asciiTheme', 'hAnsiTheme', 'eastAsiaTheme', 'cstheme'):
            style.element.get_or_add_rPr().rFonts.attrib.pop(qn('w:' + attribute), None)
        fmt = style.paragraph_format
        fmt.line_spacing, fmt.space_after = 1.25, Pt(4)
        if name.startswith('Heading'):
            fmt.keep_with_next = True
            fmt.space_before = Pt(10)
            fmt.first_line_indent = 0
        elif name in ('Title', 'Caption'):
            fmt.first_line_indent = 0
            if name == 'Title':
                for border in style.element.xpath('./w:pPr/w:pBdr'):
                    border.getparent().remove(border)
        elif name == 'Normal':
            fmt.first_line_indent = Pt(21)
    doc.core_properties.title = model['meta']['title']
    doc.core_properties.author = ''
    doc.core_properties.last_modified_by = ''
    doc.core_properties.created = doc.core_properties.modified = datetime(2000, 1, 1)
    title = model['meta']['title']
    section.different_first_page_header_footer = True
    p = section.header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = 0
    p.add_run(title).font.size = Pt(9)
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = 0
    field(p, 'PAGE')
    p = doc.add_paragraph(style='Title')
    p.paragraph_format.space_before = Pt(120)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(title)
    if review_layout and model['consistency']['gates']['generation_state'] == 'DRAFT':
        p = doc.add_paragraph('评审稿（DRAFT）')
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = 0
    for key, label in [('document_number', '文件编号'), ('version', '版本'), ('date', '日期'), ('author', '编写')]:
        f = model['meta'].get(key)
        if isinstance(f, dict) and f.get('status') == 'present' and f.get('value'):
            p = doc.add_paragraph(label + '：' + str(f['value']))
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = 0
    doc.add_page_break()
    p = doc.add_paragraph('目  录', style='Title')
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    headings = []
    for line in markdown.splitlines():
        match = re.match(r'^(#{2,' + str(toc_depth + 1) + r'}) (.+)$', line)
        if match:
            headings.append((len(match.group(1)) - 1, match.group(2)))
    for index, (level, text) in enumerate(headings):
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = 0
        p.paragraph_format.left_indent = Cm((level - 1) * 0.6)
        p.paragraph_format.space_after = Pt(0 if use_template else 2)
        link = OxmlElement('w:hyperlink')
        link.set(qn('w:anchor'), 'section_' + str(index))
        r, t = OxmlElement('w:r'), OxmlElement('w:t')
        t.text = text
        r.append(t)
        link.append(r)
        p._p.append(link)
    doc.add_page_break()
    current_landscape = False
    heading_index = 0
    figure_pending = False
    lines = markdown.splitlines()

    def wide_ahead(start, limit=12):
        """True when the next table block within a few lines is also a wide table."""
        for offset in range(start, min(len(lines), start + limit)):
            if not lines[offset].strip().startswith('|'):
                continue
            if offset + 1 >= len(lines) or not re.match(r'^\s*\|[\s:|\-]+$', lines[offset + 1]):
                continue
            block, index = [split_row(lines[offset])], offset + 2
            while index < len(lines) and lines[index].strip().startswith('|'):
                block.append(split_row(lines[index]))
                index += 1
            return table_layout(block)[0]
        return False

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if use_function_example and line == FIGURE_MARKER:
            figure_pending = True
        if not line or line.startswith('<!--') or line.startswith('生成状态：') or line.startswith('# '):
            i += 1
            continue
        if line.startswith('|') and i + 1 < len(lines) and re.match(r'^\s*\|[\s:|\-]+$', lines[i + 1]):
            rows = [split_row(line)]
            i += 2
            while i < len(lines) and lines[i].strip().startswith('|'):
                rows.append(split_row(lines[i]))
                i += 1
            if figure_pending:
                function_figure(doc, rows)
                figure_pending = False
                continue
            count = len(rows[0])
            wide, weights = table_layout(rows)
            trace = next((name for name, columns in TRACE_COLUMNS.items() if use_template and rows[0] == columns), None)
            assurance = use_template and rows[0] == ASSURANCE_COLUMNS
            if trace == "A.1":
                weights = [0.48, 2.2, 1.25, 0.75, 1.85, 1.7, 1.65, 0.65]
            elif trace == "A.2":
                weights = [0.45, 1.15, 3.1, 1.15, 0.8, 0.65]
            elif assurance:
                # 检查项与检查结果承载模板原文，给足宽度；签署列保持窄列。
                weights = [0.55, 0.95, 1.5, 2.95, 1.2, 0.9, 0.9, 2.9, 1.25]
            if wide != current_landscape:
                attached = []
                following = doc.element.body[-1]
                candidates = list(doc.paragraphs)
                for index in range(len(candidates) - 1, -1, -1):
                    paragraph = candidates[index]
                    if paragraph._p.getnext() is not following:
                        break
                    heading = paragraph.style.name == 'Caption' or paragraph.style.name.startswith('Heading')
                    # A short note between a heading and its table belongs with the table.
                    related = (index > 0 and candidates[index - 1]._p.getnext() is paragraph._p
                               and candidates[index - 1].style.name.startswith('Heading'))
                    if heading or paragraph.paragraph_format.keep_with_next or related:
                        attached.insert(0, paragraph)
                        following = paragraph._p
                    else:
                        break
                new = doc.add_section(WD_SECTION_START.NEW_PAGE)
                new.different_first_page_header_footer = False
                new.orientation = WD_ORIENT.LANDSCAPE if wide else WD_ORIENT.PORTRAIT
                new.page_width, new.page_height = (Cm(29.7), Cm(21)) if wide else (Cm(21), Cm(29.7))
                current_landscape = wide
                # Keep the caption with its table when a landscape section begins.
                for paragraph in attached:
                    doc.element.body.remove(paragraph._p)
                    doc.element.body.insert(len(doc.element.body) - 1, paragraph._p)
            table = doc.add_table(rows=0, cols=count)
            table.style = 'Table Grid'
            table.autofit = False
            usable = (doc.sections[-1].page_width - doc.sections[-1].left_margin - doc.sections[-1].right_margin)
            widths = [int(usable * w / sum(weights)) for w in weights]
            for col, width in zip(table.columns, widths):
                col.width = width
            if trace:
                group = table.add_row()
                group._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
                for cell, width in zip(group.cells, widths):
                    cell.width = width
                bands = [(1, 3, '需求规格说明'), (4, 5, '输入文件（任务书、接口协议等）')] if trace == 'A.1' else [
                    (1, 2, '用户需求分析阶段'), (3, 5, '需求分析阶段')]
                for first, last, label in bands:
                    cell = group.cells[first].merge(group.cells[last])
                    p = cell.paragraphs[0]
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p.paragraph_format.first_line_indent = 0
                    inline(p, label)
                    p.runs[-1].bold = True
                    p.runs[-1].font.size = Pt(9)
            if assurance:
                # 模板把“是否适用/是否符合/检查结果”三列合并为“设计师检查要点”。
                group = table.add_row()
                group._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
                for cell, width in zip(group.cells, widths):
                    cell.width = width
                    shade = OxmlElement('w:shd')
                    shade.set(qn('w:fill'), 'F2F2F2')
                    cell._tc.get_or_add_tcPr().append(shade)
                cell = group.cells[5].merge(group.cells[7])
                p = cell.paragraphs[0]
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.first_line_indent = 0
                inline(p, GROUP_LABEL)
                p.runs[-1].bold = True
                p.runs[-1].font.size = Pt(9)
            for row_index, values in enumerate(rows):
                row = table.add_row()
                trpr = row._tr.get_or_add_trPr()
                if row_index == 0:
                    trpr.append(OxmlElement('w:tblHeader'))
                # Permit long source/test paragraphs to flow over pages without clipping.
                for col_index, cell in enumerate(row.cells):
                    cell.width = widths[col_index]
                    p = cell.paragraphs[0]
                    p.paragraph_format.first_line_indent = 0
                    p.paragraph_format.space_after = Pt(2)
                    p.paragraph_format.line_spacing = 1.1
                    inline(p, values[col_index] if col_index < len(values) else '')
                    for run in p.runs:
                        run.font.size = Pt(9 if count >= 6 else 10)
                        if row_index == 0:
                            run.bold = True
                    if row_index == 0:
                        shade = OxmlElement('w:shd')
                        shade.set(qn('w:fill'), 'F2F2F2')
                        cell._tc.get_or_add_tcPr().append(shade)
            if assurance:
                # 模板的两行表头：序号～落实文件及末列竖向跨行，仅“设计师检查要点”例外。
                for index in list(range(5)) + [len(ASSURANCE_COLUMNS) - 1]:
                    merged = table.rows[0].cells[index].merge(table.rows[1].cells[index])
                    for paragraph in list(merged.paragraphs):
                        if len(merged.paragraphs) == 1:
                            break
                        if not paragraph.text.strip():
                            paragraph._element.getparent().remove(paragraph._element)
            doc.add_paragraph().paragraph_format.space_after = Pt(0)
            if wide and any(x.strip() for x in lines[i:]) and not wide_ahead(i):
                new = doc.add_section(WD_SECTION_START.NEW_PAGE)
                new.different_first_page_header_footer = False
                new.orientation = WD_ORIENT.PORTRAIT
                new.page_width, new.page_height = Cm(21), Cm(29.7)
                current_landscape = False
            continue
        match = re.match(r'^(#{2,6}) (.+)$', line)
        if match:
            level = min(len(match.group(1)) - 1, 4)
            p = doc.add_heading(match.group(2), level=level)
            if level <= toc_depth:
                start, end = OxmlElement('w:bookmarkStart'), OxmlElement('w:bookmarkEnd')
                start.set(qn('w:id'), str(heading_index))
                start.set(qn('w:name'), 'section_' + str(heading_index))
                end.set(qn('w:id'), str(heading_index))
                p._p.insert(0, start)
                p._p.append(end)
                heading_index += 1
        else:
            p = doc.add_paragraph()
            inline(p, line)
            if re.match(r'^表\s*[A-Z0-9]', line) or use_function_example and line == FIGURE_CAPTION:
                p.style = doc.styles['Caption']
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.first_line_indent = 0
                p.paragraph_format.keep_with_next = line != FIGURE_CAPTION or not use_function_example
            elif use_function_example and line.startswith('**需求编号：**'):
                p.paragraph_format.keep_with_next = True
            elif line.startswith('**') and (not use_template or re.fullmatch(r'\*\*[^*]+\*\*', line)):
                p.paragraph_format.first_line_indent = 0
                p.paragraph_format.keep_with_next = True
            elif re.match(r'^〔[^〕]+〕$', line):
                p.paragraph_format.first_line_indent = 0
                p.paragraph_format.keep_with_next = True
            elif review_layout and line == '人工填写。':
                p.paragraph_format.keep_with_next = True
            for run in p.runs:
                if re.fullmatch(r'〔[^〕]+〕', run.text):
                    run.font.size = Pt(8)
        i += 1
    result = io.BytesIO()
    doc.save(result)
    return result.getvalue()


def contents(data):
    with ZipFile(io.BytesIO(data)) as z:
        return {n: z.read(n) for n in z.namelist()}


def verify(path, markdown, model):
    if not path.is_file() or contents(path.read_bytes()) != contents(build(markdown, model)):
        raise ValueError('WRITER_DOCX_MODEL_MISMATCH: regenerate DOCX from the canonical model')
