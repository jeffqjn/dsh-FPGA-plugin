"""Conservative DOCX/TXT structure extractor; unsupported content is explicit."""
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from .base import digest, require

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
P = "{http://schemas.openxmlformats.org/package/2006/relationships}"

def contents(node):
    result = []
    for child in node.iter():
        if child.tag in (W + "t", W + "delText"):
            result.append(child.text or "")
        elif child.tag == W + "tab":
            result.append("\t")
        elif child.tag in (W + "br", W + "cr"):
            result.append("\n")
    return "".join(result)

def extract(source, role, artifact_uid):
    source = Path(source)
    tag = digest(source)[:16]
    archive = {"uid": "archive:" + role + "-" + tag, "artifact_uid": artifact_uid, "role": role,
        "extraction_status": "complete", "sections": [], "elements": [], "limitations": []}
    current = None
    counter = [0]

    def add(kind, value, part="word/document.xml", cells=None, numbering=None, limitations=None):
        nonlocal current
        index = counter[0]
        counter[0] += 1
        if kind == "heading":
            match = re.match(r"^\s*((?:\d+(?:\.\d+)*)|(?:[A-D](?:\.\d+)*))\s+(.+)", value)
            parent_number = match.group(1).rsplit(".", 1)[0] if match and "." in match.group(1) else None
            parent = next((s for s in reversed(archive["sections"]) if s["number"] == parent_number), None) if parent_number else None
            current = {"uid": "section:" + role + "-" + tag + "-" + str(index),
                "number": match.group(1) if match else None, "title": match.group(2) if match else value,
                "parent_uid": parent["uid"] if parent else None, "element_refs": []}
            archive["sections"].append(current)
        element = {"uid": "element:" + role + "-" + tag + "-" + str(index), "kind": kind, "part": part,
            "section_uid": current["uid"] if current else None, "order": index, "text": value, "numbering": numbering,
            "cells": cells or [], "asset_artifact_uid": None, "read_status": "partial" if limitations else "complete", "limitations": limitations or []}
        archive["elements"].append(element)
        if current:
            current["element_refs"].append(element["uid"])

    if source.suffix.lower() in (".txt", ".md"):
        for line in source.read_text(encoding="utf-8-sig").splitlines():
            is_heading = line.startswith("#") or re.match(r"^\s*(?:\d+(?:\.\d+)*|[A-D](?:\.\d+)*)\s+\S", line)
            add("heading" if is_heading else "paragraph", line.lstrip("# ") if is_heading else line, part="text")
        return archive
    require(source.suffix.lower() == ".docx", "EXTRACT_INPUT: accepts .docx/.txt/.md")
    with zipfile.ZipFile(str(source)) as container:
        total_size = sum(info.file_size for info in container.infolist())
        require(total_size <= 256 * 1024 * 1024, "DOCX_UNCOMPRESSED_TOO_LARGE")
        root = ET.fromstring(container.read("word/document.xml"))
        styles = {}
        if "word/styles.xml" in container.namelist():
            for style in ET.fromstring(container.read("word/styles.xml")).iter(W + "style"):
                name = style.find(W + "name")
                styles[style.get(W + "styleId")] = name.get(W + "val", "") if name is not None else ""
        numbering = {}
        num_ids = {}
        counters = {}
        if "word/numbering.xml" in container.namelist():
            nr = ET.fromstring(container.read("word/numbering.xml"))
            for abstract in nr.findall(W + "abstractNum"):
                levels = {}
                for level in abstract.findall(W + "lvl"):
                    def val(name, default):
                        node = level.find(W + name)
                        return node.get(W + "val", default) if node is not None else default
                    levels[int(level.get(W + "ilvl", "0"))] = {"start": int(val("start", "1")), "format": val("numFmt", "decimal"), "text": val("lvlText", "%1.")}
                numbering[abstract.get(W + "abstractNumId")] = levels
            for num in nr.findall(W + "num"):
                abstract = num.find(W + "abstractNumId")
                if abstract is not None:
                    num_ids[num.get(W + "numId")] = abstract.get(W + "val")
                if num.find(W + "lvlOverride") is not None:
                    archive["limitations"].append("numbering override requires verification")

        def number(p):
            props = p.find(W + "pPr/" + W + "numPr")
            if props is None:
                return None, []
            ni, li = props.find(W + "numId"), props.find(W + "ilvl")
            num_id, level = ni.get(W + "val") if ni is not None else "", int(li.get(W + "val", "0")) if li is not None else 0
            config = numbering.get(num_ids.get(num_id), {}).get(level)
            if not config or config["format"] != "decimal":
                return None, ["unsupported automatic numbering; preserve original XML"]
            key = (num_id, level)
            counters[key] = counters.get(key, config["start"] - 1) + 1
            for prior in list(counters):
                if prior[0] == num_id and prior[1] > level:
                    del counters[prior]
            rendered = config["text"]
            for index in range(9):
                token = "%" + str(index + 1)
                if token in rendered:
                    if (num_id, index) not in counters:
                        return rendered, ["automatic numbering has unresolved ancestor"]
                    rendered = rendered.replace(token, str(counters[(num_id, index)]))
            return rendered, []

        def visit(node):
            if node.tag == W + "p":
                value = contents(node)
                style = node.find(W + "pPr/" + W + "pStyle")
                style_name = styles.get(style.get(W + "val"), "") if style is not None else ""
                n, limits = number(node)
                is_heading = bool(re.search(r"(?:heading|标题)\s*[1-9]", style_name, re.I))
                if node.find(".//" + W + "txbxContent") is not None:
                    limits.append("textbox text order needs verification")
                if node.find(".//" + W + "fldSimple") is not None or node.find(".//" + W + "instrText") is not None:
                    limits.append("field result may be stale")
                displayed = ((n + " ") if n else "") + value
                add("heading" if is_heading else "paragraph", displayed, numbering=n, limitations=limits)
                drawings = list(node.iter(W + "drawing")) + list(node.iter(W + "pict"))
                for drawing in drawings:
                    ids = [x.get(R + "embed", "") for x in drawing.iter(A + "blip")]
                    add("figure", "embedded drawing " + ",".join(ids), limitations=["image engineering content not transcribed"])
                return
            if node.tag == W + "tbl":
                cells, rows, column = [], [], 0
                for row_index, row in enumerate(node.findall(W + "tr")):
                    column = 0
                    row_values = []
                    for cell in row.findall(W + "tc"):
                        span = cell.find(W + "tcPr/" + W + "gridSpan")
                        width = int(span.get(W + "val", "1")) if span is not None else 1
                        vm = cell.find(W + "tcPr/" + W + "vMerge")
                        continued = vm is not None and vm.get(W + "val", "continue") == "continue"
                        cell_text = "\n".join(contents(p) for p in cell.findall(W + "p"))
                        if continued:
                            anchor = next((x for x in reversed(cells) if x["column"] == column and x["row"] + x["row_span"] == row_index), None)
                            if anchor is not None:
                                anchor["row_span"] += 1
                                if cell_text:
                                    anchor["text"] += "\n" + cell_text
                            else:
                                archive["limitations"].append("unresolved vertical table merge")
                        else:
                            cells.append({"row": row_index, "column": column, "row_span": 1, "column_span": width, "text": cell_text, "element_refs": []})
                        row_values.append(cell_text)
                        column += width
                        if cell.find(W + "tbl") is not None:
                            archive["limitations"].append("nested table has separate extraction")
                            for nested in cell.findall(W + "tbl"):
                                visit(nested)
                    rows.append(" | ".join(row_values))
                add("table", "\n".join(rows), cells=cells)
                return
            for child in node:
                visit(child)

        body = root.find(W + "body")
        require(body is not None, "DOCX_BODY_MISSING")
        visit(body)
        drawings = len(list(root.iter(W + "drawing"))) + len(list(root.iter(W + "pict")))
        missing_drawings = drawings - sum(e["kind"] == "figure" for e in archive["elements"])
        if missing_drawings > 0:
            current = None
            for index in range(missing_drawings):
                add("figure", "drawing in table or unsupported container; inspect original XML", limitations=["image engineering content not transcribed"])
        math_namespace = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"
        if root.find(".//" + math_namespace + "oMath") is not None:
            archive["limitations"].append("equation semantics require verified transcription")
        if any(root.find(".//" + W + name) is not None for name in ("ins", "del", "moveFrom", "moveTo")):
            archive["limitations"].append("unaccepted tracked revisions; no silent version selection")
        if root.find(".//" + W + "altChunk") is not None:
            archive["limitations"].append("altChunk embedded content is not expanded")
        if any(n.startswith("word/embeddings/") for n in container.namelist()):
            archive["limitations"].append("embedded object/attachment requires engineering review")
        for name in container.namelist():
            if re.match(r"word/(?:footnotes|endnotes|header\d+|footer\d+)\.xml$", name):
                current = None
                part = ET.fromstring(container.read(name))
                for paragraph in part.iter(W + "p"):
                    add("paragraph", contents(paragraph), part=name)
                for drawing in list(part.iter(W + "drawing")) + list(part.iter(W + "pict")):
                    add("figure", "drawing in supplementary document part", part=name, limitations=["image engineering content not transcribed"])
    if archive["limitations"] or any(e["read_status"] != "complete" for e in archive["elements"]):
        archive["extraction_status"] = "partial"
    return archive
