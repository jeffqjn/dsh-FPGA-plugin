"""Organize each external-interface section without changing its obligations."""
import re

from .base import require


LABELS = {"definition": "接口定义", "timing": "接口时序", "programming": "接口可编程要求"}


def applies(number):
    return re.fullmatch(r"5\.2\.[1-9][0-9]*", number) is not None


def semantic(req):
    return next((r["semantic"] for r in req["revisions"] if r["uid"] == req["effective_revision_uid"]), {})


def inferred_group(req, model):
    """Legacy presentation-only fallback; statements and bounds remain intact."""
    sem = semantic(req)
    dimensions = set()
    for c in model["analysis"]["constraints"]:
        if c["uid"] in sem.get("constraint_refs", []):
            value = c.get("value") or {}
            if isinstance(value, dict):
                dimensions.add(value.get("dimension"))
    statement = sem.get("statement", "")
    if dimensions.intersection({"time", "frequency", "data_rate"}) or re.search(r"时序|脉宽|上升沿|下降沿|边沿|频率|周期|握手|同步释放|异步置位|保持稳定|建立时间|保持时间|超时|波特率|MHz|kHz|Mbit/s|bit/s", statement, re.I):
        return "timing"
    if re.search(r"寄存器|地址分配|可编程|可配置|编程要求|配置位|配置参数|软件配置|读写权限", statement):
        return "programming"
    return "definition"


def interfaces(section, tables, model):
    explicit = {r["uid"] for r in section["object_refs"] if r["kind"] == "interface"}
    if not explicit:
        signals = {s["header"]["uid"]: s for s in model["analysis"]["signals"]}
        for table in tables:
            for row in table["row_object_refs"]:
                if row["uid"] in signals:
                    explicit.add(signals[row["uid"]]["interface_uid"])
        refs = set(section["primary_requirement_refs"] + section["cross_requirement_refs"])
        explicit.update(i["header"]["uid"] for i in model["analysis"]["interfaces"] if refs.intersection(i["header"]["requirement_refs"]))
    return [i for i in model["analysis"]["interfaces"] if i["header"]["uid"] in explicit]


def groups(section, tables, model):
    result = {key: {"paragraphs": [], "requirements": [], "tables": []} for key in LABELS}
    refs = section["primary_requirement_refs"] + section["cross_requirement_refs"]
    reqs = {r["uid"]: r for r in model["requirements"]}
    assignments = {}
    current = "definition"
    for paragraph in section["paragraphs"]:
        directive = re.fullmatch(r"\s*<!-- interface-group:([a-z_]+:[A-Za-z0-9._-]+)=(definition|timing|programming) -->\s*", paragraph)
        if directive:
            req_uid, group = directive.groups()
            require(req_uid in refs, "INTERFACE_GROUP_UNKNOWN_REQUIREMENT: " + req_uid)
            require(req_uid not in assignments or assignments[req_uid] == group, "INTERFACE_GROUP_CONFLICT: " + req_uid)
            assignments[req_uid] = group
            continue
        require(not paragraph.strip().startswith("<!-- interface-group:"), "INTERFACE_GROUP_DIRECTIVE_INVALID: " + section["number"])
        label = next((key for key, title in LABELS.items() if paragraph.strip() in ("**" + title + "**", "【" + title + "】")), None)
        if label:
            current = label
        elif paragraph.strip():
            result[current]["paragraphs"].append(paragraph)
    for req_uid in refs:
        require(req_uid in reqs, "UNKNOWN_INTERFACE_REQUIREMENT: " + req_uid)
        group = assignments.get(req_uid, inferred_group(reqs[req_uid], model))
        if req_uid not in result[group]["requirements"]:
            result[group]["requirements"].append(req_uid)
    for table in tables:
        group = "programming" if any("地址" in c or "寄存器" in c for c in table["columns"]) else "definition"
        result[group]["tables"].append(table)
    for interface in interfaces(section, tables, model):
        for group, field in (("timing", "timing_text"), ("programming", "programming_rules")):
            for paragraph in interface[field]:
                if paragraph not in result[group]["paragraphs"]:
                    result[group]["paragraphs"].append(paragraph)
    return result


def missing(section, grouped):
    if section["status"] == "not_applicable":
        return []
    return [section["number"] + "：" + title + "缺少有来源的内容，需确认是否适用。"
            for key, title in LABELS.items()
            if not grouped[key]["paragraphs"] and not grouped[key]["requirements"]
            and not any(t["row_object_refs"] for t in grouped[key]["tables"])]


def warnings(model):
    from .base import SKILL, load
    from .writer_tables import resolve
    template = load(SKILL / "templates/document_structure.json")
    notes = []
    for view in model["document_views"]:
        if view["role"] == "writer_plan":
            for section in view["sections"]:
                if applies(section["number"]):
                    notes.extend(missing(section, groups(section, resolve(section, template, model), model)))
    return notes
