"""Select the user-authored HDL section using explicit project language evidence."""
import re
from pathlib import Path

from .base import SKILL, digest, load, require, save, text, verify_inputs


TEMPLATE_PATH = SKILL / "assets/device_resources/5.1.3_编程及验收性模板.md"
TOKENS = re.compile(r"(?<![A-Za-z0-9_])(VHDL|Verilog)(?![A-Za-z_])", re.I)


def read(path=None):
    path = Path(path) if path is not None else TEMPLATE_PATH
    require(path.is_file(), "PROGRAMMING_TEMPLATE_MISSING: " + str(path))
    source = path.read_text(encoding="utf-8-sig")
    headings = list(re.finditer(r"(?m)^##[ \t]+([^\r\n]+)[ \t]*$", source))
    result = {}
    for index, match in enumerate(headings):
        label = match.group(1).strip()
        require(label in ("VHDL", "Verilog"), "PROGRAMMING_TEMPLATE_BRANCH_INVALID: " + label)
        require(label not in result, "PROGRAMMING_TEMPLATE_DUPLICATE_BRANCH: " + label)
        end = headings[index + 1].start() if index + 1 < len(headings) else len(source)
        # Ignore only the newline terminating the branch heading. Body is verbatim.
        start = match.end()
        start += 1 if source[start:start + 1] == "\n" else 0
        result[label] = source[start:end]
        require(bool(result[label].strip()), "PROGRAMMING_TEMPLATE_BRANCH_EMPTY: " + label)
    require(set(result) == {"VHDL", "Verilog"}, "PROGRAMMING_TEMPLATE_BRANCH_MISSING: keep ## VHDL and ## Verilog")
    return result


def languages(value):
    return {"VHDL" if m.group(1).casefold() == "vhdl" else "Verilog" for m in TOKENS.finditer(value)}


def selection(model):
    found = set()
    for resource in model["analysis"]["platform_resources"]:
        if resource["kind"] == "language" and resource["header"]["status"] == "present":
            field = resource["model"]
            if field["status"] == "present" and isinstance(field["value"], str):
                value = field["value"]
                if re.search(r"(?<![A-Za-z])SystemVerilog(?![A-Za-z])", value, re.I):
                    found.add("SystemVerilog（未配置）")
                found.update(languages(value))
    for req in model["requirements"]:
        if req["category"] != "language" or req["lifecycle"] != "active" or not req["effective_revision_uid"]:
            continue
        sem = next(r["semantic"] for r in req["revisions"] if r["uid"] == req["effective_revision_uid"])
        for clause in re.split(r"[。；;\n，,、]", sem["statement"]):
            if re.search(r"testbench|测试平台|仿真模型|仿真代码", clause, re.I):
                continue
            positive = False
            for match in re.finditer(r"采用|使用|选用|编程语言为|开发语言为|RTL语言为|HDL语言为", clause, re.I):
                prefix = clause[max(0, match.start() - 6):match.start()]
                if not re.search(r"不|禁止|不得|不能|不允许", prefix):
                    positive = True
            standalone = re.fullmatch(r"\s*(?:VHDL|Verilog)(?:[-\s]*\d+)?\s*", clause, re.I)
            if positive or standalone:
                if re.search(r"(?<![A-Za-z])SystemVerilog(?![A-Za-z])", clause, re.I):
                    found.add("SystemVerilog（未配置）")
                found.update(languages(clause))
    selected = next(iter(found)) if len(found) == 1 and found.issubset({"VHDL", "Verilog"}) else None
    return selected, sorted(found)


def warnings(model, templates):
    selected, candidates = selection(model)
    if selected is None:
        return ["5.1.3：" + ("编程语言未明确" if not candidates else "编程语言不唯一或尚不支持：" + "、".join(candidates)) + "，请依据项目RTL语言确认VHDL或Verilog，不能自行选模板。"]
    require(selected in templates and templates[selected].strip(), "PROGRAMMING_TEMPLATE_BRANCH_MISSING: " + selected)
    if "【请配置" in templates[selected]:
        return ["5.1.3：" + selected + "模板仍含【请配置：…】，请编辑 assets/device_resources/5.1.3_编程及验收性模板.md。"]
    return []


def body(model, templates):
    selected, candidates = selection(model)
    return templates[selected] if selected else "待确认：项目编程语言未能唯一确定为VHDL或Verilog，尚未选用模板。\n"


def freeze(attempt):
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    require(info["kind"] == "writer", "GENERATE_REQUIRES_WRITER_ATTEMPT")
    require(not (attempt / "inputs/agent_model.json").exists(), "ATTEMPT_ALREADY_CONSUMED: prepare a fresh attempt")
    templates = read()
    folder = attempt / "inputs/programming_template"
    require(not folder.exists(), "PROGRAMMING_TEMPLATE_SNAPSHOT_EXISTS: prepare a fresh attempt")
    folder.mkdir(parents=True)
    target = folder / TEMPLATE_PATH.name
    text(target, TEMPLATE_PATH.read_text(encoding="utf-8-sig"))
    require(read(target) == templates, "PROGRAMMING_TEMPLATE_CHANGED_DURING_READ")
    manifest = folder / "manifest.json"
    save(manifest, {"contract": "reqspec-programming-template/1.0", "file": target.name, "sha256": digest(target)})
    for path in (target, manifest):
        info["input_bindings"].append({"path": path.relative_to(attempt).as_posix(), "sha256": digest(path)})
    info["original_inputs"].append({"path": str(TEMPLATE_PATH.resolve()), "sha256": digest(TEMPLATE_PATH)})
    save(attempt / "attempt.json", info)
    return templates


def frozen(package):
    folder = Path(package) / "inputs/programming_template"
    manifest = load(folder / "manifest.json")
    require(manifest.get("contract") == "reqspec-programming-template/1.0" and manifest.get("file") == "5.1.3_编程及验收性模板.md", "PROGRAMMING_TEMPLATE_MANIFEST_INVALID")
    path = folder / manifest["file"]
    require(path.is_file() and digest(path) == manifest["sha256"], "PROGRAMMING_TEMPLATE_SNAPSHOT_CHANGED")
    return read(path)
