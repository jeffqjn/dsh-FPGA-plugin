"""Deterministic Markdown assembly from the frozen canonical model."""
from .base import SKILL, load, require
from .writer_tables import resolve, empty_note, trace_rows, policy
from .writer_overview import OVERVIEW_NUMBERS, paragraphs as overview_paragraphs, terms_table as overview_terms

def display(value):
    if value is None:
        return "待确认"
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, list):
        return "；".join(display(x) for x in value)
    if isinstance(value, dict):
        if "status" in value and "value" in value:
            return display(value["value"]) if value["status"] == "present" else "待确认（" + (value["reason"] or value["status"]) + "）"
        if value.get("kind") == "quantity":
            return value["decimal"] + " " + value["unit"]
        if value.get("kind") == "interval":
            return ("[" if value["lower_inclusive"] else "(") + display(value["lower"]) + ", " + display(value["upper"]) + ("]" if value["upper_inclusive"] else ")")
        if value.get("kind") == "bitvector":
            return "{0}'base{1}:{2}".format(value["width"], value["radix"], value["literal"])
        if value.get("kind") == "enumeration":
            return display(value["members"])
        if "text" in value:
            return value["text"]
        return value.get("name", value.get("uid", "已结构化记录"))
    return str(value)

def report_value(value):
    # The upstream catalogue uses the legacy display contract. Change only the
    # writer projection, so old taskbook packages still validate byte-for-byte.
    if isinstance(value, dict):
        if value.get('kind') == 'bitvector':
            return "{0}'{1}{2}".format(value['width'], {2: 'b', 8: 'o', 10: 'd', 16: 'h'}.get(value['radix'], str(value['radix']) + ':'), value['literal'])
        return {k: report_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [report_value(v) for v in value]
    return value


def escape(value):
    return display(report_value(value)).replace("|", "\\|").replace("\r", "").replace("\n", "<br>")

def flatten(model):
    found = {}
    def visit(value):
        if isinstance(value, dict):
            # Typed references are links, never authoritative objects. Headers are
            # indexed through their owner so signal/clock fields remain available.
            if set(value) == {"kind", "uid", "revision_uid"}:
                return
            if "uid" in value:
                found[value["uid"]] = value
            if "header" in value:
                found[value["header"]["uid"]] = value
            for key, item in value.items():
                if key not in ("header", "before", "after", "raw_snapshots", "payload"):
                    visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
    visit(model)
    return found

def requirement_text(req, registry, model):
    if req["effective_revision_uid"] is None:
        return []
    sem = next(r["semantic"] for r in req["revisions"] if r["uid"] == req["effective_revision_uid"])
    identity = '〔' + (req['normalized_id'] or '待确认编号') + '〕'
    lines = ['']
    from .source_tables import source_table, markdown_table
    table = source_table(sem, model)
    # Technical sections carry the subject; atomic IDs are unobtrusive trace tags,
    # never another repeated heading for each sentence of the same protocol.
    lines += [identity, ''] + markdown_table(table) if table else [sem['statement'] + ' ' + identity]
    if sem["safety_critical"]:
        lines += ["", "本功能属于安全关键功能（本条原子需求为安全关键要求）。" if req["category"] == "function" else "本条原子需求属于安全关键要求。"]
    if sem["condition"]:
        lines += ["", "适用条件：" + sem["condition"]["text"]]
    for label, values in (("输入", sem["input_refs"]), ("输出", sem["output_refs"])):
        if values:
            lines += ["", label + "：" + "、".join(object_label(v['uid'], registry) for v in values)]
    for item in sem["processing_rules"]:
        lines += ["", "处理：" + item]
    for constraint_uid in sem["constraint_refs"]:
        c = registry[constraint_uid]
        lines += ["", "约束：" + c["raw_text"] + ("；条件：" + c["when"]["text"] if c["when"] else "")]
    for exception in sem["exceptions"]:
        lines += ["", "异常处理：" + exception]
    return lines


def pin_projection(table, registry):
    devices = []
    if '管脚分配' in table['columns']:
        for row in table['row_object_refs']:
            for pin in registry[row['uid']].get('pins', []):
                if pin['device_uid'] not in devices:
                    devices.append(pin['device_uid'])
    columns = []
    selectors = []
    labels = [display(registry.get(uid, {}).get('model')) if registry.get(uid, {}).get('model') else object_label(uid, registry) for uid in devices]
    labels = [label if labels.count(label) == 1 else object_label(uid, registry) for uid, label in zip(devices, labels)]
    for column in table['columns']:
        if column == '管脚分配' and len(devices) > 1:
            for uid, label in zip(devices, labels):
                columns.append('管脚分配<br>' + label)
                selectors.append((column, uid))
        else:
            columns.append(column)
            selectors.append((column, None))
    return columns, selectors


def render_table(table, section, model, registry, reqs, expected="auto"):
    number = section["number"]
    from . import template_layout
    # 1-52模板的C/D表按固定要素清单生成；旧交接包保留其原有投影。
    assurance = template_layout.enabled(model) and number in ("C", "D")
    if template_layout.enabled(model):
        if number in template_layout.TRACE_COLUMNS:
            table = dict(table, columns=template_layout.TRACE_COLUMNS[number])
        elif assurance:
            table = dict(table, columns=template_layout.ASSURANCE_COLUMNS)
        elif number == "B" and not table["row_object_refs"]:
            table = dict(table, columns=["序号", "更改时间", "章节", "更改说明", "更改原因", "备注"])
        if number in template_layout.CAPTIONS:
            table = dict(table, caption=template_layout.CAPTIONS[number])
    columns, selectors = pin_projection(table, registry)
    lines = [table["caption"], "", "| " + " | ".join(escape(c) for c in columns) + " |", "| " + " | ".join("---" for _ in columns) + " |"]
    require(not table["row_object_refs"] or expected == "auto", "MANUAL_TABLE_MUST_BE_EMPTY")
    if number == "7.1":
        from .source_test_points import rows
        for values in rows(model, table):
            lines.append("| " + " | ".join(escape(v) for v in values) + " |")
    elif number in ("A.1", "A.2"):
        for values in trace_rows(model, number, table["columns"]):
            lines.append("| " + " | ".join(escape(v) for v in values) + " |")
    elif assurance:
        # 要素行取自模板；是否适用/是否符合/检查结果由Agent逐项判定，确认列留空待签署。
        from .assurance import column_values
        for values in column_values(number, table["columns"], section, model):
            lines.append("| " + " | ".join(escape(v) for v in values) + " |")
    elif table["row_object_refs"]:
        for index, row in enumerate(table["row_object_refs"]):
            require(row["uid"] in registry, "TABLE_ROW_OBJECT_MISSING: " + row["uid"])
            values = table_row(registry[row["uid"]], index + 1, table["columns"], reqs, registry)
            by_column = dict(zip(table['columns'], values))
            values = [[p['pin'] for p in registry[row['uid']].get('pins', []) if p['device_uid'] == device] or None
                      if device is not None else by_column[column] for column, device in selectors]
            lines.append("| " + " | ".join(escape(v) for v in values) + " |")
    lines += [""]
    if number not in ("A.1", "A.2", "C", "D") and not table["row_object_refs"]:
        note = empty_note(section, table, model)
        if note:
            lines += [note, ""]
    return lines

def render(model, fixed_content=None, device_catalog=None, language_templates=None):
    from .fixed_sections import FILES, read as read_fixed
    fixed_content = read_fixed() if fixed_content is None else fixed_content
    from . import device_resources
    device_catalog = device_resources.read() if device_catalog is None else device_catalog
    from . import programming_template
    from . import interface_layout
    from . import template_layout
    use_template = template_layout.enabled(model)
    use_function_example = template_layout.follows_function_example(model)
    language_templates = programming_template.read() if language_templates is None else language_templates
    views = [v for v in model["document_views"] if v["role"] == "writer_plan"]
    require(len(views) == 1, "WRITER_PLAN_REQUIRED: exactly one writer_plan")
    plan = views[0]
    template = load(SKILL / "templates/document_structure.json")
    numbers = [s["number"] for s in plan["sections"]]
    require(len(numbers) == len(set(numbers)), "DUPLICATE_SECTION_NUMBER")
    require(set(template["required_sections"]).issubset(numbers), "MISSING_TEMPLATE_SECTION")
    order = [numbers.index(n) for n in template["required_sections"]]
    require(order == sorted(order), "SECTION_ORDER_INVALID")
    require(all(numbers.index("5.2") < index for index, number in enumerate(numbers) if interface_layout.applies(number)), "INTERFACE_SUMMARY_MUST_PRECEDE_DETAILS")
    registry = flatten(model)
    reqs = {r["uid"]: r for r in model["requirements"]}
    units = template_layout.units(model) if use_template else {}
    placements = {uid: section["number"] for section in plan["sections"] for uid in section["primary_requirement_refs"]}
    primary = []
    lines = ["# " + model["meta"]["title"], "", "生成状态：" + str(model["consistency"]["gates"]["generation_state"]), ""]
    for section in plan["sections"]:
        number = section["number"]
        expected = policy(number, model)
        require(section["handling"] == expected or number == "7.1" and section["handling"] == "deferred", "SECTION_HANDLING_INVALID: " + number)
        if number == "5.1.1":
            require(section["title"] in ("需求来源", "器件资源"), "TEMPLATE_TITLE_CHANGED: " + number)
        elif number == "7.1":
            require(section["title"] in ("测试重点", "测试要点"), "TEMPLATE_TITLE_CHANGED: " + number)
        elif number in ("3.1", "3.2"):
            # Legacy upstream titles are read compatibly; the delivered body always shows the current title.
            legacy = ("产品结构概述",) if number == "3.1" else ("产品功能描述",)
            require(section["title"] in (template["titles"][number],) + legacy, "TEMPLATE_TITLE_CHANGED: " + number)
        elif number in template["titles"]:
            allowed = (template["titles"][number], template_layout.TITLES.get(number)) if use_template else (template["titles"][number],)
            require(section["title"] in allowed, "TEMPLATE_TITLE_CHANGED: " + number)
        tables = [] if number in FILES or number in ("1.1", "1.4", "5.1.1", "5.1.3") else resolve(section, template, model)
        if use_template and number == "B" and tables and not any(t["row_object_refs"] for t in tables):
            tables = tables[:1]
        section_title = ("器件资源" if number == "5.1.1" else "测试要点" if number == "7.1"
                         else template["titles"][number] if number in ("3.1", "3.2") else section["title"])
        if use_template:
            section_title = template_layout.TITLES.get(number, section_title)
        if number.startswith("5.3."):
            refs = units.get(number, {}).get("refs", section["primary_requirement_refs"] + section["cross_requirement_refs"])
            if use_template:
                section_title = section_title.rstrip("★")
            for req_uid in refs:
                req = reqs[req_uid]
                if req["effective_revision_uid"] and any(v["uid"] == req["effective_revision_uid"] and v["semantic"]["safety_critical"] is True for v in req["revisions"]):
                    section_title = section_title.rstrip("★") + "★"
                    break
        heading = section_title if use_template and number in ("A", "B", "C", "D") else number + " " + section_title
        lines += ["#" * min(number.count(".") + 2, 6) + " " + heading, ""]
        if number in FILES:
            require(not section["primary_requirement_refs"] and not section["cross_requirement_refs"],
                    "FIXED_SECTION_REQUIREMENT_PLACEMENT: move normative obligations to their technical section: " + number)
            require(number in fixed_content and fixed_content[number].strip(), "FIXED_SECTION_CONTENT_MISSING: " + number)
            lines += [fixed_content[number], ""]
            continue
        if number in ("1.1", "1.4"):
            # 1.1 lists the frozen basic facts point by point; 1.4 renders the frozen
            # acronyms as a two-column table. Neither accepts free text or obligations.
            require(not any(p.strip() for p in section["paragraphs"]),
                    "DETERMINISTIC_SECTION_NOT_FREE_TEXT: " + number + "由脚本按冻结模型生成，不接受自写段落")
            require(not section["tables"], "DETERMINISTIC_SECTION_TABLES_INVALID: " + number + "不接受计划表格绑定")
            require(not section["primary_requirement_refs"] and not section["cross_requirement_refs"],
                    "DETERMINISTIC_SECTION_REQUIREMENT_PLACEMENT: 技术义务应安排到对应技术章节: " + number)
            lines += (overview_terms(model) if number == "1.4" else overview_paragraphs(section, model)) + [""]
            continue
        if interface_layout.applies(number):
            grouped = interface_layout.groups(section, tables, model)
            for key, title in interface_layout.LABELS.items():
                block = grouped[key]
                lines += ["**" + title + "**", ""]
                lines += block["paragraphs"] + ([""] if block["paragraphs"] else [])
                for req_uid in block["requirements"]:
                    if req_uid in section["primary_requirement_refs"]:
                        primary.append(req_uid)
                    lines += requirement_text(reqs[req_uid], registry, model)
                for table in block["tables"]:
                    lines += render_table(table, section, model, registry, reqs)
                if not block["paragraphs"] and not block["requirements"] and not any(t["row_object_refs"] for t in block["tables"]):
                    note = "不适用：" + section["reason"] if section["status"] == "not_applicable" and section["reason"] else "待确认：来源未明确本接口的" + title + "，需确认是否适用。"
                    lines += [note, ""]
            continue
        if number == "7.1":
            # Source prose comes from frozen TP evidence, not Agent paraphrases.
            for table in tables:
                lines += render_table(table, section, model, registry, reqs)
            for req_uid in section["primary_requirement_refs"]:
                primary.append(req_uid)
                require(req_uid in reqs, "UNKNOWN_PRIMARY_REQUIREMENT")
                lines += requirement_text(reqs[req_uid], registry, model)
            continue
        if expected in ("deferred", "manual"):
            if use_template and number in ("C", "D"):
                # 附录C/D只承载逐项判定行；正文由脚本按固定清单装配。
                require(not section["primary_requirement_refs"] and not section["cross_requirement_refs"],
                        "DEFERRED_MANUAL_CONTENT_NOT_EMPTY")
                from .assurance import note as assurance_note
                lines += [assurance_note(number), ""]
            else:
                require(not section["paragraphs"] and not section["primary_requirement_refs"], "DEFERRED_MANUAL_CONTENT_NOT_EMPTY")
                lines += [("7.1测试要点按源文档原文填入；其余测试章节本阶段暂缓，保留结构。" if number == "7" else "本阶段暂缓，保留结构。") if expected == "deferred" else "人工填写。", ""]
        else:
            if number in units:
                lines += template_layout.unit_body(units[number], reqs, use_function_example)
                if section_title.endswith("★"):
                    lines += ["本功能属于安全关键功能。", ""]
                if not use_function_example and section["primary_requirement_refs"]:
                    lines += ["**详细要求**", ""]
            else:
                if use_template and number in template_layout.TEST_TOPICS:
                    require(not any(p.strip() for p in section["paragraphs"]) or section["material_element_refs"],
                            "VERIFICATION_SECTION_SOURCE_REQUIRED: " + number)
                lines += ([programming_template.body(model, language_templates)] if number == "5.1.3" else overview_paragraphs(section, model)) + [""]
                if use_template and number == "5":
                    trace_note = "正文的需求编号对应附录A的需求追溯记录。" if use_function_example else "正文中的〔需求编号〕标记对应附录A的需求追溯记录。功能单元与任务书功能项的对应关系见5.3节。"
                    lines += [trace_note, ""]
                if use_template and number == "5.3" and units:
                    if use_function_example:
                        header, *rows = template_layout.figure_rows(model, units)
                        lines += [template_layout.FIGURE_MARKER, ""]
                        for row in [header, ["---"] * len(header)] + rows:
                            lines.append("| " + " | ".join(escape(value) for value in row) + " |")
                        lines += ["", template_layout.FIGURE_CAPTION, ""]
                    else:
                        lines += ["表5.3-1 功能单元及分解", "",
                                  "| 功能单元 | 任务书功能项 | 子功能 |", "| --- | --- | --- |"]
                        for row in template_layout.unit_index(units):
                            lines.append("| " + " | ".join(escape(value) for value in row) + " |")
                        lines += [""]
            if (number not in OVERVIEW_NUMBERS and number != "5.1.3"
                    and not template_layout.is_verification_group(model, number)
                    and section["status"] in ("missing", "unknown")):
                lines += ["待确认：" + (section["reason"] or "来源未明确"), ""]
            for req_uid in section["primary_requirement_refs"]:
                primary.append(req_uid)
                require(req_uid in reqs, "UNKNOWN_PRIMARY_REQUIREMENT")
                lines += requirement_text(reqs[req_uid], registry, model)
            for req_uid in section["cross_requirement_refs"]:
                location = placements.get(req_uid) if use_template else None
                lines += ["参见" + (location + "节" if location else "") + "需求 " + (reqs[req_uid]["normalized_id"] or req_uid) + "。", ""]
        if number == "5.1.1":
            lines += [device_resources.CAPTION, "", "| " + " | ".join(device_resources.COLUMNS) + " |", "| " + " | ".join("---" for _ in device_resources.COLUMNS) + " |"]
            for values in device_resources.table_rows(model, device_catalog):
                lines.append("| " + " | ".join(escape(v) for v in values) + " |")
            lines += [""]
            for note in device_resources.warnings(model, device_catalog):
                lines += ["待确认：" + note, ""]
        for table in tables:
            lines += render_table(table, section, model, registry, reqs, expected)
        if number in ("8.1", "8.2"):
            for req in model["requirements"]:
                if req["category"] == "function" and any(v["uid"] == req["effective_revision_uid"] and v["semantic"]["safety_critical"] is True for v in req["revisions"]):
                    lines += ["- 安全关键功能：{0} {1}；设计/测试要求参见该需求及已有来源材料。".format(req["normalized_id"], req["title"])]
            lines += [""]
    require(len(primary) == len(set(primary)), "REQUIREMENT_DEFINED_MULTIPLE_TIMES")
    included = {r["uid"] for r in model["requirements"] if r["lifecycle"] == "active"}
    deferred = set()
    for section in plan["sections"]:
        if policy(section["number"], model) in ("deferred", "manual"):
            deferred.update(section["cross_requirement_refs"])
    require(included == set(primary) | deferred, "WRITER_REQUIREMENT_OMISSION: every active requirement needs a main placement or explicit deferred/manual reference")
    return "\n".join(lines) + "\n"

def object_label(uid, registry):
    obj = registry.get(uid, {})
    return obj.get('header', {}).get('name') or obj.get('normalized_id') or obj.get('name') or obj.get('title') or obj.get('model') or '未提供名称'


def table_row(obj, index, columns, requirements, registry=None):
    registry = registry or {}
    name = obj.get("header", {}).get("name", obj.get("title", obj.get("name", "")))
    semantic = next((r["semantic"] for r in obj.get("revisions", []) if r["uid"] == obj.get("effective_revision_uid")), {})
    pin_devices = set(p.get('device_uid') for p in obj.get('pins', []))
    pins = [(object_label(p['device_uid'], registry) + '：' if len(pin_devices) > 1 else '') + p['pin'] for p in obj.get('pins', [])]
    values = {"序号": index, "信号名称": name, "信号标识": name, "信号方向": {'input': '输入', 'output': '输出', 'inout': '双向', 'unknown': '待确认'}.get(obj.get('direction'), obj.get('direction')),
        "信号位宽": obj.get("width"), "管脚分配": pins, "电平标准": obj.get("io_standard"),
        "初始化状态": obj.get("default_value"), "备注": obj.get("header", {}).get("reason") or '—', "器件名称": name,
        "器件型号": obj.get("model"), "个数": obj.get("count"), "功能概述": obj.get("responsibilities", []),
        "需求标识": obj.get("normalized_id"), "描述": semantic.get("statement", obj.get("title")), "需求名称": obj.get("title"),
        "信号定义": name,
        "文件编号": obj.get("identifier"), "文件名称": obj.get("title"), "版本": obj.get("version"),
        "时钟域名称": name, "时钟频率/频率": obj.get("frequency"), "和其它时钟关系": [r["kind"] for r in obj.get("relations", [])],
        "IP模块": name, "类型": obj.get("kind"), "功能": name, "参数": [p["name"] + ":" + display(p["value"] or p["text"]) for p in obj.get("parameters", [])],
        "版本号": obj.get("version"), "关键数据名称": name, "重点关注": obj.get("validity_rules", [])}
    values["文件名称（Vx.xx）"] = [obj.get("title"), obj.get("version")]
    require(all(c in values for c in columns), "TABLE_SELECTOR_NOT_SUPPORTED: implement a sourced column mapping; do not add a substitute table: " + str([c for c in columns if c not in values]))
    return [values[c] for c in columns]
