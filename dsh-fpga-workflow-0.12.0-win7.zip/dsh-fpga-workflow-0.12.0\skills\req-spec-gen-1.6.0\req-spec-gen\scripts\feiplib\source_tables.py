"""Project exact source-table obligations without editing frozen semantics."""
import re


def source_table(semantic, model):
    statement = semantic['statement']
    if not re.match(r'^col=\d+;row_span=\d+;col_span=\d+:', statement):
        return None
    evidence = {e['uid']: e for e in model['consistency']['evidence']}
    found = []
    for ref in semantic['evidence_refs']:
        ev = evidence.get(ref, {})
        for archive in model['document_archive']:
            if archive['artifact_uid'] != ev.get('artifact_uid'):
                continue
            for el in archive['elements']:
                if el['uid'] != ev.get('element_uid') or el['kind'] != 'table' or el['read_status'] != 'complete':
                    continue
                raw = '\n'.join('col={0};row_span={1};col_span={2}: {3}'.format(
                    c['column'], c['row_span'], c['column_span'], c['text']) for c in el['cells'])
                if raw == statement and ev.get('row') is None and ev.get('column') is None:
                    found.append(el)
    unique = {el['uid']: el for el in found}
    if len(unique) != 1:
        raise ValueError('SOURCE_TABLE_STATEMENT_MISMATCH: exact complete source table required')
    return next(iter(unique.values()))


def markdown_table(element):
    cells = element['cells']
    rows = max(c['row'] + c['row_span'] for c in cells)
    cols = max(c['column'] + c['column_span'] for c in cells)
    grid = [['' for _ in range(cols)] for _ in range(rows)]
    for c in cells:
        for row in range(c['row'], c['row'] + c['row_span']):
            for col in range(c['column'], c['column'] + c['column_span']):
                grid[row][col] = c['text']
    if len(grid) == 1:
        grid.insert(0, ['字段' + str(n + 1) for n in range(cols)])
    def line(row):
        return '| ' + ' | '.join(t.replace('|', '\\|').replace('\n', '<br>') for t in row) + ' |'
    return [line(grid[0]), line(['---'] * cols)] + [line(row) for row in grid[1:]]
