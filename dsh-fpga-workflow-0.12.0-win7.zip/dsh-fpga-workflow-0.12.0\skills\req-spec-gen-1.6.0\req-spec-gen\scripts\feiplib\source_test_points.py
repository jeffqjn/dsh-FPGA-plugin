"""Copy upstream source test points; never generate new test procedures."""
from .base import require

COLUMNS = ["序号", "测试要点", "测试说明", "对应需求项"]
LEGACY_COLUMNS = ["序号", "测试重点", "测试说明", "对应需求项"]


def exact_row(point, element):
    """Resolve only an exact source ID plus exact object name, never order/fuzzy text."""
    if not point.get('source_id') or not point.get('object'):
        return None
    cells = element['cells']
    candidates = [c['row'] for c in cells if c['column'] == 0 and c['row_span'] == 1
                  and c['text'].strip() == point['source_id'].strip()
                  and any(k['column'] == 1 and k['row'] <= c['row'] < k['row'] + k['row_span']
                          and k['text'].strip() == point['object'].strip() for k in cells)]
    return candidates[0] if len(candidates) == 1 else None


def original(point, model):
    evidence = {e["uid"]: e for e in model["consistency"]["evidence"]}
    elements = {(a["artifact_uid"], e["uid"]): e
                for a in model["document_archive"] if a["role"] in ("taskbook", "attachment")
                for e in a["elements"]}
    texts, notes = [], []
    for ref in point["evidence_refs"]:
        ev = evidence.get(ref, {})
        if ev.get("origin_kind") not in ("taskbook", "user_supplied") or ev.get("confirmation") not in ("evidenced", "user_confirmed"):
            notes.append("部分证据并非已确认的源文档原文")
            continue
        element = elements.get((ev.get("artifact_uid"), ev.get("element_uid")))
        if not element or element.get("read_status") != "complete":
            notes.append("原文定位缺失或原文未完整读取")
            continue
        if element["kind"] == "paragraph":
            # prepare's quote can be a 500-character preview: copy the full
            # frozen element, not that truncated preview or reconstructed fields.
            content = element["text"]
        elif element["kind"] == "table" and (type(ev.get('row')) is int or exact_row(point, element) is not None):
            row = ev['row'] if type(ev.get('row')) is int else exact_row(point, element)
            cells = sorted((c for c in element["cells"]
                            if c["row"] <= row < c["row"] + c["row_span"]),
                           key=lambda c: c["column"])
            content = " | ".join(c["text"] for c in cells)
        else:
            notes.append("需在上游为测试要点定位完整段落或表格行，不能仅用摘要代替原文")
            continue
        if content.strip() and content not in texts:
            texts.append(content)
        elif not content.strip():
            notes.append("对应原文为空")
    if not texts:
        notes.append("交接包未提供可直接复制的测试要点原文")
    return "\n\n".join(texts), list(dict.fromkeys(notes))


def rows(model, table):
    require(table["columns"] == COLUMNS, "TEST_POINT_TABLE_COLUMNS_INVALID")
    points = {p["uid"]: p for p in model["verification"]["source_test_points"]}
    requirements = {r["uid"]: r for r in model["requirements"]}
    result = []
    for ref in table["row_object_refs"]:
        require(ref["uid"] in points, "TEST_POINT_TABLE_ROW_NOT_SOURCE_POINT")
        point = points[ref["uid"]]
        raw, notes = original(point, model)
        labels = []
        for uid in point["requirement_refs"]:
            require(uid in requirements, "TEST_POINT_REQUIREMENT_MISSING: " + uid)
            labels.append(requirements[uid]["normalized_id"] or "待确认编号")
        description = raw or "待确认：交接包缺少可直接复制的测试要点原文。"
        if raw and notes:
            description += "\n\n待确认：部分原文定位不完整，详见生成检查报告。"
        result.append([len(result) + 1, " ".join(x for x in (point["source_id"], point["title"]) if x),
                       description, "；".join(labels) or "待确认：未提供需求关联"])
    return result


def warnings(model):
    points = model["verification"]["source_test_points"]
    if not points:
        return ["7.1：上游未提供源测试要点，需由上游补充，不自动编写。"]
    notes = []
    for point in points:
        _, missing = original(point, model)
        label = point["source_id"] or point["uid"]
        notes.extend("7.1 " + label + "：" + n for n in missing)
        if not point["requirement_refs"]:
            notes.append("7.1 " + label + "：缺少对应需求关联，不能推定已覆盖需求。")
    return notes
