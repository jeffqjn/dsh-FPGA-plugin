"""Source text preservation and bounded 7.1 scope (fictional fixtures)."""
import copy

from .base import Failure, SKILL, load
from .render import render
from .source_test_points import original, warnings
from .writer_tables import resolve


def run_tests(seed):
    model = copy.deepcopy(seed)
    plan = next(v for v in model["document_views"] if v["role"] == "writer_plan")
    section = next(s for s in plan["sections"] if s["number"] == "7.1")
    template = load(SKILL / "templates/document_structure.json")
    point = model["verification"]["source_test_points"][0]
    ev = next(e for e in model["consistency"]["evidence"] if e["uid"] == point["evidence_refs"][0])
    archive = next(a for a in model["document_archive"] if a["artifact_uid"] == ev["artifact_uid"])
    element = next(e for e in archive["elements"] if e["uid"] == ev["element_uid"])
    raw = "TP-A-001 原文：" + "保留既定条件、边界和异常。" * 70 + "最终判据≤10 ms。"
    element["text"] = raw
    ev["quote"] = raw[:500]
    point["procedure"] = "不能用这段重新编写的步骤替代原文。"
    section["paragraphs"] = ["不能复制这段Agent改写。"]
    before = copy.deepcopy(model)
    md = render(model)
    body = md.split("### 7.1 ", 1)[1].split("### 7.2 ", 1)[0]
    assert raw in body and body.count(raw) == 1 and "最终判据≤10 ms。" in body
    assert "不能用这段重新编写" not in body and "不能复制这段Agent" not in body
    assert "本阶段暂缓" not in body and model == before
    results = ["test-point-full-original-not-truncated-quote-or-agent-rewrite-and-no-model-mutation"]

    second = copy.deepcopy(point)
    second.update(uid="testpoint:tp2", source_id="TP-A-002", title="恢复行为")
    second_ev = copy.deepcopy(ev)
    second_ev.update(uid="evidence:tp2", element_uid="element:tp2", quote="恢复原文")
    second_element = copy.deepcopy(element)
    second_element.update(uid="element:tp2", text="恢复原文：错误解除后恢复，不重复应答。")
    second["evidence_refs"] = [second_ev["uid"]]
    archive["elements"].append(second_element)
    model["consistency"]["evidence"].append(second_ev)
    model["verification"]["source_test_points"].append(second)
    body = render(model).split("### 7.1 ", 1)[1].split("### 7.2 ", 1)[0]
    assert body.count("| 1 | TP-A-001 ") == body.count("| 2 | TP-A-002 ") == 1
    assert body.index(raw) < body.index(second_element["text"])
    assert body.count("TEST-PREQ-1") == 2 and not warnings(model)
    results.append("all-source-test-points-and-valid-requirement-numbers-rendered-in-upstream-order")

    section.update(title="测试重点", handling="deferred")
    section["tables"][0]["columns"][1] = "测试重点"
    md = render(model)
    assert "### 7.1 测试要点" in md and "| 序号 | 测试要点 | 测试说明 | 对应需求项 |" in md
    assert "#### 7.2.1 " in md and "#### 7.3.4 " in md
    assert "本阶段暂缓" not in md.split("### 7.2 ", 1)[1].split("## 8 ", 1)[0]
    assert "#### 7.2.1 功能验证要求" in md and "### 7.3 板级确认" in md
    results.append("legacy-test-point-input-preserved-with-template-verification-headings")

    for refs, code in (([{"kind": "testpoint", "uid": point["uid"], "revision_uid": None}], "TEST_POINT_TABLE_SCOPE_MISMATCH"),
                       ([{"kind": "requirement", "uid": "req:latency", "revision_uid": None}], "TEST_POINT_TABLE_ROW_NOT_SOURCE_POINT")):
        section["tables"][0]["row_object_refs"] = refs
        try:
            resolve(section, template, model)
        except Failure as exc:
            assert code in str(exc), str(exc)
        else:
            raise AssertionError("invalid source test point binding accepted")
    section["tables"][0]["row_object_refs"] = []
    results.append("omitted-source-test-points-and-non-test-point-table-rows-rejected")

    element.update(kind="table", text="表格原文", cells=[
        {"row": 0, "column": 0, "row_span": 3, "column_span": 1, "text": "共用前提"},
        {"row": 1, "column": 1, "row_span": 1, "column_span": 1, "text": "相邻测试点，不应复制"},
        {"row": 2, "column": 1, "row_span": 1, "column_span": 1, "text": "当前测试要点≤10 ms"}])
    ev["row"] = 2
    assert original(point, model) == ("共用前提 | 当前测试要点≤10 ms", [])
    results.append("source-table-row-copies-full-cell-text-with-merged-premise-without-adjacent-test-point")
    ev["row"] = None
    assert not original(point, model)[0] and warnings(model)
    ev.update(row=2, artifact_uid="artifact:wrong")
    assert not original(point, model)[0] and warnings(model)
    results.append("missing-table-row-and-mismatched-source-artifact-stay-pending-without-fabricated-text")

    second["requirement_refs"] = []
    assert any("缺少对应需求关联" in n for n in warnings(model))
    from .workflow import generation_state
    model["consistency"]["gates"]["overall"] = "PASS"
    assert generation_state(model) == "DRAFT"
    results.append("missing-original-or-requirement-link-keeps-draft-and-is-reported")
    model["verification"]["source_test_points"] = []
    body = render(model).split("### 7.1 ", 1)[1].split("### 7.2 ", 1)[0]
    assert "待确认" in body and "本阶段暂缓" not in body and warnings(model)
    results.append("absent-upstream-source-points-are-pending-not-silently-deferred-or-invented")
    return results
