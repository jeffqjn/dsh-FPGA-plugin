"""Regression tests for table binding and actual Markdown output (synthetic data)."""
import copy

from .base import Failure, SKILL, load
from .render import render
from .writer_tables import resolve, warnings


def run_tests(seed):
    results = []
    template = load(SKILL / "templates/document_structure.json")

    def section(model, number):
        return next(s for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"] if s["number"] == number)

    def rejects(code, action):
        try:
            action()
        except Failure as error:
            assert code in str(error), str(error)
        else:
            raise AssertionError("expected rejection: " + code)
        results.append(code)

    model = copy.deepcopy(seed)
    model["analysis"]["signals"] = [{"header": {"uid": "signal:s" + str(i), "name": "S" + str(i), "reason": None},
                                     "interface_uid": "interface:synthetic", "direction": "input", "width": 1,
                                     "pins": [], "io_standard": None, "default_value": None} for i in (1, 2)]
    target = section(model, "5.2")
    original = copy.deepcopy(model)
    resolved = resolve(target, template, model)
    assert len(resolved) == 1 and len(resolved[0]["row_object_refs"]) == 2
    assert model == original
    results.append("empty-signal-template-filled-without-mutating-source")

    supplementary = copy.deepcopy(resolved[0])
    supplementary.update(uid="tableview:extra", caption="信号明细")
    target["tables"].append(supplementary)
    resolved = resolve(target, template, model)
    assert len(resolved) == 1 and resolved[0]["caption"] == "表5.2-1"
    assert len(resolved[0]["row_object_refs"]) == 2
    target["tables"][0]["row_object_refs"] = copy.deepcopy(supplementary["row_object_refs"])
    assert len(resolve(target, template, model)[0]["row_object_refs"]) == 2
    results.append("template-and-populated-table-merged-without-row-loss-or-duplication")

    conflicting = copy.deepcopy(target)
    conflicting["tables"][1]["columns"] = ["信号名称", "信号方向"]
    rejects("DUPLICATE_TABLE_PURPOSE", lambda: resolve(conflicting, template, model))
    incomplete = copy.deepcopy(target)
    incomplete["tables"] = [copy.deepcopy(resolved[0])]
    incomplete["tables"][0]["row_object_refs"].pop()
    rejects("SIGNAL_TABLE_SCOPE_MISMATCH", lambda: resolve(incomplete, template, model))
    raw = copy.deepcopy(target)
    raw["paragraphs"] = ["| 信号 | 方向 |\n| --- | --- |\n| S1 | input |"]
    rejects("RAW_TABLE_IN_PARAGRAPHS", lambda: resolve(raw, template, model))
    manual = copy.deepcopy(section(model, "C"))
    manual["tables"][0]["row_object_refs"] = supplementary["row_object_refs"]
    rejects("MANUAL_TABLE_MUST_BE_EMPTY", lambda: resolve(manual, template, model))

    notes = warnings(model)
    assert any(n.startswith("4 ") for n in notes)
    assert not any(n.startswith(("2.1 ", "2.2 ", "C ", "D ")) for n in notes)
    assert any(n.startswith("7.3.2 ") for n in notes)
    results.append("unfilled-auto-table-reported-without-penalizing-approved-empty-tables")
    md = render(model)
    a1 = md.split("### A.1 ", 1)[1].split("### A.2 ", 1)[0]
    a2 = md.split("### A.2 ", 1)[1].split("## 附录B ", 1)[0]
    assert a1.count("\n| --- |") == 1 and a2.count("\n| --- |") == 1
    assert "TEST-PREQ-1" in a1 and "TEST-PREQ-1" in a2
    assert "| 工程需求 | 源父ID |" not in md
    from .fixed_sections import read as read_fixed
    assert read_fixed()["2.1"] in md and "人工填写。" in md
    results.append("trace-matrices-fill-template-once-with-actual-source-and-requirement-ids")
    summary = md.split("### 5.2 ", 1)[1].split("### 5.3 ", 1)[0]
    assert summary.count("| 序号 | 信号名称 |") == 1
    assert summary.count("| 1 | S1 |") == 1 and summary.count("| 2 | S2 |") == 1
    results.append("rendered-signal-table-once-with-all-signals")
    return results
