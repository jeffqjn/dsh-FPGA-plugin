"""Project the 1-52 FPGA template over a frozen FEIP writer plan."""
import re

from .base import require


TITLES = {
    "1.3": "文档概述", "1.4": "符号和缩略语",
    "5.1.2": "加载要求", "5.1.3": "编程规范性", "5.2": "接口需求",
    "5.5.1": "降额设计", "5.5.5": "其他可靠性设计",
    "7.2.1": "功能验证要求", "7.2.2": "时序验证要求",
    "7.2.3": "仿真验证环境差异分析", "7.2.4": "仿真验证不可测试项分析",
    "7.3": "板级确认", "7.3.2": "确认测试环境差异分析", "7.3.4": "第三方评测分析",
    "8": "安全关键功能专项要求", "8.1": "安全关键功能对设计的要求",
    "8.2": "安全关键功能对测试的要求", "10": "产保技术要素确认结果",
    "11": "待办事项追踪及验证", "A": "附录A FPGA产品需求追溯表",
    "A.1": "逆向跟踪矩阵", "B": "附录B 更改记录",
    "C": "附录C FPGA产品保证通用技术要素确认检查表",
    "D": "附录D FPGA产品保证专用技术要素确认检查表",
}
UNIT = re.compile(r"5\.3\.[1-9][0-9]*")
SUBUNIT = re.compile(r"5\.3\.[1-9][0-9]*\.[1-9][0-9]*")
SOURCE = re.compile(r"<!-- function-source:(parent:[A-Za-z0-9._-]+) -->")
FIELDS = ("功能描述", "输入", "处理", "输出", "触发条件与时序")
EXAMPLE_FIELDS = ("功能描述", "输入", "输出", "处理", "触发条件与时序")
FIGURE_MARKER = "<!-- function-decomposition-figure -->"
FIGURE_CAPTION = "图5.3-1 FPGA产品功能分解图"
FIELD = re.compile(r"(" + "|".join(FIELDS) + r")：(.+)")
TEST_TOPICS = {
    "7.2.1": "功能仿真范围、检查方法及覆盖要求",
    "7.2.2": "时序验证方法、工况及覆盖范围",
    "7.2.3": "仿真环境和实际运行环境的差异与控制措施",
    "7.2.4": "仿真阶段不可测试项及替代验证",
    "7.3.1": "板级确认测试范围、环境及判定要求",
    "7.3.2": "确认测试环境、差异与控制措施",
    "7.3.3": "板级不可测试项、适用版本及处理措施",
    "7.3.4": "第三方评测范围、条件及交付要求",
}
VERIFICATION_GROUPS = {"7", "7.2", "7.3"}
TRACE_COLUMNS = {
    "A.1": ["序号", "需求名称", "需求编号", "章节号", "任务需求标识", "输入文件名称",
            "可复用需求（说明功能点的复用来源）", "属性"],
    "A.2": ["序号", "任务需求标识", "要求项", "需求标识", "需求去向", "属性"],
}
ASSURANCE_COLUMNS = [
    "序号", "要素类别", "要素名称", "检查项", "落实文件", "是否适用",
    "是否符合", "检查结果（落实文件、章节号和内容简述）", "配置项级软件产品保证工程师验证结果",
]
CAPTIONS = {"A.1": "表A-1 逆向跟踪矩阵", "A.2": "表A-2 正向跟踪矩阵",
            "B": "表B-1 更改记录",
            "10": "表1 FPGA产品保证技术要素自确认结果统计",
            "11": "表2 FPGA产品保证技术要素确认待办事项统计",
            "C": "表C-1 通用技术要素确认检查表", "D": "表D-1 专用技术要素确认检查表"}


def producer_version(model):
    version = model.get("protocol", {}).get("producer_version", "")
    return tuple(int(x) for x in version.split(".") if x.isdigit())


def enabled(model):
    return producer_version(model) >= (1, 5)


def follows_function_example(model):
    return producer_version(model) >= (1, 6)


def is_verification_group(model, number):
    return producer_version(model) >= (1, 5, 1) and number in VERIFICATION_GROUPS


def plan_sections(model):
    return next((v["sections"] for v in model["document_views"] if v["role"] == "writer_plan"), [])


def fields(section, leaf):
    result = {}
    for paragraph in section["paragraphs"]:
        paragraph = paragraph.strip()
        if not paragraph or SOURCE.fullmatch(paragraph):
            continue
        match = FIELD.fullmatch(paragraph)
        require(match is not None, "FUNCTION_FIELD_INVALID: " + section["number"] + " " + paragraph[:50])
        field, value = match.groups()
        require(field not in result, "FUNCTION_FIELD_DUPLICATE: " + section["number"] + " " + field)
        require(leaf or field == FIELDS[0], "FUNCTION_PARENT_FIELD_INVALID: " + section["number"])
        result[field] = value.strip()
    require(not result or section["material_element_refs"], "FUNCTION_FIELD_SOURCE_REQUIRED: " + section["number"])
    return result


def units(model):
    """Check parent identity, hierarchy and trace placement, then return render fields."""
    sections = plan_sections(model)
    related = [s for s in sections if s["number"].startswith("5.3.")]
    parents = {p["uid"]: p for p in model["source_baseline"]["parents"] if p["category"] == "function"}
    if not related and not parents:
        return {}
    reqs = {r["uid"]: r for r in model["requirements"] if r["lifecycle"] == "active"}
    expected = {uid for r in reqs.values() for uid in r["source_parent_refs"] if uid in parents}
    result, anchors = {}, set()
    current = None
    for section in related:
        number = section["number"]
        refs = section["primary_requirement_refs"] + section["cross_requirement_refs"]
        if UNIT.fullmatch(number):
            bindings = [SOURCE.fullmatch(p.strip()).group(1) for p in section["paragraphs"] if SOURCE.fullmatch(p.strip())]
            require(len(bindings) == 1 and bindings[0] in expected and bindings[0] not in anchors, "FUNCTION_PARENT_BINDING_INVALID: " + number)
            source = bindings[0]
            anchors.add(source)
            require(section["title"].rstrip("★") == parents[source]["title"], "FUNCTION_PARENT_TITLE_MISMATCH: " + number)
            current = number
            result[number] = {"source": parents[source]["source_id"], "uid": source, "refs": list(refs), "children": []}
        else:
            require(SUBUNIT.fullmatch(number) and number.rsplit(".", 1)[0] == current, "FUNCTION_SUBUNIT_ORDER_INVALID: " + number)
            require(not any(SOURCE.fullmatch(p.strip()) for p in section["paragraphs"]), "FUNCTION_SUBUNIT_SOURCE_INVALID: " + number)
            require(bool(section["primary_requirement_refs"]), "FUNCTION_SUBUNIT_EMPTY: " + number)
            result[current]["refs"].extend(refs)
            result[current]["children"].append(section)
            result[number] = {"source": None, "children": []}
        result[number]["section"] = section
    require(anchors == expected, "FUNCTION_PARENT_COVERAGE_MISMATCH: " + "、".join(sorted(expected - anchors)))
    for number, entry in result.items():
        section, children = entry["section"], entry["children"]
        if entry["source"]:
            require(any(entry["uid"] in reqs.get(uid, {}).get("source_parent_refs", []) for uid in entry["refs"]),
                    "FUNCTION_PARENT_REQUIREMENT_MISSING: " + number)
            require(not children or not section["primary_requirement_refs"], "FUNCTION_PARENT_AND_SUBUNIT_DUPLICATE_SCOPE: " + number)
        entry["fields"] = fields(section, not children)
    return result


def unit_index(units):
    rows = []
    for number, entry in units.items():
        if entry["source"]:
            title = entry["section"]["title"].rstrip("★")
            children = [s["number"] + " " + s["title"].rstrip("★") for s in entry["children"]]
            rows.append((number + " " + title, entry["source"], "、".join(children) or "见本单元详细要求"))
    return rows


def unit_body(entry, requirements, use_example):
    lines = []
    if not use_example and entry["source"]:
        lines.extend(["任务书功能项：" + entry["source"], ""])
    ids = entry["section"]["primary_requirement_refs"]
    if use_example and ids:
        lines.extend(["**需求编号：**" + "、".join(requirement_id(requirements[uid]) for uid in ids), ""])
    labels = EXAMPLE_FIELDS if use_example else FIELDS
    if entry["children"]:
        labels = labels[:1]
    for label in labels:
        value = entry["fields"].get(label)
        if value:
            lines.extend(["**" + label + "：**" + value, ""])
        elif not entry["children"]:
            lines.extend(["**" + label + "：**待确认（交接包未明确）", ""])
    return lines


def requirement_id(requirement):
    number = requirement["normalized_id"] or "待确认编号"
    if re.search(r"-K(?:N)?$", number):
        return number
    if any(r["uid"] == requirement["effective_revision_uid"] and r["semantic"]["safety_critical"] is True
           for r in requirement["revisions"]):
        return number + "-K"
    return number


def figure_rows(model, units):
    labels = [number + " " + unit["section"]["title"].rstrip("★")
              for number, unit in units.items() if unit["source"]]
    count = min(4, len(labels))
    title = model["basic_info"]["product_name"]
    root = title["value"] if title["status"] == "present" else "FPGA产品"
    yield [root] + [""] * (count - 1)
    for start in range(0, len(labels), count):
        row = labels[start:start + count]
        yield row + [""] * (count - len(row))


def review_rows(model):
    requirements = {r["uid"]: r for r in model["requirements"]}
    units_by_number = units(model)
    for number, unit in units_by_number.items():
        if unit["children"]:
            continue
        parent = unit if unit["source"] else units_by_number[number.rsplit(".", 1)[0]]
        section = unit["section"]
        refs = [requirement_id(requirements[uid]) for uid in section["primary_requirement_refs"]]
        yield (parent["source"], number + " " + section["title"], "、".join(refs) or "见引用")


def warnings(model):
    if not enabled(model):
        return []
    notes = []
    for number, unit in units(model).items():
        if not unit["children"]:
            missing = [label for label in FIELDS if label not in unit["fields"]]
            if missing:
                notes.append(number + " " + unit["section"]["title"] + "待确认：" + "、".join(missing))
    for section in plan_sections(model):
        number = section["number"]
        if number in TEST_TOPICS and section["status"] in ("missing", "unknown"):
            notes.append(number + " " + TITLES.get(number, section["title"]) + "待确认：" + TEST_TOPICS[number])
    return notes
