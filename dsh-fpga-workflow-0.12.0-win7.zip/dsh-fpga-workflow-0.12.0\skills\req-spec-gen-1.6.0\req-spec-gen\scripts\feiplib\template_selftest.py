"""Check functional hierarchy, missing source handling and trace placement."""
import copy

from .base import Failure
from .render import render
from .template_layout import FIGURE_CAPTION, review_rows, warnings


def run_tests(seed):
    model = copy.deepcopy(seed)
    model["source_baseline"]["parents"][0]["category"] = "function"
    main = next(v for v in model["document_views"] if v["role"] == "writer_plan")["sections"]
    old = next(s for s in main if s["number"] == "5.4")
    old["primary_requirement_refs"] = []
    req = copy.deepcopy(model["requirements"][0])
    req.update(uid="req:response", normalized_id="TEST-FREQ-2")
    model["requirements"].append(req)
    parent = copy.deepcopy(old)
    parent.update(number="5.3.1", title="响应时间", tables=[], paragraphs=["<!-- function-source:parent:ur1 -->"])
    child = copy.deepcopy(parent)
    child.update(number="5.3.1.1", title="命令接收", primary_requirement_refs=["req:latency"],
                 paragraphs=["输入：有效命令"], material_element_refs=["element:synthetic"])
    sibling = copy.deepcopy(child)
    sibling.update(number="5.3.1.2", title="响应输出", primary_requirement_refs=["req:response"],
                   paragraphs=["输出：响应"])
    index = main.index(old)
    main[index:index] = [parent, child, sibling]
    before = copy.deepcopy(model)
    report = render(model)
    assert "#### 5.3.1 响应时间" in report and "##### 5.3.1.1 命令接收" in report
    assert "**输入：**有效命令" in report and "任务书功能项：UR-1" not in report
    assert FIGURE_CAPTION in report and "**详细要求**" not in report
    leaf = report.split("##### 5.3.1.1 命令接收", 1)[1].split("##### ", 1)[0]
    labels = ["需求编号", "功能描述", "输入", "输出", "处理", "触发条件与时序"]
    indexes = [leaf.index("**" + label + "：**") for label in labels]
    assert indexes == sorted(indexes)
    assert list(review_rows(model)) == [
        ("UR-1", "5.3.1.1 命令接收", "TEST-PREQ-1"),
        ("UR-1", "5.3.1.2 响应输出", "TEST-FREQ-2"),
    ]
    import io
    from docx import Document
    from .docx_writer import build
    doc = Document(io.BytesIO(build(report, model)))
    figure = next(t for t in doc.tables if len(t.rows) == 2 and t.rows[1].cells[0].text == "5.3.1 响应时间")
    assert figure._tbl.tblPr.xpath("./w:tblCellSpacing") and any(p.text == FIGURE_CAPTION for p in doc.paragraphs)
    assert report.count("〔TEST-PREQ-1〕") == report.count("〔TEST-FREQ-2〕") == 1
    assert "需求名称 | 需求编号 | 章节号" in report and "TEST-FREQ-2 | 5.3.1.2" in report
    assert "function-source" not in report and before == model
    assert any("5.3.1.1" in note and "触发条件与时序" in note for note in warnings(model))
    sections = {section["number"]: section for section in main}
    for number in ("7", "7.2", "7.3", "7.2.3"):
        sections[number].update(status="unknown", reason="待核对" + number + "的环境与条件")
    report = render(model)
    assert all("待核对" + number + "的环境与条件" not in report for number in ("7", "7.2", "7.3"))
    assert "待核对7.2.3的环境与条件" in report
    child["material_element_refs"] = []
    try:
        render(model)
    except Failure as exc:
        assert "FUNCTION_FIELD_SOURCE_REQUIRED" in str(exc)
    else:
        raise AssertionError("accepted function field without a source")
    return ["template-function-tree-places-each-obligation-and-trace-once",
            "template-example-field-order-editable-figure-and-review-rows",
            "template-verification-gaps-listed-at-leaf-sections",
            "template-rejects-unbound-function-prose-and-reports-missing-fields"]
