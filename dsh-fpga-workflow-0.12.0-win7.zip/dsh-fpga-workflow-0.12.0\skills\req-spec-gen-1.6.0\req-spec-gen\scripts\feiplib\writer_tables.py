"""Resolve template tables against canonical objects, without a second data table."""
import copy
import re

from .base import SKILL, load, require


def policy(number, model=None):
    from .template_layout import enabled
    if number in ("10", "11", "C", "D"):
        return "manual"
    if not enabled(model or {}) and (number == "7" or (number.startswith("7.") and number != "7.1")):
        return "deferred"
    return "auto"


def is_signal_table(table):
    return "信号名称" in table["columns"] and "信号方向" in table["columns"]


def raw_table(paragraphs):
    # Paragraphs may contain prose with pipes, but not a Markdown table separator.
    return re.search(r"(?m)^\s*\|?\s*:?-{3,}:?\s*\|(?:\s*:?-{3,}:?\s*\|?)+\s*$", "\n".join(paragraphs)) is not None


def objects_for(table, section, model):
    """Only infer bindings with an unambiguous canonical scope, never from titles."""
    analysis = model["analysis"]
    number = section["number"]
    if number == "7.1":
        return model["verification"]["source_test_points"]
    if is_signal_table(table):
        signals = analysis["signals"]
        if number == "5.2":
            return signals
        interface_ids = {r["uid"] for r in section["object_refs"] if r["kind"] == "interface"}
        refs = set(section["primary_requirement_refs"] + section["cross_requirement_refs"])
        interface_ids.update(i["header"]["uid"] for i in analysis["interfaces"]
                             if refs.intersection(i["header"]["requirement_refs"]))
        if not interface_ids:
            return []
        return [s for s in signals if s["interface_uid"] in interface_ids]
    if number in ("5.4", "5.6") and "需求标识" in table["columns"]:
        refs = set(section["primary_requirement_refs"])
        return [r for r in model["requirements"] if r["uid"] in refs and r["lifecycle"] == "active"]
    if number == "5.7" and "时钟域名称" in table["columns"]:
        return [c for c in analysis["clocks"] if c["scope"] == "external"]
    if number == "5.1.5" and "IP模块" in table["columns"]:
        return [r for r in analysis["platform_resources"] if r["kind"] == "ip"]
    if number == "6.2" and "关键数据名称" in table["columns"]:
        return analysis["data_objects"]
    return []


def resolve(section, template, model):
    """Merge same-schema duplicates; reject conflicting or raw duplicate projections."""
    require(not raw_table(section["paragraphs"]),
            "RAW_TABLE_IN_PARAGRAPHS: use tables/row_object_refs in section " + section["number"])
    required = [t for t in template["tables"] if t["section"] == section["number"]]
    tables = []
    for table in copy.deepcopy(section["tables"]):
        if section["number"] == "7.1":
            from .source_test_points import COLUMNS, LEGACY_COLUMNS
            if table["columns"] == LEGACY_COLUMNS:
                table["columns"] = list(COLUMNS)
        require(table["columns"] and len(table["columns"]) == len(set(table["columns"])),
                "TABLE_COLUMNS_INVALID: " + table["caption"])
        canonical_schema = len([t for t in required if t["columns"] == table["columns"]]) == 1
        match = next((t for t in tables if t["caption"] == table["caption"]
                      or (canonical_schema and t["columns"] == table["columns"])
                      or (is_signal_table(t) and is_signal_table(table))), None)
        if match is not None:
            require(match["columns"] == table["columns"],
                    "DUPLICATE_TABLE_PURPOSE: put rows in the template table, not a second projection: " + section["number"])
            match["row_object_refs"].extend(table["row_object_refs"])
            match["evidence_refs"] = list(dict.fromkeys(match["evidence_refs"] + table["evidence_refs"]))
            # Prefer the fixed caption even when the supplementary table came first.
            canonical = next((t for t in required if t["columns"] == match["columns"]), None)
            if canonical:
                match["caption"] = canonical["caption"]
            continue
        tables.append(table)
    for item in required:
        candidates = [t for t in tables if t["caption"] == item["caption"] and t["columns"] == item["columns"]]
        require(len(candidates) == 1, "TEMPLATE_TABLE_MISSING_OR_CHANGED: " + item["id"])
    for table in tables:
        unique = {}
        for row in table["row_object_refs"]:
            key = row["uid"]
            require(key not in unique or unique[key] == row, "TABLE_ROW_REFERENCE_CONFLICT: " + key)
            unique[key] = row
        table["row_object_refs"] = list(unique.values())
        if policy(section["number"], model) != "auto":
            require(not table["row_object_refs"], "MANUAL_TABLE_MUST_BE_EMPTY")
            continue
        objects = objects_for(table, section, model)
        available = [o.get("header", o)["uid"] for o in objects]
        if section["number"] == "7.1":
            require(all(r["uid"] in available and r["kind"] == "testpoint" for r in table["row_object_refs"]),
                    "TEST_POINT_TABLE_ROW_NOT_SOURCE_POINT")
        if is_signal_table(table):
            known_signals = {s["header"]["uid"] for s in model["analysis"]["signals"]}
            require(all(r["uid"] in known_signals for r in table["row_object_refs"]),
                    "SIGNAL_TABLE_ROW_NOT_SIGNAL: " + section["number"])
        if not table["row_object_refs"] and available:
            table["row_object_refs"] = [{"kind": uid.split(":", 1)[0], "uid": uid, "revision_uid": None} for uid in available]
        if section["number"] == "7.1":
            require({r["uid"] for r in table["row_object_refs"]} == set(available), "TEST_POINT_TABLE_SCOPE_MISMATCH")
            table["row_object_refs"].sort(key=lambda r: available.index(r["uid"]))
        if is_signal_table(table) and available:
            require({r["uid"] for r in table["row_object_refs"]} == set(available),
                    "SIGNAL_TABLE_SCOPE_MISMATCH: " + section["number"])
    return tables


def empty_note(section, table, model=None):
    number = section["number"]
    if policy(number, model) != "auto":
        return None
    if number in ("2.1", "2.2"):
        return "未提供本类引用文件清单，本表留空。"
    if number == "B":
        return "未提供对应的真实更改记录，本表留空。"
    if section["status"] == "not_applicable":
        require(bool(section["reason"]), "EMPTY_TABLE_APPLICABILITY_REASON_REQUIRED: " + number)
        return "不适用：" + section["reason"]
    return "待确认：" + (section["reason"] or "未提供可可靠映射到本表的结构化数据，请补充来源及行对象引用。")


def warnings(model):
    template = load(SKILL / "templates/document_structure.json")
    notes = []
    for view in model["document_views"]:
        if view["role"] != "writer_plan":
            continue
        for section in view["sections"]:
            if section["number"] in ("1.3", "2.1", "2.2", "5.1.1", "5.1.3"):
                continue
            for table in resolve(section, template, model):
                if section["number"] not in ("A.1", "A.2") and not table["row_object_refs"]:
                    note = empty_note(section, table, model)
                    if note and note.startswith("待确认"):
                        notes.append(section["number"] + " " + table["caption"] + "：" + note)
    return notes


def trace_rows(model, section, columns):
    """Fill A.1 and A.2 themselves instead of appending a substitute matrix."""
    parents = {p["uid"]: p["source_id"] for p in model["source_baseline"]["parents"]}
    atoms = {a["uid"]: a["source_id"] for a in model["source_baseline"]["atomic_requirements"]}
    plan = next(v for v in model["document_views"] if v["role"] == "writer_plan")
    result = []
    for req in model["requirements"]:
        locations = [s["number"] for s in plan["sections"] if req["uid"] in s["primary_requirement_refs"]]
        deferred = [s["number"] + "（" + policy(s["number"], model) + "）" for s in plan["sections"]
                    if policy(s["number"], model) != "auto" and req["uid"] in s["cross_requirement_refs"]]
        semantic = next((r["semantic"] for r in req["revisions"] if r["uid"] == req["effective_revision_uid"]), {})
        description = semantic.get('statement', req['title'])
        if description.startswith('col='):
            description = re.sub(r'——原子义务\d+$', '', req['title']) + '（完整数据表见' + '、'.join(locations) + ' ' + str(req['normalized_id']) + '）'
        source = [parents[p] for p in req["source_parent_refs"]] + [atoms[a] for a in req["source_atomic_refs"]]
        document = model["source_baseline"]["source_document_artifact_uid"]
        archive = next((a for a in model["document_archive"] if a.get("source_artifact_uid", a.get("artifact_uid")) == document), None)
        filename = archive.get("source_name", archive.get("name")) if archive else None
        values = {"序号": len(result) + 1,
                  "需求规格说明(需求名称/需求编号/章节号)": [re.sub(r'——原子义务\d+$', '', req["title"]), req["normalized_id"]] + locations + deferred,
                  "输入文件(任务需求标识/输入文件名称)": source + [filename or '输入任务书（同包归档）'],
                  "可置信要求": None, "属性": "".join(semantic.get("attributes", [])),
                  "任务需求标识": source, "要求项": description,
                  "需求标识": req["normalized_id"], "需求向": None,
                  "属性（附列表格头）": "".join(semantic.get("attributes", []))}
        values.update({"需求名称": re.sub(r'——原子义务\d+$', '', req["title"]),
                       "需求编号": req["normalized_id"], "章节号": locations + deferred,
                       "输入文件名称": filename or '输入任务书（同包归档）',
                       "可复用需求（说明功能点的复用来源）": "待确认" if "R" in semantic.get("attributes", []) else "—",
                       "需求去向": locations + deferred})
        require(all(c in values for c in columns), "TRACE_TABLE_COLUMNS_UNSUPPORTED: " + section)
        result.append([values[c] for c in columns])
    return result
