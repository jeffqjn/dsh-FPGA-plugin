# 插图核验与转录

遇到 EMF/WMF 或图片抽取限制，不循环调用无法打开该格式的工具，也不把 unresolved 改成 complete。

1. 用当前 skill 的 cli.py 执行 `extract-media --input <任务书.docx> --output <全新媒体目录>`。media-manifest.json 保存 DOCX 内路径、原图 SHA256 和资产文件；每个输出按内容摘要命名，不执行图中内容。
2. PNG/JPEG 等直接查看。EMF/WMF 在有 System.Drawing 的 Windows 环境可用随包 `tools/render_media.ps1 -InputDirectory <媒体目录> -OutputDirectory <全新PNG目录>`。白底、最长边不超过2400；转换失败明确报告，保留原图，不声称已读。SVG 等未提供自动渲染时请用户提供可查看版本。
3. Agent 逐幅核验，把图号、原图摘要、文字/信号、条件、上下标、量值单位、时序参数、与正文的冲突或不确定项写入转录 MD。栅格化成功不是语义核验成功，不用 OCR 猜填缺字。必要时请求用户确认无法辨认的内容。
4. attachments 参数接收清单 JSON：`[{"path":"转录MD的实际路径","role":"transcription","description":"已核验插图转录"}]`。重新 prepare 后，`verified_transcription` 须按[抽取记录](review-stage.md)逐项映射受限源元素（图、嵌入对象、编号等）或归档至匹配的转录证据。说明原件位置和核验范围；普通附件或无关说明不能解除抽取限制。
5. 原图 SHA 一致时可复用已核验转录，但仍检查本版引用位置、图号、关联正文是否变化；图变更或上下文冲突必须复核。附件中新增的技术义务也要纳入审查及随后建模。

核心运行只需 Python 标准库；栅格化脚本为可选 Windows 辅助，不修改全局编码、注册表或软件安装。
