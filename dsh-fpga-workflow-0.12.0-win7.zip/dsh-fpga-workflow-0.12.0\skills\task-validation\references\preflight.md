# 局部建模快速预检（1.7.0）

```text
model-preflight --attempt <建模attempt目录>
```

返回valid、local_total/local_done、error_count、report_json、report_md、cache_hit和elapsed_seconds。完整问题清单在报告中，终端只返回摘要，避免大量JSON进入Agent上下文。FEIP_SKILL_OK:model-preflight表示扫描已执行，只有valid=true才表示本次局部结构预检通过。

该动作只读取冻结的模型模板、分片manifest及已提交局部checkpoint JSON，不重新解析DOCX，不调用大模型，不生成/修改需求或meta。会写诊断报告和可重建缓存，保留全部原始checkpoint。可对兼容的旧建模attempt进行诊断，不要求旧审查的策略摘要与新版本一致；这不升级旧attempt、不改变源状态、也不授权继续生成。继续生成仍执行原来的源、规则版本与授权绑定。

## 检查范围

- 单片提交前：源父条款、atom和source修订证据非空，evidence UID有效，同片atom与source修订语义完全一致；相同UID内容/集合冲突、相同完整source_id对应不同UID、声明complete却缺字段的源测试要点、Fact状态/取值不一致和规范性素材被降为描述/历史。
- meta前一次局部汇总：上述问题以及跨片未解析引用、跨片源语义不一致、未进入工程台账的atom、inventory遗漏/pending、无主落点/多个落点及不合法章节。冲突提供任务ID、checkpoint路径、字段位置、另一任务及差异字段。
- 不把UR前缀或目录/附录中的编号引用自动当成需求。原子身份和来源语义仍由Agent判断，具体规则见[建模约束](modeling.md)。预检通过不代替语义审查，不意味着所有最终业务检查必然通过；structure仍运行全量检查。

允许局部任务未完成时存在前向对象引用。单片内部可以确定的错误立即拒绝；跨片同步修订期间的暂时语义差异会提示，但允许逐片修正。meta门禁要求全部局部任务完成且汇总问题清零。正常模式及明确授权的skill测试模式都不能绕过空证据、身份和引用等确定性要求。

## 性能与恢复

对象索引按任务payload_sha256更新摘要；校验复用已读取的checkpoint，不额外遍历原文。局部预检结果绑定当前manifest、每个局部片段摘要和检查器版本；meta内容变化不使该缓存过期。缓存损坏/版本变化可重建，checkpoint摘要不一致仍报错，不因缓存存在而忽略。

局部片段发生修正时仅重建变化对象摘要，进度返回LOCAL_PREFLIGHT_REQUIRED；普通进度查询不会每修一片就重新跑全量预检。集中修正相关任务后执行一次model-preflight，或在领取meta时由脚本运行一次。五个meta保留原有全局依赖：旧版本失效后，领取任务会返回保留旧字段的待复核草稿，不强制从头生成。Agent核对差异后提交；禁止把全量重提、五meta重写当作每次修正的固定步骤。

处理顺序：提交局部片段并检查返回的progress → 若LOCAL_MODEL_INVALID则读取报告、集中修正相关任务，LOCAL_PREFLIGHT_REQUIRED表示等待重新预检 → model-preflight确认valid=true → 填写/复核五个meta → structure。model-submit成功返回进度后通常不必额外执行model-status；如宿主没有明确正在执行的命令/会话，不以sleep代替错误定位。
