"""Extract bounded DOCX illustration assets; never silently transcribe them."""
import hashlib
import zipfile
from pathlib import Path
from .base import require, save


def extract_media(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    require(source.is_file() and source.suffix.lower() == ".docx", "MEDIA_REQUIRES_DOCX")
    require(not output.exists(), "MEDIA_OUTPUT_EXISTS")
    output.mkdir(parents=True)
    records = []
    with zipfile.ZipFile(str(source)) as archive:
        entries = [i for i in archive.infolist() if i.filename.startswith("word/media/") and not i.is_dir()]
        require(len(entries) <= 2000 and sum(i.file_size for i in entries) <= 256 * 1024 * 1024, "DOCX_MEDIA_BUDGET_EXCEEDED")
        for entry in entries:
            require(entry.file_size <= 32 * 1024 * 1024, "DOCX_MEDIA_ASSET_TOO_LARGE: " + entry.filename)
            data = archive.read(entry)
            sha = hashlib.sha256(data).hexdigest()
            suffix = Path(entry.filename).suffix.lower()
            require(suffix in (".emf", ".wmf", ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".svg"), "MEDIA_TYPE_NOT_SUPPORTED: " + suffix)
            name = sha + suffix
            (output / name).write_bytes(data)
            records.append({"source_part": entry.filename, "sha256": sha, "path": name, "bytes": len(data), "transcription_status": "not_performed"})
    save(output / "media-manifest.json", {"contract": "feip-media/1.0", "source": str(source), "assets": records})
    return {"output": str(output), "assets": len(records), "manifest": str(output / "media-manifest.json"),
            "next": "Inspect raster images; optionally render EMF/WMF with tools/render_media.ps1; record verified transcription and matching asset SHA."}
