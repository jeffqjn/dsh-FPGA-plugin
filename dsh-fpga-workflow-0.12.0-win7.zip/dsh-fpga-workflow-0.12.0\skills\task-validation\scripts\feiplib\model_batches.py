"""Confirmed, resumable model fragments; scripts assemble and render the final model."""
import copy
import json
from functools import lru_cache
from pathlib import Path

from . import contract
from .base import SKILL, check_model, digest, effective, known_artifacts, load, now, require, save, text, verify_inputs
from .batches import filename, fingerprint, source_manifest

META_GROUPS = ("meta", "basic_info", "system_overview", "acceptance", "views")


class ModelManifest(dict):
    """Memoize this immutable manifest's digest within a command, without changing JSON."""
    def __init__(self, value):
        super().__init__(value)
        self.basis = fingerprint(value)
        self.meta_basis = {}


def manifest_basis(manifest):
    return manifest.basis if isinstance(manifest, ModelManifest) else fingerprint(manifest)


def is_metadata(task_uid):
    return task_uid.startswith("model:meta-")


def get(document, pointer):
    require(isinstance(pointer, str) and pointer.startswith("/") and "~" not in pointer, "MODEL_POINTER_INVALID")
    result = document
    for part in pointer[1:].split("/"):
        result = result[part]
    return result


def put(document, pointer, value):
    parent, name = pointer.rsplit("/", 1)
    target = get(document, parent) if parent else document
    target[name] = value


def allowed_paths(base):
    collections = ["/" + k for k in ("acronyms", "reference_documents", "change_log", "requirements", "design_objects")]
    collections += ["/source_baseline/" + k for k in ("raw_snapshots", "parents", "atomic_requirements", "interface_refs", "test_point_refs")]
    collections += ["/" + group + "/" + k for group in ("analysis", "verification") for k in base[group]]
    collections += ["/traceability/" + k for k in ("relations", "mappings")]
    collections += ["/acceptance/" + k for k, v in base["acceptance"].items() if isinstance(v, list)]
    collections += ["/completeness/checks", "/completeness/gaps", "/consistency/provenance"]
    fields = ["/" + group + "/" + k for group in ("basic_info", "system_overview", "views") for k in base[group]]
    fields += ["/meta/" + k for k in base["meta"] if k != "project_uid"]
    fields += ["/acceptance/third_party"]
    return collections, fields


def initialize(attempt, info, base, budget=4000):
    attempt = Path(attempt)
    # Modeling output is much larger than source text; reserve room for generated objects.
    source = source_manifest(base["document_archive"], min(budget, 1500), max_units=4)
    collections, fields = allowed_paths(base)
    manifest = {"contract": "taskbook-model-batches/1.0", "run_uid": info["run_uid"], "source": source,
                "template_sha256": digest(attempt / "model.template.json"), "collection_paths": collections, "field_paths": fields}
    save(attempt / "model-work/manifest.json", manifest)
    (attempt / "model-work/checkpoints").mkdir()
    units = {u["uid"]: u for u in source["units"]}
    evidence = {e["element_uid"]: e["uid"] for e in base["consistency"]["evidence"]}
    for chunk in source["chunks"]:
        packet = {"task_uid": "model:" + chunk["uid"].split(":")[1], "section": chunk["section"], "units": [units[r] for r in chunk["unit_refs"]],
                  "evidence": {units[r]["element_uid"]: evidence[units[r]["element_uid"]] for r in chunk["unit_refs"]}}
        save(attempt / "model-work/packets" / filename(packet["task_uid"]), packet)
    for path in [attempt / "model-work/manifest.json", attempt / "model.template.json"] + list((attempt / "model-work/packets").glob("*.json")):
        info["input_bindings"].append({"path": path.relative_to(attempt).as_posix(), "sha256": digest(path)})
    info["model_batching"] = {"manifest": "model-work/manifest.json"}
    save(attempt / "attempt.json", info)
    return {"fragments": len(source["chunks"]) + len(META_GROUPS), "next": "model-next --attempt <attempt>; do not read the full model template"}


def workspace(attempt):
    from .review_stage import verify_structure_attempt
    attempt = Path(attempt)
    verify_structure_attempt(attempt)
    info = verify_inputs(attempt)
    require(info.get("kind") == "taskbook" and info.get("model_batching"), "CONFIRMED_MODEL_BATCH_ATTEMPT_REQUIRED")
    manifest = ModelManifest(load(attempt / info["model_batching"]["manifest"]))
    require(manifest["template_sha256"] == digest(attempt / "model.template.json"), "MODEL_TEMPLATE_CHANGED")
    return attempt, info, manifest


def tasks(manifest):
    return ["model:" + c["uid"].split(":")[1] for c in manifest["source"]["chunks"]] + ["model:meta-" + g for g in META_GROUPS]


def task_basis(manifest, task_uid, records):
    if not is_metadata(task_uid):
        return manifest_basis(manifest)
    # Preserve the existing on-disk basis algorithm for old checkpoints.
    local = {k: v["payload_sha256"] for k, v in records.items() if not is_metadata(k)}
    key = tuple(sorted(local.items()))
    if isinstance(manifest, ModelManifest) and key in manifest.meta_basis:
        return manifest.meta_basis[key]
    result = fingerprint({"manifest": manifest, "local": local})
    if isinstance(manifest, ModelManifest):
        manifest.meta_basis[key] = result
    return result


def saved(attempt, manifest):
    result = {}
    for task_uid in tasks(manifest):
        path = Path(attempt) / "model-work/checkpoints" / filename(task_uid)
        if path.exists():
            row = load(path)
            require(row["payload_sha256"] == fingerprint(row["payload"]), "MODEL_CHECKPOINT_CORRUPT")
            require(row["payload"]["run_uid"] == manifest["run_uid"], "MODEL_CHECKPOINT_STALE")
            if is_metadata(task_uid) and row["payload"]["basis_sha256"] != task_basis(manifest, task_uid, result):
                continue
            require(row["payload"]["basis_sha256"] == task_basis(manifest, task_uid, result), "MODEL_CHECKPOINT_STALE")
            result[task_uid] = row
    return result


def status(attempt):
    attempt, info, manifest = workspace(attempt)
    records = saved(attempt, manifest)
    return progress(attempt, info, manifest, records)


def progress(attempt, info, manifest, records, base=None):
    pending = [t for t in tasks(manifest) if t not in records]
    discoveries = sum(len(r["payload"]["new_issues"]) for r in records.values())
    if (attempt / "model-work/return-to-review.json").exists():
        discoveries = max(discoveries, 1)
    test_mode = info.get("skill_test") is True
    local_complete = all(t in records for t in tasks(manifest) if not is_metadata(t))
    preflight = None
    if local_complete:
        from .model_preflight import peek
        checked = peek(attempt, manifest, records)
        preflight = {k: checked[k] for k in ("valid", "error_count", "report_json", "report_md", "cache_hit")} if checked else {
            "valid": None, "error_count": None, "report_json": None, "report_md": None, "cache_hit": False}
    return {"fragments_total": len(tasks(manifest)), "fragments_done": len(records), "new_issues": discoveries,
            "next_task": pending[0] if pending else None, "complete": not pending and (test_mode or not discoveries) and bool(preflight and preflight["valid"]),
            "skill_test": test_mode, "test_only": test_mode,
            "preflight": preflight,
            "state": "RETURN_TO_REVIEW" if discoveries and not test_mode else "LOCAL_PREFLIGHT_REQUIRED" if preflight and preflight["valid"] is None else "LOCAL_MODEL_INVALID" if preflight and not preflight["valid"] else "MODELING" if pending else "READY_TO_ASSEMBLE"}


@lru_cache(maxsize=1)
def engineering_schema():
    return load(SKILL / "references/protocol/schemas/engineering.schema.json")


def schema_at(pointer):
    schema = engineering_schema()
    node = schema
    for name in pointer[1:].split("/"):
        if "$ref" in node:
            node = contract.resolve_ref(schema, node["$ref"])
        node = node["properties"][name]
    return node, schema


def export_schema(attempt, pointer):
    attempt, info, manifest = workspace(attempt)
    require(pointer in manifest["collection_paths"] + manifest["field_paths"] + ["/completeness/content_inventory"], "MODEL_PATH_NOT_ALLOWED")
    node, schema = schema_at(pointer)
    defs, pending = {}, [node]
    while pending:
        current = pending.pop()
        if isinstance(current, dict):
            if "$ref" in current:
                name = current["$ref"].split("/")[-1]
                if name not in defs:
                    defs[name] = schema["$defs"][name]
                    pending.append(defs[name])
            pending += list(current.values())
        elif isinstance(current, list):
            pending += current
    result = copy.deepcopy(node)
    result["$defs"] = defs
    target = attempt / "model-work/schema-part.json"
    save(target, result)
    # A compact field/type guide avoids feeding pretty-printed Schema scaffolding to a small Agent.
    def describe(node):
        if "$ref" in node:
            return node["$ref"].split("/")[-1]
        if "anyOf" in node:
            return " | ".join(describe(n) for n in node["anyOf"])
        if "enum" in node:
            return "enum(" + ",".join(json.dumps(v, ensure_ascii=False) for v in node["enum"]) + ")"
        if "const" in node:
            return "const(" + json.dumps(node["const"], ensure_ascii=False) + ")"
        kind = node.get("type", "any")
        if kind == "array":
            return "Array<" + describe(node["items"]) + ">"
        if kind == "object":
            required = node.get("required", [])
            return "{" + "; ".join(k + ("" if k in required else "?") + ": " + describe(v) for k, v in node.get("properties", {}).items()) + "}"
        if node.get("pattern") == "^[a-z][a-z_]*:[A-Za-z0-9._-]+$":
            return "UID"
        return str(kind) + (" pattern=" + node["pattern"] if "pattern" in node else "")
    guide = ["# " + pointer, "UID = kind:stable-id; ? = optional field. No technical defaults are implied.", "ROOT = " + describe(node)]
    guide += [name + " = " + describe(definition) for name, definition in defs.items()]
    guide_path = attempt / "model-work/schema-guide.txt"
    text(guide_path, "\n\n".join(guide) + "\n")
    return {"path": str(guide_path), "schema_path": str(target), "model_path": pointer, "bytes": guide_path.stat().st_size,
            "note": "Read the compact field/type guide first; exact constraints remain in the companion Schema and submission validator."}


def task_template(attempt, manifest, task_uid, records=None, base=None):
    base = load(Path(attempt) / "model.template.json") if base is None else base
    records = saved(attempt, manifest) if records is None else records
    template = {"contract": "taskbook-model-fragment/1.0", "run_uid": manifest["run_uid"], "task_uid": task_uid,
                "basis_sha256": task_basis(manifest, task_uid, records), "covered_unit_refs": [], "collections": {}, "fields": {},
                "inventory": [], "placements": [], "section_notes": {}, "new_issues": []}
    if not is_metadata(task_uid):
        chunk_uid = "chunk:" + task_uid.split(":")[1]
        chunk = next(c for c in manifest["source"]["chunks"] if c["uid"] == chunk_uid)
        template["covered_unit_refs"] = chunk["unit_refs"]
        units = {u["uid"]: u for u in manifest["source"]["units"]}
        refs = {units[r]["element_uid"] for r in chunk["unit_refs"]}
        template["inventory"] = [row for row in base["completeness"]["content_inventory"] if row["element_uid"] in refs]
    else:
        group = task_uid.split("meta-")[1]
        template["fields"] = {p: get(base, p) for p in manifest["field_paths"] if p.split("/")[1] == group}
    return template


def next_task(attempt, task_uid=None):
    attempt, info, manifest = workspace(attempt)
    records = saved(attempt, manifest)
    if info.get("skill_test") is not True and ((attempt / "model-work/return-to-review.json").exists() or any(r["payload"]["new_issues"] for r in records.values())):
        return {"state": "RETURN_TO_REVIEW", "next": "Resolve new issues and obtain user confirmation for the revised review before continuing."}
    order = tasks(manifest)
    if task_uid is None:
        task_uid = next((t for t in order if t not in records), None)
    if task_uid is None:
        from .model_preflight import run, require_valid
        require_valid(run(attempt, manifest, records))
        return {"complete": True, "next": "structure --attempt <attempt> --output <new-directory>"}
    require(task_uid in order, "UNKNOWN_MODEL_TASK")
    if is_metadata(task_uid):
        require(all(t in records for t in order if not is_metadata(t)), "LOCAL_MODEL_FRAGMENTS_INCOMPLETE")
        from .model_preflight import run, require_valid
        require_valid(run(attempt, manifest, records))
    template = records[task_uid]["payload"] if task_uid in records else task_template(attempt, manifest, task_uid, records)
    recheck = False
    old_path = attempt / "model-work/checkpoints" / filename(task_uid)
    if is_metadata(task_uid) and task_uid not in records and old_path.exists():
        old = load(old_path)
        require(old["payload_sha256"] == fingerprint(old["payload"]), "MODEL_CHECKPOINT_CORRUPT")
        if old["payload"]["run_uid"] == manifest["run_uid"]:
            template["fields"].update({p: copy.deepcopy(v) for p, v in old["payload"]["fields"].items() if p in template["fields"]})
            recheck = True
    target = attempt / "model-work/tasks" / filename(task_uid)
    save(target, template)
    catalog = {"allowed_collection_paths": manifest["collection_paths"], "allowed_field_paths": list(template["fields"]) if is_metadata(task_uid) else [],
               "writer_sections": load(SKILL / "templates/document_structure.json")["titles"],
               "uid_namespace_suggestion": task_uid.split(":")[1] + "-",
               "source_lookup": "model-read --path /source-index or /source-unit/unit:...; original review object index is in closed_review, accessible by review-read --subject",
               "next": "Request only needed schemas with model-schema --path; inspect existing collections using model-read, paginated."}
    catalog["preflight"] = "Local fragments are checked before metadata. Fix only reported fragments; rerun model-preflight. Metadata only fills its fields. Reused fields are drafts: recheck affected facts before submitting the refreshed template."
    if info.get("skill_test") is True:
        from .skill_test import NOTICE
        catalog["skill_test"] = {"test_only": True, "notice": NOTICE,
            "instructions": "Preserve original facts and unknown values. Record new_issues; the script retains them and simulates closure only in the test model. Do not invent technical values or test results. Prior issues: model-read --path /extensions, paginated."}
    catalog_path = attempt / "model-work/task-guide.json"
    save(catalog_path, catalog)
    return {"task_uid": task_uid, "template": str(target), "guide": str(catalog_path),
            "reading": str(attempt / "model-work/packets" / filename(task_uid)) if not is_metadata(task_uid) else None,
            "already_done": task_uid in records, "recheck_required": recheck}


def submit(attempt, model_file):
    attempt, info, manifest = workspace(attempt)
    require(not (attempt / "inputs/agent_model.json").exists(), "MODEL_ALREADY_PUBLISHED")
    payload = load(model_file)
    require(payload.get("contract") == "taskbook-model-fragment/1.0" and payload.get("run_uid") == info["run_uid"], "MODEL_FRAGMENT_BINDING_INVALID")
    require(set(payload) == {"contract", "run_uid", "task_uid", "basis_sha256", "covered_unit_refs", "collections", "fields", "inventory", "placements", "section_notes", "new_issues"}, "MODEL_FRAGMENT_FIELDS_INVALID")
    task_uid = payload["task_uid"]
    require(task_uid in tasks(manifest), "UNKNOWN_MODEL_TASK")
    records = saved(attempt, manifest)
    base = load(attempt / "model.template.json")
    expected = task_template(attempt, manifest, task_uid, records, base)
    require(payload["basis_sha256"] == expected["basis_sha256"], "MODEL_FRAGMENT_BINDING_INVALID")
    if is_metadata(task_uid):
        require(all(t in records for t in tasks(manifest) if not is_metadata(t)), "LOCAL_MODEL_FRAGMENTS_INCOMPLETE")
        from .model_preflight import run, require_valid
        require_valid(run(attempt, manifest, records, base))
        require(not payload["collections"] and not payload["inventory"] and not payload["placements"] and not payload["section_notes"],
                "MODEL_METADATA_FIELDS_ONLY: put source objects in local fragments before preflight")
    require(set(payload["covered_unit_refs"]) == set(expected["covered_unit_refs"]) and len(payload["covered_unit_refs"]) == len(expected["covered_unit_refs"]), "MODEL_FRAGMENT_SOURCE_COVERAGE_INCOMPLETE")
    require(set(payload["collections"]) <= set(manifest["collection_paths"]), "MODEL_IMMUTABLE_PATH")
    require(set(payload["fields"]) <= set(expected["fields"]), "MODEL_FIELDS_ONLY_IN_CORRESPONDING_METADATA_TASK")
    for pointer, value in list(payload["collections"].items()) + list(payload["fields"].items()):
        node, schema = schema_at(pointer)
        errors = contract.validate_schema(value, node, schema)
        require(not errors, "MODEL_FRAGMENT_SCHEMA_INVALID: " + pointer + " " + str(errors[:8]))
    require({r["element_uid"] for r in payload["inventory"]} == {r["element_uid"] for r in expected["inventory"]}
            and len(payload["inventory"]) == len(expected["inventory"]), "MODEL_FRAGMENT_INVENTORY_INCOMPLETE")
    node, schema = schema_at("/completeness/content_inventory")
    errors = contract.validate_schema(payload["inventory"], node, schema)
    require(not errors, "MODEL_FRAGMENT_INVENTORY_INVALID: " + str(errors[:8]))
    structure = load(SKILL / "templates/document_structure.json")
    for placement in payload["placements"]:
        require(set(placement) == {"requirement_uid", "section", "role"} and placement["section"] in structure["required_sections"] and
                placement["role"] in ("main", "cross", "deferred"), "MODEL_PLACEMENT_INVALID")
    for number, note in payload["section_notes"].items():
        require(number in structure["required_sections"] and set(note) <= {"status", "reason", "object_refs", "material_element_refs", "paragraphs", "tables"}, "MODEL_SECTION_NOTE_INVALID")
    require(isinstance(payload["new_issues"], list), "MODEL_DISCOVERIES_INVALID")
    from .model_preflight import check_submission, update_index
    index, pending = check_submission(attempt, manifest, records, base, payload)
    if payload["new_issues"]:
        if info.get("skill_test") is True:
            from .skill_test import record_discoveries
            record_discoveries(attempt, payload)
        else:
            save(attempt / "model-work/return-to-review.json", {"task_uid": task_uid, "new_issues": payload["new_issues"], "at": now(),
                                                               "next": "New source issue requires a new closed review and version-bound user confirmation."})
    path = attempt / "model-work/checkpoints" / filename(task_uid)
    if path.exists():
        old = load(path)
        if old["payload"] == payload:
            update_index(attempt, manifest, records, index)
            return {"saved": True, "unchanged": True, "task_uid": task_uid,
                    "pending_cross_fragment_checks": pending[:5], "progress": progress(attempt, info, manifest, records, base)}
        save(attempt / "model-work/history" / (filename(task_uid) + "." + fingerprint(old)[:16]), old)
    row = {"payload": payload, "payload_sha256": fingerprint(payload), "saved_at": now()}
    save(path, row)
    records[task_uid] = row
    records = {k: v for k, v in records.items() if not is_metadata(k) or v["payload"]["basis_sha256"] == task_basis(manifest, k, records)}
    update_index(attempt, manifest, records, {k: v for k, v in index.items() if k in records})
    return {"saved": True, "task_uid": task_uid, "pending_cross_fragment_checks": pending[:5],
            "progress": progress(attempt, info, manifest, records, base)}


def merge_collection(target, rows, pointer):
    require(isinstance(target, list) and isinstance(rows, list), "MODEL_COLLECTION_EXPECTED")
    identities = {v["uid"]: v for v in target if isinstance(v, dict) and "uid" in v}
    for value in rows:
        if isinstance(value, dict) and "uid" in value:
            require(value["uid"] not in identities or identities[value["uid"]] == value, "MODEL_UID_CONFLICT: " + pointer + "/" + value["uid"])
            if value["uid"] not in identities:
                target.append(copy.deepcopy(value))
                identities[value["uid"]] = value
        elif value not in target:
            target.append(copy.deepcopy(value))


def assign_numbers(base):
    """Number once after merging; unknown source prefixes remain unknown."""
    import re
    fact = base["basic_info"]["numbering_prefix"]
    if fact["status"] != "present" or not isinstance(fact["value"], str) or not fact["value"].strip():
        return
    categories = {"function": "FREQ", "interface": "IREQ", "performance": "PREQ", "safety": "SREQ", "reliability": "RREQ"}
    counters = {}
    for req in base["requirements"]:
        if req["normalized_id"]:
            match = re.fullmatch(re.escape(fact["value"]) + r"-(FREQ|IREQ|PREQ|SREQ|RREQ|OREQ)-([1-9][0-9]*)(?:-[KNMR]+)?", req["normalized_id"])
            if match:
                counters[match.group(1)] = max(counters.get(match.group(1), 0), int(match.group(2)))
    for req in base["requirements"]:
        if req["normalized_id"] is not None:
            continue
        category = categories.get(req["category"], "OREQ")
        counters[category] = counters.get(category, 0) + 1
        active = next((r for r in req["revisions"] if r["uid"] == req["effective_revision_uid"]), None)
        attributes = "".join(c for c in "KNMR" if active and c in active["semantic"]["attributes"])
        req["normalized_id"] = "{0}-{1}-{2}{3}".format(fact["value"], category, counters[category], "-" + attributes if attributes else "")


def merged(attempt, manifest, records, complete=True):
    base = load(Path(attempt) / "model.template.json")
    order = tasks(manifest)
    if complete:
        require(all(t in records for t in order), "MODEL_FRAGMENTS_INCOMPLETE")
    test_mode = load(Path(attempt) / "attempt.json").get("skill_test") is True
    require(test_mode or not any(r["payload"]["new_issues"] for r in records.values()), "MODEL_DISCOVERED_ISSUES: resolve issues and obtain user confirmation for the revised review")
    inventories, placements, notes = {}, [], {}
    for task_uid in order:
        if task_uid not in records:
            continue
        payload = records[task_uid]["payload"]
        for pointer, values in payload["collections"].items():
            merge_collection(get(base, pointer), values, pointer)
        for pointer, value in payload["fields"].items():
            put(base, pointer, copy.deepcopy(value))
        for row in payload["inventory"]:
            inventories.setdefault(row["element_uid"], []).append(row)
        placements += payload["placements"]
        for number, note in payload["section_notes"].items():
            for key, value in note.items():
                existing = notes.setdefault(number, {})
                if key in ("object_refs", "material_element_refs", "paragraphs", "tables"):
                    merge_collection(existing.setdefault(key, []), value, "section/" + number + "/" + key)
                else:
                    require(key not in existing or existing[key] == value, "MODEL_SECTION_FACT_CONFLICT: " + number)
                    existing[key] = value
    if complete:
        require(set(inventories) == {r["element_uid"] for r in base["completeness"]["content_inventory"]}, "MODEL_SOURCE_ELEMENTS_OMITTED")
    for row in base["completeness"]["content_inventory"]:
        values = inventories.get(row["element_uid"], [])
        if not values:
            continue
        require(not complete or all(v["disposition"] != "pending" for v in values), "MODEL_INVENTORY_STILL_PENDING")
        normative = True if any(v["normative"] is True for v in values) else None if any(v["normative"] is None for v in values) else False
        refs = []
        for value in values:
            merge_collection(refs, value["object_refs"], "inventory")
        dispositions = {v["disposition"] for v in values}
        disposition = "modeled" if "modeled" in dispositions else next(iter(dispositions)) if len(dispositions) == 1 else "pending"
        require(not complete or disposition != "pending", "MODEL_INVENTORY_DISPOSITION_CONFLICT")
        row.update(normative=normative, disposition=disposition, object_refs=refs, reason="；".join(dict.fromkeys(v["reason"] for v in values)))
    structure = load(SKILL / "templates/document_structure.json")
    plan = {"uid": "documentview:writer", "role": "writer_plan", "template_artifact_uid": None, "document_artifact_uid": None, "sections": []}
    sections = {}
    for number in structure["required_sections"]:
        policy = "deferred" if number == "7" or number.startswith("7.") else "manual" if number in ("10", "11", "C", "D") else "auto"
        section = {"uid": "sectionview:s" + number, "number": number, "title": structure["titles"][number], "status": "unknown", "handling": policy,
                   "reason": "章节素材状态待按来源核实，不代表已形成工程结论", "primary_requirement_refs": [], "cross_requirement_refs": [], "spec_item_refs": [],
                   "object_refs": [], "material_element_refs": [], "paragraphs": [],
                   "tables": [{"uid": "tableview:" + t["id"], "caption": t["caption"], "columns": t["columns"], "row_object_refs": [], "evidence_refs": []} for t in structure["tables"] if t["section"] == number]}
        note = notes.get(number, {})
        for key, value in note.items():
            if isinstance(value, list):
                merge_collection(section[key], value, "section/" + number + "/" + key)
            else:
                section[key] = value
        sections[number] = section
        plan["sections"].append(section)
    for placement in placements:
        section = sections[placement["section"]]
        require(placement["role"] != "deferred" or section["handling"] in ("deferred", "manual"), "MODEL_DEFERRED_PLACEMENT_INVALID")
        key = "primary_requirement_refs" if placement["role"] == "main" else "cross_requirement_refs"
        if placement["requirement_uid"] not in section[key]:
            section[key].append(placement["requirement_uid"])
    base["document_views"] = [plan]
    # Reuse the confirmed review judgments; convert element references to model evidence IDs.
    closed = load(Path(attempt) / "closed_review/review_state.json")["record"]
    evidence = {e["element_uid"]: e["uid"] for e in base["consistency"]["evidence"]}
    rules = []
    for check in closed["checks"]:
        require(set(check["evidence_refs"]) <= set(evidence), "MODEL_REVIEW_EVIDENCE_UNMAPPED")
        rules.append(dict(check, evidence_refs=[evidence[r] for r in check["evidence_refs"]], issue_refs=[]))
    for extension in base["extensions"]:
        if extension["namespace"] == "feip.assessments.v1":
            extension["payload"]["rules"] = rules
    if complete:
        assign_numbers(base)
        if test_mode:
            from .skill_test import project_model
            project_model(base, attempt)
    return base


def read_model(attempt, pointer, offset=0, limit=4000):
    attempt, info, manifest = workspace(attempt)
    require(pointer and pointer != "/" and offset >= 0 and 1 <= limit <= 12000, "MODEL_READ_RANGE_INVALID")
    if pointer == "/source-index":
        value = [{"task_uid": "model:" + c["uid"].split(":")[1], "section": c["section"],
                  "packet": "model-work/packets/" + filename("model:" + c["uid"].split(":")[1])} for c in manifest["source"]["chunks"]]
    elif pointer.startswith("/source-unit/"):
        unit_uid = pointer[len("/source-unit/"):]
        value = next((u for u in manifest["source"]["units"] if u["uid"] == unit_uid), None)
        require(value is not None, "UNKNOWN_MODEL_SOURCE_UNIT")
    else:
        base = merged(attempt, manifest, saved(attempt, manifest), complete=False)
        value = get(base, pointer)
    content = json.dumps(value, ensure_ascii=False, indent=2)
    target = attempt / "model-work/read.json.txt"
    text(target, content[offset:offset + limit])
    return {"path": str(target), "total_chars": len(content), "next_offset": offset + limit if offset + limit < len(content) else None}


def assemble(attempt):
    attempt, info, manifest = workspace(attempt)
    test_mode = info.get("skill_test") is True
    require(test_mode or not (attempt / "model-work/return-to-review.json").exists(), "MODEL_DISCOVERED_ISSUES: resolve issues and obtain user confirmation for the revised review")
    records = saved(attempt, manifest)
    from .model_preflight import run, require_valid
    require_valid(run(attempt, manifest, records))
    base = merged(attempt, manifest, records)
    from .checks import ensure_frozen, source_quality, revision_checks
    ensure_frozen(base, attempt, info)
    revision_checks(base)
    effective(base)
    source_quality(base, skill_test=test_mode)
    check_model(base, known_artifacts(attempt))
    require(base["source_baseline"]["status"] == "PASS" and (test_mode or not base["completeness"]["gaps"]), "MODEL_NOT_READY_FOR_PUBLICATION")
    target = attempt / "model-work/assembled-model.json"
    save(target, base)
    return target
