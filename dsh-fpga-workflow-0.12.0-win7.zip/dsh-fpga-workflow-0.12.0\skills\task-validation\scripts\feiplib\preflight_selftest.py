"""Synthetic checks for early failures, forward references, cached gating and draft reuse."""
import copy
from pathlib import Path

from . import model_batches as batches
from . import model_preflight as checks
from .base import Failure, digest, load, now, save, text
from .batch_selftest import fill_model_fragment
from .review_selftest import confirmed_prepare


def preflight_tests(root):
    from .selftest import agent_source
    root.mkdir()
    results = []

    def rejects(name, function, expected):
        try:
            function()
        except (ValueError, KeyError, OSError) as exc:
            assert expected in str(exc), (name, str(exc))
            results.append(name)
        else:
            raise AssertionError("negative case accepted: " + name)

    source = root / "source.txt"
    text(source, "UR-1 有效命令响应时间不大于10 ms。\nTP-A-001 测量响应时间，<=10ms通过。\n" +
         "\n".join("说明素材%d：虚构预检样本。" % i for i in range(14)))
    prep = confirmed_prepare(root / "normal", source)
    attempt = Path(prep["attempt"])
    manifest = batches.ModelManifest(load(attempt / "model-work/manifest.json"))
    full = agent_source(attempt)
    local_tasks = [t for t in batches.tasks(manifest) if not batches.is_metadata(t)]
    fragment = root / "fragment.json"

    def draft(task, first=False):
        save(fragment, batches.task_template(attempt, manifest, task, {}, full))
        save(fragment, fill_model_fragment(attempt, {"template": str(fragment)}, full, first))
        return load(fragment)

    payloads = [draft(task, index == 0) for index, task in enumerate(local_tasks)]

    def submit(payload):
        save(fragment, payload)
        return batches.submit(attempt, fragment)

    original = copy.deepcopy(payloads[0])
    bad = copy.deepcopy(original)
    bad["collections"]["/source_baseline/atomic_requirements"][0]["semantic"]["evidence_refs"] = []
    bad["collections"]["/requirements"][0]["revisions"][0]["semantic"]["evidence_refs"] = []
    rejects("empty-atom-evidence-is-rejected-before-checkpoint-save", lambda: submit(bad), "SOURCE_ATOM_EVIDENCE_MISSING")
    assert not (attempt / "model-work/checkpoints" / batches.filename(local_tasks[0])).exists()
    details = load(attempt / "model-work/diagnostics/submit-errors.json")
    assert len(details["errors"]) == 2 and all(e["path"] for e in details["errors"])
    results.append("submit-diagnostics-aggregate-all-empty-evidence-errors-with-field-locations")
    bad = copy.deepcopy(original)
    bad["collections"]["/source_baseline/atomic_requirements"][0]["semantic"]["evidence_refs"] = ["evidence:unknown"]
    rejects("unknown-evidence-uid-is-rejected-at-submission", lambda: submit(bad), "MODEL_EVIDENCE_REFERENCE_INVALID")
    bad = copy.deepcopy(original)
    bad["collections"]["/requirements"][0]["revisions"][0]["semantic"]["statement"] = "虚构不一致的源语义"
    rejects("same-fragment-source-revision-mismatch-is-rejected-early", lambda: submit(bad), "MODEL_SOURCE_SEMANTIC_MISMATCH")
    bad = copy.deepcopy(original)
    parent = copy.deepcopy(bad["collections"]["/source_baseline/parents"][0])
    parent.update(source_id="UR-2", title="同UID错误的第二条款")
    bad["collections"]["/source_baseline/parents"].append(parent)
    rejects("same-fragment-parent-uid-collision-is-rejected-early", lambda: submit(bad), "MODEL_UID_CONFLICT")
    submit(original)
    unchanged = submit(original)
    assert unchanged["unchanged"] and unchanged["progress"]["fragments_done"] == 1
    results.append("identical-resubmission-returns-progress-without-invalidating-checkpoints")
    bad = copy.deepcopy(payloads[1])
    bad["inventory"][0].update(normative=True, disposition="descriptive_only")
    rejects("normative-inventory-cannot-be-downgraded-to-description", lambda: submit(bad), "MODEL_NORMATIVE_DISPOSITION_INVALID")
    second = copy.deepcopy(payloads[1])
    parent = copy.deepcopy(original["collections"]["/source_baseline/parents"][0])
    parent["raw_text"] = "虚构跨片冲突原文"
    second["collections"] = {"/source_baseline/parents": [parent]}
    rejects("cross-fragment-parent-collision-names-both-tasks-and-differing-fields", lambda: submit(second), "MODEL_UID_CONFLICT")
    details = load(attempt / "model-work/diagnostics/submit-errors.json")["errors"][0]
    assert details["other_task_uid"] == local_tasks[0] and "/raw_text" in details["differing_fields"]
    second["collections"]["/source_baseline/parents"][0] = copy.deepcopy(original["collections"]["/source_baseline/parents"][0])
    second["collections"]["/source_baseline/parents"][0]["uid"] = "parent:duplicate-source"
    rejects("duplicate-full-source-id-with-different-uid-is-rejected-early", lambda: submit(second), "MODEL_SOURCE_ID_CONFLICT")
    # An identical shared parent is legal and deduplicated, including on a rebuilt index.
    second["collections"]["/source_baseline/parents"][0] = copy.deepcopy(original["collections"]["/source_baseline/parents"][0])
    text(attempt / "model-work/preflight-index.json", "corrupt cache")
    submit(second)
    results.append("corrupt-index-is-rebuilt-and-identical-parent-reuse-remains-valid")
    for payload in payloads[2:]:
        submit(payload)
    assert batches.status(attempt)["state"] == "LOCAL_PREFLIGHT_REQUIRED"
    assert not (attempt / "model-work/preflight-cache.json").exists()
    results.append("local-submit-and-status-do-not-repeatedly-launch-full-preflight")
    result = checks.run(attempt)
    assert result["valid"], result["errors"]
    repeated = checks.run(attempt)
    assert repeated["cache_hit"] and repeated["valid"]
    results.append("local-preflight-passes-and-reuses-cache-without-regenerating-fragments")
    from .workflow import run
    cli_result = run(["model-preflight", "--attempt", str(attempt)])
    assert cli_result["valid"] and "errors" not in cli_result and Path(cli_result["report_md"]).is_file()
    results.append("model-preflight-cli-returns-compact-summary-and-full-diagnostic-paths")
    # Metadata writes do not invalidate the local cache or each other.
    while not batches.status(attempt)["complete"]:
        task = batches.next_task(attempt)
        submit(fill_model_fragment(attempt, task, full))
    before = batches.status(attempt)
    assert before["preflight"]["cache_hit"]
    first_meta = "model:meta-meta"
    original_meta = copy.deepcopy(batches.saved(attempt, manifest)[first_meta]["payload"])
    changed = copy.deepcopy(original)
    changed["section_notes"] = {"5.4": {"status": "present", "reason": "虚构更新素材定位"}}
    old_key = load(attempt / "model-work/preflight-cache.json")["key"]
    submit(changed)
    assert load(attempt / "model-work/preflight-cache.json")["key"] == old_key
    assert batches.status(attempt)["state"] == "LOCAL_PREFLIGHT_REQUIRED"
    assert checks.run(attempt)["valid"] and load(attempt / "model-work/preflight-cache.json")["key"] != old_key
    assert batches.status(attempt)["fragments_done"] == len(local_tasks)
    stale = batches.next_task(attempt, first_meta)
    reused = load(stale["template"])
    assert stale["recheck_required"] and not stale["already_done"]
    assert reused["fields"] == original_meta["fields"] and reused["basis_sha256"] != original_meta["basis_sha256"]
    results.append("local-correction-keeps-metadata-as-unsubmitted-drafts-instead-of-erasing-fields")
    rejects("old-metadata-basis-is-still-rejected", lambda: submit(original_meta), "MODEL_FRAGMENT_BINDING_INVALID")
    submit(reused)
    assert batches.saved(attempt, manifest)[first_meta]["payload"]["fields"] == original_meta["fields"]
    results.append("rechecked-metadata-draft-can-be-submitted-with-refreshed-binding")
    invalid_meta = load(batches.next_task(attempt, "model:meta-basic_info")["template"])
    bad_fact = copy.deepcopy(invalid_meta)
    bad_fact["fields"]["/basic_info/product_name"].update(status="present", value=None, reason=None)
    rejects("inconsistent-metadata-fact-is-rejected-before-final-assembly", lambda: submit(bad_fact), "MODEL_FACT_INVALID")
    invalid_meta["collections"] = {"/source_baseline/parents": [parent]}
    rejects("metadata-cannot-add-unchecked-local-source-objects", lambda: submit(invalid_meta), "MODEL_METADATA_FIELDS_ONLY")

    # Simulate checkpoints accepted by the previous runtime, not by the new submitter.
    legacy = confirmed_prepare(root / "legacy", source)
    la = Path(legacy["attempt"])
    lm = batches.ModelManifest(load(la / "model-work/manifest.json"))
    lf = agent_source(la)
    lt = [t for t in batches.tasks(lm) if not batches.is_metadata(t)]
    for index, task in enumerate(lt):
        save(fragment, batches.task_template(la, lm, task, {}, lf))
        payload = fill_model_fragment(la, {"template": str(fragment)}, lf, index == 0)
        save(fragment, payload)
        payload = load(fragment)
        if index == 0:
            payload["collections"]["/source_baseline/atomic_requirements"][0]["semantic"]["evidence_refs"] = []
            payload["collections"]["/requirements"][0]["source_parent_refs"] = ["parent:missing"]
            payload["collections"]["/requirements"][0]["revisions"][0]["semantic"]["statement"] = "虚构源修订不一致"
        save(la / "model-work/checkpoints" / batches.filename(task), {"payload": payload, "payload_sha256": batches.fingerprint(payload), "saved_at": now()})
    checkpoint = la / "model-work/checkpoints" / batches.filename(lt[0])
    before_hash = digest(checkpoint)
    result = checks.run(la)
    codes = {e["code"] for e in result["errors"]}
    assert not result["valid"] and {"SOURCE_ATOM_EVIDENCE_MISSING", "MODEL_SOURCE_SEMANTIC_MISMATCH", "MODEL_REFERENCE_INVALID"} <= codes
    assert digest(checkpoint) == before_hash
    results.append("legacy-checkpoint-diagnostics-aggregate-independent-errors-without-editing-inputs")
    rejects("metadata-is-blocked-before-rewriting-any-fields-when-local-preflight-fails", lambda: batches.next_task(la, first_meta), "MODEL_LOCAL_PREFLIGHT_FAILED")
    assert batches.status(la)["state"] == "LOCAL_MODEL_INVALID"
    broken_cache = load(la / "model-work/preflight-cache.json")
    broken_cache["data"]["valid"] = True
    save(la / "model-work/preflight-cache.json", broken_cache)
    assert not checks.run(la)["valid"]
    results.append("modified-preflight-cache-cannot-hide-invalid-local-models")
    broken_checkpoint = load(checkpoint)
    broken_checkpoint["payload"]["section_notes"] = {"5.4": {"reason": "unhashed edit"}}
    save(checkpoint, broken_checkpoint)
    rejects("fast-diagnostics-still-verify-every-checkpoint-checksum", lambda: checks.run(la), "MODEL_CHECKPOINT_CORRUPT")

    # Forward object refs are accepted while local tasks are unfinished. A cross-task
    # correction can be applied one side at a time, but cannot enter metadata yet.
    forward = confirmed_prepare(root / "forward", source)
    fa = Path(forward["attempt"])
    fm = batches.ModelManifest(load(fa / "model-work/manifest.json"))
    ff = agent_source(fa)
    ft = [t for t in batches.tasks(fm) if not batches.is_metadata(t)]
    drafts = []
    for index, task in enumerate(ft):
        save(fragment, batches.task_template(fa, fm, task, {}, ff))
        save(fragment, fill_model_fragment(fa, {"template": str(fragment)}, ff, index == 0))
        drafts.append(load(fragment))
    atoms = drafts[0]["collections"].pop("/source_baseline/atomic_requirements")
    drafts[1]["collections"] = {"/source_baseline/atomic_requirements": atoms}
    atoms[0]["semantic"]["statement"] = "虚构待同步的跨片修订"
    for payload in drafts:
        save(fragment, payload)
        batches.submit(fa, fragment)
    assert not checks.run(fa)["valid"]
    results.append("forward-references-do-not-block-submission-but-final-local-mismatches-block-metadata")
    drafts[1]["collections"]["/source_baseline/atomic_requirements"][0]["semantic"] = copy.deepcopy(ff["source_baseline"]["atomic_requirements"][0]["semantic"])
    save(fragment, drafts[1])
    batches.submit(fa, fragment)
    assert checks.run(fa)["valid"]
    assert batches.next_task(fa)["task_uid"] == first_meta
    results.append("targeted-cross-fragment-repair-clears-preflight-without-rebuilding-other-tasks")
    return results
