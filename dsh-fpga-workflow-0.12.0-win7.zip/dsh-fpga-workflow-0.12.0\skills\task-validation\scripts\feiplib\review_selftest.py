"""Regression cases for review/closure/authorization boundaries; synthetic data only."""
import copy
from pathlib import Path

from .base import digest, load, now, save, text
from .prepare import prepare
from .review_stage import authorize, review, verify_review


def synthetic_record(prep):
    attempt = Path(prep["attempt"])
    model = load(attempt / "review.template.json")
    info = load(attempt / "attempt.json")
    archives = [load(attempt / p) for p in info["archives"]]
    refs = [e["uid"] for a in archives for e in a["elements"]]
    model["summary"] = "虚构自测预设结论，不代表真实任务书审查或用户授权"
    model["reviewed_element_refs"] = refs
    for check in model["checks"]:
        check.update(status="pass", rationale="虚构自测预设规则判断", evidence_refs=refs[:1])
    for check in model["extraction_checks"]:
        check.update(status="complete", rationale="虚构自测纯文本完整读取")
    return model


def synthetic_confirmation(result):
    return {"kind": "approve_taskbook_structuring", "review_uid": result["review_uid"],
            "review_state_sha256": result["review_state_sha256"], "actor": "虚构测试用户",
            "confirmed_at": now(), "request_quote": "虚构测试：请生成交接包。",
            "user_quote": "虚构测试：确认本版无其他未明确项，可以开始生成。", "review_items_confirmed": True}


def confirmed_prepare(root, source):
    prep = prepare("taskbook", root / "review-input", source)
    filename = root / "review-agent.json"
    save(filename, synthetic_record(prep))
    result = review(prep["attempt"], filename, root / "closed-review")
    confirmation = root / "structure-confirmation.json"
    save(confirmation, synthetic_confirmation(result))
    return prepare("taskbook", root / "structure-input", source, closed_review=root / "closed-review", confirmation=confirmation)


def review_tests(root):
    root.mkdir()
    results = []

    def rejects(name, function):
        try:
            function()
        except (ValueError, KeyError, OSError):
            results.append(name)
        else:
            raise AssertionError("negative case accepted: " + name)

    source = root / "source.txt"
    text(source, "1 功能要求\nFPGA应响应有效命令。\n")
    from .workflow import run
    prep = run(["prepare", "--input", str(source), "--output", str(root / "input")])
    attempt = Path(prep["attempt"])
    assert not (attempt / "model.template.json").exists()
    assert (attempt / "review_source.txt").is_file()
    results.append("review-prepare-does-not-start-full-modeling")
    record = synthetic_record(prep)
    ref = record["reviewed_element_refs"][1]
    opened = copy.deepcopy(record)
    opened["issues"] = [{"uid": "issue:one", "description": "虚构待澄清项", "status": "open", "severity": "warning", "blocking": False,
                         "evidence_refs": [ref], "impact": "虚构影响", "recommendation": "虚构修订建议：三线|四线\n核对 <接口> 与 `配置`"}]
    opened["checks"][0].update(status="unknown", issue_refs=["issue:one"])
    opened_file = root / "open.json"
    save(opened_file, opened)
    pending = run(["review", "--attempt", str(attempt), "--model", str(opened_file), "--output", str(root / "open-review")])
    assert pending["state"] == "REVIEWING"
    assert not any((root / "open-review" / p).exists() for p in ("model.json", "package.json", "需求清单.md"))
    results.append("nonblocking-issue-still-prevents-structuring-without-feip-output")
    report = (root / "open-review/taskbook_review.md").read_text(encoding="utf-8")
    stored = load(root / "open-review/review_state.json")["record"]
    assert stored == opened
    assert all(value in report for value in ("issue:one", "虚构待澄清项", "虚构影响", "STR-001", "未闭环",
                                             "source.txt", "1 功能要求", "结构元素序号 2", "FPGA应响应有效命令。", ref))
    assert '"issues":' not in report and '"todos":' not in report and '"evidence_refs":' not in report
    results.append("review-report-renders-issue-details-and-source-location-without-json-dump")
    assert "三线\\|四线<br>核对 &lt;接口&gt; 与 \\`配置\\`" in report
    assert stored["issues"][0]["recommendation"] == opened["issues"][0]["recommendation"]
    results.append("review-report-escapes-markdown-and-html-without-changing-machine-record")
    assert run(["validate", "--package", str(root / "open-review")])["state"] == "REVIEWING"
    results.append("cli-validates-lightweight-review-without-feip-manifest")
    open_confirm = root / "open-confirm.json"
    save(open_confirm, synthetic_confirmation(pending))
    rejects("open-review-cannot-be-authorized", lambda: prepare("taskbook", root / "blocked", source, closed_review=root / "open-review", confirmation=open_confirm))
    rejects("review-attempt-cannot-be-reused", lambda: review(attempt, root / "open.json", root / "repeat"))

    second = prepare("taskbook", root / "round2", source, previous_state=root / "open-review/review_state.json")
    closed = synthetic_record(second)
    second_ref = closed["reviewed_element_refs"][0]
    closed["issues"][0].update(status="closed", closure_reason="虚构源内容已核实", closure_evidence_refs=[second_ref])
    dropped = copy.deepcopy(closed)
    dropped["issues"] = []
    dropped_file = root / "dropped.json"
    save(dropped_file, dropped)
    rejects("previous-issue-cannot-disappear", lambda: review(second["attempt"], dropped_file, root / "bad-dropped"))
    closed_file = root / "closed.json"
    save(closed_file, closed)
    result = review(second["attempt"], closed_file, root / "closed")
    assert result["state"] == "AWAITING_STRUCTURE_CONFIRMATION"
    verify_review(root / "closed")
    assert not (root / "closed/model.template.json").exists() and not (root / "closed/model.json").exists()
    results.append("all-issues-closed-awaits-user-confirmation-without-generating-taskbook")
    closed_report = (root / "closed/taskbook_review.md").read_text(encoding="utf-8")
    assert "已闭环" in closed_report and "虚构源内容已核实" in closed_report
    assert "- 关闭证据：" in closed_report and second_ref in closed_report
    assert "请用户确认本版有无其他未明确项，再开始生成" in closed_report
    results.append("review-report-retains-closed-issue-evidence-and-authorization-boundary")
    rejects("closed-review-without-confirmation-rejected", lambda: prepare("taskbook", root / "missing", source, closed_review=root / "closed"))
    confirmation = root / "confirm.json"
    value = synthetic_confirmation(result)
    save(confirmation, value)
    wrong = root / "wrong.json"
    save(wrong, dict(value, review_state_sha256="0" * 64))
    rejects("confirmation-bound-to-current-review", lambda: prepare("taskbook", root / "wrong-review", source, closed_review=root / "closed", confirmation=wrong))
    save(wrong, dict(value, kind="approve_release"))
    rejects("other-approval-is-not-structuring-confirmation", lambda: authorize(root / "closed", wrong, source))
    save(wrong, dict(value, confirmed_at="2000-01-01T00:00:00+08:00"))
    rejects("confirmation-before-closure-rejected", lambda: authorize(root / "closed", wrong, source))
    save(wrong, dict(value, user_quote=""))
    rejects("missing-user-confirmation-evidence-rejected", lambda: authorize(root / "closed", wrong, source))
    full = prepare("taskbook", root / "approved", source, closed_review=root / "closed", confirmation=confirmation)
    assert Path(full["template"]).name.startswith("model-") and (Path(full["attempt"]) / "model.template.json").is_file()
    from .review_stage import verify_structure_attempt
    verify_structure_attempt(full["attempt"])
    results.append("confirmed-current-closed-review-starts-modeling")
    for label, record, expected in (
        ("legacy-auto-authorization", dict(value, kind="auto_taskbook_structuring", basis="闭环"), "STRUCTURE_CONFIRMATION_REQUIRED"),
        ("request-without-followup", dict(value, user_quote=""), "STRUCTURE_CONFIRMATION_EVIDENCE_REQUIRED"),
        ("request-reused-as-confirmation", dict(value, user_quote=value["request_quote"]), "STRUCTURE_SEPARATE_USER_CONFIRMATION_REQUIRED"),
        ("confirmation-without-initial-request", dict(value, request_quote=""), "STRUCTURE_CONFIRMATION_EVIDENCE_REQUIRED"),
        ("unconfirmed-review-items", dict(value, review_items_confirmed=False), "STRUCTURE_REVIEW_ITEMS_CONFIRMATION_REQUIRED"),
    ):
        save(wrong, record)
        rejected_output = root / label
        def start_rejected():
            try:
                prepare("taskbook", rejected_output, source, closed_review=root / "closed", confirmation=wrong)
            except ValueError as exc:
                assert expected in str(exc), str(exc)
                raise
        rejects(label + "-cannot-start-modeling", start_rejected)
        assert not rejected_output.exists()
    rejects("structuring-cannot-recursively-copy-its-review", lambda: prepare("taskbook", root / "closed/nested", source, closed_review=root / "closed", confirmation=confirmation))
    rejects("old-review-command-cannot-publish-full-model", lambda: review(full["attempt"], full["template"], root / "wrong-route"))
    original = source.read_bytes()
    text(source, "源输入变化")
    rejects("source-change-invalidates-approval", lambda: authorize(root / "closed", confirmation, source))
    rejects("source-change-also-blocks-final-structure-attempt", lambda: verify_structure_attempt(full["attempt"]))
    source.write_bytes(original)
    state_path = root / "closed/review_state.json"
    original_state = state_path.read_bytes()
    modified = load(state_path)
    modified["record"]["summary"] = "tampered"
    save(state_path, modified)
    rejects("review-record-edit-invalidates-approval", lambda: authorize(root / "closed", confirmation, source))
    state_path.write_bytes(original_state)
    todo_prep = prepare("taskbook", root / "todo-input", source)
    todo_record = synthetic_record(todo_prep)
    todo_record["issues"] = copy.deepcopy(closed["issues"])
    todo_record["todos"] = [{"uid": "todo:one", "issue_uid": "issue:one", "description": "虚构未完成待办", "status": "open", "evidence_refs": [ref]}]
    save(root / "todo.json", todo_record)
    todo_result = review(todo_prep["attempt"], root / "todo.json", root / "todo-review")
    assert todo_result["state"] == "REVIEWING"
    results.append("open-todo-blocks-even-with-all-issues-closed")
    todo_report = (root / "todo-review/taskbook_review.md").read_text(encoding="utf-8")
    assert "todo:one" in todo_report and "虚构未完成待办" in todo_report and "- 关联问题：issue:one" in todo_report
    assert '"todos":' not in todo_report
    results.append("review-report-renders-open-todo-and-related-issue")
    from .review_report import render as render_review
    closed_todo_record = copy.deepcopy(todo_record)
    closed_todo_record["todos"][0].update(status="closed", closure_reason="虚构待办已完成", closure_evidence_refs=[ref])
    closed_todo_report = render_review(closed_todo_record, "AWAITING_STRUCTURE_CONFIRMATION",
                                       load(Path(todo_prep["attempt"]) / "attempt.json"), todo_prep["attempt"])
    assert "虚构待办已完成" in closed_todo_report and "- 关闭证据：" in closed_todo_report
    assert closed_todo_report.count("- 关闭证据：") == 2
    results.append("review-report-retains-closed-todo-reason-and-evidence")
    empty_prep = prepare("taskbook", root / "empty-input", source)
    empty_record = synthetic_record(empty_prep)
    save(root / "empty.json", empty_record)
    empty_result = review(empty_prep["attempt"], root / "empty.json", root / "empty-review")
    empty_report = (root / "empty-review/taskbook_review.md").read_text(encoding="utf-8")
    assert "本轮未登记问题。" in empty_report and "本轮无待办事项。" in empty_report
    assert '"issues": []' not in empty_report and '"todos": []' not in empty_report
    assert empty_result["state"] == "AWAITING_STRUCTURE_CONFIRMATION"
    verify_review(root / "empty-review")
    results.append("review-report-renders-empty-lists-without-bypassing-confirmation")
    partial_prep = prepare("taskbook", root / "partial-input", source)
    partial_record = synthetic_record(partial_prep)
    partial_record["reviewed_element_refs"] = []
    save(root / "partial.json", partial_record)
    rejects("unreviewed-source-elements-rejected", lambda: review(partial_prep["attempt"], root / "partial.json", root / "partial-output"))
    binary = root / "diagram.bin"
    binary.write_bytes(b"synthetic diagram")
    transcript = root / "transcript.txt"
    text(transcript, "虚构原图核实转录：FPGA应响应有效命令。")
    manifest = root / "attachments.json"
    save(manifest, [{"path": str(binary)}, {"path": str(transcript)}])
    transcript_prep = prepare("taskbook", root / "transcript-input", source, attachments=manifest)
    transcript_record = synthetic_record(transcript_prep)
    transcript_info = load(Path(transcript_prep["attempt"]) / "attempt.json")
    transcript_archive = load(Path(transcript_prep["attempt"]) / transcript_info["archives"][2])
    transcript_record["extraction_checks"][1].update(status="unresolved", rationale="虚构未核实图")
    transcript_record["issues"] = copy.deepcopy(opened["issues"])
    save(root / "unread.json", transcript_record)
    unresolved = review(transcript_prep["attempt"], root / "unread.json", root / "unread-review")
    assert unresolved["state"] == "REVIEWING"
    results.append("unread-attachment-prevents-closure")
    wrong_role = copy.deepcopy(transcript_record)
    evidence_ref = transcript_archive["elements"][0]["uid"]
    wrong_role["extraction_checks"][1].update(status="verified_transcription", evidence_refs=[evidence_ref],
                                             transcription_map=[{"target_ref": wrong_role["extraction_checks"][1]["archive_uid"],
                                                                 "evidence_refs": [evidence_ref]}])
    from .review_stage import check_record
    rejects("ordinary-attachment-cannot-stand-in-for-transcription", lambda: check_record(
        wrong_role, transcript_info, Path(transcript_prep["attempt"])))
    save(manifest, [{"path": str(binary)}, {"path": str(transcript), "role": "transcription"}])
    transcript_prep2 = prepare("taskbook", root / "transcript-input2", source, attachments=manifest, previous_state=root / "unread-review/review_state.json")
    transcript_record2 = synthetic_record(transcript_prep2)
    transcript_record2["issues"][0].update(status="closed", closure_reason="虚构转录已核实", closure_evidence_refs=[transcript_archive["elements"][0]["uid"]])
    transcript_record2["extraction_checks"][1].update(status="verified_transcription", rationale="虚构原图与转录核验对应", evidence_refs=[transcript_archive["elements"][0]["uid"]])
    save(root / "transcribed.json", transcript_record2)
    rejects("transcription-cannot-clear-limitations-without-target-mapping", lambda: review(
        transcript_prep2["attempt"], root / "transcribed.json", root / "missing-transcript-map"))
    transcript_record2["extraction_checks"][1]["transcription_map"] = [
        {"target_ref": transcript_record2["extraction_checks"][1]["archive_uid"], "evidence_refs": [evidence_ref]}]
    save(root / "transcribed.json", transcript_record2)
    transcribed = review(transcript_prep2["attempt"], root / "transcribed.json", root / "transcribed-review")
    save(root / "transcribed-confirm.json", synthetic_confirmation(transcribed))
    full_transcript = prepare("taskbook", root / "transcribed-structure", source, attachments=manifest, closed_review=root / "transcribed-review", confirmation=root / "transcribed-confirm.json")
    from .selftest import agent_source
    from .workflow import structure
    save(root / "transcribed-model.json", agent_source(full_transcript["attempt"]))
    structure(full_transcript["attempt"], root / "transcribed-model.json", root / "transcribed-package")
    results.append("verified-transcript-closure-can-produce-confirmed-feip-package")
    return results
