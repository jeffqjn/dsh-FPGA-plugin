"""Compact review submissions, explicit revisions and immutable recovery forks."""
import copy
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path
from .base import SKILL, VERSION, digest, load, now, require, save, verify_inputs


def expand(payload, template):
    if payload.get("contract") != "taskbook-review-delta/1.0":
        return payload
    allowed = {"contract", "run_uid", "task_uid", "basis_sha256", "reviewed", "changes"}
    require(set(payload) == allowed, "REVIEW_DELTA_FIELDS_INVALID")
    for key in ("run_uid", "task_uid", "basis_sha256"):
        require(payload[key] == template[key], "REVIEW_DELTA_STALE_OR_WRONG_TASK: field=" + key)
    require(payload["reviewed"] is True, "REVIEW_DELTA_REQUIRES_EXPLICIT_REVIEW_ASSERTION")
    changes = payload["changes"]
    permitted = set(template) - {"contract", "run_uid", "task_uid", "basis_sha256", "reviewed_unit_refs", "inspected_rule_ids"}
    require(isinstance(changes, dict) and set(changes) <= permitted and "summary" in changes, "REVIEW_DELTA_CHANGES_INVALID")
    if "checks" in template:
        require("checks" in changes, "REVIEW_DELTA_GLOBAL_JUDGMENTS_REQUIRED")
    if "extraction_checks" in template:
        require("extraction_checks" in changes, "REVIEW_DELTA_EXTRACTION_JUDGMENTS_REQUIRED")
    result = copy.deepcopy(template)
    result.update(changes)
    return result


def reconcile(old, current, task=""):
    """Descriptions can change explicitly; identity and original wording survive."""
    require(old["uid"] == current["uid"], "REVIEW_ITEM_IDENTITY_CHANGED")
    if old["description"] == current["description"]:
        require(current.get("description_rev", 1) >= old.get("description_rev", 1), "DESCRIPTION_REV_WENT_BACKWARDS: " + old["uid"])
        return
    old_rev = old.get("description_rev", 1)
    revision = current.get("description_rev")
    history = current.get("description_history", [])
    recorded = any(h.get("description_rev") == old_rev and h.get("description") == old["description"] for h in history)
    require(type(revision) is int and revision > old_rev, "DESCRIPTION_REV_REQUIRED: task=" + task + " item=" + old["uid"] + " expected_revision>" + str(old_rev))
    if not recorded:
        require(revision == old_rev + 1, "DESCRIPTION_REV_GAP: " + old["uid"])
        current["description_history"] = copy.deepcopy(old.get("description_history", [])) + [{
            "description_rev": old_rev, "description": old["description"], "evidence_refs": copy.deepcopy(old.get("evidence_refs", [])), "revised_at": now()}]


def evidence_preview(payload, manifest):
    elements = {}
    units = {u["uid"]: u for u in manifest["units"]}
    for unit in manifest["units"]:
        elements.setdefault(unit["element_uid"], unit)
    output = []
    for key in ("issues", "todos"):
        for item in payload[key]:
            locations = item.get("evidence_locations", [])
            require(isinstance(locations, list), "REVIEW_LOCATION_LIST_INVALID: " + item["uid"])
            for loc in locations:
                require(isinstance(loc, dict) and set(loc) <= {"unit_uid", "row", "column", "label"} and loc.get("unit_uid") in units,
                        "REVIEW_LOCATION_UNIT_INVALID: " + item["uid"])
                unit = units[loc["unit_uid"]]
                require(unit["element_uid"] in item["evidence_refs"], "REVIEW_LOCATION_EVIDENCE_MISMATCH: " + item["uid"])
                require("row" not in loc or loc["row"] == unit["row"], "REVIEW_LOCATION_ROW_MISMATCH: " + item["uid"])
                if payload["task_uid"].startswith("chunk:"):
                    require(unit["uid"] in payload["scope_unit_refs"], "REVIEW_LOCATION_OUTSIDE_READ_SCOPE: " + item["uid"])
            for ref in item["evidence_refs"]:
                selected = [units[l["unit_uid"]] for l in locations if units[l["unit_uid"]]["element_uid"] == ref] or [elements.get(ref)]
                for unit in selected:
                    if unit:
                        output.append({"item_uid": item["uid"], "element_uid": ref, "unit_uid": unit["uid"], "kind": unit["kind"],
                                       "row": unit["row"], "section": unit["section"], "text": unit["text"][:80]})
    return output


def reopen(attempt, output):
    """Fork a published review; never mutate the previously delivered snapshot."""
    from .review_stage import verify_review
    source = Path(attempt).resolve()
    result = verify_review(source)
    target = Path(output).resolve()
    require(not target.exists() and source != target and source not in target.parents and target not in source.parents,
            "REVIEW_RECOVERY_REQUIRES_NEW_SEPARATE_DIRECTORY")
    require((source / "review-work/manifest.json").is_file(), "REVIEW_RECOVERY_REQUIRES_BATCH_CHECKPOINTS")
    shutil.copytree(str(source), str(target), ignore=shutil.ignore_patterns("__pycache__"))
    for relative in ("inputs/agent_review.json", "review-work/assembled-review.json", "review_state.json", "taskbook_review.md"):
        path = target / relative
        if path.is_file():
            path.unlink()
    info = load(target / "attempt.json")
    info["revision_parent"] = {"review_uid": result["review_uid"], "review_state_sha256": digest(source / "review_state.json"), "path": str(source)}
    save(target / "attempt.json", info)
    verify_inputs(target)
    return {"attempt": str(target), "preserved_review": str(source), "next": "review-next --attempt <new directory> --task <task uid>; repair only affected tasks"}


def doctor(output=None):
    import platform
    directory = Path(output or Path.cwd()).resolve()
    require(directory.is_dir(), "DOCTOR_OUTPUT_DIRECTORY_NOT_FOUND: " + str(directory))
    try:
        with tempfile.NamedTemporaryFile(prefix=".feip-write-probe-", dir=str(directory)) as stream:
            stream.write(b"FEIP write probe")
            stream.flush()
    except OSError as exc:
        raise ValueError("DOCTOR_OUTPUT_NOT_WRITABLE: " + str(directory) + " " + str(exc))
    configured = os.environ.get("FPGA_PYTHON38")
    require(not configured or Path(configured).resolve() == Path(sys.executable).resolve(), "DOCTOR_INTERPRETER_ENV_MISMATCH")
    return {"python": platform.python_version(), "version": VERSION, "executable": sys.executable,
            "skill_root": str(SKILL), "cli": str(SKILL / "scripts/cli.py"), "output": str(directory), "write_test": "passed",
            "target": "Windows 7 SP1 / PowerShell 2.0 / Python 3.8.10", "dependencies": "standard-library-only"}


def route_previous(manifest):
    chunks = {c["uid"]: c for c in manifest["chunks"]}
    units = {u["uid"]: u for u in manifest["units"]}
    for identity, old in manifest.get("prior_locations", {}).items():
        owner = manifest["prior_owners"].get(identity, "")
        if owner.startswith("global:") or owner in chunks:
            continue
        scores = {}
        for task, chunk in chunks.items():
            group = [units[r] for r in chunk["unit_refs"]]
            exact = sum(u["identity"] in old["identities"] for u in group)
            same_section = sum(u["section"] in old["sections"] and bool(u["section"]) for u in group)
            scores[task] = exact * 10000 + same_section
        if scores:
            best = max(scores.values())
            candidates = [k for k, v in scores.items() if v == best and v > 0]
            if len(candidates) == 1:
                manifest["prior_owners"][identity] = candidates[0]
    # Ambiguous/no-source matches remain explicitly owned by global:quality.


def compact_transcriptions(manifest, info):
    from .batches import fingerprint
    for slot, role in info.get("attachment_roles", {}).items():
        if role != "transcription":
            continue
        groups = [c for c in manifest["chunks"] if c["archive_slot"] == int(slot)]
        if len(groups) < 2 or sum(c["chars"] for c in groups) > 20000:
            continue
        refs = [r for c in groups for r in c["unit_refs"]]
        merged = {"uid": "chunk:" + fingerprint(refs)[:24], "unit_refs": refs, "section": groups[0]["section"],
                  "archive_slot": int(slot), "chars": sum(c["chars"] for c in groups),
                  "reusable": all(c["reusable"] for c in groups), "transcription_evidence_task": True}
        offset = manifest["chunks"].index(groups[0])
        manifest["chunks"] = [c for c in manifest["chunks"] if c not in groups]
        manifest["chunks"].insert(offset, merged)
    # Evidence is still read and checked once; role never authorizes discarding
    # a technical obligation present in an illustration/transcription.


def reuse_globals(attempt, info, manifest, previous_root, old_manifest, mapping):
    if not info.get("incremental_global") or previous_root is None or old_manifest is None:
        return []
    from .batches import all_checkpoints, checkpoints, filename, fingerprint, global_basis, remap
    prior_info = load(previous_root / "attempt.json")
    if prior_info["policy_binding"] != info["policy_binding"]:
        return []
    if sorted(b["sha256"] for b in prior_info["source_bindings"]) != sorted(b["sha256"] for b in info["source_bindings"]):
        return []
    if [u["identity"] for u in manifest["units"]] != [u["identity"] for u in old_manifest["units"]]:
        return []
    local = checkpoints(attempt, manifest)
    if len(local) != len(manifest["chunks"]) or not all(r.get("reused_from") for r in local.values()):
        return []
    old = all_checkpoints(previous_root, old_manifest)
    result = []
    for task, record in old.items():
        if not task.startswith("global:"):
            continue
        payload = remap(record["payload"], mapping)
        payload.update(run_uid=info["run_uid"], basis_sha256=global_basis(manifest, local))
        save(Path(attempt) / "review-work/checkpoints" / filename(task), {
            "payload": payload, "basis": payload["basis_sha256"], "payload_sha256": fingerprint(payload),
            "saved_at": now(), "reused_from": record["saved_at"], "reuse_scope": "all-source-and-all-local-dependencies-unchanged"})
        result.append(task)
    return result


def location_lines(item, root):
    from .review_report import markdown
    manifest = load(Path(root) / "review-work/manifest.json")
    units = {u["uid"]: u for u in manifest["units"]}
    lines = []
    for location in item.get("evidence_locations", []):
        unit = units[location["unit_uid"]]
        label = " / ".join(" ".join(filter(None, s)) for s in unit["section"])
        if unit["row"] is not None:
            label += " / 表序号 " + str(unit["table_number"]) + " / 第 " + str(unit["row"] + 1) + " 行（含表头）"
        lines.append("- 定位证据：" + markdown(label + " / " + unit["uid"] + " / " + unit["text"][:240]))
    return lines


def report_overview(record, info, root):
    from .review_report import markdown
    issues = record["issues"]
    lines = ["## 本轮结论", "", "| 严重度 | 未闭环 | 其中待定 | 已闭环 |", "| --- | ---: | ---: | ---: |"]
    for severity, label in (("error", "错误"), ("warning", "警告"), ("info", "提示")):
        selected = [i for i in issues if i["severity"] == severity]
        lines.append("| {0} | {1} | {2} | {3} |".format(label, sum(i["status"] != "closed" for i in selected),
                     sum(i["status"] == "deferred" for i in selected), sum(i["status"] == "closed" for i in selected)))
    from .review_stage import architecture_deferral_candidate
    unresolved = [i for i in issues if i["status"] != "closed"]
    candidates = [i for i in unresolved if architecture_deferral_candidate(i)]
    blockers = [i for i in unresolved if not architecture_deferral_candidate(i)]
    lines += ["", "## 初版架构前须解决的问题", ""]
    lines += ["- " + markdown(i["uid"] + "：" + i["description"]) for i in blockers] or ["无此类已登记问题。"]
    lines += ["", "## 可提请暂缓的缺项", "",
              "用户批准指定缺项后，初版架构将其列为待补充。请用 architecture-status 核对批准范围及剩余阻断。", ""]
    lines += ["- " + markdown(i["uid"] + "：" + i["description"]) for i in candidates] or ["无此类已登记缺项。"]
    lines += ["", "正式交接包须关闭全部问题与待办、解决抽取限制，并取得本版用户确认。"]
    previous = Path(root) / "inputs/previous_state.json"
    if not previous.exists() and info.get("revision_parent"):
        previous = Path(info["revision_parent"]["path"]) / "review_state.json"
    lines += ["", "## 与上一轮对比", ""]
    old = {i["uid"]: i for i in load(previous)["record"]["issues"]} if previous.is_file() else {}
    current = {i["uid"]: i for i in issues}
    for label, ids in (("新增", sorted(set(current)-set(old))),
                       ("本轮关闭", sorted(k for k in set(old)&set(current) if old[k]["status"] != "closed" and current[k]["status"] == "closed")),
                       ("重新打开", sorted(k for k in set(old)&set(current) if old[k]["status"] == "closed" and current[k]["status"] != "closed")),
                       ("仍未闭环", sorted(k for k in set(old)&set(current) if current[k]["status"] != "closed"))):
        lines.append("- " + label + "：" + str(len(ids)) + " 项" + ("；" + markdown("、".join(ids)) if ids else ""))
    lines += ["", "问题 UID 跨轮保持稳定；新增编号建议 issue:R<首次轮次>-NNN，不为已存在的问题重新编号。", ""]
    reused = []
    work = Path(root) / "review-work/checkpoints"
    if work.is_dir():
        reused = [p.stem for p in work.glob("global-*.json") if load(p).get("reused_from")]
    if reused:
        lines += ["- 全局复用（全部源输入、局部记录及规则未变）：" + markdown("、".join(reused)), ""]
    return lines
