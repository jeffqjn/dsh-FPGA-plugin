"""Synthetic regression tests for explicit, isolated downstream skill test mode."""
import copy
from pathlib import Path

from .base import Failure, digest, load, now, save, text, verify_package
from .prepare import prepare
from .review_selftest import synthetic_record, synthetic_confirmation
from .review_stage import review, verify_review, verify_structure_attempt
from .skill_test import NAMESPACE, marker


def skill_test_tests(root):
    root.mkdir()
    results = []

    def rejects(name, function, code):
        try:
            function()
        except (ValueError, KeyError, OSError) as exc:
            assert code in str(exc), (name, str(exc))
            results.append(name)
        else:
            raise AssertionError("negative case accepted: " + name)

    source = root / "source.txt"
    text(source, "1 功能要求\nUR-1 有效命令响应时间不大于10 ms。\nTP-A-001 测量响应时间，<=10ms通过。\n")
    initial = prepare("taskbook", root / "review-input", source)
    record = synthetic_record(initial)
    ref = record["reviewed_element_refs"][1]
    record["issues"] = [{"uid": "issue-0049", "description": "虚构三线/四线矛盾", "status": "open", "severity": "error",
                         "blocking": True, "evidence_refs": [ref], "impact": "虚构验收不确定", "recommendation": "虚构统一接口定义"}]
    record["todos"] = [{"uid": "todo-0049", "issue_uid": "issue-0049", "description": "虚构待办", "status": "open", "evidence_refs": [ref]}]
    record["checks"][0].update(status="fail", issue_refs=["issue-0049"])
    save(root / "record.json", record)
    reviewed = review(initial["attempt"], root / "record.json", root / "review")
    state_path = root / "review/review_state.json"
    state_hash = digest(state_path)
    ordinary = root / "ordinary.json"
    save(ordinary, synthetic_confirmation(reviewed))
    confirmation = root / "test-authorization.json"
    value = dict(synthetic_confirmation(reviewed), kind="approve_skill_test_structuring", test_only=True, simulate_closure=True,
                 request_quote="虚构测试用户：现在是对skill进行测试，请生成独立测试交接包。",
                 user_quote="虚构测试用户：确认本版列出的未明确项和模拟范围，可以开始生成测试包。")
    save(confirmation, value)

    def start(output="test-model", **kwargs):
        return prepare("taskbook", root / output, source, closed_review=root / "review",
                       confirmation=kwargs.pop("confirmation", confirmation), skill_test=kwargs.pop("skill_test", True), **kwargs)

    rejects("normal-mode-still-rejects-unclosed-review", lambda: start("normal", confirmation=ordinary, skill_test=False), "STRUCTURE_REQUIRES_ALL_ISSUES_CLOSED")
    rejects("test-authorization-cannot-implicitly-enable-mode", lambda: start("no-flag", skill_test=False), "STRUCTURE_REQUIRES_ALL_ISSUES_CLOSED")
    rejects("test-flag-with-normal-confirmation-rejected", lambda: start("normal-approval", confirmation=ordinary), "SKILL_TEST_EXPLICIT_AUTHORIZATION_REQUIRED")
    rejects("test-mode-without-review-and-authorization-rejected", lambda: prepare("taskbook", root / "missing", source, skill_test=True), "SKILL_TEST_REQUIRES_REVIEW_AND_EXPLICIT_AUTHORIZATION")
    for label, change, error in (
        ("vague-quote", {"request_quote": "先生成吧，后面再处理"}, "SKILL_TEST_USER_DECLARATION_REQUIRED"),
        ("negated-quote", {"request_quote": "现在不要进行skill测试"}, "SKILL_TEST_NEGATED_DECLARATION"),
        ("negated-feature-test", {"request_quote": "禁止测试skill功能"}, "SKILL_TEST_NEGATED_DECLARATION"),
        ("question-is-not-activation", {"request_quote": "是否进行skill测试"}, "SKILL_TEST_DECLARATION_NOT_AFFIRMATIVE"),
        ("request-without-followup", {"user_quote": ""}, "STRUCTURE_CONFIRMATION_EVIDENCE_REQUIRED"),
        ("unconfirmed-simulation-scope", {"review_items_confirmed": False}, "STRUCTURE_REVIEW_ITEMS_CONFIRMATION_REQUIRED"),
        ("missing-test-only", {"test_only": False}, "SKILL_TEST_EXPLICIT_AUTHORIZATION_REQUIRED"),
        ("missing-simulation", {"simulate_closure": False}, "SKILL_TEST_EXPLICIT_AUTHORIZATION_REQUIRED"),
        ("wrong-version", {"review_state_sha256": "0" * 64}, "STRUCTURE_CONFIRMATION_WRONG_REVIEW"),
        ("timestamp-without-timezone", {"confirmed_at": "2026-10-21T12:00:00"}, "STRUCTURE_CONFIRMATION_TIME_INVALID"),
    ):
        save(root / "bad-auth.json", dict(value, **change))
        rejects("skill-test-" + label + "-rejected", lambda: start(label, confirmation=root / "bad-auth.json"), error)
    rejects("test-mode-not-supported-for-other-skill-kinds", lambda: prepare("writer", root / "bad-kind", skill_test=True), "SKILL_TEST_REQUIRES_REVIEW_AND_EXPLICIT_AUTHORIZATION")
    from datetime import datetime, timedelta
    before_review = (datetime.fromisoformat(load(state_path)["created_at"]) - timedelta(minutes=1)).isoformat()
    save(root / "upfront-authorization.json", dict(value, confirmed_at=before_review))
    rejects("upfront-test-declaration-does-not-replace-review-confirmation",
            lambda: start("upfront", confirmation=root / "upfront-authorization.json"),
            "STRUCTURE_CONFIRMATION_MUST_FOLLOW_REVIEW")

    from .selftest import agent_source
    from .workflow import run, structure, generate
    prepared = run(["prepare", "--input", str(source), "--output", str(root / "test-model"), "--closed-review", str(root / "review"),
                    "--confirmation", str(confirmation), "--skill-test"])
    attempt = Path(prepared["attempt"])
    model = agent_source(attempt)
    model["basic_info"]["product_name"].update(status="present", value="虚构产品", reason=None)
    assert prepared["test_only"] and model["protocol"]["synthetic"]
    assert marker(model)["payload"]["source_issues"][0]["status"] == "open"
    assert model["consistency"]["issues"][0]["display_id"] == "issue-0049"
    assert verify_structure_attempt(attempt)["state"] == "REVIEWING"
    assert digest(state_path) == state_hash and verify_review(root / "review")["state"] == "REVIEWING"
    results.append("explicit-skill-test-cli-prepares-from-open-review-without-altering-real-state")
    # Technical quality gaps are retained, while simulated gate closure enables a test handoff.
    model["verification"]["source_test_points"] = []
    model["source_baseline"]["test_point_refs"] = []
    late = copy.deepcopy(model["consistency"]["issues"][0])
    late.update(uid="issue:late", display_id="IS-LATE", stable_key="late", status="open", summary="虚构建模中新发现问题")
    model["consistency"]["issues"].append(late)
    model["consistency"]["todos"].append({"uid": "todo:late", "kind": "supplement", "description": "虚构新待办", "issue_refs": ["issue:late"],
                                          "notice_refs": [], "required": True, "status": "open", "decision_refs": [], "completion_evidence_refs": []})
    model["completeness"]["gaps"] = [{"uid": "gap:late", "kind": "test-only", "description": "虚构工程缺口", "affected_refs": [],
                                      "blocking_for": ["architecture"], "evidence_refs": [], "issue_refs": ["issue:late"]}]
    for ext in model["extensions"]:
        if ext["namespace"] == "feip.assessments.v1":
            ext["payload"]["rules"][0].update(status="fail", issue_refs=["issue:late"])
    save(root / "model.json", model)
    published = structure(attempt, root / "model.json", root / "test-package")
    final, manifest = verify_package(root / "test-package")
    assert published["test_only"] and final["protocol"]["synthetic"] and manifest["synthetic"]
    assert all(i["status"] == "resolved" for i in final["consistency"]["issues"])
    assert all(t["status"] == "closed" for t in final["consistency"]["todos"])
    assert final["basic_info"]["product_name"]["value"] == "【仅供skill功能测试】虚构产品"
    simulation = marker(final)["payload"]["model_before_simulation"]
    assert simulation["issues"][-1]["status"] == "open" and simulation["todos"][-1]["status"] == "open"
    assert simulation["original_product_name"]["value"] == "虚构产品"
    assert final["completeness"]["gaps"] == simulation["gaps"] == model["completeness"]["gaps"]
    assert digest(state_path) == state_hash and (root / "test-package/closed_review/review_state.json").read_bytes() == state_path.read_bytes()
    for name in ("需求清单.md", "taskbook_review.md", "测试模式说明.md"):
        assert "【仅供skill功能测试】" in (root / "test-package" / name).read_text(encoding="utf-8")
    results.append("test-package-simulates-issues-todos-and-rules-with-audit-watermarks-and-originals-retained")
    writer = prepare("writer", root / "writer", baseline=root / "test-package")
    writer_model = load(writer["template"])
    assert writer_model["protocol"]["synthetic"] and marker(writer_model)["payload"]["test_only"]
    save(root / "writer-model.json", writer_model)
    generate(writer["attempt"], root / "writer-model.json", root / "writer-package")
    verify_package(root / "writer-package")
    assert "【仅供skill功能测试】" in (root / "writer-package/需求规格说明.md").read_text(encoding="utf-8")
    results.append("synthetic-test-package-is-accepted-by-downstream-writer-and-retains-test-identity")

    broken = start("broken")
    broken_model = agent_source(broken["attempt"])
    broken_model["requirements"][0]["source_atomic_refs"] = ["atom:missing"]
    save(root / "broken.json", broken_model)
    rejects("test-mode-still-rejects-invalid-engineering-references", lambda: structure(broken["attempt"], root / "broken.json", root / "bad-package"), "MODEL_INVARIANT_INVALID")
    stripped = start("stripped")
    stripped_model = agent_source(stripped["attempt"])
    stripped_model["protocol"]["synthetic"] = False
    save(root / "stripped.json", stripped_model)
    rejects("test-model-cannot-remove-synthetic-marker", lambda: structure(stripped["attempt"], root / "stripped.json", root / "stripped-package"), "SKILL_TEST_MARKER_REQUIRED")

    # Test discovery corrections must retain the original finding, while normal mode still latches.
    from . import model_batches
    from .batch_selftest import fill_model_fragment
    batched = start("batched")
    ba = Path(batched["attempt"])
    full = agent_source(ba)
    task = model_batches.next_task(ba)
    payload = fill_model_fragment(ba, task, full, first=True)
    payload["new_issues"] = [{"description": "虚构测试阶段新歧义"}]
    fragment = root / "fragment.json"
    save(fragment, payload)
    model_batches.submit(ba, fragment)
    payload["new_issues"] = []
    save(fragment, payload)
    model_batches.submit(ba, fragment)
    assert model_batches.status(ba)["state"] != "RETURN_TO_REVIEW"
    assert load(ba / "model-work/test-discoveries.json")[0]["new_issues"][0]["description"] == "虚构测试阶段新歧义"
    while not model_batches.status(ba)["complete"]:
        task = model_batches.next_task(ba)
        save(fragment, fill_model_fragment(ba, task, full))
        model_batches.submit(ba, fragment)
    structure(ba, None, root / "batched-package")
    batched_model, _ = verify_package(root / "batched-package")
    assert marker(batched_model)["payload"]["model_before_simulation"]["discoveries"]
    assert digest(state_path) == state_hash
    results.append("test-mode-batches-retain-new-discoveries-without-blocking-structured-test-output")
    normal = prepare("taskbook", root / "normal-after-test", source, previous_state=state_path)
    assert not load(Path(normal["attempt"]) / "attempt.json").get("skill_test")
    assert load(Path(normal["attempt"]) / "review.template.json")["issues"][0]["status"] == "open"
    results.append("test-mode-does-not-persist-or-close-issues-in-subsequent-normal-rounds")
    original_source = source.read_bytes()
    text(source, "虚构源文档修改")
    rejects("test-authorization-is-invalid-after-source-change", lambda: start("changed-source"), "REVIEW_SOURCE_CHANGED")
    source.write_bytes(original_source)

    # Missing image content stays visibly unread, rather than becoming a fabricated transcript.
    binary = root / "diagram.bin"
    binary.write_bytes(b"synthetic unread image")
    attachments = root / "attachments.json"
    save(attachments, [{"path": str(binary), "description": "虚构未读图"}])
    partial = prepare("taskbook", root / "partial", source, attachments=attachments)
    partial_record = synthetic_record(partial)
    partial_record["issues"] = copy.deepcopy(record["issues"])
    partial_record["extraction_checks"][1].update(status="unresolved", rationale="虚构图片内容未读取")
    save(root / "partial-record.json", partial_record)
    partial_review = review(partial["attempt"], root / "partial-record.json", root / "partial-review")
    partial_authorization = dict(value, review_uid=partial_review["review_uid"], review_state_sha256=partial_review["review_state_sha256"], confirmed_at=now())
    save(root / "partial-authorization.json", partial_authorization)
    partial_model = prepare("taskbook", root / "partial-model", source, attachments=attachments, closed_review=root / "partial-review",
                            confirmation=root / "partial-authorization.json", skill_test=True)
    save(root / "partial-model.json", agent_source(partial_model["attempt"]))
    structure(partial_model["attempt"], root / "partial-model.json", root / "partial-package")
    partial_final, _ = verify_package(root / "partial-package")
    assert marker(partial_final)["payload"]["extraction_checks"][1]["status"] == "unresolved"
    assert any(a["extraction_status"] == "not_read" for a in partial_final["document_archive"])
    results.append("test-mode-preserves-unread-attachment-facts-without-fabricated-transcription")
    return results
