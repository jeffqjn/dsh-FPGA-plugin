<div align="center">
  <h1>test-spec-gen</h1>
  <p><strong>把确认测试细则与 FEIP 包，按受控模板生成可直接评审交付的《FPGA 确认测试计划》与《确认测试报告》</strong></p>
  <p>Python 3.8.10 · Windows 7 SP1 离线 · 仅标准库 · 版本 1.0.0</p>
  <p><a href="README_EN.md">English</a> · <a href="#快速开始">快速开始</a> · <a href="#触发与适用范围">触发边界</a> · <a href="#输入输出与工作流">输入输出</a></p>
</div>

本技能只消费上游交付物：`test-specification` 家族产物（`test_specification.json` 必需，`verification_plan.json`、`coverage_report.json`、`RTM.csv` 建议）与一个 FEIP 包（`taskbook-reviewed` 或 `reqspec-reviewed`）。它按 1-58 计划模板与 1-59 报告模板生成 DOCX 与 Markdown，附缺口清单与产保要素自检表。**不重新抽取任务书、不做需求终审、不重排验证义务，也不填任何实测结果**——结果项一律写 `-`。

## 快速开始

```text
请使用 test-spec-gen skill 生成确认测试计划与报告。
输入：<test_specification.json 所在目录>，<taskbook-reviewed 或 reqspec-reviewed 包目录>
输出：<输出目录>，含确认测试计划.docx / .md、确认测试报告.docx / .md、缺口清单.md、生成检查报告
```

最短路径：先 `inspect` 核验输入与摘要，再 `both` 一次出两份文档，最后过九道校验门。

## 触发与适用范围

**适合使用**

- 确认测试细则已交付，需要按模板出**计划与报告**正式文档。
- 已有计划、只需生成或刷新报告（增量模式）。
- 需要附录 E/F 的产保要素判定与缺口清单，随文档一起交付。

**不适合使用**

- 还没有 `test_specification.json`——先跑确认测试细则类 skill。
- 想生成实测结论或填写结果：本技能不产生实测数据，结果项固定为 `-`。
- 想改模板结构：模板是受控文件，改动属于评审确认的结构调整，不在本技能范围内。

## 输入输出与工作流

| 阶段 | 做什么 | 产出 |
| --- | --- | --- |
| 1 核验输入 | `inspect` 确认 FEIP profile 与 state、用例与证据程序数量、规范化摘要是否与覆盖报告一致、`design_status` 与 `execution_status`；摘要按 `json.dumps(sort_keys=True, separators=(',',':'))` 重算，不是文件字节哈希 | 核验结果与错误码 |
| 2 生成计划与报告 | `both` 一次出两份，也可 `plan` / `report` 单独出；全部按槽位锚点写入，锚点缺失即 `TEMPLATE_ANCHOR_MISSING` 并停止 | 计划 DOCX/MD、报告 DOCX/MD |
| 3 自检与闭环 | 附录 E/F 由 `rules/conformance_rules.json` 判定，输出 `符合` / `不符合` / `不适用` / `待实测`；判定为 `不符合` 的必须同时出现在 `缺口清单.md` | 产保要素自检表、缺口清单 |
| 4 交付 | 九道校验门全过才发布：锚点、残留占位、标题结构、编号（含分节数与固定表行数）、数据完备、摘要、可重开、输入未变、确定性；再与模板逐节对照，C 类不变量必须零违例 | 完整交付包 |

## 常用命令

```powershell
python scripts\cli.py doctor
python scripts\cli.py inspect --source <FEIP包> --spec <test_specification.json> [--coverage coverage_report.json] [--rtm RTM.csv]
python scripts\cli.py both --source <FEIP包> --spec <test_specification.json> --out <输出目录>
python scripts\cli.py plan|report --source <FEIP包> --spec <test_specification.json> --out <输出目录>
python scripts\cli.py section --docx <某份docx> --list
python scripts\cli.py section --docx <某份docx> --heading 3.3 --max-chars 800
```

`scripts\run.ps1` 是 PowerShell 入口（Win7，需设置 `FPGA_PYTHON38`）。产物一律由脚本写盘，不经对话输出；核对文档用 `section` 按章节取，不整段读 200KB 的 Markdown。

## 功能要点

- **一份输入出两份文档**：计划先出、报告再出，因为报告附录 F 有 4 项检查对象在计划里。
- **只按槽位锚点写入**：锚点缺失就报错停止，不改用块序号猜位置。
- **九道校验门全过才发布**：锚点、残留占位、标题结构、编号、数据完备、摘要、可重开、输入未变、确定性。
- **产保要素程序自检**：附录 E/F 输出 `符合`/`不符合`/`不适用`/`待实测` 四值，判定为不符合的强制进缺口清单。
- **不填实测结果**：结果项一律 `-`，本技能不产生实测数据，只交付可评审的计划与报告。

## 更多文档

- 输入与产物契约、错误码：[`references/contract.md`](references/contract.md)
- 槽位清单与模板缺陷：[`references/slot-map.md`](references/slot-map.md)、[`references/template-defects.md`](references/template-defects.md)
- 增量模式（复用已发布计划出报告）：[`references/incremental.md`](references/incremental.md)
- 离线运行接口与实测环境：[`references/runtime.md`](references/runtime.md)
