---
name: test-spec-gen
description: 用 test-specification 数据包加结构化任务书或需求规格说明，按指定模板生成 FPGA 确认测试计划与确认测试报告的 DOCX、Markdown、缺口清单与产保要素自检表；报告不填实测结果，产保/技术要素检查表由程序自检给出判定。
---

# FPGA 确认测试计划与报告

读取[输入与产物契约](references/contract.md)。运行环境见[离线运行接口](references/runtime.md)。槽位与模板缺陷分别见[槽位清单](references/slot-map.md)、[模板缺陷与处理](references/template-defects.md)；取数与缺口口径见[映射规则](references/mapping-rules.md)；复用已发布计划出报告见[增量模式](references/incremental.md)。

本技能只消费上游交付物：`test-specification` 家族产物（`test_specification.json` 必需，`verification_plan.json`/`coverage_report.json`/`RTM.csv` 建议）与一个 FEIP 包（`taskbook-reviewed` 或 `reqspec-reviewed`）。不重新抽取任务书、不做需求终审、不重排验证义务。

## 流程

1. **核验输入。** 先 `inspect`，确认 FEIP 包 profile 与 state、细则的用例与证据程序数量、规范化摘要是否与覆盖报告一致、`design_status` 与 `execution_status`。摘要按 `json.dumps(sort_keys=True,separators=(',',':'))` 重算，不是文件字节哈希。校验失败按[契约](references/contract.md)的错误码处置，不绕过。
2. **生成计划与报告。** `both` 一次出两份；也可 `plan` 或 `report` 单独出。内容全部按槽位锚点写入，锚点缺失即报 `TEMPLATE_ANCHOR_MISSING` 并停止，**不改用块序号猜位置**。计划先出，报告再出，因为报告附录F 有 4 项检查对象在计划里。
3. **自检与闭环。** 附录E/附录F 由 `rules/conformance_rules.json` 判定，输出 `符合`/`不符合`/`不适用`/`待实测` 四值并写入表格；判定为 `不符合` 的必须同时出现在 `缺口清单.md`。结果项一律写 `-`，本技能不产生实测数据。
4. **交付。** 只有九道校验门全过才发布产物：锚点、残留占位、标题结构、编号（含分节数与固定表行数）、数据完备、摘要、可重开、输入未变、确定性。发布后再跑一次 `tests/compare_templates.py` 与模板逐节对照，差异按[模板一致性对照](references/template-conformance.md)的三分类核对：A 类是评审确认的结构调整、B 类是数据驱动的行数、**C 类不变量必须零违例**。缺口清单与生成检查报告随产物一起交付。

## 输出预算

宿主单条回复上限 32,768 token，产物一律由脚本写盘、不经对话输出。核对文档时用 `section` 按章节取，
不要整段读或转述 200 KB 的 Markdown：

```text
python scripts/cli.py section --docx <某份docx> --list
python scripts/cli.py section --docx <某份docx> --heading 3.3 --max-chars 800
```

比对脚本默认只给分类计数与报告路径，需要逐条再加 `--full`。回复里只报文件名、数字与结论。

## 边界

- 只读输入，双向 sha256 冻结；输出目录不得落在输入内，已存在则报 `OUTPUT_EXISTS` 不覆盖。
- 不补封面页、签署页与目录（模板本身没有）；不改 `styles.xml`、`numbering.xml`、页脚与分节。
- 不编造：任务书没有的量（温度、功耗、重量、尺寸、辐照、人员、工作量）写"任务书未规定"并记缺口，绝不填入示例值充数。
- 产保/技术要素判定只证明文档内容自身的完整性，不代替设计师对适用性的确认；`不适用` 与 `待实测` 两类须由人工复核。

目标 Windows 7 SP1、PowerShell 2.0、Python 3.8.10，仅标准库。先用宿主 execute command 执行准确解释器路径下的 `cli.py doctor`，核对退出码与 `FEIP_SKILL_OK:doctor`；不使用未经核实的解释器。宿主拒绝访问时保留命令及错误，在已有权限的目录完成可恢复的工作。技能的操作范围是读取输入和写入产物目录。

## 命令

```text
python scripts/cli.py doctor
python scripts/cli.py self-test
python scripts/cli.py inspect --source <FEIP包> --spec <test_specification.json>
python scripts/cli.py section --docx <某份docx> --list
python scripts/cli.py section --docx <某份docx> --heading 3.3 --max-chars 800
python scripts/cli.py both --source <FEIP包> --spec <test_specification.json> --out <输出目录>
python scripts/cli.py report --source <FEIP包> --spec <test_specification.json> --plan-docx <已发布计划.docx> --out <输出目录>
python tests/compare_templates.py
```
