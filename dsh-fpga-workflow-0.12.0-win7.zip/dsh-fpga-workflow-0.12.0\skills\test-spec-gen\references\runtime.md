# 离线运行接口（1.0.0）

目标运行环境：Windows 7 SP1 + PowerShell 2.0 + CPython 3.8.10，离线、仅标准库。入口脚本 `scripts/run.ps1`，唯一 Python 入口 `scripts/cli.py`。

## 1. 实测环境（2026-11-15，本机）

| 项 | 实测值 | 来源 |
|---|---|---|
| 操作系统 | `Windows 10`（`platform` 串 `Windows-10-10.0.26200-SP0`） | `cli.py doctor` 输出 |
| 宿主 PowerShell | 5.1.26100.9818 | `$PSVersionTable.PSVersion` |
| Python | CPython 3.8.10（64 位 MSVC 1928） | `python -V`、`platform.python_implementation()` |
| 解释器路径 | `C:\Users\NoahQ\WorkBuddy\2026-10-19-23-36-30\legacy-harness\python38\python.exe`（本机 `FPGA_PYTHON38` 未设置，`run.ps1` 的默认 `C:\Python38\python.exe` 不存在，必须显式设置） | `doctor` 的 `python_executable` |
| 模板字节数 | `plan.docx` 108395、`report.docx` 98632 | `doctor.templates` |
| 规则文件 | `rules/conformance_rules.json` 存在 | `doctor.rules_present=true` |

`doctor` 完整输出（原样；仅 `python_executable` 的长路径用 `…` 省略，其余逐字）：

```text
{"skill_version": "1.0.0", "python": "3.8.10", "python_executable": "...python38\\python.exe", "implementation": "CPython", "platform": "Windows-10-10.0.26200-SP0", "os": "Windows 10", "expected_python": "3.8.10", "stdlib_only": true, "templates": {"plan.docx": 108395, "report.docx": 98632}, "rules_present": true}
FEIP_SKILL_OK:doctor
```

## 2. `run.ps1` 用法

```powershell
$env:FPGA_PYTHON38 = 'D:\python38\python.exe'
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\run.ps1 doctor
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\run.ps1 both `
  --source  D:\feip-package `
  --spec    D:\out\test_specification.json `
  --out     D:\out\confdoc-v1
```

行为逐条（`scripts/run.ps1`，936 字节，**纯 ASCII，0 个非 ASCII 字节**，已实测）：

| 行 | 行为 |
|---|---|
| `#requires -version 2.0` | 低于 PS2.0 直接拒跑 |
| `param([string]$Action)` | 第一个位置参数是动作 |
| `$MyInvocation.MyCommand.Path` | 取脚本目录，**不用** `$PSScriptRoot`（PS2.0 没有） |
| `$env:FPGA_PYTHON38` | 未设置时回落 `C:\Python38\python.exe`；文件不存在则 `throw` |
| 环境变量导出 | `PYTHONIOENCODING=utf-8`、`PYTHONUTF8=1`、`PYTHONDONTWRITEBYTECODE=1` |
| `& $pythonExe cli.py $Action @args` | 其余参数原样透传 |
| 退出码 | 透传 Python 退出码；为 0 时再检查输出含 `FEIP_SKILL_OK:<action>`，缺失则 `throw 'Success marker missing.'` |

`run.ps1` 不解析 JSON、不计算哈希、不解压；一切逻辑在 Python 侧。

## 3. PowerShell 2.0 禁忌

| 禁用 | 原因 | 替代 |
|---|---|---|
| `$PSScriptRoot` | PS3.0 才有 | `Split-Path -Parent $MyInvocation.MyCommand.Path` |
| `ConvertFrom-Json` / `ConvertTo-Json` | PS3.0 才有 | 交给 Python；宿主需要时用 `python -c` |
| `Get-FileHash` | PS4.0 才有 | `cli.py` 内的 `file_sha256`，或 `certutil -hashfile` |
| `Expand-Archive` | PS5.0 才有 | Python `zipfile` |
| `Get-ChildItem -File` | PS3.0 才有 | `Where-Object { -not $_.PSIsContainer }` |
| 脚本内中文 | PS2.0 读无 BOM 的 UTF-8 会乱码 | 脚本纯 ASCII，中文一律放 Python 源码（UTF-8 带 `# -*- coding: utf-8 -*-`） |
| `>` 重定向写文件 | PS5.1 的 `>` 写 UTF-16LE，Python 读不了 | `| Out-File -Encoding utf8`（PS2.0 用 `| Out-File -Encoding utf8` 亦写 UTF-8 BOM，读侧 `utf-8-sig` 可容忍） |

## 4. 编码约定

| 对象 | 约定 | 实现 |
|---|---|---|
| JSON | UTF-8 **无 BOM**、LF、`ensure_ascii=False`、`allow_nan=False`、`indent=2` | `base.dumps_json` + `base.atomic_write_text`（写入前把 `\r\n`/`\r` 归一成 `\n`） |
| Markdown（`.md`） | UTF-8 无 BOM、LF | 同上 |
| CSV | 家族内**唯一允许 BOM**（`utf-8-sig` + CRLF），Excel 才认中文 | `base.write_csv_bom`；本 skill 当前不产出 CSV |
| 读输入 | 一律 `utf-8-sig`，容忍 BOM | `base.read_json` / `base.read_text` / `spec.load_rtm`（`csv.DictReader`） |
| JSON 守卫 | 拒重复 key（`JSON_DUPLICATE_KEY`）、拒 `NaN`/`Infinity`（`JSON_INVALID_CONSTANT`）、解析失败 `JSON_PARSE_FAILED` | `base.read_json` |
| 控制台 | stdout/stderr 均 UTF-8（由 `run.ps1` 导出的两个环境变量保证） | — |

## 5. 运行时闸门

`base.check_runtime()` 在 `cli.main()` 的第一条语句执行，规则：

1. `tuple(sys.version_info[:3]) == (3, 8, 10)`，**精确匹配**（3.8.11、3.8.9、3.9 一律拒绝）；
2. `platform.python_implementation() == "CPython"`。

不满足即 `PYTHON_RUNTIME_MISMATCH`，`details` 给 `{"expected":"3.8.10","actual":"<实际版本>"}`，退出码 2。这个闸门没有 `--force`、没有环境变量开关。

只有 `tests/run_tests.py` 绕过闸门：它直接 `import confdoc.selftest` 跑 17 项确定性回归，可在任意 Python 上执行（`python tests/run_tests.py`，全过返回 0）。

## 6. 排错表

| 错误码 | 现象 | 原因 | 处置 |
|---|---|---|---|
| `PYTHON_RUNTIME_MISMATCH` | 任何动作立刻失败 | 解释器不是 3.8.10 CPython | 设 `FPGA_PYTHON38` 指向 3.8.10 的 `python.exe`；`py -V:3.8` 可先确认 |
| `TEMPLATE_MISSING` | `doctor` 就失败 | `templates/plan.docx` 或 `report.docx` 缺失 | 从原件恢复，**不要**改文件名；`doctor` 会打印模板字节数，108395 / 98632 即原件 |
| `TEMPLATE_ANCHOR_MISSING` | 生成中途失败，`details` 带 `style`/`prefix`/`exact`/`needle` | 模板被替换或段落文字被改，锚点不命中 | 换回原件；确需支持新模板时改 `plan_content.py`/`report_content.py` 的锚点，禁止改回块序号定位 |
| `RESIDUAL_PLACEHOLDER` | 生成后失败，`details.hits` 列出块号与片段 | 正文仍含 `/*`、`*/`、`××`、`XX`、`……`、`例如：`、`示例：`，或 `□`/`■` 出现在表格以外的段落 | 按 hits 定位：注释段用 `strip_comments` 规则处理，示例段进 `strip_example_markers`，勾选符只能出现在健壮性列与勾选表单元格 |
| `HEADING_DRIFT` | 生成后失败，`details` 给 `before`/`after` 标题树 | 计划：标题树任何变化都报错；报告：除 `3.3.*`、`3.5.2.*` 外的原有标题必须仍是原树的子序列 | 计划侧多为“删到了带 `sectPr` 的空标题”或“新增了自动编号标题”；报告侧看是否误删 1–5 章标题 |
| `NUMBERING_BROKEN` | 生成后失败 | 残留空标题段（计划含 style `1/2/3`，报告含 `1/2/3/4`），或报告出现空的 `3.3.x` | 空标题若有内容需求就填文字；无内容则按第 7 节的分节符规则处理，**不得**直接删段 |
| 分节符丢失（无专门错误码） | 产物 Word 里附录变成纵向/页边距变了 | 删除或替换了带 `<w:pPr><w:sectPr>` 的段落 | 验收断言：`word/document.xml` 中 `<w:sectPr` 计数必须与模板一致——计划 **5**、报告 **4**。用 `zipfile` 读 `word/document.xml` 数字符串即可；`builder._write_lines` 对含 `<w:sectPr` 的段只清空文字不删除 |
| `DATA_INCOMPLETE` | 生成后失败，`details.missing` 列出条目 ID | 某个 `test_case_id`/`procedure_id` 没有出现在任何表格里 | 检查附录用例表是否因分组过滤漏项（`@boundary` 等场景节只出说明不出表，属正常）；真漏项改 `plan_content.APPENDIX_SECTIONS` 映射 |
| `DOCX_UNREADABLE` | 产物已写出后才失败 | 生成的 `word/document.xml` 无法被 `ET.fromstring` 解析 | 说明写侧拼接破坏标记；回看是否在 XML 字符串上做 `str.replace`（禁止），或用 `docxlib` 原语重写 |
| `DOCX_MALFORMED` / `DOCX_NOT_WORD` | 打开输入或模板即失败 | 包缺 `word/document.xml`，或 body 标签不平衡 | 确认传入的是 `.docx` 而不是 `.doc`/`.docm`/改后缀的文件 |
| `INPUT_MUTATED` | 写盘后失败 | 生成前后输入文件 sha256 不一致（生成期间有人改了输入） | 冻结输入后重跑；不要把 `--out` 指到输入目录内（那会先报 `OUTPUT_INSIDE_SOURCE`） |
| `OUTPUT_EXISTS` | 立刻失败 | `--out` 目录已存在 | 换新目录名；本 skill **从不**覆盖已有目录 |
| `OUTPUT_INSIDE_SOURCE` | 立刻失败 | `--out` 等于或位于 `--source` / `--spec` 目录内 | 输出放到输入之外的目录 |
| `PLAN_REQUIRED_FOR_CONFORMANCE` | 生成到附录F 时失败，`details.rule` 为 `F-01/F-07/F-09/F-10` | 附录F 的这 4 项判定对象是**计划**，而 `ctx["plan_doc"]` 为空（`report` 有兜底：没给 `--plan-docx` 就用 `--spec` 内存构建，所以 CLI 路径通常不会触发；直接调用 `conformance.evaluate` 时才可能） | 给 `--plan-docx <已发布计划.docx>` 或确保 `--spec` 可解析；**不允许**把“缺计划输入”改判成 `不符合` |
| `RULES_MISSING` | 生成到附录E/F 时失败 | `rules/conformance_rules.json` 缺失 | 恢复规则文件；路径由 `conformance.RULES_PATH` 固定 |
| `RULE_KIND_UNKNOWN` | 同上，`details.rule` 给出规则 id | 规则里 `kind` 不在六种谓词内（`doc_section`/`doc_table`/`cases_cover`/`feip_collection`/`feip_field_ratio`/`upstream_landed`）或写了 `results_available` 之外的新值 | 改规则文件，用已支持的 `kind`；新增谓词必须同时改 `conformance._CHECKERS` |
| `SPEC_*`（见契约） | `inspect` 或生成前置校验失败 | 细则 status/open_items、method、追溯、版本不合格 | 修上游交付物；本 skill 不做“容错生成” |
| `JSON_DUPLICATE_KEY` / `JSON_INVALID_CONSTANT` | 读输入即失败 | 输入 JSON 有重复 key 或 `NaN` | 修上游序列化；不要用宽松解析器绕过 |

## 7. 空标题与分节符（易踩的坑）

计划模板 p109、报告模板 p134 是空 Heading 1，它**同时携带 `w:pPr/w:sectPr`**，是纵向正文与横向附录之间的分节符所在段。删除该段会让分节从 5→4（计划）/ 4→3（报告），横向附录全部丢失。

实现因此保留该段、只摘掉标题样式（`plan_content._strip_heading_style` 去掉 `<w:pStyle/>` 与 `<w:outlineLvl/>`），报告复用同一函数。凡是 `raw` 含 `<w:sectPr` 的段落，任何删除操作都必须跳过（`builder._write_lines` 已按此实现）。验收断言即上表的“分节符丢失”一行：`<w:sectPr` 计数计划 5、报告 4。

## 8. 验收边界

- 本版本只在 Windows 10（10.0.26200）+ PowerShell 5.1 + CPython 3.8.10 上实测；**未**在 Windows 7 SP1、**未**在 PowerShell 2.0 实机验收。
- `run.ps1` 已按 PS2.0 约束编写（无 `$PSScriptRoot`、无 `ConvertFrom-Json`/`Get-FileHash`/`Expand-Archive`、纯 ASCII），但“语法在 PS2.0 可解析”只能由目标机复核，当前证据是代码审查而非实跑。
- 不依赖 Word 渲染做验收（本机 Word COM 导出 PDF 会挂死）：验收用 `zipfile` 重开 + `ET` 解析 + 表格文本比对 + `<w:sectPr` 计数。
- `self-test` 的 `scope` 字段自带提示：`deterministic helpers; agent semantics and a real Win7 host still need acceptance`。

## 性能与并行边界（实测）

一台机器、一个进程、零网络，跑完 `both`（两份 docx + Markdown + 缺口清单 + 自检表 + 检查报告）的实测耗时：

| 阶段 | 耗时 | 占比 |
|---|---|---|
| 报告内容生成 | 2.9 s | 36% |
| 校验门（G1–G10） | 2.4 s | 30% |
| 计划内容生成 | 2.4 s | 30% |
| 打开模板（2 份） | 0.25 s | 3% |
| 保存 docx（2 份） | 0.05 s | <1% |
| Markdown 导出（2 份） | 0.007 s | <1% |
| **合计** | **8.1 s** | |

优化记录（同一台机器、同一份输入，17.3 s → 8.1 s）：

| 改动 | 收益 |
|---|---|
| 单元格/段落文本按 block 缓存，`set_block` 只失效该块 | 校验门 5.1 s → 2.4 s；Markdown 2.6 s → 7 ms |
| `heading_tree()` 缓存（原来每个标题都重算一次编号） | Markdown 的主要开销消失 |
| `fill_table` 一次切分行，逐格改用 `Row.set_cells`（原来是 O(格数²)） | 内容生成 9.2 s → 5.3 s |
| `fragment_text` 改单次正则（原来每格两次标签扫描） | 再省约 1.1 s |

### 为什么不用子 agent 并行生成

生成是**确定性纯 Python**：给定同一份输入，两次运行的 `word/document.xml` 必须字节一致（G9），且"不编造"要求每个值都能追到 FEIP 字段或明确的缺口短语。子 agent 是 LLM 调用——每次几十秒、结果不确定，既做不到字节一致，也无法保证不把任务书里没有的值写进去。**用它生成会比现在慢一到两个数量级，且失去可复现性**，因此不采用。

### 值得并行的三个场景

| 场景 | 做法 | 为什么可行 |
|---|---|---|
| 多产品批量 | 每个 FPGA 一个独立进程跑 `both`，互不共享状态 | 产物目录本就要求 `OUTPUT_EXISTS` 不覆盖，天然隔离 |
| 审阅（非生成） | 多个 sub agent 分别审"正文/附录用例/追溯矩阵/产保自检"，主 agent 汇总成问题清单 | 这是判断型任务，允许非确定；且**不参与产物生成**，不影响 G9 |
| 独立校验 | `tests/compare_templates.py`、`tests/run_tests.py` 与主流程无共享写入 | 只读产物，可与下一轮生成并行 |

### 不要再叠加的优化

进程内多线程/多进程拆分 121 张用例表：`block` 列表是顺序结构，插入必须串行；内容生成只占总时长 36%，Win7 上 `spawn` 一个 Python 3.8 进程约 0.2 s，拆分收益抵不过进程开销。当前 8 秒里没有值得拆的热点。

## 宿主限制：单次回复输出上限 32,768 token

内网 Win7 上的 DSH 部署把单条回复限制在 **32,768 token**（含思考与工具调用参数），
上下文窗口是 512,000 token。超过上限时返回 `finish_reason: length`，正文会被截断。

**本技能的产物不经过对话输出**：两份 docx、Markdown、缺口清单、自检表全部由 Python 写盘，
stdout 只有一行 JSON 摘要。实测各动作的 stdout 长度：

| 动作 | stdout 字符数 | 约合 token |
|---|---|---|
| `doctor` | ~400 | <200 |
| `self-test` | ~160 | <100 |
| `inspect` | ~780 | ~400 |
| `both`（出两份文档） | ~450 | ~250 |
| `section --heading 3.3 --max-chars 400` | ~300 | ~200 |
| `tests/compare_templates.py`（默认摘要） | ~280 | ~180 |

### 必须遵守的四条

1. **不整段读生成物**。`确认测试计划.md` / `确认测试报告.md` 各约 200 KB（≈7 万 token），
   只用于人工评审；机器核对一律用 `section` 按章节取，并给 `--max-chars`。
2. **不整段贴产物**。回复里只给文件名、统计数字与结论，不要把文档正文粘进对话。
3. **比对不全量打印**。`compare_templates.py` 默认只打分类计数与报告路径；
   需要逐条时加 `--full`，且应分批看（报告已落盘在 `tests/compare_report.md`）。
4. **结果过长自动转存**。CLI 用 `--result-max-chars`（默认 8000）保护：
   结果 JSON 超限时写入 `result-<action>.json`，stdout 只留指针。

### 被截断时怎么办

- 生成是**幂等**的：产物已落盘，输入哈希记录在 `package.json`。重新跑一次即可，不必手工续写。
- 会话被截断后回一句「继续」；`plan` / `report` / `both` 都可重复执行，但输出目录已存在会报
  `OUTPUT_EXISTS`，换个 `--out` 目录即可。
- 校验门失败时只回错误码与 `details` 前若干条（代码里已 `[:20]` 截断），不要要求打印全量命中。
