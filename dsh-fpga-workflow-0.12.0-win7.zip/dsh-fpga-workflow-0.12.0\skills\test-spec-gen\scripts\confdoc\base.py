# -*- coding: utf-8 -*-
"""Runtime gate, encoding, hashing, atomic write and JSON guards.

Target: Windows 7 SP1 / Python 3.8.10 / standard library only.
"""
import errno
import hashlib
import io
import json
import os
import platform
import sys
import uuid

EXPECTED_PYTHON = (3, 8, 10)
SKILL_VERSION = "1.0.0"


class SkillError(Exception):
    """Error carrying a stable machine readable code."""

    def __init__(self, code, message, details=None):
        Exception.__init__(self, message)
        self.code = code
        self.message = message
        self.details = details

    def as_dict(self):
        return {"code": self.code, "message": self.message, "details": self.details}


def check_runtime():
    """Reject every interpreter except CPython 3.8.10."""
    actual = tuple(sys.version_info[:3])
    if actual != EXPECTED_PYTHON:
        raise SkillError(
            "PYTHON_RUNTIME_MISMATCH",
            "Python 3.8.10 is required, found %s" % (sys.version.split()[0],),
            {"expected": "3.8.10", "actual": sys.version.split()[0]},
        )
    if platform.python_implementation() != "CPython":
        raise SkillError(
            "PYTHON_RUNTIME_MISMATCH",
            "CPython is required, found %s" % (platform.python_implementation(),),
            {},
        )


def runtime_report(python_exe=None):
    return {
        "skill_version": SKILL_VERSION,
        "python": sys.version.split()[0],
        "python_executable": python_exe or sys.executable,
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "os": platform.system() + " " + platform.release(),
        "expected_python": "3.8.10",
        "stdlib_only": True,
    }


def _reject_duplicate_keys(pairs):
    seen = {}
    for key, value in pairs:
        if key in seen:
            raise SkillError(
                "JSON_DUPLICATE_KEY", "duplicate JSON key: %s" % (key,), {"key": key}
            )
        seen[key] = value
    return seen


def _reject_constant(token):
    raise SkillError(
        "JSON_INVALID_CONSTANT", "non-finite number is not allowed: %s" % (token,), {}
    )


def read_json(path):
    """Read JSON as UTF-8, tolerating a BOM, rejecting duplicate keys and NaN."""
    with io.open(path, "r", encoding="utf-8-sig") as handle:
        try:
            return json.load(
                handle,
                object_pairs_hook=_reject_duplicate_keys,
                parse_constant=_reject_constant,
            )
        except ValueError as exc:
            raise SkillError(
                "JSON_PARSE_FAILED",
                "cannot parse JSON: %s" % (str(exc),),
                {"path": str(path)},
            )


def read_jsonl(path):
    rows = []
    with io.open(path, "r", encoding="utf-8-sig") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(
                    json.loads(
                        line,
                        object_pairs_hook=_reject_duplicate_keys,
                        parse_constant=_reject_constant,
                    )
                )
            except ValueError as exc:
                raise SkillError(
                    "JSONL_PARSE_FAILED",
                    "cannot parse JSONL line: %s" % (str(exc),),
                    {"path": str(path)},
                )
    return rows


def dumps_json(payload):
    """Deterministic, human readable JSON text with trailing newline."""
    text = json.dumps(
        payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=False
    )
    return text + "\n"


def canonical_sha256(payload):
    """Digest of the canonical form used by the upstream coverage report."""
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def file_sha256(path):
    digest = hashlib.sha256()
    with io.open(path, "rb") as handle:
        while True:
            chunk = handle.read(1 << 20)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def read_text(path, encoding="utf-8-sig"):
    with io.open(path, "r", encoding=encoding, newline="") as handle:
        return handle.read()


def read_bytes(path):
    with io.open(path, "rb") as handle:
        return handle.read()


def atomic_write_bytes(path, data):
    """Write bytes through a temporary sibling file and os.replace."""
    directory = os.path.dirname(os.path.abspath(path))
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    tmp = os.path.join(directory, ".tmp-" + uuid.uuid4().hex[:16])
    handle = io.open(tmp, "wb")
    try:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    finally:
        handle.close()
    os.replace(tmp, path)


def atomic_write_text(path, text, encoding="utf-8"):
    """Write text as UTF-8 without BOM and with LF newlines."""
    if isinstance(text, str):
        data = text.replace("\r\n", "\n").replace("\r", "\n").encode(encoding)
    else:
        data = text
    atomic_write_bytes(path, data)


def write_json(path, payload):
    atomic_write_text(path, dumps_json(payload))


def write_text(path, text):
    atomic_write_text(path, text)


def write_csv_bom(path, header, rows):
    """CSV is the only artefact written with a BOM so Excel reads Chinese."""
    parts = [",".join(_csv_cell(value) for value in header)]
    for row in rows:
        parts.append(",".join(_csv_cell(value) for value in row))
    text = "\r\n".join(parts) + "\r\n"
    atomic_write_text(path, text, encoding="utf-8-sig")


def _csv_cell(value):
    if value is None:
        return ""
    text = str(value)
    if any(ch in text for ch in (",", '"', "\r", "\n")):
        return '"' + text.replace('"', '""') + '"'
    return text


def ensure_directory(path):
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def join(*parts):
    return os.path.join(*parts)


def relpath(path, start):
    try:
        return os.path.relpath(path, start)
    except ValueError:
        return path


def guard_output_outside_input(output_dir, input_dirs):
    """Refuse to write inside any input directory."""
    out = os.path.abspath(output_dir)
    for source in input_dirs:
        if not source:
            continue
        src = os.path.abspath(source)
        if out == src:
            raise SkillError(
                "OUTPUT_INSIDE_SOURCE", "output directory equals an input directory", {"path": out}
            )
        prefix = src + os.sep
        if out.startswith(prefix):
            raise SkillError(
                "OUTPUT_INSIDE_SOURCE",
                "output directory is inside an input directory",
                {"path": out, "source": src},
            )
    return out


def guard_output_not_exists(output_dir):
    if os.path.exists(output_dir):
        raise SkillError(
            "OUTPUT_EXISTS", "output directory already exists: %s" % (output_dir,), {}
        )
    return output_dir


def safe_join(root, *parts):
    """Join under root and refuse traversal outside it."""
    candidate = root
    for part in parts:
        text = str(part)
        if not text:
            raise SkillError("UNSAFE_PATH", "empty path segment", {})
        if text in (".", ".."):
            raise SkillError("UNSAFE_PATH", "relative segment not allowed: %s" % (text,), {})
        if "\\" in text or "/" in text or ":" in text:
            raise SkillError("UNSAFE_PATH", "unsafe path segment: %s" % (text,), {})
        candidate = os.path.join(candidate, text)
    resolved = os.path.abspath(candidate)
    root_abs = os.path.abspath(root)
    if resolved != root_abs and not resolved.startswith(root_abs + os.sep):
        raise SkillError("UNSAFE_PATH", "path escapes root", {"path": resolved})
    return resolved


def is_writable(path):
    try:
        return os.access(path, os.W_OK)
    except OSError as exc:
        if exc.errno in (errno.EACCES, errno.EPERM):
            return False
        raise


def display_path(path):
    return str(path).replace("\\", "/")
