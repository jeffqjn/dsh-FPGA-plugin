# -*- coding: utf-8 -*-
"""High level editing helpers used by the plan and report content modules.

Every helper records one entry in the fill map so that a reviewer can trace each
written value back to its slot and source.
"""
import re

from .base import SkillError
from .docxlib import Docx, Paragraph, Row, Table, escape_text, fragment_text

COMMENT_OPEN = "/*"
COMMENT_CLOSE = "*/"
EXAMPLE_MARKERS = ("例如：", "示例：")
HEADING_STYLES = ("1", "2", "3", "4")

_PSTYLE_RE = re.compile(r"<w:pStyle\b[^>]*/>")
_NUM_PR_RE = re.compile(r"<w:numPr>.*?</w:numPr>", re.S)
_OUTLINE_RE = re.compile(r"<w:outlineLvl\b[^>]*/>")


def as_body_paragraph(paragraph):
    """Return a copy of ``paragraph`` that is guaranteed to be body text.

    Cloning a heading to create body lines would add chapters to the automatic
    multilevel numbering, so the paragraph style and outline level are dropped.
    """
    raw = paragraph.raw
    if paragraph.style in HEADING_STYLES or "<w:outlineLvl" in raw:
        raw = _PSTYLE_RE.sub("", raw)
        raw = _NUM_PR_RE.sub("", raw)
        raw = _OUTLINE_RE.sub("", raw)
    return Paragraph(paragraph.index, raw)


class Builder(object):
    def __init__(self, doc, gaps, context=None):
        self.doc = doc
        self.gaps = gaps
        self.context = context or {}
        self.fill_map = []
        self.warnings = []

    # -- bookkeeping -----------------------------------------------------
    def note(self, slot, source, status="filled", value=None):
        entry = {"slot": slot, "source": source, "status": status}
        if value is not None:
            entry["value"] = value
        self.fill_map.append(entry)

    def warn(self, code, detail):
        self.warnings.append({"code": code, "detail": detail})

    # -- locating --------------------------------------------------------
    def find(self, prefix, style=None, start=0, optional=False):
        try:
            return self.doc.find_paragraph(text_prefix=prefix, style=style, start=start)
        except SkillError:
            if optional:
                return None
            raise

    def find_exact(self, text, optional=False):
        try:
            return self.doc.find_paragraph(exact=text)
        except SkillError:
            if optional:
                return None
            raise

    def find_contains(self, needle, optional=False, start=0):
        for index in range(start, self.doc.block_count()):
            if self.doc.block_kind(index) != "p":
                continue
            para = self.doc.paragraph(index)
            if needle in para.text:
                return para
        if optional:
            return None
        raise SkillError(
            "TEMPLATE_ANCHOR_MISSING",
            "cannot locate paragraph containing: %s" % (needle,),
            {"needle": needle},
        )

    def table_after_contains(self, needle, optional=False):
        para = self.find_contains(needle, optional=optional)
        if para is None:
            return None, None
        try:
            return para, self.table_after(para)
        except SkillError:
            if optional:
                return para, None
            raise

    def table_after(self, paragraph):
        return self.doc.find_table_after(paragraph.index)

    def table_after_prefix(self, prefix, optional=False, style=None):
        para = self.find(prefix, style=style, optional=optional)
        if para is None:
            return None, None
        return para, self.table_after(para)

    # -- paragraphs ------------------------------------------------------
    def set_text(self, prefix, text, slot, source, style=None, optional=False):
        para = self.find(prefix, style=style, optional=optional)
        if para is None:
            self.note(slot, source, status="anchor-missing")
            return None
        return self.set_text_at(para, text, slot, source)

    def set_text_at(self, para, text, slot, source):
        clean = (text or "").replace("\t", " ").lstrip()
        self.doc.set_block(para.index, para.with_text(clean))
        self.note(slot, source, value=clean)
        return self.doc.paragraph(para.index)

    def set_label_value(self, label, value, slot, source, optional=False):
        """Rewrite a paragraph of the form ``标签：值``."""
        para = self.find(label, optional=optional)
        if para is None:
            self.note(slot, source, status="anchor-missing")
            return None
        text = label + "：" + (value or "")
        return self.set_text_at(para, text, slot, source)

    def delete(self, prefix, slot, source, style=None, optional=False):
        para = self.find(prefix, style=style, optional=optional)
        if para is None:
            self.note(slot, source, status="anchor-missing")
            return False
        self.doc.delete_block(para.index)
        self.note(slot, source, status="deleted")
        return True

    def delete_exact(self, text, slot, source, optional=False):
        para = self.find_exact(text, optional=optional)
        if para is None:
            self.note(slot, source, status="anchor-missing")
            return False
        self.doc.delete_block(para.index)
        self.note(slot, source, status="deleted")
        return True

    def replace_following(self, prefix, lines, slot, source, keep=0, style=None):
        """Replace the paragraphs after ``prefix`` with ``lines``.

        ``keep`` leading paragraphs after the anchor are left untouched.
        """
        para = self.find(prefix, style=style)
        start = para.index + 1 + keep
        existing = []
        index = start
        while index < self.doc.block_count() and self.doc.block_kind(index) == "p":
            existing.append(index)
            index += 1
        self._write_lines(existing, lines, slot, source)
        return len(existing), len(lines)

    def replace_from(self, prefix, lines, slot, source, keep=0):
        """Replace the anchor itself plus the paragraphs that follow it."""
        para = self.find(prefix)
        start = para.index + keep
        existing = []
        index = start
        while index < self.doc.block_count() and self.doc.block_kind(index) == "p":
            existing.append(index)
            index += 1
        self._write_lines(existing, lines, slot, source)
        return len(existing), len(lines)

    def _write_lines(self, indexes, lines, slot, source):
        lines = [line for line in (lines or []) if line is not None]
        if not indexes:
            self.note(slot, source, status="no-target")
            return
        if len(lines) <= len(indexes):
            for offset in range(len(lines)):
                index = indexes[offset]
                current = self.doc.paragraph(index)
                if current.style in HEADING_STYLES:
                    # rewriting a heading in place would keep it in the outline and
                    # shift the chapter numbering, so demote it to body text first
                    current = as_body_paragraph(current)
                self.doc.set_block(index, current.with_text(lines[offset]))
            # surplus paragraphs must disappear, otherwise blank headings stay
            # behind and keep consuming automatic chapter numbers
            removable = []
            for index in indexes[len(lines):]:
                raw = self.doc.paragraph(index).raw
                if "<w:sectPr" in raw:
                    self.doc.set_block(index, self.doc.paragraph(index).with_text(""))
                else:
                    removable.append(index)
            if removable:
                self.doc.delete_blocks(removable)
        else:
            for offset, index in enumerate(indexes):
                current = self.doc.paragraph(index)
                if current.style in HEADING_STYLES:
                    current = as_body_paragraph(current)
                self.doc.set_block(index, current.with_text(lines[offset]))
            extra = len(lines) - len(indexes)
            template = self.doc.paragraph(indexes[-1])
            payload = [as_body_paragraph(template).with_text("")] * extra
            self.doc.insert_after(indexes[-1], payload)
            for offset in range(extra):
                target = indexes[-1] + 1 + offset
                current = self.doc.paragraph(target)
                self.doc.set_block(target, current.with_text(lines[len(indexes) + offset]))
        self.note(slot, source, value=len(lines))

    def append_lines(self, prefix, lines, slot, source):
        """Insert new body paragraphs after the anchor."""
        para = self.find(prefix)
        clone = as_body_paragraph(para).with_text("")
        payload = [clone] * len(lines)
        self.doc.insert_after(para.index, payload)
        for offset, line in enumerate(lines):
            target = para.index + 1 + offset
            current = self.doc.paragraph(target)
            self.doc.set_block(target, current.with_text(line))
        self.note(slot, source, value=len(lines))

    def replace_region(self, start_prefix, end_prefix, lines, slot, source):
        """Replace every paragraph strictly between two anchors."""
        start = self.find(start_prefix)
        end = self.find(end_prefix, start=start.index + 1)
        targets = []
        index = start.index + 1
        while index < end.index:
            if self.doc.block_kind(index) == "p":
                targets.append(index)
            index += 1
        if not targets:
            if not lines:
                self.note(slot, source, value=0)
                return 0, 0
            self.append_lines(start_prefix, lines, slot, source)
            return 0, len(lines)
        self._write_lines(targets, lines, slot, source)
        return len(targets), len(lines)

    def delete_table_after(self, prefix, slot, source, optional=False):
        para, table = self.table_after_prefix(prefix, optional=optional)
        if table is None:
            self.note(slot, source, status="anchor-missing")
            return None
        self.doc.delete_block(table.index)
        self.note(slot, source, status="deleted")
        return table

    def detach_table(self, table):
        """Return a table's raw markup for reuse as a prototype before deletion."""
        return table.raw

    def insert_table_after(self, anchor_index, table_raw, slot, source):
        self.doc.insert_after(anchor_index, [table_raw])
        self.note(slot, source, value="table")

    def set_cells_in_rows(self, table, column, mapping, slot, source):
        """Write one column in place, preserving vertical merges."""
        rebuilt = []
        for row_index, row in enumerate(table.rows()):
            if row_index in mapping:
                rebuilt.append(row.set_cell_text(column, mapping[row_index]).raw)
            else:
                rebuilt.append(row.raw)
        self.doc.set_block(table.index, table.with_rows(rebuilt))
        self.note(slot, source, value={"column": column, "rows": len(mapping)})
        return self.table_at(table.index)

    # -- tables ----------------------------------------------------------
    def fill_table(self, table, rows, slot, source, header_rows=1, tail_rows=0, template_row=None):
        """Rebuild a table's data rows from ``rows`` (list of cell lists)."""
        spans = table._row_spans()
        total = len(spans)
        if total < header_rows + tail_rows:
            raise SkillError(
                "DOCX_TABLE_SHAPE",
                "table has %d rows, need at least %d" % (total, header_rows + tail_rows),
                {"slot": slot},
            )
        raw_rows = [table.raw[start:end] for start, end in spans]
        data_start = header_rows
        data_end = total - tail_rows
        existing = data_end - data_start
        source_row_index = template_row
        if source_row_index is None:
            source_row_index = data_start if existing > 0 else header_rows
        if source_row_index >= total:
            source_row_index = total - 1
        template = Row(raw_rows[source_row_index])
        manual_seq = bool(re.match(r"^\d+\.?$", (template.cell(0).text or "").strip()))

        new_rows = []
        for offset, cells in enumerate(rows):
            row_cells = list(cells) if cells else [""]
            if manual_seq and row_cells and row_cells[0] in (None, ""):
                row_cells[0] = str(offset + 1)
            new_rows.append(self._build_row(template, row_cells).raw)

        rebuilt = raw_rows[:data_start] + new_rows + raw_rows[data_end:]
        self.doc.set_block(table.index, table.with_rows(rebuilt))
        self.note(slot, source, value={"rows": len(rows)})
        return self.table_at(table.index)

    def _build_row(self, template, cells):
        """Write every cell of one row in a single pass over its markup."""
        return template.set_cells(cells)

    def table_at(self, index):
        return self.doc.table(index)

    def set_row_cells(self, table, row_index, cells, slot, source):
        row = table.row(row_index)
        row = row.set_cells(cells)
        self.doc.set_block(table.index, table.replace_row(row_index, row))
        self.note(slot, source, value=cells)

    def clear_table_body(self, table, slot, source, header_rows=1, tail_rows=0):
        return self.fill_table(table, [], slot, source, header_rows=header_rows, tail_rows=tail_rows)

    # -- generic cleanup --------------------------------------------------
    def strip_comments(self):
        """Delete pure ``/* ... */`` paragraphs and inline comment spans."""
        deleted = 0
        rewritten = 0
        index = 0
        while index < self.doc.block_count():
            if self.doc.block_kind(index) != "p":
                index += 1
                continue
            para = self.doc.paragraph(index)
            text = para.text
            if COMMENT_OPEN not in text:
                index += 1
                continue
            stripped = text.strip()
            if stripped.startswith(COMMENT_OPEN):
                span = [index]
                cursor = index
                if COMMENT_CLOSE not in stripped:
                    cursor += 1
                    while cursor < self.doc.block_count():
                        if self.doc.block_kind(cursor) != "p":
                            break
                        span.append(cursor)
                        if COMMENT_CLOSE in self.doc.paragraph(cursor).text:
                            break
                        cursor += 1
                self.doc.delete_blocks(span)
                deleted += len(span)
                continue
            cut = text.find(COMMENT_OPEN)
            cleaned = text[:cut].rstrip()
            if cleaned:
                self.doc.set_block(index, para.with_text(cleaned))
                rewritten += 1
            else:
                self.doc.delete_block(index)
                deleted += 1
                continue
            index += 1
        self.note("cleanup.comments", "template", value={"deleted": deleted, "trimmed": rewritten})
        return deleted, rewritten

    def strip_example_markers(self, keep_texts=None):
        keep_texts = keep_texts or ()
        targets = []
        for marker in EXAMPLE_MARKERS:
            for para in self.doc.find_paragraphs(text_prefix=marker):
                if para.text.strip() in keep_texts:
                    continue
                targets.append(para.index)
        self.doc.delete_blocks(targets)
        self.note("cleanup.example_markers", "template", value=len(targets))
        return len(targets)

    def substitute(self, pairs):
        """Apply ordered literal substitutions to every remaining paragraph."""
        changed = 0
        for para in self.doc.paragraphs():
            text = para.text
            new_text = text
            for pattern, replacement in pairs:
                if pattern in new_text:
                    new_text = new_text.replace(pattern, replacement)
            if new_text != text:
                self.doc.set_block(para.index, para.with_text(new_text))
                changed += 1
        self.note("cleanup.substitutions", "mapping", value=changed)
        return changed

    def substitute_in_tables(self, pairs):
        changed = 0
        for table in self.doc.tables():
            rebuilt = []
            touched = False
            for row in table.rows():
                cells = []
                for cell in row.cells():
                    text = cell.text
                    new_text = text
                    for pattern, replacement in pairs:
                        if pattern in new_text:
                            new_text = new_text.replace(pattern, replacement)
                    if new_text != text:
                        cells.append(cell.with_text(new_text))
                        touched = True
                    else:
                        cells.append(cell.raw)
                rebuilt.append(row.with_cells(cells).raw)
            if touched:
                self.doc.set_block(table.index, table.with_rows(rebuilt))
                changed += 1
        self.note("cleanup.table_substitutions", "mapping", value=changed)
        return changed

    # -- inspection helpers ----------------------------------------------
    def paragraph_texts(self):
        return [para.text for para in self.doc.paragraphs()]

    def find_residual(self, patterns):
        """One pass over the document, using the cached text accessors."""
        hits = []
        doc = self.doc
        for index in range(doc.block_count()):
            kind = doc.block_kind(index)
            if kind == "p":
                text = doc.paragraph_texts(index)
                for pattern in patterns:
                    if pattern in text:
                        hits.append({"block": index, "pattern": pattern, "text": text[:120]})
            elif kind == "tbl":
                for row_index, row in enumerate(doc.table_texts(index)):
                    for cell_index, text in enumerate(row):
                        for pattern in patterns:
                            if pattern in text:
                                hits.append(
                                    {
                                        "block": index,
                                        "table": True,
                                        "row": row_index,
                                        "cell": cell_index,
                                        "pattern": pattern,
                                        "text": text[:120],
                                    }
                                )
        return hits
