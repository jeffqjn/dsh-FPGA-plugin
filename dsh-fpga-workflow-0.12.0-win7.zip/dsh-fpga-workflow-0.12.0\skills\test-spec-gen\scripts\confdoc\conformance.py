# -*- coding: utf-8 -*-
"""产保 / 技术要素 self-conformance engine.

Rules live in ``rules/conformance_rules.json`` so that a project can tailor the
checklist without touching code.  Each rule yields one of four verdicts:

``符合`` / ``不符合`` / ``不适用`` / ``待实测``

Verdict order is short-circuiting (see references/mapping-rules.md):
  1. the checklist item does not apply to this project      -> 不适用
  2. the item needs measured data and none is bound          -> 待实测
  3. the assertion holds                                     -> 符合
  4. otherwise                                               -> 不符合
"""
import os

from .base import SkillError, read_json

VERDICT_OK = "符合"
VERDICT_BAD = "不符合"
VERDICT_NA = "不适用"
VERDICT_PENDING = "待实测"

RULES_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "rules", "conformance_rules.json")


def load_rules(path=None):
    target = path or RULES_PATH
    if not os.path.isfile(target):
        raise SkillError("RULES_MISSING", "conformance rules not found", {"path": target})
    return read_json(target)


class Verdict(object):
    def __init__(self, rule, verdict, detail="", basis=""):
        self.rule = rule
        self.verdict = verdict
        self.detail = detail
        self.basis = basis

    @property
    def id(self):
        return self.rule.get("id")

    @property
    def row(self):
        return int(self.rule.get("row") or 0)

    @property
    def item(self):
        return self.rule.get("item") or ""

    @property
    def category(self):
        return self.rule.get("category") or ""

    @property
    def chapter(self):
        return self.rule.get("chapter") or "—"

    def as_dict(self):
        return {
            "id": self.id,
            "row": self.row,
            "category": self.category,
            "item": self.item,
            "chapter": self.chapter,
            "verdict": self.verdict,
            "basis": self.basis,
            "detail": self.detail,
        }


def evaluate(rules, ctx, doc, doc_key):
    """Evaluate every rule for ``doc_key`` ('plan' or 'report').

    A rule may set ``doc_target: plan`` when the checklist item is about the
    confirmation test plan; that document is resolved from ``ctx['plan_doc']``.
    """
    key = "plan_items" if doc_key == "plan" else "report_items"
    verdicts = []
    for rule in rules.get(key) or []:
        target = rule.get("doc_target") or doc_key
        target_doc = doc
        if target != doc_key:
            target_doc = ctx.get(target + "_doc")
            if target_doc is None:
                raise SkillError(
                    "PLAN_REQUIRED_FOR_CONFORMANCE",
                    "checklist item %s needs the %s document" % (rule.get("id"), target),
                    {"rule": rule.get("id"), "target": target},
                )
        verdicts.append(_evaluate_one(rule, ctx, target_doc))
    return verdicts


def _evaluate_one(rule, ctx, doc):
    kind = rule.get("kind")
    params = rule.get("params") or {}
    basis = rule.get("basis") or ""
    if kind == "not_applicable":
        return Verdict(rule, VERDICT_NA, params.get("reason") or "模板占位", basis)
    if kind == "results_available":
        if not ctx["spec"].has_execution_results():
            return Verdict(rule, VERDICT_PENDING, "本版本未绑定执行记录，结论待实测", basis)
        return Verdict(rule, VERDICT_OK, "已绑定执行记录", basis)

    checker = _CHECKERS.get(kind)
    if checker is None:
        raise SkillError("RULE_KIND_UNKNOWN", "unknown rule kind: %s" % (kind,), {"rule": rule.get("id")})
    ok, detail = checker(params, ctx, doc)
    return Verdict(rule, VERDICT_OK if ok else VERDICT_BAD, detail, basis)


# ---------------------------------------------------------------------------
# predicates
# ---------------------------------------------------------------------------
def _check_doc_section(params, ctx, doc):
    heading = params.get("heading") or ""
    min_chars = int(params.get("min_chars") or 1)
    found = None
    for index in range(doc.block_count()):
        if doc.block_kind(index) != "p":
            continue
        para = doc.paragraph(index)
        if heading and heading in para.text:
            found = index
            break
    if found is None:
        return False, "未找到章节：%s" % (heading,)
    total = 0
    index = found + 1
    while index < doc.block_count():
        kind = doc.block_kind(index)
        if kind == "p":
            para = doc.paragraph(index)
            if para.style in ("1", "2", "3", "4") and para.text.strip():
                break
            total += len(para.text.strip())
        elif kind == "tbl":
            table = doc.table(index)
            for row in table.rows():
                for text in row.texts():
                    total += len(text.strip())
        index += 1
    if total >= min_chars:
        return True, "章节“%s”正文 %d 字" % (heading, total)
    return False, "章节“%s”正文仅 %d 字（要求 ≥%d）" % (heading, total, min_chars)


def _find_table_by_caption(doc, caption):
    if not caption:
        return None
    for index in range(doc.block_count()):
        if doc.block_kind(index) != "p":
            continue
        if caption in doc.paragraph(index).text:
            for cursor in range(index + 1, doc.block_count()):
                if doc.block_kind(cursor) == "tbl":
                    return doc.table(cursor)
    return None


PLACEHOLDER_PHRASES = ("待填", "任务书未规定", "任务书未涉及", "任务书存在冲突，待确认", "—", "-", "")


def _is_real_text(text):
    return text.strip() not in PLACEHOLDER_PHRASES


def _check_doc_table(params, ctx, doc):
    caption = params.get("caption") or ""
    min_rows = int(params.get("min_rows") or 1)
    require_column = params.get("require_column")
    table = _find_table_by_caption(doc, caption)
    if table is None:
        return False, "未找到表格：%s" % (caption,)
    filled = 0
    placeholder_rows = 0
    for row_index, row in enumerate(table.rows()):
        if row_index == 0:
            continue
        texts = row.texts()
        if require_column is not None:
            if len(texts) > require_column and _is_real_text(texts[require_column]):
                filled += 1
            elif any(_is_real_text(text) for text in texts):
                placeholder_rows += 1
            continue
        real = [text for text in texts if _is_real_text(text)]
        if len(real) >= 2:
            filled += 1
        elif real:
            placeholder_rows += 1
    if filled >= min_rows:
        return True, "表格“%s”有效数据行 %d 行" % (caption, filled)
    detail = "表格“%s”有效数据行 %d 行（要求 ≥%d）" % (caption, filled, min_rows)
    if placeholder_rows:
        detail += "，另有 %d 行为占位内容" % (placeholder_rows,)
    return False, detail


def _matching_items(spec, feip, params):
    scenarios = params.get("scenarios") or []
    categories = params.get("categories") or []
    methods = params.get("methods") or []
    keywords = params.get("keywords") or []
    matched = []
    for item in spec.items:
        hit = False
        if scenarios:
            for scenario in spec.scenario_types(item):
                if scenario in scenarios:
                    hit = True
                    break
        if not hit and methods:
            if item["method"] in methods:
                hit = True
        if not hit and categories:
            for uid in item["requirement_uids"]:
                if feip.category(uid) in categories:
                    hit = True
                    break
        if hit and keywords:
            blob = item["title"] + "\n" + "\n".join(item["steps"])
            for uid in item["requirement_uids"]:
                blob += "\n" + feip.statement(uid)
            if not any(keyword in blob for keyword in keywords):
                hit = False
        if hit:
            matched.append(item)
    return matched


def _check_cases_cover(params, ctx, doc):
    matched = _matching_items(ctx["spec"], ctx["feip"], params)
    want = int(params.get("min") or 1)
    if len(matched) >= want:
        return True, "命中用例 %d 项（%s）" % (len(matched), "、".join(item["id"] for item in matched[:6]))
    return False, "命中用例 %d 项（要求 ≥%d）" % (len(matched), want)


def _check_feip_collection(params, ctx, doc):
    feip = ctx["feip"]
    collection = params.get("collection") or ""
    want = int(params.get("min") or 1)
    values = feip.collection(collection)
    if len(values) >= want:
        return True, "FEIP analysis.%s 共 %d 条" % (collection, len(values))
    fallback = params.get("fallback_categories") or []
    for category in fallback:
        uids = feip.by_category(category)
        if uids:
            return True, "FEIP analysis.%s 为空，回退到 %s 类需求 %d 条" % (collection, category, len(uids))
    return False, "FEIP analysis.%s 为空，且无回退依据" % (collection,)


def _check_upstream_landed(params, ctx, doc):
    spec = ctx["spec"]
    requirements = ctx["rtm_requirements"]
    if not requirements:
        return False, "无可核对的需求清单"
    landed = 0
    for uid in requirements:
        if spec.rtm_linked_ids(uid):
            landed += 1
    ratio = float(landed) / float(len(requirements))
    want = float(params.get("min_ratio") or 1.0)
    detail = "已落实 %d/%d 项（%.2f%%）" % (landed, len(requirements), ratio * 100.0)
    return ratio >= want - 1e-9, detail


def _check_feip_field_ratio(params, ctx, doc):
    """Ratio of a nested fact field that is actually known (not unknown/absent)."""
    collection = params.get("collection") or ""
    field = params.get("field") or ""
    want = float(params.get("min_ratio") or 1.0)
    values = ctx["feip"].collection(collection)
    if not values:
        return False, "FEIP analysis.%s 为空" % (collection,)
    known = 0
    total = 0
    for item in values:
        total += 1
        node = item.get(field)
        if isinstance(node, dict):
            if node.get("status") == "present" and node.get("value") not in (None, ""):
                known += 1
        elif isinstance(node, str):
            if node.strip() and node.strip() not in ("unknown", "absent", "conflict"):
                known += 1
        elif node not in (None, ""):
            known += 1
    ratio = float(known) / float(total) if total else 0.0
    detail = "analysis.%s[].%s 已知 %d/%d（%.0f%%）" % (collection, field, known, total, ratio * 100.0)
    return ratio >= want - 1e-9, detail


_CHECKERS = {
    "doc_section": _check_doc_section,
    "doc_table": _check_doc_table,
    "cases_cover": _check_cases_cover,
    "feip_collection": _check_feip_collection,
    "feip_field_ratio": _check_feip_field_ratio,
    "upstream_landed": _check_upstream_landed,
}


# ---------------------------------------------------------------------------
# applying and reporting
# ---------------------------------------------------------------------------
def apply_to_table(doc, caption_needle, column, verdicts, chapter_column=None, normalise_ellipsis=True):
    """Write verdicts (and optionally the 对应章节 reference) into the checklist."""
    from .docxlib import Table

    target = None
    for index in range(doc.block_count()):
        if doc.block_kind(index) != "p":
            continue
        if caption_needle in doc.paragraph(index).text:
            for cursor in range(index + 1, doc.block_count()):
                if doc.block_kind(cursor) == "tbl":
                    target = cursor
                    break
        if target is not None:
            break
    if target is None:
        raise SkillError(
            "TEMPLATE_ANCHOR_MISSING", "cannot locate table after %s" % (caption_needle,), {}
        )
    table = doc.table(target)
    by_row = {}
    for verdict in verdicts:
        by_row[verdict.row] = verdict
    rebuilt = []
    for row_index, row in enumerate(table.rows()):
        if row_index in by_row:
            verdict = by_row[row_index]
            row = row.set_cell_text(column, verdict.verdict)
            if chapter_column is not None and chapter_column < row.cell_count():
                row = row.set_cell_text(chapter_column, verdict.chapter)
        if normalise_ellipsis:
            cells = [cell.raw for cell in row.cells()]
            changed = False
            for cell_index, cell in enumerate(row.cells()):
                if cell.text.strip() in ("…", "...", "…."):
                    cells[cell_index] = cell.with_text("—")
                    changed = True
            if changed:
                row = row.with_cells(cells)
        rebuilt.append(row.raw)
    doc.set_block(target, table.with_rows(rebuilt))
    return doc.table(target)


def apply_readiness(doc, caption_needle, rules, ctx, result_column=4, note_column=7, header_rows=3):
    """Fill the readiness checklist's 检查结果 by analysis instead of blank boxes.

    Each row is matched against ``readiness_rules``; the basis goes into the last
    column so a reviewer can see why a row was judged 符合 or left 待现场确认.
    """
    target = None
    for index in range(doc.block_count()):
        if doc.block_kind(index) != "p":
            continue
        if caption_needle in doc.paragraph(index).text:
            for cursor in range(index + 1, doc.block_count()):
                if doc.block_kind(cursor) == "tbl":
                    target = cursor
                    break
        if target is not None:
            break
    if target is None:
        raise SkillError(
            "TEMPLATE_ANCHOR_MISSING", "cannot locate table after %s" % (caption_needle,), {}
        )
    table = doc.table(target)
    results = []
    rebuilt = []
    for row_index, row in enumerate(table.rows()):
        if row_index < header_rows or row_index == 0:
            rebuilt.append(row.raw)
            continue
        texts = [text.replace("\t", "") for text in row.texts()]
        if len(texts) <= result_column:
            rebuilt.append(row.raw)
            continue
        item_text = texts[1] if len(texts) > 1 else ""
        content_text = texts[2] if len(texts) > 2 else ""
        matched = _match_readiness(rules, item_text, content_text)
        if matched is None:
            rebuilt.append(row.raw)
            continue
        result = matched.get("result") or "待现场确认"
        note = _format_note(matched.get("note") or "", ctx)
        row = row.set_cell_text(result_column, result)
        if note_column < row.cell_count() and not texts[note_column].strip():
            row = row.set_cell_text(note_column, note)
        results.append(
            {
                "row": row_index,
                "item": item_text,
                "content": content_text,
                "result": result,
                "note": note,
            }
        )
        rebuilt.append(row.raw)
    doc.set_block(target, table.with_rows(rebuilt))
    return results


def _match_readiness(rules, item_text, content_text):
    haystack = (item_text or "") + " " + (content_text or "")
    for rule in rules:
        needle = rule.get("match") or ""
        if needle and needle in haystack:
            return rule
    return None


def _format_note(template, ctx):
    try:
        return template.format(
            basis=ctx.get("basis_title") or "任务书",
            kind="确认测试计划" if ctx.get("document_kind") == "plan" else "确认测试报告",
            chip=ctx.get("chip_model") or "见 1.1 配置项基本信息",
        )
    except (KeyError, IndexError, ValueError):
        return template


def summarise(verdicts):
    summary = {VERDICT_OK: 0, VERDICT_BAD: 0, VERDICT_NA: 0, VERDICT_PENDING: 0}
    for verdict in verdicts:
        summary[verdict.verdict] = summary.get(verdict.verdict, 0) + 1
    return summary


def by_item(verdicts):
    groups = {}
    for verdict in verdicts:
        groups.setdefault(verdict.item, []).append(verdict)
    return groups


def rollup_rows(verdicts):
    """Aggregate verdicts into (要素类别, 要素名称) counts for the summary table."""
    rows = {}
    order = []
    for verdict in verdicts:
        key = (verdict.category, verdict.item)
        if key not in rows:
            rows[key] = {VERDICT_OK: 0, VERDICT_BAD: 0, VERDICT_NA: 0, VERDICT_PENDING: 0}
            order.append(key)
        rows[key][verdict.verdict] = rows[key].get(verdict.verdict, 0) + 1
    result = []
    for key in order:
        counts = rows[key]
        total = sum(counts.values())
        result.append(
            {
                "category": key[0],
                "item": key[1],
                "checks": total,
                "satisfied": counts[VERDICT_OK],
                "unsatisfied": counts[VERDICT_BAD] + counts[VERDICT_PENDING],
                "not_applicable": counts[VERDICT_NA],
                "pending": counts[VERDICT_PENDING],
            }
        )
    return result


def render_markdown(verdicts, title="产保要素自检表"):
    summary = summarise(verdicts)
    lines = ["# %s" % (title,), ""]
    lines.append(
        "符合 %d 项 / 不符合 %d 项 / 不适用 %d 项 / 待实测 %d 项。"
        % (summary[VERDICT_OK], summary[VERDICT_BAD], summary[VERDICT_NA], summary[VERDICT_PENDING])
    )
    lines.append("")
    lines.append("| 编号 | 要素类别 | 检查项 | 对应章节 | 判定 | 依据 | 说明 |")
    lines.append("|---|---|---|---|---|---|---|")
    for verdict in verdicts:
        lines.append(
            "| %s | %s | %s | %s | %s | %s | %s |"
            % (
                verdict.id,
                verdict.category,
                verdict.item,
                verdict.chapter,
                verdict.verdict,
                verdict.basis.replace("|", "\\|"),
                (verdict.detail or "—").replace("|", "\\|"),
            )
        )
    return "\n".join(lines) + "\n"
