# -*- coding: utf-8 -*-
"""Derived values that ``test_specification.json`` does not carry.

The specification has no chapter, no case type, no test project and no
priority.  Everything here is derived from the FEIP category plus the method and
scenario vocabulary, using the fixed order documented in references/mapping-rules.md.
"""
import re

CATEGORY_ORDER = (
    "loading",
    "language",
    "tool",
    "ip",
    "function",
    "performance",
    "protocol",
    "interface",
    "reliability",
    "verification",
)

CATEGORY_LABELS = {
    "loading": "加载要求",
    "language": "编程语言",
    "tool": "开发工具和环境",
    "ip": "IP 核使用",
    "function": "功能需求",
    "performance": "性能要求",
    "protocol": "协议与数据格式",
    "interface": "FPGA 产品接口",
    "reliability": "可靠性与安全性",
    "verification": "测试验证要求",
}

CATEGORY_CODES = {
    "loading": "JZ",
    "language": "YY",
    "tool": "GJ",
    "ip": "IP",
    "function": "GN",
    "performance": "XN",
    "protocol": "XY",
    "interface": "JK",
    "reliability": "KK",
    "verification": "YZ",
}

METHOD_LABELS = {
    "board_test": "板级测试",
    "system_test": "系统测试",
    "inspection": "检查",
    "analysis": "分析",
    "timing_analysis": "时序分析",
    "review": "评审",
}

LEVEL_LABELS = {
    "board": "板级",
    "system": "系统级",
    "fpga": "FPGA 级",
}

SCENARIO_LABELS = {
    "normal": "正常",
    "boundary": "边界",
    "abnormal": "异常",
    "stress": "强度",
    "recovery": "恢复",
}

ROBUST_SCENARIOS = ("boundary", "abnormal", "stress", "recovery")

STAGE_PREFIX = "QR"

# Some upstream requirement statements degraded into table-cell fragments; they
# must never be printed as prose.
_DEGRADED_RE = re.compile(r"col=\d+\s*;\s*row_span=")
_DEGRADED_TOKEN_RE = re.compile(r"col=\d+")


def is_degraded_statement(text):
    if not text:
        return False
    if _DEGRADED_RE.search(text):
        return True
    return len(_DEGRADED_TOKEN_RE.findall(text)) >= 3


def clean_statement(text):
    """Return statement text, or an empty string when it is a degraded fragment."""
    if not text:
        return ""
    if is_degraded_statement(text):
        return ""
    return text.strip()


def method_label(method):
    return METHOD_LABELS.get(method, method or "")


def level_label(level):
    return LEVEL_LABELS.get(level, level or "")


def scenario_label(scenario):
    return SCENARIO_LABELS.get(scenario, scenario or "")


def category_label(category):
    return CATEGORY_LABELS.get(category, category or "其他")


def category_rank(category):
    if category in CATEGORY_ORDER:
        return CATEGORY_ORDER.index(category)
    return len(CATEGORY_ORDER)


class Project(object):
    """One test project: the grouping unit used by the plan's chapter 7.4."""

    def __init__(self, category):
        self.category = category
        self.label = category_label(category)
        self.code = CATEGORY_CODES.get(category, "QT")
        self.serial = 0
        self.items = []
        self.ident = ""

    def assign(self, serial):
        self.serial = serial
        self.ident = "%s-%s-%03d" % (STAGE_PREFIX, self.code, serial)

    @property
    def count(self):
        return len(self.items)

    def case_ids(self):
        return [item["id"] for item in self.items]


def project_of_item(item, feip):
    for uid in item["requirement_uids"]:
        category = feip.category(uid)
        if category:
            return category
    return "verification"


def group_items(spec, feip):
    """Group specification items into test projects, ordered by category."""
    buckets = {}
    for item in spec.items:
        category = project_of_item(item, feip)
        buckets.setdefault(category, []).append(item)
    projects = []
    serial = 0
    for category in sorted(buckets.keys(), key=category_rank):
        project = Project(category)
        serial += 1
        project.assign(serial)
        project.items = buckets[category]
        projects.append(project)
    return projects


def project_items(projects, category):
    for project in projects:
        if project.category == category:
            return project
    return None


def statistics(projects):
    total = 0
    for project in projects:
        total += project.count
    return {"projects": len(projects), "total": total}


def functional_requirement_ids(feip):
    return feip.by_category("function")


def performance_requirement_ids(feip):
    return feip.by_category("performance")


def interface_requirement_ids(feip):
    return feip.by_category("interface")


def protocol_requirement_ids(feip):
    return feip.by_category("protocol")


def reliability_requirement_ids(feip):
    return feip.by_category("reliability")


def test_point_index(spec, feip):
    """Map test point uid -> list of specification item ids covering it."""
    index = {}
    for point in feip.test_points():
        point_uid = point.get("uid")
        covered = []
        for requirement_uid in point.get("requirement_refs") or []:
            for item in spec.items_of_requirement(requirement_uid):
                if item["id"] not in covered:
                    covered.append(item["id"])
        if point_uid:
            index[point_uid] = covered
    return index


def item_test_points(item, feip):
    """Test point ids reached through the plan's obligations."""
    found = []
    for obligation_id in item["obligation_ids"]:
        obligation = feip.obligation(obligation_id)
        if obligation is None:
            continue
        for point_ref in obligation.get("test_point_refs") or []:
            if point_ref not in found:
                found.append(point_ref)
    return found


def robustness_mark(spec, item):
    return "■" if spec.is_robust(item) else "□"


def requirement_display(feip, requirement_uid):
    return feip.normalized_id(requirement_uid)


def requirement_title(feip, requirement_uid):
    return feip.title(requirement_uid)


def join_ids(values, separator="、"):
    return separator.join(str(value) for value in values if value)


def scenario_summary(spec, item):
    labels = []
    for scenario in spec.scenario_types(item):
        labels.append(scenario_label(scenario))
    if not labels:
        return ""
    return "、".join(labels)


def type_label(spec, item):
    """Template's 测试类型 column: method label plus scenario qualifiers."""
    base = method_label(item["method"])
    scenarios = [scenario_label(s) for s in spec.scenario_types(item) if s != "normal"]
    if not scenarios:
        return base
    return base + "、" + "、".join(scenarios)


def pass_criterion_text(spec, item):
    texts = []
    for entry in item["coverage"]:
        criterion = entry.get("pass_criterion")
        if criterion and criterion not in texts:
            texts.append(criterion)
    return "\n".join(texts)


def expected_result_text(spec, item):
    texts = []
    for entry in item["coverage"]:
        value = entry.get("expected_result")
        if value and value not in texts:
            texts.append(value)
    return "\n".join(texts)


def numbered_steps(steps):
    lines = []
    for index, step in enumerate(steps):
        lines.append("%d、%s" % (index + 1, step))
    return "\n".join(lines)


def clamp(text, limit):
    if text is None:
        return ""
    text = str(text)
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def test_point_ident(point):
    """Stable test point id, matching the 测试要点 column of the case tables.

    ``source_id`` is only the taskbook's ordinal ("1".."20") and collides with the
    checklist's own 序号 column, so the uid suffix (``tblA-1``) is used instead.
    """
    uid = point.get("uid") or ""
    if ":" in uid:
        return uid.split(":")[-1]
    return point.get("source_id") or uid


_ATOMIC_ANY_RE = re.compile(r"\s*——\s*原子义务\s*\d+\s*")


def clean_title(text):
    """Drop the upstream "——原子义务N" marker wherever it appears.

    ``原子义务`` is upstream bookkeeping, not product wording; it survives even
    when followed by a parenthetical such as ``（板级测试）``, so the marker is
    stripped in the middle of the string too.
    """
    if not text:
        return ""
    raw = str(text).strip()
    cleaned = _ATOMIC_ANY_RE.sub("", raw)
    cleaned = cleaned.replace("————", "——").strip()
    cleaned = re.sub(r"^——\s*", "", cleaned).strip()
    cleaned = re.sub(r"——\s*$", "", cleaned).strip()
    return cleaned or raw


def unique_titles(titles):
    """Make repeated titles unique by appending （1）（2）… only where needed."""
    counts = {}
    for title in titles:
        counts[title] = counts.get(title, 0) + 1
    seen = {}
    out = []
    for title in titles:
        if counts.get(title, 0) <= 1:
            out.append(title)
            continue
        seen[title] = seen.get(title, 0) + 1
        out.append("%s（%d）" % (title, seen[title]))
    return out


EQUIPMENT_KEYWORDS = (
    "地检设备",
    "地面检测设备",
    "测试计算机",
    "控制计算机",
    "示波器",
    "逻辑分析仪",
    "万用表",
    "电源",
    "误码仪",
    "频谱仪",
    "信号源",
)


def equipment_from_setups(spec):
    """Equipment names referenced by the specification's setup text, in order."""
    blob = "\n".join(item["setup"] for item in spec.items)
    found = []
    for keyword in EQUIPMENT_KEYWORDS:
        if keyword in blob and keyword not in found:
            found.append(keyword)
    return found


def require_ids_with_prefix(feip, category, substring=None):
    result = []
    for uid in feip.by_category(category):
        if substring is None or substring in feip.normalized_id(uid) or substring in feip.title(uid):
            result.append(uid)
    return result
