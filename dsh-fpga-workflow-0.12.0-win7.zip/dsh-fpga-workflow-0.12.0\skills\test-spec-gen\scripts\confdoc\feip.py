# -*- coding: utf-8 -*-
"""FEIP package reader and fact accessor.

A FEIP fact is an envelope ``{status, value, reason, evidence_refs}``.  Every
read goes through :class:`Fact` so that a missing value is never mistaken for an
empty string: ``status`` values are ``present``/``unknown``/``conflict``/``absent``.
"""
import io
import os

from .base import SkillError, read_json

PRESENT = "present"
UNKNOWN = "unknown"
CONFLICT = "conflict"
ABSENT = "absent"


class Fact(object):
    __slots__ = ("value", "status", "reason", "evidence_refs", "text", "raw")

    def __init__(self, value=None, status=ABSENT, reason=None, evidence_refs=None, text=None, raw=None):
        self.value = value
        self.status = status
        self.reason = reason
        self.evidence_refs = list(evidence_refs or [])
        self.text = text
        self.raw = raw

    @property
    def present(self):
        return self.status == PRESENT

    @property
    def display(self):
        """Best available text for a document cell."""
        if self.text:
            return self.text
        if self.value is not None and self.value != "":
            return str(self.value)
        return ""

    def as_dict(self):
        return {
            "value": self.value,
            "status": self.status,
            "reason": self.reason,
            "evidence_refs": self.evidence_refs,
        }


def fact_of(node):
    """Build a Fact from a FEIP node, or a synthetic one from a plain value."""
    if node is None:
        return Fact()
    if isinstance(node, dict):
        if "status" in node:
            text = node.get("text")
            if text is None and node.get("value") is not None:
                text = str(node.get("value"))
            return Fact(
                value=node.get("value"),
                status=node.get("status") or UNKNOWN,
                reason=node.get("reason"),
                evidence_refs=node.get("evidence_refs"),
                text=text,
                raw=node,
            )
        if "header" in node:
            header = node.get("header") or {}
            fact = fact_of(header)
            fact.raw = node
            if fact.value is None:
                fact.value = header.get("name")
                fact.text = header.get("name")
            return fact
        return Fact(value=None, status=UNKNOWN, reason="字段不是 FEIP 事实信封", raw=node)
    if isinstance(node, (list, tuple)):
        return Fact(value=list(node), status=PRESENT, text=None, raw=node)
    return Fact(value=node, status=PRESENT, text=str(node), raw=node)


class FeipPackage(object):
    """A loaded, validated FEIP package."""

    def __init__(self, root):
        self.root = os.path.abspath(root)
        if not os.path.isdir(self.root):
            raise SkillError(
                "FEIP_PACKAGE_INVALID", "package directory not found", {"path": self.root}
            )
        self.manifest = self._load_manifest()
        self.profile = self.manifest.get("profile") if self.manifest else None
        self.synthetic = bool(self.manifest.get("synthetic")) if self.manifest else False
        self.status = self.manifest.get("status") if self.manifest else None
        self.package_uid = self.manifest.get("package_uid") if self.manifest else None
        if self.profile not in ("taskbook-reviewed", "reqspec-reviewed"):
            raise SkillError(
                "FEIP_PACKAGE_INVALID",
                "unsupported package profile: %s" % (self.profile,),
                {"profile": self.profile},
            )
        self.model_path = self._locate_model()
        self.model = read_json(self.model_path)
        self._build_indexes()

    # -- locating --------------------------------------------------------
    def _load_manifest(self):
        manifest_path = os.path.join(self.root, "package.json")
        if not os.path.isfile(manifest_path):
            return None
        return read_json(manifest_path)

    def _locate_model(self):
        if self.manifest:
            target_uid = self.manifest.get("model_artifact_uid")
            for artifact in self.manifest.get("artifacts") or []:
                if artifact.get("role") == "engineering-model":
                    if target_uid and artifact.get("uid") != target_uid:
                        continue
                    candidate = os.path.join(self.root, artifact.get("path", ""))
                    if os.path.isfile(candidate):
                        return candidate
        fallback = os.path.join(self.root, "model.json")
        if os.path.isfile(fallback):
            return fallback
        single = [name for name in os.listdir(self.root) if name.lower() == "model.json"]
        if single:
            return os.path.join(self.root, single[0])
        raise SkillError(
            "FEIP_PACKAGE_INVALID", "engineering model not found in package", {"path": self.root}
        )

    # -- indexes ---------------------------------------------------------
    def _build_indexes(self):
        model = self.model
        self.basic_info = model.get("basic_info") or {}
        self.system_overview = model.get("system_overview") or {}
        self.meta = model.get("meta") or {}
        self.analysis = model.get("analysis") or {}
        self.verification = model.get("verification") or {}
        self.views = model.get("views") or {}
        self.completeness = model.get("completeness") or {}

        self._requirements = {}
        for req in model.get("requirements") or []:
            uid = req.get("uid")
            if uid:
                self._requirements[uid] = req

        self._effective = {}
        for entry in model.get("effective_requirements") or []:
            uid = entry.get("requirement_uid")
            if uid:
                self._effective[uid] = entry

        self._criteria = {}
        for criterion in self.verification.get("criteria") or []:
            uid = criterion.get("uid")
            if uid:
                self._criteria[uid] = criterion

        self._obligations = {}
        for obligation in self.verification.get("obligations") or []:
            uid = obligation.get("uid")
            if uid:
                self._obligations[uid] = obligation

        self._test_points = {}
        for point in self.verification.get("source_test_points") or []:
            uid = point.get("uid")
            if uid:
                self._test_points[uid] = point

        self._signals = {}
        for signal in self.analysis.get("signals") or []:
            header = signal.get("header") or {}
            uid = header.get("uid")
            if uid:
                self._signals[uid] = signal

        self._category_index = {}
        for uid, req in self._requirements.items():
            self._category_index.setdefault(req.get("category"), []).append(uid)

    # -- facts -----------------------------------------------------------
    def fact(self, collection, key):
        node = (collection or {}).get(key)
        return fact_of(node)

    def basic(self, key):
        return fact_of(self.basic_info.get(key))

    def overview(self, key):
        return fact_of(self.system_overview.get(key))

    def meta_fact(self, key):
        return fact_of(self.meta.get(key))

    # -- requirements ----------------------------------------------------
    def requirement(self, uid):
        return self._requirements.get(uid)

    def has_requirement(self, uid):
        return uid in self._requirements

    def normalized_id(self, uid):
        req = self._requirements.get(uid)
        if req and req.get("normalized_id"):
            return req["normalized_id"]
        return uid

    def title(self, uid):
        req = self._requirements.get(uid)
        return (req or {}).get("title") or ""

    def category(self, uid):
        req = self._requirements.get(uid)
        return (req or {}).get("category") or ""

    def requirement_uids(self):
        return list(self._requirements.keys())

    def by_category(self, category):
        return list(self._category_index.get(category) or [])

    def statement(self, uid):
        """Statement text of the effective revision."""
        req = self._requirements.get(uid)
        if not req:
            return ""
        effective = self._effective.get(uid) or {}
        target = effective.get("revision_uid") or req.get("effective_revision_uid")
        revisions = req.get("revisions") or []
        chosen = None
        for revision in revisions:
            if revision.get("uid") == target:
                chosen = revision
                break
        if chosen is None and revisions:
            chosen = revisions[-1]
        if not chosen:
            return ""
        semantic = chosen.get("semantic") or {}
        text = semantic.get("statement")
        if text:
            return text
        parts = [
            semantic.get("subject") or "",
            semantic.get("action") or "",
            semantic.get("object") or "",
        ]
        return "".join(part for part in parts if part)

    def revision_uid(self, uid):
        effective = self._effective.get(uid) or {}
        if effective.get("revision_uid"):
            return effective["revision_uid"]
        req = self._requirements.get(uid) or {}
        return req.get("effective_revision_uid")

    def safety_critical(self, uid):
        req = self._requirements.get(uid) or {}
        for revision in req.get("revisions") or []:
            semantic = revision.get("semantic") or {}
            if semantic.get("safety_critical"):
                return True
        return False

    # -- criteria and obligations ---------------------------------------
    def criterion_text(self, uid):
        criterion = self._criteria.get(uid) or {}
        evaluation = criterion.get("evaluation") or {}
        text = evaluation.get("text")
        if text:
            return text
        return criterion.get("description") or ""

    def obligation(self, uid):
        return self._obligations.get(uid)

    def obligations(self):
        return list(self._obligations.values())

    # -- test points -----------------------------------------------------
    def test_points(self):
        return list(self._test_points.values())

    def test_point(self, uid):
        return self._test_points.get(uid)

    def test_point_of_requirement(self, requirement_uid):
        result = []
        for point in self._test_points.values():
            if requirement_uid in (point.get("requirement_refs") or []):
                result.append(point)
        return result

    # -- design information ---------------------------------------------
    def references(self, kind=None):
        docs = self.model.get("reference_documents") or []
        if kind is None:
            return docs
        return [doc for doc in docs if doc.get("kind") == kind]

    def acronyms(self):
        return self.model.get("acronyms") or []

    def interfaces(self):
        return self.analysis.get("interfaces") or []

    def signals(self):
        return self.analysis.get("signals") or []

    def platforms(self):
        return self.analysis.get("platform_resources") or []

    def collection(self, name):
        return self.analysis.get(name) or []

    def readiness(self, view):
        node = (self.views or {}).get(view) or {}
        return node.get("readiness"), node.get("reason")

    def gaps(self):
        return self.completeness.get("gaps") or []

    def document_archive(self):
        return self.model.get("document_archive") or []

    def evidence_quote(self, evidence_uid):
        for evidence in (self.model.get("consistency") or {}).get("evidence") or []:
            if evidence.get("uid") == evidence_uid:
                return evidence.get("quote")
        return None
