# -*- coding: utf-8 -*-
"""Fill the confirmation test plan template (1-58).

Every step is anchored on template text, never on a block index, so that a
re-published template fails loudly (TEMPLATE_ANCHOR_MISSING) instead of silently
writing into the wrong place.
"""
import re

from . import derive


def _title_map(feip, uids):
    """Requirement titles with duplicates disambiguated by （1）（2）…"""
    cleaned = [derive.clean_title(feip.title(uid)) or feip.normalized_id(uid) for uid in uids]
    return dict(zip(uids, derive.unique_titles(cleaned)))
from .base import SkillError
from .builder import Builder
from .contract import (
    PHRASE_RESULT,
    PHRASE_TODO,
    PHRASE_UNKNOWN,
)
from .docxlib import Table

APPENDIX_SECTIONS = (
    ("附录A.2 接口测试", ("interface", "protocol")),
    ("附录A.3 功能测试", ("function", "loading", "language", "tool", "ip", "verification")),
    ("附录A.4 性能和余量测试", ("performance",)),
    ("附录A.5 边界测试", ("@boundary",)),
    ("附录A.6 强度测试", ("@stress",)),
    ("附录A.7 恢复性测试", ("@recovery",)),
    ("附录A.8 安全性测试", ("reliability",)),
)


def build(doc, ctx):
    b = Builder(doc, ctx["gaps"], ctx)
    b.strip_comments()
    b.strip_example_markers()
    _drop_template_defects(b)
    _basic_info(b, ctx)
    _system_overview(b, ctx)
    _document_overview(b, ctx)
    _acronyms(b, ctx)
    _references(b, ctx)
    _environment(b, ctx)
    _requirements(b, ctx)
    _schedule(b, ctx)
    _criteria(b, ctx)
    _test_description(b, ctx)
    _trace_tables(b, ctx)
    _tracking_tables(b, ctx)
    _appendix_a(b, ctx)
    _appendix_b(b, ctx)
    _appendix_c(b, ctx)
    _appendix_d(b, ctx)
    _appendix_e(b, ctx)
    _drop_stray_dots(b)
    b.substitute(ctx["substitutions"])
    b.substitute_in_tables(ctx["substitutions"])
    return b


def _drop_stray_dots(b):
    """Delete leftover ellipsis placeholder paragraphs."""
    targets = []
    for para in b.doc.paragraphs():
        text = para.text.strip()
        if text in ("…", "….", "...", "……"):
            targets.append(para.index)
    if targets:
        b.doc.delete_blocks(targets)
        b.note("cleanup.ellipsis", "template", status="deleted", value=len(targets))


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _drop_template_defects(b):
    """Neutralise the empty Heading 1 without losing the section break it carries.

    The template's stray empty Heading 1 sits on the boundary between the
    portrait body and the landscape appendices; the ``sectPr`` lives inside that
    paragraph, so deleting the paragraph would merge the sections and lose the
    landscape orientation.  The paragraph is therefore kept and only stripped of
    its heading style.
    """
    kept = 0
    for para in b.doc.paragraphs():
        if para.style not in ("1", "2", "3"):
            continue
        if para.text.strip():
            continue
        if "<w:sectPr" in para.raw:
            b.doc.set_block(para.index, _strip_heading_style(para.raw))
            kept += 1
        else:
            b.doc.delete_block(para.index)
    if kept:
        b.note("defect.empty_heading", "template", value="section break preserved (%d)" % (kept,))

    caption = b.find("图 1需求标识内容", optional=True)
    if caption is not None:
        targets = [caption.index]
        previous = caption.index - 1
        if previous >= 0 and b.doc.block_kind(previous) == "p":
            raw = b.doc.paragraph(previous).raw
            if "<w:drawing" in raw or "<w:pict" in raw or "<v:imagedata" in raw:
                targets.append(previous)
        b.doc.delete_blocks(targets)
        b.note("defect.example_figure", "template", status="deleted")


def _strip_heading_style(raw):
    import re

    raw = re.sub(r"<w:pStyle\b[^>]*/>", "", raw)
    raw = re.sub(r"<w:outlineLvl\b[^>]*/>", "", raw)
    return raw


def _require(b, prefix, slot, source):
    para = b.find(prefix, optional=True)
    if para is None:
        raise SkillError(
            "TEMPLATE_ANCHOR_MISSING", "plan template anchor missing: %s" % (prefix,), {"prefix": prefix}
        )
    b.note(slot, source, status="anchor")
    return para


def _basic_info(b, ctx):
    feip = ctx["feip"]
    fields = (
        ("FPGA产品名称", ctx["product"], "plan.1.1.product_name", "basic_info.product_name"),
        ("FPGA产品代号", ctx["config_code"], "plan.1.1.config_item_code", "basic_info.config_item_code"),
        ("研制类型", ctx["development_type"], "plan.1.1.development_type", "basic_info.development_type"),
        ("安全关键等级", ctx["safety_level"], "plan.1.1.safety_level", "basic_info.safety_level"),
        ("继承基线", ctx["maintenance_base"], "plan.1.1.maintenance_base", "basic_info.maintenance_base"),
        ("交办方", ctx["assigner"], "plan.1.1.assigner", "basic_info.assigner"),
        ("承制方", ctx["contractor"], "plan.1.1.contractor", "basic_info.contractor"),
    )
    for label, value, slot, source in fields:
        b.set_label_value(label, value, slot, source)


def _system_overview(b, ctx):
    feip = ctx["feip"]
    lines = []
    host = ctx["overview"]["host_unit"]
    composition = ctx["overview"]["subsystem_composition"]
    functions = ctx["overview"]["main_functions"]
    power_on = ctx["overview"]["long_term_power_on"]

    if host:
        lines.append("被测 FPGA 位于%s。" % (host,))
    if functions:
        lines.append("其主要功能包括：%s。" % (functions,))
    if composition:
        lines.append("外部环境与组成：%s。" % (composition,))
    lines.append("长期加电要求：%s。" % (power_on,))
    if not lines:
        lines.append(ctx["gaps"].phrase_for(None, "plan.1.2.1", "system_overview", ""))
    b.append_lines("系统组成和任务概述", lines, "plan.1.2.1", "system_overview")

    # lead-in sentence above the hardware table
    b.set_text(
        "××FPGA产品设计确认所用的测试环境及工具见下表",
        "被测 FPGA 设计确认所用的测试环境及工具见下表。",
        "plan.3.lead_in",
        "template",
        optional=True,
    )


def _document_overview(b, ctx):
    lines = [
        "本确认测试计划依据《%s》制定，分析并提出设计确认的需求，为测试用例设计提供依据，"
        "并为设计确认活动确定所需的资源。通过独立于 FPGA 开发的测试组织实施确认设计，"
        "以验证 %s 与《%s》的一致性。" % (ctx["basis_title"], ctx["product"], ctx["basis_title"]),
        "本文件的预期读者为 FPGA 研制人员、用户、质量保证人员、高层管理者和需要阅读本文件的其他人员。",
        "本文件中，测试用例标识的命名规则为“%s-<测试类型码>-<序号>”，其中测试类型码按需求类目取值"
        "（GN 功能、JK 接口、XN 性能、XY 协议与数据格式、KK 可靠性与安全性、JZ 加载、YY 编程语言、"
        "GJ 开发工具、IP 核、YZ 测试验证要求），序号从 001 开始；用例表中的“编号”列给出与追溯矩阵、"
        "覆盖报告一致的用例标识。" % (derive.STAGE_PREFIX,),
    ]
    b.replace_region("文档概述", "符号和缩略语", lines, "plan.1.3", "derived")


def _acronyms(b, ctx):
    rows = []
    for entry in ctx["feip"].acronyms():
        abbreviation = entry.get("abbreviation") or ""
        meaning = (entry.get("meaning") or {}).get("value") or (entry.get("full_name") or {}).get("value")
        if abbreviation:
            rows.append([abbreviation, meaning or PHRASE_UNKNOWN])
    if not rows:
        rows = [["—", "本文件使用的缩略语以任务书术语为准。"]]
        ctx["gaps"].add("absent", "1.4", "acronyms", "FEIP 包未提供缩略语表", "符号和缩略语")
    b.replace_region("符号和缩略语", "引用文件", [], "plan.1.4", "model.acronyms")
    heading = b.find("符号和缩略语")
    proto = _reference_table_prototype(b)
    raw = _simple_table(proto.raw, ["缩略语", "含义"], rows)
    b.doc.insert_after(heading.index, [raw])
    b.note("plan.1.4.table", "model.acronyms", value=len(rows))


def _reference_table_prototype(b):
    """The 2-column 引用文件 table is the best available two-column prototype."""
    _, table = b.table_after_prefix("规范性引用文件", optional=True)
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing reference table prototype", {})
    return table


def _simple_table(proto_raw, header_cells, rows):
    """Build a bordered two-column table from a template prototype."""
    table = Table(-1, proto_raw).with_borders()
    prototype = table.row(0)
    built = []
    for cells in [header_cells] + rows:
        row = prototype
        for index, value in enumerate(cells):
            if index < row.cell_count():
                row = row.set_cell_text(index, value)
        built.append(row.raw)
    return table.with_rows(built)


def _references(b, ctx):
    feip = ctx["feip"]
    normative = []
    for doc in feip.references("normative"):
        identifier = (doc.get("identifier") or {}).get("value") or PHRASE_UNKNOWN
        title = doc.get("title") or ""
        normative.append([identifier, title])
    if not normative:
        normative = [[PHRASE_TODO, PHRASE_TODO]]
    table = b.table_after(_require(b, "规范性引用文件", "plan.2.1", "model.reference_documents"))
    table = table.with_borders()
    b.doc.set_block(table.index, table.raw)
    b.fill_table(
        table,
        [["文件编号", "文件名称"]] + normative,
        "plan.2.1.table",
        "reference_documents[normative]",
        header_rows=0,
    )

    development = []
    for doc in feip.references("development"):
        identifier = (doc.get("identifier") or {}).get("value") or PHRASE_UNKNOWN
        title = doc.get("title") or ""
        development.append([identifier, title])
    if not development:
        development = [[PHRASE_TODO, PHRASE_TODO]]
    table = b.table_after(_require(b, "研制依据引用文件", "plan.2.2", "model.reference_documents"))
    table = table.with_borders()
    b.doc.set_block(table.index, table.raw)
    b.fill_table(
        table,
        [["文件编号", "文件名称"]] + development,
        "plan.2.2.table",
        "reference_documents[development]",
        header_rows=0,
    )


def _environment(b, ctx):
    """The three equipment tables keep the template's row categories."""
    derived_note = "、".join(ctx["equipment"]) if ctx["equipment"] else PHRASE_TODO

    # 1.2.2 表1: FPGA 运行硬件环境（模板 5 行 = 表头 + 4 类）
    rows = [
        ["", "控制计算机", PHRASE_TODO, ""],
        ["", "检测设备", PHRASE_TODO, derived_note],
        ["", "专用仪器", PHRASE_TODO, derived_note],
        ["", "其他设备", PHRASE_TODO, ""],
    ]
    _, table = b.table_after_prefix("FPGA运行硬件环境")
    if table is not None:
        b.fill_table(table, rows, "plan.1.2.2.table1", "derived+gap")

    # 3 表2: 环境及工具表（模板 9 行 = 表头 + 8 类）
    rows = [
        ["", ctx["product"], ctx["config_code"], "受控库", "1套"],
        ["", "联试设备", PHRASE_TODO, PHRASE_TODO, "1套"],
        ["", "系统管理软件", PHRASE_TODO, PHRASE_TODO, "1套"],
        ["", "控制计算机", PHRASE_TODO, PHRASE_TODO, "1台"],
        ["", "万用表", PHRASE_TODO, PHRASE_TODO, "1台"],
        ["", "电源", PHRASE_TODO, PHRASE_TODO, "1台"],
        ["", "示波器", PHRASE_TODO, PHRASE_TODO, "1台"],
        ["", "分析仪", PHRASE_TODO, PHRASE_TODO, "1台"],
    ]
    _, table = b.table_after_prefix("FPGA产品设计确认环境及工具表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing environment table", {})
    b.fill_table(table, rows, "plan.3.table2", "template categories + gap")

    # 3.1 表3: 硬件说明表（模板 5 行 = 表头 + 4 类）
    rows = [
        ["单检地检设备", "地检设备", PHRASE_TODO, ""],
        ["测试计算机", "控制计算机", PHRASE_TODO, ""],
        ["附件", "电缆、数据线、下载线", PHRASE_TODO, "电缆、数据线、下载线等"],
        ["其他设备", "、".join(ctx["equipment"]) or PHRASE_TODO, PHRASE_TODO, ""],
    ]
    _, table = b.table_after_prefix("FPGA设计确认硬件说明表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing hardware table", {})
    b.fill_table(table, rows, "plan.3.table3", "template categories + gap")

    # environment difference: electrical vs flight part is a real, evidenced difference
    difference = ctx["difference_rows"]
    _, table = b.table_after_prefix("测试环境差异性分析表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing difference table", {})
    b.fill_table(table, difference, "plan.3.table4", "basic_info.chip_model + platform_resources")
    if not difference:
        ctx["gaps"].add(
            "absent", "plan.3.2", "环境差异性", "任务书未给出测试环境与在轨环境差异说明", "3.2 测试环境差异性分析"
        )

    b.set_text(
        "××FPGA产品设计确认所用的测试设备的组成",
        "被测 FPGA 设计确认所用测试设备的组成以及各部分功能见下表。",
        "plan.3.1.lead_in",
        "template",
        optional=True,
    )


def _requirements(b, ctx):
    projects = ctx["projects"]
    stats = ctx["stats"]
    labels = [project.label for project in projects]
    lines = [
        "本设计确认任务依据《%s》，对 %s 的接口、功能、性能与余量、协议、可靠性与安全性需求，"
        "以及隐含要求（边界、强度、健壮性）开展配置项设计确认。"
        % (ctx["basis_title"], ctx["product"]),
        "本设计确认范围覆盖全部有效需求共 %d 项，划分为 %d 个测试项目，设计测试用例与证据程序共 %d 项，"
        "涵盖%s。" % (ctx["requirement_count"], len(projects), stats["total"], "、".join(labels)),
    ]
    b.set_text("本设计确认任务是针对", lines[0], "plan.4.1", "derived")
    b.append_lines("本设计确认任务是针对", lines[1:], "plan.4.1.2", "derived")

    coverage_lines = [
        "本次设计确认以有效需求为覆盖分母，要求需求覆盖率、测试要点覆盖率均达到 100%，"
        "安全关键功能全部覆盖并单独跟踪。",
        "对不可测试项按 I/II/III 类判定并在 7.6.4 汇总，明确在其他测试时机或环境下的验证途径，"
        "并在设计确认报告中跟踪处理情况。",
    ]
    b.replace_region("4.2测试覆盖性要求", "4.3测试策略与方法", coverage_lines, "plan.4.2", "derived")

    method_counts = ctx["method_counts"]
    strategy_lines = [
        "本设计确认以黑盒测试为主，对内部信号与状态相关项结合白盒观测；按方法划分：%s。"
        % ("、".join("%s %d 项" % (derive.method_label(method), count) for method, count in method_counts),),
        "对无法在板级直接观测的项，以检查、分析或时序分析作为独立证据程序，写明检查材料、核对对象、"
        "保存证据与判定方法。",
    ]
    b.replace_region("4.3测试策略与方法", "测试项目", strategy_lines, "plan.4.3", "derived")

    project_lines = []
    for project in projects:
        ids = [item["id"] for item in project.items]
        shown = ids if len(ids) <= 8 else ids[:8] + ["…"]
        project_lines.append(
            "%s（%s）：%d 项，用例编号 %s。" % (project.label, project.ident, project.count, "、".join(shown))
        )
    b.replace_region("测试项目", "测试进度和测试人员安排", project_lines, "plan.4.4", "derived")


def _schedule(b, ctx):
    rows = [
        ["设计测试用例", PHRASE_TODO, PHRASE_TODO],
        ["执行测试、测试数据管理", PHRASE_TODO, PHRASE_TODO],
        ["测试问题分析", PHRASE_TODO, PHRASE_TODO],
        ["完成测试报告", PHRASE_TODO, PHRASE_TODO],
    ]
    _, table = b.table_after_prefix("工作量估计以及人员分配表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing workload table", {})
    b.fill_table(table, rows, "plan.5.table5", "gap")
    ctx["gaps"].add(
        "missing",
        "plan.5",
        "工作量与人员安排",
        "任务书与 FEIP 包均未提供工作量估算和人员分工",
        "5 测试进度和测试人员安排",
        "由项目负责人补充人天与人员安排",
    )
    b.set_text(
        "总体设计确认进度按",
        "总体设计确认进度按 %s 的研制计划流程及项目开发计划执行，工作量估计与人员分配见下表（待项目负责人补充）。"
        % (ctx["product"],),
        "plan.5.lead_in",
        "derived",
        optional=True,
    )


def _criteria(b, ctx):
    lines = [
        "设计确认的有效性：测试用例的设计、执行，测试结果的产生、记录符合设计确认规程。",
        "测试用例通过：某一测试用例产生的实际结果与期望结果一致。",
        "测试用例未通过：某一测试用例产生的实际结果与期望结果不一致。",
        "设计确认通过：满足《%s》中规定的所有功能、性能等要求；或所有已发现缺陷的影响均被消除，"
        "或缺陷的影响虽未消除，但已弄清带着缺陷运行的风险并经认可。" % (ctx["basis_title"],),
        "设计确认未通过：不满足《%s》中规定的所有功能、性能等要求；并且发现缺陷的影响未被消除，"
        "并且带着缺陷运行的风险未经认可。" % (ctx["basis_title"],),
        "设计确认终止：正常终止指已完成所有测试项目且达到测试充分性要求；异常终止指在设计确认过程中"
        "发现的 FPGA 缺陷影响测试继续进行或测试环境不满足设计确认要求。",
    ]
    b.replace_region("6 评价准则", "7 测试说明", lines, "plan.6", "template+derived")


def _test_description(b, ctx):
    stats = ctx["stats"]
    projects = ctx["projects"]
    lines = [
        "本设计确认任务针对《%s》中提出的接口、功能、性能及余量、边界、强度、安全性、恢复性要求，"
        "在 3.1 所述测试设备上进行 %s 的配置项设计确认，共 %d 个测试项目、%d 项测试用例与证据程序。"
        % (ctx["basis_title"], ctx["product"], len(projects), stats["total"]),
        "测试用例给出正常与异常的输入，检验 FPGA 是否按需求规格说明中确定的功能、性能等技术要求工作。"
        "对安全关键功能进行跟踪和专项测试，并在设计确认报告中给出实测结果满足裕度要求的分析。",
    ]
    b.replace_region("7.1测试总体说明", "7.2测试项目说明", lines, "plan.7.1", "derived")

    naming = [
        "测试用例标识的命名规则为“%s-<测试类型码>-<序号>”，测试类型码按需求类目取值；"
        "用例表中的“编号”列给出与追溯矩阵、覆盖报告一致的用例标识。" % (derive.STAGE_PREFIX,),
    ]
    b.replace_region("7.2测试项目说明", "7.2.1接口测试", naming, "plan.7.2", "derived")

    type_map = {
        "7.2.1接口测试": ("interface", "protocol"),
        "7.2.2功能测试": ("function",),
        "7.2.3性能和余量测试": ("performance",),
        "7.2.4健壮性验证": (),
        "7.2.4.1边界测试": ("@boundary",),
        "7.2.4.2强度测试": ("@stress",),
        "7.2.4.3恢复性测试": ("@recovery",),
        "7.2.4.4安全性测试": ("reliability",),
    }
    order = [
        "7.2.1接口测试",
        "7.2.2功能测试",
        "7.2.3性能和余量测试",
        "7.2.4健壮性验证",
        "7.2.4.1边界测试",
        "7.2.4.2强度测试",
        "7.2.4.3恢复性测试",
        "7.2.4.4安全性测试",
        "7.3测试需求跟踪矩阵",
    ]
    for index, heading in enumerate(order[:-1]):
        next_heading = order[index + 1]
        project = derive.project_items(projects, type_map[heading][0]) if type_map[heading] else None
        if project is not None:
            ids = [item["id"] for item in project.items]
            shown = ids if len(ids) <= 8 else ids[:8] + ["…"]
            text = ["依据《%s》，本项共 %d 项，用例编号 %s，具体操作过程见附录A。"
                    % (ctx["basis_title"], project.count, "、".join(shown))]
        else:
            matched = ctx["scenario_projects"].get(type_map[heading][0]) if type_map[heading] else None
            if matched:
                ids = [item["id"] for item in matched]
                shown = ids if len(ids) <= 8 else ids[:8] + ["…"]
                text = ["依据《%s》，本项共 %d 项（用例编号 %s），具体操作过程见附录A。"
                        % (ctx["basis_title"], len(matched), "、".join(shown))]
            elif heading == "7.2.4健壮性验证":
                text = ["健壮性验证涵盖边界、强度、恢复性与安全性测试，对应用例见 7.2.4.1 至 7.2.4.4 及附录A。"]
            else:
                text = ["依据《%s》，本版本无此类测试项。" % (ctx["basis_title"],)]
        b.replace_region(heading, next_heading, text, "plan." + heading, "derived")


def _trace_tables(b, ctx):
    """7.3 requirement trace matrix, 7.4 test case statistics, 7.5 forward matrix."""
    spec = ctx["spec"]
    feip = ctx["feip"]
    requirements = ctx["rtm_requirements"]

    titles = _title_map(feip, requirements)
    rows = []
    for uid in requirements:
        linked = spec.rtm_linked_ids(uid)
        rows.append(["", feip.normalized_id(uid), titles[uid], "、".join(linked) or "无", ""])
    if not rows:
        rows = [["", "无", "无", "无", ""]]
    _, table = b.table_after_prefix("需求跟踪矩阵表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing requirement trace matrix", {})
    b.fill_table(table, rows, "plan.7.3.table6", "RTM.csv")

    rows = [[None, project.label, project.ident, str(project.count)] for project in ctx["projects"]]
    b.set_text(
        "本测试任务有",
        "本测试任务有 %d 个测试项目，共设计了 %d 项测试用例与证据程序，用例统计见下表。"
        % (len(ctx["projects"]), ctx["stats"]["total"]),
        "plan.7.4.lead_in",
        "derived",
        optional=True,
    )
    _, table = b.table_after_prefix("测试用例统计表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing case statistics table", {})
    table = b.fill_table(table, rows, "plan.7.4.table7", "derived", tail_rows=1)
    total_row = table.row(table.row_count() - 1)
    if total_row.cell_count() >= 2:
        total_row = total_row.set_cell_text(total_row.cell_count() - 1, str(ctx["stats"]["total"]))
        b.doc.set_block(table.index, table.replace_row(table.row_count() - 1, total_row))
        b.note("plan.7.4.total", "derived", value=ctx["stats"]["total"])

    covered = 0
    for uid in requirements:
        if spec.rtm_linked_ids(uid):
            covered += 1
    uncovered = len(requirements) - covered
    b.set_text(
        "本次测试共涉及需求功能项",
        "本次测试共涉及需求 %d 项，通过测试用例设计覆盖了 %d 项，其余 %d 项为不可测试项或未覆盖项，"
        "正向需求跟踪矩阵见下表。" % (len(requirements), covered, uncovered),
        "plan.7.5.lead_in",
        "RTM.csv",
        optional=True,
    )
    rows = []
    for uid in requirements:
        if spec.rtm_linked_ids(uid):
            continue
        rows.append(["", feip.normalized_id(uid), titles[uid], "无", "不可测试项或未覆盖"])
    if not rows:
        rows = [["", "无", "无", "无", "无未覆盖项"]]
    _, table = b.table_after_prefix("正向需求跟踪矩阵表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing forward trace matrix", {})
    b.fill_table(table, rows, "plan.7.5.table8", "RTM.csv")


def _tracking_tables(b, ctx):
    """7.6.1 test points, 7.6.2 new states, 7.6.3 safety critical, 7.6.4 untestable."""
    spec = ctx["spec"]
    feip = ctx["feip"]

    rows = []
    for point in feip.test_points():
        title = point.get("title") or ""
        requirement = point.get("procedure") or point.get("purpose") or PHRASE_UNKNOWN
        ident = derive.test_point_ident(point)
        rows.append([title, requirement, ident])
    if not rows:
        rows = [[PHRASE_TODO, PHRASE_UNKNOWN, PHRASE_TODO]]
    _, table = b.table_after_contains("测试要点汇总表")
    if table is not None:
        b.fill_table(table, rows, "plan.7.6.1.table9", "verification.source_test_points")

    rows = [[PHRASE_TODO, PHRASE_UNKNOWN, PHRASE_TODO], ["", "", ""]]
    _, table = b.table_after_contains("新状态识别表")
    if table is not None:
        b.fill_table(table, rows, "plan.7.6.2.table10", "gap")
    ctx["gaps"].add(
        "absent",
        "plan.7.6.2",
        "新状态识别",
        "FEIP 包未提供新状态识别对象（需求属性 N 无对应字段）",
        "7.6.2 新状态闭环追踪",
        "由设计师补充本版本新状态清单",
    )

    safety_uids = derive.reliability_requirement_ids(feip)
    titles = _title_map(feip, safety_uids)
    rows = []
    for uid in safety_uids:
        linked = spec.rtm_linked_ids(uid)
        rows.append(["", feip.normalized_id(uid), titles[uid], "、".join(linked) or "无"])
    if not rows:
        rows = [["", "无", "无", "无"]]
    _, table = b.table_after_contains("安全关键功能测试用例对应表")
    if table is not None:
        b.fill_table(table, rows, "plan.7.6.3.table11", "requirements[reliability]")
    ctx["gaps"].add(
        "unknown",
        "plan.7.6.3",
        "safety_critical",
        "FEIP 中 semantic.safety_critical 全为 null，安全关键判定按可靠性与安全性需求类目派生，需人工确认",
        "7.6.3 安全关键功能",
    )

    rows = []
    for item in spec.items:
        if item["status"] == "READY":
            continue
        reason = "；".join(item["open_items"]) or PHRASE_UNKNOWN
        rows.append(["", "%s %s" % (item["id"], derive.clean_title(item["title"])), "II 类", reason, "检查 / 分析", PHRASE_TODO])
    gaps = spec.coverage_gaps() or {}
    for obligation in (gaps.get("uncovered_obligation_ids") or []):
        rows.append(["", "未覆盖义务 %s" % (obligation,), "II 类", "细则追溯覆盖不足", "补充用例", PHRASE_TODO])
    if not rows:
        rows = [["", "无", "—", "本版本未识别不可测试项", "—", "—"]]
    _, table = b.table_after_contains("不可测试项分析汇总表")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing untestable table", {})
    b.fill_table(table, rows, "plan.7.6.4.table12", "status!=READY + coverage gaps", tail_rows=1)


def _appendix_a(b, ctx):
    _delete_example_tables(b)

    intro = [
        "本附录给出全部测试用例与证据程序。表格按测试项目组织，用例公共属性在括号内一并说明；"
        "“实际结果”“测试结论”为执行阶段预留项，计划阶段不填写。",
        "评估准则：每个操作步骤的实际结果与期望结果一致；终止条件为正常执行完所有操作步骤，"
        "或在执行过程中某一操作步骤的实际结果与期望结果不一致。",
    ]
    b.replace_region("附录A.1 测试记录表说明", "附录A.2 接口测试", intro, "plan.appendixA.1", "derived")

    for position, (heading, categories) in enumerate(APPENDIX_SECTIONS):
        if position + 1 < len(APPENDIX_SECTIONS):
            end_heading = APPENDIX_SECTIONS[position + 1][0]
        else:
            end_heading = "附录B"
        scenario_based = any(category.startswith("@") for category in categories)
        if scenario_based:
            selected = _items_for_categories(ctx, categories)
            if selected:
                ids = [item["id"] for item in selected]
                shown = ids if len(ids) <= 12 else ids[:12] + ["…"]
                lines = [
                    "本类用例共 %d 项，已在所属测试项目表的“健壮性”列中标注为实心方框，编号：%s。"
                    % (len(selected), "、".join(shown))
                ]
            else:
                lines = ["本版本无此类测试用例。"]
            b.replace_region(heading, end_heading, lines, "plan." + heading, "derived")
            continue
        projects = [project for project in ctx["projects"] if project.category in categories]
        if not projects:
            b.replace_region(heading, end_heading, ["本版本无此类测试用例。"], "plan." + heading, "derived")
            continue
        b.replace_region(heading, end_heading, [], "plan." + heading + ".body", "derived")
        anchor = b.find(heading)
        insert_at = anchor.index
        for project in projects:
            for raw in _build_case_tables(project, ctx):
                b.doc.insert_after(insert_at, [raw, "<w:p/>"])
                insert_at += 2
            b.note("plan." + heading + "." + project.ident, "test_cases", value=project.count)


def _items_for_categories(ctx, categories):
    spec = ctx["spec"]
    selected = []
    for category in categories:
        if category.startswith("@"):
            scenario = category[1:]
            for item in spec.items:
                if scenario in spec.scenario_types(item) and item not in selected:
                    selected.append(item)
            continue
        for item in spec.items:
            for uid in item["requirement_uids"]:
                if ctx["feip"].category(uid) == category and item not in selected:
                    selected.append(item)
                    break
    selected.sort(key=lambda item: item["id"])
    return selected


def _projects_for_items(ctx, items):
    """Group the selected items into temporary projects by their own category."""
    buckets = {}
    for item in items:
        category = derive.project_of_item(item, ctx["feip"])
        buckets.setdefault(category, []).append(item)
    projects = []
    serial = 0
    for category in sorted(buckets.keys(), key=derive.category_rank):
        from .derive import Project

        projection = Project(category)
        serial += 1
        projection.assign(serial)
        projection.items = buckets[category]
        projects.append(projection)
    return projects




def _delete_example_tables(b):
    victims = []
    for table in b.doc.tables():
        try:
            first = table.row(0).texts()
        except SkillError:
            continue
        if any("××测试项1" in cell for cell in first) or any("用例标识" == cell.strip() for cell in first):
            victims.append(table.index)
    if victims:
        b.doc.delete_blocks(victims)
        b.note("defect.example_tables", "template", status="deleted", value=len(victims))


def _case_cells(item, spec, feip):
    """The eleven cells of one 模板1 data row."""
    requirement_ids = [feip.normalized_id(uid) for uid in item["requirement_uids"]]
    point_ids = [pid.split(":")[-1] for pid in derive.item_test_points(item, feip)]
    return [
        item["id"],
        derive.type_label(spec, item),
        derive.clean_title(item["title"]),
        derive.join_ids(requirement_ids),
        derive.numbered_steps(item["steps"]),
        derive.expected_result_text(spec, item) or derive.pass_criterion_text(spec, item),
        PHRASE_RESULT,
        PHRASE_RESULT,
        derive.robustness_mark(spec, item),
        derive.join_ids(point_ids),
        "",
    ]


CASE_COLUMNS = (
    ("编号", 850),
    ("测试类型", 900),
    ("测试目的", 1800),
    ("功能项", 1150),
    ("操作步骤", 3100),
    ("期望结果", 1950),
    ("实际结果", 570),
    ("测试结论", 570),
    ("健壮性", 500),
    ("测试要点", 900),
    ("备注", 920),
)

_CASE_BORDERS = (
    "<w:tblBorders>"
    '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
    '<w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
    '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
    '<w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
    '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
    '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
    "</w:tblBorders>"
)


def _tc(text, width, span=1, bold=False):
    """One table cell with an explicit width, used by the generated case tables."""
    from .docxlib import escape_text

    pr = '<w:tcPr><w:tcW w:w="%d" w:type="dxa"/>' % (width,)
    if span > 1:
        pr += '<w:gridSpan w:val="%d"/>' % (span,)
    pr += '<w:vAlign w:val="center"/></w:tcPr>'
    rpr = "<w:rPr><w:b/></w:rPr>" if bold else ""
    pieces = []
    for index, line in enumerate(str(text).split("\n")):
        if index:
            pieces.append("<w:br/>")
        pieces.append('<w:t xml:space="preserve">%s</w:t>' % escape_text(line))
    paragraphs = (
        '<w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>'
        "<w:r>%s%s</w:r></w:p>" % (rpr, "".join(pieces))
    )
    return "<w:tc>%s%s</w:tc>" % (pr, paragraphs)


def _row(cells):
    return "<w:tr>%s</w:tr>" % ("".join(cells),)


def _span_width(start, span):
    return sum(width for _, width in CASE_COLUMNS[start:start + span])


def _case_table_xml(project, item, ctx):
    """Build one self-contained case table (one 编号 per table).

    Adjacent ``w:tbl`` elements with no paragraph between them are merged by
    Word, so the caller inserts a separator paragraph after every table.
    """
    spec = ctx["spec"]
    feip = ctx["feip"]
    total_width = sum(width for _, width in CASE_COLUMNS)
    grid = "".join('<w:gridCol w:w="%d"/>' % (width,) for _, width in CASE_COLUMNS)
    header = "".join(_tc(label, width, 1, bold=True) for label, width in CASE_COLUMNS)

    project_row = _row(
        [
            _tc("测试项目", _span_width(0, 1)),
            _tc(project.label, _span_width(1, 2), 2),
            _tc("项目对应功能项", _span_width(3, 1)),
            _tc(_functional_ids(project.items, feip), _span_width(4, 3), 3),
            _tc("项目标识", _span_width(7, 2), 2),
            _tc(project.ident, _span_width(9, 2), 2),
        ]
    )

    cells = _case_cells(item, spec, feip)
    data_row = _row([_tc(value, CASE_COLUMNS[index][1]) for index, value in enumerate(cells)])

    signature = _row(
        [
            _tc("设计人", CASE_COLUMNS[0][1]),
            _tc("", CASE_COLUMNS[1][1]),
            _tc("设计日期", CASE_COLUMNS[2][1]),
            _tc("", CASE_COLUMNS[3][1]),
            _tc("执行人", CASE_COLUMNS[4][1]),
            _tc("", CASE_COLUMNS[5][1]),
            _tc("执行日期", CASE_COLUMNS[6][1]),
            _tc("复核人", CASE_COLUMNS[7][1]),
            _tc("", CASE_COLUMNS[8][1]),
            _tc("复核日期", CASE_COLUMNS[9][1]),
            _tc("", CASE_COLUMNS[10][1]),
        ]
    )

    return (
        "<w:tbl><w:tblPr>"
        '<w:tblW w:w="%d" w:type="dxa"/>'
        '<w:jc w:val="center"/>'
        "%s"
        '<w:tblLayout w:type="fixed"/>'
        "</w:tblPr><w:tblGrid>%s</w:tblGrid>%s%s%s%s</w:tbl>"
        % (total_width, _CASE_BORDERS, grid, project_row, _row([header]), data_row, signature)
    )


def _build_case_tables(project, ctx):
    """One table per 编号."""
    return [_case_table_xml(project, item, ctx) for item in project.items]


def _functional_ids(items, feip, limit=12):
    ids = []
    for item in items:
        for uid in item["requirement_uids"]:
            normalized = feip.normalized_id(uid)
            if normalized not in ids:
                ids.append(normalized)
    if len(ids) <= limit:
        return "、".join(ids)
    return "、".join(ids[:limit]) + " 等 %d 项" % (len(ids),)


def _appendix_b(b, ctx):
    spec = ctx["spec"]
    feip = ctx["feip"]
    requirements = ctx["rtm_requirements"]

    titles = _title_map(feip, requirements)
    rows = []
    for index, uid in enumerate(requirements):
        linked = spec.rtm_linked_ids(uid)
        rows.append(
            [
                "",
                derive.join_ids(linked, "；") or "无",
                "",
                feip.normalized_id(uid),
                titles[uid],
                "",
            ]
        )
    if not rows:
        rows = [["", "无", "", "", "", ""]]
    _, table = b.table_after_prefix("B.1 逆向跟踪矩阵")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing reverse trace matrix", {})
    b.fill_table(table, rows, "plan.B.1", "RTM.csv", header_rows=2)

    rows = []
    for uid in requirements:
        linked = spec.rtm_linked_ids(uid)
        if linked:
            continue
        rows.append(["", feip.normalized_id(uid), titles[uid], "", "无", "不可测试项或未覆盖"])
    if not rows:
        rows = [["", "无", "无", "", "无", "无未覆盖项"]]
    _, table = b.table_after_prefix("B.2 正向跟踪矩阵")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing forward trace matrix", {})
    b.fill_table(table, rows, "plan.B.2", "RTM.csv", header_rows=2)


def _appendix_c(b, ctx):
    _, table = b.table_after_prefix("附录C")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing readiness checklist", {})
    # row 0: 名称 | 产品名   row 1: 检查日期 | ... | 检查地点 | ... | 研制阶段 | ...
    table = b.set_cells_in_rows(table, 1, {0: ctx["product"]}, "plan.appendixC.name", "basic_info.product_name")
    meta = {}
    for row_index, row in enumerate(table.rows()):
        if row_index >= 3:
            break
        texts = [cell.replace("\t", "") for cell in row.texts()]
        if len(texts) > 1 and texts[0].strip() == "检查日期":
            meta = texts
            break
    if meta:
        current = table.row(1)
        cells = [cell.raw for cell in current.cells()]
        replacements = {}
        for index, text in enumerate(meta):
            if text.strip() in ("××××", "×楼×房间"):
                replacements[index] = PHRASE_TODO
            elif text.strip() == "C/Z":
                replacements[index] = PHRASE_TODO
        if replacements:
            for index, value in replacements.items():
                cells[index] = current.cell(index).with_text(value)
            b.doc.set_block(table.index, table.replace_row(1, current.with_cells(cells)))
            table = b.table_at(table.index)
            b.note("plan.appendixC.meta", "gap", value=replacements)

    mapping = {}
    results = _readiness(b, ctx, "plan")
    b.note("plan.appendixC.result", "readiness_rules.json", value=len(results))


def _readiness(b, ctx, kind):
    """Fill 检查结果 by analysis; the basis goes into the 备注 column."""
    from . import conformance

    ctx["document_kind"] = kind
    rules = conformance.load_rules().get("readiness_rules") or []
    return conformance.apply_readiness(b.doc, "准备状态检查表", rules, ctx)


def _appendix_d(b, ctx):
    """Change log: header row only (decision D14)."""
    _, table = b.table_after_prefix("附录D")
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing change log table", {})
    b.doc.set_block(table.index, table.with_rows([table.row(0).raw]))
    b.note("plan.appendixD", "d14", value="header only")

    targets = []
    for para in b.doc.paragraphs():
        text = para.text.strip()
        if re.match(r"^V1\.0[12]版本更改记录表", text) or text == "….":
            targets.append(para.index)
    if targets:
        b.doc.delete_blocks(targets)
        b.note("plan.appendixD.placeholders", "d14", status="deleted", value=len(targets))


def _appendix_e(b, ctx):
    """Appendix E is filled by the conformance engine, not by hand (D15)."""
    from . import conformance

    rules = conformance.load_rules()
    verdicts = conformance.evaluate(rules, ctx, b.doc, "plan")
    conformance.apply_to_table(b.doc, "产保要素测试阶段确认检查表", 5, verdicts, chapter_column=4)
    ctx["plan_verdicts"] = verdicts
    b.note("plan.appendixE", "conformance_rules.json", value=conformance.summarise(verdicts))
