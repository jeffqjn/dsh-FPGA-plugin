# -*- coding: utf-8 -*-
"""Fill the confirmation test report template (1-59).

The report never contains measured results: every result column is written as
``-`` and the conclusion section states that the measurements are still pending.
"""
from . import conformance, derive, plan_content
from .base import SkillError
from .builder import Builder
from .contract import PHRASE_RESULT, PHRASE_TODO, PHRASE_UNKNOWN
from .docxlib import Paragraph

_LEADING_ORDINAL = __import__("re").compile(r"^\s*[（(]\s*\d+\s*[）)]\s*")


def _title_map(feip, uids):
    """Requirement titles with duplicates disambiguated by （1）（2）…"""
    cleaned = [derive.clean_title(feip.title(uid)) or feip.normalized_id(uid) for uid in uids]
    return dict(zip(uids, derive.unique_titles(cleaned)))


REPORT_APPENDIX_SECTIONS = (
    ("附录B.2 接口测试", ("interface", "protocol")),
    ("附录B.3 功能测试", ("function", "loading", "language", "tool", "ip", "verification")),
    ("附录B.4 性能和余量测试", ("performance",)),
    ("附录B.5 边界测试", ("@boundary",)),
    ("附录B.6 强度测试", ("@stress",)),
    ("附录B.7 恢复性测试", ("@recovery",)),
    ("附录B.8 安全性测试", ("reliability",)),
)

TEMPLATE_DEFECT_NOTE = (
    "模板自身缺陷提示：模板第 4 章的“4.2测试覆盖性要求”“4.3测试策略与方法”为手工编号，"
    "而“测试项目”为自动编号标题（同样得到 4.2）；按“严格按模板”未做消重，请评审时知悉。"
)


def build(doc, ctx, plan_doc_texts=None):
    b = Builder(doc, ctx["gaps"], ctx)
    b.strip_comments()
    b.strip_example_markers()
    _drop_empty_heading(b)
    ctx["report_builder"] = b

    _basic_info(b, ctx)
    _document_overview(b, ctx)
    _acronyms(b, ctx)
    _references(b, ctx)
    _system_overview(b, ctx)
    _development_environment(b, ctx)
    _functional_sections(b, ctx)
    _performance(b, ctx)
    _interface_definition(b, ctx)
    _interface_timing(b, ctx)
    _test_overview(b, ctx)
    _test_summary(b, ctx)
    _appendix_a(b, ctx)
    _appendix_b(b, ctx)
    _appendix_c(b, ctx)
    _appendix_d(b, ctx)
    _appendix_e(b, ctx)
    verdicts = _appendix_f(b, ctx)
    _rollup_summary(b, ctx, verdicts)
    b.note("report.template_defect_note", "d6", value=TEMPLATE_DEFECT_NOTE)

    _drop_stray_dots(b)
    b.substitute(ctx["substitutions"])
    b.substitute_in_tables(ctx["substitutions"])
    return b


def _drop_empty_heading(b):
    """Neutralise the empty Heading 1, keeping any section break it carries."""
    kept = 0
    for para in b.doc.paragraphs():
        if para.style not in ("1", "2", "3", "4"):
            continue
        if para.text.strip():
            continue
        if "<w:sectPr" in para.raw:
            b.doc.set_block(para.index, plan_content._strip_heading_style(para.raw))
            kept += 1
        else:
            b.doc.delete_block(para.index)
    if kept:
        b.note("defect.empty_heading", "template", value="section break preserved (%d)" % (kept,))


def _drop_stray_dots(b):
    plan_content._drop_stray_dots(b)


def _basic_info(b, ctx):
    fields = (
        ("FPGA产品名称", ctx["product"], "report.1.1.product_name"),
        ("FPGA产品代号", ctx["config_code"], "report.1.1.config_item_code"),
        ("研制类型", ctx["development_type"], "report.1.1.development_type"),
        ("安全关键等级", ctx["safety_level"], "report.1.1.safety_level"),
        ("继承基线", ctx["maintenance_base"], "report.1.1.maintenance_base"),
        ("交办方", ctx["assigner"], "report.1.1.assigner"),
        ("承制方", ctx["contractor"], "report.1.1.contractor"),
    )
    for label, value, slot in fields:
        b.set_label_value(label, value, slot, "basic_info")


def _document_overview(b, ctx):
    lines = [
        "本文件为 %s %s 版本的设计确认报告，目的在于总结设计确认阶段的工作、汇总确认测试计划与测试细则，"
        "并对配置项满足《%s》的情况给出结论性说明。"
        % (ctx["product"], ctx["version"] or "", ctx["basis_title"]),
        "本文件的预期读者为 FPGA 研制人员、用户、质量保证人员、高层管理者和需要阅读本报告的其他人员。",
        "本文件中，测试用例标识的命名规则为“%s-<测试类型码>-<序号>”，用例表中的“编号”列给出与追溯矩阵、"
        "覆盖报告一致的用例标识。" % (derive.STAGE_PREFIX,),
        "本版本未包含实测结果，相关结论待测试执行后确认。",
    ]
    b.replace_region("文档概述", "符号和缩略语", lines, "report.1.2", "derived")


def _acronyms(b, ctx):
    rows = []
    for entry in ctx["feip"].acronyms():
        abbreviation = entry.get("abbreviation") or ""
        meaning = (entry.get("meaning") or {}).get("value") or (entry.get("full_name") or {}).get("value")
        if abbreviation:
            rows.append([abbreviation, meaning or PHRASE_UNKNOWN])
    if not rows:
        rows = [["—", "本文件使用的缩略语以任务书术语为准。"]]
    b.replace_region("符号和缩略语", "引用文件", [], "report.1.3", "model.acronyms")
    heading = b.find("符号和缩略语")
    proto = plan_content._reference_table_prototype(b)
    raw = plan_content._simple_table(proto.raw, ["缩略语", "含义"], rows)
    b.doc.insert_after(heading.index, [raw])
    b.note("report.1.3.table", "model.acronyms", value=len(rows))


def _references(b, ctx):
    feip = ctx["feip"]
    for kind, heading, slot in (
        ("normative", "规范性引用文件", "report.2.1"),
        ("development", "研制依据引用文件", "report.2.2"),
    ):
        rows = []
        for doc in feip.references(kind):
            identifier = (doc.get("identifier") or {}).get("value") or PHRASE_UNKNOWN
            rows.append([identifier, doc.get("title") or ""])
        if not rows:
            rows = [[PHRASE_TODO, PHRASE_TODO]]
        table = b.table_after(b.find(heading))
        table = table.with_borders()
        b.doc.set_block(table.index, table.raw)
        b.fill_table(
            table,
            [["文件编号", "文件名称"]] + rows,
            slot,
            "reference_documents[%s]" % (kind,),
            header_rows=0,
        )


def _system_overview(b, ctx):
    overview = ctx["overview"]
    lines = []
    if overview["host_unit"]:
        lines.append("被测 FPGA 位于%s。" % (overview["host_unit"],))
    if overview["main_functions"]:
        lines.append("主要功能包括：%s。" % (overview["main_functions"],))
    if overview["subsystem_composition"]:
        lines.append("系统组成与数据流：%s。" % (overview["subsystem_composition"],))
    lines.append("长期加电要求：%s。" % (overview["long_term_power_on"],))
    b.replace_region("系统概述", "FPGA开发环境", lines, "report.3.1", "system_overview")


def _statement(ctx, uid, location):
    """Clean requirement statement; degraded upstream fragments become a gap."""
    feip = ctx["feip"]
    raw = feip.statement(uid)
    text = derive.clean_statement(raw)
    if not text:
        ctx["gaps"].add(
            "absent",
            location,
            "requirements[%s].semantic.statement" % (feip.normalized_id(uid),),
            "上游需求原文退化为表格单元格片段，无法作为正文使用",
            "正文描述缺失",
            "回归档表 cells[] 重建该条需求原文",
        )
        return PHRASE_UNKNOWN
    return text


def _development_environment(b, ctx):
    feip = ctx["feip"]
    lines = []
    for category in ("language", "tool"):
        for uid in feip.by_category(category):
            statement = _statement(ctx, uid, "report.3.2")
            if statement and statement != PHRASE_UNKNOWN:
                lines.append(statement)
    if not lines:
        lines = [PHRASE_UNKNOWN]
        ctx["gaps"].add("absent", "report.3.2", "开发环境", "任务书未给出编程语言与开发工具要求", "3.2 FPGA开发环境")
    b.replace_region("FPGA开发环境", "功能概述", lines, "report.3.2", "requirements[language/tool]")


def _functional_sections(b, ctx):
    """3.3 功能概述 lists every function requirement in one section."""
    feip = ctx["feip"]
    uids = feip.by_category("function")
    lines = []
    for index, uid in enumerate(uids):
        statement = _statement(ctx, uid, "report.3.3")
        # the upstream statement already carries its own "(n)" prefix
        statement = _LEADING_ORDINAL.sub("", statement).strip()
        lines.append("%d）%s" % (index + 1, statement))
    if not lines:
        lines = [PHRASE_UNKNOWN]
    b.replace_region("功能概述", "性能要求", lines, "report.3.3", "requirements[function]")
    b.note("report.3.3", "requirements[function]", value=len(lines))


def _performance(b, ctx):
    feip = ctx["feip"]
    lines = []
    for uid in feip.by_category("performance"):
        lines.append("%s（%s）" % (_statement(ctx, uid, "report.3.4"), feip.normalized_id(uid)))
    if not lines:
        lines = [PHRASE_UNKNOWN]
    b.replace_region("性能要求", "设计要求", lines, "report.3.4", "requirements[performance]")


def _interface_definition(b, ctx):
    feip = ctx["feip"]
    interfaces = feip.interfaces()
    lines = ["FPGA 对外接口共 %d 组，分组及主要信号如下：" % (len(interfaces),)]
    for interface in interfaces[:20]:
        header = interface.get("header") or {}
        name = header.get("name") or ""
        signals = interface.get("signal_refs") or []
        names = [ref.split(":")[-1] for ref in signals]
        if name:
            lines.append("%s：%s。" % (name, "、".join(names) if names else PHRASE_UNKNOWN))
    if not interfaces:
        lines = [PHRASE_UNKNOWN]
        ctx["gaps"].add("absent", "report.3.5.1", "interfaces", "任务书未给出接口定义", "3.5.1 接口定义")
    b.replace_region("接口定义", "接口时序", lines, "report.3.5.1", "analysis.interfaces")


def _interface_timing(b, ctx):
    feip = ctx["feip"]
    clock_lines = []
    other_lines = []
    for uid in feip.by_category("interface") + feip.by_category("protocol"):
        statement = derive.clean_statement(feip.statement(uid))
        if not statement:
            continue
        if "时钟" in statement or "复位" in statement:
            clock_lines.append(statement)
        elif len(other_lines) < 30:
            other_lines.append(statement)
    if not clock_lines:
        clock_lines = [PHRASE_UNKNOWN]
    if not other_lines:
        other_lines = [PHRASE_UNKNOWN]

    sub1 = b.find("时钟和复位接口")
    body_proto = b.doc.paragraph(sub1.index + 1) if b.doc.block_kind(sub1.index + 1) == "p" else None
    sub2 = b.find_contains("接口", start=sub1.index + 1)
    # replace whole 3.5.2 body: from first subsection to next heading of level <= 3
    end = None
    for index in range(sub1.index + 1, b.doc.block_count()):
        if b.doc.block_kind(index) != "p":
            continue
        para = b.doc.paragraph(index)
        if para.style in ("1", "2", "3") and para.text.strip():
            end = index
            break
    if end is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "cannot find end of 接口时序 section", {})
    targets = []
    for index in range(sub1.index, end):
        if b.doc.block_kind(index) == "p":
            targets.append(index)
    b._write_lines(targets, [], "report.3.5.2.old", "derived")
    anchor = b.find("接口时序")
    heading_raw = sub1.raw
    body_raw = body_proto.raw if body_proto is not None else heading_raw
    payload = [
        Paragraph(-1, heading_raw).with_text("时钟和复位接口"),
        Paragraph(-1, body_raw).with_text("\n".join(clock_lines[:12])),
        Paragraph(-1, heading_raw).with_text("数据与指令接口"),
        Paragraph(-1, body_raw).with_text("\n".join(other_lines[:40])),
    ]
    b.doc.insert_after(anchor.index, payload)
    b.note("report.3.5.2", "requirements[interface/protocol]", value=2)


def _test_overview(b, ctx):
    """4.1 表1 keeps the template's six environment categories."""
    rows = [
        ["", ctx["product"], ctx["config_code"], "受控库", "1套"],
        ["", "联试设备", PHRASE_TODO, PHRASE_TODO, "1套"],
        ["", "FPGA软件", PHRASE_TODO, "受控库", "1套"],
        ["", "星上产品", PHRASE_TODO, PHRASE_TODO, "1套"],
        ["", "万用表", PHRASE_TODO, PHRASE_TODO, "1台"],
        ["", "示波器", PHRASE_TODO, PHRASE_TODO, "1台"],
    ]
    table = b.table_after(b.find_contains("FPGA设计确认环境及工具表"))
    b.fill_table(table, rows, "report.4.1.table1", "template categories + gap")

    spec = ctx["spec"]
    lines = [
        "本报告对应《%s》中设计的全部测试用例与证据程序，共 %d 个测试项目、%d 项。"
        % (ctx["basis_title"], len(ctx["projects"]), ctx["stats"]["total"]),
        "测试按附录B 的测试工作记录表逐项执行，将实际结果填入表格并与期望结果比较；"
        "本版本尚未绑定执行记录，实际结果与测试结论列均为预留。",
        "覆盖率口径：需求覆盖率与测试要点覆盖率以有效需求为分母；本版本计划覆盖率为 100%。",
    ]
    b.replace_region("测试说明", "测试用例统计", lines, "report.4.2", "derived")


def _test_summary(b, ctx):
    spec = ctx["spec"]
    rows = [[None, project.label, project.ident, str(project.count), PHRASE_RESULT] for project in ctx["projects"]]
    b.set_text(
        "本次设计确认的",
        "本次设计确认共 %d 个测试项目、%d 项测试用例与证据程序，执行情况见下表。"
        % (len(ctx["projects"]), ctx["stats"]["total"]),
        "report.4.3.lead_in",
        "derived",
        optional=True,
    )
    table = b.table_after(b.find_contains("测试用例统计表"))
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing report statistics table", {})
    table = b.fill_table(table, rows, "report.4.3.table2", "derived", tail_rows=1)
    total_row = table.row(table.row_count() - 1)
    count = total_row.cell_count()
    if count >= 2:
        total_row = total_row.set_cell_text(count - 2, str(ctx["stats"]["total"]))
        total_row = total_row.set_cell_text(count - 1, PHRASE_RESULT)
        b.doc.set_block(table.index, table.replace_row(table.row_count() - 1, total_row))

    index = derive.test_point_index(spec, ctx["feip"])
    rows = []
    for point_uid, item_ids in index.items():
        point = ctx["feip"].test_point(point_uid) or {}
        ident = derive.test_point_ident(point)
        note = "" if item_ids else "不可测试项"
        rows.append(["", ident, "、".join(item_ids) or "无", note])
    if not rows:
        rows = [["", "无", "无", "无"]]
    table = b.table_after(b.find_contains("测试要点跟踪表"))
    if table is not None:
        b.fill_table(table, rows, "report.4.4.table3", "source_test_points + RTM")

    rows = []
    for item in spec.items:
        if item["status"] == "READY":
            continue
        rows.append(
            [
                "",
                "%s %s" % (item["id"], derive.clean_title(item["title"])),
                ctx["version"] or PHRASE_TODO,
                "；".join(item["open_items"]) or PHRASE_UNKNOWN,
                PHRASE_TODO,
            ]
        )
    if not rows:
        rows = [["", "无", "—", "本版本未识别不可测试项", "—"]]
    table = b.table_after(b.find_contains("不可测试项跟踪表"))
    if table is not None:
        b.fill_table(table, rows, "report.4.5.table4", "status!=READY")

    rows = []
    feip = ctx["feip"]
    safety_uids = derive.reliability_requirement_ids(feip)
    safe_titles = _title_map(feip, safety_uids)
    for uid in safety_uids:
        linked = spec.rtm_linked_ids(uid)
        rows.append(["", feip.normalized_id(uid), safe_titles[uid], "、".join(linked) or "无", ""])
    if not rows:
        rows = [["", "无", "无", "无", ""]]
    table = b.table_after(b.find_contains("安全关键功能测试用例对应表"))
    if table is not None:
        b.fill_table(table, rows, "report.4.6.table5", "requirements[reliability]")

    result_lines = [
        "本版本已按《%s》完成 %d 个测试项目、%d 项测试用例与证据程序的设计，"
        "尚未绑定执行记录，实测通过率与覆盖率数据待测试执行后补充。"
        % (ctx["basis_title"], len(ctx["projects"]), ctx["stats"]["total"]),
        "计划覆盖率：需求覆盖率 100%%；细则追溯覆盖率 %s。"
        % (_metric_text(ctx),),
    ]
    b.replace_region("测试结果分析", "技术指标符合性", result_lines, "report.5.1", "coverage_report")

    function_rows = []
    for uid in feip.by_category("function"):
        statement = _statement(ctx, uid, "report.5.2")
        function_rows.append(["", ctx["product"], statement or PHRASE_UNKNOWN, "", PHRASE_RESULT])
    if not function_rows:
        function_rows = [["", ctx["product"], PHRASE_UNKNOWN, "", PHRASE_RESULT]]
    table = b.table_after(b.find_contains("设计符合情况对照表"))
    if table is not None:
        header = table.row(0)
        cells = [cell.raw for cell in header.cells()]
        if len(cells) >= 4 and not header.cell(3).text.strip():
            cells[3] = header.cell(3).with_text("技术指标")
            b.doc.set_block(table.index, table.replace_row(0, header.with_cells(cells)))
            table = b.doc.table(table.index)
        b.fill_table(table, function_rows, "report.5.2.table6", "requirements[function]")

    conclusion = [
        "本版本未包含实测结果，测试结论待测试执行后确认。",
        "测试结论按以下三种情形之一给出：全部用例通过且覆盖达到要求时为通过；发现问题但处理措施明确、"
        "风险经认可时为带风险通过；发现问题影响严重或未通过率超过 20% 时为不通过或测试异常终止。",
        "本次确认测试是否通过，以测试执行记录与《%s》的符合性为准。" % (ctx["basis_title"],),
    ]
    b.replace_region("测试结论", "附录A", conclusion, "report.5.4", "d4")


def _metric_text(ctx):
    metrics = ctx["spec"].coverage_metrics() or {}
    value = metrics.get("design_trace_coverage_percent")
    if value is None:
        return PHRASE_UNKNOWN
    return "%.2f%%" % (float(value),)


def _appendix_a(b, ctx):
    table = b.table_after(b.find_contains("FPGA设计确认工作准备状态检查表"))
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing readiness checklist", {})
    table = b.set_cells_in_rows(table, 1, {0: ctx["product"]}, "report.appendixA.name", "basic_info.product_name")
    meta = {}
    for row_index, row in enumerate(table.rows()):
        if row_index != 1:
            continue
        texts = [cell.replace("\t", "") for cell in row.texts()]
        meta = texts
        break
    if meta:
        row = table.row(1)
        cells = [cell.raw for cell in row.cells()]
        changed = False
        for index, text in enumerate(meta):
            if text.strip() in ("××××", "×楼×房间", "C/Z"):
                cells[index] = row.cell(index).with_text(PHRASE_TODO)
                changed = True
        if changed:
            b.doc.set_block(table.index, table.replace_row(1, row.with_cells(cells)))
            table = b.doc.table(table.index)
    results = plan_content._readiness(b, ctx, "report")
    b.note("report.appendixA.result", "readiness_rules.json", value=len(results))


def _appendix_b(b, ctx):
    plan_content._delete_example_tables(b)
    intro = [
        "本附录给出全部测试用例与证据程序，表格按测试项目组织。"
        "“实际结果”“测试结论”为执行阶段填写项，本版本为预留状态。",
        "评估准则：每个操作步骤的实际结果与期望结果一致；终止条件为正常执行完所有操作步骤，"
        "或在执行过程中某一操作步骤的实际结果与期望结果不一致。",
    ]
    b.replace_region("附录B.1 测试记录表说明", "附录B.2 接口测试", intro, "report.appendixB.1", "derived")
    for position, (heading, categories) in enumerate(REPORT_APPENDIX_SECTIONS):
        if position + 1 < len(REPORT_APPENDIX_SECTIONS):
            end_heading = REPORT_APPENDIX_SECTIONS[position + 1][0]
        else:
            end_heading = "附录C"
        scenario_based = any(category.startswith("@") for category in categories)
        if scenario_based:
            selected = plan_content._items_for_categories(ctx, categories)
            if selected:
                ids = [item["id"] for item in selected]
                shown = ids if len(ids) <= 12 else ids[:12] + ["…"]
                lines = [
                    "本类用例共 %d 项，已在所属测试项目表的“健壮性”列中标注为实心方框，编号：%s。"
                    % (len(selected), "、".join(shown))
                ]
            else:
                lines = ["本版本无此类测试用例。"]
            b.replace_region(heading, end_heading, lines, "report." + heading, "derived")
            continue
        projects = [project for project in ctx["projects"] if project.category in categories]
        if not projects:
            b.replace_region(heading, end_heading, ["本版本无此类测试用例。"], "report." + heading, "derived")
            continue
        b.replace_region(heading, end_heading, [], "report." + heading + ".body", "derived")
        anchor = b.find(heading)
        insert_at = anchor.index
        for project in projects:
            for raw in plan_content._build_case_tables(project, ctx):
                b.doc.insert_after(insert_at, [raw, "<w:p/>"])
                insert_at += 2
            b.note("report." + heading + "." + project.ident, "test_cases", value=project.count)


def _appendix_c(b, ctx):
    table = b.table_after(b.find_contains("问题报告单"))
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing problem report form", {})
    rebuilt = []
    for row_index, row in enumerate(table.rows()):
        cells = []
        for cell in row.cells():
            text = _clean_form_cell(cell.text)
            if text != cell.text:
                cells.append(cell.with_text(text))
            else:
                cells.append(cell.raw)
        row = row.with_cells(cells)
        texts = [cell.replace("\t", "") for cell in row.texts()]
        first = texts[0].strip() if texts else ""
        if first == "严重等级":
            row = _apply_pattern(
                row,
                ["严重等级", "□", "致命问题", "□", "严重问题", "□", "一般问题", "□", "轻微问题", "□", "改进建议"],
            )
        elif first == "问题类别":
            row = _apply_pattern(
                row, ["问题类别", "□", "文档问题", "□", "设计问题", "□", "程序问题", "□", "其他问题", "□"]
            )
        texts = [cell.replace("\t", "") for cell in row.texts()]
        if row_index == 0 and len(texts) >= 2:
            row = row.set_cell_text(1, "%s %s版本" % (ctx["product"], ctx["version"] or ""))
        rebuilt.append(row.raw)
    b.doc.set_block(table.index, table.with_rows(rebuilt))
    b.note("report.appendixC", "d12", value="checkboxes and form hints normalised")


def _apply_pattern(row, pattern):
    cells = [cell.raw for cell in row.cells()]
    limit = min(len(cells), len(pattern))
    for index in range(limit):
        cell = row.cell(index)
        if cell.text.strip() != pattern[index]:
            cells[index] = cell.with_text(pattern[index])
    return row.with_cells(cells)


_COMMENT_RE = __import__("re").compile(r"/\*.*?\*/", __import__("re").S)
_PLACEHOLDER_RE = __import__("re").compile(
    r"^(XX[-A-Za-z0-9~/\._]*|XXX/XXX|XXX|YYYYMMDD/YYYYMMDD|YYYYMMDD|【.*】)$"
)


def _clean_form_cell(text):
    """Strip guidance comments and unfilled placeholder codes from a form cell."""
    if not text:
        return text
    cleaned = _COMMENT_RE.sub("", text)
    cleaned = cleaned.replace("■", "□")
    cleaned = " ".join(cleaned.split()) if "\n" not in cleaned else cleaned
    cleaned = cleaned.strip()
    if not cleaned:
        return ""
    if _PLACEHOLDER_RE.match(cleaned):
        return ""
    return cleaned


def _appendix_d(b, ctx):
    spec = ctx["spec"]
    feip = ctx["feip"]
    requirements = ctx["rtm_requirements"]
    titles = _title_map(feip, requirements)
    rows = []
    for uid in requirements:
        linked = spec.rtm_linked_ids(uid)
        rows.append(["", "、".join(linked) or "无", "", feip.normalized_id(uid), titles[uid], ""])
    if not rows:
        rows = [["", "无", "", "", "", ""]]
    table = b.table_after(b.find_contains("逆向跟踪矩阵"))
    if table is not None:
        b.fill_table(table, rows, "report.D.1", "RTM.csv", header_rows=2)

    rows = []
    for uid in requirements:
        if spec.rtm_linked_ids(uid):
            continue
        rows.append(["", feip.normalized_id(uid), titles[uid], "", "无", "不可测试项或未覆盖"])
    if not rows:
        rows = [["", "无", "无", "", "无", "无未覆盖项"]]
    table = b.table_after(b.find_contains("正向跟踪矩阵"))
    if table is not None:
        b.fill_table(table, rows, "report.D.2", "RTM.csv", header_rows=2)


def _appendix_e(b, ctx):
    table = b.table_after(b.find_contains("更改记录"))
    if table is None:
        raise SkillError("TEMPLATE_ANCHOR_MISSING", "missing change log table", {})
    b.doc.set_block(table.index, table.with_rows([table.row(0).raw]))
    b.note("report.appendixE", "d14", value="header only")
    targets = []
    for para in b.doc.paragraphs():
        text = para.text.strip()
        if text.startswith("V1.01版本更改记录表") or text.startswith("V1.02版本更改记录表") or text == "….":
            targets.append(para.index)
    if targets:
        b.doc.delete_blocks(targets)
        b.note("report.appendixE.placeholders", "d14", status="deleted", value=len(targets))


def _appendix_f(b, ctx):
    rules = conformance.load_rules()
    verdicts = conformance.evaluate(rules, ctx, b.doc, "report")
    conformance.apply_to_table(b.doc, "技术要素确认检查表", 5, verdicts, chapter_column=4)
    ctx["report_verdicts"] = verdicts
    b.note("report.appendixF", "conformance_rules.json", value=conformance.summarise(verdicts))
    return verdicts


def _rollup_summary(b, ctx, verdicts):
    """5.3 表7 is the roll-up of 附录F and must cover every checklist item.

    The template's table 7 only lists 21 of the 27 checks (it omits 器件选型,
    单粒子防护设计 and the three 在轨维护设计 rows), so the table is rebuilt from
    the appendix F verdicts: one row per 要素名称, a 合计 row per category block,
    and the totals therefore add up to the appendix.
    """
    from . import conformance

    summary = conformance.summarise(verdicts)
    lines = [
        "FPGA 确认测试报告通用技术要素 3 类、共计 %d 个检查项。检查结果为 %d 项满足、%d 项不满足、"
        "%d 项不适用、%d 项待实测，详见下表。"
        % (
            len(verdicts),
            summary[conformance.VERDICT_OK],
            summary[conformance.VERDICT_BAD],
            summary[conformance.VERDICT_NA],
            summary[conformance.VERDICT_PENDING],
        )
    ]
    b.set_text("FPGA确认测试报告通用技术要素", lines[0], "report.5.3.lead_in", "appendixF", optional=True)
    entries = conformance.rollup_rows(verdicts)

    table = b.table_after(b.find_contains("技术要素自确认结果统计"))
    if table is None:
        return
    rows = table.rows()
    if len(rows) < 2:
        return
    header_raw = rows[0].raw
    data_proto = rows[1]
    total_proto = None
    for row in rows:
        texts = [text.replace("\t", "") for text in row.texts()]
        if texts and "合计" in texts[0]:
            total_proto = row
            break
    if total_proto is None:
        total_proto = rows[-1]

    generic = [entry for entry in entries if "专用" not in entry["category"]]
    special = [entry for entry in entries if "专用" in entry["category"]]

    rebuilt = [header_raw]
    rebuilt.extend(_rollup_block(data_proto, generic))
    rebuilt.append(_rollup_total(total_proto, generic))
    if special:
        rebuilt.extend(_rollup_block(data_proto, special))
        rebuilt.append(_rollup_total(total_proto, special))
    b.doc.set_block(table.index, table.with_rows(rebuilt))
    b.note(
        "report.5.3.table7",
        "appendixF rollup (all %d checks)" % (len(entries),),
        value={
            "rows": len(rebuilt) - 1,
            "checks": sum(entry["checks"] for entry in entries),
            "satisfied": sum(entry["satisfied"] for entry in entries),
        },
    )


def _rollup_block(prototype, entries):
    """One row per 要素名称; the category is printed on its first row only."""
    out = []
    last_category = None
    for entry in entries:
        category = entry["category"]
        if not category.endswith("要素"):
            category = category + "要素"
        values = [
            "",
            category if category != last_category else "",
            entry["item"],
            str(entry["checks"]),
            str(entry["satisfied"]),
            str(entry["unsatisfied"]),
            str(entry["not_applicable"]),
        ]
        last_category = category
        row = prototype
        for index, value in enumerate(values):
            if index < row.cell_count():
                row = row.set_cell_text(index, value)
        out.append(row.raw)
    return out


def _rollup_total(prototype, entries):
    """合计 row: the first cell spans 序号/类别/名称, then four numeric cells."""
    checks = sum(entry["checks"] for entry in entries)
    satisfied = sum(entry["satisfied"] for entry in entries)
    unsatisfied = sum(entry["unsatisfied"] for entry in entries)
    not_applicable = sum(entry["not_applicable"] for entry in entries)
    values = [str(checks), str(satisfied), str(unsatisfied), str(not_applicable)]
    row = prototype
    count = row.cell_count()
    start = max(1, count - 4)
    for offset, value in enumerate(values):
        index = start + offset
        if 0 < index < count:
            row = row.set_cell_text(index, value)
    return row.raw
