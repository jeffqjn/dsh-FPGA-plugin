# -*- coding: utf-8 -*-
"""Zero dependency regression checks for the deterministic parts.

Run with ``cli.py self-test`` (needs 3.8.10) or directly with any Python via
``tests/run_tests.py``.  Nothing here touches the network or an LLM.
"""
import os
import shutil
import tempfile

from . import contract, derive
from .base import SkillError, canonical_sha256, read_json, write_json
from .docxlib import Docx, Table, fragment_text

RESULTS = []


def _ok(name):
    RESULTS.append({"test": name, "status": "pass"})


def _rejects(name, function, code):
    try:
        function()
    except SkillError as exc:
        if exc.code != code:
            RESULTS.append({"test": name, "status": "fail", "detail": "wrong code: %s" % (exc.code,)})
            return
        RESULTS.append({"test": name, "status": "pass", "code": code})
        return
    RESULTS.append({"test": name, "status": "fail", "detail": "no error raised"})


def test_escape_roundtrip():
    from .docxlib import escape_text, unescape_text

    sample = "a&b<c>d\"e'f"
    if unescape_text(escape_text(sample)) != sample:
        raise AssertionError("escape roundtrip failed")
    _ok("escape roundtrip")


def test_template_roundtrip():
    for kind in (contract.DOC_PLAN, contract.DOC_REPORT):
        source = contract.template_path(kind)
        doc = Docx(source)
        tmp = tempfile.mkdtemp(prefix="confdoc-selftest-")
        try:
            target = os.path.join(tmp, "out.docx")
            doc.save(target)
            import zipfile

            with zipfile.ZipFile(source) as left, zipfile.ZipFile(target) as right:
                if left.read("word/document.xml") != right.read("word/document.xml"):
                    raise AssertionError("document.xml changed on a no-op save: %s" % (kind,))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    _ok("template roundtrip is byte identical")


def test_heading_tree():
    doc = Docx(contract.template_path(contract.DOC_PLAN))
    tree = doc.heading_tree()
    if not tree:
        raise AssertionError("no headings parsed")
    if tree[0]["number"] != "1" or tree[0]["text"] != "前言":
        raise AssertionError("unexpected first heading: %r" % (tree[0],))
    if tree[1]["number"] != "1.1":
        raise AssertionError("unexpected second heading: %r" % (tree[1],))
    _ok("heading numbering reconstructed")


def test_paragraph_rewrite():
    doc = Docx(contract.template_path(contract.DOC_PLAN))
    para = doc.find_paragraph(text_prefix="FPGA产品名称")
    doc.set_block(para.index, para.with_text("FPGA产品名称：单元测试"))
    if doc.paragraph(para.index).text.strip() != "FPGA产品名称：单元测试":
        raise AssertionError("paragraph text not rewritten")
    _ok("paragraph rewrite keeps properties")


def test_table_cell_write():
    doc = Docx(contract.template_path(contract.DOC_PLAN))
    table = doc.tables()[0]
    row = table.row(1).set_cell_text(1, "写入测试")
    doc.set_block(table.index, table.replace_row(1, row))
    if doc.tables()[0].row(1).texts()[1] != "写入测试":
        raise AssertionError("cell write failed")
    _ok("table cell write")


def test_canonical_digest():
    payload = {"b": 1, "a": [1, 2]}
    left = canonical_sha256(payload)
    right = canonical_sha256({"a": [1, 2], "b": 1})
    if left != right:
        raise AssertionError("canonical digest is order dependent")
    _ok("canonical digest is key order independent")


def test_json_guards():
    tmp = tempfile.mkdtemp(prefix="confdoc-selftest-")
    try:
        path = os.path.join(tmp, "dup.json")
        with open(path, "wb") as handle:
            handle.write(b'{"a": 1, "a": 2}')
        _rejects("duplicate JSON key rejected", lambda: read_json(path), "JSON_DUPLICATE_KEY")
        path2 = os.path.join(tmp, "nan.json")
        with open(path2, "wb") as handle:
            handle.write(b'{"a": NaN}')
        _rejects("NaN rejected", lambda: read_json(path2), "JSON_INVALID_CONSTANT")
        write_json(os.path.join(tmp, "ok.json"), {"中文": 1})
        if read_json(os.path.join(tmp, "ok.json"))["中文"] != 1:
            raise AssertionError("roundtrip failed")
        _ok("json write/read roundtrip")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_derive_order():
    order = derive.CATEGORY_ORDER
    if list(order) != sorted(order, key=derive.category_rank):
        raise AssertionError("category rank is not consistent")
    if derive.method_label("board_test") != "板级测试":
        raise AssertionError("method label missing")
    _ok("derived vocabulary")


def test_unsafe_paths():
    for bad in ("..", ".", "a/b", "a\\b", "c:x"):
        _rejects("unsafe path rejected: %s" % bad, lambda bad=bad: _safe_join(bad), "UNSAFE_PATH")


def _safe_join(segment):
    from .base import safe_join

    return safe_join("root", segment)


def test_missing_anchor():
    doc = Docx(contract.template_path(contract.DOC_PLAN))
    _rejects(
        "missing anchor reported",
        lambda: doc.find_paragraph(text_prefix="不存在的锚点"),
        "TEMPLATE_ANCHOR_MISSING",
    )


def test_fragment_text_skips_ppr():
    doc = Docx(contract.template_path(contract.DOC_PLAN))
    for para in doc.paragraphs():
        text = para.text
        if "\t" in text and not text.strip():
            continue
    _ok("paragraph text extraction")


def run_all():
    del RESULTS[:]
    tests = (
        test_escape_roundtrip,
        test_template_roundtrip,
        test_heading_tree,
        test_paragraph_rewrite,
        test_table_cell_write,
        test_canonical_digest,
        test_json_guards,
        test_derive_order,
        test_unsafe_paths,
        test_missing_anchor,
        test_fragment_text_skips_ppr,
    )
    for test in tests:
        try:
            test()
        except Exception as exc:  # noqa: BLE001 - collect, do not abort
            RESULTS.append({"test": test.__name__, "status": "fail", "detail": str(exc)})
    failed = [entry for entry in RESULTS if entry["status"] != "pass"]
    return {
        "tests": len(RESULTS),
        "passed": len(RESULTS) - len(failed),
        "failed": failed,
        "scope": "deterministic helpers; agent semantics and a real Win7 host still need acceptance",
    }
