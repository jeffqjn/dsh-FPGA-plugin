# -*- coding: utf-8 -*-
"""Reader and validator for the test-specification family outputs.

Consumes ``test_specification.json`` (mandatory) and optionally
``verification_plan.json``, ``coverage_report.json`` and ``RTM.csv``.
"""
import csv
import io
import os

from .base import SkillError, canonical_sha256, read_json

CASE_METHODS = ("board_test", "system_test")
PROCEDURE_METHODS = ("inspection", "analysis", "timing_analysis", "review")
ALL_METHODS = CASE_METHODS + PROCEDURE_METHODS
ROBUST_SCENARIOS = ("boundary", "abnormal", "stress", "recovery")

RTM_COLUMNS = (
    "requirement_uid",
    "revision_uid",
    "planning_status",
    "obligation_id",
    "method",
    "scenario_type",
    "criterion_ref",
    "linked_specification_ids",
    "ready_specification_ids",
    "execution_status",
)


def load_rtm(path):
    rows = []
    with io.open(path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(dict((key, (value or "")) for key, value in row.items() if key))
    if rows:
        missing = [name for name in RTM_COLUMNS[:7] if name not in rows[0]]
        if missing:
            raise SkillError(
                "RTM_INVALID", "RTM.csv is missing columns: %s" % (", ".join(missing),), {}
            )
    return rows


class Specification(object):
    def __init__(self, spec_path, plan_path=None, coverage_path=None, rtm_path=None):
        self.spec_path = os.path.abspath(spec_path)
        if not os.path.isfile(self.spec_path):
            raise SkillError(
                "SPEC_NOT_FOUND", "test specification not found", {"path": self.spec_path}
            )
        self.raw = read_json(self.spec_path)
        self.schema_version = self.raw.get("schema_version")
        if self.schema_version != "2.0":
            raise SkillError(
                "SPEC_VERSION_UNSUPPORTED",
                "test_specification schema_version must be 2.0, found %s" % (self.schema_version,),
                {},
            )
        self.source_plan_sha256 = self.raw.get("source_plan_sha256")
        self.approved_simulation = self.raw.get("approved_simulation")
        self.cases = self.raw.get("test_cases") or []
        self.procedures = self.raw.get("evidence_procedures") or []
        if not self.cases and not self.procedures:
            raise SkillError("SPEC_EMPTY", "specification has no test cases or procedures", {})

        self.plan_path = os.path.abspath(plan_path) if plan_path else None
        self.plan = read_json(self.plan_path) if self.plan_path else None
        self.coverage_path = os.path.abspath(coverage_path) if coverage_path else None
        self.coverage = read_json(self.coverage_path) if self.coverage_path else None
        self.rtm_path = os.path.abspath(rtm_path) if rtm_path else None
        self.rtm = load_rtm(self.rtm_path) if self.rtm_path else []

        self.issues = []
        self.warnings = []
        self._plan_index = {}
        self._obligation_index = {}
        self._build_plan_index()
        self.items = self._unify()
        self._index_items()

    # -- plan ------------------------------------------------------------
    def _build_plan_index(self):
        if not self.plan:
            return
        for item in self.plan.get("verification_items") or []:
            requirement_uid = item.get("requirement_uid")
            obligations = item.get("verification_obligations") or []
            for obligation in obligations:
                obligation_id = obligation.get("obligation_id") or obligation.get("source_obligation_uid")
                if obligation_id:
                    self._obligation_index[obligation_id] = obligation
            if requirement_uid:
                self._plan_index[requirement_uid] = item

    def plan_item(self, requirement_uid):
        return self._plan_index.get(requirement_uid)

    def planned_obligation(self, obligation_id):
        return self._obligation_index.get(obligation_id)

    def planned_obligation_ids(self):
        return set(self._obligation_index.keys())

    # -- unify -----------------------------------------------------------
    def _unify(self):
        items = []
        for case in self.cases:
            items.append(self._normalise(case, "case", "test_case_id"))
        for procedure in self.procedures:
            items.append(self._normalise(procedure, "procedure", "procedure_id"))
        return items

    def _normalise(self, node, kind, id_key):
        item_id = node.get(id_key)
        if not item_id:
            raise SkillError(
                "SPEC_ITEM_INVALID",
                "item of kind %s has no %s" % (kind, id_key),
                {"kind": kind},
            )
        steps = node.get("steps") or []
        if isinstance(steps, str):
            steps = [steps]
        coverage = node.get("coverage") or []
        return {
            "id": item_id,
            "kind": kind,
            "title": node.get("title") or "",
            "requirement_uids": list(node.get("requirement_uids") or []),
            "obligation_ids": list(node.get("obligation_ids") or []),
            "method": node.get("method") or "",
            "level": node.get("level") or "",
            "status": node.get("status") or "",
            "open_items": list(node.get("open_items") or []),
            "setup": node.get("setup") or "",
            "steps": list(steps),
            "observables": list(node.get("observables") or []),
            "data_to_record": list(node.get("data_to_record") or []),
            "cleanup": node.get("cleanup") or "",
            "coverage": list(coverage),
            "evidence_refs": list(node.get("evidence_refs") or []),
        }

    def _index_items(self):
        self._by_id = {}
        for item in self.items:
            self._by_id[item["id"]] = item
        self._by_requirement = {}
        for item in self.items:
            for uid in item["requirement_uids"]:
                self._by_requirement.setdefault(uid, []).append(item)

    def item(self, item_id):
        return self._by_id.get(item_id)

    def items_of_requirement(self, requirement_uid):
        return list(self._by_requirement.get(requirement_uid) or [])

    def requirement_uids(self):
        return list(self._by_requirement.keys())

    def scenario_types(self, item):
        found = []
        for entry in item["coverage"]:
            scenario = entry.get("scenario_type")
            if scenario and scenario not in found:
                found.append(scenario)
        return found

    def is_robust(self, item):
        for scenario in self.scenario_types(item):
            if scenario in ROBUST_SCENARIOS:
                return True
        return False

    def criterion_refs(self, item):
        found = []
        for entry in item["coverage"]:
            ref = entry.get("criterion_ref")
            if ref and ref not in found:
                found.append(ref)
        return found

    # -- validation ------------------------------------------------------
    def validate(self):
        """Run the pre-generation checks. Raises on fatal, records warnings."""
        self.validate_status_open_items()
        self.validate_methods()
        self.validate_trace_closure()
        digest_checked = self.validate_digest()
        return {"digest_checked": digest_checked, "warnings": list(self.warnings)}

    def validate_status_open_items(self):
        for item in self.items:
            ready = item["status"] == "READY"
            has_open = bool(item["open_items"])
            if ready and has_open:
                self.issues.append(
                    {
                        "code": "SPEC_STATUS_INCONSISTENT",
                        "item": item["id"],
                        "detail": "status=READY but open_items is not empty",
                    }
                )
            if not ready and not has_open:
                self.issues.append(
                    {
                        "code": "SPEC_STATUS_INCONSISTENT",
                        "item": item["id"],
                        "detail": "status=%s but open_items is empty" % (item["status"],),
                    }
                )
        if self.issues:
            raise SkillError(
                "SPEC_STATUS_INCONSISTENT",
                "status and open_items disagree on %d item(s)" % (len(self.issues),),
                {"items": self.issues[:20]},
            )

    def validate_methods(self):
        problems = []
        for item in self.items:
            if item["kind"] == "case" and item["method"] not in CASE_METHODS:
                problems.append(
                    {
                        "item": item["id"],
                        "detail": "test_cases method must be one of %s, found %s"
                        % (",".join(CASE_METHODS), item["method"]),
                    }
                )
            if item["kind"] == "procedure" and item["method"] not in PROCEDURE_METHODS:
                problems.append(
                    {
                        "item": item["id"],
                        "detail": "evidence_procedures method must be one of %s, found %s"
                        % (",".join(PROCEDURE_METHODS), item["method"]),
                    }
                )
        if problems:
            raise SkillError(
                "SPEC_METHOD_MISMATCH",
                "method does not match the item kind for %d item(s)" % (len(problems),),
                {"items": problems[:20]},
            )

    def validate_trace_closure(self):
        if not self.plan:
            self.warnings.append(
                {
                    "code": "PLAN_MISSING",
                    "detail": "verification_plan.json not supplied; obligation level checks skipped",
                }
            )
            return
        known = self.planned_obligation_ids()
        problems = []
        for item in self.items:
            unknown = [oid for oid in item["obligation_ids"] if oid not in known]
            if unknown:
                problems.append({"item": item["id"], "detail": "unknown obligation ids: %s" % (unknown,)})
                continue
            expected = set()
            for obligation_id in item["obligation_ids"]:
                obligation = self.planned_obligation(obligation_id) or {}
                requirement_uid = obligation.get("requirement_uid")
                if requirement_uid:
                    expected.add(requirement_uid)
            actual = set(item["requirement_uids"])
            if expected and actual != expected:
                problems.append(
                    {
                        "item": item["id"],
                        "detail": "requirement_uids %s != obligations' requirements %s"
                        % (sorted(actual), sorted(expected)),
                    }
                )
        if problems:
            raise SkillError(
                "SPEC_TRACE_BROKEN",
                "requirement/obligation traceability is inconsistent on %d item(s)" % (len(problems),),
                {"items": problems[:20]},
            )

    def validate_digest(self):
        if not self.coverage:
            self.warnings.append(
                {"code": "COVERAGE_MISSING", "detail": "coverage_report.json not supplied"}
            )
            return False
        recorded = self.coverage.get("specification_sha256")
        if not recorded:
            self.warnings.append(
                {"code": "COVERAGE_DIGEST_ABSENT", "detail": "coverage report has no specification_sha256"}
            )
            return False
        actual = canonical_sha256(self.raw)
        if actual != recorded:
            self.warnings.append(
                {
                    "code": "SPEC_DIGEST_MISMATCH",
                    "detail": "canonical digest of specification differs from coverage report",
                    "expected": recorded,
                    "actual": actual,
                }
            )
            return False
        return True

    # -- coverage views --------------------------------------------------
    def coverage_counts(self):
        return (self.coverage or {}).get("counts") or {}

    def coverage_metrics(self):
        return (self.coverage or {}).get("metrics") or {}

    def coverage_gaps(self):
        return (self.coverage or {}).get("gaps") or {}

    def design_status(self):
        return (self.coverage or {}).get("design_status")

    def execution_status(self):
        return (self.coverage or {}).get("execution_status")

    def has_execution_results(self):
        return bool((self.coverage or {}).get("execution_status") not in (None, "", "NOT_PROVIDED"))

    # -- rtm views -------------------------------------------------------
    def rtm_requirements(self):
        """Ordered unique requirement uids from RTM, preserving file order."""
        seen = []
        for row in self.rtm:
            uid = row.get("requirement_uid")
            if uid and uid not in seen:
                seen.append(uid)
        return seen

    def rtm_linked_ids(self, requirement_uid):
        linked = []
        for row in self.rtm:
            if row.get("requirement_uid") != requirement_uid:
                continue
            for field in ("linked_specification_ids", "ready_specification_ids"):
                raw = row.get(field) or ""
                for token in raw.split(";"):
                    token = token.strip()
                    if token and token not in linked:
                        linked.append(token)
        return linked

    def rtm_test_point_ids(self, requirement_uid):
        """Test point ids are not in RTM; derived from the plan's obligations."""
        return []
