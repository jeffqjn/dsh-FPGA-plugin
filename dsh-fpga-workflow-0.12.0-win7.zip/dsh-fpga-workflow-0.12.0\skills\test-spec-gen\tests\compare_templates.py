# -*- coding: utf-8 -*-
"""Compare a generated document with its template, section by section.

For every section marker (auto heading 1-4, or a manually numbered paragraph such
as ``7.1测试总体说明`` / ``附录A 测试工作记录表``) it records what the template
puts directly under that section and what the generated document puts there, then
reports every difference: missing sections, paragraph count drift, table count
drift, and per-table header / row-count mismatches.

The differences this tool reports are triaged in
``references/template-conformance.md``: A-class are reviewed structural changes,
B-class are data-driven row counts, C-class invariants must be zero.

Usage:
    set BUILD_DIR=final
    python tests\\compare_templates.py
"""
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
WORKSPACE = os.path.dirname(SKILL)
BUILD = os.path.join(WORKSPACE, "_build", os.environ.get("BUILD_DIR", "final"))
sys.path.insert(0, os.path.join(SKILL, "scripts"))

from confdoc.docxlib import Docx  # noqa: E402

MARK_RE = re.compile(r"^(\d+(\.\d+)*\s*[^\d\s]|附录[A-F]|[A-F]\.\d)")


def is_marker(para):
    text = para.text.strip()
    if not text or len(text) > 48:
        return False
    if para.style in ("1", "2", "3", "4"):
        return True
    return bool(MARK_RE.match(text))


def sections(path):
    doc = Docx(path)
    out = []
    current = {"title": "(文档开头)", "paras": [], "tables": []}
    for index in range(doc.block_count()):
        kind = doc.block_kind(index)
        if kind == "p":
            para = doc.paragraph(index)
            if is_marker(para):
                out.append(current)
                current = {"title": para.text.strip(), "paras": [], "tables": []}
                continue
            text = para.text.strip()
            if text:
                current["paras"].append(text)
        elif kind == "tbl":
            table = doc.table(index)
            header = table.row(0).texts() if table.row_count() else []
            current["tables"].append(
                {
                    "rows": table.row_count(),
                    "cols": max((row.cell_count() for row in table.rows()), default=0),
                    "header": [cell.replace("\n", " ").strip() for cell in header],
                }
            )
    out.append(current)
    return out


def signature(table):
    return "%dx%d %s" % (table["rows"], table["cols"], "|".join(table["header"])[:60])


def compare(template_path, generated_path, label):
    tpl = sections(template_path)
    gen = sections(generated_path)
    gen_index = {}
    for section in gen:
        gen_index.setdefault(section["title"], []).append(section)
    used = {}

    lines = ["## %s" % (label,), ""]
    problems = []
    for section in tpl:
        title = section["title"]
        candidates = gen_index.get(title)
        if not candidates:
            problems.append("MISSING_SECTION %s" % (title,))
            continue
        nth = used.get(title, 0)
        used[title] = nth + 1
        match = candidates[nth] if nth < len(candidates) else candidates[-1]
        if len(match["tables"]) != len(section["tables"]):
            problems.append(
                "TABLE_COUNT %s : 模板 %d / 生成 %d"
                % (title, len(section["tables"]), len(match["tables"]))
            )
        for position, table in enumerate(section["tables"]):
            if position >= len(match["tables"]):
                problems.append("TABLE_MISSING %s #%d" % (title, position + 1))
                continue
            got = match["tables"][position]
            if got["header"] != table["header"]:
                problems.append(
                    "HEADER %s #%d\n    T: %s\n    G: %s"
                    % (title, position + 1, signature(table), signature(got))
                )
            elif table["rows"] and got["rows"] != table["rows"]:
                problems.append(
                    "ROWS %s #%d : 模板 %d 行 / 生成 %d 行 (%s)"
                    % (title, position + 1, table["rows"], got["rows"], "|".join(table["header"])[:40])
                )
    if problems:
        lines.append("")
        lines.append("```")
        lines.extend(problems)
        lines.append("```")
    else:
        lines.append("无差异。")
    lines.append("")
    return lines, problems


def _find_docx(prefix):
    if not os.path.isdir(BUILD):
        raise SystemExit("build directory not found: %s" % (BUILD,))
    for name in sorted(os.listdir(BUILD)):
        if name.startswith(prefix) and name.endswith(".docx"):
            return os.path.join(BUILD, name)
    raise SystemExit("no %s*.docx in %s" % (prefix, BUILD))


def main():
    pairs = (
        ("确认测试计划", os.path.join(SKILL, "templates", "plan.docx"), _find_docx("FPGA确认测试计划")),
        ("确认测试报告", os.path.join(SKILL, "templates", "report.docx"), _find_docx("FPGA确认测试报告")),
    )
    out = []
    total = 0
    counters = {}
    for label, tpl, gen in pairs:
        lines, problems = compare(tpl, gen, label)
        out.extend(lines)
        total += len(problems)
        for problem in problems:
            kind = problem.split(" ", 1)[0]
            counters[kind] = counters.get(kind, 0) + 1
    report_path = os.path.join(HERE, "compare_report.md")
    io.open(report_path, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")

    full = "--full" in sys.argv[1:]
    if full:
        print("\n".join(out))
    # a host that caps one reply at 32K tokens must not receive the whole list
    print("TOTAL PROBLEMS: %d" % (total,))
    for kind in sorted(counters):
        print("  %-14s %d" % (kind, counters[kind]))
    print("report: %s" % (report_path,))
    print("Triage against references/template-conformance.md; pass --full to print the list.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
