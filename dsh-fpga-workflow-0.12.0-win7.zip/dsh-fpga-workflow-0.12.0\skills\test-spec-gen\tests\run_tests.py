# -*- coding: utf-8 -*-
"""Run the deterministic self-tests under any Python interpreter.

``cli.py`` deliberately rejects every interpreter except CPython 3.8.10.  This
entry point imports the library directly so the helpers can still be exercised
on a developer machine, for example to reproduce a failure.

Usage: python tests/run_tests.py
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from confdoc import selftest  # noqa: E402


def main():
    result = selftest.run_all()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not result["failed"] else 1


if __name__ == "__main__":
    sys.exit(main())
