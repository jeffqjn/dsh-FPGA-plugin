<div align="center">
  <h1>test-spec-generator</h1>
  <p><strong>让验证工程师把已冻结的 FEIP 数据包，变成可直接上板执行的表格化确认测试细则、RTM 与覆盖报告</strong></p>
  <p>Python 3.8.10 · Windows 7 SP1 离线 · 仅标准库 · 仅仿真义务计划需设计师确认</p>
  <p><a href="README_EN.md">English</a> · <a href="#快速开始">快速开始</a> · <a href="#触发与适用范围">触发边界</a> · <a href="#输入输出与工作流">输入输出</a></p>
</div>

本 Skill 服务 FPGA 确认测试阶段：输入是 `task-validation` 产出的 `taskbook-reviewed` 包，或 `req-spec-consistency-check` 产出的 `reqspec-reviewed` 包（也接受已发布的单份 `reqspec.json`），走哪条入口由包清单自动识别。输出是仿真义务计划（含设计师评审稿）、确认测试验证计划、`test_specification.json`、**表格版确认测试细则**、`RTM.csv` 与 `coverage_report.json`。它只做规划、细则与追溯的生成和复核，不生成 RTL、不执行测试、不替代真实执行结果——执行覆盖率只在用户提供已绑定的独立记录时统计。

## 快速开始

```text
请使用 test-spec-generator skill 从已闭环的任务书数据包生成确认测试细则。
输入：<taskbook-reviewed 包目录>（或 <reqspec-reviewed 包目录> / <reqspec.json>）
输出：<输出目录>，含 simulation_obligation_plan.json、verification_plan.json、
      test_specification.json、确认测试细则表格、RTM.csv、coverage_report.json
```

最短路径：先 `feip_input.py` 核验输入与就绪状态，再编仿真义务计划并请设计师确认，然后自主生成确认测试计划、细则与覆盖报告。

## 触发与适用范围

**适合使用**

- 任务书已闭环（`taskbook-reviewed`，审查 PASS），需要把有效需求落成确认测试计划与细则。
- 需求规格说明已发布（`reqspec-reviewed` 或独立 `reqspec.json`），需要确认测试侧的测试项、步骤与判据。
- 需要一份测试员能照着做的**表格化细则**：怎么设输入、在哪观察、记录什么、如何判定。
- 需要 RTM 与覆盖报告证明「需求 → 验证义务 → 测试项 → 判据」没有断链。

**不适合使用**

- 上游数据包还没闭环，或规格说明还在 `BLOCKED` / `DRAFT` 状态——先修上游。
- 只想跑仿真、写 RTL 或执行实测；本 Skill 只产出计划和细则。
- 只想要仿真细则（不带确认测试）：走仿真类 Skill，本 Skill 的仿真义务计划只是确认前的评审环节。

## 输入输出与工作流

| 阶段 | 做什么 | 产出 |
| --- | --- | --- |
| 1 核验输入 | `feip_input.py` 读包清单，确认来源、有效范围、仿真与确认测试就绪状态；包大时用 `--catalog` 生成 JSONL 工作清单分批回查原文 | 输入核验结果、工作清单 |
| 2 仿真义务计划 | 按适用范围编 `simulation_obligation_plan.json` 与设计师评审稿，`plan_review.py inspect` 自检，邀请设计师逐项确认，变更先 `reopen` 再 `approve` | 计划 JSON + 评审稿（需确认） |
| 3 确认测试计划与细则 | 按附录 A 组织细则，把功能、性能、接口、协议指标落到步骤与判据；有效需求没有对应附录要点时也纳入规划 | `verification_plan.json`、`test_specification.json`、表格版细则（自主完成，不需逐版确认） |
| 4 复核与闭环 | `build_coverage.py` 生成 `RTM.csv` 与 `coverage_report.json`，逐行检查可执行性，漏项回补 | RTM、覆盖报告 |
| 5 交付 | 规划与细则设计覆盖 100%、无阻断、语义复核通过后交付；资料用尽仍无法消除的缺口如实标注受影响 UID | 完整交付包 |

**边界**：仅仿真义务计划需要设计师确认；确认测试计划、细则、覆盖报告的修订自主完成。修复若改变仿真义务计划，才回到第 2 步重新评审。

## 常用命令

```powershell
python scripts\feip_input.py --source <包目录|model.json|reqspec.json> [--checker <上游技能目录>] [--catalog catalog.jsonl]
python scripts\plan_review.py inspect|reopen|approve <plan.json> --source <包> [--revision <rev>] [--sha256 <摘要>]
python scripts\verification_plan.py --source <包> --plan verification_plan.json [--simulation-plan simulation_obligation_plan.json]
python scripts\build_coverage.py --source <包> --plan verification_plan.json --spec test_specification.json --out-json coverage_report.json --out-csv RTM.csv
```

所有脚本只读取输入、写入指定输出目录；Python 3.8.10 标准库，无第三方依赖，可完全离线运行。

## 功能要点

- **两条入口自动识别**：`taskbook-reviewed` 与 `reqspec-reviewed` 包按清单判断，不需要人工选模式。
- **可执行的表格，不是散文**：每条测试项都落到输入设置、观察点、记录与判据，测试员拿表即可执行。
- **追溯闭环**：需求 → 验证义务（VO）→ 测试项 → 判据 → 覆盖报告，断链会被点名到具体 UID。
- **只有一处人工确认**：仿真义务计划经设计师评审确认，其余计划与细则由 Agent 自主迭代到覆盖 100%。
- **缺口不掩盖**：资料用尽仍缺的项，交付时标未完成范围、缺失证据与受影响 UID，而不是判定为通过。

## 常见问题

**上游包很大，一次读不完怎么办？**
用 `--catalog <path>.jsonl` 生成工作清单，按 `requirement_uid` 分批读取，每批只回查必需原文、平台与接线资料。

**上游技能不在默认位置？**
加 `--checker <上游技能目录>`，命令只读取输入，不修改上游包。

**没有执行结果会怎样？**
覆盖报告只统计规划与细则设计覆盖；执行通过覆盖只在提供已绑定的独立执行记录时计算。

## 更多文档

- 输入与产物契约、字段与示例：[`references/contract.md`](references/contract.md)
- 工作流与命令细节：`SKILL.md`
