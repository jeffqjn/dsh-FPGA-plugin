<div align="center">
  <h1>test-spec-generator</h1>
  <p><strong>Turn a frozen FEIP data package into executable, table-driven confirmation test procedures, an RTM and a coverage report</strong></p>
  <p>Python 3.8.10 · offline on Windows 7 SP1 · standard library only · only the simulation obligation plan needs designer approval</p>
  <p><a href="README.md">中文</a> · <a href="#quick-start">Quick Start</a> · <a href="#when-to-use">When to use</a> · <a href="#inputs-outputs-and-workflow">Inputs &amp; outputs</a></p>
</div>

This skill serves the FPGA confirmation-test stage. Input is either a `taskbook-reviewed` package produced by `task-validation`, or a `reqspec-reviewed` package (or a published standalone `reqspec.json`) produced by `req-spec-consistency-check`; the package manifest decides which entry applies. Output is a simulation obligation plan (with a designer review draft), a confirmation verification plan, `test_specification.json`, the **table-driven confirmation test procedures**, `RTM.csv` and `coverage_report.json`. It plans, specifies and traces tests — it does not generate RTL, run tests or claim results; execution coverage is counted only when the user supplies an independently bound execution record.

## Quick Start

```text
Use the test-spec-generator skill to derive confirmation test procedures from a closed taskbook package.
Input: <taskbook-reviewed package dir> (or <reqspec-reviewed dir> / <reqspec.json>)
Output: <output dir> with simulation_obligation_plan.json, verification_plan.json,
        test_specification.json, the procedure tables, RTM.csv and coverage_report.json
```

Shortest path: validate the input with `feip_input.py`, write the simulation obligation plan and get designer approval, then generate the confirmation plan, procedures and coverage autonomously.

## When to use

**Use it when**

- The taskbook is closed (`taskbook-reviewed`, review PASS) and effective requirements must become confirmation tests.
- The requirement specification is published (`reqspec-reviewed` or a standalone `reqspec.json`).
- You need a table a tester can follow: where to drive the input, where to observe, what to record, how to decide pass/fail.
- You need an RTM and a coverage report proving requirement → verification obligation → test item → criterion is unbroken.

**Do not use it when**

- The upstream package is not closed, or the specification is still `BLOCKED` / `DRAFT` — fix upstream first.
- You want to run simulations, write RTL or execute hardware tests; this skill only plans and specifies.
- You only need simulation procedures; that belongs to a simulation skill — the simulation plan here is the pre-confirmation review step.

## Inputs, outputs and workflow

| Stage | What happens | Output |
| --- | --- | --- |
| 1 Validate input | `feip_input.py` reads the manifest and confirms source, effective scope and readiness; large packages can emit a JSONL work list with `--catalog` | Validation result, work list |
| 2 Simulation obligation plan | Build `simulation_obligation_plan.json` plus a designer review draft, self-check with `plan_review.py inspect`, have the designer confirm item by item; changes go through `reopen` then `approve` | Plan JSON + review draft (needs approval) |
| 3 Confirmation plan and procedures | Organise procedures around Appendix A, mapping functional, performance, interface and protocol criteria to steps and pass/fail rules. Requirements without a matching appendix item are still planned | `verification_plan.json`, `test_specification.json`, procedure tables (autonomous) |
| 4 Review and close | `build_coverage.py` produces `RTM.csv` and `coverage_report.json`; check each row for executability and backfill missing items | RTM, coverage report |
| 5 Deliver | Deliver once planning and design coverage reach 100% with no blockers and semantic review passed; gaps that cannot be closed are reported with the affected UIDs | Complete delivery |

**Boundary**: only the simulation obligation plan needs designer approval; confirmation plan, procedures and coverage revisions are autonomous. Re-review happens only when a fix changes the simulation obligation plan.

## Commands

```powershell
python scripts\feip_input.py --source <package|model.json|reqspec.json> [--checker <upstream skill dir>] [--catalog catalog.jsonl]
python scripts\plan_review.py inspect|reopen|approve <plan.json> --source <package> [--revision <rev>] [--sha256 <digest>]
python scripts\verification_plan.py --source <package> --plan verification_plan.json [--simulation-plan simulation_obligation_plan.json]
python scripts\build_coverage.py --source <package> --plan verification_plan.json --spec test_specification.json --out-json coverage_report.json --out-csv RTM.csv
```

Scripts only read inputs and write to the output directory; standard library only, no third-party dependencies, fully offline.

## Highlights

- **Two entries, auto-detected** — the manifest decides between `taskbook-reviewed` and `reqspec-reviewed`; no manual mode selection.
- **Executable tables, not prose** — every test item carries input setup, observation point, records and pass/fail criteria.
- **Closed traceability** — requirement → VO → test item → criterion → coverage report, with broken links named by UID.
- **A single human checkpoint** — the simulation obligation plan is approved by the designer; everything else iterates autonomously to 100% coverage.
- **Gaps stay visible** — anything still missing is reported with unfinished scope, missing evidence and affected UIDs instead of being marked as passed.

## FAQ

**The upstream package is too large to read at once?**
Use `--catalog <path>.jsonl` to emit a work list and read in batches by `requirement_uid`.

**Upstream skills live elsewhere?**
Pass `--checker <upstream skill dir>`; commands only read inputs.

**What if there is no execution record?**
Coverage only reports planning and design coverage; execution pass coverage appears only with an independently bound execution record.

## More

- Contract, fields and examples: [`references/contract.md`](references/contract.md)
- Full workflow: `SKILL.md`
