# 输入与产物契约

## FEIP 输入

| 输入来源 | 可以传入 | 核验方式 |
|---|---|---|
| `task-validation` | `taskbook-reviewed` 包目录或包内 `model.json` | 用同级 `task-validation` 校验包并检查闭环 PASS，读取清单绑定的 `model.json`。源任务书及附件证据从包中定位。 |
| `req-spec-consistency-check` | `reqspec-reviewed` 包目录、包内 `reqspec.json` 或已发布的独立 `reqspec.json` | 用同级 `req-spec-consistency-check` 校验。完整包包含清单、文件摘要及 ICD 等绑定交付件。独立文件用字节摘要绑定，`package_uid` 和 `manifest_sha256` 为 null，需外部附件或 ICD 才能判定的义务记缺口。 |

上游技能在其他路径时用 `--checker <相应上游技能目录>`。命令只读取输入。任务书入口沿用已完成的上游审查，直接消费任务书有效修订。缺少板卡、端点、环境或实测判据时标明待补资料。设计、仿真覆盖率、工具或验收文档本身也可能是交付义务，按来源选择分析、检查、时序分析或评审，保留具体证据及独立接受条件。

有的任务书包只在 `verification.obligations[]` 登记义务，并将视图的 `obligation_refs` 留空。按当前有效修订及方法遍历全局义务。上游缺少独立可观测点时，从同条判据、源 TP 及原文提取可核实的观察途径。只有泛化描述时记录阻断。UID 和层级按原值引用。

闭环任务书包可能尚无规格说明条目，导致有效需求的规格落实状态为 `unmapped`。有已绑定的源原子义务和修订证据且相关视图允许时，直接依据任务书规划。已有规格落点未映射、部分落实或偏离时，保留阻断并回查对应证据。

可用 `--catalog <新JSONL路径>` 生成工作清单。每行包含一个有效需求及其修订语义、继承义务、判据、约束、源 TP、证据和关联对象 UID。`applicable_scopes` 标明规划范围，`obligations` 在两个范围下分别列出已继承义务；空数组的范围仍可能需要派生义务。逐批用该清单定位原文。计划和覆盖计算使用原始 FEIP 输入。

| FEIP 字段 | 用法 |
|---|---|
| `effective_requirements[]`、`requirements[].revisions[]` | 按有效 `requirement_uid` 和 `revision_uid` 找当前语义。批准删除的条目随报告保留审计索引。 |
| `views.simulation`、`views.confirmation`、`completeness.gaps` | 读取 `readiness`、范围、约束、义务和缺口。conditional 只在对应需求或义务有允许引用时继续，逐项保留排除原因和决定。blocked 时只形成阻断记录及可据实编写的草案。遇到平台对象等间接缺口，沿工程关系回查受影响义务。 |
| `verification.obligations[]` | 按 `method` 选择流程，继承原 UID、有效修订、方法、层级、工况、约束、判据、观测、适用版本、测试要点和证据。上游 VO 均按强制项保留。 |
| `verification.source_test_points[]`、`verification.criteria[]` | 源测试要点用于识别已有试验意图。判据、可观测点、刺激仍须核对其约束、适用工况和证据。 |
| `analysis`、`consistency.evidence`、`document_archive`、发布包中已有的 `icd.json` | 定位约束、模式、信号、时钟、平台、原文及接口细节。回溯实际附件、表格和当前资料，未知或冲突时记录阻断。 |

仿真范围包含上游 `simulation` VO、有效修订中明示的仿真方法及仿真视图按需求明确允许的项。确认验证范围保留全部有效需求，采用 `board_test`、`system_test`、`analysis`、`inspection`、`timing_analysis` 或 `review`。确认视图明确排除的需求仍留在 RTM 与覆盖报告。对缺少上游确认 VO 的需求，依据有效修订及范围自主派生可验证的义务；如果目前只有仿真依据且无法建立确认方法，记录确认覆盖缺口。仿真计划的批准不能认定某项已经上板验证。

## 计划 JSON

`simulation_obligation_plan.json` 和 `verification_plan.json` 采用以下字段。示例 UID 只用于说明形状。`source` 整体复制 `feip_input.py` 返回值。任务书入口返回 `profile: "taskbook-reviewed"` 和 `model_sha256`，规格说明入口返回 `reqspec_sha256`。

```json
{
  "schema_version": "2.0",
  "scope": "confirmation",
  "source": {
    "package_uid": "package:example",
    "manifest_sha256": "从 feip_input.py 返回值复制",
    "reqspec_sha256": "从 feip_input.py 返回值复制"
  },
  "verification_items": [
    {
      "requirement_uid": "req:latency",
      "revision_uid": "rev:latency",
      "planning_status": "READY",
      "reason": null,
      "verification_obligations": [
        {
          "obligation_id": "obligation:latency",
          "source_obligation_uid": "obligation:latency",
          "method": "board_test",
          "level": "board",
          "mandatory": true,
          "status": "READY",
          "reason": null,
          "objective": "测量有效命令的响应延迟",
          "observable": "有效命令及对应响应的采样时刻",
          "scenario_types": ["normal"],
          "criteria": [{"criterion_ref": "criterion:latency", "check": "有效命令响应时间 ≤10 ms", "evidence_refs": ["evidence:latency"]}],
          "coverage_targets": [{"scenario_type": "normal", "criterion_ref": "criterion:latency"}],
          "evidence_refs": ["evidence:latency"]
        }
      ]
    }
  ]
}
```

- 每个范围内的需求写一条规划记录。状态为 `READY`、`BLOCKED` 或 `OUT_OF_SCOPE`，后两者写明原因。上游规定不可测或缺乏客观判据的义务仍保留为强制、`BLOCKED`。部分可验证需求可以同时有就绪与阻断的义务。
- 继承义务使用原 UID；派生义务使用新的稳定 UID，`source_obligation_uid` 为 null。派生依据来自 FEIP，有客观依据的额外场景可补充。每条 `READY` 需求至少有一个强制且就绪的义务。使用 FEIP 的方法与层级，保留上游给定的组合。在义务中另存适用的 `mode_refs`、`constraint_refs`、`test_point_refs`、`observable_refs`、`applicable_versions` 和受控决定或缺口引用，沿用 FEIP 引用形状。
- `criterion_ref` 优先用上游判据 UID。为同一有效修订派生独立的确认义务时，可引用该修订已有的客观判据，并为所选方法定义独立证据。无独立判据时，用包含客观接受条件的约束或当前需求修订 UID，并写出可验证的判定表达。每个适用的场景与判据组合列入 `coverage_targets`。根据条件和约束作用范围确定组合。一个场景内若存在独立的多个条件、版本或限值，并需分别验证，应该拆成不同判据或义务。需要替代验证时保留受限情形和依据；不能自行把原强制项改成可选。
- 仿真文件的 `scope` 为 `simulation`，`method` 为 `simulation`。在计划内明确仿真层级、刺激工况、观察及判定逻辑。在顶层加入 `"plan_review": {"status":"PENDING","revision":1,"approved_revision":null,"approved_sha256":null,"change_log":[]}`。记录实际用户提出的方案变更、受影响 UID、处理结论和修订号。要求改变需求本身的意见回溯到上游缺口。脚本绑定范围、上游摘要、当前计划内容和批准修订，调用 `approve` 之前需要用户对展示版本的明确确认。

## 设计师评审稿

有适用仿真义务时，`仿真义务计划_设计师评审稿.md` 是必交付件。每次发起评审都提供可直接打开的评审稿，以同一版 `simulation_obligation_plan.json` 和 FEIP 来源生成。确认请求包含评审稿路径、修订号和 `inspect` 返回的摘要。

首页交代适用范围、计划状态、阻断项及需要设计师判断的取舍。按需求类别组织全文，每项写出需求编号、义务编号、验证目标、工况、观察点、通过判据和来源位置，并注明继承或派生。按 `coverage_targets` 展示每个工况对应的判据，保留本版计划的参数和接受条件。

邀请设计师按义务编号讨论覆盖范围、场景、观测点和接受条件。逐条回应意见，记录采纳、未采纳或待澄清的结论及依据。涉及计划修改时，先 `reopen`，再同时更新 JSON、`change_log` 和评审稿。新版评审稿首页增加本轮变更与待讨论项，注明受影响的义务及其工况或判据，重新运行 `inspect` 并请设计师确认新版。需要改变需求本身的意见作为上游待决事项追溯。

设计师的明确确认须对应已交付评审稿的当前修订和摘要。完成讨论或确认个别意见后，继续核对整版是否已明确确认。当前版本确认并通过 `approve` 后，自主开展确认测试细则和覆盖迭代。

## 细则与覆盖

### 测试要点与数据包依据

附录 A 或 `verification.source_test_points[]` 提供标题、原有工况和试验意图。以确认视图和所有有效需求修订为规划范围。对每个测试要点，按对象、接口、配置和工况追踪相关的功能行为、性能指标、接口定义、协议格式、工程约束及验收条款。由功能条款确定要验证的行为，由性能和验收条款确定限值、单位、容差及测量条件，由接口和协议条款确定信号、连接、采样位置、输入和响应。包内有未归入附录 A 的有效义务时，按对应需求类别补入细则，使用相同的追溯和覆盖口径。

原始测试描述与有效条款的口径有差异时，回查两处的适用修订、版本和条件。可由受控证据明确的，记录取值及出处。无法确定判据或责任边界时，把原文位置、未决条件及影响写入对应项，保留受影响场景的缺口。设备设置或观察途径缺失且影响执行时，以 `DRAFT` 或 `BLOCKED` 记录现有可写部分和需要补齐的具体资料。

### 表格版确认测试细则

从同一版 `test_specification.json` 交付 `确认测试细则.md`。表格按附录 A 或结构化源测试要点组织，未关联源测试要点的有效义务按需求类别编排。每个表格保留稳定用例或证据程序编号及追溯关系。对同一要点的独立工况或判定拆行，使每行可以逐项执行和判定。

| 要确认什么 | 测试员实际怎么做 | 看到什么算符合 | 数据包依据 |
|---|---|---|---|
| 要验证的行为、指标或证据要求 | 前置条件、适用版本、仪器和接线、输入或操作、具体观察点及应保存的记录。通用配置可引用文中明确的接线表或操作表。 | 分别写出本行期望的可观察响应和通过条件，标明适用限值、单位、容差与边界。 | 需求或判据编号及原文位置，例如章节、表格、图或绑定附件。 |

板级与系统级用例写清对哪个对象执行何种动作、从哪个接口或测点取得数据。分析、检查、时序分析和评审作为独立证据程序，写明检查哪份材料、核对哪个对象、保存什么证据以及如何判定。对于内部信号，标为 `READY` 前需核实确有板外观测或调试路径，或按经证据支持的方法编写独立证据程序。关键参数、步骤或观测途径不能靠“按要求连接”“检查是否正常”等泛称来填充。仅在本行适用时补充环境、测量窗口、误差、重复次数、异常恢复与清理。

可读表格与 JSON 使用相同的用例编号、状态、判据和输入版本。表格题头标注覆盖报告中的 `specification_sha256`，修订后一起更新。交付前按表格从操作一路核对到判定和来源，确保测试员无需猜测接线、刺激或合格条件。

### 结构化细则和覆盖口径

`test_specification.json` 顶层字段为 `schema_version: "2.0"`、`source_plan_sha256`、`approved_simulation`、`test_cases[]` 和 `evidence_procedures[]`。复制 `verification_plan.py` 返回的两个绑定字段。无仿真计划时 `approved_simulation` 为 null。

- 物理用例用 `test_case_id`，证据程序用 `procedure_id`。两者均含 `title`、`requirement_uids[]`、`obligation_ids[]`、`method`、`level`、`status`（`READY`、`DRAFT`、`BLOCKED`）、`open_items[]`、`evidence_refs[]`。追溯的修订从绑定计划取得。草案或阻断项仍记录当前可写的步骤和具体缺口。
- `READY` 项还需 `setup`、`steps[]`、`observables[]`、`data_to_record[]`、`cleanup`。物理用例在设置和步骤中说明前置条件、设备、连接、激励、测量与清理；证据程序写清输入材料、检查动作和应获得的证据。知悉的项目来源保留可定位的出处。
- 用例或证据程序的 `coverage[]` 包含 `obligation_id`、`scenario_type`、`criterion_ref`、`expected_result` 和 `pass_criterion`。合并用例时，每个被引用的义务须有独立可核查的覆盖记录。保留每个判据对应的输入与观察条件。
- 规划覆盖率为至少有一个强制且就绪的确认 VO 的有效需求数除以有效需求总数。细则追溯覆盖率为每项覆盖目标均关联 `READY` 细则的强制确认 VO 数除以全部强制确认 VO 数，漏写的上游 VO 同样进入分母。无分母时指标为 null。报告的 `design_status` 同时检查所有必需需求和义务的结构覆盖。达到 100% 后仍需逐项复核实际步骤、条件边界及判据是否充分。
- `RTM.csv` 用 UTF-8 BOM。每行追溯一个需求修订到 VO、场景、判据及细则；未规划需求或缺失义务也可定位。覆盖报告保留缺口、细则版本摘要、仿真适用需求数及确认状态（`APPROVED` 或 `NOT_APPLICABLE`）。
- 可选执行记录为 `{"source_specification_sha256":"来自相应报告的 specification_sha256","results":[{"case_id":"TC-1","status":"PASS","evidence":"实际记录编号或路径"}]}`。一项只保留一条当前结果，状态还可取 `FAIL`、`BLOCKED`、`NOT_RUN`、`INCONCLUSIVE`。强制 VO 的全部覆盖目标都有就绪细则，且所有关联的就绪细则均有可追溯的 PASS 时才计执行通过。

## 命令

示例在技能目录执行，替换路径及尖括号中的值。用 Python 3.8.10 时也可加 `-X utf8` 处理重定向输出中的中文。

Windows PowerShell 5.1 的 `>` 默认把摘要写成 UTF-16。如果另存脚本 stdout 供下游读取，通过 `Out-File -Encoding utf8` 写入工作目录。脚本通过产物路径直接写出的文件已有指定编码。

```text
python scripts/feip_input.py --source <FEIP包> --catalog <输出目录/requirements_catalog.jsonl>
python scripts/plan_review.py inspect simulation_obligation_plan.json --source <FEIP包>
python scripts/plan_review.py reopen simulation_obligation_plan.json
python scripts/plan_review.py approve simulation_obligation_plan.json --source <FEIP包> --revision <确认的修订> --sha256 <所展示的摘要>
python scripts/verification_plan.py --source <FEIP包> --simulation-plan simulation_obligation_plan.json --plan verification_plan.json
python scripts/build_coverage.py --source <FEIP包> --simulation-plan simulation_obligation_plan.json --plan verification_plan.json --spec test_specification.json --out-json coverage_report.json --out-csv RTM.csv
```

无适用仿真时省略 `--simulation-plan`。有绑定执行记录时向最后一条命令传入 `--execution execution_results.json`。
