"""Build confirmation design coverage and RTM from a released FEIP model."""

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

from feip_input import load_json, read_source, scope_requirements
from verification_plan import approved_simulation, canonical_digest, fingerprint, index
from verification_plan import require, strings, text, validate_plan


def specification_links(spec, obligations, evidence):
    items = {}
    linked = defaultdict(set)
    ready = defaultdict(set)
    for collection, id_key, physical in (
        ("test_cases", "test_case_id", True),
        ("evidence_procedures", "procedure_id", False),
    ):
        for case_id, case in index(spec[collection], id_key).items():
            require(case_id not in items, "Duplicate specification ID: " + case_id)
            items[case_id] = case
            status = case["status"]
            require(status in ("READY", "DRAFT", "BLOCKED"), "Invalid case status: " + case_id)
            open_items = strings(case["open_items"])
            require(bool(open_items) == (status != "READY"), "Inconsistent open_items: " + case_id)
            refs = strings(case["obligation_ids"])
            require(refs and refs <= obligations.keys(), "Unknown or empty obligation links: " + case_id)
            require(strings(case["requirement_uids"]) == {obligations[vo][0] for vo in refs},
                    "Incorrect requirement references: " + case_id)
            for vo_id in refs:
                _, vo, _ = obligations[vo_id]
                method = vo["method"]
                require(case["method"] == method and case["level"] == vo["level"] and
                        physical == (method in ("board_test", "system_test")),
                        "Case method or level disagrees with its obligation: " + case_id)
                require(status != "READY" or vo["status"] == "READY",
                        "READY case points to blocked obligation: " + case_id)
                linked[vo_id].add(case_id)
            if status == "READY":
                required = ("title", "setup", "cleanup")
                require(all(text(case[key]) for key in required), "Incomplete case setup: " + case_id)
                required_lists = ("steps", "observables", "data_to_record")
                require(all(strings(case[key]) for key in required_lists), "Incomplete procedure: " + case_id)
                evidence_refs = strings(case["evidence_refs"])
                require(evidence_refs and evidence_refs <= evidence, "Missing or unknown case evidence: " + case_id)
            checks = set()
            for check in case["coverage"]:
                vo_id, scenario, criterion = (check[key] for key in
                                              ("obligation_id", "scenario_type", "criterion_ref"))
                target = (vo_id, scenario, criterion)
                require(vo_id in refs and target[1:] in obligations[vo_id][2] and target not in checks,
                        "Incorrect or duplicate coverage target: " + case_id)
                checks.add(target)
                if status == "READY":
                    require(text(check["expected_result"]) and text(check["pass_criterion"]),
                            "READY coverage needs an expected result and pass criterion: " + case_id)
                    ready[target].add(case_id)
            if status == "READY":
                require({target[0] for target in checks} == refs,
                        "READY case has obligation links without evaluated criteria: " + case_id)
    return items, linked, ready


def execution_results(execution, spec, cases):
    if execution is None:
        return None
    require(execution["source_specification_sha256"] == canonical_digest(spec),
            "Execution results refer to a different specification")
    results = index(execution["results"], "case_id")
    for case_id, result in results.items():
        require(case_id in cases, "Execution result refers to unknown specification: " + case_id)
        status = result["status"]
        require(status in ("PASS", "FAIL", "BLOCKED", "NOT_RUN", "INCONCLUSIVE"),
                "Invalid execution status: " + case_id)
        if status == "PASS":
            require(cases[case_id]["status"] == "READY" and text(result["evidence"]),
                    "PASS requires a READY case and execution evidence: " + case_id)
    return results


def percent(count, total):
    return 100.0 * count / total if total else None


def build(model, source, plan, spec, simulation=None, execution=None):
    approved = approved_simulation(model, source, simulation)
    requirements, plans, obligations, missing_source = validate_plan(model, source, plan, "confirmation")
    plan_digest = fingerprint(plan)
    require(spec["schema_version"] == "2.0" and spec["source_plan_sha256"] == plan_digest and
            spec["approved_simulation"] == approved,
            "Specification links do not match the current confirmation and simulation plans")
    evidence = {item["uid"] for item in model["consistency"]["evidence"]}
    cases, linked, ready = specification_links(spec, obligations, evidence)
    results = execution_results(execution, spec, cases)
    plan_gaps = sorted(uid for uid in requirements if plans.get(uid, {}).get("planning_status") != "READY")
    mandatory = {uid for uid, (_, vo, _) in obligations.items() if vo["mandatory"]}
    uncovered = set(missing_source)
    missing_targets = []
    covered_cases = {}
    for vo_id, (_, vo, targets) in sorted(obligations.items()):
        ready_cases = set()
        missing = vo["status"] != "READY" or not targets
        for scenario, criterion in sorted(targets):
            case_ids = ready.get((vo_id, scenario, criterion), set())
            ready_cases.update(case_ids)
            if not case_ids and vo["mandatory"]:
                missing_targets.append({"obligation_id": vo_id, "scenario_type": scenario,
                                        "criterion_ref": criterion})
                missing = True
        if vo_id in mandatory and missing:
            uncovered.add(vo_id)
        covered_cases[vo_id] = ready_cases
    covered = mandatory - uncovered
    execution_state = {}
    missing_execution = set()
    if results is not None:
        for vo_id in covered:
            ids = covered_cases[vo_id]
            missing_execution.update(ids - results.keys())
            statuses = {results.get(case, {}).get("status", "NOT_RUN") for case in ids}
            execution_state[vo_id] = next(
                (status for status in ("FAIL", "BLOCKED", "INCONCLUSIVE", "NOT_RUN") if status in statuses),
                "PASS",
            )
    passed = sum(state == "PASS" for state in execution_state.values())
    vo_total = len(mandatory | missing_source)
    complete = bool(requirements and vo_total) and not (plan_gaps or uncovered)
    execution_complete = results is not None and complete and passed == vo_total
    report = {
        "schema_version": "2.0",
        "source": source,
        "upstream_profile": model["protocol"]["profile"],
        "synthetic": model["protocol"]["synthetic"],
        "source_plan_sha256": plan_digest,
        "specification_sha256": canonical_digest(spec),
        "approved_simulation": approved,
        "simulation_review_status": "APPROVED" if approved else "NOT_APPLICABLE",
        "upstream_readiness": {scope: model["views"][scope]["readiness"]
                               for scope in ("simulation", "confirmation")},
        "design_status": "COMPLETE" if complete else "INCOMPLETE",
        "execution_status": ("NOT_PROVIDED" if results is None else
                             "COMPLETE" if execution_complete else "INCOMPLETE"),
        "counts": {"effective_requirements": len(requirements),
                   "simulation_requirements": len(scope_requirements(model, "simulation")),
                   "planned_requirements": len(requirements) - len(plan_gaps),
                   "mandatory_obligations": vo_total, "design_covered_obligations": len(covered)},
        "metrics": {
            "planning_coverage_percent": percent(len(requirements) - len(plan_gaps), len(requirements)),
            "design_trace_coverage_percent": percent(len(covered), vo_total),
            "execution_pass_coverage_percent": percent(passed, vo_total) if results is not None else None,
        },
        "gaps": {
            "unplanned_requirement_uids": plan_gaps,
            "missing_source_obligation_uids": sorted(missing_source),
            "uncovered_obligation_ids": sorted(uncovered),
            "uncovered_targets": missing_targets,
            "not_ready_specification_ids": sorted(uid for uid in cases if cases[uid]["status"] != "READY"),
            "missing_execution_result_ids": sorted(missing_execution),
            "execution_unpassed_obligation_ids": sorted((mandatory | missing_source) - {
                uid for uid, status in execution_state.items() if status == "PASS"
            }) if results is not None else [],
        },
        "deleted_approved_requirement_uids": sorted(
            req["uid"] for req in model["requirements"] if req["lifecycle"] == "deleted_approved"),
    }
    matrix = []
    for uid, (effective, _, inherited) in sorted(requirements.items()):
        item = plans.get(uid, {})
        base = [uid, effective["revision_uid"], item.get("planning_status", "MISSING")]
        planned = item.get("verification_obligations", [])
        for vo_id in sorted(vo["uid"] for vo in inherited if vo["uid"] in missing_source):
            matrix.append(base + [vo_id, "", "", "", "", "", "MISSING_SOURCE_OBLIGATION"])
        if not planned and not inherited:
            matrix.append(base + ["", "", "", "", "", "", "NO_OBLIGATION"])
        for vo in planned:
            vo_id = vo["obligation_id"]
            targets = obligations[vo_id][2]
            for scenario, criterion in sorted(targets or {("", "")}):
                ready_ids = ready.get((vo_id, scenario, criterion), set())
                matrix.append(base + [vo_id, vo["method"], scenario, criterion,
                                      ";".join(sorted(linked[vo_id])), ";".join(sorted(ready_ids)),
                                      execution_state.get(vo_id, "NO_DESIGN_COVERAGE" if vo_id in uncovered
                                                          else "NOT_PROVIDED")])
    return report, matrix


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--checker")
    parser.add_argument("--simulation-plan")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--spec", required=True)
    parser.add_argument("--execution")
    parser.add_argument("--out-json", required=True)
    parser.add_argument("--out-csv", required=True)
    args = parser.parse_args()
    outputs = {Path(path).resolve() for path in (args.out_json, args.out_csv)}
    inputs = {Path(path).resolve() for path in (args.plan, args.spec, args.simulation_plan,
                                               args.execution, args.source) if path}
    source_path = Path(args.source).resolve()
    package = source_path if source_path.is_dir() else source_path.parent
    is_package = source_path.is_dir() or (package / "package.json").exists()
    require(len(outputs) == 2 and not (outputs & inputs) and (not is_package or
            all(package not in path.parents and path != package for path in outputs)),
            "Output paths must be distinct and outside the upstream package and input files")
    model, source = read_source(args.source, args.checker)
    report, matrix = build(
        model, source, load_json(args.plan), load_json(args.spec),
        load_json(args.simulation_plan) if args.simulation_plan else None,
        load_json(args.execution) if args.execution else None,
    )
    with open(args.out_json, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    with open(args.out_csv, "w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["requirement_uid", "revision_uid", "planning_status", "obligation_id",
                         "method", "scenario_type", "criterion_ref", "linked_specification_ids",
                         "ready_specification_ids", "execution_status"])
        writer.writerows(matrix)
    print(report["design_status"] + " (confirmation design)")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        sys.exit("Coverage error: " + str(exc))
