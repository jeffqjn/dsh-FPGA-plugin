"""Load the released FEIP model using its upstream validation contract."""

import argparse
import hashlib
import importlib
import importlib.util
import json
import sys
from collections import defaultdict
from pathlib import Path


SCOPES = ("simulation", "confirmation")
CONFIRMATION_METHODS = ("board_test", "system_test", "analysis", "inspection",
                        "timing_analysis", "review")
PROFILE_INPUTS = {
    "taskbook-reviewed": ("task-validation", "model.json"),
    "reqspec-reviewed": ("req-spec-consistency-check", "reqspec.json"),
}


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def upstream_module(profile, checker):
    if profile not in PROFILE_INPUTS:
        raise ValueError("Expected taskbook-reviewed or reqspec-reviewed, received: " + str(profile))
    skill, _ = PROFILE_INPUTS[profile]
    checker = Path(checker) if checker else Path(__file__).resolve().parents[2] / skill
    library = checker.resolve() / "scripts" / "feiplib"
    entry = library / "__init__.py"
    if not entry.is_file() or not (library / "base.py").is_file():
        raise ValueError("Set --checker to the " + skill + " skill directory")
    # Both producers ship a module named feiplib. Isolate them in the same process.
    name = "_test_spec_feip_" + hashlib.sha256(str(library).encode("utf-8")).hexdigest()[:16]
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, str(entry), submodule_search_locations=[str(library)])
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return importlib.import_module(name + ".base")


def read_source(path, checker=None):
    path = Path(path).resolve()
    model_only = path.is_file()
    package = path.parent if model_only else path
    manifest_path = package / "package.json"
    if model_only and not manifest_path.exists():
        raw = path.read_bytes()
        preliminary = json.loads(raw.decode("utf-8"))
        if preliminary.get("protocol", {}).get("profile") != "reqspec-reviewed":
            raise ValueError("Taskbook input requires the complete reviewed FEIP package; standalone input is reqspec-reviewed only")
        base = upstream_module("reqspec-reviewed", checker)
        contract = base.contract
        model = json.loads(raw.decode("utf-8"), object_pairs_hook=contract.object_pairs,
                           parse_constant=contract.reject_constant)
        base.schema_model(model)
        # In the single-file form, artifact UIDs are handles to unavailable bytes.
        artifact_refs = set()
        for _, node in contract.walk(model):
            for value in node.values():
                for ref in value if isinstance(value, list) else (value,):
                    if isinstance(ref, str) and ref.startswith("artifact:"):
                        artifact_refs.add(ref)
        errors = contract.semantic_checks(model, artifact_refs)
        if errors:
            raise ValueError("Invalid standalone FEIP model:\n" + "\n".join(errors[:40]))
        return model, {"package_uid": None, "manifest_sha256": None,
                       "reqspec_sha256": hashlib.sha256(raw).hexdigest()}

    manifest_bytes = manifest_path.read_bytes()
    header = json.loads(manifest_bytes.decode("utf-8-sig"))
    profile = header.get("profile")
    base = upstream_module(profile, checker)
    model, manifest = base.verify_package(package)
    artifact = next(a for a in manifest["artifacts"] if a["uid"] == manifest["model_artifact_uid"])
    _, model_filename = PROFILE_INPUTS[profile]
    if (model["protocol"]["profile"] != profile or manifest["status"] != "complete" or
            artifact["path"] != model_filename or (model_only and path.name != model_filename)):
        raise ValueError("Expected the complete " + profile + " package and its manifest-bound " + model_filename)
    if manifest_path.read_bytes() != manifest_bytes:
        raise ValueError("Source manifest changed during validation")
    if profile == "taskbook-reviewed":
        gates = model["consistency"]["gates"]
        if (model["source_baseline"]["status"] != "PASS" or gates["overall"] != "PASS" or
                any(issue["status"] in ("open", "deferred") for issue in model["consistency"]["issues"]) or
                any(todo["required"] and todo["status"] != "closed" for todo in model["consistency"]["todos"])):
            raise ValueError("Taskbook input requires closed PASS review")
    source = {
        "package_uid": manifest["package_uid"],
        "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    }
    if profile == "taskbook-reviewed":
        source.update(profile=profile, model_sha256=artifact["sha256"])
    else:
        source["reqspec_sha256"] = artifact["sha256"]
    return model, source


def scope_requirements(model, scope):
    ledger = {item["uid"]: item for item in model["requirements"]}
    methods = ("simulation",) if scope == "simulation" else CONFIRMATION_METHODS
    view = model["views"][scope]
    obligations = {}
    for item in model["verification"]["obligations"]:
        if item["method"] in methods:
            obligations.setdefault(item["requirement_uid"], []).append(item)
    requirements = {}
    for effective in model["effective_requirements"]:
        uid, revision_uid = effective["requirement_uid"], effective["revision_uid"]
        revision = next(r for r in ledger[uid]["revisions"] if r["uid"] == revision_uid)
        inherited = obligations.get(uid, [])
        if (scope == "simulation" and not inherited and
                "simulation" not in revision["semantic"]["verification_methods"] and
                not refers_to(view["allowed_refs"], uid, revision_uid)):
            continue
        requirements[uid] = (effective, revision["semantic"], inherited)
    return requirements


def refers_to(refs, uid, revision_uid=None):
    return any(ref["uid"] == uid and ref["revision_uid"] in (None, revision_uid)
               for ref in refs)


def available(model, scope, effective, semantic, obligation=None):
    """Return whether FEIP permits formal work on this requirement or obligation."""
    uid, revision = effective["requirement_uid"], effective["revision_uid"]
    view = model["views"][scope]
    if view["readiness"] == "blocked":
        return False
    alignment = effective["alignment"]
    if alignment != "complete":
        if model["protocol"]["profile"] != "taskbook-reviewed" or alignment != "unmapped":
            return False
        ledger = next(req for req in model["requirements"] if req["uid"] == uid)
        # In a taskbook-only baseline there is no specification item to realize B1.
        if ledger["spec_item_refs"] or not ledger["source_atomic_refs"] or not semantic["evidence_refs"]:
            return False
    dependencies = {uid, revision, *semantic["constraint_refs"]}
    if obligation is not None:
        dependencies.update({obligation["uid"], *obligation["constraint_refs"],
                             *obligation["criterion_refs"], *obligation["mode_refs"]})
        dependencies.update(ref["uid"] for ref in obligation["observable_refs"])
    if any(ref["uid"] in dependencies and ref["revision_uid"] in (None, revision)
           for ref in view["excluded_refs"]):
        return False
    for gap in model["completeness"]["gaps"]:
        if scope not in gap["blocking_for"]:
            continue
        if not gap["affected_refs"] or any(
                ref["uid"] in dependencies and ref["revision_uid"] in (None, revision)
                for ref in gap["affected_refs"]):
            return False
    return view["readiness"] == "ready" or (
        refers_to(view["allowed_refs"], uid, revision) or
        (obligation is not None and refers_to(view["allowed_refs"], obligation["uid"]))
    )


def write_catalog(path, model):
    requirements = {row["uid"]: row for row in model["requirements"]}
    criteria = {row["uid"]: row for row in model["verification"]["criteria"]}
    constraints = {row["uid"]: row for row in model["analysis"]["constraints"]}
    evidence = {row["uid"]: row for row in model["consistency"]["evidence"]}
    point_index = {row["uid"]: row for row in model["verification"]["source_test_points"]}
    scopes = {scope: scope_requirements(model, scope) for scope in SCOPES}
    points = defaultdict(list)
    for point in point_index.values():
        for uid in point["requirement_refs"]:
            points[uid].append(point)

    with path.open("x", encoding="utf-8", newline="\n") as stream:
        for uid, (effective, semantic, _) in scopes["confirmation"].items():
            ledger = requirements[uid]
            applicable_scopes = [scope for scope in SCOPES if uid in scopes[scope]]
            obligations = {scope: scopes[scope][uid][2] if uid in scopes[scope] else [] for scope in SCOPES}
            inherited = [vo for rows in obligations.values() for vo in rows]
            criterion_ids = {ref for vo in inherited for ref in vo["criterion_refs"]}
            relevant_criteria = [criteria[ref] for ref in sorted(criterion_ids)]
            constraint_ids = set(semantic["constraint_refs"])
            constraint_ids.update(ref for row in inherited + relevant_criteria for ref in row["constraint_refs"])
            relevant_constraints = [constraints[ref] for ref in sorted(constraint_ids)]
            relevant_points = {point["uid"]: point for point in points[uid]}
            for vo in inherited:
                for ref in vo["test_point_refs"]:
                    if ref not in relevant_points:
                        relevant_points[ref] = point_index[ref]
            evidence_ids = set(semantic["evidence_refs"])
            for row in inherited + relevant_criteria + relevant_constraints + list(relevant_points.values()):
                evidence_ids.update(row["evidence_refs"])
            record = dict(effective, title=ledger["title"], normalized_id=ledger["normalized_id"],
                          category=ledger["category"], semantic=semantic,
                          analysis_refs=ledger["analysis_refs"], source_atomic_refs=ledger["source_atomic_refs"],
                          spec_item_refs=ledger["spec_item_refs"], applicable_scopes=applicable_scopes,
                          obligations=obligations,
                          criteria=relevant_criteria, constraints=relevant_constraints,
                          source_test_points=list(relevant_points.values()),
                          evidence=[evidence[ref] for ref in sorted(evidence_ids)])
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--checker")
    parser.add_argument("--catalog", type=Path, help="Write one effective requirement and its evidence per JSONL line")
    args = parser.parse_args()
    model, source = read_source(args.source, args.checker)
    if args.catalog:
        source_path = Path(args.source).resolve()
        package = source_path if source_path.is_dir() else source_path.parent
        if source["manifest_sha256"] is not None and package in args.catalog.resolve().parents:
            raise ValueError("Catalog must be outside the upstream package")
        write_catalog(args.catalog, model)
    print(json.dumps({
        "profile": model["protocol"]["profile"],
        "synthetic": model["protocol"]["synthetic"],
        "source": source,
        "views": {scope: model["views"][scope]["readiness"] for scope in SCOPES},
        "requirement_uids": {scope: list(scope_requirements(model, scope)) for scope in SCOPES},
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        sys.exit("FEIP input error: " + str(exc))
