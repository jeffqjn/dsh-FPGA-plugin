#!/usr/bin/env python
"""Inspect, reopen or approve the simulation obligation plan."""

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

from feip_input import load_json, read_source
from verification_plan import fingerprint, require, validate_plan


def update_plan(document, action, reviewed_sha256=None):
    require(document.get("scope") == "simulation", "Only simulation plans have user review")
    review = document.get("plan_review")
    items = document.get("verification_items")
    if not isinstance(review, dict) or not isinstance(items, list):
        raise ValueError("Missing plan_review or verification_items")
    revision = review.get("revision")
    if isinstance(revision, bool) or not isinstance(revision, int) or revision < 1:
        raise ValueError("plan_review.revision must be a positive integer")
    if not isinstance(review.get("change_log"), list):
        raise ValueError("plan_review.change_log must be an array")
    if action == "reopen":
        review["revision"] = revision + 1
        review["status"] = "PENDING"
        review["approved_revision"] = None
        review["approved_sha256"] = None
    elif action == "approve":
        if review.get("status") != "PENDING":
            raise ValueError("Only a PENDING plan can be approved")
        digest = fingerprint(document)
        require(reviewed_sha256 == digest, "Plan content changed after it was presented")
        review["status"] = "APPROVED"
        review["approved_revision"] = revision
        review["approved_sha256"] = digest
    else:
        raise ValueError("Unknown action: " + action)
    return document


def write_atomic(path, document):
    handle, temporary = tempfile.mkstemp(prefix=".plan-review-", suffix=".json",
                                         dir=str(path.parent))
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(document, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(temporary, str(path))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("inspect", "reopen", "approve"))
    parser.add_argument("plan_path")
    parser.add_argument("--source")
    parser.add_argument("--checker")
    parser.add_argument("--revision", type=int)
    parser.add_argument("--sha256")
    args = parser.parse_args()
    path = Path(args.plan_path).resolve()
    document = load_json(path)
    review = document["plan_review"]
    if args.action != "reopen":
        require(args.source, "--source is required for inspect and approve")
        model, source = read_source(args.source, args.checker)
        requirements, items, _, missing = validate_plan(model, source, document, "simulation")
        require(requirements and items.keys() == requirements.keys() and not missing,
                "Simulation plan has no applicable work or omits requirements/source obligations")
        require(type(review["revision"]) is int and review["revision"] > 0,
                "Invalid simulation plan revision")
        if args.action == "inspect":
            print(json.dumps({"revision": review["revision"], "sha256": fingerprint(document)}))
            return
        require(args.revision == review["revision"], "Expected the presented simulation plan revision")
    update_plan(document, args.action, args.sha256)
    write_atomic(path, document)
    print(review["status"] + " revision " + str(review["revision"]))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print("Plan review error: " + str(exc), file=sys.stderr)
        sys.exit(2)
