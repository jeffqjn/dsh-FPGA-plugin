"""Validate plan identities, scope, source obligations and coverage targets."""

import argparse
import hashlib
import json
import sys
from collections import defaultdict

from feip_input import CONFIRMATION_METHODS, available, load_json
from feip_input import read_source, refers_to, scope_requirements


SCENARIOS = {"normal", "boundary", "abnormal", "stress", "recovery"}
LEVELS = {"unit", "integration", "fpga", "board", "system", "document"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical_digest(value):
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def fingerprint(plan):
    return canonical_digest({key: plan[key] for key in
                             ("schema_version", "scope", "source", "verification_items")})


def index(items, key):
    require(isinstance(items, list), "Expected an array for " + key)
    result = {}
    for item in items:
        uid = item[key]
        require(isinstance(uid, str) and uid and uid not in result, "Invalid or duplicate " + key + ": " + str(uid))
        result[uid] = item
    return result


def text(value):
    return isinstance(value, str) and bool(value.strip())


def strings(values):
    require(isinstance(values, list) and all(text(v) for v in values), "Expected a string array")
    require(len(values) == len(set(values)), "Duplicate array entries")
    return set(values)


def validate_plan(model, source, plan, scope):
    require(plan["schema_version"] == "2.0" and plan["scope"] == scope,
            "Incorrect plan version or scope: " + scope)
    require(plan["source"] == source, "Plan source does not match the current FEIP package")
    requirements = scope_requirements(model, scope)
    view = model["views"][scope]
    items = index(plan["verification_items"], "requirement_uid")
    require(not (items.keys() - requirements.keys()), "Plan contains out-of-view requirement IDs")
    methods = ("simulation",) if scope == "simulation" else CONFIRMATION_METHODS
    evidence = {item["uid"] for item in model["consistency"]["evidence"]}
    criteria = index(model["verification"]["criteria"], "uid")
    source_ids = index(model["verification"]["obligations"], "uid")
    requirement_criteria = defaultdict(set)
    for source_vo in source_ids.values():
        requirement_criteria[(source_vo["requirement_uid"], source_vo["revision_uid"])].update(
            source_vo["criterion_refs"])
    obligations = {}
    missing_source = set()
    for uid, (effective, semantic, inherited) in requirements.items():
        prior = index(inherited, "uid")
        if uid not in items:
            missing_source.update(prior)
            continue
        item = items[uid]
        revision = effective["revision_uid"]
        require(item["revision_uid"] == revision, "Non-effective requirement revision: " + uid)
        status = item["planning_status"]
        require(status in ("READY", "BLOCKED", "OUT_OF_SCOPE"), "Invalid planning_status: " + uid)
        excluded = refers_to(view["excluded_refs"], uid, revision)
        require((status == "OUT_OF_SCOPE") == excluded, "Incorrect exclusion status: " + uid)
        if status != "READY":
            require(text(item.get("reason")), "Missing limitation or exclusion reason: " + uid)
        seen = set()
        ready = False
        for vo_id, vo in index(item["verification_obligations"], "obligation_id").items():
            require(vo_id not in obligations, "Duplicate obligation ID: " + vo_id)
            method = vo["method"]
            require(method in methods and vo["level"] in LEVELS, "Invalid method or level: " + vo_id)
            require(type(vo["mandatory"]) is bool, "Invalid mandatory flag: " + vo_id)
            vo_status = vo["status"]
            require(vo_status in ("READY", "BLOCKED"), "Invalid obligation status: " + vo_id)
            require(text(vo["objective"]) and text(vo["observable"]), "Missing obligation detail: " + vo_id)
            vo_evidence = strings(vo["evidence_refs"])
            require(vo_evidence <= evidence, "Unknown obligation evidence: " + vo_id)
            scenarios = strings(vo["scenario_types"])
            require(scenarios <= SCENARIOS, "Invalid scenario: " + vo_id)
            basis = index(vo["criteria"], "criterion_ref")
            source_uid = vo["source_obligation_uid"]
            upstream = None
            allowed_basis = {revision, *semantic["constraint_refs"], *requirement_criteria[(uid, revision)]}
            allowed_basis.update(key for key, criterion in criteria.items()
                                 if criterion["constraint_refs"] and
                                 set(criterion["constraint_refs"]) <= set(semantic["constraint_refs"]))
            if source_uid is not None:
                require(source_uid in prior and source_uid not in seen and vo_id == source_uid,
                        "Invalid, duplicate or reassigned source obligation: " + str(source_uid))
                upstream = prior[source_uid]
                seen.add(source_uid)
                require(vo["mandatory"] and method == upstream["method"] and
                        vo["level"] == upstream["level"] and set(upstream["scenario_types"]) <= scenarios,
                        "Source obligation method, level, scenario or priority changed: " + vo_id)
                allowed_basis.update(upstream["criterion_refs"])
                allowed_basis.update(upstream["constraint_refs"])
            else:
                require(vo_id not in source_ids, "Derived obligation reuses an upstream ID: " + vo_id)
            for ref, criterion in basis.items():
                require(ref in allowed_basis and text(criterion["check"]),
                        "Invalid criterion reference or missing objective check: " + ref)
                require(strings(criterion["evidence_refs"]) <= evidence,
                        "Unknown criterion evidence: " + ref)
            targets = set()
            for target in vo["coverage_targets"]:
                pair = (target["scenario_type"], target["criterion_ref"])
                require(pair[0] in scenarios and pair[1] in basis and pair not in targets,
                        "Invalid or duplicate coverage target: " + vo_id)
                targets.add(pair)
            if vo_status == "READY":
                require(status == "READY" and available(model, scope, effective, semantic, upstream),
                        "Upstream readiness prohibits formal planning: " + vo_id)
                require(scenarios and basis and vo_evidence and
                        all(c["evidence_refs"] for c in basis.values()),
                        "READY obligation lacks scenarios, criteria or evidence: " + vo_id)
                require({scenario for scenario, _ in targets} == scenarios and
                        {ref for _, ref in targets} == basis.keys(),
                        "Coverage targets omit scenarios or criteria: " + vo_id)
                if upstream:
                    require(upstream["testability"] != "not_testable" and
                            set(upstream["criterion_refs"]) <= basis.keys(),
                            "Source obligation testability or criteria not preserved: " + vo_id)
                ready = ready or vo["mandatory"]
            else:
                require(text(vo.get("reason")), "Blocked obligation lacks a reason: " + vo_id)
            obligations[vo_id] = (uid, vo, targets)
        require(status != "READY" or ready, "READY requirement needs a mandatory READY obligation: " + uid)
        missing_source.update(prior.keys() - seen)
    return requirements, items, obligations, missing_source


def approved_simulation(model, source, plan):
    if plan is None and not scope_requirements(model, "simulation"):
        return None
    require(plan is not None, "Simulation obligations require a reviewed simulation_obligation_plan.json")
    requirements, items, _, missing = validate_plan(model, source, plan, "simulation")
    require(items.keys() == requirements.keys() and not missing,
            "Simulation plan omits required revisions or source obligations")
    review = plan["plan_review"]
    revision = review["revision"]
    require(type(revision) is int and revision > 0 and review["status"] == "APPROVED" and
            type(review["approved_revision"]) is int and review["approved_revision"] == revision,
            "Current simulation plan revision has not been approved")
    digest = fingerprint(plan)
    require(digest == review["approved_sha256"], "Approved simulation fingerprint does not match")
    return {"revision": revision, "sha256": digest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--checker")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--simulation-plan")
    args = parser.parse_args()
    model, source = read_source(args.source, args.checker)
    plan = load_json(args.plan)
    simulation = load_json(args.simulation_plan) if args.simulation_plan else None
    approved = approved_simulation(model, source, simulation)
    requirements, items, _, missing = validate_plan(model, source, plan, "confirmation")
    print(json.dumps({
        "source_plan_sha256": fingerprint(plan),
        "approved_simulation": approved,
        "missing_requirement_uids": sorted(requirements.keys() - items.keys()),
        "missing_source_obligation_uids": sorted(missing),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        sys.exit("Plan error: " + str(exc))
