"""Regression tests for scope, review binding and confirmation coverage."""

import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from build_coverage import build
from plan_review import update_plan
from verification_plan import fingerprint


SOURCE = {"package_uid": "package:released", "manifest_sha256": "a" * 64,
          "reqspec_sha256": "b" * 64}


def fixture(simulate=False):
    effective = {"requirement_uid": "req:x", "revision_uid": "rev:x", "alignment": "complete"}
    semantic = {"verification_methods": ["simulation"] if simulate else [], "constraint_refs": []}
    view = {"readiness": "ready", "allowed_refs": [], "excluded_refs": []}
    obligation = {"uid": "obligation:board", "method": "board_test", "level": "board",
                  "requirement_uid": "req:x", "revision_uid": "rev:x", "scenario_types": ["normal", "boundary"],
                  "criterion_refs": ["criterion:x"], "constraint_refs": [], "mode_refs": [],
                  "observable_refs": [], "testability": "testable"}
    model = {
        "protocol": {"profile": "reqspec-reviewed", "synthetic": True},
        "requirements": [
            {"uid": "req:x", "lifecycle": "active", "revisions": [{"uid": "rev:x", "semantic": semantic}]},
            {"uid": "req:old", "lifecycle": "deleted_approved"},
        ],
        "effective_requirements": [effective],
        "views": {"simulation": dict(view), "confirmation": dict(view)},
        "verification": {"criteria": [{"uid": "criterion:x", "constraint_refs": []}],
                         "obligations": [obligation]},
        "completeness": {"gaps": []},
        "consistency": {"evidence": [{"uid": "evidence:x"}]},
    }
    targets = [{"scenario_type": scenario, "criterion_ref": "criterion:x"}
               for scenario in obligation["scenario_types"]]
    vo = {"obligation_id": obligation["uid"], "source_obligation_uid": obligation["uid"],
          "method": "board_test", "level": "board", "mandatory": True, "status": "READY",
          "objective": "Confirm the response time", "observable": "Request and response timestamps",
          "scenario_types": obligation["scenario_types"], "evidence_refs": ["evidence:x"],
          "criteria": [{"criterion_ref": "criterion:x", "check": "Latency <= 10ms",
                        "evidence_refs": ["evidence:x"]}],
          "coverage_targets": targets}
    plan = {"schema_version": "2.0", "scope": "confirmation", "source": dict(SOURCE),
            "verification_items": [{"requirement_uid": "req:x", "revision_uid": "rev:x",
                                    "planning_status": "READY", "verification_obligations": [vo]}]}
    case = {"test_case_id": "TC-1", "title": "Measure latency", "requirement_uids": ["req:x"],
            "obligation_ids": [obligation["uid"]], "method": "board_test", "level": "board",
            "status": "READY", "open_items": [], "evidence_refs": ["evidence:x"], "setup": "Load DUT",
            "cleanup": "Return to idle", "steps": ["Send both commands and capture responses"],
            "observables": ["Response timestamp"], "data_to_record": ["Latency"],
            "coverage": [dict(t, obligation_id=obligation["uid"], expected_result="Response arrives",
                              pass_criterion="Latency <= 10ms") for t in targets]}
    spec = {"schema_version": "2.0", "source_plan_sha256": fingerprint(plan), "approved_simulation": None,
            "test_cases": [case], "evidence_procedures": []}
    return model, plan, spec


def simulation_plan(plan):
    simulation = copy.deepcopy(plan)
    simulation["scope"] = "simulation"
    simulation["plan_review"] = {"status": "PENDING", "revision": 1, "approved_revision": None,
                                 "approved_sha256": None, "change_log": []}
    vo = simulation["verification_items"][0]["verification_obligations"][0]
    vo.update(method="simulation", level="unit", obligation_id="obligation:sim", source_obligation_uid=None)
    vo["criteria"][0]["criterion_ref"] = "rev:x"
    for target in vo["coverage_targets"]:
        target["criterion_ref"] = "rev:x"
    return simulation


class WorkflowTests(unittest.TestCase):
    def test_confirmation_completes_without_a_confirmation_plan_approval(self):
        model, plan, spec = fixture()
        report, matrix = build(model, SOURCE, plan, spec)
        self.assertEqual(report["design_status"], "COMPLETE")
        self.assertEqual(report["metrics"]["design_trace_coverage_percent"], 100)
        self.assertEqual(report["execution_status"], "NOT_PROVIDED")
        self.assertEqual(report["simulation_review_status"], "NOT_APPLICABLE")
        self.assertEqual(report["counts"]["simulation_requirements"], 0)
        self.assertEqual(report["deleted_approved_requirement_uids"], ["req:old"])
        self.assertEqual({row[5] for row in matrix}, {"normal", "boundary"})

    def test_a_single_mapped_case_does_not_hide_a_missing_boundary(self):
        model, plan, spec = fixture()
        case = spec["test_cases"][0]
        boundary = case["coverage"].pop()
        report, _ = build(model, SOURCE, plan, spec)
        self.assertEqual(report["design_status"], "INCOMPLETE")
        self.assertEqual(report["gaps"]["uncovered_targets"][0]["scenario_type"], "boundary")
        case["coverage"].append(boundary)
        report, _ = build(model, SOURCE, plan, spec)
        self.assertEqual(report["design_status"], "COMPLETE")

    def test_no_denominator_reduction_on_omitted_source_obligation(self):
        model, plan, spec = fixture()
        plan["verification_items"].clear()
        spec["test_cases"].clear()
        spec["source_plan_sha256"] = fingerprint(plan)
        report, matrix = build(model, SOURCE, plan, spec)
        self.assertEqual(report["gaps"]["missing_source_obligation_uids"], ["obligation:board"])
        self.assertEqual(report["counts"]["mandatory_obligations"], 1)
        self.assertEqual(report["metrics"]["design_trace_coverage_percent"], 0)
        self.assertEqual(matrix[0][3], "obligation:board")

    def test_simulation_approval_survives_autonomous_confirmation_case_edits(self):
        model, plan, spec = fixture(simulate=True)
        simulation = simulation_plan(plan)
        with self.assertRaisesRegex(ValueError, "has not been approved"):
            build(model, SOURCE, plan, spec, simulation)
        with self.assertRaisesRegex(ValueError, "content changed"):
            update_plan(simulation, "approve", "0" * 64)
        update_plan(simulation, "approve", fingerprint(simulation))
        spec["approved_simulation"] = {"revision": 1, "sha256": fingerprint(simulation)}
        spec["test_cases"][0]["data_to_record"].append("DUT version")
        report, _ = build(model, SOURCE, plan, spec, simulation)
        self.assertEqual(report["design_status"], "COMPLETE")
        self.assertEqual(report["simulation_review_status"], "APPROVED")
        self.assertEqual(report["counts"]["simulation_requirements"], 1)
        simulation["verification_items"][0]["verification_obligations"][0]["objective"] = "Different target"
        with self.assertRaisesRegex(ValueError, "fingerprint"):
            build(model, SOURCE, plan, spec, simulation)

    def test_blocked_upstream_cannot_be_used_for_ready_obligations(self):
        model, plan, spec = fixture()
        model["views"]["confirmation"]["readiness"] = "blocked"
        with self.assertRaisesRegex(ValueError, "prohibits formal planning"):
            build(model, SOURCE, plan, spec)

    def test_execution_requires_bound_evidence(self):
        model, plan, spec = fixture()
        report, _ = build(model, SOURCE, plan, spec)
        execution = {"source_specification_sha256": report["specification_sha256"],
                     "results": [{"case_id": "TC-1", "status": "PASS", "evidence": ""}]}
        with self.assertRaisesRegex(ValueError, "requires a READY case and execution evidence"):
            build(model, SOURCE, plan, spec, execution=execution)
        execution["results"][0]["evidence"] = "log:1"
        report, _ = build(model, SOURCE, plan, spec, execution=execution)
        self.assertEqual(report["execution_status"], "COMPLETE")

    def test_taskbook_simulation_criterion_can_support_a_separate_board_obligation(self):
        model, plan, spec = fixture(simulate=True)
        model["protocol"]["profile"] = "taskbook-reviewed"
        source = {"profile": "taskbook-reviewed", "package_uid": "package:taskbook",
                  "manifest_sha256": "1" * 64, "model_sha256": "2" * 64}
        model["verification"]["obligations"][0].update(uid="obl:legacy", method="simulation", level="fpga")
        plan["source"] = source
        simulation = simulation_plan(plan)
        sim_vo = simulation["verification_items"][0]["verification_obligations"][0]
        sim_vo.update(obligation_id="obl:legacy", source_obligation_uid="obl:legacy", level="fpga")
        sim_vo["criteria"][0]["criterion_ref"] = "criterion:x"
        for target in sim_vo["coverage_targets"]:
            target["criterion_ref"] = "criterion:x"
        board_vo = plan["verification_items"][0]["verification_obligations"][0]
        board_vo["source_obligation_uid"] = None
        fingerprint_before = fingerprint(simulation)
        with self.assertRaisesRegex(ValueError, "has not been approved"):
            build(model, source, plan, spec, simulation)
        update_plan(simulation, "approve", fingerprint_before)
        spec["source_plan_sha256"] = fingerprint(plan)
        spec["approved_simulation"] = {"revision": 1, "sha256": fingerprint_before}
        report, matrix = build(model, source, plan, spec, simulation)
        self.assertEqual(report["upstream_profile"], "taskbook-reviewed")
        self.assertEqual(report["design_status"], "COMPLETE")
        self.assertEqual({row[3] for row in matrix}, {"obligation:board"})

    def test_taskbook_source_does_not_need_a_specification_mapping(self):
        model, plan, spec = fixture()
        effective = model["effective_requirements"][0]
        effective["alignment"] = "unmapped"
        requirement = model["requirements"][0]
        requirement.update(spec_item_refs=[], source_atomic_refs=["atom:x"])
        requirement["revisions"][0]["semantic"]["evidence_refs"] = ["evidence:x"]
        with self.assertRaisesRegex(ValueError, "prohibits formal planning"):
            build(model, SOURCE, plan, spec)
        model["protocol"]["profile"] = "taskbook-reviewed"
        report, _ = build(model, SOURCE, plan, spec)
        self.assertEqual(report["design_status"], "COMPLETE")
        requirement["spec_item_refs"] = ["item:x"]
        with self.assertRaisesRegex(ValueError, "prohibits formal planning"):
            build(model, SOURCE, plan, spec)


if __name__ == "__main__":
    unittest.main()
