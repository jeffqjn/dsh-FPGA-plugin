# FPGA 工作流 · Win7 移植包（dsh-fpga-workflow 0.13.2-rc.4）

把开发机上的「FPGA 工作流」插件搬到 Win7 的 DSH：侧栏底部一个按钮，点开是全链路目录，每个阶段加载文件后一键开始运行。0.13.2-rc.4 把 **GateFlow Lite** 并进阶段 04「TB 编制及仿真」：Testbench 生成、仿真执行、覆盖率采集与报告仍是三个分开的子类型，但背后是同一个 `gf-run` 技能。

## 包里有什么

```text
dsh-fpga-workflow-0.13.2-rc.4/
  dsh-fpga-workflow-0.13.2-rc.4.tgz   # 插件本体（npm 包，无第三方依赖）
  install.ps1                   # 安装脚本（PowerShell 2.0 语法、纯 ASCII）
  README-Win7.md                # 本文件
  SHA256SUMS.txt                # 校验值
  plugin/                       # 已解开的插件目录，图形界面装这一层
  skills/                       # 14 个可注册 skill + GateFlow 包（见第 3 步）
    task-validation/
    req-spec-gen-1.6.0/req-spec-gen/
    req-spec-consistency-check/
    fpga-architecture-design/
    fpga-simulation-specification/
    standalone-lint/standalone_lint/
    fpga-git/
    xilinx-skill-main/plugins/xilinx-suite/skills/xilinx-suite/
    待完善/fpga-verification-plan/  fpga-test-specification/  fpga-coverage-trace/
    gateflow/                   # GateFlow Lite：gf-run 入口 + 8 个内部技能 + 工具/规则/提示词/模板/基准
      skills/gf-run/            #   只有它注册进技能清单
      skills/gf-{rtl,tb,debug,lint,ip,uvm,cov,protocol}/
      tools/  rules/  prompts/  templates/  benchmarks/  config/
      installers/win7-x64/      #   Icarus Verilog 11 与 GTKWave 3.3.100 离线安装件
```

`skills/` 按**原目录结构**保留：`xilinx-suite`、三个「待完善」skill 和 `gateflow` 都靠嵌套路径定位，别把它们拍平。`gateflow` 内部还有 `tools/`、`rules/`、`prompts/`，技能的相对引用（`../../tools/dut_sim.py`）依赖这个布局，整包搬走即可。

## 前置条件

- Windows 7 SP1 + PowerShell 2.0（脚本只用 2.0 语法）。
- 目标机器上已装 DSH，且 `dsh` 命令在 PATH 里。
- 插件本身不需要 Node 构建、不需要联网、不需要额外 Python 包。
- **skill 脚本**需要 Python **3.8.10**（补丁版本也必须一致），默认找 `C:\Python38\python.exe`，其他位置设 `FPGA_PYTHON38`。
- **GateFlow 仿真**需要 Icarus Verilog 11（`iverilog`、`vvp`），离线安装件在 `skills\gateflow\installers\win7-x64\`；UVM、覆盖率、SVA 另需 ModelSim / QuestaSim，按实际能力探测。

## 三步安装

### 1. 装插件

**方式 A：图形界面（不用命令行）**

1. 解压这个 zip。
2. 打开 DSH：设置 → 插件 → **添加插件**。
3. 在输入框里填**插件目录**，即解压出来的：

   ```text
   ...\dsh-fpga-workflow-0.13.2-rc.4\plugin
   ```

   注意是 `plugin` 这一层（里面有 `package.json`、`index.js`、`client.js`），**不要**填 `...\dsh-fpga-workflow-0.13.2-rc.4` 这一层，也不要填 `.tgz`。
4. 点「安装」，然后重启 DSH 或对本页 `Ctrl+F5`。

「安装源」下拉只影响从 registry 取包，选本地目录时无所谓。

**方式 B：install.ps1（PowerShell 2.0）**

在解压出来的目录里执行：

```bat
powershell -ExecutionPolicy Bypass -File install.ps1 -Profile desktop
```

脚本只做一件事：调用 `dsh plugin --profile <profile> add <tgz>`，然后打印后续步骤。它不会手改 profile 文件。

**方式 C：手动命令行**

```bat
dsh plugin --profile desktop add "D:\port\dsh-fpga-workflow-0.13.2-rc.4.tgz"
```

如果这台机器能连 registry，且包已经发布，也可以直接用包名（不必带 tgz）：

```bat
dsh plugin --profile desktop add dsh-fpga-workflow
```

### 2. 让技能被扫到

插件按顺序找，**取第一个存在的目录**：

1. profile 的 `cordis.patch.yml` 里 `id: fpga-workflow` 那行的 `config.root`
2. 环境变量 `FPGA_WORKFLOW_ROOT`
3. `%DSH_HOME%\fpga-workflow`
4. DSH 进程的当前目录

最省事的做法是把包里的 `skills\` 整个复制到 `%DSH_HOME%\fpga-workflow`（默认是 `C:\Users\<你>\.dsh\fpga-workflow`），**不用改任何配置**。

想固定到别的位置，就在 profile 的 `cordis.patch.yml` 里加：

```yaml
- id: fpga-workflow
  config:
    root: 'D:/fpga/skills'
```

（tgz 里自带的 `root` 是开发机路径，在新机器上不存在会被自动跳过，不用管它。）

### 3. 刷新并确认

重启 DSH，或对网页按 `Ctrl+F5`。打开后：

- 侧栏底部设置按钮旁出现 **「FPGA 工作流」**；点开是 FPGA 研制工作台（左边八阶段、中间 Skill、右边详情），点「返回对话」或再点入口回主界面。
- **04 TB 编制及仿真** 里有三个子类型：「TestCase 生成（自检 TB）」「仿真执行」「覆盖率采集与报告」，都显示 `v0.1.1`、都指向同一个 `gf-run`；它的八个内部技能不出现在技能清单里，由 `gf-run` 按路径读取。
- 新会话的技能清单里能看到 `task-validation`、`req-spec-gen`、`standalone-lint`、`xilinx-suite`、`gf-run` 等 14 项（工作台里的入口是 16 个，因为 GateFlow 拆成三个子类型共用一个 `gf-run`）。
- 宿主日志有两行：`[dsh-fpga-workflow] registered N FPGA workflow skills from ...` 与 `[dsh-fpga-workflow] 8 internal skill(s) left out of the catalog, ...`。

## 用法

1. 左栏选阶段，中栏选 Skill（三个「待完善」Skill 有标识，未接入的规划能力显示为灰色条目）。
2. 右栏按输入角色添加资料：任务书、FEIP 包、规格书、架构包、验证计划……页内浏览、系统选目录、粘贴绝对路径都行。
3. 先「预览指令」核对，再「开始运行」发到页头选定的会话；没有会话时会写入草稿并提示按回车。
4. 跑完到「产物」里登记实际输出，点下游按钮「带入 …」把路径填进下一阶段的输入。
5. 「运行记录」回看每次提交、目标会话和状态，能直接跳回对话。

### GateFlow（阶段 04）怎么跑

三个子类型是同一技能的三段，按顺序用：

| 子类型 | 什么时候用 | 主要输入 | 主要产物 |
| --- | --- | --- | --- |
| TestCase 生成（自检 TB） | 要写/改 RTL 与自检 Testbench | 设计需求、可选现有 RTL、验证计划 | RTL 与 TB 的 FileSet、`sim.log`（TEST PASSED / FAILED）、`report.json` |
| 仿真执行 | 已有 RTL 和 TB，要跑一轮 | 待仿真 RTL（必填）、Testbench、可选验证计划 | `compile.log`、`sim.log`、可选 `wave.vcd`、`report.json` |
| 覆盖率采集与报告 | 仿真已通过，要看覆盖率 | 本轮仿真结果或覆盖率库、覆盖门限 | 覆盖率报告、门限判定、`report.json` 的 `coverage` 段 |

1. 阶段 04 选一个子类型，执行模式按它自己的档位选（TB 生成：生成 RTL+TB / 只补 TB；仿真：Icarus 自动自检 / DUT 仿真 Icarus / DUT 仿真 ModelSim / 仅 Lint；覆盖率：代码覆盖率 / 功能计数器 / 自动选择）。
2. 输入按角色给；仿真器（`iverilog` / `modelsim`）和语言写在「补充要求」里。
3. 指令里始终是 `请使用 $gf-run 执行「TB 编制及仿真 · <子类型>」…`，跑完这一子类型可用「带入」把产物接到下一子类型。
4. 需要人工决定时它会停下提问（最多 3 个）；同一错误 2 次、3 轮修复或 30 分钟预算到点必须停下出报告。

本插件**不**注册 `gf_doctor` / `gf_lint` / `gf_sim` / `gf_ip` / `gf_uvm` / `gf_cov` 六个宿主工具，GateFlow 走随包入口，在 `skills\gateflow\` 目录下执行：

```bat
python -B tools\dut_sim.py --run-dir D:\gf\runs\uart_001 --fileset fileset.json --simulator iverilog --language verilog --lint
python -B tools\dut_sim.py --run-dir D:\gf\runs\uart_001 --fileset fileset.json --lint-only
python -B tools\lint_fix_check.py --before baseline\lint.log --after candidate\lint.log --target-index 0
```

运行目录必须是纯 ASCII，例如 `D:\gf\runs\uart_001`，日志与 `report.json` 都写在该目录下。

## 升级 / 卸载

- 升级：用新版本的 tgz 再跑一次 `dsh plugin --profile desktop add <新tgz>`，然后 `Ctrl+F5`；从 0.12.0 升到 0.13.2-rc.4 不需要改配置，`gateflow` 放进 `skills\` 即可。
- 卸载：在插件管理界面移除 `dsh-fpga-workflow`，或用 `dsh plugin --help` 里的 remove 子命令；卸载不影响 `%DSH_HOME%\fpga-workflow` 里的技能文件。

## 兼容性

- 界面半区依赖与 DSH `0.2.2-rc.1` 同代的槽位：`main`（keyed）、`sidebar.footer.action`、`shell.overlay`，以及 `ctx.get('uiWorkspace')` / `ctx.get('sessions')`。
- 更老的 DSH 上不会报错，但只有**宿主半区**生效：技能照样注册、照样能用 `skill` 工具加载，只是没有侧栏按钮和工作台页面。
- 插件代码只用标准 Node 内置模块与浏览器原生 API（无编译、无第三方依赖），Win7 上的 DSH 只要能加载该版本的插件即可运行。

## 排错

| 现象 | 处理 |
| --- | --- |
| 侧栏没有按钮 | 先 `Ctrl+F5`；再看 DSH 版本是否有 `sidebar.footer.action` 槽位；插件管理里确认 `dsh-fpga-workflow` 已启用 |
| 有按钮但技能清单为空 | 检查第 2 步的四个路径是否存在、目录里有没有 `SKILL.md`；看日志里那行 registered 的数量 |
| 技能清单里看不到 `gf-run` | 确认 `skills\gateflow\skills\gf-run\SKILL.md` 存在且 front matter 完整；日志里应有 `registered N` 与 `8 internal skill(s) left out` 两行 |
| 技能清单里多出 `gf-rtl` 等 8 项 | 说明装的是 0.12.0 的宿主半区，`gateflow` 的内部技能过滤只在 0.13.2-rc.4 起生效；升级插件 |
| 点「开始运行」提示会话服务不可用 | 当前 DSH 没有 `sessions`/`uiWorkspace` 客户端服务；改用「复制指令」粘到输入框 |
| 运行报 `PYTHON_RUNTIME_MISMATCH` | skill 侧的解释器不是 3.8.10，设置 `FPGA_PYTHON38` 指向正确的 python.exe |
| GateFlow 报缺 `iverilog` / `vvp` | 按 `skills\gateflow\installers\win7-x64\` 装 Icarus Verilog 11，把 `bin` 加进 PATH 后重开 cmd 验证 `iverilog -V` |
| GateFlow 报 `UVM unavailable (edition/license)` | 当前 ModelSim/QuestaSim 版别或许可证不含 UVM；Icarus 基础闭环照常运行，报告会注明 |
| 文件浏览报「无法列出该目录」 | 该 DSH 的目录浏览后端不可用，改用「系统选目录」或直接粘贴绝对路径 |
