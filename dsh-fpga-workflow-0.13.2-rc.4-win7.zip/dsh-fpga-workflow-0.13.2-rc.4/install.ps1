# dsh-fpga-workflow installer (Windows 7 SP1 / PowerShell 2.0)
#
# Installs the bundled dsh-fpga-workflow-*.tgz into one DSH profile.
# It never edits the profile by hand: it calls the official CLI, then prints
# the three supported ways to point the plugin at the FPGA skills.
#
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Profile desktop
#
param(
  [string]$Profile = 'desktop',
  [string]$Tarball = ''
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($Tarball -eq '') {
  $found = Get-ChildItem -Path $here -Filter 'dsh-fpga-workflow-*.tgz' | Sort-Object Name
  if ($found -eq $null) {
    Write-Host 'ERROR: no dsh-fpga-workflow-*.tgz next to this script.'
    exit 2
  }
  $Tarball = ($found | Select-Object -Last 1).FullName
}

if (-not (Test-Path $Tarball)) {
  Write-Host ('ERROR: tarball not found: ' + $Tarball)
  exit 2
}

$dsh = Get-Command dsh -ErrorAction SilentlyContinue
if ($dsh -eq $null) {
  Write-Host 'ERROR: the "dsh" command is not on PATH.'
  Write-Host 'Open a shell where DSH is installed, or run this yourself:'
  Write-Host ('  dsh plugin --profile ' + $Profile + ' add "' + $Tarball + '"')
  exit 2
}

Write-Host ('Installing ' + $Tarball)
Write-Host ('Profile: ' + $Profile)
& dsh plugin --profile $Profile add $Tarball
$code = $LASTEXITCODE
if ($code -ne 0) {
  Write-Host ('ERROR: dsh plugin add failed with exit code ' + $code)
  exit $code
}

Write-Host ''
Write-Host 'Installed. Next steps:'
Write-Host '  1. Restart DSH, or refresh the web page with Ctrl+F5, so the new client bundle loads.'
Write-Host '  2. Put the FPGA skills where the plugin scans them. Pick ONE:'
Write-Host '     a) copy the skills folder to  %DSH_HOME%\fpga-workflow   (drop-in, no config)'
Write-Host '     b) set the user variable     FPGA_WORKFLOW_ROOT=D:\fpga\skills'
Write-Host '     c) append this row to the profile cordis.patch.yml:'
Write-Host '          - id: fpga-workflow'
Write-Host '            config:'
Write-Host "              root: 'D:/fpga/skills'"
Write-Host '  3. Open DSH: an "FPGA workflow" button sits at the sidebar foot.'
Write-Host ''
Write-Host 'Troubleshooting: no button -> refresh (Ctrl+F5) and check that the DSH build has the'
Write-Host 'sidebar.footer.action slot; no skills -> check the root path and the DSH log line'
Write-Host '"[dsh-fpga-workflow] registered N FPGA workflow skills".'
exit 0
