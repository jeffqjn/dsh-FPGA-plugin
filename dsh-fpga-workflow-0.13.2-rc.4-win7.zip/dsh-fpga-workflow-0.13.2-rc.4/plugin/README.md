# dsh-fpga-workflow · FPGA 研制工作台

在 DeepSeek Harness 侧栏底部加一个 **「FPGA 工作流」** 入口：点开是研制工作台，回答四个问题——**当前做哪一步、需要哪些资料、哪里要我确认、产物怎么交给下一步**。

首页按已有资料提供任务入口。「全部研制阶段」可打开原有八阶段和跨阶段任务。当前工作区有已提交或执行中的任务时，可从「继续上次任务」回到对应会话。

「开始」页还提供 Vivado 工程操作、确认测试细则生成、文实一致性检查和文文一致性检查。文实检查需要需求规格书和工程资料，文文检查默认检查一份规格书内部的一致性。

Vivado 工程操作直接展示综合与布局布线问题分析、时序分析、关键路径分析和报告生成。可从已完成的 Vivado 运行导出原生报告，也可汇总工程诊断为 JSON。

确认测试细则页可选已评审数据、研制任务书原文或需求规格说明原文。原文先走上游审查；只有规格说明原文时可先检查文档，正式生成前需补充闭环基线、已评审需求包或已发布的独立 `reqspec.json`。

任务页优先显示本次资料和执行会话。影响必填资料的模式放在首屏，其余选项、预览和复制指令收在「高级选项」。

背景图取自 `docs/assets/fpga-workbench-wafer.png`，压成 80 KB WebP 后以 data URI 内嵌在 `client.js` 里，运行期不依赖任何外部图片；遮罩用主题 token 混合，亮暗主题都能读。

## 八阶段与 16 个技能入口

| 阶段 | 挂载的 Skill | 规划中的能力（标「未接入」） |
| --- | --- | --- |
| 01 需求分析 | `task-validation`、`req-spec-gen`、`req-spec-consistency-check` | — |
| 02 设计 | `fpga-architecture-design`、`fpga-rtl-generator` | 概要设计报告、概要设计检查、RTL 代码辅助、FMEA/FMECA、XDC/SDC |
| 03 仿真验证计划 | `fpga-simulation-specification` | 不可测试项检查 |
| 04 TB 编制及仿真 | `gf-run-tb`（TestCase 生成）、`gf-run-sim`（仿真执行）、`gf-run-cov`（覆盖率采集与报告）——三者都调 `gf-run` | — |
| 05 综合布局布线 | `xilinx-suite` | — |
| 06 设计确认 | `test-spec-generator`、`test-spec-gen` | 确认测试计划与报告 |
| 07 第三方验证 | `fpga-spec-code-consistency`、`standalone-lint` | 送测结果及问题复查 |
| 08 验收交付 | — | 研制总结、验收交付资料 |
| 跨阶段能力 | `fpga-coverage-trace`、`fpga-git` | 技术要素检查、变更影响与文档同步、配置和缺陷台账 |

阶段、Skill、输入角色、产物和交接关系集中在 `client.js` 顶部一份配置里，导航、列表和详情共用它；新增普通 Skill 只需补配置并实际注册。

阶段 04 由 **GateFlow Lite** 接管，仍按三步分开放：

| 子类型 | 界面键 | 干什么 | 交给下一步 |
| --- | --- | --- | --- |
| TestCase 生成 | `gf-run-tb` | 冻结接口 → 生成 RTL 与自检 TB → 轻量 Lint → Icarus 自检 | 「带入」仿真执行的 Testbench |
| 仿真执行 | `gf-run-sim` | 完整 RTL 先 Lint，通过后按 Icarus / ModelSim 编译运行 | 「带入」覆盖率的仿真结果 |
| 覆盖率采集与报告 | `gf-run-cov` | 仿真通过后采代码覆盖率，门控关闭则回退功能计数器 | 收口，写 `report.json` |

三个界面键背后是**同一个已注册技能 `gf-run`**（界面用 `invoke` 字段指向它，指令里仍然是 `请使用 $gf-run …`，只是把「阶段 · 子类型」和该子类型自己的执行模式、输入角色、预期产物带进去）。GateFlow 的八个内部技能（`gf-rtl`、`gf-tb`、`gf-debug`、`gf-lint`、`gf-ip`、`gf-uvm`、`gf-cov`、`gf-protocol`）只在包内按路径读取，**不注册进技能清单**——判定规则见下文配置一节。

## 一条 Skill 的用法

1. **选阶段 → 选 Skill**：从首页按资料选择任务，也可展开「全部研制阶段」按阶段浏览；阶段列表会标记上次打开的任务。每个 Skill 的「高级选项」中有一块**简介**——一句话定位 + 一段「输入什么、产出什么、不做什么」，取自该 Skill 自己的 README；标题旁显示打包时记录的版本（如 `v2.3.1`），没有声明版本的显示「未标版本」。一个 Skill 可以有多个独立的执行选项（例如「文实一致性检查」的工程读取方式与证据缺口处理），也可以是一份可多选的功能清单（例如「Xilinx 全工具链」的 11 项能力，勾选后写进同一条指令）；不勾选时交给 Skill 按任务自动判断。
2. **添加资料**：选择器以当前工作区为**基础路径**打开——顶部显示「工作区 · 目录名」，面包屑不会爬到工作区之外，越界请求自动收回基础路径；右栏每个输入角色单独添加（任务书、FEIP 包、规格书、架构包、验证计划……）。**DSH 只提供目录选择器，没有系统文件对话框**：所以文件是在资料对话框里浏览目录点选，或直接粘贴完整路径（输入框默认聚焦）；「选目录」只用于定位，选中目录后补全文件名。盘符、UNC、中文目录都可以，重复路径自动去重。
3. **补充要求（可选）**：每个 Skill 都有一个自由文本框，写一句具体要求（如「比特流只要 impl_1」「时序先看 WNS 最差 10 条」），会作为「补充要求」段落并入同一条指令，随项目一起保存。
4. **预览 → 复制 → 运行**：三条路径调用同一个指令生成函数，内容必然一致。指令带上项目名、运行编号、按角色列出的路径和 Skill 的入口要求。
5. **提交**：`开始运行` 通过会话绑定发一轮请求，然后打开目标会话；没有可用会话时写入新会话草稿并提示按回车；失败保留输入并显示原因。
6. **运行记录**：列表含 Skill、目标会话、发起时间、状态，可打开会话或回看当次指令。

**状态口径**：只有宿主会话快照能证明「执行中」；读不到就说「见会话」，不猜完成、不编进度。任务书审查的分块分母、仿真覆盖等权威计数需要在会话里由 Skill 给出，工作台不代填。

## GateFlow Lite（阶段 04）

`gateflow/` 是随包内嵌的 GateFlow Lite 0.1.1：一个入口技能、八个内部技能，以及工具、规则、提示词、模板、基准与协议参考。

```text
gateflow/
├── skills/gf-run/                 # 入口技能（唯一注册进技能清单的）
├── skills/gf-{rtl,tb,debug,lint,ip,uvm,cov,protocol}/
├── tools/{dut_sim.py,rtl_lint.py,lint_fix_check.py}
├── rules/{rules.md,rules.json}
├── prompts/{planner,builder,integrator,fixer}.md
├── templates/  benchmarks/  config/gf.example.json
└── installers/win7-x64/           # Icarus Verilog 11 与 GTKWave 3.3.100 离线安装件
```

- **入口**：工作台阶段 04 下三个子类型——「TestCase 生成（自检 TB）」「仿真执行」「覆盖率采集与报告」，都指向同一个 `gf-run`。执行模式按子类型收敛：TB 生成给「生成 RTL + 自检 TB / 只补 Testbench」，仿真给「Icarus 自动自检 / DUT 仿真 Icarus / DUT 仿真 ModelSim / 仅 Lint」，覆盖率给「代码覆盖率 / 功能计数器 / 自动选择」。仿真器与语言写在补充要求里。
- **工具**：本插件**不**注册 `gf_doctor` / `gf_lint` / `gf_sim` / `gf_ip` / `gf_uvm` / `gf_cov` 六个宿主工具，GateFlow 走随包入口——技能正文已写明这条回退路径。在 `gateflow/` 目录下执行：

```bat
python -B tools\dut_sim.py --run-dir D:\gf\runs\uart_001 --fileset fileset.json --simulator iverilog --language verilog --lint
python -B tools\dut_sim.py --run-dir D:\gf\runs\uart_001 --fileset fileset.json --lint-only
python -B tools\lint_fix_check.py --before baseline\lint.log --after candidate\lint.log --target-index 0
```

- **环境**：Python 3.8.10（仅标准库）；Icarus Verilog 11 提供 `iverilog` / `vvp`；UVM、覆盖率、SVA 需要 ModelSim / QuestaSim，且以实际能力探测为准，探测为 false 时报告 `UVM unavailable (edition/license)` 而不是跳过。运行目录必须是纯 ASCII，默认 `D:\gf\runs\<id>`。
- **证据**：PASS 只能来自 `lint.ok=true` → `compile.ok=true` → `sim.pass=true` 与落盘日志；运行目录里留 `report.json`（RunReport，含 `status`、`attempts`、`logs`、`verify`）。
- **内部技能**：`gf-rtl`、`gf-tb`、`gf-debug`、`gf-lint`、`gf-ip`、`gf-uvm`、`gf-cov`、`gf-protocol` 的 description 以 `Internal —` 开头，宿主半区因此不注册它们；`gf-run` 用技能资源基址按路径读取 `../gf-<name>/SKILL.md` 与 `../../tools/`、`../../rules/`。
- 完整说明见 `gateflow/README.md`（含 Icarus / GTKWave 离线安装步骤与 SHA-256 校验值）。

## 执行中浮窗

工作台发起、尚未结束的任务会以浮窗出现在右下角（`shell.overlay`，在 Harness 任何界面都可见）：Skill 名、阶段、状态、已用时间、目标会话，可「打开会话」或「工作台」，也可收成一颗“N 个任务执行中”的胶囊。

- 没有已提交或执行中的任务时，浮窗隐藏。
- **可拖拽**：按住标题栏（或胶囊本身）拖动，位置按像素记住，刷新后仍在；靠近边缘自动收进可视区，窗口缩放时也会校正。
- **外观与插件背景同源**：浮窗表面复用工作台那张晶圆背景（同一张内嵌图，共享 CSS 变量 `--w-bg-image`），叠半透明遮罩与顶部流动进度条，和整页风格一致；
- 只显示 `已提交 / 执行中` 的任务；结束或失败自动消失。
- 「执行中」来自会话快照（`sessions.binding(id).session.getSnapshot().running`），读不到就停在「已提交」，不猜完成。
- 同时多个任务显示前 3 个，其余折叠成计数；打开工作台时浮窗自动上移，避开底部操作条。

## 顶部状态

工作台页头右上角有一枚状态胶囊，和右下角浮窗同源：

- 执行中：`◈ 正在执行 · 任务书审查 · 03:21 · 打开会话`，用时每秒刷新，点「打开会话」直接跳转。

任务浮窗可以收起或拖走。页头显示当前任务状态。

## 产物与交接

`产物` 面板登记实际生成的产物（Skill、类型、路径、版本、reviewState），列表里直接给出下游入口：

| 上游 | 带入下游 |
| --- | --- |
| 任务书审查 | 需求规格编制的「任务书基线包」 |
| 需求规格编制 | 一致性检查的「需求规格书」 |
| 一致性检查 | 架构设计的「需求包」、仿真细则的「一致性需求包」 |
| 架构设计 | 仿真细则的「架构交接包」 |
| 验证计划 | 测试细则的「verification_plan.json」 |
| 测试细则 | 覆盖追溯的「test_specification.json」 |
| RTL 代码生成 | TestCase 生成的「现有 RTL」 |
| 仿真验证细则 | TestCase 生成的「验证计划 / 测试项」 |
| TestCase 生成 | 仿真执行的「Testbench」 |
| 仿真执行 | 覆盖率采集与报告的「仿真结果 / 覆盖率数据库」 |

「带入」只改本次拟运行的输入并跳到目标阶段，**运行仍由工程师发起**；已选资料保留可核对。

## 知识库

独立页面，当前统一显示 **待连接**（工程规范与模板、项目经验与问题复盘、成熟 IP 与复用资料）。未连接时工作台与各 Skill 按输入契约照常运转；只有工程师选中的引用才会进入指令，并与运行记录保存同一版本。

## 安装

```sh
# 从 npm（发布后）
dsh plugin --profile desktop add dsh-fpga-workflow

# 本地开发目录
dsh plugin --profile desktop add "D:\ceshipingtai\release\fpga-workflow"

# 离线 tarball
dsh plugin --profile desktop add "D:\port\dsh-fpga-workflow-0.13.2-rc.4.tgz"
```

安装或升级客户端代码后 **刷新一次页面**（`Ctrl+F5`）。Win7 便携包见 `dist\dsh-fpga-workflow-0.13.2-rc.4-win7.zip`（含 `plugin\` 目录、`install.ps1` 与 `skills\`）。

## 配置

宿主按下面顺序找技能目录，**取第一个存在的**，同名 Skill 只注册先命中的那份：

1. `cordis.patch.yml` 里的 `root`
2. 环境变量 `FPGA_WORKFLOW_ROOT`
3. `<DSH_HOME>\fpga-workflow`
4. DSH 进程的当前目录

扫描时会跳过**内部技能**：front matter 写了 `internal: true`，或 `description` 以 `Internal` 开头的 SKILL.md 不注册进技能清单，只留在目录里供入口技能按路径读取。GateFlow 的八个 `gf-*` 就是这种形态，只有 `gf-run` 会出现在技能清单里。扫描日志会单独打一行 `N internal skill(s) left out of the catalog`。

换机器时把 `skills\` 复制到 `%DSH_HOME%\fpga-workflow`，或在 profile 的 patch 里覆盖：

```yaml
- id: fpga-workflow
  config:
    root: 'D:/fpga/skills'
```

## 用到的接口

| 用途 | 接口 |
| --- | --- |
| 侧栏入口 | 槽位 `sidebar.footer.action`（`wide` 区分宽栏/图标栏） |
| 工作台 | 槽位 `main`，key `fpga-workflow` |
| 执行中浮窗 | 槽位 `shell.overlay`，id `fpga-task-hud` |
| 进出 | `ctx.get('layout').selectPanel(key / null)` |
| 技能注册 | 宿主 `ctx.get('skills').register`（扫描、去重、卸载） |
| 会话列表 | 槽位 `useSessions`，回退 `sessions.list.getSnapshot()` |
| 文件浏览 | `uiWorkspace.listDirectory(path)` / `pickDirectory()` |
| 指令提交 | `sessions.retain(id,{source}).ready → binding.session.prompt([{type:'text',text}],'queue')` |
| 打开会话 | `uiWorkspace.openSession(id)` |
| 草稿回退 | `uiWorkspace.startSession(undefined,{prompt,whenDraftExists:'append'})` |
| 执行状态 | `sessions.binding(id).session.getSnapshot().running` |

## 数据与持久化

- 项目 = 工程师选定的工作目录；每项目独立保存输入、选择、运行记录与产物。
- 存储位置是浏览器 `localStorage`（键 `dsh-fpga-workflow:v2`），按项目隔离，刷新与重启后仍在；清除站点数据会丢。这是**本机**数据，不随 Harness 会话同步。
- 运行记录保留当次指令与输入快照，切换项目后仍可读。

## 打包

```sh
npm --cache .npm-cache pack --pack-destination ..\dist
# 便携包：dist\portable\dsh-fpga-workflow-<版本>\ 放 tgz + packaging\* + plugin\ + skills\，
# 生成 SHA256SUMS.txt 后 Compress-Archive 成 zip
```

产物：`dist\dsh-fpga-workflow-0.13.2-rc.4.tgz`（插件包）与 `dist\dsh-fpga-workflow-0.13.2-rc.4-win7.zip`。

## Win7 兼容性

Win7 上最后能跑的 Chromium 是 109，本次按这个上限核对了一遍：

- **已修 · `color-mix()`**：需要 Chromium 111。插件里 45 处颜色混合都补了 `@supports not (color: color-mix(in srgb, #000, #fff))` 回退——边框与底色退回主题 token，整页背景退回 22% 不透明度的晶圆图，浮窗退回实心面板。功能和可读性不受影响，只是层次感略弱。
- **已修 · 非法 `font` 简写**：`font: 500 12.5px/18px inherit` 把 `inherit` 当字体名，整条声明会被丢弃；已展开成 `font-weight/size/line-height/family` 四条。
- **本来就兼容**：客户端只用 ES2017 级语法（无 `?.`、`??`、`replaceAll`、`structuredClone`）；指针事件、`navigator.clipboard`（含 `execCommand` 回退）、`localStorage`、`inset`、`:focus-visible`、flex `gap`、`backdrop-filter` 都在 Chromium 109 能力内；背景图是 WebP（Chromium 32+）。
- **宿主半区**：只用 `node:fs` / `node:path` 与 `readdirSync({ withFileTypes: true })`，Electron 22 自带的 Node 16 可用。
- **仍需在目标机确认**：那台 DSH 的版本是否具备 `main`（keyed）、`sidebar.footer.action`、`shell.overlay` 三个槽位与 `layout` / `sessions` / `uiWorkspace` 服务（`0.2.2-rc.1` 同代）；以及 `dsh plugin add` 用的 pnpm 能否在 Win7 运行（pnpm 11 要求 Node ≥18，若失败就用离线 tgz 从插件管理界面装）。

## 已知限制

- 没有权威运行事件接口：执行状态只能到「已提交 / 执行中（会话快照）/ 见会话」，不显示百分比。
- 工作台不代替 Skill 的校验器：路径只是路径，格式、指纹、版本绑定由各 Skill 判断。
- 项目与记录存在本机浏览器，不跨机器同步；跨机器请复制 `skills` 与项目资料。
- 界面半区依赖与 DSH `0.2.2-rc.1` 同代的槽位与服务；更老的 DSH 只有宿主半区（技能注册）生效。

## 自检

| 编号 | 项 | 状态 |
| --- | --- | --- |
| A01 | 侧栏进入、返回、Esc、入口再点 | 已实现（Esc 先关最上层弹层） |
| A02 | 八阶段 + 公共能力、16 个技能入口、三个待完善标识 | 交互冒烟测试通过（9 个阶段组、16 个入口可达） |
| A03 | 切换 Skill、中文路径增删、离开返回 | 按项目持久化，已测 |
| A04 | 预览/复制/运行同一指令、一次只提交一条 | 同一生成函数，已测 |
| A05 | 无会话、失效会话、失败、结果不明 | 草稿回退 / 「已失效」提示 / 失败留输入 / 「见会话」 |
| A06–A07 | 交接与实际校验 | 交接已测；语义校验由 Skill 执行 |
| A08 | 知识库待连接 | 已实现 |
| A09 | 亮暗主题、窄窗口、长路径、键盘 | 仅主题 token + 响应式；键盘为基础可达性，未见真机 |
| A10 | npm 打包与安装 | `npm pack` 9 个文件；安装需在目标 Harness 复测 |
| A11 | GateFlow 三个子类型：阶段 04 列表、详情、指令都指向 `gf-run`；内部技能不入清单 | 冒烟测试通过（3 个入口可达、指令均为 `请使用 $gf-run 执行「TB 编制及仿真 · <子类型>」`、8 个 `Internal —` 技能不注册） |
















