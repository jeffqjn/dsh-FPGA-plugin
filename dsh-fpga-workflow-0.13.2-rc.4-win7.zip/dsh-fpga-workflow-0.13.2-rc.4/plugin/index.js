// Host half of dsh-fpga-workflow.
//
// The browser half owns the sidebar entry and the workflow-directory page. The
// Host half does one job: walk the workspace, read every SKILL.md, and register
// it into the Harness skill catalog so the `skill` tool can load it in any
// Session. Registration failures are logged and skipped; one malformed skill
// never takes the plugin down.
//
// A skill whose front matter says `internal: true`, or whose description starts
// with "Internal" (the GateFlow pack writes "Internal — loaded by gf-run"), is
// deliberately not registered: those skills are read from their file by their
// entry skill, so the model-facing catalog stays the set a human would pick.
import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'

export const name = 'dsh-fpga-workflow'

// Directories that never contain a skill but can hold tens of thousands of
// files. `runs`/`.test`/`.probe` are local scratch areas of this workspace.
const SKIP = new Set([
  'node_modules',
  '.git',
  '.probe',
  '.test',
  '__pycache__',
  'runs',
  'dist',
  'build',
  'coverage',
])

const MAX_DEPTH = 5
// A workspace that keeps the release zip, a portable folder and a dev copy side by
// side can hold well over 64 SKILL.md files; the cap only stops runaway scans.
const MAX_SKILLS = 256

/**
 * Roots to scan, in priority order: the row's `root`, the
 * `FPGA_WORKFLOW_ROOT` environment variable, `<DSH_HOME>/fpga-workflow` (the
 * drop-in directory, so a fresh machine needs no configuration), then the
 * process directory. Missing roots are skipped; a skill name keeps the copy
 * found first.
 */
export function resolveRoots(config = {}) {
  const roots = []
  const push = (value) => {
    if (typeof value !== 'string' || value.trim() === '') return
    let absolute
    try {
      absolute = resolve(value.trim())
    } catch {
      return
    }
    if (roots.indexOf(absolute) === -1) roots.push(absolute)
  }
  push(config.root)
  push(process.env.FPGA_WORKFLOW_ROOT)
  if (process.env.DSH_HOME) push(join(process.env.DSH_HOME, 'fpga-workflow'))
  push(process.cwd())
  return roots
}

/** Collect every `SKILL.md` under `dir`, bounded by depth and count. */
function collect(dir, depth, out) {
  if (depth > MAX_DEPTH || out.length >= MAX_SKILLS) return
  let entries
  try {
    entries = readdirSync(dir, { withFileTypes: true })
  } catch {
    return
  }
  for (const entry of entries) {
    if (entry.isFile() && entry.name === 'SKILL.md') {
      out.push(join(dir, 'SKILL.md'))
      if (out.length >= MAX_SKILLS) return
    }
  }
  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    if (SKIP.has(entry.name) || entry.name.startsWith('.')) continue
    collect(join(dir, entry.name), depth + 1, out)
  }
}

/**
 * Parse the YAML front matter the way these skills write it: a leading `---`
 * block with `key: value` rows, where a value may be a `>`/`|` block scalar.
 * Returns `null` when the file has no front matter at all.
 */
function parseSkill(text) {
  const lines = text.replace(/\r\n/g, '\n').split('\n')
  if (lines.length === 0 || lines[0].trim() !== '---') return null
  let end = -1
  for (let i = 1; i < lines.length; i += 1) {
    if (lines[i].trim() === '---') {
      end = i
      break
    }
  }
  if (end === -1) return null

  const fields = {}
  let current = null
  for (let i = 1; i < end; i += 1) {
    const line = lines[i]
    if (line.trim() === '') continue
    const match = /^([A-Za-z][\w-]*)\s*:\s*(.*)$/.exec(line)
    if (match === null) {
      if (current !== null) {
        const extra = line.trim()
        if (extra !== '') fields[current] = `${fields[current]} ${extra}`.trim()
      }
      continue
    }
    const key = match[1]
    const value = match[2].trim()
    current = null
    if (value === '>' || value === '|' || value === '>-' || value === '|-') {
      fields[key] = ''
      current = key
      continue
    }
    fields[key] = value.replace(/^['"]|['"]$/g, '')
  }

  const content = lines.slice(end + 1).join('\n').replace(/^\n+/, '').trim()
  if (content === '') return null
  return { fields, content }
}

/**
 * Whether the skill is an internal helper that its entry skill loads by path.
 * Two signals, both declared by the skill itself: an explicit `internal: true`
 * front-matter flag, or the `Internal — …` description prefix this workspace's
 * GateFlow pack uses. Entry skills simply omit both.
 */
export function isInternalSkill(parsed) {
  const flag = String(parsed.fields.internal || '').trim().toLowerCase()
  if (flag === 'true' || flag === 'yes' || flag === '1') return true
  return /^internal\b/i.test(String(parsed.fields.description || '').trim())
}

function describe(file) {
  let text
  try {
    text = readFileSync(file, 'utf8')
  } catch {
    return null
  }
  const parsed = parseSkill(text)
  if (parsed === null) return null
  const name = (parsed.fields.name || '').trim()
  const description = (parsed.fields.description || '').trim()
  if (!/^[a-z0-9][a-z0-9-]*$/.test(name) || description === '') return null
  return {
    name,
    description,
    whenToUse: parsed.fields.whenToUse || parsed.fields.when_to_use || undefined,
    content: parsed.content,
    path: file,
    resourceBase: { kind: 'directory', path: dirname(file) },
    internal: isInternalSkill(parsed),
  }
}

/**
 * Scan a workspace root and return the winning skill per name, the internal
 * helpers that must stay out of the catalog, and the files that had no usable
 * front matter. Exported for local diagnostics.
 */
export function scanSkills(root) {
  const files = []
  collect(root, 0, files)
  // Two copies of one skill may exist in a workspace (a nested checkout, for
  // example): keep the shortest path so the registration stays deterministic.
  files.sort((a, b) => a.length - b.length || a.localeCompare(b))

  const skills = []
  const internal = []
  const problems = []
  const seen = new Set()
  for (const file of files) {
    const skill = describe(file)
    if (skill === null) {
      problems.push(file)
      continue
    }
    if (seen.has(skill.name)) continue
    seen.add(skill.name)
    if (skill.internal === true) internal.push(skill)
    else skills.push(skill)
  }
  return { skills, internal, problems, files }
}

export function apply(ctx, config = {}) {
  const skills = typeof ctx.get === 'function' ? ctx.get('skills') : ctx.skills
  if (skills === undefined || typeof skills.register !== 'function') {
    log(ctx, 'warn', 'skill catalog unavailable; workspace skills were not registered')
    return
  }

  const candidates = resolveRoots(config)
  const roots = candidates.filter((root) => existsSync(root))
  if (roots.length === 0) {
    log(ctx, 'warn', `no FPGA workflow root found; looked in: ${candidates.join(' | ')}`)
    return
  }

  const registered = []
  const keptInternal = []
  const seen = new Set()
  for (const root of roots) {
    const { skills: found, internal, problems } = scanSkills(root)
    for (const file of problems) {
      log(ctx, 'warn', `skipped unreadable skill front matter: ${file}`)
    }
    let fromRoot = 0
    for (const skill of found) {
      if (seen.has(skill.name)) continue
      seen.add(skill.name)
      try {
        const { internal: _internal, ...entry } = skill
        registered.push(skills.register({ ...entry, source: 'custom' }))
        fromRoot += 1
      } catch (error) {
        log(ctx, 'warn', `skill ${skill.name} was not registered: ${String(error)}`)
      }
    }
    for (const skill of internal) {
      if (seen.has(skill.name)) continue
      seen.add(skill.name)
      keptInternal.push(skill)
    }
    if (fromRoot > 0) log(ctx, 'info', `${fromRoot} skill(s) registered from ${root}`)
  }

  if (keptInternal.length > 0) {
    log(
      ctx,
      'info',
      `${keptInternal.length} internal skill(s) left out of the catalog, loaded by path from their entry skill: ` +
        keptInternal.map((skill) => skill.name).join(', '),
    )
  }

  if (registered.length === 0) log(ctx, 'warn', `no skill found under ${roots.join(' | ')}`)
  else log(ctx, 'info', `registered ${registered.length} FPGA workflow skills from ${roots.length} root(s)`)

  ctx.effect(() => () => {
    for (const dispose of registered.reverse()) {
      try {
        dispose()
      } catch {
        // Teardown continues; the fiber is going away anyway.
      }
    }
  }, 'fpga-workflow: workspace skills')
}

function log(ctx, level, message) {
  try {
    const logger = ctx.logger
    if (logger !== undefined && typeof logger[level] === 'function') {
      logger[level](message)
      return
    }
  } catch {
    // Fall through to the console.
  }
  // eslint-disable-next-line no-console
  console[level === 'warn' ? 'warn' : 'log'](`[dsh-fpga-workflow] ${message}`)
}
