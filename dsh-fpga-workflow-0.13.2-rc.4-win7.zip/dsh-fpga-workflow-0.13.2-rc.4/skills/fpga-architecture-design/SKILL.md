---
name: fpga-architecture-design
description: 先将继承代码和结构说明整理为可查询的结构化现状基线，再基于FEIP需求、ICD及用户批准范围完成增删改和目标FPGA架构、文档交接JSON；也支持从零设计。不替代需求批准、RTL实现或真实验证结果。
---

# FPGA架构设计

设计深度 detailed，执行模式 sequential。Agent 负责工程判断。脚本冻结输入、检查结构与引用、计算预算并生成交付。Skill 脚本目标环境为 Windows 7 SP1、PowerShell 2.0、Python **3.8.10**，无需 pip、Node 或在线服务。按目标器件和项目受控资料确认 FPGA 实现工具链、版本与 IP 支持。

## 开始前

读取 [输入协议](references/input-contract.md) 和 [运行接口](references/runtime.md)。输入是完整 `reqspec-reviewed` FEIP 发布目录，至少包含同版 `package.json`、`reqspec.json`、`icd.json`、候选/确认快照、Schema及原文证据。不得仅取两个JSON丢失其证据依赖。旧版无ICD或仅候选包只能诊断，不可冻结架构。

先执行`doctor`。有继承代码/架构时，先读[现有架构结构化与查询](references/legacy-store.md)，执行`legacy-prepare`→分批读取代码/结构说明→`legacy-build`，先交付描述现状的legacy_architecture.json及索引。此阶段只需代码与结构说明，可不具备新需求包；明确来源、推断、未知和未读范围，不生成目标设计。查询用legacy-query，源码分段读取用legacy-read。

随后读取[继承与增量设计](references/incremental-design.md)，用`prepare --legacy-baseline <现状整理包>`连接目标需求/ICD。原始`--legacy`仍可冻结输入，但继承场景propose前必须先有结构化现状基线。成功标记和退出码均核对；拒绝/缺口反馈给用户。prepare只冻结输入并产生内部模板，查看input_summary、legacy_inventory、有效修订和两份architecture视图。

输入 blocked 时走诊断轮。核对两个 architecture 视图和所有影响架构的 ICD 诊断，交付已知流向、受影响流段、缺失受控资料及复验判据。由上游正式发布修订基线后重新 prepare。

## 缺口分流与使用者提示

在输入诊断、设计或评审发现缺口时，根据有效需求、任务书和 ICD 判断谁负责确定缺失信息。执行前告知设计师和 skill 使用者当前缺什么、接下来调用哪个 skill、准备修改什么产物，以及是否需要他们提供资料或作出决定。多项缺口分别提示；已有授权且资料齐全时，告知后直接继续。

- **继续使用本架构设计 skill。** 既有外部契约与验收要求足以约束设计时，内部模块划分、FIFO 深度、仲裁、流水线等由本轮架构决定。把选择、依据、受影响对象和验证义务写入当前架构模型，复查预算和数据流，再执行相应的构建与校验。对使用者说明本轮将补入的设计内容及验证方式。
- **调用需求规格说明一致性检查 skill（`req-spec-consistency-check`）。** 缺少外部接口义务、对端时序、管脚映射、验收边界，或发现它们与任务书冲突时，提供受影响的需求/修订 UID、ICD 对象、证据位置、适用配置及所需确认项。找到并读取该 skill 的 `SKILL.md`，用同一任务书基线和最新规格启动复查。对使用者说明要回查的条款和需要补进交接包的内容。取得更新的正式需求和 ICD 交付包后重新 `prepare`，核对缺口状态，再继续受影响的架构设计。

如果事实暂时无法确认，告知使用者缺少的具体受控资料或待定事项，并按现有就绪状态继续可执行的工作。文件损坏、摘要不符和版本不兼容按输入合同排查，分别修复导出或适配后重跑 `prepare`。

## 生成前必须取得用户批准

这是用户明确要求的目标架构生成前门禁，与完成后的架构冻结批准不同。用户已允许先整理继承现状，因此legacy-build描述性输出及只读查询可在此之前执行，它们不表示批准现有架构或任何变更。基于现状基线做范围分析，填写generation_plan.template.json副本，执行propose，展示approval_request及proposal摘要。材料包含目标、范围、保留约束、旧对象复用/修改/替换/删除、新增与改动范围、估算口径、缺口及输出清单；此时不执行详细目标架构设计，不调用build、不生成目标architecture.json、目标图/报告或下游交接包。

等待用户明确批准这个范围。真实答复记录为generation_approval.json，执行`check-approval`成功后才进入下列顺序工作流。沉默、旧轮批准、批准本Skill实现、上游需求发布确认以及架构冻结确认，都不能替代本次生成批准。已明确批准当前摘要时直接转录，不重复询问；范围、继承处置或输入变化重新propose。授权格式见[批准与结构化文档合同](references/approval-document.md)。

## 顺序工作流

按顺序完成下列阶段，在同一模型中增量填写；阶段职责和完成判据见 [设计方法](references/design-method.md)。不隐式启动子Agent。

1. **输入与边界**：核验联合基线、readiness、有效修订与约束，列出范围、模式、异常、外部服务前提和问题。`blocked`仅诊断；`conditional`保留允许/排除范围，不擅自升级为ready。
2. **方案与划分**：建立功能/算法分解和稳定模块ID；高代价决策比较备选、证据、风险原型与回退。内部模块/接口是设计提案，不能伪装为上游需求事实。
3. **定量与可行性**：按 [预算与实现工具链](references/budgets-vivado.md) 完成吞吐、延迟、缓存、存储、精度、资源和物理规划。所有值带单位、口径、来源或假设及证据等级。
4. **契约与域**：定义外部ICD落实、内部接口、模块契约、时钟复位、逐条CDC/RDC、启动/故障恢复、配置/寄存器/软件所有权。不能修改需求级ICD；冲突返回上游变更流程。
5. **一致模型与图**：依照 [模型合同](references/model-contract.md) 填写 `architecture.template.json` 的另存副本。保留全局视图，并在 `function_views` 为每项功能建独立架构图，展开子功能单元、对应模块、边界接口、数据和信息流。可独立评审的子功能另建子图。按 [设计方法](references/design-method.md) 核对层级、方向与有效需求覆盖。
6. **规则与评审**：读取 [项目规则](references/guide/FPGA架构设计规则规范.md)，按 [规则检查](references/rules-review.md) 展开全部规则×对象×配置记录，并按 [设计方法](references/design-method.md) 逐条复核信息流与数据流。经验指南按相关章节查阅，案例数值不作项目约束。使用随附报告模板组织项目内容；禁止用一条笼统“符合”覆盖所有对象。
7. **装配与交接**：`build --proposal ... --approval ...`再次核验生成批准后生成`architecture.json`、`documentation_input.json`、`inheritance_delta.json`、DRAFT报告、接口、全局视图、分功能图、RTM和交接JSON；`validate`。交付时先给设计师可离线打开的 `review.html`，从首页核对主数据流、逐功能架构、关键预算、待确认事项和证据。主路径、关键时序图的录入口径和下游交接见 [交付约定](references/handoff.md)。

## 评审边界

`build`只生成DRAFT，结构检查成功不表示G1通过。只有收到针对当前包摘要的明确冻结授权，且存在真实架构、设计、验证角色评审记录与独立复核证据后，才可写入 `review.json` 并调用 `freeze`。先展示可审阅成品，再请求尚未获得的授权；已有明确授权直接转录，不重复询问。不得自动填签名、批准人或测试通过。脚本只能检查记录及摘要绑定，授权真实性由宿主核实。

指南尚未到期的实现/板测项记 `planned`，不能写“不适用/符合”。不产生虚假RPT-05或G3发布结论。当前架构冻结最多表示允许按记录范围推进详细设计，不能代表器件电气、时序或板测验收成功。

## 不变量

- 上游UID和有效revision_uid原样保留。已批准偏离不改变有效采用值；约束选择有歧义时保留问题并阻断受影响设计。
- 指标缺来源保留null并关联问题；新设计选择标proposal/assumption/derived，不能自行变成source。未知器件、管脚、时钟、效率、资源门限和安全策略不得补造。
- 需求、协议、器件/IP、精度、时钟复位或配置变化必须重新prepare，显式列出受影响对象、预算、规则与回归范围，不能复用旧冻结授权。
- 本Skill输出自身 `FPGA-ARCH/1.1.0` 合同，不冒称FEIP已注册的architecture profile。上游FEIP快照保持原样；交接中的verification obligations不是已执行用例或结果。
- 继承场景先重建as-is再形成to-be差异；原ID放original_uid并映射目标UID。10%～70%等变化估计必须说明分母和依据，不按比例自动切换从零重写；复用部分也要检查新需求、接口、时钟复位、时序与回归影响，旧测试通过不自动继承为本版通过。
- 现状基线不可作为CRUD的可覆盖工作文件。查询不修改；新增/修改/替换/删除在获批目标模型及changes中执行，删除保留旧ID与墓碑；纠正现状认识则新建描述性版本并保留parent基线，已有目标范围批准因现状摘要变化失效。
