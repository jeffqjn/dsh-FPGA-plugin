# 生成批准与结构化文档交接

## 生成批准

继承场景顺序：legacy-prepare→分批整理现有架构→legacy-build/查询→prepare绑定目标需求→propose调整范围→用户批准→check-approval→详细目标设计→build→validate→独立评审/冻结。无继承时从prepare开始。现状描述整理是用户明确要求的前置工作，不表示批准现状正确；生成前不先做完整目标架构成品再索要执行授权。

`generation_plan.template.json`另存为plan.json后填写。输出清单固定含architecture.json、documentation_input.json、interface_contracts.json、diagrams、traceability、reports、review。propose输出generation_plan.json、approval_request.md和proposal.json，状态AWAITING_USER_APPROVAL。展示这份方案后才能取得真实的用户决定。

只有用户明确批准当前方案，宿主才记录：

```json
{
  "kind":"approve_architecture_generation",
  "proposal_sha256":"当前proposal.json实际SHA256",
  "actor":"用户实际身份，未提供姓名则如实注明",
  "confirmed_at":"带时区的实际确认时间",
  "user_quote":"用户明确批准这份生成/调整范围的原话"
}
```

上述是字段说明，不是授权样例。脚本检查摘要、时间及绑定，宿主负责用户意见的真实性；不能自行制作批准。先check-approval，成功后才执行详细设计。build仍要求--proposal和--approval并重新检查，缺失批准不会创建架构输出目录；审批记录和方案一起归档到generation/。

输入、代码快照、设计模式、复用/修改/替换/删除处置、变更集合或输出范围变化须重新propose并获批准。文字设计不得超出获批goal/scope/preservation_constraints；脚本只对可机器判定的字段做核验，宿主还要核对语义。完全相同范围的文件写盘失败可复用原有效批准。生成批准不表示关键技术缺口关闭，也不表示架构已冻结。

## 文档主输入

`architecture.json`采用FPGA-ARCH/1.1.0及architecture.schema.json，是完整目标模型。`documentation_input.json`采用FPGA-ARCH-DOCUMENT/1.1.0及documentation.schema.json，包含：

| 字段 | 用途 |
|---|---|
| architecture_sha256 | 逐字节绑定同包architecture.json |
| publication_state | 当前文档源快照为DRAFT，最终批准状态另读package/review |
| model | 完整架构对象、接口、域、预算、决策、有效需求分配、规则、证据、问题及继承差异 |
| model.document_sections | 章节UID、报告ID、顺序、标题、段落数组、对象/需求/证据引用 |
| model.design_context | new/incremental、继承基线摘要、变更比例和口径 |
| model.legacy_objects/changes | 现有行为、复用处置、原ID与目标映射、迁移兼容及回归 |
| legacy_baseline | 完整结构化现状模型，含端口、属性、关系、代码出处、文件阅读状态及未知项；无继承则null |
| section_order | 按报告ID与order确定的章节UID顺序 |

文档Skill先validate联合交付包，再校验文档Schema及architecture_sha256，按document_sections组织章节，从model的结构化对象生成表格、接口表、追溯和图；不从Markdown逆向提取事实。每个章节的object_refs/requirement_refs/evidence_refs为内容提供出处。模型中仍有null、假设、问题时，文档必须保留状态，不能润色为已确认或测试通过。

document_sections是正式章节正文的数据源，Markdown报告由它派生。narratives保留为兼容摘要，不能形成相矛盾的另一份架构事实。G1可冻结条件要求六份适用报告均有结构化章节；模板空章节不算完成。

后续写Word/PDF等文档时使用目标文档Skill及模板，本Skill提供JSON和Schema，不把文档排版能力绑定到Win7运行脚本。
