# 定量预算与实现工具链交接

所有quantity使用 `{value,unit,basis,source_refs,issue_ref}`：basis=source/derived/proposal/assumption；未知value=null且issue_ref非空。source引用上游UID，derived引用证据/决策及计算；proposal不能宣称已批准。通用百分比裕量、效率或MTBF不是默认门限。

脚本支持三个可重算预算kind：

- throughput：参数clock_hz、lanes、vector、ii、efficiency、memory_limit_sps、required_sps；单位统一Hz、样本/s。能力=min(lanes×clock_hz×vector/ii×efficiency, memory_limit_sps)。memory_limit_sps未知时结果unknown，不假定无限带宽。区分峰值、持续和适用工作负载。
- latency：参数components_s（各段最大值列表）、limit_s；含成帧、CDC、排队、计算、访存、传输与软件。不能将若干独立分位数简单相加声称端到端同分位；统计型指标使用analysis型预算并说明联合模型。
- buffer：参数initial_bytes、inflight_bytes、margin_bytes、capacity_bytes、windows（重复停顿/恢复片段，含duration_s、arrival_Bps、service_Bps）、periodic。每段净流入后队列下限0；周期累计到达超过累计可服务量时判unbounded，不能仅凭首周期末占用高于初始值就判持续倒挂。非正净流入周期额外模拟一周期，覆盖跨周期积压峰值。模型限于逐段常速的服务容量假设，有限观察窗不能证明任意服务条件，必须说明窗口覆盖和不可反压时策略。

其他kind=analysis：用`analysis`文本和evidence_refs提供可复核公式/模型，不执行任意eval。覆盖资源、存储、精度、功耗、物理规划；自动结果unknown，不冒称脚本已经验证计算。资源同时列LUT/FF/DSP/RAM/时钟/GT/IO及局部约束、调试开销；无器件资料容量保持未知。

定点链：每节点总位W/小数F/符号/单位/范围、全精度中间值、缩放、正负舍入中点、饱和/回绕、除零与状态恢复。反馈插流水要有算法等价性证据，随机不溢出不能代替范围证明。算法特有条件按指南第6～9章检查。

按器件和受控资料记录工具链及版本、器件/封装/速度级、IP版本/配置/许可证、板卡版本和资料来源。按配置记录适用范围，器件或板卡配置不同则分别核算。未提供写 null 并登记缺口。后续约束义务包括主/派生时钟、IO min/max、抖动/不确定性、模式/角、CDC物理限制、例外范围与理由、未约束路径审查。引脚、Bank 和收发器参考时钟须核对器件封装与板级资料。

交接按目标工具链指定约束格式和待生成的时钟、时序、例外、CDC、DRC 与资源报告。命令与选项以实际工具版本为准。实现结果须关联实际运行的版本、日志和配置摘要。未运行工具时证据等级为 theory、estimate 或 plan。
