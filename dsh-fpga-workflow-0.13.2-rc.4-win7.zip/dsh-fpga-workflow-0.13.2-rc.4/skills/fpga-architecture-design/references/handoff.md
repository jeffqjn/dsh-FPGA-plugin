# 下游交接

设计师从包根目录的 `review.html` 开始评审。首页由同版模型、预算结果和输入摘要生成，可离线打开，链接到报告、四视图、问题、证据和结构化交接文件。首页随包校验。冻结包首页引用本版冻结记录，原评审首页以 `reviewed_review.html` 归档。

首页“分功能架构图”可逐项展开。每项功能在 `diagrams/functions/` 有独立 SVG 与 Mermaid 源，`index.json` 记录功能层级、子单元、模块、接口和有效需求修订。图和索引随包做内容校验。

建模时在 `review_paths` 用 `name` 和有序 `node_refs` 选出少量主数据流路径。相邻 UID 必须有数据流视图中的同向边，路径卡片显示节点名称和 UID。对关键事务，在 `review_timelines` 填写 `name`、时间原点 `reference`、按 `offset_us` 排序的 `events`（每项含 `label`）和同版 `evidence_refs`。标清估算、响应起点、结果可用点和消费期限。有新输入但尚未重新生成架构时，独立评审材料应注明草案版本并链接其证据。

消费者先validate本包，再核验package.status、synthetic、readiness、review及限制。DRAFT可用于评审/探索；仅FROZEN且自身输入足够时可按批准范围推进详细设计。冻结不是仿真或确认测试ready的替代判断。

`architecture.json`是本Skill架构事实/提案的单一源；`documentation_input.json`、`interface_contracts.json`、`inheritance_delta.json`、`RTM.csv`、`diagrams/*.mmd`、预算结果与报告由它派生，不能分开手改。`inputs/`保留冻结上游及继承资料，`generation/`保留本轮范围方案和用户生成批准；上游需求级ICD与新架构接口契约分文件保存。

文档Skill优先消费documentation_input.json及schemas/documentation.schema.json，按结构化章节、段落和对象引用成文，不解析报告Markdown找事实。读取package/review判断正式批准状态；生成批准只授权设计与输出。继承场景legacy_baseline包含完整现状模型，as_is_architecture.json为同内容独立副本，model为完整目标模型，legacy_objects/changes表达映射和差异。文档应同时展示现状、复用/修改/替换/删除/新增、理由、兼容/迁移、影响和回归，不能仅从变更片段猜完整目标架构。

`detailed_design_input.json`包含模块契约、接口、域、CDC、预算、决策、未决项、约束义务；设计者继续分解寄存器、FSM、微架构和RTL，保留ARCH UID及需求UID/修订。`verification_input.json`包含义务、判据、方法、对象、前提、需求修订、规则、未决项及result_status=not_run。验证Skill应把VO映射为其本地格式；这不是现有fpga-verification-plan等Skill的无适配替代输入。

追溯为有效REQ/revision→ADR→模块/接口→VO→后续用例→结果→构建。当前没有后续用例/结果时RTM记录NOT_RUN；不能把规划覆盖率写成验证通过率。未分配需求仍有RTM行并显示UNALLOCATED。

变更时重新prepare，change_log列before/after基线、修改理由、requirement_refs、object_refs、evidence_refs和regression_scope。原授权仅对原包摘要有效；不得因ID相同就继承旧证据结论。
