# 继承代码与既有架构的增量设计

用户提供继承工程时默认incremental。即使预计改动60%～70%，也从现有架构出发做差异设计，明确保留与替换边界；要改成new模式必须在新方案中说明并获得用户明确批准，不能隐藏或丢弃旧基线。

## 输入与只读快照

在继承资料根目录准备清单，例如：

```json
{
  "baseline_name":"现有采集工程v2",
  "files":[
    {"path":"rtl/top.v","role":"rtl","encoding":"utf-8"},
    {"path":"constraints/board.xdc","role":"constraints","encoding":"utf-8"},
    {"path":"docs/architecture.json","role":"architecture","encoding":"utf-8"},
    {"path":"ip/core.xci","role":"ip","encoding":"utf-8"},
    {"path":"reports/timing.rpt","role":"implementation_evidence","encoding":"gb18030"}
  ]
}
```

先按legacy-store.md执行legacy-prepare及legacy-build，把代码和结构说明整理为结构化现状包。然后`prepare --baseline <需求发布包> --legacy-baseline <现状包> --output <新目录>`绑定现状与目标需求。原始--legacy仍只复制清单与文件，但不能越过结构化现状直接propose目标变更。路径相对清单目录，不允许绝对/上级跳转；不要求Git，不执行Tcl/XDC/工程脚本，不编译或改写继承代码。编码支持utf-8/utf-8-sig/gb18030/ascii/binary；不可读关键依赖明确标记并登记缺口。

## 批准前的as-is调查

Agent读取legacy_inventory及源文件，建立可定位的现状：top/层次、模块实例/参数/宏、generate分支、端口与数据格式、时钟复位、CDC/RDC、存储、寄存器、IP、XDC、构建配置、验证与历史缺陷。仅由文本或名称推断的内容标inferred/unknown，不把正则匹配当成完整HDL展开；宏/参数组合、封装IP和不可读关键依赖不足时登记风险。

代码说明当前实现，批准需求说明目标义务；二者冲突必须显式登记，不能因为旧代码这样写就当作新的需求约束。历史时序/仿真/板测证据要核对其代码、约束、器件、工具与工况，未经核对仅为prior_only。

generation_plan绑定legacy_architecture_sha256，并从现状基线预置全部已识别对象。legacy_scope保留uid、original_uid、name、kind、file_refs、locator、current_behavior、confidence，另加action及理由；不得在目标变更方案中悄悄修改现状事实。uid使用稳定LEG命名。文件状态可以analyzed/deferred/excluded/unreadable，未阅读文件保留deferred及补读触发条件，不强迫一次载入全部源码，也不能把deferred当已分析。关键文件无法分析时说明受阻范围，不因用户批准生成就变ready。

action是reuse/modify/replace/remove，新增设计在change_scope中用add。检查哪些内容必须保留：已稳定验证模块、外部协议与管脚、软件ABI、时钟复位边界、性能/精度、已批准安全策略；未提供保留约束时提出可审阅建议，不能自行认定全部可推倒。

estimated_change_percent允许null。若用户说约10%或70%，标明是用户预估；若自行计算，给出分母（模块数、功能义务、改动工作量等）、权重、证据及不确定性。行数比例不能代替架构影响。该比例只描述范围，不控制是否重建。

## 批准后的to-be设计

check-approval成功后，沿用原架构进行目标设计。legacy_objects补全current_behavior、confidence、target_refs、requirement_refs、impact_refs、regression_refs、evidence_refs和verification_status。reuse仍须检查新工况下成立的前提；modify明确修改边界；replace明确封装/接口替代；remove检查消费者、初始化、约束和软件依赖。target_refs保留从旧对象到目标对象的映射，删除对象保留墓碑记录而不悄然消失。

changes逐项描述原对象→目标对象、需求依据、兼容影响、迁移/切换、回退和回归VO。追踪数据流、控制流、共享资源、配置、错误恢复和跨域影响，不能只检查编辑过的文件。结构变化影响缓存/吞吐/延迟、位宽、资源、CDC、约束和验证时重算/重审；未变化对象若受到新环境影响也要回归。

输出inheritance_delta.json与完整目标architecture.json：后续写文档必须同时能说明现有架构、复用部分、修改内容、理由与影响，而不是只得到一个变更片段。保留原代码快照；本Skill不直接执行RTL修改。
