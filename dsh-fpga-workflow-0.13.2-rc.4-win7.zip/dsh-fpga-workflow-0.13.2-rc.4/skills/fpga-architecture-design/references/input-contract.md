# 输入合同与上游适配

适配来源见 source_manifest.json。支持 req-spec-consistency-check 1.3.0 和 2.0.0 的 FEIP/1.0.0、FEIP-ICD/1.0.0 交付。随包 vendor/feiplib 保留原版 contract.py 和 icd.py，base.py 提供 ICD 所需的加载、摘要与断言；protocol/schemas 为独立副本。部署不依赖原目录。新增生产者版本前，用正式交接包对照 Schema，并重放发布模型、候选及正式 ICD 绑定校验。

`prepare --baseline <目录>` 对上游执行原版 contract.validate_package 和 icd.verify：核验Schema、引用、源快照、每个artifact字节摘要、正式ICD与reqspec的投影一致、candidate_icd与已确认候选绑定。还要求主模型是reqspec.json、producer为req-spec-consistency-check，profile=reqspec-reviewed、status=complete、stage=released、门禁overall=PASS。synthetic标志向下传播，合成样本不能成为正式项目冻结。

读取 `reqspec.views.architecture`、`icd.review.consumer_views.architecture` 和 ICD 中 `blocking_for` 包含 architecture 的全部诊断。任一视图 blocked 或存在此类诊断时，用 `prepare --diagnostic` 冻结只读诊断快照。诊断轮交付差距清单及来源，记录受影响流段、待补资料和复验判据。`propose`、`check-approval` 和 `build` 均拒绝诊断轮。conditional 可形成受限草稿，freeze 要求 ready。

诊断时对照有效需求检查 ICD 对象覆盖及需求与对象的双向追溯。按本项目实际适用范围核查端点、时钟复位、协议、帧格式和数据对象。字段级诊断为空时仍检查整类对象是否遗漏。若源规定某管脚预留且未连接，记录该证据并交上游核实状态和适用范围，避免把方向未知直接解释成活动信号。

有效集合：`effective_requirements[]` 的 requirement_uid/revision_uid，以台账中active requirement的effective_revision_uid交叉核对；使用该revision.semantic.constraint_refs。遍历analysis.constraints整个历史数组不能直接当有效采用值。prepare输出完整有效清单和有效约束，ICD的effective_requirement_constraint_refs须与之相等。

上游豁免保留实际差异和缺口，不代表需求取消。删除/历史修订仍在源快照，不纳入当前有效分母，但保留变更影响记录。架构设计提案不得回写reqspec/icd。若用户要求修改源指标，先登记冲突并交给上游需求变更流程。

`prepare`将上游包内全部清单artifact复制为只读意义的内容快照（并非修改文件权限），保留原package.json；不复制清单之外文件。指南/规则/报告模板也冻结并记录摘要。之后模型和交付均绑定attempt摘要，输出不能位于任何输入目录之内，已有目录不覆盖。prepare后的输入摘要变化会拒绝build。

没有提供某项数据不等于不适用。若旧包无ICD，须从原模型经上游重新导出；本Skill不推测重建需求级ICD。额外协议/器件资料以`evidence`记录路径、摘要、章节、版本和阅读结论；不能仅凭链接存在即称已经验证。
