# 先整理现有架构，再增删改查

## 两份模型

legacy_architecture.json是as-is描述性基线，architecture.json是获批后设计的to-be目标模型。前者只描述代码/结构说明所表达的现状，status固定DESCRIPTIVE_DRAFT，不声称已评审、正确或通过测试。整理和只读查询已在用户授权范围内；目标架构设计、增删改输出仍需先批准范围。

继承侧最少是代码目录与结构说明。清单由Agent从目录整理，用户无需手工维护UID或摘要。可以先整理现状，之后再接入目标需求/ICD包。IP配置、初始化文件、宏等已知依赖尽量列入，缺失信息登记unknowns，不能假设其不存在。

## 分批建立结构化基线

1. legacy-prepare仅冻结输入并生成legacy_inventory、legacy_workspace及legacy_architecture.template。只建文件索引，不表示已理解全部HDL。
2. Agent从顶层、结构说明和当前变更相关模块开始，使用legacy-read分段读取。为对象建立稳定UID、原始ID、模块/接口/时钟/复位/存储/IP等种类、行为摘要、端口、属性、关系、代码来源行及未知项。
3. 每个文件标记indexed/read/deferred/excluded/unreadable。未阅读的文件保留在索引，不伪装read或不适用。分批分析记录存磁盘，必要时回查源码，不依赖长期聊天记忆。
4. legacy-build验证Schema、UID、关系、来源范围与逐文件状态，然后生成完整legacy_architecture.json、objects/逐对象JSON、object_index、relationship_index、coverage及带摘要的legacy_package。输出目录必须全新。
5. legacy-query分页查询对象；默认只返回简要信息，--detail建议配--limit 1。legacy-read每次最多500行和约20k字符，保留文件摘要、原行号和下一段入口；超长单行会明确截断，不能当作已读完整行。

现状模型的configuration记录top、实际宏/参数、工具和器件。properties以key/value/unit/status表示各模块或其他对象的具体属性；未知值用null。ports记录方向/位宽/格式/域引用。source_spans是file_uid、起止行与理由。confirmed对象或关系必须有代码/文本依据，但“确认代码写了什么”不等于确认实现满足需求。verification_status仅允许not_run/prior_only。

现状认识逐步补全时，读旧JSON后另存新版本再legacy-build到新目录，不覆盖旧包。填写parent_baseline_sha256为前包legacy_package.json摘要、revision_reason说明修正原因，并通过--parent <旧整理包>核验后继承其模型/清单历史快照。若修改了代码输入，应重新legacy-prepare；若仅补充理解，继续使用相同源码workspace。新现状模型有新摘要，目标范围方案必须重新绑定。

## 基于基线的增删改查

| 操作 | 处理方式 |
|---|---|
| 查询 | legacy-query按UID/种类/分页查对象，查原文用legacy-read；不需变更批准 |
| 新增 | 目标changes登记add，分配新目标UID，关联新需求和验证义务 |
| 修改/替换 | 在legacy_scope批准modify/replace，保留旧UID、original_uid、目标映射、影响/迁移/回退和回归 |
| 删除 | changes登记remove，目标映射为空；旧对象保留在as-is和历史记录，不物理删除基线记录 |
| 复用 | 默认reuse，重新检查新需求/工况与接口依赖，不能自动继承旧通过结论 |

prepare --legacy-baseline将已整理包与需求基线共同冻结；generation_plan绑定现状模型SHA256并预置全部已识别旧对象。未变对象也有去向，不能因只关心改动部分而悄然遗漏。随后propose→用户批准→check-approval→基于原架构完成目标模型→build/validate。事实纠正不能偷偷混进变更提案；先新建现状版本，再提交对应目标方案。

当前工具检查对象/摘要/来源等确定性条件；代码展开、功能理解与变更影响由Agent分析。部分索引仍可交付描述性草稿，但不能据此宣称全工程已分析，关键未知项仍阻断相应目标冻结。

## Python3.8.10 / PowerShell2.0命令

```powershell
& 'C:\Python38\python.exe' 'D:\skills\fpga-architecture-design\scripts\cli.py' legacy-prepare --legacy 'D:\old\manifest.json' --output 'D:\work\legacy-work'
# Agent分批阅读并填写模板副本后：
& 'C:\Python38\python.exe' 'D:\skills\fpga-architecture-design\scripts\cli.py' legacy-build --workspace 'D:\work\legacy-work' --model 'D:\work\legacy.agent.json' --output 'D:\work\legacy-v1'
& 'C:\Python38\python.exe' 'D:\skills\fpga-architecture-design\scripts\cli.py' legacy-query --baseline 'D:\work\legacy-v1' --kind module --offset 0 --limit 20
& 'C:\Python38\python.exe' 'D:\skills\fpga-architecture-design\scripts\cli.py' prepare --baseline 'D:\req\release' --legacy-baseline 'D:\work\legacy-v1' --output 'D:\work\target-attempt'
```

所有动作仍须退出码0和FPGA_ARCH_OK:<action>。legacy-validate --baseline用于检查整理包完整性，不代替设计评审。
