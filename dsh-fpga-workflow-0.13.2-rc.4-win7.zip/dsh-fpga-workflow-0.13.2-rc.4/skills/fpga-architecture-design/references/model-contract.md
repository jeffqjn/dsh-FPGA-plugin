# FPGA-ARCH/1.1.0模型合同

Schema：`architecture.schema.json`。prepare生成已绑定本轮attempt的内部模板；在propose方案获用户批准且check-approval成功后，才执行目标设计并另存architecture.agent.json，不能覆写输入快照。ID自由命名但全局唯一，建议MOD-/IF-/CLK-/RST-/CDC-/ADR-/BUD-/VO-/ISS-/EVD-/CHK-；不复用上游UID。生成批准和完整文档交接结构见approval-document.md；继承模型见incremental-design.md。

顶层 contract、attempt_uid、binding_sha256 绑定当前轮次。project/version/phase(G0 或 G1)/author/configuration/scope/target 记录项目实际字段。target.environment 记录与器件匹配的工具链名称，toolchain_version 记录受控版本。原 Vivado 模型可继续使用 vivado_version。未知工具链、版本、器件、板卡或 IP 基线以 null 表示并阻断冻结。无 IP 时记录可追溯的依据。document_sections 是章节、段落与引用的结构化正文。narratives 保留六份报告的兼容摘要。change_log 保留变更、影响与回归。design_context、legacy_objects、changes 记录设计模式、现状到目标映射和增量设计。new 模式的 legacy_objects 为空。

工程对象modules/interfaces/clocks/resets/cdcs/decisions/budgets/verification_obligations的共同字段：uid/name/requirement_refs/evidence_refs/issue_refs/basis。requirement_refs只引当前有效REQ UID；revision由allocations绑定。evidence_refs只引本模型EVD，source_refs/upstream_refs用于上游事实。basis区分source/derived/proposal/assumption，不因记录进入JSON就自动批准。

特有字段详见Schema和design-method：

| 数组 | 主要特有字段 |
|---|---|
| modules | clock_refs/reset_refs，contracts八类契约字符串 |
| interfaces | internal/external、upstream_refs、endpoint_refs、contract、clock_refs/reset_refs |
| clocks | frequency quantity、source_refs、contract（含关系/停止/动态变化） |
| resets | clock_refs、contract（置位/释放/最小脉宽/依赖/RDC） |
| cdcs | source_clock/destination_clock、signal_semantics、method、assumptions、constraints、verification_refs |
| decisions | alternatives、selected、rationale、risk、fallback |
| budgets | kind、parameters、parameter_sources、unit、analysis、assumptions |
| verification_obligations | object_refs、criterion、method、preconditions、rule_refs |

budget.parameters是命名参数字典；每个参数在parameter_sources中有同名非空来源UID数组。数值单位在参数名规定，如clock_hz、arrival_Bps。来源可为上游有效约束/对象、EVD或ADR，提案及效率前提在basis/assumptions明确。未知数填null，并以issue_refs关联问题。不使用未经限定的可执行表达式。

```json
{
  "uid":"BUD-01","name":"持续采样处理能力","requirement_refs":["req:实际UID"],
  "evidence_refs":["EVD-01"],"issue_refs":[],"basis":"derived","kind":"throughput",
  "parameters":{"clock_hz":100000000,"lanes":1,"vector":1,"ii":2,"efficiency":0.8,"memory_limit_sps":30000000,"required_sps":20000000},
  "parameter_sources":{"clock_hz":["EVD-01"],"lanes":["ADR-01"],"vector":["ADR-01"],"ii":["EVD-01"],"efficiency":["EVD-01"],"memory_limit_sps":["EVD-01"],"required_sps":["req:实际UID"]},
  "unit":"sample/s","analysis":"引用实际计算文件及条件。","assumptions":"来源材料限定的工作负载。"
}
```

此段仅说明格式，数值不是项目建议。analysis型预算的自动status保持unknown；若要冻结，必须有针对该budget对象、独立复核人、同一证据的到期pass检查，并有可复核analysis正文。机械数值未知或失败不能用此途径覆盖。

evidence.path相对于Agent模型所在目录，禁止绝对/上级跳转路径。build复制到support/并按原相对路径保存；SHA256必须匹配真实文件。locator记录章节/页/日志行；version、level、date、tool_environment、conclusion说明证据条件。可以把准备包中的证据复制到模型旁的evidence/目录后引用，不把路径存在当作已阅读。外部网页先取得可离线核验的项目资料及版本，不能伪造内容或日期。

allocations必须包含每个有效REQ一次，原requirement_uid/revision_uid不能变。object_refs与verification_refs允许DRAFT未分配，但freeze会阻断。VO和对象的requirement_refs须与分配相互一致。views必须恰好四项functional/data/clock_reset/physical，node_refs/edges引用同一对象UID；图由模型生成。

`function_views` 每项含稳定 `FN-...` UID、名称、有效需求 UID、父功能 UID 或 null、`units`、`ports` 和 `internal_flows`。单元含 UID、名称及实现模块 UID。端口以 `interface_ref/module_ref/unit_ref/direction/kind` 绑定全局数据流的定向接口边，双向逐方向录入。模块内连线以 `from/to/module_ref/label/kind` 绑定同一模块内的子单元。流类别为 data、control、status、clock_reset。 每个模块侧接口方向都须绘出或在 `excluded_ports` 说明范围理由。由本功能需求分配的接口和本功能所含模块间的接口须绘出。子图须覆盖或解释所选模块在父图上的端口。 根图未展开的已分配模块或接口须逐一列入 `support_refs`，并在评审页可见。功能图至少有一条流。SVG 边号对应首页逐边表及 Mermaid 边标签。模式相关路径用 `condition` 描述。同一接口方向展开到多个单元时，各映射均须注明模式或分发条件。脚本检查每条有效功能需求有图、模块在需求分配内、相关接口边齐全、父子层级无环及子单元可达。子图可选取父图端口和模块的子集。功能义务之外的协议或接口需求可随功能纳入。按具体模式核对分支条件、共享逻辑和依赖项。

data 视图用有向边表示生产端 → 接口 UID → 消费端。双向接口按各方向分别列边，标签注明相应载荷或事件。接口相邻节点集合须与 endpoint_refs 一致，且至少各有一条入边和出边。外部接口引用需求级 ICD 接口 UID，脚本据其已知信号方向核对 FPGA 边界，并在唯一 FPGA 端点明确时检查其余 ICD 端点是否沿同一接口声明的板级端点可达。双向多端点的逐信号方向、位宽、选通条件与协议按源证据复核。

checks与issues格式见rules-review。问题关闭/偏离需证据，不能仅变status。deviations逐条记录rule_id/object_ref/issue_ref、reason/impact/compensation/configuration/expiry_condition、approver/approved_at、verification_requirement/exit_plan及evidence_refs；证据中须含实际review记录。hard_requirement_conflict=true时阻断冻结，不能靠偏离覆盖绝对额定值或有效硬性需求冲突。输出不提供虚构批准记录。

freeze输入review.json字段：kind=approve_architecture_freeze、package_sha256（当前DRAFT package.json实际SHA256）、actor、user_quote、confirmed_at、allowed_scope、conclusion=通过、reviewer、evidence_refs、participants。participants是包含role(architecture/design/verification)、name、reviewed_at的真实评审记录数组。evidence_refs须引用模型已有level=review证据；关键复核人不同于author。没有真实评审和当前包授权不创建此文件。freeze生成新FROZEN清单与独立review.json；原DRAFT报告保持其被评原字节，审批状态以新package/review记录为准。
