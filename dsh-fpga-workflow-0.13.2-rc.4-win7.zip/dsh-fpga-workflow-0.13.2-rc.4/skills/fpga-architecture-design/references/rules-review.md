# 规则覆盖与关口

`rules.json`逐行提取随包规则规范中M/S/F/R/C/O编号、原文、来源行号与SHA256。条文正文是权威；脚本索引不改写条文适用前提。所有ID均必须在checks中出现。适用规则需要针对每个相关module/interface/clock/reset/cdc/budget等对象展开，不以一个design全局记录覆盖全部实例。

每条check包含uid、rule_id、object_ref、configuration、phase、applicability(pending/applicable/not_applicable)、criterion、method、evidence_refs、result(unchecked/pass/fail/insufficient/not_applicable/deviation/planned)、issue_refs、owner、reviewer、date、baseline、rationale。检查矩阵元数据用实际值；unknown不伪装为签署。S类推荐项也记录采用/替代理由，不自动作为强制失败。

prepare给出pending记录供Agent分配，不自动决定G0/G1/G2/G3或适用性。未来G2/G3项用planned并记录执行计划；不计当前到期分母。not_applicable必须applicability=not_applicable、有理由与实际复核人。pass有判据/方法/证据、当前基线，证据强度必须与阶段相符。deviation必须有真实批准证据、范围、补偿、失效与验证条件，不计pass。

统计按条款×对象×配置实例：到期适用=pass+fail+unchecked+insufficient+deviation；N/A、planned单列；符合率pass/N_due，N_due=0为null。已失败处置不算符合。规则覆盖率是有记录的编号数/规则总数；不等于对象展开完整，也不等于设计满足率。脚本检查引用和基本一致性；Agent还要审查每个对象的展开充分性与证据语义。

问题B0/B1阻断冻结；B2限期/有效偏离；B3建议不自动阻断。关键证据不足不能靠降低问题等级绕过G1。review.json绑定当前package.json SHA256；评审记录至少包含架构、设计、验证角色，关键项reviewer不得仅为作者，结论通过，有真实evidence_refs及明确允许范围。冻结前重新核验所有输入、模型、报告和证据；任一变更使旧摘要授权失效。

完整模板见guide/报告模板。G1输出RPT-01/02/03/04/06/07；RPT-04只表达计划，不生成测试通过。RPT-05与RPT-08属于后续实现和构建发布，当前只在handoff中列责任/关口，不虚构报告。
