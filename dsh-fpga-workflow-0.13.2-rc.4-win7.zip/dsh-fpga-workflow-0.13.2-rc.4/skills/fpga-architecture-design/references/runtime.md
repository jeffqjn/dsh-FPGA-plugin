# Windows7离线运行

生产CLI精确要求Python 3.8.10。标准库，无pip/Node/网络依赖。默认解释器`C:\Python38\python.exe`，或进程环境变量FPGA_PYTHON38完整路径。PS1纯ASCII、#requires 2.0，只作参数转发和退出码核对；JSON/MD UTF-8无BOM，CSV UTF-8带BOM便于旧Excel查看。Mermaid提供文本源，渲染器是可选阅读工具，不是运行依赖。

```powershell
$env:FPGA_PYTHON38 = 'C:\Python38\python.exe'
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' doctor
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' self-test
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' prepare --baseline 'D:\project\req-release' --output 'D:\project\arch-attempt-01'
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' propose --attempt 'D:\project\arch-attempt-01' --plan 'D:\project\plan.json' --output 'D:\project\generation-proposal-01'
```

展示当前方案并等待用户明确批准，真实记录generation_approval.json后再执行：

```powershell
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' check-approval --attempt 'D:\project\arch-attempt-01' --proposal 'D:\project\generation-proposal-01' --approval 'D:\project\generation_approval.json'
```

检查成功后才由Agent执行详细设计并保存architecture.agent.json，然后：

```powershell
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' build --attempt 'D:\project\arch-attempt-01' --model 'D:\project\architecture.agent.json' --proposal 'D:\project\generation-proposal-01' --approval 'D:\project\generation_approval.json' --output 'D:\project\arch-review-01'
& 'D:\skills\fpga-architecture-design\scripts\run.ps1' validate --package 'D:\project\arch-review-01'
```

也可直接`& 'C:\Python38\python.exe' '<skill>\scripts\cli.py' <动作及参数>`。每动作须退出码0且`FPGA_ARCH_OK:<action>`。成功标记只表示动作成功，readiness另看JSON。doctor记录当前实际OS；即使Python检查通过也不宣称已在Win7真机验收。32/64位解释器须与目标系统匹配。

继承场景先使用legacy-prepare/legacy-build/legacy-query/legacy-read/legacy-validate，详见legacy-store.md；整理现状可只用代码和结构说明。然后prepare传--legacy-baseline <整理包>连接目标需求。原始--legacy只冻结文件，不能在缺少结构化现状时propose。prepare可加--diagnostic，完整性错误仍拒绝。propose参数--attempt/--plan/--output；check-approval参数--attempt/--proposal/--approval。未批准只保留输入、描述性现状和范围方案。build强制--proposal/--approval；validate同时核验现状摘要与目标派生一致性。freeze是生成之后的独立冻结关口。

失败退出2，错误含前缀；发布使用同级staging和目录锁，只有完成后rename成为交接目录。保留失败staging供诊断，不自动删除用户文件或并发锁。路径避免Win7 MAX_PATH限制，建议短根路径；中文路径走Unicode API，部署压缩包不含Python解释器或Vivado。
