"""FPGA-ARCH/1.0: deterministic package mechanics, not engineering judgement."""
import argparse
import copy
import csv
import hashlib
import io
import json
import math
import os
import platform
import re
import shutil
import sys
import uuid
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts/vendor"))
from feiplib import contract, icd, base

# Preserve the upstream ICD algorithms and schema subset without requiring another skill.
contract.ROOT = SKILL / "references/protocol"
base.SCHEMAS = contract.ROOT / "schemas"
icd.SCHEMAS = base.SCHEMAS
load = contract.read_json
sha = contract.sha_file
fingerprint = contract.fingerprint
safe = contract.safe_artifact
GROUPS = ("modules", "interfaces", "clocks", "resets", "cdcs", "decisions", "budgets", "verification_obligations")
REPORTS = (1, 2, 3, 4, 6, 7)
SUPPORTED_CHECKER_VERSIONS = {"1.3.0", "2.0.0"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def data_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data_bytes(value))


def all_files(root):
    return [p for p in sorted(root.rglob("*")) if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"]


def tool_fingerprint():
    return fingerprint({p.relative_to(SKILL).as_posix(): sha(p) for p in all_files(SKILL)
                        if p.parts[len(SKILL.parts)] in ("scripts", "references")})


@contextmanager
def transaction(output, sources=()):
    output = Path(output).resolve()
    for source in sources:
        source = Path(source).resolve()
        require(output != source and source not in output.parents and output not in source.parents,
                "OUTPUT_OVERLAPS_INPUT: " + str(output))
    require(not output.exists(), "OUTPUT_EXISTS: use a new directory")
    output.parent.mkdir(parents=True, exist_ok=True)
    lock = output.parent / ("." + output.name + ".lock")
    fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.close(fd)
    staging = output.parent / (output.name + ".staging-" + uuid.uuid4().hex)
    try:
        staging.mkdir()
        yield staging
        require(not output.exists(), "OUTPUT_EXISTS")
        os.rename(str(staging), str(output))
    except Exception as exc:
        if staging.exists():
            save(staging / "FAILED.json", {"status": "staging", "error": str(exc)})
        raise
    finally:
        lock.unlink()


def upstream(root, diagnostic=False):
    root = Path(root).resolve()
    errors = contract.validate_package(root)
    require(not errors, "UPSTREAM_PACKAGE_INVALID: " + "; ".join(errors[:15]))
    manifest = load(root / "package.json")
    model_artifact = next(a for a in manifest["artifacts"] if a["uid"] == manifest["model_artifact_uid"])
    model = load(safe(root, model_artifact["path"]))
    protocol = model["protocol"]
    require(protocol["producer"] == "req-spec-consistency-check" and
            protocol["producer_version"] in SUPPORTED_CHECKER_VERSIONS,
            "UNSUPPORTED_UPSTREAM_PRODUCER: " + protocol["producer"] + "/" + protocol["producer_version"])
    interface = icd.verify(root, model)
    released = (manifest["status"] == "complete" and protocol["profile"] == "reqspec-reviewed" and model_artifact["path"] == "reqspec.json" and
                interface["binding"]["stage"] == "released" and model["consistency"]["gates"]["overall"] == "PASS")
    views = [model["views"]["architecture"], interface["review"]["consumer_views"]["architecture"]]
    if not released or any(v["readiness"] == "blocked" for v in views) or any(
        "architecture" in gap["blocking_for"] for gap in interface["diagnostics"]
    ):
        readiness = "blocked"
    else:
        readiness = "conditional" if any(v["readiness"] == "conditional" for v in views) else "ready"
    require(diagnostic or readiness != "blocked", "ARCHITECTURE_INPUT_BLOCKED: use --diagnostic for analysis only")
    active = {r["uid"]: r for r in model["requirements"] if r["lifecycle"] == "active"}
    effective = []
    constraints = []
    for entry in model["effective_requirements"]:
        req = active[entry["requirement_uid"]]
        require(req["effective_revision_uid"] == entry["revision_uid"], "EFFECTIVE_REVISION_MISMATCH")
        rev = next(v for v in req["revisions"] if v["uid"] == entry["revision_uid"])
        effective.append(dict(entry, title=req["title"], statement=rev["semantic"]["statement"], constraint_refs=rev["semantic"]["constraint_refs"]))
        constraints.extend(rev["semantic"]["constraint_refs"])
    require(set(constraints) == set(interface["traceability"]["effective_requirement_constraint_refs"]), "ICD_EFFECTIVE_CONSTRAINT_MISMATCH")
    registry = {}
    for _, value in contract.walk(model):
        if isinstance(value, dict) and isinstance(value.get("uid"), str):
            registry[value["uid"]] = value
    return {"model": model, "manifest": manifest, "icd": interface, "registry": registry,
            "effective": effective, "constraints": sorted(set(constraints)), "readiness": readiness}


def empty_model(info, summary, rules):
    model = {"contract": "FPGA-ARCH/1.1.0", "attempt_uid": info["attempt_uid"], "binding_sha256": info["binding_sha256"],
             "project": "", "version": "0.1.0", "phase": "G1", "author": None, "configuration": "", "scope": "",
             "target": {"environment": None, "toolchain_version": None, "part": None, "board": None, "ip_baseline": None},
             "narratives": {"RPT-" + str(i).zfill(2): "" for i in REPORTS}, "change_log": [],
             "issues": [], "evidence": [], "deviations": [], "allocations": [], "checks": [], "views": [],
             "design_context": {"mode": "new", "legacy_manifest_sha256": None, "estimated_change_percent": None, "estimate_basis": "尚未估算"},
             "legacy_objects": [], "changes": [], "document_sections": [], "preservation_constraints": [],
             "review_paths": [], "review_timelines": [], "function_views": []}
    for group in GROUPS:
        model[group] = []
    for rule in rules:
        model["checks"].append({"uid": "CHK-" + rule["id"], "rule_id": rule["id"], "object_ref": "design", "configuration": "",
                                "phase": "G1", "applicability": "pending", "criterion": "", "method": "", "evidence_refs": [],
                                "result": "unchecked", "issue_refs": [], "owner": None, "reviewer": None, "date": None,
                                "baseline": summary["baseline_uid"], "rationale": ""})
    for req in summary["effective_requirements"]:
        model["allocations"].append({"requirement_uid": req["requirement_uid"], "revision_uid": req["revision_uid"],
                                     "object_refs": [], "decision_refs": [], "verification_refs": [], "rationale": ""})
    return model


def prepare(baseline, output, diagnostic=False, legacy=None, legacy_baseline=None):
    import evolution
    import legacy_store
    require(not (legacy is not None and legacy_baseline is not None), "CHOOSE_RAW_LEGACY_OR_STRUCTURED_BASELINE")
    baseline = Path(baseline).resolve()
    facts = upstream(baseline, diagnostic)
    sources = [baseline, SKILL]
    if legacy is not None:
        sources.append(Path(legacy).resolve().parent)
    if legacy_baseline is not None:
        sources.append(Path(legacy_baseline).resolve())
    with transaction(output, sources) as dest:
        if legacy_baseline is None:
            evolution.snapshot_legacy(legacy, dest)
        else:
            legacy_store.attach(legacy_baseline, dest)
        for item in facts["manifest"]["artifacts"]:
            path = safe(baseline, item["path"])
            if path.exists():
                target = safe(dest / "upstream", item["path"])
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(str(path), str(target))
        shutil.copyfile(str(baseline / "package.json"), str(dest / "upstream/package.json"))
        shutil.copytree(str(SKILL / "references/guide"), str(dest / "guide"))
        rules = load(SKILL / "references/rules.json")
        save(dest / "rules.json", rules)
        summary = {"baseline_uid": facts["model"]["protocol"]["baseline_uid"],
                   "run_uid": facts["model"]["protocol"]["run_uid"], "candidate_uid": facts["icd"]["binding"]["candidate_uid"],
                   "synthetic": facts["model"]["protocol"]["synthetic"], "readiness": facts["readiness"],
                   "diagnostic": diagnostic, "effective_requirements": facts["effective"],
                   "effective_constraint_refs": facts["constraints"],
                   "source_architecture_view": facts["model"]["views"]["architecture"],
                   "icd_architecture_view": facts["icd"]["review"]["consumer_views"]["architecture"],
                   "icd_diagnostics": facts["icd"]["diagnostics"]}
        save(dest / "input_summary.json", summary)
        bindings = {p.relative_to(dest).as_posix(): sha(p) for p in all_files(dest)}
        info = {"attempt_uid": "attempt:" + uuid.uuid4().hex, "created_at": now(),
                "tool_fingerprint": tool_fingerprint(), "bindings": bindings}
        info["binding_sha256"] = fingerprint(info)
        save(dest / "attempt.json", info)
        template = empty_model(info, summary, rules)
        template["design_context"] = evolution.context(dest)
        save(dest / "architecture.template.json", template)
        save(dest / "generation_plan.template.json", evolution.plan_template(dest, info))
    return {"attempt": str(Path(output).resolve()), "readiness": summary["readiness"], "synthetic": summary["synthetic"], "rules": len(rules)}


def verify_attempt(root, *, check_tool=True):
    import evolution
    root = Path(root)
    info = load(root / "attempt.json")
    unsigned = dict(info)
    unsigned.pop("binding_sha256")
    require(fingerprint(unsigned) == info["binding_sha256"], "ATTEMPT_BINDING_CHANGED")
    if check_tool:
        require(info["tool_fingerprint"] == tool_fingerprint(), "TOOL_OR_RULES_CHANGED: prepare again")
    for path, digest in info["bindings"].items():
        require(sha(safe(root, path)) == digest, "STALE_INPUT: " + path)
    facts = upstream(root / "upstream", True)
    summary = load(root / "input_summary.json")
    expected = {"baseline_uid": facts["model"]["protocol"]["baseline_uid"], "run_uid": facts["model"]["protocol"]["run_uid"],
                "candidate_uid": facts["icd"]["binding"]["candidate_uid"], "synthetic": facts["model"]["protocol"]["synthetic"],
                "readiness": facts["readiness"], "effective_requirements": facts["effective"], "effective_constraint_refs": facts["constraints"],
                "source_architecture_view": facts["model"]["views"]["architecture"], "icd_architecture_view": facts["icd"]["review"]["consumer_views"]["architecture"],
                "icd_diagnostics": facts["icd"]["diagnostics"]}
    require({k: v for k, v in summary.items() if k != "diagnostic"} == expected, "INPUT_SUMMARY_MISMATCH")
    require(not (summary["readiness"] == "blocked" and not summary["diagnostic"]), "DIAGNOSTIC_FLAG_REQUIRED")
    evolution.inventory(root)
    return info, summary, facts


def evaluate_budget(budget):
    kind, p = budget["kind"], budget["parameters"]
    if kind == "analysis":
        return {"uid": budget["uid"], "status": "unknown", "reason": "Agent analysis; not mechanically proved"}
    required = {"throughput": ("clock_hz", "lanes", "vector", "ii", "efficiency", "memory_limit_sps", "required_sps"),
                "latency": ("components_s", "limit_s"),
                "buffer": ("initial_bytes", "inflight_bytes", "margin_bytes", "capacity_bytes", "windows", "periodic")}[kind]
    require(set(p) == set(required), "BUDGET_PARAMETER_KEYS: " + budget["uid"])
    def has_null(v):
        return v is None or (isinstance(v, list) and any(has_null(x) for x in v)) or (isinstance(v, dict) and any(has_null(x) for x in v.values()))
    if has_null(p):
        require(budget["issue_refs"], "UNKNOWN_BUDGET_NEEDS_ISSUE")
        return {"uid": budget["uid"], "status": "unknown", "reason": "unknown input; no defaults substituted"}
    def number(v, positive=False):
        require(type(v) in (int, float) and math.isfinite(v) and (v > 0 if positive else v >= 0), "INVALID_BUDGET_NUMBER")
        return v
    if kind == "throughput":
        for key in required:
            number(p[key], key in ("clock_hz", "lanes", "vector", "ii"))
        require(p["efficiency"] <= 1 and all(type(p[k]) is int for k in ("lanes", "vector", "ii")), "INVALID_THROUGHPUT_PARAMETERS")
        value = min(p["clock_hz"] * p["lanes"] * p["vector"] / p["ii"] * p["efficiency"], p["memory_limit_sps"])
        status = "pass" if value >= p["required_sps"] else "fail"
    elif kind == "latency":
        require(isinstance(p["components_s"], list) and p["components_s"], "LATENCY_COMPONENTS_REQUIRED")
        value = sum(number(v) for v in p["components_s"])
        status = "pass" if value <= number(p["limit_s"]) else "fail"
    else:
        require(type(p["periodic"]) is bool and isinstance(p["windows"], list) and p["windows"], "BUFFER_WINDOWS_REQUIRED")
        q = number(p["initial_bytes"])
        peak = q
        increments = []
        for window in p["windows"]:
            require(set(window) == {"duration_s", "arrival_Bps", "service_Bps"}, "INVALID_BUFFER_WINDOW")
            increments.append(number(window["duration_s"], True) * (number(window["arrival_Bps"]) - number(window["service_Bps"])))
        net = math.fsum(increments)
        # Reflection at empty means q_end > q_start alone does not prove drift.
        # For nonpositive period net, one additional cycle covers the periodic
        # fixed point (or an occupancy no higher than the initial transient).
        cycles = 2 if p["periodic"] and net <= 0 else 1
        for _ in range(cycles):
            for increment in increments:
                q = max(0, q + increment)
                peak = max(peak, q)
        value = peak + number(p["inflight_bytes"]) + number(p["margin_bytes"])
        status = "unbounded" if p["periodic"] and net > 0 else "pass" if value <= number(p["capacity_bytes"]) else "fail"
    return {"uid": budget["uid"], "status": status, "value": value, "unit": budget["unit"], "basis": budget["basis"], "scope": budget["assumptions"]}


def validate_model(model, attempt, evidence_root=None, *, check_tool=True):
    info, summary, facts = verify_attempt(attempt, check_tool=check_tool)
    schema = load(SKILL / "references/architecture.schema.json")
    contract.audit_schema(schema)
    errors = contract.validate_schema(model, schema)
    require(not errors, "ARCH_SCHEMA_INVALID: " + "; ".join(errors[:20]))
    require(model["attempt_uid"] == info["attempt_uid"] and model["binding_sha256"] == info["binding_sha256"], "MODEL_BOUND_TO_OTHER_ATTEMPT")
    for key in ("project", "version", "configuration", "scope"):
        require(model[key].strip(), "EMPTY_DESIGN_FIELD: " + key)
    entities = [x for group in GROUPS for x in model[group]]
    local = entities + model["issues"] + model["evidence"] + model["checks"] + model["deviations"] + model["legacy_objects"] + model["changes"] + model["document_sections"]
    ids = [x["uid"] for x in local]
    require(len(ids) == len(set(ids)) and all(ids), "DUPLICATE_OR_EMPTY_ARCH_UID")
    require(not set(ids).intersection(facts["registry"]), "ARCH_UID_COLLIDES_WITH_SOURCE")
    registry = {x["uid"]: x for x in local}
    source_ids = set(facts["registry"])
    historical_constraints = {x["uid"] for x in facts["model"]["analysis"]["constraints"]} - set(summary["effective_constraint_refs"])
    known = set(ids) | source_ids | {"design"}
    sets = {group: {x["uid"] for x in model[group]} for group in GROUPS + ("evidence", "issues")}
    effective = {r["requirement_uid"]: r["revision_uid"] for r in summary["effective_requirements"]}
    def check_refs(values, allowed, context):
        require(set(values) <= set(allowed), "DANGLING_OR_WRONG_TYPE_REFERENCE: " + context + ": " + str(set(values) - set(allowed)))
        require(not set(values).intersection(historical_constraints), "HISTORICAL_CONSTRAINT_NOT_EFFECTIVE: " + context)
    for entity in entities:
        check_refs(entity["requirement_refs"], effective, entity["uid"])
        check_refs(entity["evidence_refs"], sets["evidence"], entity["uid"])
        check_refs(entity["issue_refs"], sets["issues"], entity["uid"])
        require(entity["name"].strip(), "ENTITY_NAME_EMPTY")
    for group in ("modules", "interfaces", "resets"):
        for x in model[group]:
            check_refs(x["clock_refs"], sets["clocks"], x["uid"])
            if "reset_refs" in x:
                check_refs(x["reset_refs"], sets["resets"], x["uid"])
    for x in model["interfaces"]:
        check_refs(x["upstream_refs"], source_ids, x["uid"])
        check_refs(x["endpoint_refs"], sets["modules"] | source_ids, x["uid"])
        require(len(set(x["endpoint_refs"])) >= 2, "INTERFACE_ENDPOINTS_REQUIRED")
        if x["scope"] == "external":
            require(x["upstream_refs"], "EXTERNAL_INTERFACE_SOURCE_REQUIRED")
    for x in model["clocks"]:
        check_refs(x["source_refs"], source_ids | sets["decisions"], x["uid"])
        q = x["frequency"]
        check_refs(q["source_refs"], known, x["uid"])
        if q["issue_ref"] is not None:
            check_refs([q["issue_ref"]], sets["issues"], x["uid"])
        if q["value"] is None:
            require(q["issue_ref"] in sets["issues"], "UNKNOWN_QUANTITY_NEEDS_ISSUE")
        else:
            require(q["value"] > 0 and q["unit"] == "Hz" and q["source_refs"], "INVALID_CLOCK_FREQUENCY")
    for x in model["cdcs"]:
        check_refs([x["source_clock"], x["destination_clock"]], sets["clocks"], x["uid"])
        require(x["source_clock"] != x["destination_clock"], "CDC_SAME_DOMAIN")
        check_refs(x["verification_refs"], sets["verification_obligations"], x["uid"])
    for x in model["verification_obligations"]:
        check_refs(x["object_refs"], set(ids) | source_ids, x["uid"])
        check_refs(x["rule_refs"], {r["id"] for r in load(Path(attempt) / "rules.json")}, x["uid"])
    seen = set()
    for a in model["allocations"]:
        uid = a["requirement_uid"]
        require(uid not in seen and effective.get(uid) == a["revision_uid"], "ALLOCATION_REVISION_OR_DUPLICATE")
        seen.add(uid)
        check_refs(a["object_refs"], set().union(*(sets[g] for g in ("modules", "interfaces", "clocks", "resets", "cdcs", "budgets"))), uid)
        check_refs(a["decision_refs"], sets["decisions"], uid)
        check_refs(a["verification_refs"], sets["verification_obligations"], uid)
        for object_uid in a["object_refs"]:
            require(uid in registry[object_uid]["requirement_refs"], "ALLOCATION_OBJECT_REQUIREMENT_MISMATCH")
        for vo_uid in a["verification_refs"]:
            require(uid in registry[vo_uid]["requirement_refs"], "VO_REQUIREMENT_LINK_MISMATCH")
    require(seen == set(effective), "EFFECTIVE_REQUIREMENTS_OMITTED")
    rules = {r["id"] for r in load(Path(attempt) / "rules.json")}
    require({c["rule_id"] for c in model["checks"]} == rules, "RULE_COVERAGE_INCOMPLETE")
    check_keys = set()
    for d in model["deviations"]:
        require(d["rule_id"] in rules and d["issue_ref"] in sets["issues"] and d["object_ref"] in known, "DEVIATION_REFERENCE_INVALID")
        check_refs(d["evidence_refs"], sets["evidence"], d["uid"])
        require(d["evidence_refs"] and d["approver"] and d["approved_at"] and
                all(d[k].strip() for k in ("reason", "impact", "compensation", "configuration", "expiry_condition", "verification_requirement", "exit_plan")), "DEVIATION_RECORD_INCOMPLETE")
        require(any(registry[e]["level"] == "review" for e in d["evidence_refs"]), "DEVIATION_APPROVAL_EVIDENCE_REQUIRED")
    for c in model["checks"]:
        check_refs([c["object_ref"]], known, c["uid"])
        check_refs(c["evidence_refs"], sets["evidence"], c["uid"])
        check_refs(c["issue_refs"], sets["issues"], c["uid"])
        key = (c["rule_id"], c["object_ref"], c["configuration"], c["phase"])
        require(key not in check_keys, "DUPLICATE_RULE_OBJECT_CONFIGURATION_PHASE")
        check_keys.add(key)
        require(c["baseline"] == summary["baseline_uid"], "CHECK_BASELINE_MISMATCH")
        if c["phase"] > model["phase"]:
            require(c["result"] == "planned" and c["rationale"], "FUTURE_CHECK_MUST_BE_PLANNED")
        else:
            require(c["result"] != "planned", "DUE_CHECK_CANNOT_BE_DEFERRED")
        if c["result"] in ("pass", "deviation"):
            require(c["applicability"] == "applicable" and c["criterion"] and c["method"] and c["evidence_refs"] and c["reviewer"] and c["date"], "UNSUPPORTED_CHECK_CONCLUSION")
        if c["result"] == "not_applicable" or c["applicability"] == "not_applicable":
            require(c["result"] == "not_applicable" and c["applicability"] == "not_applicable" and c["rationale"] and c["reviewer"], "NA_REASON_AND_REVIEW_REQUIRED")
        if c["result"] in ("fail", "insufficient", "deviation"):
            require(c["issue_refs"], "CHECK_ISSUE_REQUIRED")
        if c["result"] == "deviation":
            require(any(d["rule_id"] == c["rule_id"] and d["object_ref"] == c["object_ref"] and d["issue_ref"] in c["issue_refs"] for d in model["deviations"]), "CHECK_DEVIATION_RECORD_REQUIRED")
    require(len(model["views"]) == 4 and {v["kind"] for v in model["views"]} == {"functional", "data", "clock_reset", "physical"}, "FOUR_ARCHITECTURE_VIEWS_REQUIRED")
    for v in model["views"]:
        check_refs(v["node_refs"], set(ids) | source_ids, "view")
        require(len(v["node_refs"]) == len(set(v["node_refs"])), "DUPLICATE_VIEW_NODE")
        for edge in v["edges"]:
            require({edge["from"], edge["to"]} <= set(v["node_refs"]), "VIEW_EDGE_ENDPOINT_MISSING")
    from review_page import validate_views
    validate_views(model)
    if "function_views" in model:
        from function_views import collect
        collect(model, summary, facts)
    for issue in model["issues"]:
        check_refs(issue["object_refs"], known, issue["uid"])
        check_refs(issue["evidence_refs"], sets["evidence"], issue["uid"])
        if issue["status"] != "open":
            require(issue["evidence_refs"], "ISSUE_CLOSE_OR_DEVIATION_EVIDENCE_REQUIRED")
    for b in model["budgets"]:
        require(set(b["parameter_sources"]) == set(b["parameters"]), "BUDGET_PARAMETER_PROVENANCE_REQUIRED")
        for name, refs in b["parameter_sources"].items():
            require(refs, "BUDGET_PARAMETER_SOURCE_EMPTY: " + name)
            check_refs(refs, known, b["uid"])
        evaluate_budget(b)
    for ev in model["evidence"]:
        path = safe(evidence_root or Path(attempt), ev["path"])
        require(path.is_file() and sha(path) == ev["sha256"], "EVIDENCE_MISSING_OR_CHANGED: " + ev["uid"])
        require(ev["locator"] and ev["version"] and ev["conclusion"], "EVIDENCE_METADATA_INCOMPLETE")
    for change in model["change_log"]:
        check_refs(change["requirement_refs"], effective, "change_log")
        check_refs(change["object_refs"], known, "change_log")
        check_refs(change["evidence_refs"], sets["evidence"], "change_log")
    import evolution
    targets = set().union(*(sets[g] for g in GROUPS))
    evolution.validate_inheritance(model, attempt, known, effective, sets["evidence"], sets["verification_obligations"], targets)
    section_keys = set()
    for section in model["document_sections"]:
        check_refs(section["object_refs"], known, section["uid"])
        check_refs(section["requirement_refs"], effective, section["uid"])
        check_refs(section["evidence_refs"], sets["evidence"], section["uid"])
        key = (section["report_id"], section["order"])
        require(key not in section_keys and section["title"].strip(), "DOCUMENT_SECTION_ORDER_OR_TITLE_INVALID")
        require(section["paragraphs"] and all(p.strip() for p in section["paragraphs"]), "DOCUMENT_SECTION_CONTENT_REQUIRED")
        section_keys.add(key)
    import legacy_store
    facts["legacy_architecture"] = legacy_store.inherited(attempt)
    return summary, facts


def reviewed_analysis(budget, model):
    if budget["kind"] != "analysis" or not budget["analysis"].strip() or not budget["evidence_refs"]:
        return False
    return any(c["object_ref"] == budget["uid"] and c["phase"] <= model["phase"] and c["result"] == "pass" and
               c["reviewer"] != model["author"] and set(c["evidence_refs"]).intersection(budget["evidence_refs"])
               for c in model["checks"])


def reachable_peers(seeds, neighbors, peers):
    """Follow only board endpoints belonging to the same ICD interface."""
    reached = seeds & peers
    pending = list(reached)
    while pending:
        new = (neighbors.get(pending.pop(), set()) & peers) - reached
        reached.update(new)
        pending.extend(new)
    return reached


def interface_flow_gaps(model, source_analysis=None):
    """Check interface topology and FPGA-side direction when ICD facts are available."""
    view = next(v for v in model["views"] if v["kind"] == "data")
    incoming, outgoing = {}, {}
    for edge in view.get("edges", []):
        incoming.setdefault(edge["to"], set()).add(edge["from"])
        outgoing.setdefault(edge["from"], set()).add(edge["to"])
    modules = {module["uid"] for module in model.get("modules", [])}
    analysis = source_analysis or {}
    fpga_contexts = {obj["header"]["uid"] for obj in analysis.get("context_entities", [])
                     if obj["kind"] == "fpga"}
    source_peers = {}
    for item in analysis.get("interfaces", []):
        endpoints = {ref["uid"] for ref in item["endpoint_refs"]}
        if len(endpoints & fpga_contexts) == 1:
            source_peers[item["header"]["uid"]] = endpoints - fpga_contexts
    source_directions = {}
    for signal in analysis.get("signals", []):
        directions = source_directions.setdefault(signal["interface_uid"], set())
        direction = signal["direction"]
        directions.update(("input", "output") if direction in ("bidirectional", "inout") else (direction,))
    gaps = []
    for interface in model["interfaces"]:
        uid = interface["uid"]
        sources = incoming.get(uid, set())
        sinks = outgoing.get(uid, set())
        if not sources or not sinks or sources | sinks != set(interface["endpoint_refs"]):
            gaps.append(uid)
            continue
        if interface.get("scope") != "external":
            continue
        directions = set().union(*(source_directions.get(ref, set()) for ref in interface["upstream_refs"]))
        observed = set()
        if sources - modules and sinks & modules:
            observed.add("input")
        if sources & modules and sinks - modules:
            observed.add("output")
        expected = directions & {"input", "output"}
        if expected and observed != expected:
            gaps.append(uid)
            continue
        for ref in interface["upstream_refs"]:
            peers = source_peers.get(ref, set())
            required = source_directions.get(ref, set()) & {"input", "output"}
            reached = set()
            if "input" in required:
                reached |= reachable_peers(sources, incoming, peers)
            if "output" in required:
                reached |= reachable_peers(sinks, outgoing, peers)
            if required and peers - reached:
                gaps.append(uid)
                break
    return gaps


def readiness(model, summary, facts):
    reasons = []
    if summary["readiness"] != "ready" or summary["diagnostic"]:
        reasons.append("upstream not ready or diagnostic mode")
    if summary["synthetic"]:
        reasons.append("synthetic upstream")
    if not model["modules"] or not model["verification_obligations"] or not model["budgets"]:
        reasons.append("missing modules, verification obligations or budgets")
    if not model["author"]:
        reasons.append("author missing")
    if {s["report_id"] for s in model.get("document_sections", [])} != {"RPT-" + str(i).zfill(2) for i in REPORTS}:
        reasons.append("structured document sections incomplete")
    target = model["target"]
    toolchain_version = target.get("toolchain_version", target.get("vivado_version"))
    if not toolchain_version or any(not target.get(key) for key in ("environment", "part", "board", "ip_baseline")):
        reasons.append("target baseline incomplete")
    if any(not all(value.strip() for value in m["contracts"].values()) or not m["clock_refs"] or not m["reset_refs"] for m in model["modules"]):
        reasons.append("module contracts or clock/reset allocation incomplete")
    if any(not i["contract"].strip() or not i["clock_refs"] or not i["reset_refs"] for i in model["interfaces"]):
        reasons.append("interface contract or domains incomplete")
    if not model["clocks"] or not model["resets"] or any(c["frequency"]["value"] is None for c in model["clocks"]):
        reasons.append("clock/reset architecture incomplete")
    if any(not c["contract"].strip() for c in model["clocks"] + model["resets"]):
        reasons.append("clock/reset contract missing")
    for kind, objects in (("functional", model["modules"]), ("data", model["modules"] + model["interfaces"]),
                          ("clock_reset", model["clocks"] + model["resets"] + model["cdcs"]), ("physical", model["modules"])):
        view = next(v for v in model["views"] if v["kind"] == kind)
        if not {x["uid"] for x in objects} <= set(view["node_refs"]):
            reasons.append("incomplete view object coverage: " + kind)
    for uid in interface_flow_gaps(model, facts["model"]["analysis"]):
        reasons.append("interface data flow does not match producer/consumer endpoints: " + uid)
    if any(not all(v[key].strip() for key in ("criterion", "method", "preconditions")) or not v["object_refs"] for v in model["verification_obligations"]):
        reasons.append("verification contract incomplete")
    if any(not a["object_refs"] or not a["verification_refs"] for a in model["allocations"]):
        reasons.append("unallocated effective requirement")
    external = {x["header"]["uid"] for x in facts["model"]["analysis"]["interfaces"] if x["scope"] == "external"}
    mapped = {u for i in model["interfaces"] if i["scope"] == "external" for u in i["upstream_refs"]}
    if not external <= mapped:
        reasons.append("unallocated upstream external interface")
    if any(i["status"] == "open" and i["severity"] in ("B0", "B1", "B2") for i in model["issues"]):
        reasons.append("open B0/B1/B2 issue")
    if any(d["hard_requirement_conflict"] for d in model["deviations"]):
        reasons.append("deviation cannot override electrical limits or effective hard requirements")
    if any(o["action"] in ("reuse", "modify") and o["confidence"] != "confirmed" for o in model.get("legacy_objects", [])):
        reasons.append("retained inherited behavior not established")
    if any(not o["regression_refs"] for o in model.get("legacy_objects", [])) or any(not c["verification_refs"] for c in model.get("changes", [])):
        reasons.append("incremental impact regression obligations incomplete")
    if any(evaluate_budget(b)["status"] in ("fail", "unbounded", "unknown") and not reviewed_analysis(b, model) for b in model["budgets"]):
        reasons.append("budget failed or not mechanically resolved; requires reviewed evidence")
    for c in model["checks"]:
        if c["phase"] <= model["phase"] and not c["rule_id"].startswith("S-") and c["result"] not in ("pass", "not_applicable", "deviation"):
            reasons.append("due mandatory checks incomplete")
            break
    if any(c["applicability"] == "pending" for c in model["checks"]):
        reasons.append("rule applicability pending")
    return {"status": "blocked" if reasons else "ready_for_review", "reasons": reasons}


def statistics(model):
    due = Counter(c["result"] for c in model["checks"] if c["phase"] <= model["phase"] and c["applicability"] == "applicable" and c["result"] not in ("not_applicable", "planned"))
    count = sum(due.values())
    return {"due_instances": count, "results": dict(due), "pass_ratio": due["pass"] / count if count else None,
            "not_applicable": sum(c["result"] == "not_applicable" for c in model["checks"]),
            "planned": sum(c["result"] == "planned" for c in model["checks"]),
            "pending_applicability": sum(c["applicability"] == "pending" for c in model["checks"]),
            "rule_ids_recorded": len({c["rule_id"] for c in model["checks"]})}


def diagram(view, names):
    mapping = {uid: "n" + str(i) for i, uid in enumerate(view["node_refs"])}
    def label(value):
        # Entities are data, never Mermaid syntax/HTML or directives.
        return "".join(ch if ch.isalnum() or ch in " _-.:/" else " " for ch in value).strip()
    lines = ["flowchart LR"]
    for uid, node in mapping.items():
        lines.append('  ' + node + '["' + label(names.get(uid, uid)) + '"]')
    for e in view["edges"]:
        lines.append('  ' + mapping[e["from"]] + ' -->|"' + label(e["label"]) + '"| ' + mapping[e["to"]])
    return "\n".join(lines) + "\n"


def derived_files(model, summary, facts):
    import evolution
    import review_page
    files = {}
    ready = readiness(model, summary, facts)
    stats = statistics(model)
    results = [evaluate_budget(b) for b in model["budgets"]]
    for b, result in zip(model["budgets"], results):
        result["reviewed_analysis"] = reviewed_analysis(b, model)
    files["budget_results.json"] = data_bytes(results)
    files["readiness.json"] = data_bytes(ready)
    files["rule_statistics.json"] = data_bytes(stats)
    document = evolution.document_input(model, facts.get("legacy_architecture"))
    document_schema = load(SKILL / "references/documentation.schema.json")
    contract.audit_schema(document_schema)
    require(not contract.validate_schema(document, document_schema), "DOCUMENT_INPUT_SCHEMA_INVALID")
    files["documentation_input.json"] = data_bytes(document)
    if facts.get("legacy_architecture") is not None:
        files["as_is_architecture.json"] = data_bytes(facts["legacy_architecture"])
    files["inheritance_delta.json"] = data_bytes({"design_context": model["design_context"], "legacy_objects": model["legacy_objects"], "changes": model["changes"]})
    files["interface_contracts.json"] = data_bytes({"contract": "FPGA-ARCH-INTERFACE/1.0.0", "binding_sha256": model["binding_sha256"], "interfaces": model["interfaces"], "clocks": model["clocks"], "resets": model["resets"], "cdcs": model["cdcs"]})
    common = {"contract": "FPGA-ARCH-HANDOFF/1.0.0", "binding_sha256": model["binding_sha256"], "synthetic": summary["synthetic"],
              "readiness": ready, "effective_requirements": summary["effective_requirements"], "issues": model["issues"], "deviations": model["deviations"], "result_status": "not_run"}
    common.update(design_context=model["design_context"], legacy_objects=model["legacy_objects"], changes=model["changes"])
    files["detailed_design_input.json"] = data_bytes(dict(common, **{k: model[k] for k in GROUPS if k != "verification_obligations"}, target=model["target"]))
    files["verification_input.json"] = data_bytes(dict(common, verification_obligations=model["verification_obligations"], allocations=model["allocations"], checks=model["checks"]))
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, lineterminator="\r\n")
    writer.writerow(["requirement_uid", "revision_uid", "decision_refs", "object_refs", "verification_refs", "planning_status", "execution_status"])
    for a in model["allocations"]:
        row = [a["requirement_uid"], a["revision_uid"], "|".join(a["decision_refs"]), "|".join(a["object_refs"]), "|".join(a["verification_refs"]), "ALLOCATED" if a["object_refs"] and a["verification_refs"] else "UNALLOCATED", "NOT_RUN"]
        writer.writerow(["'" + x if x.startswith(("=", "+", "-", "@", "\t", "\r")) else x for x in row])
    files["RTM.csv"] = b"\xef\xbb\xbf" + stream.getvalue().encode("utf-8")
    names = {item["header"]["uid"]: item["header"]["name"]
             for item in facts["model"]["analysis"]["context_entities"]}
    names.update({x["uid"]: x["name"] for g in GROUPS for x in model[g]})
    for v in model["views"]:
        files["diagrams/" + v["kind"] + ".mmd"] = diagram(v, names).encode("utf-8")
    functions = []
    if "function_views" in model:
        from function_views import collect, artifacts
        functions = collect(model, summary, facts)
        files.update(artifacts(functions, names, data_bytes))
    report_names = {1: "架构设计", 2: "定量预算与算法精度", 3: "接口与时钟复位设计", 4: "验证计划与覆盖", 6: "架构评审与问题闭环", 7: "规则符合性"}
    safe_project = re.sub(r"[^\w-]", "_", model["project"])[:40] or "project"
    safe_version = re.sub(r"[^\w.-]", "_", model["version"])[:20]
    reports = {}
    for number in REPORTS:
        rid = "RPT-" + str(number).zfill(2)
        body = model["narratives"][rid] or "尚未填写工程分析；本报告为未完成草稿。"
        structured = sorted((s for s in model["document_sections"] if s["report_id"] == rid), key=lambda s: s["order"])
        if structured:
            body = "\n\n".join("## " + s["title"] + "\n\n" + "\n\n".join(s["paragraphs"]) for s in structured)
        header = "# " + report_names[number] + "报告\n\n" + json.dumps({"project": model["project"], "report_id": rid, "version": model["version"], "status": "DRAFT", "date": summary["report_date"], "author": model["author"], "reviewer": None, "phase": model["phase"], "rules": "FPGA-ARCH-RULES-1.0", "baseline": summary["baseline_uid"], "configuration": model["configuration"]}, ensure_ascii=False, indent=2)
        text = header + "\n\n当前结论：未评审。工程判定和签署不得由结构检查代替。\n\n" + body + "\n\n"
        section = {1: {k: model[k] for k in ("scope", "modules", "decisions", "issues", "allocations")},
                   2: {"budgets": model["budgets"], "results": results},
                   3: {k: model[k] for k in ("interfaces", "clocks", "resets", "cdcs")},
                   4: {"verification_obligations": model["verification_obligations"], "execution": "not_run"},
                   6: {"readiness": ready, "issues": model["issues"], "review": "未评审"},
                   7: {"statistics": stats, "checks": model["checks"]}}[number]
        text += "## 受控模型明细\n\n```json\n" + data_bytes(section).decode("utf-8") + "```\n\n## 证据与修订\n\n```json\n" + data_bytes({"evidence": model["evidence"], "change_log": model["change_log"]}).decode("utf-8") + "```\n"
        if number == 1:
            for view in model["views"]:
                text += "\n## " + view["kind"] + "\n\n```mermaid\n" + diagram(view, names) + "```\n\n" + view["notes"] + "\n"
        filename = safe_project + "_" + rid + "_" + report_names[number] + "_v" + safe_version + "_" + summary["report_date"].replace("-", "") + ".md"
        reports[rid[-2:]] = "reports/" + filename
        files["reports/" + filename] = text.encode("utf-8")
    files["review.html"] = review_page.render(model, summary, ready, results, names, reports,
                                            functions=functions).encode("utf-8")
    files["reports/index.md"] = ("# 架构交付索引\n\n[打开架构评审首页](../review.html)\n\n状态DRAFT；阶段" + model["phase"] + "；结论未评审。\n\n" + "\n".join("- [" + Path(p).name + "](" + Path(p).name + ")" for p in reports.values()) + "\n\nRPT-05和RPT-08留待实际实现/板测/构建发布阶段。\n").encode("utf-8")
    files["evidence/index.json"] = data_bytes(model["evidence"])
    return files


def manifest(root, status, summary, model):
    return {"contract": "FPGA-ARCH-PACKAGE/1.0.0", "status": status, "created_at": now(), "synthetic": summary["synthetic"],
            "binding_sha256": model["binding_sha256"], "artifacts": {p.relative_to(root).as_posix(): sha(p) for p in all_files(root) if p != root / "package.json"}}


def build(attempt, model_path, output, proposal=None, approval_path=None):
    import evolution
    require(proposal is not None and approval_path is not None, "GENERATION_APPROVAL_REQUIRED: propose and obtain user approval before build")
    attempt, model_path = Path(attempt).resolve(), Path(model_path).resolve()
    model = load(model_path)
    require("function_views" in model, "FUNCTION_VIEWS_REQUIRED: use the current architecture template")
    approval = load(Path(approval_path))
    evolution.validate_approval(proposal, approval, attempt, model)
    summary, facts = validate_model(model, attempt, model_path.parent)
    summary = dict(summary, report_date=now()[:10])
    with transaction(output, (attempt, SKILL, model_path, Path(proposal), Path(approval_path))) as dest:
        shutil.copytree(str(attempt), str(dest / "inputs"))
        (dest / "generation/proposal").mkdir(parents=True)
        for name in ("proposal.json", "generation_plan.json", "approval_request.md"):
            shutil.copyfile(str(Path(proposal) / name), str(dest / "generation/proposal" / name))
        save(dest / "generation/approval.json", approval)
        save(dest / "architecture.json", model)
        save(dest / "report_context.json", summary)
        for ev in model["evidence"]:
            source = safe(model_path.parent, ev["path"])
            target = safe(dest / "support", ev["path"])
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(source), str(target))
        for relative, content in derived_files(model, summary, facts).items():
            target = safe(dest, relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        save(dest / "schemas/architecture.schema.json", load(SKILL / "references/architecture.schema.json"))
        save(dest / "schemas/documentation.schema.json", load(SKILL / "references/documentation.schema.json"))
        save(dest / "package.json", manifest(dest, "DRAFT", summary, model))
        validate_package(dest)
    return {"package": str(Path(output).resolve()), "status": "DRAFT", "readiness": readiness(model, summary, facts)}


def validate_package(root):
    import evolution
    root = Path(root).resolve()
    package = load(root / "package.json")
    require(package["contract"] == "FPGA-ARCH-PACKAGE/1.0.0" and package["status"] in ("DRAFT", "FROZEN"), "ARCH_PACKAGE_STATUS_INVALID")
    actual = {p.relative_to(root).as_posix(): sha(p) for p in all_files(root) if p != root / "package.json"}
    require(actual == package["artifacts"], "ARCH_PACKAGE_DIGEST_OR_FILE_SET_MISMATCH")
    model = load(root / "architecture.json")
    reviewed = load(root / "reviewed_package.json") if package["status"] == "FROZEN" else package
    has_review_page = "review.html" in reviewed["artifacts"]
    has_function_views = "function_views" in model
    # Pre-review-page packages retain their original schema and rendered files.
    # Live attempts still require the current tool before generating a new package.
    summary, facts = validate_model(model, root / "inputs", root / "support", check_tool=has_function_views)
    evolution.validate_approval(root / "generation/proposal", load(root / "generation/approval.json"), root / "inputs", model, check_tool=False)
    context = load(root / "report_context.json")
    require({k: v for k, v in context.items() if k != "report_date"} == summary and re.match(r"^\d{4}-\d{2}-\d{2}$", context["report_date"]), "REPORT_CONTEXT_CHANGED")
    require(package["synthetic"] == summary["synthetic"] and package["binding_sha256"] == model["binding_sha256"], "PACKAGE_MODEL_BINDING_MISMATCH")
    schema = load(SKILL / "references/architecture.schema.json")
    document_schema = load(SKILL / "references/documentation.schema.json")
    if not has_function_views:
        del schema["properties"]["function_views"]
        del document_schema["$defs"]["architecture"]["properties"]["function_views"]
    if not has_review_page:
        for key in ("review_paths", "review_timelines"):
            del schema["properties"][key]
            del document_schema["$defs"]["architecture"]["properties"][key]
        require("review_paths" not in model and "review_timelines" not in model, "REVIEW_PAGE_REQUIRED")
    require(load(root / "schemas/architecture.schema.json") == schema, "SCHEMA_CHANGED")
    require(load(root / "schemas/documentation.schema.json") == document_schema, "DOCUMENT_SCHEMA_CHANGED")
    for path, expected in derived_files(model, context, facts).items():
        if not has_review_page:
            if path == "review.html":
                continue
            if path == "reports/index.md":
                expected = expected.replace("[打开架构评审首页](../review.html)\n\n".encode("utf-8"), b"", 1)
        original = "reviewed_review.html" if path == "review.html" and package["status"] == "FROZEN" else path
        require(safe(root, original).read_bytes() == expected, "DERIVED_ARTIFACT_CHANGED: " + original)
    if package["status"] == "FROZEN":
        validate_review(load(root / "review.json"), model, summary, facts, package["draft_manifest_sha256"])
        require(sha(root / "reviewed_package.json") == package["draft_manifest_sha256"], "FROZEN_REVIEWED_MANIFEST_CHANGED")
        require(reviewed["status"] == "DRAFT", "REVIEWED_MANIFEST_NOT_DRAFT")
        if has_review_page:
            require((root / "review.html").read_bytes() == frozen_review_page(root, review), "DERIVED_ARTIFACT_CHANGED: review.html")
        for p, digest in reviewed["artifacts"].items():
            path = safe(root, "reviewed_review.html" if p == "review.html" else p)
            require(sha(path) == digest, "REVIEWED_ARTIFACT_CHANGED")
    return {"valid": True, "status": package["status"], "synthetic": package["synthetic"], "readiness": readiness(model, summary, facts)}


def validate_review(review, model, summary, facts, package_digest):
    require(readiness(model, summary, facts)["status"] == "ready_for_review", "ARCHITECTURE_NOT_READY_FOR_FREEZE")
    require(model["phase"] == "G1", "FREEZE_REQUIRES_G1_REVIEW")
    require(review.get("kind") == "approve_architecture_freeze" and review.get("package_sha256") == package_digest and
            review.get("conclusion") == "通过" and review.get("actor") and review.get("user_quote") and review.get("confirmed_at") and review.get("allowed_scope"), "CURRENT_PACKAGE_FREEZE_AUTHORIZATION_REQUIRED")
    records = review.get("participants", [])
    require({p["role"] for p in records} >= {"architecture", "design", "verification"} and
            all(p.get("name") and p.get("reviewed_at") for p in records), "REVIEW_ROLES_REQUIRED")
    require(review.get("reviewer") and review["reviewer"] != model["author"], "INDEPENDENT_REVIEW_REQUIRED")
    evs = {e["uid"] for e in model["evidence"] if e["level"] == "review"}
    require(review.get("evidence_refs") and set(review["evidence_refs"]) <= evs, "REVIEW_EVIDENCE_REQUIRED")


def freeze(package_root, review_path, output):
    root = Path(package_root).resolve()
    validate_package(root)
    package = load(root / "package.json")
    require(package["status"] == "DRAFT", "FREEZE_REQUIRES_DRAFT")
    model = load(root / "architecture.json")
    summary, facts = validate_model(model, root / "inputs", root / "support",
                                    check_tool="function_views" in model)
    review = load(Path(review_path))
    digest = sha(root / "package.json")
    validate_review(review, model, summary, facts, digest)
    with transaction(output, (root, SKILL, Path(review_path))) as dest:
        for p in all_files(root):
            target = dest / p.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(p), str(target))
        shutil.copyfile(str(root / "package.json"), str(dest / "reviewed_package.json"))
        if (dest / "review.html").is_file():
            (dest / "review.html").rename(dest / "reviewed_review.html")
            (dest / "review.html").write_bytes(frozen_review_page(dest, review))
        save(dest / "review.json", review)
        frozen = manifest(dest, "FROZEN", summary, model)
        frozen["draft_manifest_sha256"] = digest
        save(dest / "package.json", frozen)
        validate_package(dest)
    return {"package": str(Path(output).resolve()), "status": "FROZEN", "scope": review["allowed_scope"]}


def frozen_review_page(root, review):
    from review_page import DRAFT_STATUS, frozen_status
    page = (root / "reviewed_review.html").read_text(encoding="utf-8")
    return page.replace(DRAFT_STATUS, frozen_status(review), 1).encode("utf-8")


def run(argv=None):
    parser = argparse.ArgumentParser(description="Offline FPGA architecture package tools")
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("doctor")
    sub.add_parser("self-test")
    p = sub.add_parser("legacy-prepare")
    p.add_argument("--legacy", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("legacy-build")
    p.add_argument("--workspace", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--parent")
    p = sub.add_parser("legacy-query")
    p.add_argument("--baseline", required=True)
    p.add_argument("--uid")
    p.add_argument("--kind")
    p.add_argument("--offset", type=int, default=0)
    p.add_argument("--limit", type=int, default=20)
    p.add_argument("--detail", action="store_true")
    p = sub.add_parser("legacy-read")
    p.add_argument("--workspace", required=True)
    p.add_argument("--file-uid", required=True)
    p.add_argument("--start-line", type=int, default=1)
    p.add_argument("--line-count", type=int, default=100)
    p = sub.add_parser("legacy-validate")
    p.add_argument("--baseline", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--baseline", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--diagnostic", action="store_true")
    p.add_argument("--legacy")
    p.add_argument("--legacy-baseline")
    p = sub.add_parser("propose")
    p.add_argument("--attempt", required=True)
    p.add_argument("--plan", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("check-approval")
    p.add_argument("--attempt", required=True)
    p.add_argument("--proposal", required=True)
    p.add_argument("--approval", required=True)
    p = sub.add_parser("build")
    p.add_argument("--attempt", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--proposal", required=True)
    p.add_argument("--approval", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("validate")
    p.add_argument("--package", required=True)
    p = sub.add_parser("freeze")
    p.add_argument("--package", required=True)
    p.add_argument("--review", required=True)
    p.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    if args.action == "doctor":
        return {"python": platform.python_version(), "os": platform.platform(), "powershell_requirement": "2.0", "win7_hardware_verified": False, "tool_fingerprint": tool_fingerprint()}
    if args.action == "self-test":
        from selftest import run_tests
        return run_tests()
    if args.action.startswith("legacy-"):
        import legacy_store
        if args.action == "legacy-prepare":
            return legacy_store.prepare(args.legacy, args.output)
        if args.action == "legacy-build":
            return legacy_store.build(args.workspace, args.model, args.output, args.parent)
        if args.action == "legacy-query":
            return legacy_store.query(args.baseline, args.uid, args.kind, args.offset, args.limit, args.detail)
        if args.action == "legacy-read":
            return legacy_store.read_source(args.workspace, args.file_uid, args.start_line, args.line_count)
        model = legacy_store.validate(args.baseline)
        return {"valid": True, "status": model["status"], "objects": len(model["objects"])}
    if args.action == "prepare":
        return prepare(args.baseline, args.output, args.diagnostic, args.legacy, args.legacy_baseline)
    if args.action == "propose":
        import evolution
        return evolution.propose(args.attempt, args.plan, args.output)
    if args.action == "check-approval":
        import evolution
        evolution.validate_approval(args.proposal, load(Path(args.approval)), args.attempt)
        return {"status": "GENERATION_AUTHORIZED", "proposal_sha256": sha(Path(args.proposal) / "proposal.json")}
    if args.action == "build":
        return build(args.attempt, args.model, args.output, args.proposal, args.approval)
    if args.action == "validate":
        return validate_package(args.package)
    return freeze(args.package, args.review, args.output)
