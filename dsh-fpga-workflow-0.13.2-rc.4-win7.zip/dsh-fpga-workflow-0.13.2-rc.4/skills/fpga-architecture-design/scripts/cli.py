"""Production entry point: exactly Python 3.8.10, no override switch."""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))


def main():
    try:
        if sys.version_info[:3] != (3, 8, 10):
            raise ValueError("PYTHON_RUNTIME_MISMATCH: requires exactly Python 3.8.10; got " + sys.version.split()[0])
        from archlib import run
        result = run()
        print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        print("FPGA_ARCH_OK:" + sys.argv[1])
        return 0
    except Exception as exc:
        print("FPGA_ARCH_ERROR: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
