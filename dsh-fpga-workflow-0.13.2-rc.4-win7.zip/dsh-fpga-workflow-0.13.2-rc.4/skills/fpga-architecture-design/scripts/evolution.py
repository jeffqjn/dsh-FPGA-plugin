"""Read-only legacy snapshots and user-approved generation plans; Python 3.8."""
import re
import shutil
from datetime import datetime
from pathlib import Path

import archlib as a

OUTPUTS = ["architecture.json", "documentation_input.json", "interface_contracts.json", "diagrams", "traceability", "reports", "review"]
ACTIONS = {"reuse", "modify", "replace", "remove"}


def snapshot_legacy(manifest_path, dest):
    if manifest_path is None:
        value = {"mode": "new", "baseline_name": None, "manifest_sha256": None, "files": []}
    else:
        path = Path(manifest_path).resolve()
        manifest = a.load(path)
        a.require(manifest.get("baseline_name") and manifest.get("files"), "LEGACY_MANIFEST_INCOMPLETE")
        seen = set()
        files = []
        for entry in manifest["files"]:
            relative = entry["path"]
            a.require(relative not in seen and entry.get("role"), "LEGACY_FILE_DUPLICATE_OR_ROLE_MISSING")
            seen.add(relative)
            source = a.safe(path.parent, relative)
            a.require(source.is_file(), "LEGACY_FILE_MISSING: " + relative)
            target = a.safe(dest / "legacy/files", relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(source), str(target))
            encoding = entry.get("encoding", "utf-8")
            a.require(encoding in ("utf-8", "utf-8-sig", "gb18030", "ascii", "binary"), "UNSUPPORTED_LEGACY_ENCODING")
            read_status, lines = "opaque", None
            if encoding != "binary":
                try:
                    content = target.read_bytes().decode(encoding)
                    read_status = "readable" if "\x00" not in content else "opaque"
                    lines = len(content.splitlines()) if read_status == "readable" else None
                except UnicodeDecodeError:
                    read_status = "unreadable"
            files.append({"uid": "LEG-F-" + a.fingerprint(relative)[:16], "path": relative, "role": entry["role"],
                          "encoding": encoding, "sha256": a.sha(target), "size_bytes": target.stat().st_size,
                          "read_status": read_status, "line_count": lines})
        (dest / "legacy").mkdir(exist_ok=True)
        shutil.copyfile(str(path), str(dest / "legacy/manifest.json"))
        value = {"mode": "incremental", "baseline_name": manifest["baseline_name"], "manifest_sha256": a.sha(path), "files": files}
    a.save(dest / "legacy_inventory.json", value)
    return value


def inventory(attempt):
    root = Path(attempt)
    result = a.load(root / "legacy_inventory.json")
    if result["mode"] == "new":
        a.require(result == {"mode": "new", "baseline_name": None, "manifest_sha256": None, "files": []}, "INVALID_NEW_DESIGN_INVENTORY")
        return result
    a.require(result["mode"] == "incremental" and result["files"] and a.sha(root / "legacy/manifest.json") == result["manifest_sha256"], "LEGACY_BASELINE_CHANGED")
    manifest = a.load(root / "legacy/manifest.json")
    a.require(result["baseline_name"] == manifest["baseline_name"] and [e["path"] for e in manifest["files"]] == [e["path"] for e in result["files"]], "LEGACY_INVENTORY_CHANGED")
    for item, entry in zip(result["files"], manifest["files"]):
        path = a.safe(root / "legacy/files", item["path"])
        a.require(a.sha(path) == item["sha256"] and path.stat().st_size == item["size_bytes"] and item["role"] == entry["role"] and
                  item["uid"] == "LEG-F-" + a.fingerprint(item["path"])[:16] and item["encoding"] == entry.get("encoding", "utf-8"), "LEGACY_FILE_CHANGED")
    return result


def context(attempt):
    inv = inventory(attempt)
    return {"mode": inv["mode"], "legacy_manifest_sha256": inv["manifest_sha256"],
            "estimated_change_percent": None, "estimate_basis": "尚未估算；不是自动重写门限。"}


def plan_template(attempt, info):
    import legacy_store
    ctx = context(attempt)
    result = {"contract": "FPGA-ARCH-GENERATION-PLAN/1.1.0", "attempt_uid": info["attempt_uid"], "binding_sha256": info["binding_sha256"],
            "legacy_architecture_sha256": a.sha(Path(attempt) / "inherited_architecture/legacy_architecture.json") if legacy_store.inherited(attempt) is not None else None,
            "design_context": ctx, "goal": "", "scope": "", "preservation_constraints": [],
            "legacy_scope": legacy_store.seed_scope(attempt), "change_scope": [], "outputs": OUTPUTS,
            "limitations": [], "file_dispositions": [{"file_uid": f["uid"], "disposition": "pending", "rationale": ""} for f in inventory(attempt)["files"]]}
    asis = legacy_store.inherited(attempt)
    if asis is not None:
        statuses = {f["file_uid"]: f for f in asis["file_dispositions"]}
        for row in result["file_dispositions"]:
            row.update(disposition={"read": "analyzed", "indexed": "deferred", "deferred": "deferred", "excluded": "excluded", "unreadable": "unreadable"}[statuses[row["file_uid"]]["status"]],
                       rationale=statuses[row["file_uid"]]["reason"])
    return result


def validate_plan(plan, attempt, *, check_tool=True):
    import legacy_store
    info, summary, _ = a.verify_attempt(attempt, check_tool=check_tool)
    a.require(summary["readiness"] != "blocked" and not summary["diagnostic"],
              "DIAGNOSTIC_ATTEMPT_CANNOT_GENERATE: resolve upstream blockers and prepare a new attempt")
    inv = inventory(attempt)
    schema = a.load(a.SKILL / "references/generation-plan.schema.json")
    a.contract.audit_schema(schema)
    a.require(not a.contract.validate_schema(plan, schema), "GENERATION_PLAN_SCHEMA_INVALID")
    legacy_store.validate_plan_basis(plan, attempt)
    a.require(plan["attempt_uid"] == info["attempt_uid"] and plan["binding_sha256"] == info["binding_sha256"], "PLAN_ATTEMPT_MISMATCH")
    ctx = plan["design_context"]
    a.require(ctx["mode"] == inv["mode"] and ctx["legacy_manifest_sha256"] == inv["manifest_sha256"], "PLAN_LEGACY_BINDING_MISMATCH")
    a.require(plan["goal"].strip() and plan["scope"].strip() and ctx["estimate_basis"].strip(), "PLAN_SCOPE_REQUIRED")
    a.require(plan["outputs"] == OUTPUTS, "PLAN_OUTPUT_SCOPE_CHANGED")
    file_ids = {f["uid"] for f in inv["files"]}
    dispositions = plan["file_dispositions"]
    a.require(len(dispositions) == len(file_ids) and {x["file_uid"] for x in dispositions} == file_ids and
              all(x["disposition"] != "pending" and x["rationale"].strip() for x in dispositions), "LEGACY_FILES_NOT_DISPOSITIONED")
    file_map = {f["uid"]: f for f in inv["files"]}
    for disposition in dispositions:
        if disposition["disposition"] == "analyzed":
            a.require(file_map[disposition["file_uid"]]["read_status"] == "readable", "UNREADABLE_FILE_CANNOT_BE_MARKED_ANALYZED")
    objects = {x["uid"]: x for x in plan["legacy_scope"]}
    a.require(len(objects) == len(plan["legacy_scope"]), "DUPLICATE_LEGACY_OBJECT")
    for item in objects.values():
        a.require(item["file_refs"] and set(item["file_refs"]) <= file_ids and item["locator"] and item["rationale"] and item["current_behavior"].strip(), "LEGACY_OBJECT_EVIDENCE_REQUIRED")
    if inv["mode"] == "new":
        a.require(not objects and not dispositions, "NEW_MODE_WITH_LEGACY_OBJECTS")
    else:
        a.require(objects, "LEGACY_ARCHITECTURE_INVENTORY_REQUIRED")
        object_files = {r for obj in objects.values() for r in obj["file_refs"]}
        a.require(all(x["file_uid"] in object_files for x in dispositions if x["disposition"] == "analyzed"), "ANALYZED_LEGACY_FILE_HAS_NO_OBJECT")
    changes = {x["uid"]: x for x in plan["change_scope"]}
    a.require(changes and len(changes) == len(plan["change_scope"]), "CHANGE_SCOPE_REQUIRED")
    for change in changes.values():
        a.require(set(change["legacy_refs"]) <= set(objects) and change["description"].strip(), "INVALID_PLANNED_CHANGE")
        a.require((change["action"] == "add" and not change["legacy_refs"]) or
                  (change["action"] != "add" and change["legacy_refs"] and all(objects[r]["action"] == change["action"] for r in change["legacy_refs"])), "CHANGE_DISPOSITION_MISMATCH")
    for uid, item in objects.items():
        if item["action"] != "reuse":
            a.require(any(uid in c["legacy_refs"] for c in changes.values()), "LEGACY_CHANGE_OMITTED_FROM_PLAN")
    return plan


def propose(attempt, plan_path, output):
    attempt = Path(attempt).resolve()
    plan = validate_plan(a.load(Path(plan_path)), attempt)
    with a.transaction(output, (attempt, a.SKILL, Path(plan_path))) as dest:
        a.save(dest / "generation_plan.json", plan)
        request = "# 架构生成批准请求\n\n状态：AWAITING_USER_APPROVAL。当前仅为范围分析和调整方案，不含已生成的目标架构。\n\n```json\n" + a.data_bytes(plan).decode("utf-8") + "```\n\n请针对本目录proposal.json的SHA256明确批准本次范围后再执行详细架构设计与输出。输入、复用处置、范围改变后需重新提交。\n"
        (dest / "approval_request.md").write_bytes(request.encode("utf-8"))
        a.save(dest / "proposal.json", {"contract": "FPGA-ARCH-PROPOSAL/1.0.0", "status": "AWAITING_USER_APPROVAL", "created_at": a.now(),
                                       "attempt_uid": plan["attempt_uid"], "binding_sha256": plan["binding_sha256"],
                                       "artifacts": {name: a.sha(dest / name) for name in ("generation_plan.json", "approval_request.md")}})
    return {"proposal": str(Path(output).resolve()), "status": "AWAITING_USER_APPROVAL", "proposal_sha256": a.sha(Path(output) / "proposal.json")}


def verify_proposal(proposal, attempt, *, check_tool=True):
    root = Path(proposal)
    record = a.load(root / "proposal.json")
    a.require(record["contract"] == "FPGA-ARCH-PROPOSAL/1.0.0" and record["status"] == "AWAITING_USER_APPROVAL", "INVALID_GENERATION_PROPOSAL")
    a.require(set(record["artifacts"]) == {"generation_plan.json", "approval_request.md"}, "PROPOSAL_ARTIFACT_SET_CHANGED")
    for name, digest in record["artifacts"].items():
        a.require(a.sha(a.safe(root, name)) == digest, "PROPOSAL_CHANGED_AFTER_APPROVAL")
    plan = validate_plan(a.load(root / "generation_plan.json"), attempt, check_tool=check_tool)
    a.require(record["attempt_uid"] == plan["attempt_uid"] and record["binding_sha256"] == plan["binding_sha256"], "PROPOSAL_BINDING_CHANGED")
    return plan


def validate_approval_timestamp(value):
    # Python 3.8 accepts three or six fractional digits. Normalize ISO fractions
    # before parsing timestamps produced by PowerShell and other hosts.
    value = re.sub(r"\.(\d+)(?=Z$|[+-]\d{2}:\d{2}$|$)",
                   lambda match: "." + match[1][:6].ljust(6, "0"), value)
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    try:
        stamp = datetime.fromisoformat(value)
    except ValueError:
        raise ValueError("APPROVAL_TIMESTAMP_INVALID") from None
    a.require(stamp.utcoffset() is not None, "APPROVAL_TIMEZONE_REQUIRED")
    return stamp


def validate_approval(proposal, approval, attempt, model=None, *, check_tool=True):
    plan = verify_proposal(proposal, attempt, check_tool=check_tool)
    a.require(approval.get("kind") == "approve_architecture_generation" and approval.get("proposal_sha256") == a.sha(Path(proposal) / "proposal.json") and
              all(isinstance(approval.get(k), str) and approval[k].strip() for k in ("actor", "user_quote", "confirmed_at")), "GENERATION_APPROVAL_REQUIRED")
    validate_approval_timestamp(approval["confirmed_at"])
    if model is None:
        return plan
    a.require(model["scope"] == plan["scope"] and model["preservation_constraints"] == plan["preservation_constraints"], "APPROVED_SCOPE_OR_PRESERVATION_CHANGED")
    a.require(model["design_context"] == plan["design_context"], "APPROVED_DESIGN_CONTEXT_CHANGED")
    approved = {x["uid"]: x for x in plan["legacy_scope"]}
    actual = {x["uid"]: x for x in model["legacy_objects"]}
    a.require(set(actual) == set(approved), "APPROVED_LEGACY_SCOPE_CHANGED")
    for uid, item in actual.items():
        a.require(all(item[k] == approved[uid][k] for k in ("original_uid", "name", "kind", "file_refs", "locator", "action", "current_behavior", "confidence")), "APPROVED_LEGACY_DISPOSITION_CHANGED")
    planned_changes = {x["uid"]: x for x in plan["change_scope"]}
    changes = {x["uid"]: x for x in model["changes"]}
    a.require(set(changes) == set(planned_changes), "APPROVED_CHANGE_SCOPE_CHANGED")
    for uid, item in changes.items():
        a.require(item["action"] == planned_changes[uid]["action"] and item["legacy_refs"] == planned_changes[uid]["legacy_refs"], "APPROVED_CHANGE_ACTION_CHANGED")
    return plan


def validate_inheritance(model, attempt, known, effective, evidence_ids, vo_ids, target_ids):
    inv = inventory(attempt)
    ctx = model["design_context"]
    a.require(ctx["mode"] == inv["mode"] and ctx["legacy_manifest_sha256"] == inv["manifest_sha256"], "MODEL_LEGACY_BASELINE_MISMATCH")
    files = {x["uid"] for x in inv["files"]}
    legacy = {x["uid"]: x for x in model["legacy_objects"]}
    for obj in legacy.values():
        a.require(obj["file_refs"] and set(obj["file_refs"]) <= files and obj["locator"] and obj["current_behavior"] and obj["rationale"], "LEGACY_OBJECT_UNGROUNDED")
        a.require(set(obj["target_refs"]) <= target_ids and set(obj["requirement_refs"]) <= set(effective) and set(obj["impact_refs"]) <= known and
                  set(obj["regression_refs"]) <= vo_ids and set(obj["evidence_refs"]) <= evidence_ids, "LEGACY_OBJECT_REFERENCE_INVALID")
        a.require((obj["action"] == "remove" and not obj["target_refs"]) or (obj["action"] != "remove" and obj["target_refs"]), "LEGACY_TARGET_MAPPING_REQUIRED")
        if obj["verification_status"] == "revalidated":
            a.require(obj["evidence_refs"], "LEGACY_REVALIDATION_EVIDENCE_REQUIRED")
    a.require((inv["mode"] == "new" and not legacy) or (inv["mode"] == "incremental" and legacy), "INHERITED_ARCHITECTURE_REQUIRED")
    for change in model["changes"]:
        a.require(set(change["legacy_refs"]) <= set(legacy) and set(change["target_refs"]) <= target_ids and set(change["requirement_refs"]) <= set(effective) and
                  set(change["impact_refs"]) <= known and set(change["verification_refs"]) <= vo_ids, "CHANGE_REFERENCE_INVALID")
        a.require((change["action"] == "remove" and not change["target_refs"]) or (change["action"] != "remove" and change["target_refs"]), "CHANGE_TARGET_MAPPING_REQUIRED")
        a.require(change["rationale"].strip() and change["compatibility"].strip() and change["migration"].strip() and change["rollback"].strip(), "CHANGE_MIGRATION_CONTRACT_REQUIRED")


def document_input(model, legacy_baseline=None):
    return {"contract": "FPGA-ARCH-DOCUMENT/1.1.0", "architecture_sha256": a.hashlib.sha256(a.data_bytes(model)).hexdigest(),
            "publication_state": "DRAFT", "model": model, "legacy_baseline": legacy_baseline,
            "section_order": [s["uid"] for s in sorted(model["document_sections"], key=lambda x: (x["report_id"], x["order"]))]}
