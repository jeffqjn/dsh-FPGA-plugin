"""Validate function decomposition and project its flows from the architecture."""
from collections import defaultdict
from html import escape
import re


KINDS = {"data": "数据", "control": "控制", "status": "状态", "clock_reset": "时钟／复位"}


def collect(model, summary, facts):
    functions = model["function_views"]
    by_uid = {item["uid"]: item for item in functions}
    if len(by_uid) != len(functions):
        raise ValueError("DUPLICATE_FUNCTION_VIEW")
    if any(not re.fullmatch(r"FN-[A-Z0-9]+(?:-[A-Z0-9]+)*", uid) or len(uid) > 64 for uid in by_uid):
        raise ValueError("INVALID_FUNCTION_VIEW_UID")
    effective = {row["requirement_uid"]: row["revision_uid"] for row in summary["effective_requirements"]}
    mandatory = {r["uid"] for r in facts["model"]["requirements"] if r["category"] == "function"} & effective.keys()
    covered = {ref for item in functions if item["parent_ref"] is None for ref in item["requirement_refs"]}
    if mandatory - covered:
        raise ValueError("FUNCTION_REQUIREMENTS_WITHOUT_VIEW: " + ", ".join(sorted(mandatory - covered)))

    allocations = {row["requirement_uid"]: set(row["object_refs"]) for row in model["allocations"]}
    modules = {row["uid"] for row in model["modules"]}
    interfaces = {row["uid"] for row in model["interfaces"]}
    local_ids = {obj["uid"] for obj in walk_objects(model) if "uid" in obj} | set(facts.get("registry", ()))
    unit_ids = [unit["uid"] for item in functions for unit in item["units"]]
    if len(set(unit_ids)) != len(unit_ids) or set(unit_ids) & (local_ids | by_uid.keys()) or by_uid.keys() & local_ids:
        raise ValueError("DUPLICATE_OR_COLLIDING_FUNCTION_UNIT")
    view = next(view for view in model["views"] if view["kind"] == "data")
    edges_by_port = defaultdict(list)
    for edge in view["edges"]:
        if edge["from"] in interfaces:
            edges_by_port[(edge["from"], edge["to"], "in")].append(edge)
        if edge["to"] in interfaces:
            edges_by_port[(edge["to"], edge["from"], "out")].append(edge)
    module_endpoints = defaultdict(set)
    for interface, module, _ in edges_by_port:
        if module in modules:
            module_endpoints[interface].add(module)

    result = []
    for function in functions:
        uid, refs = function["uid"], set(function["requirement_refs"])
        if refs - effective.keys() or refs - allocations.keys():
            raise ValueError("FUNCTION_REQUIREMENT_NOT_EFFECTIVE: " + uid)
        ancestors = {uid}
        parent = function["parent_ref"]
        while parent is not None:
            if parent not in by_uid or parent in ancestors:
                raise ValueError("INVALID_FUNCTION_PARENT_OR_CYCLE: " + uid)
            if not refs <= set(by_uid[parent]["requirement_refs"]):
                raise ValueError("SUBFUNCTION_REQUIREMENTS_OUTSIDE_PARENT: " + uid)
            ancestors.add(parent)
            parent = by_uid[parent]["parent_ref"]

        units = {unit["uid"]: set(unit["module_refs"]) for unit in function["units"]}
        owned = set().union(*units.values())
        allocated = set().union(*(allocations[ref] for ref in refs))
        if owned - (modules & allocated) or any(not (owned & allocations[ref]) for ref in refs):
            raise ValueError("FUNCTION_MODULE_ALLOCATION_MISMATCH: " + uid)
        graph = []
        bound = set()
        exposed = set()
        projected_ports = defaultdict(list)
        for port in function["ports"]:
            interface, module, direction = port["interface_ref"], port["module_ref"], port["direction"]
            unit = port["unit_ref"]
            key = (interface, module, direction)
            if module not in units.get(unit, ()) or key not in edges_by_port:
                raise ValueError("FUNCTION_PORT_DIRECTION_OR_OWNERSHIP_MISMATCH: " + uid + " / " + interface)
            mapping = (key, unit)
            if mapping in bound:
                raise ValueError("DUPLICATE_FUNCTION_PORT_MAPPING: " + uid)
            bound.add(mapping)
            projected_ports[key].append(port)
            exposed.add(unit)
            start, end = (interface, unit) if direction == "in" else (unit, interface)
            graph.extend({"from": start, "to": end, "label": edge["label"], "kind": port["kind"],
                          "source_edge": edge, "condition": port.get("condition")} for edge in edges_by_port[key])
        for key, mappings in projected_ports.items():
            if len(mappings) > 1 and any(not port.get("condition", "").strip() for port in mappings):
                raise ValueError("FUNCTION_PORT_FANOUT_NEEDS_CONDITION: " + uid + " / " + key[0])
        keys = {key for key, _ in bound}
        excluded = {}
        for port in function["excluded_ports"]:
            key = (port["interface_ref"], port["module_ref"], port["direction"])
            if key not in edges_by_port or key[1] not in owned or key in keys or key in excluded or not port["reason"].strip():
                raise ValueError("INVALID_FUNCTION_PORT_EXCLUSION: " + uid + " / " + key[0])
            excluded[key] = port
        parent = by_uid.get(function["parent_ref"])
        if parent is None:
            connected = {interface for interface, endpoints in module_endpoints.items() if len(endpoints & owned) > 1}
            required = {key for key in edges_by_port if key[0] in (allocated | connected) and key[1] in owned}
            boundary = {key for key in edges_by_port if key[1] in owned}
        else:
            parent_modules = {ref for unit in parent["units"] for ref in unit["module_refs"]}
            parent_keys = {(port["interface_ref"], port["module_ref"], port["direction"]) for port in parent["ports"]}
            boundary = {key for key in parent_keys if key[1] in owned}
            if owned - parent_modules or (keys | excluded.keys()) - boundary:
                raise ValueError("SUBFUNCTION_OUTSIDE_PARENT_BOUNDARY: " + uid)
            required = set()
        if required - keys:
            raise ValueError("FUNCTION_INTERFACE_NOT_MAPPED: " + uid + " / " +
                             ", ".join(":".join(key) for key in sorted(required - keys)))
        if boundary - keys - excluded.keys():
            missing = sorted(boundary - keys - excluded.keys())
            raise ValueError("FUNCTION_BOUNDARY_NOT_ACCOUNTED: " + uid + " / " + ", ".join(":".join(key) for key in missing))
        visible = owned | {key[0] for key in keys}
        supports = set(function["support_refs"])
        outstanding = (allocated & (modules | interfaces)) - visible
        if parent is None and supports != outstanding:
            raise ValueError("FUNCTION_ALLOCATED_SUPPORT_NOT_ACCOUNTED: " + uid)
        if parent is not None and supports - outstanding:
            raise ValueError("INVALID_SUBFUNCTION_SUPPORT_REF: " + uid)
        for edge in function["internal_flows"]:
            start, end, module = edge["from"], edge["to"], edge["module_ref"]
            if start == end or module not in units.get(start, ()) or module not in units.get(end, ()):
                raise ValueError("FUNCTION_INTERNAL_FLOW_REQUIRES_SHARED_MODULE: " + uid)
            graph.append(dict(edge))
        neighbors = defaultdict(set)
        for edge in function["internal_flows"]:
            neighbors[edge["from"]].add(edge["to"])
            neighbors[edge["to"]].add(edge["from"])
        if not graph:
            raise ValueError("FUNCTION_WITHOUT_FLOW: " + uid)
        if not exposed:
            exposed.add(next(iter(units)))
        pending = list(exposed)
        while pending:
            fresh = neighbors[pending.pop()] - exposed
            pending.extend(fresh)
            exposed.update(fresh)
        if set(units) - exposed:
            raise ValueError("DISCONNECTED_FUNCTION_UNIT: " + uid)
        nodes = list(units) + sorted({port["interface_ref"] for port in function["ports"]})
        result.append(dict(function, node_refs=nodes, edges=graph,
                           revisions=[{"requirement_uid": ref, "revision_uid": effective[ref]} for ref in function["requirement_refs"]]))
    return result


def walk_objects(value):
    if isinstance(value, dict):
        yield value
        for key, item in value.items():
            if key != "function_views":
                yield from walk_objects(item)
    elif isinstance(value, list):
        for item in value:
            yield from walk_objects(item)


def artifacts(functions, names, data_bytes, *, prefix="diagrams/functions"):
    files = {}
    index = []
    for function in functions:
        uid = function["uid"]
        stem = prefix + "/" + uid
        labels = dict(names, **{unit["uid"]: unit["name"] for unit in function["units"]})
        source = mermaid(function, labels)
        files[stem + ".mmd"] = source.encode("utf-8")
        files[stem + ".svg"] = svg(function, labels).encode("utf-8")
        index.append(dict({key: function[key] for key in ("uid", "name", "parent_ref", "units", "ports", "excluded_ports", "support_refs",
                                                        "revisions", "internal_flows", "edges")},
                          svg=uid + ".svg", mermaid=uid + ".mmd"))
    files[prefix + "/index.json"] = data_bytes(index)
    return files


def flow_label(edge):
    condition = " · " + edge["condition"] if edge.get("condition") else ""
    return KINDS[edge["kind"]] + condition + " · " + edge["label"]


def mermaid(function, labels):
    def label(text):
        # Mermaid numeric entities preserve punctuation without interpreting syntax.
        return "".join(ch if ch.isalnum() or ch == " " else f"#{ord(ch)};" for ch in text)

    mapping = {node: f"n{i}" for i, node in enumerate(function["node_refs"])}
    lines = ["flowchart LR"]
    for node, token in mapping.items():
        lines.append(f'  {token}["{label(labels[node] + " / " + node)}"]')
    for i, edge in enumerate(function["edges"], 1):
        text = label(f"{i}. " + flow_label(edge))
        lines.append(f'  {mapping[edge["from"]]} -->|"{text}"| {mapping[edge["to"]]}')
    return "\n".join(lines) + "\n"


def svg(function, names):
    """Draw editable Mermaid's companion as a dependency-free offline view."""
    nodes = function["node_refs"]
    units = {unit["uid"]: unit for unit in function["units"]}
    edges = function["edges"]
    links = defaultdict(list)
    for index, edge in enumerate(edges, 1):
        links[(edge["from"], edge["to"], edge["kind"])].append((index, flow_label(edge)))
    # Place ingress on the left and egress and bidirectional ports on the right.
    sides = defaultdict(set)
    for port in function["ports"]:
        sides[port["interface_ref"]].add(port["direction"])
    columns = ([node for node in nodes if sides[node] == {"in"}], list(units),
               [node for node in nodes if sides[node] == {"out"} or len(sides[node]) == 2])
    positions = {node: (32 + col * 370, 70 + row * 68)
                 for col, column in enumerate(columns) for row, node in enumerate(column)}
    height = 99 + max(map(len, columns)) * 68
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1090 {height}" role="img">',
           "<title>" + escape(function["name"]) + "</title>",
           '<style>text{font-family:Microsoft YaHei UI,sans-serif;fill:#183148}.title{font-size:17px;font-weight:bold}.uid{font-size:11px;fill:#46627a}.col{font-size:14px;fill:#315168}.edge{fill:none;stroke-width:1.6;opacity:.76}</style>',
           '<rect width="100%" height="100%" fill="#f6f9fc"/>']
    colors = {"data": "#0a786e", "control": "#395d91", "status": "#985b0d", "clock_reset": "#78558f"}
    for kind, color in colors.items():
        out.append(f'<marker id="a-{kind}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="{color}"/></marker>')
    for index, (kind, color) in enumerate(colors.items()):
        x = 32 + index * 117
        out.append(f'<path d="M{x} 29 h16" stroke="{color}" stroke-width="2"/><text class="col" x="{x + 22}" y="34">{KINDS[kind]}</text>')
    for x, name in ((32, "输入接口"), (402, "子功能单元"), (772, "输出／双向接口")):
        out.append(f'<text class="col" x="{x}" y="61">{name}</text>')
    tracks = defaultdict(list)
    for key in links:
        tracks[tuple(sorted(key[:2]))].append(key)
    for (start, end, kind), labels in links.items():
        x1, y1 = positions[start]
        x2, y2 = positions[end]
        y1, y2 = y1 + 26, y2 + 26
        tracks_here = tracks[tuple(sorted((start, end)))]
        track = tracks_here.index((start, end, kind))
        offset = (track - (len(tracks_here) - 1) / 2) * min(8, 28 / len(tracks_here))
        y1, y2 = y1 + offset, y2 + offset
        if x1 == x2:
            x1, x2 = x1 + 286, x2 + 286
            path = f"M{x1} {y1} C{x1 + 44} {y1} {x2 + 44} {y2} {x2} {y2}"
            lx = x1 + 33
        else:
            if x1 < x2:
                x1 += 286
            else:
                x2 += 286
            mid = (x1 + x2) / 2
            path = f"M{x1} {y1} C{mid} {y1} {mid} {y2} {x2} {y2}"
            lx = mid
        label = "；".join(f"{i}. {text}" for i, text in labels)
        out.append(f'<path class="edge" d="{path}" stroke="{colors[kind]}" marker-end="url(#a-{kind})"><title>{escape(label)}</title></path>')
        edge_ids = ",".join(str(i) for i, _ in labels)
        out.append(f'<text x="{lx}" y="{(y1 + y2) / 2 - 3}" text-anchor="middle" class="uid" stroke="white" stroke-width="4" paint-order="stroke">{edge_ids}</text>')
    for node, (x, y) in positions.items():
        name = names.get(node, node)
        short = name if len(name) <= 16 else name[:15] + "…"
        refs = " / ".join(units[node]["module_refs"]) if node in units else node
        fill = "#dff4ef" if node in units else "#fff"
        out.append(f'<g><title>{escape(name)} · {escape(refs)}</title><rect x="{x}" y="{y}" width="286" height="52" rx="7" fill="{fill}" stroke="#a8bdce"/><text class="title" x="{x+10}" y="{y+21}">{escape(short)}</text><text class="uid" x="{x+10}" y="{y+39}">{escape(refs[:39])}</text></g>')
    out.append("</svg>\n")
    return "\n".join(out)
