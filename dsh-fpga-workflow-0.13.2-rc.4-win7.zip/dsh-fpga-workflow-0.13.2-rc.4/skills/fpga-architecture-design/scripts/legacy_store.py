"""Descriptive as-is architecture store. No RTL execution or target design."""
from pathlib import Path
import copy
import shutil
import uuid

import archlib as a
import evolution as e


def workspace_info(root):
    root = Path(root)
    info = a.load(root / "legacy_workspace.json")
    unsigned = dict(info)
    unsigned.pop("binding_sha256")
    a.require(a.fingerprint(unsigned) == info["binding_sha256"] and info["tool_fingerprint"] == a.tool_fingerprint(), "LEGACY_WORKSPACE_BINDING_CHANGED")
    for path, digest in info["bindings"].items():
        a.require(a.sha(a.safe(root, path)) == digest, "LEGACY_WORKSPACE_SOURCE_CHANGED")
    e.inventory(root)
    return info


def prepare(manifest, output):
    manifest = Path(manifest).resolve()
    with a.transaction(output, (manifest.parent, a.SKILL)) as dest:
        inv = e.snapshot_legacy(manifest, dest)
        info = {"workspace_uid": "legacy-workspace:" + uuid.uuid4().hex, "created_at": a.now(), "tool_fingerprint": a.tool_fingerprint(),
                "bindings": {p.relative_to(dest).as_posix(): a.sha(p) for p in a.all_files(dest)}}
        info["binding_sha256"] = a.fingerprint(info)
        a.save(dest / "legacy_workspace.json", info)
        template = {"contract": "FPGA-LEGACY-ARCH/1.0.0", "workspace_uid": info["workspace_uid"], "binding_sha256": info["binding_sha256"],
                    "name": inv["baseline_name"], "version": "0.1.0", "status": "DESCRIPTIVE_DRAFT",
                    "parent_baseline_sha256": None, "revision_reason": "初次整理现有实现",
                    "configuration": {"top": None, "tool_version": None, "part": None, "defines": [], "parameters": []},
                    "objects": [], "relationships": [], "unknowns": [],
                    "file_dispositions": [{"file_uid": f["uid"], "status": "indexed", "object_refs": [], "reason": "仅建立文件索引，尚未语义阅读"} for f in inv["files"]]}
        a.save(dest / "legacy_architecture.template.json", template)
    return {"workspace": str(Path(output).resolve()), "status": "INDEXED", "file_count": len(inv["files"])}


def validate_model(model, workspace):
    info = workspace_info(workspace)
    schema = a.load(a.SKILL / "references/legacy-architecture.schema.json")
    a.contract.audit_schema(schema)
    errors = a.contract.validate_schema(model, schema)
    a.require(not errors, "LEGACY_ARCHITECTURE_SCHEMA_INVALID: " + "; ".join(errors[:8]))
    a.require(model["workspace_uid"] == info["workspace_uid"] and model["binding_sha256"] == info["binding_sha256"] and model["name"].strip() and model["version"].strip(), "LEGACY_MODEL_BINDING_INVALID")
    a.require(model["revision_reason"].strip(), "LEGACY_REVISION_REASON_REQUIRED")
    inv = e.inventory(workspace)
    files = {f["uid"]: f for f in inv["files"]}
    objects = {x["uid"]: x for x in model["objects"]}
    unknowns = {x["uid"]: x for x in model["unknowns"]}
    ids = [x["uid"] for g in ("objects", "relationships", "unknowns") for x in model[g]]
    a.require(len(ids) == len(set(ids)) and all(ids), "DUPLICATE_LEGACY_UID")
    def spans(records, allowed_files):
        for span in records:
            a.require(span["file_uid"] in allowed_files and span["file_uid"] in files and 1 <= span["start_line"] <= span["end_line"] and span["reason"].strip(), "LEGACY_SOURCE_SPAN_INVALID")
            f = files[span["file_uid"]]
            a.require(f["read_status"] == "readable" and span["end_line"] <= f["line_count"], "LEGACY_SOURCE_SPAN_OUT_OF_RANGE")
    for obj in objects.values():
        a.require(obj["file_refs"] and set(obj["file_refs"]) <= set(files) and obj["summary"].strip() and obj["name"].strip(), "LEGACY_OBJECT_SOURCE_REQUIRED")
        spans(obj["source_spans"], obj["file_refs"])
        a.require(obj["confidence"] != "confirmed" or obj["source_spans"], "CONFIRMED_LEGACY_OBJECT_NEEDS_SOURCE_SPAN")
        a.require(set(obj["clock_refs"]) <= set(objects) and set(obj["reset_refs"]) <= set(objects) and set(obj["unknown_refs"]) <= set(unknowns), "LEGACY_OBJECT_REFERENCE_INVALID")
        for ref in obj["clock_refs"]:
            a.require(objects[ref]["kind"] == "clock", "LEGACY_CLOCK_REFERENCE_WRONG_TYPE")
        for ref in obj["reset_refs"]:
            a.require(objects[ref]["kind"] == "reset", "LEGACY_RESET_REFERENCE_WRONG_TYPE")
        for port in obj["ports"]:
            a.require(port["clock_ref"] is None or port["clock_ref"] in obj["clock_refs"], "LEGACY_PORT_CLOCK_REFERENCE_INVALID")
            a.require(port["reset_ref"] is None or port["reset_ref"] in obj["reset_refs"], "LEGACY_PORT_RESET_REFERENCE_INVALID")
    for relation in model["relationships"]:
        a.require(relation["from_uid"] in objects and relation["to_uid"] in objects and relation["description"].strip(), "LEGACY_RELATIONSHIP_DANGLING")
        a.require(set(relation["file_refs"]) <= set(files), "LEGACY_RELATIONSHIP_SOURCE_INVALID")
        spans(relation["source_spans"], relation["file_refs"])
        a.require(relation["confidence"] != "confirmed" or relation["source_spans"], "CONFIRMED_RELATIONSHIP_NEEDS_SOURCE")
    for unknown in unknowns.values():
        a.require(set(unknown["object_refs"]) <= set(objects) and set(unknown["file_refs"]) <= set(files) and
                  unknown["description"].strip() and unknown["close_criterion"].strip(), "LEGACY_UNKNOWN_INVALID")
    disposition = {x["file_uid"]: x for x in model["file_dispositions"]}
    a.require(len(disposition) == len(model["file_dispositions"]) and set(disposition) == set(files), "LEGACY_FILE_COVERAGE_MISSING")
    for uid, d in disposition.items():
        a.require(set(d["object_refs"]) <= set(objects) and d["reason"].strip(), "LEGACY_FILE_DISPOSITION_INVALID")
        if d["status"] == "read":
            a.require(files[uid]["read_status"] == "readable" and d["object_refs"] and all(uid in objects[o]["file_refs"] for o in d["object_refs"]), "READ_FILE_NEEDS_GROUNDED_OBJECT")
    return inv


def derived(model, inventory):
    index = [{"uid": x["uid"], "original_uid": x["original_uid"], "name": x["name"], "kind": x["kind"],
              "confidence": x["confidence"], "file_refs": x["file_refs"], "path": "objects/" + a.fingerprint(x["uid"]) + ".json"} for x in model["objects"]]
    files = {"object_index.json": a.data_bytes(index), "relationship_index.json": a.data_bytes(model["relationships"]),
             "coverage.json": a.data_bytes({"files_total": len(inventory["files"]), "objects_total": len(index),
                                            "read": sum(x["status"] == "read" for x in model["file_dispositions"]),
                                            "indexed_or_deferred": sum(x["status"] in ("indexed", "deferred") for x in model["file_dispositions"]),
                                            "unknowns": len(model["unknowns"]), "engineering_approval": False})}
    for obj, row in zip(model["objects"], index):
        files[row["path"]] = a.data_bytes(obj)
    return files


def build(workspace, model_path, output, parent=None):
    workspace, model_path = Path(workspace).resolve(), Path(model_path).resolve()
    model = a.load(model_path)
    inv = validate_model(model, workspace)
    sources = [workspace, model_path, a.SKILL]
    if model["parent_baseline_sha256"] is None:
        a.require(parent is None, "UNBOUND_LEGACY_PARENT")
    else:
        a.require(parent is not None, "LEGACY_PARENT_PACKAGE_REQUIRED")
        previous = validate(parent)
        a.require(a.sha(Path(parent) / "legacy_package.json") == model["parent_baseline_sha256"] and previous["version"] != model["version"], "LEGACY_PARENT_BINDING_OR_VERSION_INVALID")
        sources.append(Path(parent))
    with a.transaction(output, sources) as dest:
        shutil.copytree(str(workspace), str(dest / "sources"))
        a.save(dest / "legacy_architecture.json", model)
        a.save(dest / "schemas/legacy-architecture.schema.json", a.load(a.SKILL / "references/legacy-architecture.schema.json"))
        if parent is not None:
            (dest / "history").mkdir()
            shutil.copyfile(str(Path(parent) / "legacy_package.json"), str(dest / "history/parent_package.json"))
            shutil.copyfile(str(Path(parent) / "legacy_architecture.json"), str(dest / "history/parent_model.json"))
        for relative, content in derived(model, inv).items():
            path = a.safe(dest, relative)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        a.save(dest / "legacy_package.json", {"contract": "FPGA-LEGACY-PACKAGE/1.0.0", "status": "DESCRIPTIVE_DRAFT", "created_at": a.now(),
                                               "artifacts": {p.relative_to(dest).as_posix(): a.sha(p) for p in a.all_files(dest)}})
        validate(dest)
    return {"baseline": str(Path(output).resolve()), "status": "DESCRIPTIVE_DRAFT", "objects": len(model["objects"]), "requires_generation_approval_for_changes": True}


def validate(root):
    root = Path(root).resolve()
    package = a.load(root / "legacy_package.json")
    a.require(package["contract"] == "FPGA-LEGACY-PACKAGE/1.0.0" and package["status"] == "DESCRIPTIVE_DRAFT", "LEGACY_PACKAGE_NOT_DESCRIPTIVE")
    a.require(package["artifacts"] == {p.relative_to(root).as_posix(): a.sha(p) for p in a.all_files(root) if p != root / "legacy_package.json"}, "LEGACY_PACKAGE_DIGEST_MISMATCH")
    model = a.load(root / "legacy_architecture.json")
    inv = validate_model(model, root / "sources")
    a.require(a.load(root / "schemas/legacy-architecture.schema.json") == a.load(a.SKILL / "references/legacy-architecture.schema.json"), "LEGACY_SCHEMA_CHANGED")
    if model["parent_baseline_sha256"] is not None:
        a.require(a.sha(root / "history/parent_package.json") == model["parent_baseline_sha256"], "LEGACY_PARENT_MANIFEST_CHANGED")
        parent_manifest = a.load(root / "history/parent_package.json")
        a.require(parent_manifest["artifacts"]["legacy_architecture.json"] == a.sha(root / "history/parent_model.json"), "LEGACY_PARENT_MODEL_CHANGED")
    for path, content in derived(model, inv).items():
        a.require(a.safe(root, path).read_bytes() == content, "LEGACY_DERIVED_OBJECT_CHANGED")
    return model


def query(root, uid=None, kind=None, offset=0, limit=20, detail=False):
    model = validate(root)
    a.require(0 <= offset and 1 <= limit <= 100, "LEGACY_QUERY_PAGE_INVALID")
    rows = [x for x in model["objects"] if (uid is None or x["uid"] == uid) and (kind is None or x["kind"] == kind)]
    selected = rows[offset:offset + limit]
    if not detail:
        selected = [{k: x[k] for k in ("uid", "original_uid", "name", "kind", "confidence", "file_refs", "unknown_refs")} for x in selected]
    return {"status": "DESCRIPTIVE_DRAFT", "total": len(rows), "items": selected, "next_offset": offset + limit if offset + limit < len(rows) else None}


def read_source(workspace, file_uid, start=1, count=100):
    workspace_info(workspace)
    a.require(start >= 1 and 1 <= count <= 500, "LEGACY_READ_RANGE_INVALID")
    record = next((f for f in e.inventory(workspace)["files"] if f["uid"] == file_uid), None)
    a.require(record is not None and record["read_status"] == "readable", "LEGACY_FILE_NOT_READABLE")
    path = a.safe(Path(workspace) / "legacy/files", record["path"])
    selected = []
    consumed = 0
    with path.open("r", encoding=record["encoding"]) as stream:
        for number, line in enumerate(stream, 1):
            if number < start:
                continue
            if not selected and len(line) > 20000:
                return {"file_uid": file_uid, "sha256": record["sha256"], "lines": [{"line": number, "text": line[:20000], "line_truncated": True}], "next_line": number + 1, "truncated": True}
            if len(selected) >= count or consumed + len(line) > 20000:
                return {"file_uid": file_uid, "sha256": record["sha256"], "lines": selected, "next_line": number, "truncated": True}
            selected.append({"line": number, "text": line.rstrip("\r\n")})
            consumed += len(line)
    return {"file_uid": file_uid, "sha256": record["sha256"], "lines": selected, "next_line": None, "truncated": False}


def attach(baseline, destination):
    baseline = Path(baseline).resolve()
    model = validate(baseline)
    shutil.copytree(str(baseline), str(destination / "inherited_architecture"))
    shutil.copytree(str(baseline / "sources/legacy"), str(destination / "legacy"))
    shutil.copyfile(str(baseline / "sources/legacy_inventory.json"), str(destination / "legacy_inventory.json"))
    a.save(destination / "legacy_baseline_binding.json", {"package_sha256": a.sha(baseline / "legacy_package.json"), "model_sha256": a.sha(baseline / "legacy_architecture.json")})
    return model


def inherited(attempt):
    path = Path(attempt) / "legacy_baseline_binding.json"
    if not path.exists():
        return None
    record = a.load(path)
    root = Path(attempt) / "inherited_architecture"
    a.require(record == {"package_sha256": a.sha(root / "legacy_package.json"), "model_sha256": a.sha(root / "legacy_architecture.json")}, "INHERITED_ARCHITECTURE_BINDING_CHANGED")
    model = validate(root)
    a.require(e.inventory(attempt) == e.inventory(root / "sources"), "INHERITED_CODE_BASELINE_MISMATCH")
    return model


def seed_scope(attempt):
    model = inherited(attempt)
    if model is None:
        return []
    return [{"uid": x["uid"], "original_uid": x["original_uid"], "name": x["name"], "kind": x["kind"], "file_refs": x["file_refs"],
             "locator": "; ".join(s["file_uid"] + ":" + str(s["start_line"]) + "-" + str(s["end_line"]) for s in x["source_spans"]) or "仅结构说明/索引；待核实", "action": "reuse",
             "rationale": "默认保留现有对象，待范围方案决定处置", "current_behavior": x["summary"], "confidence": x["confidence"]} for x in model["objects"]]


def validate_plan_basis(plan, attempt):
    model = inherited(attempt)
    if e.inventory(attempt)["mode"] == "new":
        a.require(plan["legacy_architecture_sha256"] is None and model is None, "NEW_MODE_WITH_ASIS_BASELINE")
        return
    a.require(model is not None, "STRUCTURED_LEGACY_BASELINE_REQUIRED: organize legacy architecture before proposing target changes")
    a.require(plan["legacy_architecture_sha256"] == a.sha(Path(attempt) / "inherited_architecture/legacy_architecture.json"), "PLAN_ASIS_BASELINE_CHANGED")
    expected = {x["uid"]: x for x in seed_scope(attempt)}
    actual = {x["uid"]: x for x in plan["legacy_scope"]}
    a.require(set(actual) == set(expected), "ASIS_OBJECTS_OMITTED_FROM_CHANGE_PLAN")
    for uid, item in actual.items():
        a.require(all(item[k] == expected[uid][k] for k in ("original_uid", "name", "kind", "file_refs", "locator", "current_behavior", "confidence")), "ASIS_FACT_CHANGED_IN_TARGET_PLAN")
