"""Render the offline review entry point from validated architecture data."""
from html import escape
from pathlib import Path
from string import Template
from urllib.parse import quote
import math


DRAFT_STATUS = '<span class="status">DRAFT · 待架构冻结</span>'
LAYOUT = Path(__file__).resolve().parents[1] / "references/review-page.html"


def validate_views(model):
    view = next(v for v in model["views"] if v["kind"] == "data")
    edges = {(e["from"], e["to"]) for e in view["edges"]}
    for path in model.get("review_paths", []):
        refs = path["node_refs"]
        if any(edge not in edges for edge in zip(refs, refs[1:])):
            raise ValueError("REVIEW_PATH_EDGE_MISSING: " + path["name"])
    evidence = {ev["uid"] for ev in model["evidence"]}
    for timeline in model.get("review_timelines", []):
        offsets = [event["offset_us"] for event in timeline["events"]]
        if not all(math.isfinite(value) for value in offsets) or offsets != sorted(offsets):
            raise ValueError("REVIEW_TIMELINE_ORDER_OR_TIME_INVALID: " + timeline["name"])
        if not set(timeline["evidence_refs"]) <= evidence:
            raise ValueError("REVIEW_TIMELINE_EVIDENCE_UNKNOWN: " + timeline["name"])


def e(value):
    return escape(str(value), quote=True)


def link(path, label):
    return '<a href="' + e(quote(path, safe="/#.-_")) + '">' + e(label) + "</a>"


def frozen_status(review):
    return '<span class="status frozen">FROZEN · 已冻结</span><p class="allowed">批准范围 · ' + e(review["allowed_scope"]) + " · " + link("review.json", "查看冻结记录") + "</p>"


def rows(columns, values):
    head = "".join('<th scope="col">' + e(col) + "</th>" for col in columns)
    body = "".join("<tr>" + "".join("<td>" + val + "</td>" for val in row) + "</tr>" for row in values)
    return '<div class="table-wrap"><table><thead><tr>' + head + "</tr></thead><tbody>" + body + "</tbody></table></div>"


def flow(model, names):
    blocks = []
    for path in model.get("review_paths", []):
        nodes = "".join("<li>" + e(names.get(uid, uid)) + "<small>" + e(uid) + "</small></li>" for uid in path["node_refs"])
        blocks.append("<h3>" + e(path["name"]) + '</h3><div class="flow-wrap"><ol class="flow">' + nodes + "</ol></div>")
    return "".join(blocks) or "<p>主路径摘要待编制，可从完整数据流视图核对生产端、消费端和流向。</p>"


def timelines(items, evidence):
    charts = []
    for item in items:
        events = item["events"]
        start, end = events[0]["offset_us"], events[-1]["offset_us"]
        span = end - start or 1
        lines = []
        for event in events:
            value = event["offset_us"]
            position = (value - start) / span * 100
            time = f"{value:,.6g} μs" if abs(value) < 1000 else f"{value / 1000:,.6g} ms"
            lines.append(f'<li><span>{e(event["label"])}</span><strong>{time}</strong><div class="track" aria-hidden="true"><i style="left:{position:.4f}%"></i></div></li>')
        sources = " · ".join(evidence[uid] for uid in item["evidence_refs"])
        charts.append("<h3>" + e(item["name"]) + "</h3><p>时间原点 · " + e(item["reference"]) +
                      '</p><ol class="timeline">' + "".join(lines) + '</ol><p class="fine">依据 · ' + sources + "</p>")
    return "".join(charts)


def function_section(functions, prefix):
    from function_views import flow_label

    if not functions:
        return "", ""
    names = {item["uid"]: item["name"] for item in functions}
    children = {}
    for item in functions:
        children.setdefault(item["parent_ref"], []).append(item["uid"])
    diagrams = []
    for item in functions:
        uid = item["uid"]
        stem = prefix + "/" + uid
        parent = " · 上级 " + link("#" + item["parent_ref"], names[item["parent_ref"]]) if item["parent_ref"] else ""
        related = " · ".join(link("#" + child, names[child]) for child in children.get(uid, ()))
        related = f'<p class="fine">子功能图 · {related}</p>' if related else ""
        units = "、".join(e(unit["name"]) for unit in item["units"])
        unit_names = {unit["uid"]: unit["name"] for unit in item["units"]}
        refs = " · ".join("<code>" + e(row["revision_uid"]) + "</code>" for row in item["revisions"])
        flows = rows(("边号", "起点", "终点", "流向与条件"),
                     [(str(index), e(unit_names.get(edge["from"], edge["from"])),
                       e(unit_names.get(edge["to"], edge["to"])), e(flow_label(edge)))
                      for index, edge in enumerate(item["edges"], 1)])
        support = " · ".join("<code>" + e(ref) + "</code>" for ref in item["support_refs"])
        support = f'<p class="fine">配套架构对象 · {support}</p>' if support else ""
        excluded = rows(("接口", "模块", "方向", "排除理由"),
                        [(e(port["interface_ref"]), e(port["module_ref"]), e("输入" if port["direction"] == "in" else "输出"),
                          e(port["reason"])) for port in item["excluded_ports"]]) if item["excluded_ports"] else ""
        excluded = f'<details><summary>本图范围外的接口</summary>{excluded}</details>' if excluded else ""
        diagrams.append(f'<details id="{e(uid)}"><summary>{e(item["name"])} · {len(item["units"])} 个子功能单元</summary>'
                        f'<p class="fine">{e(uid)}{parent} · {units}</p><p class="fine">{refs}</p>{related}{support}'
                        f'<p class="fine">{link(stem + ".svg", "打开完整图")} · {link(stem + ".mmd", "Mermaid 源文件")}</p>'
                        f'<div class="flow-wrap"><img class="flow-image" style="min-width:800px" loading="lazy" src="{e(quote(stem + ".svg"))}" alt="{e(item["name"])}架构图"></div>'
                        f'<details><summary>逐边流向与条件</summary>{flows}</details>{excluded}</details>')
    return ('<li><a href="#functions">分功能架构图</a></li>',
            '<section id="functions" class="panel"><h2>分功能架构图</h2><p class="fine">' +
            str(len(children.get(None, ()))) + " 项功能 · " + str(len(functions) - len(children.get(None, ()))) +
            " 张子功能图 · " + link(prefix + "/index.json", "结构化索引") + "</p>" + "".join(diagrams) + "</section>")


def render(model, summary, readiness, results, names, reports, *, base="", comparison="", flow_override=None,
           functions=(), function_prefix=None):
    evidence = {ev["uid"]: link(base + "support/" + ev["path"], ev["uid"]) for ev in model["evidence"]}
    issue_ids = {issue["uid"]: "issue-" + str(index) for index, issue in enumerate(model["issues"], 1) if issue["status"] == "open"}
    issues = []
    for issue in sorted(model["issues"], key=lambda row: (row["severity"], row["uid"])):
        if issue["uid"] not in issue_ids:
            continue
        refs = " · ".join(evidence[uid] for uid in issue["evidence_refs"])
        issues.append('<article class="issue" id="' + issue_ids[issue["uid"]] + '"><h3><span>' + e(issue["severity"]) + "</span> " +
                      e(issue["uid"]) + "</h3><p>" + e(issue["description"]) + "</p><dl><dt>关闭条件</dt><dd>" +
                      e(issue["close_criterion"]) + "</dd><dt>负责人</dt><dd>" + e(issue["owner"]) +
                      '</dd></dl><p class="fine">' + refs + "</p></article>")
    measures = []
    outcome = {"pass": "计算通过", "fail": "计算不通过", "unbounded": "无界", "unknown": "待证明"}
    for budget, result in zip(model["budgets"], results):
        uid = budget["uid"]
        value = f'{result["value"]:,.6g} {result["unit"]}' if "value" in result else "待定"
        result_label = "分析已复核" if result["status"] == "unknown" and result.get("reviewed_analysis") else outcome[result["status"]]
        issues_link = " · ".join(link("#" + issue_ids[i], i) for i in budget["issue_refs"] if i in issue_ids)
        measures.append((e(budget["name"]) + "<small>" + e(uid) + "</small>", e(value), e(result_label),
                         e(budget["analysis"]) + ("<small>" + issues_link + "</small>" if issues_link else "")))
    decisions = [
        (e(item["name"]) + "<small>" + e(item["uid"]) + "</small>", e(item["selected"]), e(item["rationale"]))
        for item in model["decisions"]
    ]
    allocated = sum(bool(row["object_refs"] and row["verification_refs"]) for row in model["allocations"])
    gates = "".join("<li>" + e(REASONS.get(reason, reason)) + "</li>" for reason in readiness["reasons"])
    gate_label = "冻结条件未满足" if readiness["status"] == "blocked" else "具备评审条件"
    input_label = {"ready": "可用于架构", "conditional": "限范围可用", "blocked": "阻塞"}[summary["readiness"]]
    if summary["synthetic"]:
        input_label += " · 合成数据"
    views = [("functional", "功能分解"), ("data", "完整数据流"), ("clock_reset", "时钟复位"), ("physical", "物理接口")]
    resources = [("package.json", "架构包清单"), ("architecture.json", "架构主模型"),
                 ("inputs/upstream/package.json", "需求发布清单"), ("inputs/upstream/icd.json", "输入 ICD"),
                 ("interface_contracts.json", "架构接口契约"), ("RTM.csv", "需求追溯矩阵"),
                 ("detailed_design_input.json", "详细设计输入"), ("verification_input.json", "验证输入")]
    entry_links = "".join("<li>" + link(base + path, title) + "</li>" for path, title in resources)
    report_links = "".join("<li>" + link(base + reports[uid], title) + "</li>" for uid, title in REPORTS if uid in reports)
    appendix = "".join("<li>" + evidence[ev["uid"]] + "<span> " + e(ev["locator"]) + "</span></li>" for ev in model["evidence"])
    tags = {
        "project": e(model["project"]), "phase": e(model["phase"]), "version": e(model["version"]), "status": DRAFT_STATUS,
        "date": e(summary["report_date"]), "configuration": e(model["configuration"]),
        "baseline": e(summary["baseline_uid"]), "run": e(summary["run_uid"]),
        "candidate": e(summary.get("candidate_uid") or "无"), "input_label": e(input_label),
        "gate_label": e(gate_label), "open_count": str(len(issues)), "allocated": f'{allocated}/{len(summary["effective_requirements"])}',
        "gates": '<ul class="reasons">' + gates + "</ul>" if gates else "",
        "comparison": comparison, "flow": flow(model, names) if flow_override is None else flow_override,
        "views": "".join(link(base + "diagrams/" + key + ".mmd", title) for key, title in views),
        "timelines": timelines(model.get("review_timelines", []), evidence),
        "budgets": rows(("预算", "结果", "状态", "口径与待核项"), measures) if measures else "<p>当前无预算条目。</p>",
        "budget_link": link(base + "budget_results.json", "预算计算明细"),
        "issues": "".join(issues) or "<p>当前架构模型没有开放问题。</p>",
        "decisions": rows(("决策", "选定方案", "理由"), decisions) if decisions else "<p>当前无架构决策条目。</p>",
        "resources": entry_links, "reports": report_links, "evidence": appendix or "<li>当前无已绑定证据。</li>",
    }
    output = Template(LAYOUT.read_text(encoding="utf-8")).substitute(tags)
    nav, section = function_section(functions, function_prefix or base + "diagrams/functions")
    if section:
        if '<li><a href="#budgets">' not in output or '<section id="budgets"' not in output:
            raise ValueError("FUNCTION_REVIEW_LAYOUT_ANCHOR_MISSING")
        output = output.replace('<li><a href="#budgets">', nav + '<li><a href="#budgets">', 1)
        output = output.replace('<section id="budgets"', section + '\n<section id="budgets"', 1)
    return output


REPORTS = (("01", "RPT-01 架构设计"), ("02", "RPT-02 定量预算与算法精度"), ("03", "RPT-03 接口与时钟复位"),
           ("04", "RPT-04 验证计划与覆盖"), ("06", "RPT-06 评审与问题闭环"), ("07", "RPT-07 规则符合性"))
REASONS = {
    "target baseline incomplete": "器件、板卡或实现工具链基线待补齐",
    "open B0/B1/B2 issue": "存在开放的 B0/B1/B2 问题",
    "budget failed or not mechanically resolved; requires reviewed evidence": "部分预算待证明或复核",
    "due mandatory checks incomplete": "当前阶段强制检查待完成",
    "rule applicability pending": "部分规则适用性待确认",
}
