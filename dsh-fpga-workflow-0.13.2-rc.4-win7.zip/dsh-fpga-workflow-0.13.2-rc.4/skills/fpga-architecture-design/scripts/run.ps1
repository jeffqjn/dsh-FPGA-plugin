#requires -version 2.0
param([string]$Action)
$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = $env:FPGA_PYTHON38
if ([string]::IsNullOrEmpty($pythonExe)) { $pythonExe = 'C:\Python38\python.exe' }
if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) {
    throw 'Python 3.8.10 was not found. Set FPGA_PYTHON38 to its full python.exe path.'
}
if ([string]::IsNullOrEmpty($Action)) { throw 'Action is required. Start with doctor or self-test.' }
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$lines = & $pythonExe (Join-Path $scriptDir 'cli.py') $Action @args
$resultCode = $LASTEXITCODE
foreach ($line in $lines) { Write-Output $line }
if ($resultCode -ne 0) { exit $resultCode }
$joined = [string]::Join("`n", [string[]]$lines)
if ($joined.IndexOf(('FPGA_ARCH_OK:' + $Action)) -lt 0) { throw 'Success marker missing.' }
exit 0
