"""Offline invariant tests. All generated files stay in TemporaryDirectory."""
import copy
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import archlib as a


def run_tests():
    import review_page
    from function_views import collect, mermaid

    passed = []
    def check(name, condition):
        a.require(condition, "SELF_TEST_FAILED: " + name)
        passed.append(name)
    def rejects(name, callback, expected=None):
        try:
            callback()
        except (ValueError, OSError, KeyError) as exc:
            if expected is not None and not str(exc).startswith(expected):
                raise
            passed.append(name)
            return
        raise ValueError("SELF_TEST_DID_NOT_REJECT: " + name)
    def budget(kind, parameters, issues=None):
        return {"uid": "BUD-test", "kind": kind, "parameters": parameters, "issue_refs": issues or [],
                "unit": "test", "basis": "derived", "assumptions": "synthetic self-test only"}
    timeline = {"name": "Request", "reference": "Trigger", "evidence_refs": ["EVD-01"],
                "events": [{"label": "Start", "offset_us": 0}, {"label": "Return", "offset_us": 30}]}
    review_model = {"views": [{"kind": "data", "edges": [{"from": "A", "to": "B"}]}],
                    "review_paths": [{"name": "Frame", "node_refs": ["A", "B"]}],
                    "review_timelines": [timeline], "evidence": [{"uid": "EVD-01"}]}
    review_page.validate_views(review_model)
    reversed_path = dict(review_model, review_paths=[{"name": "Frame", "node_refs": ["B", "A"]}])
    rejects("review path cannot reverse a model edge", lambda: review_page.validate_views(reversed_path), "REVIEW_PATH_EDGE_MISSING")
    unbound = dict(review_model, evidence=[])
    rejects("review timeline requires model evidence", lambda: review_page.validate_views(unbound), "REVIEW_TIMELINE_EVIDENCE_UNKNOWN")
    unsorted = dict(review_model, review_timelines=[dict(timeline, events=list(reversed(timeline["events"])))])
    rejects("review timeline offsets must be ordered", lambda: review_page.validate_views(unsorted), "REVIEW_TIMELINE_ORDER_OR_TIME_INVALID")
    check("review path escapes model labels", "&lt;script&gt;" in review_page.flow(review_model, {"A": "<script>"}))
    check("frozen review links to its signed record", 'href="review.json"' in review_page.frozen_status({"allowed_scope": "<scope>"}))
    function = dict(uid="FN-TEST", name="Test", parent_ref=None, requirement_refs=["R1"],
                    units=[{"uid": "U1", "name": "Sample", "module_refs": ["M1"]},
                           {"uid": "U2", "name": "Publish", "module_refs": ["M2"]}],
                    ports=[dict(interface_ref="IF1", module_ref="M1", unit_ref="U1", direction="out", kind="data"),
                           dict(interface_ref="IF1", module_ref="M2", unit_ref="U2", direction="in", kind="data")],
                    internal_flows=[], excluded_ports=[], support_refs=[])
    function_model = dict(function_views=[function], modules=[{"uid": "M1"}, {"uid": "M2"}], interfaces=[{"uid": "IF1"}],
                          allocations=[{"requirement_uid": "R1", "object_refs": ["M1", "M2"]}],
                          views=[{"kind": "data", "edges": [{"from": "M1", "to": "IF1", "label": "payload"},
                                                             {"from": "IF1", "to": "M2", "label": "payload"}]}])
    function_summary = {"effective_requirements": [{"requirement_uid": "R1", "revision_uid": "R1-r1"}]}
    function_facts = {"model": {"requirements": [{"uid": "R1", "category": "function"}]}}
    def project_functions(item):
        return collect(dict(function_model, function_views=item), function_summary, function_facts)
    projected = project_functions([function])[0]
    check("function graph uses global interface edges and exact requirement revision",
          [(edge["from"], edge["to"]) for edge in projected["edges"]] == [("U1", "IF1"), ("IF1", "U2")] and
          projected["revisions"][0]["revision_uid"] == "R1-r1")
    rejects("effective function cannot lack a view", lambda: project_functions([]), "FUNCTION_REQUIREMENTS_WITHOUT_VIEW")
    reversed_port = dict(function["ports"][0], direction="in")
    rejects("function port cannot reverse a global edge",
            lambda: project_functions([dict(function, ports=[reversed_port, function["ports"][1]])]),
            "FUNCTION_PORT_DIRECTION_OR_OWNERSHIP_MISMATCH")
    rejects("both endpoints of a cross-module interface are required",
            lambda: project_functions([dict(function, ports=function["ports"][:1])]), "FUNCTION_INTERFACE_NOT_MAPPED")
    invalid_flow = {"from": "U1", "to": "U2", "module_ref": "M1", "label": "payload", "kind": "data"}
    rejects("cross-module subunits cannot bypass a global interface",
            lambda: project_functions([dict(function, internal_flows=[invalid_flow])]), "FUNCTION_INTERNAL_FLOW_REQUIRES_SHARED_MODULE")
    child = dict(function, uid="FN-CHILD", parent_ref="FN-TEST",
                 units=[dict(function["units"][0], uid="U3")], ports=[dict(function["ports"][0], unit_ref="U3")])
    check("child can expose a subset of parent module endpoints", project_functions([function, child])[1]["parent_ref"] == "FN-TEST")
    rejects("function parent cycle is invalid",
            lambda: project_functions([function, dict(child, parent_ref="FN-CHILD")]), "INVALID_FUNCTION_PARENT_OR_CYCLE")
    duplicate_path = dict(function["ports"][0], unit_ref="U3")
    branched = dict(function, ports=function["ports"] + [duplicate_path],
                    units=function["units"] + [dict(function["units"][0], uid="U3")])
    rejects("multiple units on one port direction require conditions", lambda: project_functions([branched]),
            "FUNCTION_PORT_FANOUT_NEEDS_CONDITION")
    rejects("unsafe function ID cannot become a diagram filename",
            lambda: project_functions([dict(function, uid="FN-TEST\n")]), "INVALID_FUNCTION_VIEW_UID")
    external = dict(function_model, interfaces=function_model["interfaces"] + [{"uid": "IF2"}],
                    views=[{"kind": "data", "edges": function_model["views"][0]["edges"] +
                            [{"from": "IF2", "to": "M1", "label": "configuration"}]}])
    rejects("cross-function boundary cannot be silently omitted",
            lambda: collect(external, function_summary, function_facts), "FUNCTION_BOUNDARY_NOT_ACCOUNTED")
    exclusion = dict(interface_ref="IF2", module_ref="M1", direction="in", reason="Shared configuration outside this diagram")
    scoped = dict(external, function_views=[dict(function, excluded_ports=[exclusion])])
    check("reviewed boundary can be scoped explicitly", collect(scoped, function_summary, function_facts)[0]["excluded_ports"] == [exclusion])
    empty_flow = dict(function_model, interfaces=[], views=[{"kind": "data", "edges": []}],
                      function_views=[dict(function, units=function["units"][:1], ports=[])])
    rejects("single unit without flow cannot satisfy a function",
            lambda: collect(empty_flow, function_summary, function_facts), "FUNCTION_ALLOCATED_SUPPORT_NOT_ACCOUNTED")
    empty_flow["function_views"][0]["support_refs"] = ["M2"]
    rejects("accounted support still cannot replace a flow", lambda: collect(empty_flow, function_summary, function_facts),
            "FUNCTION_WITHOUT_FLOW")
    special = dict(projected, edges=[dict(projected["edges"][0], label='a[1] → b | "quoted"')])
    source = mermaid(special, {"U1": "Sample", "U2": "Publish", "IF1": "Interface"})
    check("function Mermaid preserves punctuation using inert entities",
          '#91;1#93; #8594; b #124; #34;quoted#34;' in source and 'a[1]' not in source)
    p = {"clock_hz": 100000000, "lanes": 1, "vector": 1, "ii": 2, "efficiency": 0.8,
         "memory_limit_sps": 30000000, "required_sps": 20000000}
    result = a.evaluate_budget(budget("throughput", p))
    check("memory supply limits throughput", result["value"] == 30000000 and result["status"] == "pass")
    rejects("II zero", lambda: a.evaluate_budget(budget("throughput", dict(p, ii=0))))
    rejects("boolean is not numeric", lambda: a.evaluate_budget(budget("throughput", dict(p, lanes=True))))
    rejects("efficiency cannot exceed one", lambda: a.evaluate_budget(budget("throughput", dict(p, efficiency=1.1))))
    rejects("negative rate", lambda: a.evaluate_budget(budget("throughput", dict(p, memory_limit_sps=-1))))
    check("unknown input remains unknown", a.evaluate_budget(budget("throughput", dict(p, memory_limit_sps=None), ["ISS-test"]))["status"] == "unknown")
    rejects("unknown needs tracked issue", lambda: a.evaluate_budget(budget("throughput", dict(p, memory_limit_sps=None))))
    check("latency sums full path", a.evaluate_budget(budget("latency", {"components_s": [0.01, 0.02], "limit_s": 0.02}))["status"] == "fail")
    p = {"initial_bytes": 0, "inflight_bytes": 2048, "margin_bytes": 2048, "capacity_bytes": 32768,
         "windows": [{"duration_s": 0.00002, "arrival_Bps": 800000000, "service_Bps": 0}], "periodic": False}
    check("FIFO includes inflight and margin", a.evaluate_budget(budget("buffer", p))["value"] == 20096)
    check("periodic average deficit is unbounded", a.evaluate_budget(budget("buffer", dict(p, periodic=True)))["status"] == "unbounded")
    windows = p["windows"] + [{"duration_s": 0.00002, "arrival_Bps": 800000000, "service_Bps": 1600000000}]
    check("recovery drains before repeat", a.evaluate_budget(budget("buffer", dict(p, windows=windows, periodic=True)))["status"] == "pass")
    windows2 = [{"duration_s": 1, "arrival_Bps": 5, "service_Bps": 0}, {"duration_s": 1, "arrival_Bps": 0, "service_Bps": 10}, {"duration_s": 1, "arrival_Bps": 5, "service_Bps": 0}]
    p3 = dict(p, inflight_bytes=0, margin_bytes=0, capacity_bytes=10, windows=windows2, periodic=True)
    result = a.evaluate_budget(budget("buffer", p3))
    check("periodic startup occupancy is not average drift", result["status"] == "pass")
    check("periodic peak includes next-cycle boundary", result["value"] == 10)
    p2 = dict(p, initial_bytes=1000, capacity_bytes=21000)
    check("initial occupancy preserved", a.evaluate_budget(budget("buffer", p2))["status"] == "fail")
    with tempfile.TemporaryDirectory(prefix="fpga-arch-test-") as temp:
        root = Path(temp)
        for relative in ("../outside", "/outside", "C:/outside", "a\\b", "a//b"):
            rejects("reject unsafe path " + relative, lambda r=relative: a.safe(root, r))
        (root / "duplicate.json").write_text('{"a":1,"a":2}', encoding="utf-8")
        rejects("duplicate JSON key", lambda: a.load(root / "duplicate.json"))
        (root / "nan.json").write_text('{"a":NaN}', encoding="utf-8")
        rejects("nonfinite JSON", lambda: a.load(root / "nan.json"))
        rejects("do not overwrite output", lambda: _publish(root))
        def failure():
            with a.transaction(root / "failed") as dest:
                raise ValueError("intentional")
        rejects("transaction fails closed", failure)
        check("failed transaction has no committed output", not (root / "failed").exists() and bool(list(root.glob("failed.staging-*/FAILED.json"))))
        check("transaction owns and releases lock", not (root / ".failed.lock").exists())
    schema = a.load(a.SKILL / "references/architecture.schema.json")
    a.contract.audit_schema(schema)
    check("schema audited closed subset", True)
    check("incomplete object rejected by schema", bool(a.contract.validate_schema({"contract": "FPGA-ARCH/1.0.0"}, schema)))
    document_schema = a.load(a.SKILL / "references/documentation.schema.json")
    a.contract.audit_schema(document_schema)
    target = {"part": "part", "board": "board", "ip_baseline": "fixture"}
    for target_schema in (schema["properties"]["target"], document_schema["$defs"]["architecture"]["properties"]["target"]):
        check("legacy Vivado target retained", not a.contract.validate_schema(dict(target, environment="vivado", vivado_version="fixture"), target_schema))
        check("non-Vivado target accepted", not a.contract.validate_schema(dict(target, environment="libero", toolchain_version="fixture"), target_schema))
        check("non-Vivado target needs its own version field", bool(a.contract.validate_schema(dict(target, environment="libero", vivado_version="fixture"), target_schema)))
    import evolution
    stamp = evolution.validate_approval_timestamp("2026-10-20T00:00:00.1234567+08:00")
    check("PowerShell approval timestamp retains timezone", stamp.microsecond == 123456 and stamp.utcoffset().total_seconds() == 28800)
    rejects("approval timestamp without timezone rejected",
            lambda: evolution.validate_approval_timestamp("2026-10-20T00:00:00.1234567"), "APPROVAL_TIMEZONE_REQUIRED")
    with patch.object(a, "verify_attempt", return_value=({}, {"readiness": "blocked", "diagnostic": True}, {})):
        rejects("blocked input cannot generate a proposal", lambda: evolution.validate_plan({}, Path(".")),
                "DIAGNOSTIC_ATTEMPT_CANNOT_GENERATE")
    with patch.object(a, "verify_attempt", return_value=({}, {"readiness": "ready", "diagnostic": True}, {})):
        rejects("explicit diagnostic attempt cannot generate a proposal", lambda: evolution.validate_plan({}, Path(".")),
                "DIAGNOSTIC_ATTEMPT_CANNOT_GENERATE")
    flow = {"interfaces": [{"uid": "IF", "endpoint_refs": ["SOURCE", "SINK"]}],
            "views": [{"kind": "data", "edges": [{"from": "SOURCE", "to": "IF"}, {"from": "IF", "to": "SINK"}]}]}
    check("interface graph connects producer and consumer", not a.interface_flow_gaps(flow))
    flow["views"][0]["edges"][1]["to"] = "UNRELATED"
    check("wrong sink blocks interface graph", a.interface_flow_gaps(flow) == ["IF"])
    flow["views"][0]["edges"].pop()
    check("missing sink blocks interface graph", a.interface_flow_gaps(flow) == ["IF"])
    flow["modules"] = [{"uid": "SINK"}]
    flow["interfaces"][0].update(scope="external", upstream_refs=["source-if"])
    analysis = {"signals": [{"interface_uid": "source-if", "direction": "input"}]}
    flow["views"][0]["edges"].append({"from": "IF", "to": "SINK"})
    check("ICD input flows into FPGA module", not a.interface_flow_gaps(flow, analysis))
    flow["views"][0]["edges"] = [{"from": "SINK", "to": "IF"}, {"from": "IF", "to": "SOURCE"}]
    check("reversed ICD input blocks even with complete graph", a.interface_flow_gaps(flow, analysis) == ["IF"])
    flow["modules"] = [{"uid": "SOURCE"}]
    flow["views"][0]["edges"] = [
        {"from": "SOURCE", "to": "IF"}, {"from": "IF", "to": "SINK"},
        {"from": "SINK", "to": "PEER-A"}, {"from": "SINK", "to": "PEER-B"}]
    analysis = {
        "signals": [{"interface_uid": "source-if", "direction": "output"}],
        "context_entities": [{"header": {"uid": "FPGA"}, "kind": "fpga"}],
        "interfaces": [{"header": {"uid": "source-if"},
                        "endpoint_refs": [{"uid": uid} for uid in ("FPGA", "SINK", "PEER-A", "PEER-B")]}],
    }
    check("ICD peers behind a board selector are reachable", not a.interface_flow_gaps(flow, analysis))
    flow["views"][0]["edges"][-1]["to"] = "UNRELATED"
    check("misrouted board selector branch is detected", a.interface_flow_gaps(flow, analysis) == ["IF"])
    flow["views"][0]["edges"][-1] = {"from": "PEER-B", "to": "SINK"}
    check("reversed board selector branch is detected", a.interface_flow_gaps(flow, analysis) == ["IF"])
    diagram = a.diagram({"node_refs": ["x"], "edges": []}, {"x": '<script>alert("x")</script>\n%%{init:evil}%%'})
    check("diagram labels cannot inject HTML or directives", "<script>" not in diagram and "%%" not in diagram)
    stats = a.statistics({"phase": "G1", "checks": [
        {"rule_id": "M-X-001", "phase": "G1", "applicability": "applicable", "result": "deviation"},
        {"rule_id": "M-X-002", "phase": "G1", "applicability": "not_applicable", "result": "not_applicable"},
        {"rule_id": "M-X-003", "phase": "G2", "applicability": "applicable", "result": "planned"}]})
    check("deviation not pass, future and NA excluded", stats["due_instances"] == 1 and stats["pass_ratio"] == 0 and stats["planned"] == 1)
    # These records exercise only the review mechanics, without publishing a real package.
    model = {"phase": "G1", "modules": [{"uid": "M", "clock_refs": ["C"], "reset_refs": ["R"], "contracts": {"a": "defined"}}],
             "verification_obligations": [{"criterion": "fixture", "method": "inspection", "preconditions": "unit test", "object_refs": ["M"]}],
             "budgets": [budget("throughput", {"clock_hz": 1, "lanes": 1, "vector": 1, "ii": 1, "efficiency": 1, "memory_limit_sps": 1, "required_sps": 1})],
             "author": "author", "narratives": {"report": "defined"},
             "target": dict(target, environment="libero", toolchain_version="fixture"),
             "document_sections": [{"report_id": "RPT-" + str(i).zfill(2)} for i in a.REPORTS],
             "interfaces": [], "clocks": [{"uid": "C", "frequency": {"value": 1}, "contract": "defined"}],
             "resets": [{"uid": "R", "contract": "defined"}], "cdcs": [], "allocations": [], "issues": [], "deviations": [], "checks": [],
             "evidence": [{"uid": "E", "level": "review"}],
             "views": [{"kind": k, "node_refs": ["M", "C", "R"]} for k in ("functional", "data", "clock_reset", "physical")]}
    summary = {"readiness": "ready", "diagnostic": False, "synthetic": False}
    facts = {"model": {"analysis": {"interfaces": []}}}
    review = {"kind": "approve_architecture_freeze", "package_sha256": "0" * 64, "conclusion": "通过", "actor": "unit-test actor",
              "user_quote": "synthetic fixture", "confirmed_at": "2026-10-20T00:00:00+08:00", "allowed_scope": "unit test",
              "reviewer": "reviewer", "evidence_refs": ["E"], "participants": [{"role": role, "name": role, "reviewed_at": "2026-10-20"} for role in ("architecture", "design", "verification")]}
    a.validate_review(review, model, summary, facts, "0" * 64)
    check("bound complete review mechanics accepted", True)
    rejects("stale freeze authorization", lambda: a.validate_review(review, model, summary, facts, "1" * 64))
    rejects("author cannot be sole reviewer", lambda: a.validate_review(dict(review, reviewer="author"), model, summary, facts, "0" * 64))
    rejects("missing role cannot approve", lambda: a.validate_review(dict(review, participants=review["participants"][:2]), model, summary, facts, "0" * 64))
    rejects("review evidence cannot be omitted", lambda: a.validate_review(dict(review, evidence_refs=[]), model, summary, facts, "0" * 64))
    rejects("synthetic project cannot freeze", lambda: a.validate_review(review, model, dict(summary, synthetic=True), facts, "0" * 64))
    return {"passed": len(passed), "tests": passed, "scope": "deterministic invariants only; not hardware or engineering sign-off"}


def _publish(root):
    with a.transaction(root):
        pass
