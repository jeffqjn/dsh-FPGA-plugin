---
name: fpga-git
description: 在 Windows 7 离线电脑上使用本地 Git 仓库管理 FPGA 开发过程，处理建库、RTL 与约束变更、提交、分支、合并、回退和本地里程碑。适用于工程师自行管理代码；不包含远端同步或发布。
---

# FPGA 项目 Git 管理

使用本机 `git` 和仓库已有工具完成用户要求。部署基线固定为 **Windows 7、PowerShell 2.0、Python 3.8.10、Git 2.17.0.windows.1**；不要求升级或安装额外 Python 包。日常 Git 操作不依赖 Python。提交只写入当前电脑上项目目录的 `.git` 仓库；本 skill 不配置远端，不执行 `fetch`、`pull`、`push`，也不处理发布或跨电脑传输。优先遵守仓库中的 `AGENTS.md` 和项目约定。Git 历史在同一台电脑上，不等于异地备份。

## 兼容性

- 首次运行 `git --version`、`$PSVersionTable.PSVersion` 和 `python --version` 核对基线。使用 `git checkout`、`git reset HEAD --`；不使用 `switch`、`restore`、`init -b`、`branch --show-current` 或 `stash push --staged` 等后续版本功能。
- PowerShell 命令逐条执行；每次 Git/Python 调用后立即检查 `$LASTEXITCODE`，失败后不要继续依赖该结果的操作。不要使用 `&&`、`||`、`--%`、`$PSScriptRoot`、`Get-Content -Raw` 或新版 cmdlet。带空格的路径加引号；程序路径加引号时用调用运算符 `&`。`stash@{0}` 和 `HEAD^` 等修订表达式用单引号。
- 自动化读取状态用 `git status --porcelain -z`，保留原始字节并按 NUL 分隔；Git 输出的路径按 UTF-8 解码。不要用 PowerShell 管道或 `>` 保存机器格式输出，也不要用它们生成 `.gitignore`（旧版重定向可能写成 UTF-16）。编码、路径、退出码和部署方法见 [Windows 7 运行约束](references/windows7-compat.md)。
- 随附可选只读工具：`python "<skill目录>\scripts\repo_check.py" doctor --repo "<项目目录>"`；严格验收加 `--strict-target`，提交前改用 `audit`。Git 不在 PATH 时用 `--git "<git.exe完整路径>"`。退出码 **0** 表示检查通过，**1** 表示需要审查（无暂存文件、冲突、空白或风险提示），**2** 表示环境、参数或 Git 执行错误。0 不代表 HDL 或硬件验证通过，也不代替差异审查。脚本不修改仓库；Python 不可用时按 Git 命令人工检查。

## 每次操作的起点

1. 确认工作目录与仓库根目录：`git rev-parse --show-toplevel`。若用户要求管理现有 FPGA 项目而它尚未建库，在项目目录执行 `git init`；不要在无关的父目录建库。
2. 查看 `git status --short --branch`、当前分支、相关文件差异和未跟踪文件。识别用户已有的未提交修改，不覆盖它们。
3. 确认本次目标、影响的文件、分支与基线。按目标选择最小的 Git 操作，避免把无关文件纳入提交。
4. 操作后复查 `git status --short --branch`；产生提交时核对 `git show --stat --oneline HEAD`，合并时核对冲突和最终历史。向用户报告提交 ID、分支、验证结果与未完成事项。

首次建库、日常提交、分支、回退的具体步骤见 [本地操作流程](references/local-workflows.md)。常用命令查阅 [Git 操作速查](references/git-operations.md)；判断 FPGA 文件取舍与本地版本记录时查阅 [FPGA 仓库约定](references/fpga-workflow.md)。

## 对仓库的处理原则

- 提交能够重建工程的输入：RTL、Testbench、约束、IP 配置、构建脚本、依赖版本说明。EDA 工具生成的缓存和临时输出通常忽略；工程描述文件和 IP 元数据按项目实际构建方式判断，不能仅凭扩展名删除或忽略。
- 查看 `.gitignore` 与 `git status --ignored` 后再调整忽略规则。某文件已被跟踪时，新增忽略规则不会使它自动退出版本控制。
- 提交前检查 `git ls-files -u`（有输出表示冲突未解决）、`git diff --check`、`git diff --cached --check`、`git diff --cached --stat` 和 `git diff --cached`。`git diff` 不显示未跟踪文件，因此同时检查 `git status`。用明确路径暂存；确认无关缓存、凭据、许可证文件及大体积构建输出没有进入暂存区。
- 可运行只读 `repo_check.py audit` 辅助识别暂存的大文件、常见生成产物和许可证/密钥文件。脚本的提示需要结合工程判断，不能自动丢弃文件或替代对差异的人工审查。
- 尽量使一次提交对应一项可解释的变更；提交信息描述模块和意图，例如 `rtl(uart): 修正接收超时状态转换`。不把仿真、综合或时序验证说成已通过，除非实际运行并记录结果。
- 对硬件相关变更注明板卡、器件型号、工具版本、时钟及约束变化。重要的本地检查点可用注释标签标记，同时记录实际验证情况。
- 对用户未明确要求的破坏性动作保持克制。`reset --hard`、`clean -fdx`、删除分支或标签、丢弃现有改动，必须先确认目标及可恢复方案。解决冲突时保留两方意图，不能机械地全选一侧。
- 不自行修改全局 Git 配置、凭据、钩子或仓库权限。若操作失败，解释本地状态和所需权限。

## 常见工作流

- **初次建库**：在 FPGA 项目根目录执行 `git init`，检查需要跟踪的工程输入和 `.gitignore`，配置本仓库提交身份，审查暂存内容后建立首次提交。
- **日常开发**：检查现有修改；根据工作复杂度决定直接提交或新建功能分支；修改后运行可用的仿真、lint 或构建；审查差异并提交到本地仓库。
- **合并与冲突**：先检查两侧提交及冲突文件。RTL、约束和 Tcl 的冲突需要逐项理解逻辑；解决后运行相关验证，确认无冲突标记，再提交或继续合并流程。
- **定位回归**：比较已知好坏提交；需要时使用 `git bisect` 配合可重复的仿真或综合检查。只在干净工作区开始，完成后 `git bisect reset`。
- **本地里程碑**：功能阶段完成后确认源码、约束、IP 与验证记录；必要时建立注释标签，并核对标签指向的提交。

若用户只需要说明或命令清单，给出可复制的命令、作用及风险，无须实际更改仓库。

## 部署与回归验证

将整个 `fpga-git` 文件夹复制到目标环境已有的 skill 目录，保留相对路径。可选检查器和回归测试只用 Python 3.8 标准库。首次部署或修改后按 [兼容与验收说明](references/windows7-compat.md) 执行 `tests/run_tests.ps1 -StrictTarget`。测试只操作自行创建的临时仓库，不在实际 FPGA 工程里测试回退。交付测试范围和现场待验证项见 [测试报告](references/test-report.md)。
