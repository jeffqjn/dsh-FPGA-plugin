# Git 操作速查

以下命令在当前电脑的 FPGA 项目目录执行。`<...>` 是要替换的占位符。固定面向 Windows 7 / PowerShell 2.0 / Git 2.17.0.windows.1，避免使用后续版本子命令和选项。命令逐条执行，并立即检查 `$LASTEXITCODE`；出现错误先停止后续依赖操作。路径有空格时写成 `"<路径>"`；所有提交、分支和标签都保存在项目的 `.git` 仓库内。

## 建库与配置

| 目的 | 命令 | 要点 |
| --- | --- | --- |
| 查看 Git 版本 | `git --version` | 排查命令兼容性。 |
| 初始化仓库 | `git init` | 只在项目根目录执行；随后建立 `.gitignore`。 |
| 查看仓库根目录 | `git rev-parse --show-toplevel` | 避免在错误目录操作。 |
| 查看跟踪文件 | `git ls-files` | 与工作区中的未跟踪文件区分。 |
| 检查忽略原因 | `git check-ignore -v -- <路径>` | 确认 `.gitignore` 规则为何命中；退出码 1 表示没有命中。 |
| 查看本仓库提交身份 | `git config --local user.name`、`git config --local user.email` | 首次提交前检查。 |
| 仅为本仓库设置身份 | `git config --local user.name "<姓名>"`、`git config --local user.email "<邮箱>"` | 不更改全局配置。 |

## 检查与比较

| 目的 | 命令 | 要点 |
| --- | --- | --- |
| 查看状态 | `git status --short --branch` | 先看工作区和分支。 |
| 读取稳定格式的状态 | `git status --porcelain -z` | 程序按 NUL 分隔、UTF-8 解码；不用 PowerShell 文本管道保存机器格式输出。 |
| 查看最近历史 | `git log --oneline --decorate -n 20` | 可加 `--graph --all` 看分叉。 |
| 查看提交 | `git show --stat <提交>`、`git show <提交> -- <路径>` | 核对内容与影响范围。 |
| 查看未暂存差异 | `git diff -- <路径>` | 省略路径查看全部。 |
| 查看已暂存差异 | `git diff --cached -- <路径>` | 提交前重点检查。 |
| 比较分支 | `git diff --stat <基线>..<目标>` | 先看范围再看详细内容。 |
| 检查空白问题 | `git diff --check`、`git diff --cached --check` | 无输出通常表示未发现问题。 |
| 追溯文件历史 | `git log --follow -- <路径>`、`git blame <路径>` | 定位引入变更的提交。 |
| 查找变更内容 | `git log -S'<文本>' -- <路径>` | 找文本增删的提交。 |

## 暂存与提交

| 目的 | 命令 | 要点 |
| --- | --- | --- |
| 暂存指定文件 | `git add -- <路径>` | 避免顺手提交无关生成文件。 |
| 交互暂存 | `git add -p -- <路径>` | 拆分混合改动；Git 2.17 需要完整发行版自带的 Perl，MinGit 不支持时改为明确文件暂存。 |
| 撤销暂存 | `git reset HEAD -- <路径>` | 保留工作区修改；首次提交前没有 `HEAD`，改用 `git rm --cached -- <路径>` 并确认文件仍在工作区。 |
| 创建提交 | `git commit -m "<模块: 意图>"` | 先审查已暂存差异。 |
| 修正最近一次提交 | `git commit --amend` | 会改变提交 ID；先确认没有误覆盖需要保留的本地检查点。 |

## 分支、合并与补丁

| 目的 | 命令 | 要点 |
| --- | --- | --- |
| 列出本地分支 | `git branch -v` | 星号表示当前分支。 |
| 新建并切换分支 | `git checkout -b <分支名>` | 从当前提交开始；首次提交后再建功能分支。 |
| 切换已有分支 | `git checkout <分支名>` | 有未提交修改时先检查是否可安全切换。 |
| 合并分支 | `git merge <分支名>` | 在接收变更的分支执行。 |
| 变基 | `git rebase <基线分支>` | 改写当前分支提交 ID；已有本地检查点或标签时先核对影响。 |
| 挑选提交 | `git cherry-pick <提交>` | 把单个修复带入另一条本地分支。 |
| 撤销已提交变更 | `git revert <提交>` | 新增反向提交，保留变更记录。 |
| 查看冲突状态 | `git status` | 解决后 `git add`；合并用 `git commit` 完成，变基用 `git rebase --continue`。 |
| 检查未解决冲突 | `git ls-files -u` | 有输出即存在未合并索引，不能认为暂存区可提交。 |
| 退出合并/变基 | `git merge --abort`、`git rebase --abort` | 仅在对应流程进行中使用。 |

## 临时保存、恢复与排错

| 目的 | 命令 | 要点 |
| --- | --- | --- |
| 临时保存已跟踪及未跟踪修改 | `git stash save -u "<说明>"` | 兼容较旧 Git；先确认是否包含大文件或敏感文件。 |
| 查看临时保存 | `git stash list`、`git stash show -p 'stash@{0}'` | PowerShell 2.0 中必须给 stash 引用加引号。 |
| 取回临时保存 | `git stash apply 'stash@{0}'` | 确认无误后再 `git stash drop`；`pop` 会同时删除记录。 |
| 恢复单个文件 | `git checkout -- <路径>` | 用暂存区版本覆盖工作区文件，会丢弃未暂存修改；先确认无需保留。 |
| 找回提交指针 | `git reflog` | 排查误切换、误变基或误重置。 |
| 定位回归 | `git bisect start`、`git bisect bad`、`git bisect good <已知好提交>` | 每轮验证后标记 `good`/`bad`，最后 `git bisect reset`。 |
| 清理未跟踪文件预览 | `git clean -nd` | `git clean -fd` 会删除文件，执行前确认。 |
| 重置预览 | `git diff <目标提交>`、`git status` | `git reset --hard` 会丢弃修改，不作为常规同步手段。 |

## 本地里程碑

| 目的 | 命令 | 要点 |
| --- | --- | --- |
| 查看标签 | `git tag --list`、`git show <标签>` | 找到某次本地里程碑。 |
| 标记本地里程碑 | `git tag -a <名称> -m "<说明>"` | 标签指向当前提交，记录阶段成果。 |

## 最简日常顺序

1. `git status --short --branch`：确认当前分支与未提交文件。
2. 修改 RTL、约束或测试；运行可用的相关验证。
3. `git diff --check`、`git diff`：查看实际改动。
4. `git add -- <本次文件>`，再用 `git diff --cached --stat` 与 `git diff --cached` 检查暂存内容。
5. `git commit -m "<模块: 意图>"`，最后用 `git status --short --branch` 核对结果。

硬重置、删除分支/标签、清理未跟踪文件会使本地记录或文件丢失，执行前确认。Git 提交只保存在当前电脑，不构成另一台设备上的备份。
