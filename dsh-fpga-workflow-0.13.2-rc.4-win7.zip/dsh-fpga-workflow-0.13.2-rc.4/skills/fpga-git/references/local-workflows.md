# FPGA 项目的本地 Git 流程

以下步骤针对单台 Windows 7 / PowerShell 2.0 / Git 2.17.0.windows.1 电脑，不使用远端。命令在项目根目录逐条执行；每次外部命令后检查 `$LASTEXITCODE`，失败时先处理再继续。带空格的路径用引号括起来；对路径参数使用 `--`。Agent 应先看实际状态，再执行与用户目标对应的操作。创建 `.gitignore` 时显式使用 UTF-8 无 BOM，不用 PowerShell 默认重定向。

## 第一次纳入 Git

1. 进入 FPGA 项目目录，运行 `git rev-parse --show-toplevel`。如果已是仓库，沿用它，不要再次初始化。
2. 若尚未建库且工程师要求纳入版本控制，运行 `git init`。先检查 `git status --short` 和文件结构，按 [FPGA 仓库约定](fpga-workflow.md) 决定哪些输入需要跟踪。
3. 建立或修订 `.gitignore`，只排除已确认可再生成的缓存、波形及构建目录。运行 `git status --ignored --short` 检查有没有误排除的源文件、约束或 IP 配置。
4. 运行 `git config --local user.name` 与 `git config --local user.email`。缺少提交身份时向工程师取得值，再用 `git config --local user.name "<姓名>"` 和 `git config --local user.email "<邮箱>"` 设置；不要编造身份或修改全局配置。
5. 用 `git add -- <明确路径>` 暂存第一批输入。运行 `git diff --cached --stat`、`git diff --cached`；可用 `repo_check.py audit` 检查暂存区。确认后执行 `git commit -m "init: 建立FPGA工程基线"`。
6. 运行 `git status --short --branch`、`git log -1 --oneline` 核对结果。默认分支名可能是 `master`，不要假定为 `main`。

## 每次日常提交

1. `git status --short --branch`：确认分支、已有修改和未跟踪文件。
2. 完成一个功能或修复后，运行工程已有的相关仿真、lint、综合或时序检查；工具不可用时记录未运行。
3. `git diff --check`、`git diff -- <相关路径>`：检查未暂存改动。对未跟踪的新文件直接查看文件内容，因为 `git diff` 不显示它们。
4. `git add -- <本次文件>`；然后检查 `git ls-files -u`、`git diff --cached --check`、`git diff --cached --stat` 和 `git diff --cached`。`ls-files -u` 必须无输出；可运行 `repo_check.py audit`，退出码 1 的提示需逐项审查。发现混入文件时，已有 `HEAD` 的仓库用 `git reset HEAD -- <路径>` 取消暂存；首次提交前用 `git rm --cached -- <路径>`，并确认工作区文件还在。
5. 用描述意图的消息执行 `git commit -m "<模块: 修改意图>"`。最后核对 `git status --short --branch` 与 `git log -1 --oneline`。向工程师报告提交 ID 与实际验证结果。

## 功能分支与合并

功能较大、需要尝试不同方案或希望保留稳定状态时，用 `git checkout -b <分支名>` 建本地分支。分支开发期间照常小步提交。合并前确认工作区状态，切回接收分支 `git checkout <接收分支>`，审查双方历史，再执行 `git merge <功能分支>`。

发生冲突时逐文件理解 RTL、约束、脚本及 IP 配置的两侧意图。解决后运行相关验证，用 `git add -- <冲突文件>` 标记已解决；普通合并用 `git commit` 完成。不能只删除冲突标记就假定逻辑正确。需要放弃本次合并时用 `git merge --abort`，先确认它不会影响本次合并开始后的额外工作。

## 回退与找回

| 情况 | 操作 | 边界 |
| --- | --- | --- |
| 误暂存文件 | `git reset HEAD -- <路径>` | 保留工作区文件；首次提交前改用 `git rm --cached -- <路径>`。 |
| 未暂存修改需要丢弃 | `git checkout -- <路径>` | 会覆盖该文件的未暂存内容，须由工程师明确要求。 |
| 已提交变更需要撤销 | `git revert <提交>` | 产生新提交，保留原历史。 |
| 错误移动了分支指针 | `git reflog` | 先定位原提交，再决定恢复方法。 |

不要把 `git reset --hard` 或 `git clean -fdx` 作为普通回退步骤。

## 本地阶段标记

当某个版本经过所需的仿真或上板验证，可以用 `git tag -a <里程碑名> -m "<板卡和验证摘要>"` 标记当前提交。运行 `git show <里程碑名>` 核对指向。标签仅存在本机；未实际运行的验证不能写成已通过。
