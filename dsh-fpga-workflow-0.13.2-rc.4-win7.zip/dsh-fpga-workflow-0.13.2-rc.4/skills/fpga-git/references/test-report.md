# 适配与测试报告

交付日期：2026-10-26。部署目标：Windows 7 / PowerShell 2.0 / CPython 3.8.10 / Git 2.17.0.windows.1。

## 验证结论与范围

**最终自动回归全部通过；Win7 + PowerShell 2.0 真机验收尚未执行。** 当前测试主机内核为 Windows 10.0.26200，Shell 为 Windows PowerShell 5.1.26100.9711。实际运行了官方 Python 3.8.10 与 Git 2.17.0.windows.1 的 x64 和 x86 版本；没有用新版 Python/Git 替代目标版本。现代主机的结果不能证明旧系统的系统 DLL、控制台、权限、执行策略和 PS2 引擎行为。

| 最终测试组合 | Python 回归 | PowerShell 命令冒烟 | 失败/错误/跳过 | 原始结果 |
| --- | --- | --- | --- | --- |
| Python 3.8.10 x64 + Git 2.17.0 x64 | 54/54 | 5/5（PS 5.1） | 0/0/0 | [x64 JSON](test-results/x64.json) |
| Python 3.8.10 x86 + Git 2.17.0 x86 | 54/54 | 5/5（PS 5.1） | 0/0/0 | [x86 JSON](test-results/x86.json) |
| Windows 7 + PowerShell 2.0 | 待现场执行 | 待现场执行 | 未执行 | 使用严格验收入口 |

每组 54 项包含 43 项临时仓库集成测试及 11 项单元/结构测试；两个组合重复覆盖同一套用例。JSON 记录逐项结果、运行时、执行时间、源脚本 SHA-256。通过结果不包含 FPGA 仿真、综合、时序或上板验证。

## 已完成的适配与修复

- 文档和工作流固定为目标版本；移除较新 Git 基线，说明 PS2 的调用、退出码、修订引用、编码和离线解压方式。
- Git 路径按 UTF-8 解码，支持中文、空格及特殊路径；旧控制台不能显示的字符转义输出。
- 审计从索引对象读取大小；修复仅删除提交误报、未解决冲突漏检、对象读取失败被忽略，以及 Git 2.17 的 intent-to-add 被当作可提交文件。
- 大文件、生成产物、密钥/许可证和子模块提示返回审查状态；保留仓库原有换行与空白规则，不自动改全局配置。
- 加入严格目标环境检查及离线测试入口。脚本只依赖 Python 3.8 标准库；PowerShell 入口使用 PS2 语法及 .NET 2.0 可用 API，源码为 ASCII。

## 测试覆盖

- 检查器：未建库目录/裸仓库/空仓库/首次暂存/干净仓库/未跟踪文件/intent-to-add/修改/删除/重命名/嵌套目录；中文和特殊路径；阈值及边界；暂存与工作区大小不同；CRLF 策略；生成目录、敏感文件、子模块；未合并索引；对象损坏；无效 Git/目录/参数；版本解析；严格目标接受与拒绝；关闭外部 diff/textconv；ASCII 控制台；成功与审查场景前后仓库全部文件哈希不变。
- Git 工作流：初始化与本地身份配置、首次与后续取消暂存、提交与 amend、真实交互分块暂存、分支合并、冲突解决及中止、stash 保存/查看/恢复/删除、revert、reflog、cherry-pick、rebase 成功/冲突继续/中止、bisect/reset、忽略规则、历史查询、恢复文件、clean 只预览、注释标签及目标提交核对。
- PowerShell 冒烟：中文/空格参数与首次提交、stash 引用、取消暂存与恢复、注释标签的修订表达式、仅删除提交审计。
- skill 官方结构校验器通过；Python 3.8 实际执行及语法检查通过；相对 Markdown 链接和交付 ZIP 字节回读验证通过。
- 严格验收入口在本机被实测为拒绝 PowerShell 5.1，未把 `-Version 2.0` 回落行为当成 PS2 测试；单元测试中的目标接受分支使用模拟环境，不是真机证据。

## 测试运行时来源与完整性

[Git 官方 2.17.0 发布页](https://github.com/git-for-windows/git/releases/tag/v2.17.0.windows.1) 的校验值与下载结果一致：

| 资产 | 官方及实测 SHA-256 |
| --- | --- |
| PortableGit-2.17.0-64-bit.7z.exe | `9625365ccb67d1c7c52f14824c5dd68af4cca2a1b83a2ba998ba9ba45b708551` |
| Git-2.17.0-32-bit.tar.bz2 | `d589200952debd3848602ee1287075428c096a8d94776090641645a858d020ec` |

x86 tar 分发中 `/dev/*` 与 `/etc/mtab` 的 Unix 系统符号链接未部署到 Windows 测试目录；其余运行文件来自该官方压缩包。x64 使用官方便携包。完整 Git 的交互暂存依赖其自带 Perl，MinGit 不作为完整验收基线。

[Python 官方 3.8.10 发布页](https://www.python.org/downloads/release/python-3810/) 所列两个嵌入式 ZIP 的 MD5 均核对一致；x64 `python.exe` 的 Python Software Foundation Authenticode 签名状态为 Valid。运行时仅用于开发机隔离测试，不附带到 skill，不修改系统安装。

## 现场验收

按 [兼容与验收说明](windows7-compat.md) 在目标 Win7 / PS2 中执行 `tests/run_tests.ps1 -StrictTarget`，并检查退出码和输出报告。该入口使用现场已有的 Python/Git，不联网。目标机最终验收通过之前，交付状态为“适配完成、自动回归通过、真机验收待完成”。
