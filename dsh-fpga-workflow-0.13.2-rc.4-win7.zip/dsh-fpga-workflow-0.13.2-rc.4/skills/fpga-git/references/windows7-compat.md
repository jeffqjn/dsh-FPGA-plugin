# Windows 7 兼容与验收

## 固定部署基线

| 组件 | 目标 |
| --- | --- |
| 操作系统 | Windows 7；Python 所需的 Service Pack、VC 运行库和系统补丁由现场已有环境提供 |
| Shell | Windows PowerShell 2.0 |
| Python | CPython 3.8.10；仅标准库，无 pip 依赖 |
| Git | 完整 Git for Windows 2.17.0.windows.1 |
| 架构 | 32 位系统使用 x86 程序；64 位系统可使用对应 x64 程序 |

这是固定部署约束，不因其他版本也支持 Win7 而更换基线。开发机新版环境通过不能代替目标机验收。测试运行时来源：[Git 官方 2.17.0 发布页](https://github.com/git-for-windows/git/releases/tag/v2.17.0.windows.1)、[Python 官方 3.8.10 发布页](https://www.python.org/downloads/release/python-3810/)。离线部署不需要联网。

## PowerShell 2.0 命令与编码

先 `Set-Location -LiteralPath 'D:\FPGA Project'`，在工程根目录执行 Git 操作。`<...>` 是需要替换的占位符。不假定默认分支名为 `main`，用 `git branch` 或 `git symbolic-ref --short HEAD` 查看。

```powershell
git --version
if ($LASTEXITCODE -ne 0) { throw 'Git unavailable' }
$PSVersionTable.PSVersion
python --version
if ($LASTEXITCODE -ne 0) { throw 'Python unavailable' }
```

- 外部命令失败不会自动触发 PowerShell 异常。每次调用后立即检查 `$LASTEXITCODE`；`$ErrorActionPreference = 'Stop'` 不能代替它。
- 不使用 `&&` / `||`、`--%`、`$PSScriptRoot`、`[ordered]`、`::new()`、`Get-Content -Raw`、`ConvertTo-Json`、`Get-FileHash`、`Compress-Archive`、`Expand-Archive` 或 `ForEach-Object -Parallel`。脚本路径从 `$MyInvocation.MyCommand.Path` 得到。
- 程序路径带空格时使用 `& 'C:\Program Files\Git\cmd\git.exe' status --short --branch`。不要把完整命令拼成一个字符串，也不要使用 `Invoke-Expression`。
- 文件路径使用 `git add -- 'rtl\uart rx.v'`；Git 子命令支持路径分隔符时添加 `--`，不要把它随意加在分支名或提交 ID 前面。修订引用用单引号，例如 `git stash apply 'stash@{0}'`、`git show 'HEAD^'`、`git rev-parse 'milestone^{}'`。
- `git status --porcelain -z`、`git diff --cached --name-only -z`、`git ls-files --stage -z` 输出按 NUL 分隔并按 UTF-8 解码；不能按空格拆路径，也不能用系统 ANSI 编码解码 Git 路径。
- 不用 `>`、`>>` 或默认 `Out-File` 写 `.gitignore`、RTL、补丁或机器格式 Git 输出；旧版重定向会改变文件编码。已有源文件保留原编码和换行。新建 UTF-8 无 BOM 文件可用 Python 的 `open(path, 'w', encoding='utf-8', newline='\n')`；PowerShell 可用 `[System.IO.File]::WriteAllText` 并显式提供 `New-Object System.Text.UTF8Encoding`。
- 随附 `.ps1` 为纯 ASCII，避免 PowerShell 2.0 将无 BOM 中文脚本当 ANSI。若添加中文 `.ps1`，保存为 UTF-8 BOM；Markdown 和 Python 为 UTF-8。参考 [Microsoft 编码说明](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_character_encoding?view=powershell-5.1)。
- 中文控制台无法显示某字符时，检查器会转义该字符而不崩溃；转义输出只用于阅读，不要复制成路径。使用较短工程路径，不自动更改全局编码、`core.longpaths` 或系统策略。

## 只读检查器

```powershell
python 'D:\skills\fpga-git\scripts\repo_check.py' doctor --repo 'D:\FPGA Project' --strict-target
if ($LASTEXITCODE -ne 0) { throw 'Deployment environment mismatch' }
python 'D:\skills\fpga-git\scripts\repo_check.py' audit --repo 'D:\FPGA Project'
$auditCode = $LASTEXITCODE
```

`--repo` 可为根目录或子目录；`doctor` 只要求目录存在，`audit` 要求工作区仓库。两者支持 `--git 'C:\Program Files\Git\cmd\git.exe'`。`audit --large-mib 10` 设置大文件提示阈值，必须为正整数；超过阈值才提示。

| 退出码 | 意义 |
| --- | --- |
| 0 | 环境检查通过，或暂存区无所检查到的问题；仍须审查差异 |
| 1 | 无暂存文件、未解决冲突、空白错误，或大文件/生成产物/许可证/密钥/子模块需要审查 |
| 2 | 目录/参数错误、Git 不可用或过旧、索引对象读取失败，或严格环境不匹配 |

`doctor` 默认输出实际 OS、Python、Git，允许在开发机诊断；`--strict-target` 才要求四组件精确匹配。PowerShell 版本通过默认 `powershell.exe -NoProfile` 检查，不尝试启用旧版引擎。`powershell.exe -Version 2.0` 若回落到新版，不能当作 PS2 测试。

审计读取索引对象大小，支持仅删除提交并拦截未合并索引；不暂存、不提交、不联网、不自动删除文件。扩展名只是提示规则，不是密钥扫描器，也不验证 HDL。禁用 Git 可选锁及外部 diff/textconv；仍应只检查可信本地仓库配置。CRLF 是否构成空白错误由仓库原有 Git 配置决定，不为消除提示自动修改该配置。

## 离线部署与全量复跑

使用 Windows 资源管理器解压交付 ZIP，将整个 `fpga-git` 文件夹复制到目标工具已有 skill 目录，保留结构。不依赖 `Expand-Archive`、pip 或联网安装。不更改全局 Git 配置或执行策略。

在 PowerShell 2.0 中运行（路径按现场修改）：

```powershell
& 'D:\skills\fpga-git\tests\run_tests.ps1' -PythonExe 'C:\Python38\python.exe' -GitExe 'C:\Program Files\Git\cmd\git.exe' -StrictTarget -ReportPath 'D:\fpga-git-target-test.json'
if ($LASTEXITCODE -ne 0) { throw 'Acceptance failed; inspect test output' }
```

执行策略禁止 `.ps1` 时按现场既有策略处理，不自行永久改策略。仍可单独运行 Python 回归，但不覆盖 PowerShell 脚本验收：

```powershell
python 'D:\skills\fpga-git\tests\run_tests.py' --git 'C:\Program Files\Git\cmd\git.exe' --report 'D:\fpga-git-python-test.json'
if ($LASTEXITCODE -ne 0) { throw 'Regression failed' }
```

PowerShell 入口先核对严格目标环境，再在唯一临时目录执行命令冒烟测试，之后执行完整 Python 回归。覆盖检查器正常/异常路径及文档主要本地 Git 工作流；所有写入和回退均在测试自行创建的临时仓库中，结束后清理。JSON 报告保存到指定位置。报告包含跳过项；出现跳过项不能声称覆盖相应功能。

Git 2.17 的 `add -p` 依赖完整发行版的 Perl；精简 MinGit 缺少它。若现场只有 MinGit，不使用交互暂存，改为明确文件暂存或由工程师拆分改动。完整基线回归应在完整 Git 上执行。
