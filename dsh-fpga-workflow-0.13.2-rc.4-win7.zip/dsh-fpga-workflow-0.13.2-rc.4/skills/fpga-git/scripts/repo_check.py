#!/usr/bin/env python3
"""Read-only checks for a local FPGA Git repository (Python 3.8 compatible)."""

import argparse
import os
import platform
import re
import subprocess
import sys


TARGET_GIT = "git version 2.17.0.windows.1"
MIN_GIT = (2, 17, 0)
DEFAULT_LARGE_MIB = 10
BUILD_SUFFIXES = (".bit", ".bin", ".mcs", ".sof", ".pof", ".vcd", ".wlf", ".jou")
BUILD_DIRS = (".xil", "db", "incremental_db", "output_files")
SECRET_SUFFIXES = (".lic", ".pem", ".pfx", ".p12", ".key")
SECRET_NAMES = ("id_rsa", "id_ed25519", ".env")


def display(value):
    """Print through old Windows code pages without crashing on file names."""
    encoding = sys.stdout.encoding or "utf-8"
    # Escape control characters in file names instead of injecting terminal lines.
    value = "".join(char if char >= " " or char == "\n" else repr(char)[1:-1]
                    for char in value)
    sys.stdout.write(value.encode(encoding, "backslashreplace").decode(encoding) + "\n")


def git(repo, *args, executable="git"):
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    try:
        return subprocess.run(
            [executable] + list(args),
            cwd=repo,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            env=env,
        )
    except OSError as exc:
        display("ERROR: Cannot run Git: {}".format(exc))
        raise SystemExit(2)


def decode(data):
    return data.decode("utf-8", "replace").strip()


def git_version(repo, executable="git"):
    result = git(repo, "--version", executable=executable)
    if result.returncode:
        display("ERROR: {}".format(decode(result.stderr)))
        raise SystemExit(2)
    label = decode(result.stdout)
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", label)
    if not match:
        display("ERROR: Cannot parse Git version: {}".format(label))
        raise SystemExit(2)
    return label, tuple(int(match.group(i)) for i in (1, 2, 3))


def is_windows_7():
    if sys.platform != "win32":
        return False
    version = sys.getwindowsversion()
    return version.major == 6 and version.minor == 1


def git_path(data):
    # Git for Windows emits UTF-8 paths even when Python's filesystem codec is mbcs.
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        display("ERROR: Git returned a path that is not UTF-8; inspect it manually.")
        raise SystemExit(2)


def checked(repo, *args, executable="git"):
    result = git(repo, *args, executable=executable)
    if result.returncode:
        display("ERROR: Git command failed: {}".format(decode(result.stderr)))
        raise SystemExit(2)
    return result.stdout


def repository_root(repo, executable="git"):
    result = git(repo, "rev-parse", "--show-toplevel", executable=executable)
    if result.returncode:
        display("ERROR: Not a Git repository: {}".format(decode(result.stderr)))
        raise SystemExit(2)
    return git_path(result.stdout.rstrip(b"\r\n"))


def doctor(repo, executable="git", strict_target=False):
    label, version = git_version(repo, executable)
    display("OS: {}".format(platform.platform()))
    display("Python: {}".format(platform.python_version()))
    display("Git: {}".format(label))
    if version < MIN_GIT:
        display("ERROR: This skill requires Git 2.17.0 or later.")
        return 2
    if strict_target:
        try:
            ps = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                 "$PSVersionTable.PSVersion.ToString()"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            ps_ok = ps.returncode == 0 and ps.stdout.strip() == b"2.0"
            display("PowerShell: {}".format(decode(ps.stdout)))
        except OSError as exc:
            ps_ok = False
            display("PowerShell: unavailable ({})".format(exc))
        if not (is_windows_7() and sys.version_info[:3] == (3, 8, 10)
                and label == TARGET_GIT and ps_ok):
            display("ERROR: Target requires Windows 7, PowerShell 2.0, "
                    "Python 3.8.10 and Git 2.17.0.windows.1.")
            return 2
    elif label != TARGET_GIT or sys.version_info[:3] != (3, 8, 10) or not is_windows_7():
        display("INFO: This is not the exact deployment environment; "
                "use doctor --strict-target on the Windows 7 machine.")
    display("OK: Environment check completed.")
    return 0


def staged_paths(repo, executable="git"):
    data = checked(repo, "diff", "--cached", "--name-only", "-z", "--no-renames",
                   "--ita-invisible-in-index", "--no-ext-diff", "--no-textconv",
                   executable=executable)
    return [git_path(part) for part in data.split(b"\x00") if part]


def staged_blob_size(repo, oid, executable="git"):
    result = git(repo, "cat-file", "-s", oid, executable=executable)
    if result.returncode:
        display("ERROR: Cannot read staged object: {}".format(decode(result.stderr)))
        raise SystemExit(2)
    try:
        return int(result.stdout.strip())
    except ValueError:
        display("ERROR: Invalid staged object size.")
        raise SystemExit(2)


def staged_entries(repo, executable="git"):
    data = checked(repo, "ls-files", "--stage", "-z", executable=executable)
    entries = {}
    for record in data.split(b"\x00"):
        if record:
            metadata, path = record.split(b"\t", 1)
            mode, oid, stage = metadata.split()
            if stage != b"0":
                display("ERROR: Unresolved merge conflict: {}".format(git_path(path)))
                raise SystemExit(1)
            entries[git_path(path)] = (mode, oid.decode("ascii"))
    return entries


def path_warnings(path, size, limit):
    normalized = path.replace("\\", "/").lower()
    parts = normalized.split("/")
    name = parts[-1]
    warnings = []
    if any(part in BUILD_DIRS or part.endswith((".runs", ".cache", ".sim")) for part in parts[:-1]):
        warnings.append("EDA-generated directory")
    if name.endswith(BUILD_SUFFIXES):
        warnings.append("possible generated output")
    if name in SECRET_NAMES or name.endswith(SECRET_SUFFIXES):
        warnings.append("possible secret or license")
    if size is not None and size > limit:
        warnings.append("staged blob exceeds {} MiB".format(limit // (1024 * 1024)))
    return warnings


def audit(repo, large_mib, executable="git"):
    _, version = git_version(repo, executable)
    if version < MIN_GIT:
        display("ERROR: This skill requires Git 2.17.0 or later.")
        return 2
    root = repository_root(repo, executable)
    display("Repository: {}".format(root))
    entries = staged_entries(root, executable)
    paths = staged_paths(root, executable)
    if not paths:
        display("NO STAGED FILES: Nothing is ready to commit.")
        return 1

    display("Staged files: {}".format(len(paths)))
    limit = large_mib * 1024 * 1024
    review = False
    for path in paths:
        entry = entries.get(path)
        if entry is None:  # A staged deletion has no index object to inspect.
            display("DELETE: {}".format(path))
            continue
        mode, oid = entry
        if mode == b"160000":
            warnings = ["submodule: verify local source availability"]
        else:
            warnings = path_warnings(path, staged_blob_size(root, oid, executable), limit)
        if warnings:
            review = True
            display("REVIEW: {} ({})".format(path, ", ".join(warnings)))

    check = git(root, "diff", "--cached", "--check", "--ita-invisible-in-index",
                "--no-ext-diff", "--no-textconv",
                executable=executable)
    if check.returncode:
        display("ERROR: git diff --cached --check reported problems:")
        display(decode(check.stdout + check.stderr))
        return 2 if check.stderr else 1

    if review:
        display("REVIEW REQUIRED: Inspect the warnings and the staged diff before committing.")
        return 1
    display("OK: Staged diff has no whitespace errors or heuristic warnings. "
            "Review the diff before committing; no HDL validation was performed.")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("doctor", "audit"))
    parser.add_argument("--repo", default=".", help="path inside the local Git repository")
    parser.add_argument("--large-mib", type=int, default=DEFAULT_LARGE_MIB)
    parser.add_argument("--git", default="git", help="path to the existing git.exe")
    parser.add_argument("--strict-target", action="store_true",
                        help="doctor only: require the exact deployment environment")
    args = parser.parse_args()
    if not os.path.isdir(args.repo):
        parser.error("--repo must be an existing directory")
    if args.large_mib < 1:
        parser.error("--large-mib must be positive")
    if args.strict_target and args.command != "doctor":
        parser.error("--strict-target is only valid with doctor")
    if args.command == "doctor":
        return doctor(args.repo, args.git, args.strict_target)
    return audit(args.repo, args.large_mib, args.git)


if __name__ == "__main__":
    sys.exit(main())
