# Offline entry point. ASCII source; syntax and APIs are limited to PowerShell 2.0.
param(
    [string]$PythonExe = 'python',
    [string]$GitExe = 'git',
    [switch]$StrictTarget,
    [string]$ReportPath = ''
)

$ErrorActionPreference = 'Stop'
$testDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillDirectory = Split-Path -Parent $testDirectory
$checkerPath = Join-Path $skillDirectory 'scripts\repo_check.py'
$pythonTestPath = Join-Path $testDirectory 'run_tests.py'
$resultCode = 1
$smokeCount = 0
$originalDirectory = Get-Location
$tempRoot = [System.IO.Path]::GetTempPath()
$testRoot = Join-Path $tempRoot ('fpga-git-ps-' + [Guid]::NewGuid().ToString('N'))
$savedEnvironment = @{}
$environmentNames = @('HOME', 'USERPROFILE', 'XDG_CONFIG_HOME')
foreach ($entry in [Environment]::GetEnvironmentVariables('Process').GetEnumerator()) {
    if ($entry.Key -like 'GIT_*') { $environmentNames += $entry.Key }
}
$environmentNames += @('GIT_CONFIG_NOSYSTEM', 'GIT_CONFIG_GLOBAL', 'GIT_TERMINAL_PROMPT',
    'GIT_EDITOR', 'GIT_MERGE_AUTOEDIT', 'GIT_OPTIONAL_LOCKS')
foreach ($name in $environmentNames) {
    $savedEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
}

function Invoke-TestGit {
    param([string[]]$GitArgs)
    & $GitExe @GitArgs
    if ($LASTEXITCODE -ne 0) { throw ('Git failed: ' + ($GitArgs -join ' ')) }
}

try {
    foreach ($name in $environmentNames) {
        if ($name -like 'GIT_*') { [Environment]::SetEnvironmentVariable($name, $null, 'Process') }
    }
    if ($StrictTarget) {
        if ($PSVersionTable.PSVersion.Major -ne 2 -or $PSVersionTable.PSVersion.Minor -ne 0) {
            throw ('Expected PowerShell 2.0; actual: ' + $PSVersionTable.PSVersion.ToString())
        }
        & $PythonExe -B $checkerPath doctor --repo $skillDirectory --git $GitExe --strict-target
        if ($LASTEXITCODE -ne 0) { throw 'Exact deployment environment check failed' }
    }
    New-Item -ItemType Directory -Path $testRoot | Out-Null
    $repoPath = Join-Path $testRoot ('FPGA ' + [char]0x5DE5 + [char]0x7A0B + ' with spaces')
    New-Item -ItemType Directory -Path $repoPath | Out-Null
    $env:HOME = $testRoot
    $env:USERPROFILE = $testRoot
    $env:XDG_CONFIG_HOME = $testRoot
    $env:GIT_CONFIG_NOSYSTEM = '1'
    $env:GIT_CONFIG_GLOBAL = 'NUL'
    $env:GIT_TERMINAL_PROMPT = '0'
    $env:GIT_EDITOR = 'true'
    $env:GIT_MERGE_AUTOEDIT = 'no'
    $env:GIT_OPTIONAL_LOCKS = '0'
    Set-Location -LiteralPath $repoPath
    Invoke-TestGit -GitArgs @('init')
    Invoke-TestGit -GitArgs @('config', '--local', 'user.name', 'Offline Test')
    Invoke-TestGit -GitArgs @('config', '--local', 'user.email', 'offline-test@example.invalid')
    Invoke-TestGit -GitArgs @('config', '--local', 'core.autocrlf', 'false')
    Invoke-TestGit -GitArgs @('config', '--local', 'commit.gpgsign', 'false')
    $utf8 = New-Object System.Text.UTF8Encoding
    $sourceName = ([char]0x9876).ToString() + ' top.v'
    $sourcePath = Join-Path $repoPath $sourceName
    [System.IO.File]::WriteAllText($sourcePath, "module top;`nendmodule`n", $utf8)
    Invoke-TestGit -GitArgs @('add', '--', $sourceName)
    & $PythonExe -B $checkerPath audit --repo $repoPath --git $GitExe
    if ($LASTEXITCODE -ne 0) { throw 'Initial staged audit failed' }
    Invoke-TestGit -GitArgs @('commit', '-m', 'baseline')
    $smokeCount += 1

    [System.IO.File]::WriteAllText($sourcePath, "module changed;`nendmodule`n", $utf8)
    Invoke-TestGit -GitArgs @('stash', 'save', '-u', 'local work')
    Invoke-TestGit -GitArgs @('stash', 'show', '-p', 'stash@{0}')
    Invoke-TestGit -GitArgs @('stash', 'apply', 'stash@{0}')
    if ([System.IO.File]::ReadAllText($sourcePath) -notmatch 'changed') { throw 'Stash restore mismatch' }
    Invoke-TestGit -GitArgs @('stash', 'drop', 'stash@{0}')
    $smokeCount += 1

    Invoke-TestGit -GitArgs @('add', '--', $sourceName)
    Invoke-TestGit -GitArgs @('reset', 'HEAD', '--', $sourceName)
    if ([System.IO.File]::ReadAllText($sourcePath) -notmatch 'changed') { throw 'Unstage lost work' }
    Invoke-TestGit -GitArgs @('checkout', '--', $sourceName)
    if ([System.IO.File]::ReadAllText($sourcePath) -match 'changed') { throw 'Restore mismatch' }
    $smokeCount += 1

    Invoke-TestGit -GitArgs @('tag', '-a', 'milestone', '-m', 'test only')
    $tagCommit = Invoke-TestGit -GitArgs @('rev-parse', 'milestone^{}')
    $headCommit = Invoke-TestGit -GitArgs @('rev-parse', 'HEAD')
    if ($tagCommit -ne $headCommit) { throw 'Annotated tag target mismatch' }
    $smokeCount += 1

    Invoke-TestGit -GitArgs @('rm', '--', $sourceName)
    & $PythonExe -B $checkerPath audit --repo $repoPath --git $GitExe
    if ($LASTEXITCODE -ne 0) { throw 'Deletion audit failed' }
    $smokeCount += 1
    Set-Location -LiteralPath $originalDirectory.Path

    $pythonArgs = @('-B', $pythonTestPath, '--git', $GitExe,
        '--powershell-version', $PSVersionTable.PSVersion.ToString(),
        '--powershell-smoke-count', $smokeCount.ToString())
    if ($ReportPath -ne '') { $pythonArgs += @('--report', $ReportPath) }
    & $PythonExe @pythonArgs
    $resultCode = $LASTEXITCODE
    if ($resultCode -ne 0) { throw 'Python regression suite failed' }
    Write-Host ('PowerShell smoke checks passed: ' + $smokeCount)
}
catch {
    Write-Host ('FAILED: ' + $_.Exception.Message)
    $resultCode = 1
}
finally {
    Set-Location -LiteralPath $originalDirectory.Path
    foreach ($name in $savedEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($name, $savedEnvironment[$name], 'Process')
    }
    if (Test-Path -LiteralPath $testRoot) {
        $resolvedTestRoot = [System.IO.Path]::GetFullPath($testRoot)
        $resolvedTempRoot = [System.IO.Path]::GetFullPath($tempRoot).TrimEnd('\') + '\'
        if (-not $resolvedTestRoot.StartsWith($resolvedTempRoot, [StringComparison]::OrdinalIgnoreCase) -or
            (Split-Path -Leaf $resolvedTestRoot) -notlike 'fpga-git-ps-*') {
            throw 'Refusing cleanup outside the generated temporary directory'
        }
        Remove-Item -LiteralPath $resolvedTestRoot -Recurse -Force
    }
}
exit $resultCode
