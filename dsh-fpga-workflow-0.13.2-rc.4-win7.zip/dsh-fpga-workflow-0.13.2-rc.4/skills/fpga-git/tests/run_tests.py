#!/usr/bin/env python3
"""Offline regression suite. Python 3.8 stdlib; repositories are temporary."""

import argparse
import datetime
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import subprocess
import struct
import sys
import tempfile
import time
import unittest
from unittest import mock


SKILL = Path(__file__).resolve().parents[1]
SCRIPT = SKILL / "scripts" / "repo_check.py"
spec = importlib.util.spec_from_file_location("repo_check", str(SCRIPT))
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)
GIT = "git"
BASE_ENV = None


class RepoCase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="fpga-git-test-")
        self.addCleanup(self.cleanup_temp)
        self.repo = Path(self.temp.name) / "FPGA 工程 with spaces"
        self.repo.mkdir()
        self.env = BASE_ENV.copy()
        self.env["HOME"] = self.temp.name
        self.env["USERPROFILE"] = self.temp.name
        self.env["XDG_CONFIG_HOME"] = self.temp.name
        self.env["GIT_CONFIG_NOSYSTEM"] = "1"
        self.env["GIT_CONFIG_GLOBAL"] = os.devnull
        self.env["GIT_TERMINAL_PROMPT"] = "0"
        self.env["GIT_EDITOR"] = "true"
        self.env["GIT_SEQUENCE_EDITOR"] = "true"
        self.env["GIT_MERGE_AUTOEDIT"] = "no"
        self.env["GIT_OPTIONAL_LOCKS"] = "0"
        self.env["PYTHONIOENCODING"] = "utf-8"
        self.g("init")
        self.g("config", "--local", "user.name", "Offline Test")
        self.g("config", "--local", "user.email", "offline-test@example.invalid")
        self.g("config", "--local", "core.autocrlf", "false")
        self.g("config", "--local", "commit.gpgsign", "false")

    def cleanup_temp(self):
        # Windows 7 can briefly report "directory not empty" (WinError 145)
        # while a just-unlinked object file is still being released.
        for attempt in range(5):
            try:
                self.temp.cleanup()
                return
            except OSError:
                if attempt == 4:
                    raise
                time.sleep(0.2 * (attempt + 1))

    def call(self, argv, cwd=None, env=None, input_data=None):
        return subprocess.run(argv, cwd=str(cwd or self.repo),
                              env=env or self.env, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, check=False,
                              input=input_data, timeout=60)

    def g(self, *args, **kwargs):
        expected = kwargs.pop("expected", 0)
        result = self.call([GIT] + list(args), **kwargs)
        allowed = expected if isinstance(expected, tuple) else (expected,)
        self.assertIn(result.returncode, allowed,
                      repr(args) + "\n" + (result.stdout + result.stderr).decode("utf-8", "replace"))
        return result.stdout

    def write(self, path, content=b"module top;\nendmodule\n"):
        target = self.repo / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        return target

    def commit(self, message="baseline"):
        self.g("add", "--", ".")
        self.g("commit", "-m", message)
        return self.g("rev-parse", "HEAD").strip().decode("ascii")

    def baseline(self):
        self.write("rtl/top.v")
        return self.commit()

    def tool(self, command="audit", expected=0, extra=(), repo=None, env=None):
        result = self.call([sys.executable, "-B", str(SCRIPT), command,
                            "--repo", str(repo or self.repo), "--git", GIT] + list(extra),
                           env=env)
        output = (result.stdout + result.stderr).decode("utf-8", "replace")
        self.assertEqual(result.returncode, expected, output)
        return output

    def snapshot(self):
        return {str(p.relative_to(self.repo)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.repo.rglob("*") if p.is_file()}

    def test_doctor_does_not_require_repository(self):
        self.tool("doctor", repo=Path(self.temp.name))

    def test_strict_doctor_checks_actual_target(self):
        if check.is_windows_7() and sys.version_info[:3] == (3, 8, 10):
            label = self.g("--version").strip().decode("ascii")
            ps = self.call(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                            "$PSVersionTable.PSVersion.ToString()"])
            if label == check.TARGET_GIT and ps.returncode == 0 and ps.stdout.strip() == b"2.0":
                self.tool("doctor", extra=("--strict-target",))
                return
        self.tool("doctor", expected=2, extra=("--strict-target",))

    def test_empty_unborn_repository(self):
        self.assertIn("NO STAGED FILES", self.tool(expected=1))

    def test_first_commit_audit(self):
        self.write("rtl/top.v")
        self.g("add", "--", "rtl/top.v")
        self.assertIn("Staged files: 1", self.tool())

    def test_clean_repository(self):
        self.baseline()
        self.tool(expected=1)

    def test_untracked_file_is_not_staged(self):
        self.write("new.v")
        self.tool(expected=1)

    def test_intent_to_add_is_not_ready_to_commit(self):
        self.baseline()
        self.write("intent.v")
        self.g("add", "-N", "--", "intent.v")
        self.tool(expected=1)

    def test_modification(self):
        self.baseline()
        self.write("rtl/top.v", b"module renamed;\nendmodule\n")
        self.g("add", "--", "rtl/top.v")
        self.tool()

    def test_deletion_only(self):
        self.baseline()
        self.g("rm", "--", "rtl/top.v")
        self.assertIn("DELETE: rtl/top.v", self.tool())

    def test_rename(self):
        self.baseline()
        self.g("mv", "rtl/top.v", "rtl/new top.v")
        self.tool()

    def test_chinese_and_special_paths(self):
        for name in ("rtl/中文 顶层.v", "rtl/-leading.v", "rtl/[unit];&$.sv", "rtl/tab\tfile.v"):
            if "\t" in name and os.name == "nt":
                continue  # Windows disallows control characters in filenames.
            self.write(name)
            self.g("add", "--", name)
        # Git normalizes 8.3 short path components (common on real Win7 TEMP
        # locations) to long names in rev-parse output; compare resolved paths.
        self.assertIn(str(self.repo.resolve()).replace("\\", "/"), self.tool())

    def test_nested_working_directory(self):
        self.write("rtl/top.v")
        self.g("add", "--", "rtl/top.v")
        self.tool(repo=self.repo / "rtl")

    def test_staged_size_not_worktree_size(self):
        self.write("rtl/top.v")
        self.g("add", "--", "rtl/top.v")
        self.write("rtl/top.v", b"x" * (2 * 1024 * 1024))
        self.tool(extra=("--large-mib", "1"))

    def test_large_staged_blob(self):
        self.write("rom.dat", b"x" * (1024 * 1024 + 1))
        self.g("add", "--", "rom.dat")
        self.assertIn("exceeds 1 MiB", self.tool(expected=1, extra=("--large-mib", "1")))

    def test_size_boundary(self):
        self.write("rom.dat", b"x" * (1024 * 1024))
        self.g("add", "--", "rom.dat")
        self.tool(extra=("--large-mib", "1"))

    def test_generated_and_secret_warnings(self):
        for name in (".Xil/cache.dat", "p.runs/result.dat", "out.BIT", "license.LIC", ".env"):
            self.write(name)
        self.g("add", "--", ".")
        output = self.tool(expected=1)
        for warning in ("EDA-generated", "possible generated", "possible secret", "REVIEW REQUIRED"):
            self.assertIn(warning, output)

    def test_whitespace_errors(self):
        self.write("rtl/top.v", b"module top; \nendmodule\n")
        self.g("add", "--", ".")
        self.assertIn("whitespace", self.tool(expected=1))

    def test_crlf(self):
        self.g("config", "--local", "core.whitespace", "cr-at-eol")
        self.write("rtl/top.v", b"module top;\r\nendmodule\r\n")
        self.g("add", "--", ".")
        self.tool()

    def test_crlf_respects_existing_git_whitespace_policy(self):
        self.write("rtl/top.v", b"module top;\r\nendmodule\r\n")
        self.g("add", "--", ".")
        self.tool(expected=1)

    def test_read_only_for_success_and_review(self):
        self.write("rtl/top.v")
        self.g("add", "--", ".")
        before = self.snapshot()
        self.tool()
        self.tool("doctor")
        self.assertEqual(before, self.snapshot())
        self.write("key.pem")
        self.g("add", "--", "key.pem")
        before = self.snapshot()
        self.tool(expected=1)
        self.assertEqual(before, self.snapshot())

    def test_ascii_console_does_not_crash(self):
        self.write("rtl/中文.bit")
        self.g("add", "--", ".")
        env = self.env.copy()
        env["PYTHONIOENCODING"] = "ascii"
        self.assertIn("REVIEW", self.tool(expected=1, env=env))

    def test_conflict_rejected_and_resolved(self):
        self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "feature")
        self.write("rtl/top.v", b"feature\n")
        self.commit("feature")
        self.g("checkout", branch)
        self.write("rtl/top.v", b"stable\n")
        self.commit("stable")
        self.g("merge", "feature", expected=1)
        before = self.snapshot()
        self.assertIn("Unresolved merge conflict", self.tool(expected=1))
        self.assertEqual(before, self.snapshot())
        self.write("rtl/top.v", b"combined\n")
        self.g("add", "--", "rtl/top.v")
        self.tool()
        self.g("commit", "-m", "resolve")
        self.assertEqual(self.g("ls-files", "-u"), b"")

    def test_submodule_without_local_object_is_review(self):
        oid = self.baseline()
        self.g("update-index", "--add", "--cacheinfo", "160000," + oid + ",ip/module")
        self.assertIn("submodule", self.tool(expected=1))

    def test_missing_index_object_is_error(self):
        self.write("rtl/top.v")
        self.g("add", "--", ".")
        oid = self.g("rev-parse", ":rtl/top.v").strip().decode("ascii")
        object_path = self.repo / ".git" / "objects" / oid[:2] / oid[2:]
        object_path.chmod(0o600)  # Git creates read-only loose objects on Windows.
        object_path.unlink()
        self.tool(expected=2)

    def test_audit_disables_external_diff_and_textconv(self):
        self.write(".gitattributes", b"*.v diff=broken\n")
        self.write("rtl/top.v")
        self.g("config", "--local", "diff.external", "nonexistent-fpga-diff")
        self.g("config", "--local", "diff.broken.textconv", "nonexistent-fpga-converter")
        self.g("add", "--", ".")
        self.tool()

    def test_invalid_directory(self):
        self.tool(expected=2, repo=self.repo / "missing")

    def test_not_a_repository(self):
        self.tool(expected=2, repo=Path(self.temp.name))

    def test_bare_repository(self):
        bare = Path(self.temp.name) / "bare.git"
        self.g("init", "--bare", str(bare))
        self.tool(expected=2, repo=bare)

    def test_missing_git(self):
        self.tool("doctor", expected=2, extra=("--git", str(self.repo / "missing.exe")))

    def test_invalid_arguments(self):
        for extra in (("--large-mib", "0"), ("--large-mib", "-1"),
                      ("--large-mib", "abc"), ("--strict-target",)):
            self.tool(expected=2, extra=extra)

    def test_unstage_before_first_commit_preserves_file(self):
        target = self.write("rtl/top.v")
        self.g("add", "--", "rtl/top.v")
        self.g("rm", "--cached", "--", "rtl/top.v")
        self.assertTrue(target.exists())
        self.assertEqual(self.g("ls-files"), b"")

    def test_unstage_after_commit_preserves_edit(self):
        self.baseline()
        content = b"new design\n"
        target = self.write("rtl/top.v", content)
        self.g("add", "--", "rtl/top.v")
        self.g("reset", "HEAD", "--", "rtl/top.v")
        self.assertEqual(target.read_bytes(), content)
        self.assertEqual(self.g("diff", "--cached", "--name-only"), b"")

    def test_branch_merge_and_annotated_tag(self):
        self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "feature")
        self.write("rtl/uart.v")
        oid = self.commit("uart")
        self.g("checkout", branch)
        self.g("merge", "feature")
        self.g("tag", "-a", "milestone", "-m", "simulation not run")
        self.assertEqual(self.g("rev-parse", "milestone^{}").strip().decode("ascii"), oid)
        self.g("show", "--stat", "--oneline", "HEAD")
        self.g("tag", "--list")

    def test_merge_abort_preserves_baseline(self):
        first = self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "feature")
        self.write("rtl/top.v", b"feature\n")
        self.commit()
        self.g("checkout", branch)
        self.write("rtl/top.v", b"stable\n")
        stable = self.commit()
        self.g("merge", "feature", expected=1)
        self.g("merge", "--abort")
        self.assertNotEqual(first, stable)
        self.assertEqual(self.g("rev-parse", "HEAD").strip().decode("ascii"), stable)
        self.assertEqual((self.repo / "rtl/top.v").read_bytes(), b"stable\n")

    def test_stash_save_apply_drop_with_untracked(self):
        self.baseline()
        self.write("rtl/top.v", b"edit\n")
        self.write("new tb.sv")
        self.g("stash", "save", "-u", "local work")
        self.assertFalse((self.repo / "new tb.sv").exists())
        self.g("stash", "list")
        self.g("stash", "show", "-p", "stash@{0}")
        self.g("stash", "apply", "stash@{0}")
        self.assertTrue((self.repo / "new tb.sv").exists())
        self.assertEqual((self.repo / "rtl/top.v").read_bytes(), b"edit\n")
        self.g("stash", "drop", "stash@{0}")
        self.assertEqual(self.g("stash", "list"), b"")

    def test_revert_and_reflog(self):
        self.baseline()
        self.write("rtl/top.v", b"change\n")
        oid = self.commit("change")
        self.g("revert", "--no-edit", oid)
        self.assertEqual((self.repo / "rtl/top.v").read_bytes(), b"module top;\nendmodule\n")
        self.g("reflog")

    def test_cherry_pick(self):
        self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "fix")
        self.write("fix.v")
        oid = self.commit("fix")
        self.g("checkout", branch)
        self.g("cherry-pick", oid)
        self.assertTrue((self.repo / "fix.v").exists())

    def test_rebase(self):
        self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "feature")
        self.write("feature.v")
        self.commit("feature")
        self.g("checkout", branch)
        self.write("stable.v")
        stable = self.commit("stable")
        self.g("checkout", "feature")
        self.g("rebase", branch)
        self.g("merge-base", "--is-ancestor", stable, "HEAD")
        self.assertTrue((self.repo / "feature.v").exists())

    def test_rebase_abort(self):
        self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "feature")
        self.write("rtl/top.v", b"feature\n")
        feature = self.commit("feature")
        self.g("checkout", branch)
        self.write("rtl/top.v", b"stable\n")
        self.commit("stable")
        self.g("checkout", "feature")
        self.g("rebase", branch, expected=(1, 128))
        self.g("rebase", "--abort")
        self.assertEqual(self.g("rev-parse", "HEAD").strip().decode("ascii"), feature)

    def test_rebase_conflict_resolution_continue(self):
        self.baseline()
        branch = self.g("symbolic-ref", "--short", "HEAD").strip().decode("ascii")
        self.g("checkout", "-b", "feature")
        self.write("rtl/top.v", b"feature\n")
        self.commit("feature")
        self.g("checkout", branch)
        self.write("rtl/top.v", b"stable\n")
        stable = self.commit("stable")
        self.g("checkout", "feature")
        self.g("rebase", branch, expected=(1, 128))
        self.write("rtl/top.v", b"combined\n")
        self.g("add", "--", "rtl/top.v")
        self.g("rebase", "--continue")
        self.g("merge-base", "--is-ancestor", stable, "HEAD")
        self.assertEqual((self.repo / "rtl/top.v").read_bytes(), b"combined\n")

    def test_bisect_and_reset(self):
        good = self.baseline()
        for i in range(3):
            self.write("rtl/top.v", ("revision {}\n".format(i)).encode("ascii"))
            self.commit("revision {}".format(i))
        bad = self.g("rev-parse", "HEAD").strip().decode("ascii")
        self.g("bisect", "start")
        self.g("bisect", "bad")
        self.g("bisect", "good", good)
        self.g("bisect", "bad")
        self.g("bisect", "reset")
        self.assertEqual(self.g("rev-parse", "HEAD").strip().decode("ascii"), bad)

    def test_ignore_history_restore_and_clean_preview(self):
        self.write(".gitignore", b"*.vcd\n")
        self.write("wave.vcd")
        self.baseline()
        self.g("check-ignore", "-v", "--", "wave.vcd")
        self.g("status", "--ignored", "--short")
        self.g("status", "--porcelain")
        self.g("branch", "-v")
        self.g("log", "--oneline", "--decorate", "-n", "20", "--graph", "--all")
        self.g("log", "--follow", "--", "rtl/top.v")
        self.g("blame", "--", "rtl/top.v")
        self.g("log", "-Smodule", "--", "rtl/top.v")
        self.write("rtl/top.v", b"unwanted edit\n")
        self.g("diff", "--check")
        self.g("diff", "--", "rtl/top.v")
        self.g("checkout", "--", "rtl/top.v")
        self.assertEqual((self.repo / "rtl/top.v").read_bytes(), b"module top;\nendmodule\n")
        self.write("new.v")
        self.g("clean", "-nd")
        self.assertTrue((self.repo / "new.v").exists())
        self.assertTrue((self.repo / "wave.vcd").exists())

    def test_amend_and_interactive_add(self):
        self.baseline()
        self.g("commit", "--amend", "-m", "reword")
        self.assertEqual(self.g("log", "-1", "--format=%s").strip(), b"reword")
        self.write("rtl/top.v", b"module renamed;\nendmodule\n")
        self.g("add", "-p", "--", "rtl/top.v", input_data=b"y\n")
        self.assertEqual(self.g("diff", "--name-only"), b"")
        self.assertIn(b"+module renamed;", self.g("diff", "--cached"))


class UnitCase(unittest.TestCase):
    def test_git_path_uses_utf8_not_mbcs(self):
        value = "D:/中文 工程/顶层.v"
        self.assertEqual(check.git_path(value.encode("utf-8")), value)

    def test_invalid_utf8_fails_closed(self):
        with mock.patch("sys.stdout", new=io.StringIO()):
            with self.assertRaises(SystemExit) as caught:
                check.git_path(b"\xff")
        self.assertEqual(caught.exception.code, 2)

    def test_version_parse_failure_and_git_failure(self):
        for code, data in ((0, b"unknown"), (2, b"")):
            result = subprocess.CompletedProcess([], code, data, b"failure")
            with mock.patch.object(check, "git", return_value=result), mock.patch("sys.stdout", new=io.StringIO()):
                with self.assertRaises(SystemExit) as caught:
                    check.git_version(".")
            self.assertEqual(caught.exception.code, 2)

    def test_old_git_rejected(self):
        with mock.patch.object(check, "git_version", return_value=("git version 2.16.0", (2, 16, 0))), mock.patch("sys.stdout", new=io.StringIO()):
            self.assertEqual(check.doctor("."), 2)
            self.assertEqual(check.audit(".", 10), 2)

    def test_strict_doctor_accepts_exact_target(self):
        ps = subprocess.CompletedProcess([], 0, b"2.0\r\n", b"")
        with mock.patch.object(check, "git_version", return_value=(check.TARGET_GIT, (2, 17, 0))), mock.patch.object(check, "is_windows_7", return_value=True), mock.patch.object(check.sys, "version_info", (3, 8, 10)), mock.patch.object(check.subprocess, "run", return_value=ps), mock.patch("sys.stdout", new=io.StringIO()):
            self.assertEqual(check.doctor(".", strict_target=True), 0)

    def test_strict_doctor_rejects_missing_or_new_powershell(self):
        for value in (OSError("missing"), subprocess.CompletedProcess([], 0, b"5.1.1\r\n", b"")):
            kwargs = {"side_effect": value} if isinstance(value, OSError) else {"return_value": value}
            with mock.patch.object(check, "git_version", return_value=(check.TARGET_GIT, (2, 17, 0))), mock.patch.object(check, "is_windows_7", return_value=True), mock.patch.object(check.sys, "version_info", (3, 8, 10)), mock.patch.object(check.subprocess, "run", **kwargs), mock.patch("sys.stdout", new=io.StringIO()):
                self.assertEqual(check.doctor(".", strict_target=True), 2)

    def test_size_failure_is_not_silently_ignored(self):
        for result in (subprocess.CompletedProcess([], 1, b"", b"missing"),
                       subprocess.CompletedProcess([], 0, b"not-a-size", b"")):
            with mock.patch.object(check, "git", return_value=result), mock.patch("sys.stdout", new=io.StringIO()):
                with self.assertRaises(SystemExit) as caught:
                    check.staged_blob_size(".", "a" * 40)
            self.assertEqual(caught.exception.code, 2)

    def test_checked_git_failure(self):
        result = subprocess.CompletedProcess([], 1, b"", b"error")
        with mock.patch.object(check, "git", return_value=result), mock.patch("sys.stdout", new=io.StringIO()):
            with self.assertRaises(SystemExit) as caught:
                check.checked(".", "ls-files")
        self.assertEqual(caught.exception.code, 2)

    def test_windows_detection(self):
        with mock.patch.object(check.sys, "platform", "linux"):
            self.assertFalse(check.is_windows_7())
        if sys.platform == "win32":
            version = type("Version", (), {"major": 6, "minor": 1})()
            with mock.patch.object(check.sys, "getwindowsversion", return_value=version):
                self.assertTrue(check.is_windows_7())

    def test_warning_rules(self):
        self.assertEqual(check.path_warnings("rtl/top.v", 100, 100), [])
        for path in ("db/a.dat", "incremental_db/a.dat", "output_files/a.dat", "p.cache/a.dat", "p.sim/a.dat"):
            self.assertIn("EDA-generated directory", check.path_warnings(path, 0, 100))
        for path in ("id_rsa", "id_ed25519", ".env", "x.PFX", "x.p12", "x.key"):
            self.assertIn("possible secret or license", check.path_warnings(path, 0, 100))

    def test_python38_grammar_and_reference_links(self):
        import ast
        for path in SKILL.rglob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path), feature_version=(3, 8))
        for path in SKILL.rglob("*.ps1"):
            path.read_text(encoding="ascii")
        import re
        for path in SKILL.rglob("*.md"):
            for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
                if "://" not in target and not target.startswith("#"):
                    self.assertTrue((path.parent / target.split("#")[0]).is_file(), str(path) + ": " + target)


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({"test": test.id(), "status": "passed"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({"test": test.id(), "status": "failed"})

    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({"test": test.id(), "status": "error"})

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.records.append({"test": test.id(), "status": "skipped", "reason": reason})


def main():
    global GIT, BASE_ENV
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--git", default="git")
    parser.add_argument("--report", help="optional output JSON path (outside the skill recommended)")
    parser.add_argument("--powershell-version", help="set by the PowerShell runner")
    parser.add_argument("--powershell-smoke-count", type=int, default=0)
    args = parser.parse_args()
    GIT = args.git
    BASE_ENV = os.environ.copy()
    # Never allow a calling shell's repository/index overrides to target a real project.
    for key in list(BASE_ENV):
        if key.startswith("GIT_"):
            del BASE_ENV[key]
    version = subprocess.run([GIT, "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             env=BASE_ENV, check=True).stdout.decode("ascii").strip()
    print("Runtime: {} / {} / {}".format(platform.platform(), platform.python_version(), version))
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult).run(suite)
    if args.report:
        source_hashes = {str(path.relative_to(SKILL)).replace("\\", "/"):
                         hashlib.sha256(path.read_bytes()).hexdigest()
                         for path in SKILL.rglob("*") if path.is_file() and path.suffix in (".py", ".ps1")}
        report = {"os": platform.platform(), "python": platform.python_version(), "git": version,
                  "python_bits": struct.calcsize("P") * 8,
                  "executed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "git_executable": GIT, "source_sha256": source_hashes,
                  "tests": result.testsRun, "failures": len(result.failures),
                  "errors": len(result.errors), "skipped": len(result.skipped),
                  "powershell": args.powershell_version,
                  "powershell_smoke_passed": args.powershell_smoke_count,
                  "successful": result.wasSuccessful(), "cases": result.records,
                  "failures_detail": [(test.id(), message) for test, message in result.failures + result.errors]}
        Path(args.report).write_text(json.dumps(report, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
