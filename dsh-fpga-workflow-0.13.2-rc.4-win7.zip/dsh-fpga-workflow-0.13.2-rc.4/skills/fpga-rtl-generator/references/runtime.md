# 运行接口与输入

将 `fpga-rtl-generator` 放入内网 Harness 可读取的 skill 目录。保持工作区同级的 `fpga-architecture-design` 和 `standalone-lint`，或通过 `--arch-skill` 指向架构 skill 根、`--rules` 指向 `standalone-lint` 的 `RTL_Coding_Rule.md`。直接入口只依赖规则文件。脚本路径建议由完整绝对路径调用。运行目录与交付目录均须使用新目录，写在冻结架构包外部。旧系统建议采用短路径。

```powershell
$env:FPGA_PYTHON38 = 'C:\Python38\python.exe'
$rtl = 'D:\skills\fpga-rtl-generator\scripts\run.ps1'
& $rtl doctor
& $rtl prepare --request 'D:\proj\selection.json' --package 'D:\proj\arch-frozen' --run 'D:\proj\rtl-run'
& $rtl next --run 'D:\proj\rtl-run' --limit 8
& $rtl accept --run 'D:\proj\rtl-run' --job m0001 --stage plan
& $rtl accept --run 'D:\proj\rtl-run' --job m0001 --stage reference
& $rtl accept --run 'D:\proj\rtl-run' --job m0001 --stage rtl
& $rtl accept --run 'D:\proj\rtl-run' --job m0001 --stage lint --batch l001
& $rtl lint-status --run 'D:\proj\rtl-run'
& $rtl publish --run 'D:\proj\rtl-run' --output 'D:\proj\rtl-delivery'
```

每次接受产物后调用 `next` 派发后续任务。退出码 0 和 `FPGA_RTL_OK:<action>` 表示动作成功。交付就绪看 `delivery.json` 的各检查状态。可用 `publish --partial-lint` 交付评审副本。当前规则库默认 8 批，每批 11 或 12 条。`next --limit 8` 可列出同一文件待检查的 8 批，实际并发由宿主槽位决定。每批默认约 8 KiB 上限，可通过 `prepare --batch-rules` 或 `--batch-bytes` 拆成更小批次。工具输出提供路径和少量摘要。中断时先检查工作路径中的候选文件，已接受快照须保持只读。若协调脚本被强制终止且留下 `.coordinator.lock`，先根据文件中的 PID 核实原进程确已退出，再清理锁并续跑。

开发验收可用配置的 Python 运行 `scripts/selftest.py -v`。脚本使用临时目录。测试覆盖直接请求、模拟的架构交接口、子模块准备、阶段恢复、实例连线检查、旧 lint 结果失效和离线产物发布。现场另用实际工程运行布局、展开或其他已配置工具的验收。

## 架构入口

交接包使用现有 `fpga-architecture-design` 的生产 `FROZEN` 包。范围文件以 `package.json` 的原始 SHA-256 绑定该版。选定模块用架构 UID。清单可列完整设计或选定子树。如果工程顶层可确定，填它的 UID，即使它位于所选子树外。未给出时用 `null`。

```json
{
  "contract": "FPGA-RTL-SELECTION/1.0.0",
  "package_sha256": "填写实际64位十六进制摘要",
  "root": "MOD-CTRL",
  "project_top": "MOD-TOP",
  "modules": [
    {"uid": "MOD-CTRL", "name": "controller", "mode": "generate", "children": [
      {"module": "MOD-PIPE", "instance": "u_pipe", "parameters": {},
       "connections": {"i_clk": "i_clk", "i_rst_n": "i_rst_n", "i_data": "i_data", "o_data": "o_data"}}
    ]},
    {"uid": "MOD-PIPE", "name": "pipeline_stage", "mode": "generate", "children": []}
  ]
}
```

`children` 中的连接按「子端口名 → 父模块中的 Verilog 表达式」填写，参数覆盖同样使用名称和表达式。显式悬空用空字符串，只有契约允许时使用。生成模块可提供 `requirements` 补充已确认的实现细节。复用模块用 `mode: reuse`、`sources` 和 `interface.interfaces.ports`。`sources` 相对于范围文件，可包含 `.v` 和 `.vh`。外部模块用 `mode: external`、`dependency` 和同形接口。需要追踪的复用模块依赖也应列入 `children`。共享模块用同一 UID 引用，多个实例各自填写参数与端口绑定。

## 直接入口

`prepare` 省略 `--package`。使用 `FPGA-RTL-REQUEST/1.0.0`，其余模块和实例字段相同。每个生成模块提供自己负责的要求，单模块也可使用顶层 `requirements`。没有固定工程顶层时用 `null`。

```json
{
  "contract": "FPGA-RTL-REQUEST/1.0.0",
  "root": "MOD-COUNTER",
  "project_top": "MOD-COUNTER",
  "modules": [
    {"uid": "MOD-COUNTER", "name": "sample_counter", "mode": "generate", "children": [],
     "requirements": "每个有效采样上升沿递增，8位回卷，低有效同步复位。"}
  ]
}
```

## 检查工具

需要工具展开时，显式指定 `--iverilog <可执行文件>`，并按需提供相对交付包的 `--include-dir`。外部黑盒定义缺失或执行工具出错时，报告记录对应状态和原因。默认交付执行快速强制规则检查。`files.f` 从交付包根目录使用，一行一个 `.v` 路径，复用头文件随包保留。

原版 VG 严格门禁要求 Python 3.10 或更高版本。在具备该独立运行环境的工作站上，可在 `publish` 显式指定 `--vg-python <解释器路径>` 和 `--vg-root <原生成器目录>`，带规格执行原严格门禁。Windows 7 内网基线路径默认记录该门禁 `not_run`。当前仿真和综合也记录 `not_run`。Windows 7 真机、PowerShell 2.0 和内网多 Agent 调度需现场验证。
