# 阶段与产物

协调者先查看 `next` 返回的任务卡路径和工作位置。创建工作目录后再写文件。每个批次持有自己的路径。进入 `accept` 前，主 Agent 对照任务卡、产物与上游事实确认内容。脚本验证格式、证据位置和依赖完整性，并记录接受快照。

## plan

- `requirements.json` 须有非空 `requirements`，记录本模块义务、来源、假设和未决项。架构路径保留引用的需求 UID、修订 UID、模块 UID 和接口 UID。
- `codegen_plan.json` 须有非空 `steps`，解释时钟复位、接口、参数、时序、FSM、数据格式、关键边界、模块例化与测试方式。
- `spec.json` 描述确认的 Verilog-2001 模块。使用 `name`、`rtl_path`（`rtl/<name>.v`）、`target: rtl`、`rtl_dialect: verilog`、`interfaces.ports`（`name/direction/width/description`）、`clock`、`reset`、`behavior`、`constraints`、`corner_cases`、`verification_cases` 和 `timing_diagrams`。时钟和复位对象至少提供端口 `name`，并按设计写明边沿、极性、同步或异步和复位值。无对应域时显式填 `null`。行为、约束、边界和验证场景为字符串数组。直接输入另写 `design_requirements.confirmed_by_user: true` 及 `confirmation_notes`，引用真实的确认来源。
- 每个 `timing_diagrams` 项提供 `id/title/scenario/description/wavejson`。离线 SVG 支持 `signal` 平铺数组，元素为 `name/wave` 和可选 `data`，例 `{"signal":[{"name":"i_clk","wave":"p...."},{"name":"i_valid","wave":"0.1.0"}]}`。支持 `0/1/x/z/p/n/P/N/./=/2–9`，总线标签与每个新数据段对应。把长场景分成每图最多 160 步。接受规格时自动生成 Markdown、JSON5 和 SVG。

## reference 和 rtl

`reference` 写 `reference.py`，用 Python 3.8 实现独立于 RTL 的参考语义，给出清楚的调用入口。为适合的场景写 `vectors.json`，包含激励和期望周期。控制逻辑模型应覆盖复位、保持、反压或优先级，按契约适用性裁剪。接受阶段检查语法及入口，模型执行和仿真需有真实运行记录。

`rtl` 写 `<name>.v`，按需写 `tb_<name>.v`。先从确认的契约与参考模型推导逻辑。一个生成文件只定义自己的模块，实例用具名端口。父模块使用任务卡的实例名、参数和连线。已有生成契约发生变化时重建运行输入。只修改 RTL 行为实现时可重新提交该阶段并触发新版 lint 检查。

## lint

在 `next` 指定的 JSON 文件中写数组。每个被分配的强制规则恰有一行。`status` 取 `pass`、`fail`、`not_applicable` 或 `unverified`。每项填写 `rule_id` 和非空 `evidence`。失败还需提供 1 基 `line` 和该行中的 `snippet`。核对规则的作用范围，尤其顶层、ASIC 特定规则、外部依赖和工具才能确定的属性。工程顶层信息未知时，相应规则需要标记 `unverified`。主 Agent 根据真实项目的上下文复核这些规则。程序按源文件 SHA-256 保存结果，报告含规则源摘要、覆盖数量、失败和待查清单。

```json
[
  {"rule_id": "2.1.1", "status": "pass", "evidence": "填写核对的代码及项目依据"}
]
```
