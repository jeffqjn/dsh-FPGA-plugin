"""Freeze a selected RTL subtree and its local rule source."""

import hashlib
import json
import re
import sys
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[2]
DEFAULT_ARCH = WORKSPACE / 'fpga-architecture-design'
DEFAULT_RULES = (WORKSPACE / 'standalone-lint' / 'standalone_lint' / 'assets'
                 / 'rules' / 'RTL_Coding_Rule.md')
IDENTIFIER = re.compile(r'[A-Za-z_][A-Za-z0-9_]*\Z')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    def unique(pairs):
        obj = dict(pairs)
        require(len(obj) == len(pairs), 'Duplicate JSON key in ' + str(path))
        return obj

    def reject_constant(value):
        raise ValueError('Non-finite JSON value {} in {}'.format(value, path))

    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=reject_constant)


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            digest.update(chunk)
    return digest.hexdigest()


def inside(root, relative):
    path = (root / relative).resolve()
    require(path != root and root in path.parents, 'Path escapes its input root: ' + str(relative))
    return path


def index(items, key):
    result = {item[key]: item for item in items}
    require(len(result) == len(items), 'Duplicate ' + key)
    return result


def read_architecture(root, selection, skill):
    manifest = root / 'package.json'
    digest = sha(manifest)
    require(selection.get('package_sha256') == digest, 'Selection does not match package.json SHA-256')
    scripts = skill / 'scripts'
    require((scripts / 'archlib.py').is_file(), 'Architecture validator missing. Set --arch-skill.')
    sys.path.insert(0, str(scripts))
    try:
        import archlib
        validated = archlib.validate_package(root)
    finally:
        sys.path.pop(0)
    require(validated['status'] == 'FROZEN' and not validated['synthetic'],
            'Architecture generation requires a validated production FROZEN package')
    handoff = root / 'detailed_design_input.json'
    package = load(manifest)
    require(sha(manifest) == digest and sha(handoff) == package['artifacts']['detailed_design_input.json'],
            'Architecture handoff changed during validation')
    data = load(handoff)
    require(data['contract'] == 'FPGA-ARCH-HANDOFF/1.0.0', 'Unsupported architecture handoff')
    review = root / 'review.json'
    require(sha(review) == package['artifacts']['review.json'], 'Architecture review changed during validation')
    data['approved_scope'] = load(review)['allowed_scope']
    return data, digest


def module_order(modules, root):
    order = []
    visiting = set()
    complete = set()

    def visit(uid):
        require(uid in modules, 'Unknown child module UID: ' + uid)
        require(uid not in visiting, 'Cycle in RTL instances at ' + uid)
        if uid in complete:
            return
        visiting.add(uid)
        module = modules[uid]
        children = index(module.get('children', []), 'instance')
        for instance, item in children.items():
            require(IDENTIFIER.fullmatch(instance), 'Invalid instance name: ' + instance)
            for key in ('parameters', 'connections'):
                require(isinstance(item.get(key), dict), 'Missing ' + key + ' for ' + instance)
                require(all(IDENTIFIER.fullmatch(name) and isinstance(value, str)
                            for name, value in item[key].items()),
                        'Use named Verilog expression strings in ' + key + ' for ' + instance)
            visit(item['module'])
        visiting.remove(uid)
        complete.add(uid)
        order.append(uid)

    visit(root)
    return order


def architecture_context(architecture, uid, scoped_issues):
    module = index(architecture['modules'], 'uid')[uid]
    interfaces = [item for item in architecture['interfaces'] if uid in item['endpoint_refs']]
    clocks = set(module['clock_refs'])
    resets = set(module['reset_refs'])
    for item in interfaces:
        clocks.update(item.get('clock_refs', []))
        resets.update(item.get('reset_refs', []))
    reqs = set(module['requirement_refs'])
    for item in interfaces:
        reqs.update(item['requirement_refs'])
    related = {uid} | clocks | resets | {item['uid'] for item in interfaces}
    cdcs = [item for item in architecture.get('cdcs', [])
            if {item['source_clock'], item['destination_clock']} & clocks]
    related.update(item['uid'] for item in cdcs)
    issue_refs = set(module['issue_refs'])
    for item in interfaces + cdcs:
        issue_refs.update(item.get('issue_refs', []))
    return dict(module=module, interfaces=interfaces, cdcs=cdcs, target=architecture['target'],
                approved_scope=architecture['approved_scope'],
                clocks=[item for item in architecture['clocks'] if item['uid'] in clocks],
                resets=[item for item in architecture['resets'] if item['uid'] in resets],
                requirements=[item for item in architecture['effective_requirements']
                              if item['requirement_uid'] in reqs],
                budgets=[item for item in architecture.get('budgets', [])
                         if reqs.intersection(item['requirement_refs'])],
                decisions=[item for item in architecture.get('decisions', [])
                           if reqs.intersection(item['requirement_refs'])],
                issues=[item for item in scoped_issues if item['uid'] in issue_refs
                        or related.intersection(item.get('object_refs', []))])


def build_tasks(request, base, architecture=None):
    modules = index(request['modules'], 'uid')
    root = request['root']
    order = module_order(modules, root)
    require(modules[root]['mode'] == 'generate', 'Selected root must be generated')
    top = request.get('project_top')
    require(top is None or isinstance(top, str) and top, 'project_top must be a module UID or null')
    contexts = {}
    if architecture is not None:
        arch_modules = index(architecture['modules'], 'uid')
        require((set(order) | ({top} if top else set())) <= set(arch_modules),
                'Selection contains a UID outside the architecture modules')
        for uid in order:
            contexts[uid] = architecture_context(architecture, uid, architecture.get('issues', []))
    require(len({modules[uid]['name'].lower() for uid in order}) == len(order),
            'Duplicate HDL definition names')
    tasks = []
    sources = {}
    jobs = {uid: 'm{:04d}'.format(number) for number, uid in enumerate(order, 1)}
    for uid in order:
        module = modules[uid]
        name = module['name']
        require(IDENTIFIER.fullmatch(name), 'Invalid Verilog module name: ' + name)
        mode = module['mode']
        require(mode in ('generate', 'reuse', 'external'), 'Invalid implementation mode for ' + uid)
        require(mode != 'external' or module.get('dependency'), 'External module needs a dependency description')
        require(mode != 'reuse' or module.get('sources'), 'Reused module must provide source files')
        require(mode != 'generate' or not module.get('sources'), 'Generated module cannot list reused sources')
        require(mode == 'generate' or module.get('interface'), 'Dependency needs its interface contract: ' + uid)
        job = jobs[uid]
        files = []
        for relative in module.get('sources', []):
            source = inside(base, relative)
            require(source.is_file() and source.suffix.lower() in ('.v', '.vh'),
                    'Expected a Verilog source: ' + relative)
            canonical = source.relative_to(base).as_posix()
            files.append('dependencies/' + canonical)
            sources[canonical] = source
        children = [dict(item, job=jobs[item['module']], name=modules[item['module']]['name'],
                         mode=modules[item['module']]['mode'],
                         interface=modules[item['module']].get('interface'))
                    for item in module.get('children', [])]
        request_input = module.get('requirements', request.get('requirements') if uid == root else None)
        require(mode != 'generate' or architecture is not None or request_input,
                'Direct generation needs requirements for ' + uid)
        tasks.append(dict(job=job, uid=uid, name=name, mode=mode, children=children, sources=files,
                          is_project_top=None if top is None else uid == top,
                          architecture=contexts.get(uid), requirements=request_input,
                          interface=module.get('interface'), dependency=module.get('dependency')))
    return tasks, sources


def rule_batches(rule_text, limit=None, byte_limit=8192):
    rules = []
    active = False
    in_fence = False
    level = None
    current = None
    for line_number, line in enumerate(rule_text.splitlines(), 1):
        if line.strip() == '## 规则清单':
            active = True
        elif active and not in_fence and (re.match(r'^##\s', line) or line.startswith('### 第三部分')):
            break
        if not active:
            continue
        if line.lstrip().startswith('```'):
            in_fence = not in_fence
            if current:
                current['lines'].append(line)
            continue
        if not in_fence:
            heading = re.match(r'^#{4,5}\s+(.+)', line)
            if heading:
                current = None
                value = heading.group(1)
                level = 'mandatory' if '强制类' in value else ('advisory' if '推荐类' in value else None)
                continue
            header = re.match(r'^\s*\*\*(\d+(?:\.\d+)+)\s+(.+?)\*\*\s*$', line)
            if header:
                require(level is not None, 'Numbered rule without a level: ' + header.group(1))
                current = None
                if level == 'mandatory':
                    current = dict(id=header.group(1), title=header.group(2), source_line=line_number,
                                   lines=[line])
                    rules.append(current)
                continue
        if current and line.strip() != '---':
            current['lines'].append(line)
    require(rules, 'No mandatory rules could be read from RTL_Coding_Rule.md')
    index(rules, 'id')
    for rule in rules:
        rule['text'] = '\n'.join(rule.pop('lines')).strip()
    groups = min(8, len(rules))
    if limit is not None:
        groups = max(groups, (len(rules) + limit - 1) // limit)
    base, extra = divmod(len(rules), groups)
    batches = []
    start = 0
    for group in range(groups):
        end = start + base + (group < extra)
        batch = []
        size = 0
        for rule in rules[start:end]:
            added = len(json.dumps(rule, ensure_ascii=False).encode('utf-8')) + 64
            require(added <= byte_limit, 'One rule exceeds the configured rule byte budget: ' + rule['id'])
            if size + added > byte_limit:
                batches.append(batch)
                batch = []
                size = 0
            batch.append(rule)
            size += added
        batches.append(batch)
        start = end
    return batches
