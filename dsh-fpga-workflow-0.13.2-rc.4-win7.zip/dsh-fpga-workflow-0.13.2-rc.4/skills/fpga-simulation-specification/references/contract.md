# 产物契约与运行约定

运行 `python <skill>/scripts/workflow.py --help` 查看参数。脚本仅用 Python 3.8+ 标准库。JSON 与 Markdown 用 UTF-8，CSV 用带 BOM 的 UTF-8。以下文件均放在独立的项目输出目录，输入包和 skill 目录保持只读。每个计划修订和回归单独留档。

## 1. 义务计划

`inputs --requirements <需求包> --architecture <架构包> --output <input_index.json>`。允许省略 `--requirements` 并使用架构快照。上游完整校验按[输入适配](inputs.md)另行执行。索引的 `binding` 对象原样进入计划；其余字段用于编制计划。以下为 `obligation_plan.json` 字段约定。

| 字段 | 内容 |
|---|---|
| `revision`, `binding`, `changes` | 正整数修订号、输入索引的绑定对象、本次变更的字符串数组 |
| `evaluations[]` | 每条有效原子需求恰有一条。字段为 `requirement_uid`、`revision_uid`、`domain`、`title`、`disposition`、`reason`、`dimensions`。处置取 `SIMULATION`、`MIXED`、`OTHER_EVIDENCE`。 |
| `dimensions` | 六个键 `NORMAL`、`BOUNDARY`、`STRESS`、`OFFSET`、`ERROR`、`RECOVERY`。每个值为 `{"applicable":true或false,"reason":"理由"}`。处置为 OTHER_EVIDENCE 时这六项均不适用。 |
| `obligations[]` | 每项有 `id`、`requirement_uids[]`、`architecture_ids[]`、`function_ids[]`、`performance_ids[]`、`objective`、`evidence`、`criterion`、`source_refs[]`、`method`、`items[]`。两种需求点编号无适用项时填 `["—"]`，映射缺失时填 `["待补"]` 并说明。 |
| `method` | `RTL_FUNCTIONAL`、`GATE_TIMING`、`STA`、`STATIC_CDC`、`INSPECTION`、`ANALYSIS`、`BOARD` 或 `REVIEW`。混合取证用多条义务。 |
| `items[]` | 功能义务至少一个覆盖项，其他义务置空。每项有 `id`、`requirement_uids[]`、`dimension`、`configuration`、`scenario`、`criterion`、`mandatory`、`status`、`gap`。状态为 `READY` 或 `BLOCKED`，后者写明确的关闭条件。 |
| `coverage_policy` | `branch_target_percent`、`statement_target_percent` 取受控强制门槛，未规定时为 null。规定门槛时 `source_refs[]` 写来源。功能门槛固定 100%。 |
| `issue_reviews[]` | 对输入索引中的每条未关闭架构问题记录 `id`、`disposition`、`reason` 和 `item_ids[]`。影响必测项判定时用 `BLOCKED` 并挂接受阻覆盖项。其余用 `OTHER_EVIDENCE` 或 `NO_IMPACT`，说明取证去向或为何无影响。 |

每个覆盖项定义可独立判定的场景与配置。按各需求、适用场景和配置评估完整性，区分所有必测项与探索性覆盖项。每个适用维度至少挂一个本需求的必测覆盖项。合并义务时，覆盖项自身应指向真正受其检查的需求。各原子需求和上游架构义务均须有明确去向。需求包内的验证义务、ICD、判据和源测试点 UID 可写入 `source_refs`。通过依据未知时明确注明待定。保持义务和覆盖项 ID 稳定，删除的 ID 不复用。

`render-plan --inputs <索引> --plan <计划> --output <仿真验证义务计划.md>`。向用户展示此稿。真实用户确认后运行 `approve --inputs <索引> --plan <计划> --revision <当前修订> --user-response <记录确认原话的UTF-8文本> --output <plan_approval.json>`。脚本只能绑定输入和指纹，记录真实确认由调用者负责。更新计划时重新输出评审稿和批准记录。

## 2. 仿真细则

`check-approval --inputs <当前索引> --plan <计划> --approval <批准记录>`。随后编制 `simulation_specification.json`，顶层含 `plan_sha256`（批准记录中的值）、`plan_revision`（当前计划修订）、`revision`（细则自身正整数修订）和 `cases[]`。

每个用例含 `id`、`title`、`level`、`configuration`、`preconditions[]`、`stimulus[]`、`steps[]`、`checks[]`。每个检查点含 `id`、`item_id`、`sample_event`、`expected`、`criterion`、`evidence`。检查点 ID 跨用例唯一；同一覆盖项可由多个检查点取证，此时全部检查点必须通过。待补项沿用已确认计划中的条目及缺口，待补项不编造检查结果。用例步骤说明数据值、驱动方式和观察时点，必要时引用版本固定的参考向量或模型；同一覆盖项的配置和检查必须相符。

`render-spec --inputs <当前索引> --plan <计划> --approval <批准记录> --spec <细则JSON> --markdown <仿真验证细则.md> --rtm <simulation_rtm.csv>`。该命令要求每个 READY 且必测的功能覆盖项至少有一项可判定检查点，并保留阻塞项和非功能仿真义务。Markdown 和 RTM 从结构化产物生成。

## 3. 覆盖证据

`coverage --inputs <索引> --plan <计划> --approval <批准记录> --spec <细则> [--results <当前回归结果>] --output <覆盖报告.md>`。结果文件由实际回归适配得到，包含：

- `spec_sha256` 为脚本所示当前细则的规范化 JSON SHA-256，`run_id` 为回归标识，`evidence_refs[]` 为日志、构建、配置和覆盖报告位置。
- `items[]` 含 `item_id` 和布尔 `hit`，代表相应配置下的功能覆盖采样。
- `checks[]` 含 `check_id` 和 `status`（PASS、FAIL、NOT_RUN），PASS/FAIL 须引用 `evidence_ref`。
- 可选 `branches`、`statements` 各含 `covered`、`total`、`report_ref`。分支使用仿真器报告口径，按批准配置归并结果，保留实际计数和不可达分析。缺报告时不估算百分比。

没有结果时只汇报细则设计覆盖率。设计覆盖分子为已有检查点的必测项，执行覆盖分子为实际命中且所有关联检查均通过的必测项。两者分母都是当前已确认计划中的必测功能覆盖项，含 BLOCKED。零分母显示不适用。报告列出未闭合项和对应需求、编号、义务和用例。测试扩展后重新绑定和回归，禁止将过期细则结果计入当前覆盖率。
