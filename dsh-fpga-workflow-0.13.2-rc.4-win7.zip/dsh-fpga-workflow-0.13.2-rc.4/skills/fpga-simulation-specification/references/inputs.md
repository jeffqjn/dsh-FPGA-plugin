# 结构化输入与版本绑定

- 需求包必须是 `req-spec-consistency-check` 发布的 `reqspec-reviewed` 交付包。使用该 skill 的 `validate --package` 核验 FEIP、发布与候选绑定、ICD 投影和证据完整性。架构包使用架构 skill 的 `validate --package` 核验其清单、输入快照和派生交接件。按各上游版本的运行说明调用。缺少校验器或校验未通过时报告原因，不能宣称已经完成该项核验。
- `inputs` 另做下游机械核对。对照架构包清单核验 `architecture.json`、`verification_input.json`、`inputs/upstream/package.json`、快照的需求与 ICD 字节摘要，校对外部需求包和架构内快照，核对架构交接摘要及有效修订集合。基线 UID 相同不足以证明同版；绑定失败先修正输入，再生成该基线的计划。原子义务以需求包的有效修订为准。
- 从 `reqspec.requirements[].revisions[]`、`source_baseline.parents`、`verification.obligations`、`verification.criteria`、`verification.source_test_points`、`analysis` 和 `views.simulation` 取规范及验收依据。从 `icd` 取实际信号、协议、域、时序和约束，查看 `review.consumer_views.simulation` 和影响 simulation 的诊断、缺口、豁免、允许及排除范围。历史条款不加入有效分母。以有效修订、适用配置和来源证据判断每项约束。
- 从 `verification_input.json` 取 `allocations`、`verification_obligations`、`issues`、`checks`，从同包 `architecture.json` 和 `interface_contracts.json` 查模块、接口和 CDC/RDC 等观察点。将上游义务和本地义务做显式映射。架构建议、估算或派生值保留原证据等级；依赖架构提案的场景注明条件。结构化源测试点缺字段时，仅从同版结构化义务、判据或 ICD 补足。
- 功能、性能需求点优先用 `source_parent_refs` 指向的父条款 `source_id`，按父条款的 `category=function/performance` 分类。相关义务可通过受控关系引用其他有效条款的父编号，记录对应关系依据。分类、适用性或映射无依据时登记缺口；禁止按字符串前缀、用例名称或架构模块名猜编号。
- 需求已发布、架构已冻结、仿真可执行是独立状态。架构 DRAFT、仿真视图 conditional/blocked 或合成包可用于带标记的计划评审。逐项判断影响，保留受阻项和依赖。对受影响部分，冻结或计划确认无法替代未决技术条件。合成包只用于演练。
- 索引提示缺父条款、缺有效修订级义务或判据、序列化表格及未关闭架构问题。共用模块产生的关联只用于缩小核查范围。逐项确认真实影响。受控新增要求可引用该修订和直接受控证据；未建立映射时不得写成“不适用”。表格须核对列头、行列关系和单位，接口绑定优先使用稳定 UID 并核对信号名和有效电平。无法确认的检查点标为受阻并回流给上游。
