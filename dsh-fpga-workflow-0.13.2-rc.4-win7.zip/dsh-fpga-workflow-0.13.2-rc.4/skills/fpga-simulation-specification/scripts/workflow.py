"""Validate and render FPGA simulation plans, specifications, and coverage."""
import argparse
import csv
import hashlib
import io
import json
import re
import sys
from pathlib import Path

DIMENSIONS = {
    "NORMAL": "常规", "BOUNDARY": "边界", "STRESS": "强度",
    "OFFSET": "偏移", "ERROR": "异常", "RECOVERY": "恢复",
}
METHODS = {
    "RTL_FUNCTIONAL": "RTL 功能仿真", "GATE_TIMING": "门级时序仿真",
    "STA": "静态时序", "STATIC_CDC": "静态 CDC", "INSPECTION": "检查",
    "ANALYSIS": "分析", "BOARD": "板级验证", "REVIEW": "评审",
}
DISPOSITIONS = {"SIMULATION": "功能仿真", "MIXED": "仿真及其他证据",
                "OTHER_EVIDENCE": "其他证据"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def dump(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(value):
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return digest(data.encode("utf-8"))


def write(path, content, encoding="utf-8"):
    with path.open("x", encoding=encoding, newline="") as output:
        output.write(content)


def indexed(records, key):
    index = {}
    for record in records:
        uid = record[key]
        require(isinstance(uid, str) and uid.strip() and uid not in index,
                "空或重复标识 {}: {}".format(key, uid))
        index[uid] = record
    return index


def ids(values, label, required=False):
    require(isinstance(values, list) and (values or not required)
            and all(isinstance(value, str) and value.strip() for value in values)
            and len(values) == len(set(values)), "无效列表 " + label)
    return set(values)


def fields(record, *keys):
    for key in keys:
        require(isinstance(record[key], str) and record[key].strip(),
                "缺少有效字段 " + key)


def revision(value):
    require(type(value) is int and value > 0, "修订号须为正整数")


def make_index(arch_root, req_root=None):
    snapshot = arch_root / "inputs/upstream"
    req_root = req_root or snapshot
    arch_manifest = load(arch_root / "package.json")
    req_manifest = load(req_root / "package.json")
    require(arch_manifest["contract"] == "FPGA-ARCH-PACKAGE/1.0.0"
            and arch_manifest["status"] in {"DRAFT", "FROZEN"}, "架构包合同或状态不支持")
    require(req_manifest["profile"] == "reqspec-reviewed"
            and req_manifest["status"] == "complete", "需要完整发布的需求交付包")
    artifacts = arch_manifest["artifacts"]
    for name in ("architecture.json", "verification_input.json", "interface_contracts.json", "inputs/upstream/package.json",
                 "inputs/upstream/reqspec.json", "inputs/upstream/icd.json"):
        require(digest((arch_root / name).read_bytes()) == artifacts[name],
                "架构清单摘要不符 " + name)
    for name in ("package.json", "reqspec.json", "icd.json"):
        require((req_root / name).read_bytes() == (snapshot / name).read_bytes(),
                "需求包与架构绑定快照不符 " + name)

    req = load(req_root / "reqspec.json")
    icd = load(req_root / "icd.json")
    arch = load(arch_root / "architecture.json")
    handoff = load(arch_root / "verification_input.json")
    protocol = req["protocol"]
    icd_binding = icd["binding"]
    require(protocol["producer"] == "req-spec-consistency-check"
            and protocol["profile"] == "reqspec-reviewed"
            and req["consistency"]["gates"]["overall"] == "PASS"
            and icd["contract"] == "FEIP-ICD/1.0.0"
            and icd_binding["model_path"] == "reqspec.json"
            and icd_binding["stage"] == "released"
            and icd_binding["run_uid"] == protocol["run_uid"] == req_manifest["run_uid"]
            and icd_binding["baseline_uid"] == protocol["baseline_uid"]
            and icd_binding["candidate_uid"] == req_manifest["candidate_uid"]
            and icd_binding["model_sha256"] == digest((req_root / "reqspec.json").read_bytes()),
            "需求模型、正式 ICD 或发布候选绑定不符")
    require(handoff["contract"] == "FPGA-ARCH-HANDOFF/1.0.0"
            and handoff["binding_sha256"] == arch["binding_sha256"] == arch_manifest["binding_sha256"]
            and handoff["synthetic"] == arch_manifest["synthetic"] == req_manifest["synthetic"],
            "架构交接合同、来源绑定或合成标记不符")

    requirements = indexed(req["effective_requirements"], "requirement_uid")
    arch_requirements = indexed(handoff["effective_requirements"], "requirement_uid")
    active = {key: value["effective_revision_uid"]
              for key, value in indexed(req["requirements"], "uid").items()
              if value["lifecycle"] == "active"}
    require({key: value["revision_uid"] for key, value in requirements.items()} == active
            == {key: value["revision_uid"] for key, value in arch_requirements.items()},
            "有效原子需求或修订集合不一致")
    parents = indexed(req["source_baseline"]["parents"], "uid")
    source_requirements = indexed(req["requirements"], "uid")
    verification = req["verification"]
    req_obligations = {}
    for item in verification["obligations"]:
        req_obligations.setdefault((item["requirement_uid"], item["revision_uid"]), []).append(item)
    for uid, record in requirements.items():
        source = source_requirements[uid]
        record["title"] = source["title"]
        record["category"] = source["category"]
        record["semantic"] = indexed(source["revisions"], "uid")[record["revision_uid"]]["semantic"]
        record["source_points"] = [
            {"uid": ref, "id": parents[ref]["source_id"], "category": parents[ref]["category"]}
            for ref in source["source_parent_refs"]
        ]
        local = req_obligations.get((uid, record["revision_uid"]), [])
        record["source_obligation_ids"] = [item["uid"] for item in local]
        record["source_criterion_ids"] = sorted({ref for item in local for ref in item["criterion_refs"]})
        record["input_findings"] = []
        if not record["source_points"]:
            record["input_findings"].append("缺父条款编号映射，核对受控扩展及直接证据")
        if not local or not record["source_criterion_ids"]:
            record["input_findings"].append("有效修订缺结构化验证义务或判据，核对受控替代依据")
        if re.search(r"(?m)^col=\d+;row_span=\d+;col_span=\d+:", record["semantic"]["statement"]):
            record["input_findings"].append("验收涉及序列化表格，核对行列、单位和适用配置")
    architecture_ids = indexed(handoff["verification_obligations"], "uid")
    for uid, obligation in architecture_ids.items():
        require(set(obligation["requirement_refs"]) <= requirements.keys(),
                "架构义务包含非有效需求 " + uid)
    binding = {
        "requirement_package_sha256": digest((req_root / "package.json").read_bytes()),
        "architecture_package_sha256": digest((arch_root / "package.json").read_bytes()),
        "architecture_binding_sha256": handoff["binding_sha256"],
        "baseline_uid": protocol["baseline_uid"], "candidate_uid": req_manifest["candidate_uid"],
        "synthetic": req_manifest["synthetic"], "architecture_status": arch_manifest["status"],
        "requirement_simulation_readiness": req["views"]["simulation"]["readiness"],
        "icd_simulation_readiness": icd["review"]["consumer_views"]["simulation"]["readiness"],
        "architecture_readiness": handoff["readiness"]["status"],
    }
    issues = indexed(handoff["issues"], "uid")
    allocations = indexed(handoff["allocations"], "requirement_uid")
    open_issues = []
    for uid, issue in issues.items():
        if issue["status"] != "open":
            continue
        objects = set(issue["object_refs"])
        related = [vo for vo in architecture_ids.values() if uid in vo.get("issue_refs", [])
                   or objects.intersection(vo.get("object_refs", []))]
        explicit = [vo for vo in related if uid in vo.get("issue_refs", [])]
        open_issues.append({**issue, "architecture_ids": [vo["uid"] for vo in related],
                            "explicit_architecture_ids": [vo["uid"] for vo in explicit]})
    return {"binding": binding, "requirements": list(requirements.values()),
            "architecture_obligations": list(architecture_ids.values()),
            "allocations": list(allocations.values()), "architecture_issues": open_issues,
            "architecture_readiness": handoff["readiness"],
            "architecture_checks": handoff["checks"],
            "requirement_simulation_view": req["views"]["simulation"],
            "icd_simulation_view": icd["review"]["consumer_views"]["simulation"],
            "icd_simulation_diagnostics": [item for item in icd["diagnostics"]
                                           if "simulation" in item.get("blocking_for", [])]}


def validate_plan(index, plan):
    revision(plan["revision"])
    require(plan["binding"] == index["binding"], "计划输入绑定已变化")
    require(isinstance(plan["changes"], list)
            and all(isinstance(value, str) and value.strip() for value in plan["changes"]),
            "变更记录须为非空文字组成的列表")
    source = indexed(index["requirements"], "requirement_uid")
    architecture = indexed(index["architecture_obligations"], "uid")
    evaluations = indexed(plan["evaluations"], "requirement_uid")
    require(evaluations.keys() == source.keys(), "计划必须逐条评估全部有效原子需求")
    for uid, evaluation in evaluations.items():
        fields(evaluation, "domain", "title", "reason")
        require(evaluation["revision_uid"] == source[uid]["revision_uid"],
                "需求修订不符 " + uid)
        dimensions = evaluation["dimensions"]
        require(evaluation["disposition"] in DISPOSITIONS and dimensions.keys() == DIMENSIONS.keys(),
                "处置或维度不完整 " + uid)
        for value in dimensions.values():
            fields(value, "reason")
            require(type(value["applicable"]) is bool, "适用性须为布尔值 " + uid)

    obligations = indexed(plan["obligations"], "id")
    items = {}
    methods = {uid: set() for uid in evaluations}
    mandatory = {uid: set() for uid in evaluations}
    mapped_arch = {uid: set() for uid in architecture}
    seen_arch = set()
    for vo, obligation in obligations.items():
        fields(obligation, "objective", "evidence", "criterion")
        reqs = ids(obligation["requirement_uids"], vo, required=True)
        archs = ids(obligation["architecture_ids"], vo)
        require(reqs <= evaluations.keys() and archs <= architecture.keys(), "无效追溯 " + vo)
        seen_arch.update(archs)
        for key in ("function_ids", "performance_ids"):
            points = ids(obligation[key], vo + " " + key, required=True)
            require("—" not in points or len(points) == 1, "不适用编号不能混用 " + vo)
            category = "function" if key == "function_ids" else "performance"
            expected = {p["id"] for uid in reqs for p in source[uid]["source_points"]
                        if p["category"] == category}
            require(expected <= points, "遗漏直接关联的需求点编号 " + vo + " " + key)
        ids(obligation["source_refs"], vo, required=True)
        for arch_uid in archs:
            linked = set(architecture[arch_uid]["requirement_refs"])
            require(not linked or bool(reqs & linked), "架构义务关联需求不符 " + vo)
            mapped_arch[arch_uid].update(reqs & linked)
        method = obligation["method"]
        require(method in METHODS, "未知取证方式 " + vo)
        for uid in reqs:
            methods[uid].add(method)
        local = indexed(obligation["items"], "id")
        functional = method == "RTL_FUNCTIONAL"
        require(bool(local) == functional, "功能义务须有覆盖项 " + vo)
        require(not items.keys() & local.keys(), "重复覆盖项 " + vo)
        item_requirements = set()
        for item_id, item in local.items():
            fields(item, "configuration", "scenario", "criterion")
            targets = ids(item["requirement_uids"], item_id, required=True)
            require(targets <= reqs and item["dimension"] in DIMENSIONS
                    and type(item["mandatory"]) is bool
                    and item["status"] in {"READY", "BLOCKED"}, "覆盖项字段无效 " + item_id)
            if item["status"] == "BLOCKED":
                fields(item, "gap")
            else:
                require(item["gap"] in (None, ""), "READY 项包含未决缺口 " + item_id)
            for uid in targets:
                require(evaluations[uid]["dimensions"][item["dimension"]]["applicable"],
                        "覆盖项使用不适用维度 " + item_id + " " + uid)
                if item["mandatory"]:
                    mandatory[uid].add(item["dimension"])
            item_requirements.update(targets)
            items[item_id] = (obligation, item)
        if functional:
            require(item_requirements == reqs, "功能义务存在未挂接到覆盖项的需求 " + vo)
    for uid, evaluation in evaluations.items():
        applicable = {name for name, value in evaluation["dimensions"].items() if value["applicable"]}
        selected = methods[uid]
        functional = "RTL_FUNCTIONAL" in selected
        other = bool(selected - {"RTL_FUNCTIONAL"})
        expected = "MIXED" if functional and other else "SIMULATION" if functional else "OTHER_EVIDENCE"
        require(selected and evaluation["disposition"] == expected and
                applicable == mandatory[uid] and bool(applicable) == functional,
                "处置、适用维度或必测映射不完整 " + uid)
    for uid, upstream in architecture.items():
        require(uid in seen_arch
                and mapped_arch[uid] == set(upstream["requirement_refs"]),
                "上游架构义务或其关联需求未完整映射 " + uid)
    issue_reviews = indexed(plan["issue_reviews"], "id")
    upstream_issues = indexed(index["architecture_issues"], "uid")
    require(issue_reviews.keys() == upstream_issues.keys(), "缺少上游未决架构问题的逐项评估")
    for uid, issue in issue_reviews.items():
        fields(issue, "disposition", "reason")
        affected = ids(issue["item_ids"], uid)
        require(affected <= items.keys(), "问题关联无效覆盖项 " + uid)
        require(issue["disposition"] in {"BLOCKED", "OTHER_EVIDENCE", "NO_IMPACT"}, "未知问题处置 " + uid)
        if issue["disposition"] == "BLOCKED":
            require(affected and all(items[item_id][1]["status"] == "BLOCKED" for item_id in affected),
                    "阻断问题须关联受阻覆盖项 " + uid)
        else:
            require(not affected, "受阻覆盖项须使用 BLOCKED 处置 " + uid)
    policy = plan["coverage_policy"]
    refs = ids(policy["source_refs"], "覆盖率门槛来源")
    for key in ("branch_target_percent", "statement_target_percent"):
        target = policy[key]
        require(target is None or (type(target) in (int, float) and 0 <= target <= 100 and refs),
                "覆盖率门槛无效或缺来源 " + key)
    return items


def check_approval(index, plan, approval):
    items = validate_plan(index, plan)
    require(approval["revision"] == plan["revision"]
            and approval["plan_sha256"] == fingerprint(plan)
            and approval["binding"] == index["binding"], "确认记录与当前计划或输入不符")
    fields(approval, "user_response")
    return items


def cell(value):
    return str(value).replace("|", "\\|").replace("\n", "<br>")


def row(*values):
    return "| " + " | ".join(cell(value) for value in values) + " |"


def render_plan(index, plan, items):
    required = [item for _, item in items.values() if item["mandatory"]]
    lines = ["# 仿真验证义务计划 · 待确认", "", "修订 v{} · 计划指纹 `{}`".format(
        plan["revision"], fingerprint(plan)), "",
        "原子需求 {} 条，验证义务 {} 条，必测功能覆盖项 {} 条，其中受阻 {} 条。".format(
            len(plan["evaluations"]), len(plan["obligations"]), len(required),
            sum(item["status"] == "BLOCKED" for item in required)), "",
        "架构状态 {}，架构就绪度 {}，需求仿真就绪度 {}，ICD 仿真就绪度 {}。".format(
            plan["binding"]["architecture_status"], plan["binding"]["architecture_readiness"],
            plan["binding"]["requirement_simulation_readiness"], plan["binding"]["icd_simulation_readiness"]),
        "", "请按需求、义务或覆盖项编号提出修改，或明确确认当前修订。", "",
        "## 本版变更", ""]
    if plan["binding"]["synthetic"]:
        lines.insert(4, "**合成输入，仅用于演练。**\n")
    lines.extend("- " + value for value in (plan["changes"] or ["首次提交"]))
    gaps = [item for _, item in items.values() if item["status"] == "BLOCKED"]
    lines.extend(["", "## 待解决事项", ""])
    lines.extend(["- {} · {}".format(item["id"], item["gap"]) for item in gaps] or ["无已登记的受阻覆盖项。"])
    lines.extend(["", "## 上游就绪条件及影响", ""])
    for view in (index["architecture_readiness"], index["requirement_simulation_view"], index["icd_simulation_view"]):
        for reason in view.get("reasons", []) or [view.get("reason")]:
            if reason:
                lines.append("- " + reason)
    for uid, issue in indexed(index["architecture_issues"], "uid").items():
        review = indexed(plan["issue_reviews"], "id")[uid]
        lines.append("- {} · {} · {} · {} · 受影响覆盖项 {} · 关闭条件 {}".format(
            uid, issue["description"], review["disposition"], review["reason"],
            "、".join(review["item_ids"]) or "—", issue["close_criterion"]))
    for requirement in index["requirements"]:
        if requirement.get("input_findings"):
            lines.append("- {} · {}".format(requirement["requirement_uid"],
                                             "；".join(requirement["input_findings"])))
    by_domain = {}
    revisions = {}
    for evaluation in plan["evaluations"]:
        by_domain.setdefault(evaluation["domain"], []).append(evaluation)
        revisions[evaluation["requirement_uid"]] = evaluation["revision_uid"]
    by_requirement = {}
    for vo in plan["obligations"]:
        for uid in vo["requirement_uids"]:
            by_requirement.setdefault(uid, []).append(vo["id"])
    for domain, evaluations in by_domain.items():
        lines.extend(["", "## " + domain, "",
                      row("原子需求与有效修订", "处置及理由", "逐维度判断", "义务"),
                      row("---", "---", "---", "---")])
        for evaluation in evaluations:
            uid = evaluation["requirement_uid"]
            dimensions = "\n".join("{}（{}） {}".format(
                label, "适用" if evaluation["dimensions"][name]["applicable"] else "不适用",
                evaluation["dimensions"][name]["reason"]) for name, label in DIMENSIONS.items())
            lines.append(row(uid + " · " + evaluation["title"] + "\n" + evaluation["revision_uid"],
                             DISPOSITIONS[evaluation["disposition"]] + " · " + evaluation["reason"],
                             dimensions, "、".join(by_requirement[uid])))
    lines.extend(["", "## 验证义务及必测场景", ""])
    for vo in plan["obligations"]:
        lines.extend(["### " + vo["id"] + " · " + vo["objective"], "",
                      "- 功能需求点编号 " + "、".join(vo["function_ids"]),
                      "- 性能需求点编号 " + "、".join(vo["performance_ids"]),
                      "- 原子需求及有效修订 " + "、".join(
                          "{}（{}）".format(uid, revisions[uid]) for uid in vo["requirement_uids"]),
                      "- 架构义务 " + ("、".join(vo["architecture_ids"]) or "—"),
                      "- 取证方式 " + METHODS[vo["method"]] + " · " + vo["evidence"],
                      "- 通过依据 " + vo["criterion"],
                      "- 来源 " + "、".join(vo["source_refs"]), ""])
        if vo["items"]:
            lines.extend([row("覆盖项", "场景及配置", "判据", "范围及状态"),
                          row("---", "---", "---", "---")])
            for item in vo["items"]:
                lines.append(row(item["id"], DIMENSIONS[item["dimension"]] + " · " + item["scenario"]
                                 + "\n配置 " + item["configuration"] + "\n" + "、".join(item["requirement_uids"]),
                                 item["criterion"], ("必测" if item["mandatory"] else "补充")
                                 + " · " + ("就绪" if item["status"] == "READY" else "受阻")))
            lines.append("")
    return "\n".join(lines) + "\n"


def validate_spec(items, plan, approval, spec):
    revision(spec["revision"])
    require(spec["plan_sha256"] == approval["plan_sha256"] and
            spec["plan_revision"] == plan["revision"], "细则未绑定当前已确认计划")
    checks = {}
    by_item = {uid: [] for uid in items}
    for case_id, case in indexed(spec["cases"], "id").items():
        fields(case, "title", "level", "configuration")
        for key in ("preconditions", "stimulus", "steps"):
            require(isinstance(case[key], list) and (case[key] or key == "preconditions")
                    and all(isinstance(step, str) and step.strip() for step in case[key]),
                    "用例缺少有效步骤或输入 " + case_id + " " + key)
        local = indexed(case["checks"], "id")
        require(local and not local.keys() & checks.keys(), "用例缺检查点或 ID 重复 " + case_id)
        for check_id, check in local.items():
            fields(check, "sample_event", "expected", "criterion", "evidence")
            uid = check["item_id"]
            require(uid in items and items[uid][1]["status"] == "READY", "检查点未关联就绪项 " + check_id)
            require(case["configuration"] == items[uid][1]["configuration"],
                    "检查点配置不符 " + check_id)
            by_item[uid].append((case_id, check_id))
        checks.update(local)
    for uid, (_, item) in items.items():
        require(not item["mandatory"] or item["status"] == "BLOCKED" or by_item[uid],
                "必测就绪项缺少检查点 " + uid)
    return checks, by_item


def specification_documents(plan, spec, items, by_item):
    revisions = {e["requirement_uid"]: e["revision_uid"] for e in plan["evaluations"]}
    lines = ["# FPGA 仿真验证细则", "", "细则 v{} · 已确认计划 v{} · 细则指纹 `{}`".format(
        spec["revision"], plan["revision"], fingerprint(spec)), "",
        "## 用例", ""]
    if plan["binding"]["synthetic"]:
        lines[4:4] = ["**合成输入，仅用于演练。**", ""]
    for case in spec["cases"]:
        lines.extend(["### " + case["id"] + " · " + case["title"], "",
                      "- 层级与配置 " + case["level"] + " · " + case["configuration"], ""])
        for title, key in (("前置条件", "preconditions"), ("激励", "stimulus"), ("步骤", "steps")):
            if case[key]:
                lines.extend(["**" + title + "**", ""])
                lines.extend("{}．{}".format(i, value) for i, value in enumerate(case[key], 1))
                lines.append("")
        lines.extend([row("检查点与覆盖项", "需求点编号", "原子需求与有效修订", "采样与期望", "判据及证据"),
                      row("---", "---", "---", "---", "---")])
        for check in case["checks"]:
            vo, item = items[check["item_id"]]
            lines.append(row(check["id"] + " · " + item["id"],
                             "功能 " + "、".join(vo["function_ids"]) + "\n性能 " + "、".join(vo["performance_ids"]),
                             "\n".join(uid + " · " + revisions[uid] for uid in item["requirement_uids"]),
                             check["sample_event"] + "\n" + check["expected"],
                             check["criterion"] + "\n" + check["evidence"]))
        lines.append("")
    lines.extend(["## 受阻项和其他取证义务", ""])
    for uid, (vo, item) in items.items():
        if item["status"] == "BLOCKED":
            lines.append("- {} · {} · {}".format(vo["id"], uid, item["gap"]))
    for vo in plan["obligations"]:
        if vo["method"] != "RTL_FUNCTIONAL":
            lines.append("- {} · {} · {} · {}".format(
                vo["id"], METHODS[vo["method"]], vo["objective"], vo["evidence"]))

    rtm = io.StringIO(newline="")
    writer = csv.writer(rtm)
    writer.writerow(("功能需求点", "性能需求点", "原子需求", "有效修订", "义务", "架构义务",
                     "取证方式", "覆盖项", "配置", "必测", "用例", "检查点", "状态", "缺口"))
    for vo in plan["obligations"]:
        for item in vo["items"] or [None]:
            targets = vo["requirement_uids"] if item is None else item["requirement_uids"]
            for uid in targets:
                common = ["、".join(vo["function_ids"]), "、".join(vo["performance_ids"]), uid,
                          revisions[uid], vo["id"], "、".join(vo["architecture_ids"]), vo["method"]]
                if item is None:
                    writer.writerow(common + ["", "", "", "", "", "其他证据待收集", ""])
                    continue
                for case, check in by_item[item["id"]] or [("", "")]:
                    writer.writerow(common + [item["id"], item["configuration"], item["mandatory"],
                                              case, check, item["status"], item["gap"] or ""])
    return "\n".join(lines) + "\n", rtm.getvalue()


def percent(count, total):
    return "{}/{}（{:.2f}%）".format(count, total, count * 100 / total) if total else "不适用（分母为 0）"


def render_coverage(plan, spec, items, checks, by_item, results):
    revisions = {e["requirement_uid"]: e["revision_uid"] for e in plan["evaluations"]}
    mandatory = {uid for uid, (_, item) in items.items() if item["mandatory"]}
    designed = {uid for uid in mandatory if by_item[uid]}
    lines = ["# 仿真覆盖报告", "", "细则指纹 `{}`".format(fingerprint(spec)), "",
             "- 细则设计覆盖率 " + percent(len(designed), len(mandatory))]
    if plan["binding"]["synthetic"]:
        lines[4:4] = ["**合成输入，仅用于演练。**", ""]
    hits, outcomes = {}, {}
    if results is not None:
        require(results["spec_sha256"] == fingerprint(spec), "回归结果不对应当前细则")
        fields(results, "run_id")
        ids(results["evidence_refs"], "回归证据", required=True)
        hits = indexed(results["items"], "item_id")
        outcomes = indexed(results["checks"], "check_id")
        require(hits.keys() <= items.keys() and outcomes.keys() <= checks.keys(), "回归记录包含未知 ID")
        for record in hits.values():
            require(type(record["hit"]) is bool, "命中记录须为布尔值")
        for record in outcomes.values():
            require(record["status"] in {"PASS", "FAIL", "NOT_RUN"}, "检查结果状态无效")
            if record["status"] != "NOT_RUN":
                fields(record, "evidence_ref")
        lines.append("- 回归 " + results["run_id"] + " · " + "、".join(results["evidence_refs"]))
    covered = set()
    reasons = {}
    for uid in mandatory:
        vo, item = items[uid]
        statuses = [outcomes.get(check_id, {}).get("status") for _, check_id in by_item[uid]]
        if item["status"] == "BLOCKED":
            reasons[uid] = "受阻 · " + item["gap"]
        elif "FAIL" in statuses:
            reasons[uid] = "关联检查失败"
        elif results is None:
            reasons[uid] = "待执行"
        elif not hits.get(uid, {}).get("hit", False):
            reasons[uid] = "未命中"
        elif not statuses or any(value != "PASS" for value in statuses):
            reasons[uid] = "关联检查未完成"
        else:
            covered.add(uid)
    lines.append("- 功能覆盖率 " + ("待执行" if results is None else percent(len(covered), len(mandatory))))
    for label, key, policy_key in (("分支", "branches", "branch_target_percent"),
                                   ("语句", "statements", "statement_target_percent")):
        value = results.get(key) if results is not None else None
        target = plan["coverage_policy"][policy_key]
        if value is None:
            lines.append("- " + label + "覆盖率 待提供报告" +
                         (" · 受控门槛 {}%".format(target) if target is not None else ""))
            continue
        hit, total = value["covered"], value["total"]
        require(type(hit) is int and type(total) is int and 0 <= hit <= total, label + "覆盖计数无效")
        fields(value, "report_ref")
        line = "- " + label + "覆盖率 " + percent(hit, total) + " · " + value["report_ref"]
        if target is not None:
            status = "待判定" if not total else "达到" if hit * 100 >= target * total else "未达到"
            line += " · {}受控门槛 {}%".format(status, target)
        lines.append(line)
    lines.extend(["", "## 未闭合的必测功能项", "",
                  row("覆盖项", "需求与义务", "用例与检查点", "原因"),
                  row("---", "---", "---", "---")])
    for uid, (vo, item) in items.items():
        if uid in reasons:
            lines.append(row(uid, "功能 " + "、".join(vo["function_ids"]) + "\n性能 "
                             + "、".join(vo["performance_ids"]) + "\n"
                             + "\n".join(key + " · " + revisions[key] for key in item["requirement_uids"])
                             + "\n" + vo["id"],
                             "、".join(case + "/" + check for case, check in by_item[uid]) or "—",
                             reasons[uid]))
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    command = commands.add_parser("inputs")
    command.add_argument("--architecture", type=Path, required=True)
    command.add_argument("--requirements", type=Path)
    command.add_argument("--output", type=Path, required=True)
    for name in ("render-plan", "approve", "check-approval", "render-spec", "coverage"):
        command = commands.add_parser(name)
        command.add_argument("--inputs", type=Path, required=True)
        command.add_argument("--plan", type=Path, required=True)
        if name in ("check-approval", "render-spec", "coverage"):
            command.add_argument("--approval", type=Path, required=True)
        if name in ("render-plan", "approve", "coverage"):
            command.add_argument("--output", type=Path, required=True)
        if name == "approve":
            command.add_argument("--revision", type=int, required=True)
            command.add_argument("--user-response", type=Path, required=True)
        if name in ("render-spec", "coverage"):
            command.add_argument("--spec", type=Path, required=True)
        if name == "render-spec":
            command.add_argument("--markdown", type=Path, required=True)
            command.add_argument("--rtm", type=Path, required=True)
        if name == "coverage":
            command.add_argument("--results", type=Path)
    args = parser.parse_args()
    if args.command == "inputs":
        for root in (args.architecture, args.requirements):
            require(root is None or root.resolve() not in args.output.resolve().parents,
                    "输出须位于上游包之外")
        write(args.output, dump(make_index(args.architecture, args.requirements)))
        return
    index, plan = load(args.inputs), load(args.plan)
    if args.command in ("render-plan", "approve"):
        items = validate_plan(index, plan)
        if args.command == "render-plan":
            write(args.output, render_plan(index, plan, items))
        else:
            response = args.user_response.read_text(encoding="utf-8-sig").strip()
            require(response and args.revision == plan["revision"], "缺用户确认原话或确认修订不匹配")
            write(args.output, dump({"revision": plan["revision"], "binding": index["binding"],
                                     "plan_sha256": fingerprint(plan), "user_response": response}))
        return
    approval = load(args.approval)
    items = check_approval(index, plan, approval)
    if args.command == "check-approval":
        print(approval["plan_sha256"])
        return
    spec = load(args.spec)
    checks, by_item = validate_spec(items, plan, approval, spec)
    if args.command == "render-spec":
        require(args.markdown.resolve() != args.rtm.resolve()
                and not args.markdown.exists() and not args.rtm.exists(), "交付路径重复或已存在")
        markdown, rtm = specification_documents(plan, spec, items, by_item)
        write(args.markdown, markdown)
        write(args.rtm, rtm, encoding="utf-8-sig")
    else:
        results = load(args.results) if args.results else None
        write(args.output, render_coverage(plan, spec, items, checks, by_item, results))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("FPGA_SIM_ERROR: " + str(error), file=sys.stderr)
        sys.exit(2)
