---
name: fpga-spec-code-consistency
description: 对照 FPGA 需求规格说明与实际 RTL、Vivado 或 Libero 工程，提取代码架构并逐条核验功能、接口、性能和时钟复位等需求，交付带原文及实现证据的文实一致性报告。适用于 Windows 7 DeepSeek Harness。
---

# FPGA 文实一致性检查

输入为当前规格书（DOCX、UTF-8 Markdown 或 UTF-8 TXT）和待检查的工程或 RTL。由用户选择 **直接读取工程**（`existing_project`）或 **自建工程读取**（`temporary_project`）。选择尚未表达且输入只支持一种方式时，可按明确的输入推定并记录。两种方式均可执行时沿用用户选择，缺少选择时请用户指定。

1. 按[运行接口](references/runtime.md)从 Harness 调用 `prepare`，建立保留章节、段落及表格单元格的 `structure.json`。逐元素清点，并按[审查规则和数据格式](references/review.md)把规范性声明拆成可独立判定的原子需求。原子需求保留规格原编号和原文字段证据。
2. 按[架构提取](references/architecture.md)准备选定模式的配置并运行 `architecture`。从实际工程顶层或临时工程顶层向下确认实例、端口、连接、有效参数和依赖，从必要位置回查 RTL。记录工具展开未覆盖的部分及原因。器件型号只在工具需要时使用。
3. 从顶层接口或触发事件追到实际实现，逐项比对条件、约束、边界、异常与恢复。用当前版本的 RTL、工程导出和已有仿真或实现报告取证。把无法确认的条件写入受影响的条目，并按[证据缺口处理](references/review.md#证据缺口处理)准备向设计师询问的问题。依据设计师的选择记录询问或本次忽略，同时继续检查其余条目。
4. 写入审查模型，用[设计师可直接处理的措辞](references/review.md#面向设计师的报告)整理差异、待澄清条款和证据缺口。调用 `report` 验证摘录和覆盖关系。向设计师交付 `report.md`，同时提供可从条款跳转的 `report-evidence.md` 和供 Harness 加载的 `report.json`。

Python 3.8.10 标准库负责抽取、校验和生成报告，Harness 中的模型负责语义判断。按用户选定的模式和配置执行两种入口。遇到工具不可用或展开不完整，可在同一检查内补查源码，并在报告保留工具结果和限制。

宿主仅提供文件工具时，可使用外部执行方生成并绑定当前输入的结构及工程证据，参照[复用和交接](references/runtime.md#仅文件工具时的复用和交接)完成语义审查并交出审查模型，由外部执行方校验和生成报告。
