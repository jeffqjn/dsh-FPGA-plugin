# 文实审查和报告输入

## 拆解规格和核验实际实现

沿用需求规格文文检查的结构化方法。先按章节树清点段落、表格行列、图示、附录、引用及未读对象，再从规范性声明提取主体／对象、适用条件、触发及输入、预期行为和输出、限制值及单位、异常及恢复、测量或验证条件。同一编号下多个独立义务分别建项并保留原编号。保留同一义务的多处声明，原文冲突则给出各位置并标为 `spec_ambiguous`。图未读或悬挂引用应登记未覆盖原因。DOCX 的 `embedded_object` 保留所在章节和 OOXML 关系 ID，未核验内容时按未读对象清点。

- 功能核对事件触发、状态和数据流、异常和恢复分支，按实际实例核对参数。
- 接口核对端口方向、位宽、寄存器地址及位域，还有握手、有效极性、协议时序和错误响应。
- 性能先核对工况、起止事件、时钟和单位。按同一对输出事件推导固定周期，计入分频计数器的起止值、状态切换和字节边界。背压或跨域下的最坏时延需要支持该界限的证据。实际频率、时序裕量和资源用量使用与目标构建相符的工具报告。
- 帧格式逐区段核对使用数据和填充字节的实际分支，区分有效载荷长度、协议数据单元总长与编码后总长。
- 时钟、复位和 CDC 检查信号来源、有效条件、跨域路径、复位释放和真实启用的约束或同步结构。
- 必要时反向核对规格未描述的外部可见行为。额外的内部实例本身无需登记为差异。

结论使用 `consistent`、`inconsistent`、`not_implemented`、`insufficient_evidence`、`spec_ambiguous`、`not_applicable`。前两项需要同一条件下的实际证据。判定 `not_implemented` 时引用活动工程范围和已排查实现路径，说明排查如何覆盖该义务。缺宏、黑盒、报告过期或只查了单一工况时，用 `insufficient_evidence` 标记相应条目。明确限定的选定配置若确实排除了条款的适用条件，可据此用 `not_applicable`。

## 审查模型

模型由当前审查者填写。`spec_sha256` 取 `prepare` 的返回值，`architecture_sha256` 取 `architecture` 的返回值。下面展示单条需求和关联架构的形状。原文清点按本轮 `structure.json` 补全每个元素 UID。

```json
{
  "schema": "fpga-spec-code.review-input.v1",
  "spec_sha256": "prepare 返回的规格文件摘要",
  "architecture_sha256": "architecture 返回的工程证据文件摘要",
  "scope": "检查目标版本的正常与异常接收路径，复核当前顶层配置",
  "architecture": {
    "top": "fpga_top",
    "limits": [],
    "instances": [
      {
        "path": "fpga_top/u_rx",
        "module": "receiver",
        "parameters": {"TIMEOUT_CYCLES": 12},
        "evidence": [{"kind": "tool", "line": 42}]
      }
    ]
  },
  "inventory": {
    "element:example-heading": {"disposition": "context"},
    "element:example-row": {"disposition": "modeled"}
  },
  "requirements": [
    {
      "id": "PREQ-012.1",
      "source_id": "PREQ-012",
      "topic": "performance",
      "condition": "正常接收，无背压，从接收握手到结果有效沿",
      "expected": "8 个时钟周期内输出结果",
      "actual": "同一工况下第 12 拍结果有效",
      "basis": "从握手装载计数器，输出有效条件在计数达到 11 时于下一拍生效",
      "status": "inconsistent",
      "instance_paths": ["fpga_top/u_rx"],
      "spec_evidence": [{"element_uid": "element:example-row", "row": 2, "column": 1, "quote": "8 个时钟周期内"}],
      "implementation_evidence": [
        {"kind": "rtl", "path": "rx/receiver.sv", "line": 83, "end_line": 85, "quote": "if (count == TIMEOUT_CYCLES - 1)"},
        {"kind": "tool", "line": 42}
      ]
    }
  ],
  "undocumented_behavior": []
}
```

- `topic` 可取 `function`、`interface`、`performance`、`clock_reset_cdc`、`reliability`、`other`。原子项 ID 唯一。待补材料、规格澄清和未实现条目在 `follow_up` 写明需补信息或排查范围。
- 文档表格证据的行列从零开始。不同单元格里的字段或限定条件分别引用。`inventory` 用 `modeled`、`context`、`out_of_scope`、`unresolved` 标记，后两项填写 `reason`。未读内容采用 `unresolved` 并说明可能影响。
- 实现证据的文件行号从一开始，区间包含两端。路径可用工程或源码根目录相对路径，也可使用绝对路径。类型为 `rtl`、`constraint`、`report`、`configuration`、`tool_export` 或 `tool`。前五种需原文摘录，可用指定行内逐字可定位的短串；多行摘录中的换行与制表符按 JSON 字符串转义。 `tool` 的行号对应 `records[].line`。
- `architecture.top` 未确认时可填 `null` 并在 `limits` 记录原因。实例路径以顶层为首段，保留中间父级和取证点。建议在架构对象或实例上记录经确认的端口、连线、参数和功能职责，字段会保留在 JSON 中。实际连线或参数的口径应可通过实例证据或关联需求复核。
- `undocumented_behavior` 的每项填写 `actual`、`basis` 和 `evidence`，说明可见行为及已检索的规格范围。

## 面向设计师的报告

主报告开头给范围、条目数和结果。按文实差异、缺少实现、规格待确认、验证证据缺口列出需要处理的事。每项用一句写清规格要求、实际行为和下一步，已知的实际影响可另起一行。性能差异在主报告直接给出目标值、实际值及适用工况，并说明是源码推导还是实测。规格口径有冲突时，把需要规格方决定的定义写清楚。证据不足时写具体需要的波形、测试报告或源码范围。动作建议依证据提出，避免把待验证的风险描述成已发生的故障。

描述代码覆盖时，分别写明递归发现并纳入工程的文件数、实际展开或源码索引覆盖的层级，以及逐需求报告直接引用的 RTL 文件数。声称逐文件或逐模块审查时，应有对应的审查记录。未形成直接引用的文件，其取证情况按已有记录说明。

在模型的 `presentation.scope` 填写简短检查范围和主要限制。对需处理的条目填写可选 `presentation` 对象，包含 `title`、`expected`、`actual`、`impact` 和 `action`，均用文本。标题写具体信号或行为，例如“星时接口速率低于 1 Mbps”。多项条款指向同一设计问题、适用条件与结论一致时，可设置相同的 `presentation.group`。首项的文案用于主报告，并列出每条证据链接。规格未描述的行为可填写 `presentation.title`、`actual`、`action`。较早的审查模型可直接生成报告，主报告沿用已填写的审查文字。

工具日志、展开配置、完整的逐项判定与摘录放在 `report-evidence.md`。`report.json` 保留结论、清点和可追溯证据。为主报告压缩措辞时，保留原始判定字段和引用供逐条复核。

## 证据缺口处理

用 `evidence_gaps` 记录需要补材料或向设计师确认的具体问题。先说明已经核对的源码位置、尚需确认的行为，以及回答所需的材料。一个缺口可关联多个需求。架构或逐文件审查中独立发现的缺口也可记录，在描述中注明文件和实例路径。

```json
{
  "evidence_gaps": [
    {
      "id": "RAM-RESET",
      "description": "遥测缓存的 RAM 封装端口已核对。缺少 RAM IP 的配置或模型，无法确认初始化和复位后的数据行为。",
      "requirement_ids": [],
      "question": "请提供 twoports_ram 的生成参数或仿真模型，并确认复位后由哪层逻辑丢弃旧帧。",
      "action": "pending"
    }
  ]
}
```

插件对每个缺口提供两个选项。

- **询问设计师**写入 `ask_designer`，通过当前会话或插件问题卡展示 `question`。有待答复的问题可随本轮报告交付。收到新证据后复查关联条款。
- **忽略本次**写入 `ignore`，可附 `note`。主报告注明本次忽略及尚缺的证据。仍按原条款判定汇总。

没有选择时记录 `pending`，也可省略 `action`。只有设计师明确选择后才写入 `ignore`。这些字段用于处理缺口，条款结论仍由证据支持。新版本复查时核实缺口是否仍存在，再采用原有选择。
