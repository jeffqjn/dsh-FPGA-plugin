"""Collect project evidence with the selected vendor tool."""
import os
from pathlib import Path
import re
import shutil
import subprocess

from support import existing, inside, require, save
from source_hierarchy import candidates

HDL = {".v", ".sv", ".vh", ".svh", ".vhd", ".vhdl"}
DESIGN = HDL | {".xci", ".xcix", ".bd", ".edn", ".edf", ".dcp"}
CONSTRAINTS = {".xdc", ".sdc", ".pdc", ".fdc", ".ndc"}
MANIFESTS = {".tcl", ".f", ".prj", ".do", ".flist"}
EXTENSIONS = DESIGN | CONSTRAINTS | MANIFESTS
SIM_DIRS = {"tb", "testbench", "testbenches", "sim", "simulation", "test", "tests"}


def inventory(root):
    hits = []
    for base, dirs, files in os.walk(str(root)):
        dirs[:] = sorted(name for name in dirs if not name.startswith("."))
        for name in sorted(files):
            entry = Path(base) / name
            suffix = entry.suffix.lower()
            if suffix not in EXTENSIONS:
                continue
            relative = entry.relative_to(root)
            if suffix in MANIFESTS:
                kind = "build_hint"
            elif suffix in CONSTRAINTS:
                kind = "constraint_candidate"
            elif ({part.lower() for part in relative.parts[:-1]} & SIM_DIRS
                  or re.search(r"(^tb_|_tb$|^testbench|_testbench$)", entry.stem, re.I)):
                kind = "simulation_candidate"
            else:
                kind = "design_candidate"
            hits.append({"path": relative.as_posix(), "kind": kind})
    return hits


def tool_path(provider, given, base):
    override = given or os.environ.get("FPGA_" + provider.upper())
    if override:
        return existing(override, base)
    located = shutil.which(provider)
    return Path(located).resolve() if located else None


def collect(config, base, output):
    mode = config["mode"]
    require(mode in ("existing_project", "temporary_project"), "必须选择一种架构提取模式")
    project = None
    design_paths = []
    rows = [("mode", mode)]
    limits = []
    if mode == "existing_project":
        project = existing(config["project"], base)
        provider = {".xpr": "vivado", ".prjx": "libero"}.get(project.suffix.lower())
        require(provider, "原工程须为 .xpr 或 .prjx")
        root = project.parent
        rows.append(("top", config.get("component_hint", "") if provider == "libero" else ""))
    else:
        provider = "vivado"
        root = existing(config["source_root"], base, directory=True)
        top = config.get("top")
        require(isinstance(top, str) and top.strip(), "临时工程需要确定用于展开的顶层")
        require(bool(str(config.get("top_basis", "")).strip()), "临时工程需要记录顶层的选择依据")
        rows.extend([("top", top), ("part", config.get("part", ""))])
        sources = config.get("sources")
        require(isinstance(sources, list) and sources, "请提供按用途整理的 sources 清单")
        used = set()
        design_count = 0
        for entry in sources:
            source = existing(entry["path"], root)
            role = entry["role"]
            suffix = source.suffix.lower()
            require(role in ("design", "simulation", "constraint"), "未知源集 " + role)
            allowed = {".xdc", ".sdc"} if role == "constraint" else (HDL if role == "simulation" else DESIGN)
            require(suffix in allowed, "源文件类型与源集不匹配 " + str(source))
            require((source, role) not in used, "重复源文件 " + str(source))
            used.add((source, role))
            design_count += role == "design"
            if role == "design":
                design_paths.append(source)
            rows.append(("source", source.as_posix(), role, entry.get("library", ""), entry.get("file_type", "")))
        require(design_count, "至少需要一个设计源")
        for name, key in (("include_dirs", "include_dir"), ("defines", "define"), ("generics", "generic")):
            values = config.get(name, [])
            require(isinstance(values, list) and all(isinstance(v, str) and v for v in values),
                    name + " 需要字符串数组")
            for value in values:
                rows.append((key, existing(value, root, directory=True).as_posix() if key == "include_dir" else value))
        if not config.get("part"):
            limits.append("临时器件由工具从本机已安装器件中选择，仅用于 RTL 展开。")

    require(not inside(output, root), "架构输出目录须位于工程或源码目录之外")
    try:
        tool = tool_path(provider, config.get("tool"), base)
    except (OSError, ValueError) as error:
        tool = None
        limits.append(str(error))
    output.mkdir(parents=True)
    result = {
        "schema": "fpga-spec-code.architecture-evidence.v1",
        "mode": mode, "provider": provider, "root": str(root),
        "project": str(project) if project else None, "tool": str(tool) if tool else None,
        "configuration": config, "evidence_directory": str(output), "status": "unavailable",
        "limits": limits, "records": [], "exports": [],
    }
    if tool is None:
        limits.append("未找到本机工具 " + provider)
    else:
        try:
            run_tool(tool, provider, project, rows, output, result)
        except (OSError, ValueError, subprocess.TimeoutExpired) as error:
            limits.append(str(error))
    result["observed_configuration"] = [
        record for record in result["records"] if record["kind"] in ("top", "tool_version", "part", "setting", "snapshot")
    ]
    if result["status"] != "elaborated":
        if project is not None and provider == "vivado":
            top = next((row["fields"][0] for row in result["records"] if row["kind"] == "top"), None)
            design_paths = [Path(row["fields"][0]) for row in result["records"] if row["kind"] == "source"]
        else:
            top = config.get("top") if project is None else None
        if top and design_paths:
            result["source_hierarchy"] = candidates(design_paths, top)
            limits.extend(result["source_hierarchy"]["limits"])
    save(output / "architecture_evidence.json", result)
    return result


def run_tool(tool, provider, project, rows, output, result):
    rows.append(("provider", provider))
    if project is not None:
        if provider == "libero":
            # Libero can convert an older project on open. Use a copy as its working project.
            copy = output / "libero"
            shutil.copytree(str(project.parent), str(copy), symlinks=True)
            project = copy / project.name
            result["limits"].append("Libero 使用工程副本，跨工程目录的相对链接需核对。")
        rows.append(("project", project.as_posix()))
    request = ["\t".join([name] + [value.encode("utf-8").hex() for value in values]) for name, *values in rows]
    (output / "request.tsv").write_text("\n".join(request) + "\n", encoding="ascii")
    shutil.copyfile(str(Path(__file__).with_name("driver.tcl")), str(output / "driver.tcl"))
    args = (["-mode", "batch", "-source", "driver.tcl", "-nojournal", "-nolog"] if provider == "vivado"
            else ["SCRIPT:driver.tcl", "LOGFILE:libero.log"])
    timeout = result["configuration"].get("timeout_seconds", 600)
    require(type(timeout) is int and timeout > 0, "timeout_seconds 须为正整数")
    with (output / "tool.log").open("wb") as log:
        try:
            run = subprocess.run([str(tool)] + args, cwd=str(output), stdout=log, stderr=subprocess.STDOUT,
                                 timeout=timeout, check=False)
            result["exit_code"] = run.returncode
        except subprocess.TimeoutExpired:
            result["limits"].append("工具提取超过 {} 秒，保留已生成的证据。".format(timeout))

    records_path = output / "design.tsv"
    if records_path.is_file():
        records = result["records"]
        for number, line in enumerate(records_path.read_text(encoding="ascii").splitlines(), 1):
            kind, *values = line.split("\t")
            try:
                fields = [bytes.fromhex(value).decode("utf-8") for value in values]
            except ValueError:
                result["limits"].append("无法解码工具记录第 {} 行。".format(number))
                continue
            records.append({"line": number, "kind": kind, "fields": fields})
            if kind in ("error", "limitation"):
                result["limits"].extend(fields)
        if records:
            kinds = {record["kind"] for record in records}
            completed = records[-1]["kind"] == "complete" and result.get("exit_code") == 0
            result["status"] = "elaborated" if completed and "elaborated" in kinds else "partial"
    for filename in ("design.tsv", "tool.log", "libero.log", "libero-summary.html", "libero-component.tcl"):
        if (output / filename).is_file():
            result["exports"].append(filename)
    if result["status"] != "elaborated" and provider == "vivado":
        result["limits"].append("Vivado 未完成 RTL 展开。请查阅工具日志并补查可确认的源码路径。")
        diagnostics = []
        with (output / "tool.log").open("rb") as log:
            for number, line in enumerate(log, 1):
                if line.lstrip().startswith((b"ERROR:", b"CRITICAL WARNING:", b"couldn't read file")):
                    diagnostics.append({"line": number, "message": line.decode("utf-8", errors="replace").strip()})
        result["diagnostics"] = diagnostics[:20]
        result["diagnostic_count"] = len(diagnostics)
