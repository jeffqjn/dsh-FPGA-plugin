# Input values are hex-encoded UTF-8 fields. They are handled as Tcl data.
set evidence_dir [file dirname [file normalize [info script]]]
set input [open [file join $evidence_dir request.tsv] r]
array set cfg {}
array set many {}
while {[gets $input line] >= 0} {
    set fields [split $line "\t"]
    set key [lindex $fields 0]
    set values {}
    foreach field [lrange $fields 1 end] {
        lappend values [encoding convertfrom utf-8 [binary format H* $field]]
    }
    if {[llength $values] == 1} {
        set cfg($key) [lindex $values 0]
    }
    lappend many($key) $values
}
close $input
set records [open [file join $evidence_dir design.tsv] w]
fconfigure $records -translation lf -encoding ascii -buffering line

proc record {kind args} {
    global records
    set line [list $kind]
    foreach value $args {
        binary scan [encoding convertto utf-8 $value] H* hex
        lappend line $hex
    }
    puts $records [join $line "\t"]
}

proc property {name object} {
    if {[catch {get_property -quiet $name $object} value]} {
        return ""
    }
    return $value
}

proc vivado_design {} {
    global cfg many evidence_dir
    record tool_version [version -short]
    if {$cfg(mode) eq "existing_project"} {
        open_project -read_only $cfg(project)
        # Older Vivado versions can require a writable project for RTL elaboration.
        foreach src [get_files -compile_order sources -used_in synthesis] {
            record original_source [get_property NAME $src] [property FILE_TYPE $src] [property LIBRARY $src]
        }
        set copied_dir [file join $evidence_dir project_copy]
        save_project_as audit_snapshot $copied_dir
        close_project
        set snapshot [file join $copied_dir audit_snapshot.xpr]
        open_project $snapshot
        record snapshot $snapshot
    } else {
        set part $cfg(part)
        if {$part eq ""} {
            foreach preferred {xc7a35tcpg236-1 xc7z020clg400-1} {
                set installed [get_parts -quiet $preferred]
                if {[llength $installed]} {
                    set part [get_property NAME [lindex $installed 0]]
                    break
                }
            }
            if {$part eq ""} {
                set installed [lsort [get_parts -quiet]]
                if {![llength $installed]} {error "No Vivado device data available"}
                set part [get_property NAME [lindex $installed 0]]
            }
        }
        create_project inspection [file join $evidence_dir vivado] -part $part
        foreach source $many(source) {
            lassign $source path role library file_type
            set fileset [dict get {design sources_1 simulation sim_1 constraint constrs_1} $role]
            set added [add_files -norecurse -fileset $fileset $path]
            if {$library ne ""} {set_property LIBRARY $library $added}
            if {$file_type ne ""} {set_property FILE_TYPE $file_type $added}
        }
        set sources [current_fileset]
        set_property TOP $cfg(top) $sources
        foreach {key prop} {include_dir INCLUDE_DIRS define VERILOG_DEFINE generic GENERIC} {
            if {[info exists many($key)]} {
                set list_value {}
                foreach value $many($key) {lappend list_value [lindex $value 0]}
                set_property $prop $list_value $sources
            }
        }
    }
    set sources [current_fileset]
    update_compile_order -fileset $sources
    set top [get_property TOP $sources]
    if {$top eq ""} {error "Project design top is unresolved"}
    record top $top
    record part [get_property PART [current_project]]
    foreach prop {INCLUDE_DIRS VERILOG_DEFINE GENERIC} {
        foreach value [property $prop $sources] {record setting $prop $value}
    }
    foreach src [get_files -compile_order sources -used_in synthesis] {
        record source [get_property NAME $src] [property FILE_TYPE $src] [property LIBRARY $src]
    }
    synth_design -rtl -name inspection_rtl
    record elaborated $top
    foreach port [get_ports -quiet] {
        record port [get_property NAME $port] [property DIRECTION $port] \
            [property BUS_NAME $port] [property BUS_START $port] [property BUS_STOP $port]
    }
    foreach cell [get_cells -quiet -hierarchical] {
        set name [get_property NAME $cell]
        set ref [property REF_NAME $cell]
        set blackbox [property IS_BLACKBOX $cell]
        record instance $name $ref [property ORIG_REF_NAME $cell] $blackbox [property IS_PRIMITIVE $cell]
        if {$blackbox in {1 true TRUE}} {record limitation "Black box: $name"}
        # Keep instance properties that the tool exposes. RTL parameters may require source tracing.
        foreach prop [list_property $cell] {
            if {[string match CONFIG.* $prop]} {record parameter $name $prop [property $prop $cell]}
        }
    }
    foreach net [get_nets -quiet -hierarchical] {
        set name [get_property NAME $net]
        foreach pin [get_pins -quiet -of_objects $net] {
            record connection $name pin [get_property NAME $pin] [property DIRECTION $pin]
        }
        foreach port [get_ports -quiet -of_objects $net] {
            record connection $name port [get_property NAME $port] [property DIRECTION $port]
        }
    }
}

proc libero_design {} {
    global cfg evidence_dir
    open_project -file $cfg(project)
    record opened $cfg(project)
    if {[catch {build_design_hierarchy} message]} {record limitation $message}
    set summary [file join $evidence_dir libero-summary.html]
    if {[catch {export_design_summary -file $summary} message] || ![file isfile $summary]} {
        record limitation "Root SmartDesign summary unavailable: $message"
    } else {
        record exported libero-summary.html
    }
    if {$cfg(top) ne ""} {
        set exported [file join $evidence_dir libero-component.tcl]
        if {[catch {export_component_to_tcl -component $cfg(top) -file $exported} message] ||
                ![file isfile $exported]} {
            record limitation "Component description unavailable: $message"
        } else {
            record component_hint $cfg(top)
            record exported libero-component.tcl
        }
    }
    close_project -save 0
}

if {[catch {
    if {$cfg(provider) eq "vivado"} {vivado_design} else {libero_design}
} message]} {
    record error $message
    close $records
    puts stderr $message
    exit 1
}
record complete $cfg(provider)
close $records
exit 0
