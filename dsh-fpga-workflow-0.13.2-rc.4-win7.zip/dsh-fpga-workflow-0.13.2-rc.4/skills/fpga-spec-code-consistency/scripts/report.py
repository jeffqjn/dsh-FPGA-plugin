"""Validate evidence references and render one review model to JSON and Markdown."""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import re

from support import digest, existing, load, read_source, require, save

STATUSES = {
    "consistent": "一致", "inconsistent": "不一致", "not_implemented": "未实现",
    "insufficient_evidence": "证据不足", "spec_ambiguous": "规格待澄清", "not_applicable": "不适用",
}
TOPICS = {
    "function": "功能", "interface": "接口", "performance": "性能",
    "clock_reset_cdc": "时钟／复位／跨域", "reliability": "可靠性", "other": "其他",
}
DISPOSITIONS = {"modeled", "context", "out_of_scope", "unresolved"}
ISSUE_SECTIONS = {
    "inconsistent": "需要处理的文实差异", "not_implemented": "缺少实现的需求",
    "spec_ambiguous": "需要确认的规格口径", "insufficient_evidence": "需要补充的验证证据",
}
GAP_ACTIONS = {
    "pending": "待选择",
    "ask_designer": "待设计师答复",
    "ignore": "本次忽略（证据仍缺）",
}


def plain(value):
    return re.sub(r"([\\`*_{}\[\]()<>!&#|~])", r"\\\1", " ".join(str(value).splitlines()))


def doc_locator(archive):
    elements = {entry["uid"]: entry for entry in archive["elements"]}
    sections = {entry["uid"]: entry for entry in archive["sections"]}

    def element_location(uid):
        element = elements[uid]
        section = sections.get(element["section_uid"], {})
        trail = []
        visited = set()
        while section:
            require(section["uid"] not in visited, "规格章节树存在循环引用 " + uid)
            visited.add(section["uid"])
            trail.append(" ".join(value for value in (section.get("number"), section.get("title")) if value))
            section = sections.get(section.get("parent_uid"))
        return "，".join(filter(None, (" › ".join(reversed(trail)), element["part"],
                                       "元素 " + str(element["order"]))))

    def locate(ref):
        uid = ref["element_uid"]
        element = elements[uid]
        quote = ref["quote"].strip()
        require(quote, "规格摘录不能为空 " + uid)
        row, column = ref.get("row"), ref.get("column")
        location = element_location(uid)
        if element["kind"] == "table":
            require(type(row) is int and type(column) is int, "表格证据需要行列坐标 " + uid)
            cells = [c for c in element["cells"] if c["row"] <= row < c["row"] + c["row_span"]
                     and c["column"] <= column < c["column"] + c["column_span"]]
            require(len(cells) == 1, "找不到表格单元格 " + uid)
            cell = cells[0]
            source = cell["text"]
            row, column = cell["row"], cell["column"]
            location += "，第 {} 行第 {} 列".format(row + 1, column + 1)
        else:
            require(row is None and column is None, "非表格证据不应填写行列 " + uid)
            source = element["text"]
        require(quote in source, "规格摘录无法在原文定位 " + uid)
        return dict(ref, quote=quote, row=row, column=column, location=location)

    return elements, locate, element_location


def implementation_locator(architecture):
    raw = {record["line"]: record for record in architecture["records"]}
    root = Path(architecture["root"])
    tool_records = Path(architecture["evidence_directory"]) / "design.tsv"

    @lru_cache(maxsize=64)
    def source_lines(path):
        before = digest(path)
        lines = read_source(path).splitlines()
        require(before == digest(path), "读取期间文件发生变化 " + str(path))
        return lines, before

    def locate(ref):
        if ref["kind"] == "tool":
            line = ref["line"]
            require(type(line) is int and line in raw, "找不到工具证据记录")
            return dict(ref, location="{} 第 {} 行".format(tool_records, line), record=raw[line])
        require(ref["kind"] in ("rtl", "constraint", "report", "configuration", "tool_export"),
                "未知实现证据类型 " + ref["kind"])
        path = existing(ref["path"], root)
        start, end = ref["line"], ref.get("end_line", ref["line"])
        lines, sha = source_lines(path)
        require(type(start) is int and type(end) is int and 1 <= start <= end <= len(lines),
                "实现证据行号无效 " + str(path))
        quote = ref["quote"].strip().replace("\r\n", "\n")
        require(quote and quote in "\n".join(lines[start - 1:end]), "实现摘录无法定位 " + str(path))
        return dict(ref, path=str(path), location="{} 第 {}–{} 行".format(path, start, end),
                    quote=quote, sha256=sha)

    return locate


def meaningful(item, key):
    value = item.get(key)
    require(isinstance(value, str) and value.strip(), "缺少有效字段 " + key)
    return value.strip()


def validate_presentation(item, label, fields):
    if "presentation" in item:
        view = item["presentation"]
        require(isinstance(view, dict), "{} 的报告文案须为对象".format(label))
        for key in fields:
            if key in view:
                meaningful(view, key)


def locate_evidence(refs, locate, label):
    resolved = []
    for index, ref in enumerate(refs, 1):
        try:
            resolved.append(locate(ref))
        except (ValueError, KeyError, OSError, TypeError) as error:
            raise ValueError("{} 第 {} 项证据：{}".format(label, index, error)) from error
    return resolved


def validate_gaps(gaps, requirement_ids):
    require(isinstance(gaps, list), "证据缺口须为列表")
    identifiers = set()
    normalized = []
    for gap in gaps:
        require(isinstance(gap, dict), "每项证据缺口须为对象")
        identifier = meaningful(gap, "id")
        require(identifier not in identifiers, "证据缺口 ID 重复 " + identifier)
        identifiers.add(identifier)
        meaningful(gap, "description")
        action = gap.get("action", "pending")
        require(isinstance(action, str) and action in GAP_ACTIONS, "未知证据缺口处理方式 " + identifier)
        if action == "ask_designer" or "question" in gap:
            meaningful(gap, "question")
        if "note" in gap:
            meaningful(gap, "note")
        linked = gap.get("requirement_ids", [])
        require(isinstance(linked, list) and all(isinstance(uid, str) and uid in requirement_ids for uid in linked),
                "证据缺口引用了未知需求 " + identifier)
        normalized.append(dict(gap, id=identifier, action=action, requirement_ids=linked))
    return normalized


def normalize(structure, architecture, model):
    require(architecture["schema"] == "fpga-spec-code.architecture-evidence.v1", "不支持的工程证据格式")
    require(model["schema"] == "fpga-spec-code.review-input.v1", "不支持的审查模型格式")
    require(model["spec_sha256"] == structure["source"]["sha256"], "审查模型绑定的规格版本有误")
    elements, spec_evidence, element_location = doc_locator(structure["archive"])
    implementation_evidence = implementation_locator(architecture)
    scope = meaningful(model, "scope")
    validate_presentation(model, "整份报告", ("scope",))
    tree = model["architecture"]
    top = tree["top"]
    require(top is None or isinstance(top, str) and top.strip(), "架构顶层须为名称或 null")
    tool_tops = {record["fields"][0] for record in architecture["records"] if record["kind"] == "top"}
    require(not tool_tops or top in tool_tops, "架构顶层与工具记录不符")
    instances = {}
    for instance in tree["instances"]:
        path = meaningful(instance, "path")
        require(top and (path == top or path.startswith(top + "/")) and path not in instances,
                "实例路径重复或未落在顶层下 " + path)
        meaningful(instance, "module")
        refs = instance["evidence"]
        require(isinstance(refs, list) and refs, "实例路径需要证据 " + path)
        instances[path] = dict(instance, evidence=locate_evidence(refs, implementation_evidence, path))
    for path in instances:
        parent = path.rpartition("/")[0]
        require(path == top or parent == top or parent in instances, "缺少实例父级 " + path)
    limits = tree["limits"]
    require(isinstance(limits, list) and all(isinstance(v, str) and v.strip() for v in limits),
            "架构限制须为文本数组")
    require(top or limits, "未确认顶层时需要登记证据缺口")
    rows, identifiers, covered = [], set(), set()
    for row in model["requirements"]:
        identifier = meaningful(row, "id")
        validate_presentation(row, identifier, ("title", "group", "expected", "actual", "impact", "action"))
        require(identifier not in identifiers, "需求 ID 重复 " + identifier)
        identifiers.add(identifier)
        for field in ("condition", "expected", "actual", "basis"):
            meaningful(row, field)
        status = row["status"]
        require(status in STATUSES and row["topic"] in TOPICS, "无效结论或需求分类 " + identifier)
        require(row["spec_evidence"], "每条需求需要规格原文证据 " + identifier)
        doc_refs = locate_evidence(row["spec_evidence"], spec_evidence, identifier + " 规格")
        covered.update(ref["element_uid"] for ref in doc_refs)
        refs = locate_evidence(row["implementation_evidence"], implementation_evidence, identifier + " 实现")
        require(status not in ("consistent", "inconsistent", "not_implemented") or refs,
                "此结论需要实际实现证据 " + identifier)
        if status in ("insufficient_evidence", "spec_ambiguous", "not_implemented"):
            meaningful(row, "follow_up")
        paths = row.get("instance_paths", [])
        require(all(path == top or path in instances for path in paths), "未知实例路径 " + identifier)
        rows.append(dict(row, spec_evidence=doc_refs, implementation_evidence=refs))
    inventory = model["inventory"]
    require(set(inventory) == set(elements), "原文清点必须覆盖 structure.json 的全部元素")
    normalized_inventory = {}
    for uid, entry in inventory.items():
        disposition = entry["disposition"]
        require(disposition in DISPOSITIONS, "无效的原文清点状态 " + uid)
        require((uid in covered) == (disposition == "modeled"), "需求映射与原文清点不符 " + uid)
        if disposition in ("out_of_scope", "unresolved"):
            meaningful(entry, "reason")
        element = elements[uid]
        normalized_inventory[uid] = dict(entry, kind=element["kind"], read_status=element["read_status"],
                                         location=element_location(uid))
    extras = []
    for extra in model.get("undocumented_behavior", []):
        validate_presentation(extra, "规格未描述的行为", ("title", "actual", "action"))
        meaningful(extra, "actual")
        meaningful(extra, "basis")
        require(extra["evidence"], "额外行为需要实现证据")
        extras.append(dict(extra, evidence=[implementation_evidence(ref) for ref in extra["evidence"]]))
    counts = Counter(row["status"] for row in rows)
    result = {
        "schema": "fpga-spec-code.report.v1", "specification": structure["source"],
        "spec_extraction_status": structure["archive"]["extraction_status"],
        "spec_limits": structure["archive"]["limitations"], "scope": scope,
        "architecture_evidence": {k: v for k, v in architecture.items() if k != "records"},
        "architecture": dict(tree, instances=list(instances.values())),
        "counts": {key: counts[key] for key in STATUSES}, "requirements": rows,
        "inventory": normalized_inventory, "undocumented_behavior": extras,
    }
    if "presentation" in model:
        result["presentation"] = model["presentation"]
    if "evidence_gaps" in model:
        result["evidence_gaps"] = validate_gaps(model["evidence_gaps"], identifiers)
    return result


def references(identifiers, anchors):
    return " · ".join("[{}](report-evidence.md#{})".format(plain(uid), anchors[uid]) for uid in identifiers)


def render(result, anchors):
    rows = result["requirements"]
    counts = result["counts"]
    scope = result.get("presentation", {}).get("scope", result["scope"])
    top = result["architecture"]["top"] or "待确认"
    source = result["specification"]["name"]
    lines = ["# FPGA 文实一致性检查报告", "", "## 检查结果", "",
             "本轮对照《{}》和顶层 **{}** 的实现，共评审 **{} 条**原子需求。".format(
                 plain(source), plain(top), len(rows)), "",
             " · ".join("{} **{}**".format(label, counts[key]) for key, label in STATUSES.items()), "",
             plain(scope), "",
             "[查看逐条证据与检查范围](report-evidence.md) · [下载结构化结果](report.json)"]
    for status, heading in ISSUE_SECTIONS.items():
        groups = {}
        for row in rows:
            if row["status"] == status:
                group = row.get("presentation", {}).get("group")
                key = ("group", group) if group else ("row", row["id"])
                groups.setdefault(key, []).append(row)
        if not groups:
            continue
        lines.extend(["", "## " + heading])
        for group in groups.values():
            row = group[0]
            view = row.get("presentation", {})
            lines.extend(["", "### " + plain(view.get("title") or row.get("source_id") or row["id"]), ""])
            for label, value in (
                ("规格要求", view.get("expected") or row["expected"]),
                ("当前实现", view.get("actual") or row["actual"]),
                ("可能影响", view.get("impact")),
                ("下一步", view.get("action") or row.get("follow_up")),
            ):
                if value:
                    lines.append("- **{}** {}".format(label, plain(value)))
            lines.append("- **条款与证据** " + references((row["id"] for row in group), anchors))
    if result["undocumented_behavior"]:
        lines.extend(["", "## 规格未描述的行为", ""])
        for index, extra in enumerate(result["undocumented_behavior"], 1):
            view = extra.get("presentation", {})
            lines.append("- **{}** {} [证据](report-evidence.md#extra-{})".format(
                plain(view.get("title") or "外部行为待核对"), plain(view.get("actual") or extra["actual"]), index))
            if view.get("action"):
                lines.append("  - **下一步** " + plain(view["action"]))
    gaps = result.get("evidence_gaps", [])
    if gaps:
        lines.extend(["", "## 证据缺口处理记录", ""])
        for gap in gaps:
            lines.append("- **{}** · {}。{}".format(
                plain(gap["id"]), GAP_ACTIONS[gap["action"]], plain(gap["description"])))
            if gap["action"] == "ask_designer":
                lines.append("  - **请设计师确认** " + plain(gap["question"]))
            elif gap["action"] == "pending" and gap.get("question"):
                lines.append("  - **拟询问** " + plain(gap["question"]))
            if gap.get("note"):
                lines.append("  - **备注** " + plain(gap["note"]))
            if gap["requirement_ids"]:
                lines.append("  - **关联条款** " + references(gap["requirement_ids"], anchors))
    return "\n".join(lines) + "\n"


def render_evidence(result, anchors):
    spec = result["specification"]
    ev = result["architecture_evidence"]
    architecture = result["architecture"]
    lines = ["# FPGA 文实一致性逐条证据", "", "[返回检查报告](report.md)", "", "## 检查范围与版本", "",
             "- 规格 " + plain(spec["name"]),
             "- 规格 SHA-256 `{}`".format(spec["sha256"]),
             "- 代码范围 " + plain(ev["project"] or ev["root"]),
             "- 架构提取 `{}` · {} · 顶层 {}".format(ev["mode"], ev["provider"], plain(architecture["top"] or "待确认")),
             "- 工具证据目录 {}（{}）".format(plain(ev["evidence_directory"]), ev["status"]),
             "- 检查口径 " + plain(result["scope"]), "", "## 汇总", "",
             " · ".join("{} {}".format(label, result["counts"][key]) for key, label in STATUSES.items()), ""]
    pending = [(entry["location"], entry["reason"]) for entry in result["inventory"].values()
               if entry["disposition"] == "unresolved"]
    inventory_counts = Counter(entry["disposition"] for entry in result["inventory"].values())
    lines.append("原文清点 {} 个元素。已建模 {} 个，背景 {} 个，范围外 {} 个，待核实 {} 个。".format(
        len(result["inventory"]), inventory_counts["modeled"], inventory_counts["context"],
        inventory_counts["out_of_scope"], inventory_counts["unresolved"]))
    if not result["requirements"]:
        lines.append("本轮没有可判定的原子需求。")
    lines.extend(["", "## 配置与证据限制", ""])
    lines.extend("- " + plain(v) for v in result["spec_limits"] + ev["limits"] + architecture["limits"])
    for diagnostic in ev.get("diagnostics", ()):
        lines.append("- tool.log 第 {} 行 {}".format(diagnostic["line"], plain(diagnostic["message"])))
    for key in ("top_basis", "configuration_basis"):
        if ev["configuration"].get(key):
            lines.append("- " + plain(ev["configuration"][key]))
    configuration_labels = {"tool_version": "工具版本", "part": "展开使用的器件",
                            "setting": "生效配置", "snapshot": "展开使用的工程副本"}
    for record in ev["observed_configuration"]:
        if record["kind"] in configuration_labels:
            lines.append("- {} {}".format(configuration_labels[record["kind"]],
                                           plain(" · ".join(record["fields"]))))
    lines.extend("- 原文元素 {}。{}".format(plain(uid), plain(reason)) for uid, reason in pending)
    lines.extend(["", "## 逐条需求证据"])
    priority = ("inconsistent", "not_implemented", "insufficient_evidence",
                "spec_ambiguous", "consistent", "not_applicable")
    for status in priority:
        rows = [row for row in result["requirements"] if row["status"] == status]
        if not rows:
            continue
        lines.extend(["", "### {}（{} 条）".format(STATUSES[status], len(rows))])
        for row in rows:
            lines.extend(["", '<a id="{}"></a>'.format(anchors[row["id"]]), "",
                          "#### {} · {}".format(plain(row["id"]), TOPICS[row["topic"]]), "",
                          "- **规格要求** " + plain(row["expected"]), "- **当前实现** " + plain(row["actual"]),
                          "- **适用条件** " + plain(row["condition"]), "- **判定依据** " + plain(row["basis"])])
            if row.get("source_id"):
                lines.append("- **规格原编号** " + plain(row["source_id"]))
            if row.get("instance_paths"):
                lines.append("- **实例路径** " + plain("，".join(row["instance_paths"])))
            for ref in row["spec_evidence"]:
                lines.append("- **规格原文** " + evidence_text(ref))
            for ref in row["implementation_evidence"]:
                lines.append("- **实现证据** " + evidence_text(ref))
            if row.get("follow_up"):
                lines.append("- **待补或复核** " + plain(row["follow_up"]))
    if result["undocumented_behavior"]:
        lines.extend(["", "## 规格未描述的外部可见行为", ""])
        for index, extra in enumerate(result["undocumented_behavior"], 1):
            lines.extend(["", '<a id="extra-{}"></a>'.format(index), "",
                          "- **当前实现** " + plain(extra["actual"]), "- **判定依据** " + plain(extra["basis"])])
            lines.extend("- **实现证据** " + evidence_text(ref) for ref in extra["evidence"])
    lines.extend(["", "## 架构索引", ""])
    for item in architecture["instances"]:
        lines.append("- {}（{}）".format(plain(item["path"]), plain(item["module"])))
    return "\n".join(lines) + "\n"


def evidence_text(ref):
    value = " · ".join(ref["record"]["fields"]) if "record" in ref else ref["quote"]
    return "{}「{}」".format(plain(ref["location"]), plain(value))


def validate(structure_path, architecture_path, review_path):
    structure, architecture, review = map(load, (structure_path, architecture_path, review_path))
    require(digest(architecture_path) == review["architecture_sha256"], "审查模型绑定的工程证据版本有误")
    result = normalize(structure, architecture, review)
    result["architecture_evidence_sha256"] = review["architecture_sha256"]
    return result


def publish(structure_path, architecture_path, review_path, output):
    result = validate(structure_path, architecture_path, review_path)
    anchors = {row["id"]: "req-{}".format(index) for index, row in enumerate(result["requirements"], 1)}
    markdown = render(result, anchors)
    evidence = render_evidence(result, anchors)
    output.mkdir(parents=True)
    (output / "report.md").write_text(markdown, encoding="utf-8")
    (output / "report-evidence.md").write_text(evidence, encoding="utf-8")
    save(output / "report.json", result)
    return result["counts"]
