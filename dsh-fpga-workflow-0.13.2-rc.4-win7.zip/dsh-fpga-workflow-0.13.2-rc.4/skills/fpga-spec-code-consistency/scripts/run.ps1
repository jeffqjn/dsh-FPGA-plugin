#requires -version 2.0
param([string]$Action)
$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = $env:FPGA_PYTHON38
if ([string]::IsNullOrEmpty($pythonExe)) { $pythonExe = 'C:\Python38\python.exe' }
if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) {
    throw 'Set FPGA_PYTHON38 to the Python 3.8.10 executable.'
}
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUTF8 = '1'
& $pythonExe -B (Join-Path $scriptDir 'cli.py') $Action @args
exit $LASTEXITCODE
