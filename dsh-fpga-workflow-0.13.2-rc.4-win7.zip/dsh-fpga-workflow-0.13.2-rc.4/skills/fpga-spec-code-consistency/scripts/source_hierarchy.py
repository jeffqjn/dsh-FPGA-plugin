"""Index Verilog instance candidates when a tool cannot elaborate the design."""
from collections import defaultdict
import re

from support import read_source

IDENT = r"[A-Za-z_][A-Za-z0-9_$]*"
MASK = re.compile(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"', re.S)
MODULE = re.compile(r"\b(?:module|macromodule)\s+(?:automatic\s+|static\s+)?(" + IDENT + r")\b"
                    r"(?P<body>.*?)\bendmodule\b", re.S)
LEAD = re.compile(r"(?:^|(?<=;))[ \t]*(" + IDENT + r")\s*(?=\s|#)", re.M)
INSTANCE = re.compile(r"\s*(" + IDENT + r")\s*(?:\[[^\]\n]+\]\s*)?\(")
PARAMETERS = re.compile(r"#\s*\(")
SKIP = set("""always always_comb always_ff always_latch assign begin case default end endfunction endgenerate
              endtask for foreach fork function generate if initial inout input localparam output parameter reg
              return task wire logic bit integer time typedef automatic static import package interface property
              sequence assert assume cover signed unsigned genvar else unique priority wait repeat""".split())


def skip_parameters(body, start):
    opening = PARAMETERS.match(body, start)
    if not opening:
        return start
    depth = 1
    for offset in range(opening.end(), len(body)):
        char = body[offset]
        depth += (char == "(") - (char == ")")
        if not depth:
            return offset + 1
    return None


def module_index(paths):
    modules = defaultdict(list)
    limits = []
    for path in dict.fromkeys(paths):
        if path.suffix.lower() not in (".v", ".sv"):
            continue
        try:
            source = read_source(path)
        except (OSError, ValueError) as error:
            limits.append(str(error))
            continue
        code = MASK.sub(lambda match: re.sub(r"[^\n]", " ", match[0]), source)
        lines = source.splitlines()
        for match in MODULE.finditer(code):
            base_line = code.count("\n", 0, match.start("body")) + 1
            body = match["body"]
            children = []
            for lead in LEAD.finditer(body):
                module = lead[1]
                if module in SKIP:
                    continue
                offset = skip_parameters(body, lead.end())
                instance = INSTANCE.match(body, offset) if offset is not None else None
                if not instance:
                    continue
                first = base_line + body.count("\n", 0, lead.start(1))
                last = base_line + body.count("\n", 0, instance.end() - 1)
                children.append({
                    "name": instance[1], "module": module,
                    "evidence": {"kind": "rtl", "path": str(path), "line": first, "end_line": last,
                                 "quote": "\n".join(lines[first - 1:last]).strip()},
                })
            modules[match[1]].append(children)
    return modules, limits


def candidates(paths, top):
    modules, limits = module_index(paths)
    result = {"top": top, "status": "unavailable", "instances": [], "limits": limits}
    if len(modules[top]) != 1:
        limits.append("无法唯一定位顶层 Verilog 定义 " + top)
        return result
    result["status"] = "candidates"
    missing, ambiguous = set(), set()
    pending = [(top, child, (top,)) for child in reversed(modules[top][0])]
    while pending and len(result["instances"]) < 10000:
        parent, child, ancestors = pending.pop()
        path = parent + "/" + child["name"]
        module = child["module"]
        definitions = modules.get(module, [])
        result["instances"].append(dict(child, path=path, definitions=len(definitions)))
        if not definitions:
            missing.add(module)
        elif len(definitions) > 1 or module in ancestors:
            ambiguous.add(module)
        else:
            pending.extend((path, instance, ancestors + (module,)) for instance in reversed(definitions[0]))
    if missing:
        limits.append("候选实例缺少唯一可读的 Verilog 定义，需确认是否为外部 IP 或原语 " + "、".join(sorted(missing)))
    if ambiguous:
        limits.append("候选定义存在重名或递归，需人工解析 " + "、".join(sorted(ambiguous)))
    if pending:
        limits.append("候选层级达到 10000 个实例，剩余路径需人工检查。")
    limits.append("候选来自 Verilog 文本。条件编译、generate、数组实例、复杂语法和具体连接需回查源码。")
    return result
