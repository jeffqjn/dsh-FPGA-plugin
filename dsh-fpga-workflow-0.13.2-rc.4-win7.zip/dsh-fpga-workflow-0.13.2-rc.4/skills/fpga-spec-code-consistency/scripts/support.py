import hashlib
import json
import locale
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


def inside(path, root):
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def existing(value, base, directory=False):
    path = (base / Path(value)).resolve()
    require(path.is_dir() if directory else path.is_file(), "路径不存在或类型不符 " + str(path))
    return path


def read_source(path):
    data = path.read_bytes()
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    for encoding in ("utf-8-sig", locale.getpreferredencoding(False), "gb18030"):
        try:
            decoded = data.decode(encoding)
        except UnicodeError:
            continue
        if "\x00" not in decoded:
            return decoded
    raise ValueError("无法可靠解码源文件 " + str(path))
