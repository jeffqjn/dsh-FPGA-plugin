# GateFlow Lite

版本 `0.1.1` · Windows 7 DeepSeek Harness（DSH）

本包包含 9 个技能、4 份 subagent 提示词、7 份协议参考、规则、模板、基准和配置。开始前先在 Win7 实机进行下面的宿主自检。

## 环境

| 项目 | 约定 |
|---|---|
| 系统 | Windows 7 SP1 64-bit |
| Python | 3.8.10，仅标准库 |
| 命令执行 | Windows cmd 命令行。宿主提供 `gf.cmd` → `python gf.py ...`。本包不依赖 PowerShell 2.0 逻辑 |
| 生成 RTL/TB 的自动自检 | Icarus Verilog 11（`iverilog`、`vvp`） |
| 显式 DUT 仿真 | 用 `simulator=iverilog` 或 `simulator=modelsim` 选择 Icarus 或 ModelSim／QuestaSim |
| UVM / 覆盖率 / SVA | ModelSim／QuestaSim（`vlib`、`vlog`、`vsim`、`vcover`），以能力自检为准 |
| 波形 | GTKWave 3.3.x（`gtkwave`，可选） |
| 运行目录 | 例如 `D:\gf\runs\uart_tx_001`，路径 MUST 为纯 ASCII |
| 文本 | UTF-8 无 BOM |

## 安装与加载

### Win7 x64 离线工具

离线安装文件在 [installers/win7-x64](installers/win7-x64)。将包拷到 Win7 SP1 x64 后，先安装 Icarus Verilog，再按需解压 GTKWave。

| 工具 | 离线文件 | 来源 |
|---|---|---|
| Icarus Verilog 11（2020-11-23 x64 构建） | [iverilog-v11-20201123-x64_setup.exe](installers/win7-x64/iverilog-v11-20201123-x64_setup.exe) | [Pablo Bleyer 的 Windows 安装包](https://bleyer.org/icarus/) |
| GTKWave 3.3.100 Win64 | [gtkwave-3.3.100-bin-win64.zip](installers/win7-x64/gtkwave-3.3.100-bin-win64.zip) | [GTKWave 项目发行包](https://sourceforge.net/projects/gtkwave/files/gtkwave-3.3.100-bin-win64/gtkwave-3.3.100-bin-win64.zip/download) |

1. 运行 Icarus 安装程序，例如安装到 `D:\tools\iverilog`。将实际包含 `iverilog.exe` 和 `vvp.exe` 的 `bin` 目录加入 PATH，或在宿主配置中填写两者的完整路径。使用下方的独立 GTKWave 时，可以跳过安装程序自带的 GTKWave 组件。
2. 将 GTKWave ZIP 完整解压到例如 `D:\tools`，从 `D:\tools\gtkwave64\bin\gtkwave.exe` 启动。需要在 cmd 中直接运行 `gtkwave` 时，把该 `bin` 目录加入 PATH。
3. 打开新的 cmd 窗口，执行 `iverilog -V`、`vvp -V` 和 `gtkwave --version`（GTKWave 未加入 PATH 时用完整路径）。然后运行下文的 `gf_doctor`，用 UART 基准跑一次仿真并用 GTKWave 打开生成的 VCD，完成 Win7 实机验证。

在安装包目录中可用 `certutil -hashfile <文件名> SHA256` 核对拷贝后的文件。Icarus 的值取自本包下载件，GTKWave 的值也与 SourceForge 发布页一致。

~~~text
73db2a54c3702145473d4a094f1000a005d5278e96690c835573d6962d16751a  iverilog-v11-20201123-x64_setup.exe
cace98e9c1e5bb6ab74ac2c4c1a2913617b6db7071418d052d2cf999a1acf39d  gtkwave-3.3.100-bin-win64.zip
~~~

### DSH 加载

1. 完整包就绪后，将整个包放入 Win7 上的纯 ASCII 路径。在 DSH 已配置的 skill 搜索位置放置或注册 `skills\<name>\SKILL.md`。保留包目录结构，特别是 `skills` 与 `prompts`、`rules`、`templates` 的相对位置。实际搜索位置由部署实例决定。
2. 在 DSH 中使 `gf-run` 可由自然语言发现。其余 8 个 skill 由 `gf-run` 按需读取。如果 DSH 会自动匹配搜索位置里的每个 skill，且没有可见性控制，则只注册 `gf-run`，其余文件保留在包内供读取。加载后检查 9 份文件均可读取、自然语言只能触发 `gf-run`。
3. 主 agent 用 DSH 的 subagent 能力读取 `prompts` 中的角色提示词并传入 JSON。每轮最多并行运行两个 builder。提示词以文件内容传入，调用方式沿用宿主实例的接口。
4. 用 [gf.example.json](config/gf.example.json) 配置宿主的相应字段。工具不在 PATH 时填入 Win7 实机上的可执行文件完整路径。检查运行根目录可写，确认 DSH 插件已注册下列六个工具。

在验收会话中核对 `gf-run` 出现在 DSH 的可用技能清单，且内部技能由主 agent 按需读取。核对会话的工具清单和实际调用结果。基础生成自检可以用包内入口跑轻量 Lint 与 Icarus。实际缺少所请求流程的工具时，预检报告 NEEDS_HUMAN 并列出缺失项。

## 选择 DUT 仿真器

生成或修改 RTL、Testbench 后，先对该次仿真使用的全部 RTL 做轻量 Lint，再固定使用 Icarus 自检。多模块覆盖所有子模块、集成顶层及列入 FileSet 的 RTL 头文件。给已有 DUT 和普通 TB 单独做仿真时，可在 DSH 请求里指定参数。

- 「仿真已提供的 DUT 和 TB，`simulator=iverilog`。」
- 「仿真已提供的 DUT 和 TB，`simulator=modelsim`。」该值也用于 QuestaSim，包括内网的 10.6c，按实机验证。
- 「生成 RTL 和自检 TB，再另外执行 DUT 仿真，`simulator=modelsim`。」自动自检通过后，会用同一普通 TB 再做一次显式 ModelSim 仿真。

明确请求 DUT 仿真但省略参数时，采用 `sim.default_simulator`，示例配置默认为 `iverilog`。独立 DUT 仿真调用随包的 [dut_sim.py](tools/dut_sim.py)，所选工具不可用时会报告具体缺失项。普通 ModelSim 仿真只用 `vlib`、`vlog`、`vsim`。UVM 与覆盖率仍按各自能力自检。

也可以在包根目录用 cmd 直接运行。`fileset.json` 放在运行目录下，格式见 [gf-run 的 Build](skills/gf-run/SKILL.md#4-build)，源码路径相对该目录，并带实际 SHA-256。若工具不在 PATH，用 `--config` 指定包含实际可执行文件路径的配置。

~~~bat
python -B tools\dut_sim.py --run-dir D:\gf\runs\reg8_dut_001 --fileset fileset.json --simulator modelsim --language verilog
~~~

脚本先核对 `top` 与 `tb_top` 的实际模块声明。日志、仿真工作库及 TB 生成的 `wave.vcd` 保存在本次调用的子目录。ModelSim／QuestaSim 普通仿真开启信号访问。生成 VCD 时，结果包含 `sim.vcd_signals`；VCD 无信号定义会单独报波形失败。stdout 返回实际仿真器、编译、自检和波形结果的 JSON。仿真的当前工作目录为本次调用子目录，使用相对路径读入数据的 TB 应按此定位测试数据。

生成流程使用 `--simulator iverilog --lint`，先写 `lint.log`，通过才写编译和仿真日志。`--lint-only` 仅检查 RTL。轻量检查读取包里的 `rules/rules.json`，按规则原级别阻断或警告，并记录已检查规则及文件哈希。每轮轻量 Lint 修复用 `lint_fix_check.py` 核对候选是否只处理了一条分配的强制违规。完整的 146 条规则审查仍可单独请求。

## ModelSim 能力自检

在 DSH 调用 `gf_doctor`。若宿主将其映射为 `doctor` 子命令，可在宿主入口目录执行以下等价命令。CLI 参数以宿主实际实现为准。

```bat
python gf.py doctor
```

- 生成任务的自动自检要求 `iverilog.available` 和 `vvp.available` 同为 `true`。单独做 DUT 仿真时，按选择检查对应的可执行文件。
- `modelsim.gates.uvm` 为 `false` 时，报告 `UVM unavailable (edition/license)`。为 `true` 时才启动 ModelSim UVM 流程。探测应覆盖编译和实际启动所需的能力。
- `modelsim.gates.coverage` 为 `false` 时，使用 TB 功能计数器并在报告中注明；为 `true` 时采集 ModelSim 代码覆盖率。两个 ModelSim 门控均独立于 Icarus。
- `capabilities.override.uvm` 和 `capabilities.override.coverage` 默认为 `null`，表示采用探测结果。设为 `false` 可禁用对应能力。设为 `true` 时仍须经宿主探测确认可用。配置值不能代替工具或许可证可用证据。

## 宿主工具契约

下表定义技能需要的逻辑字段。宿主插件负责工具注册、参数映射和超时执行。除 `gf_doctor` 外，各工具接收运行目录 `run_dir`；FileSet 中文件用路径和 SHA-256 标识，另含 RTL 顶层 `top` 与仿真顶层 `tb_top`。工具 MUST 将日志写入本轮运行目录，返回相对该目录的日志路径。编译或执行失败时仍须返回可读诊断。

| 工具 | 输入 | 返回 |
|---|---|---|
| `gf_doctor` | 可选宿主配置 | `iverilog.available`、`vvp.available`、`modelsim.gates.uvm`、`modelsim.gates.coverage` 以及诊断 |
| `gf_lint` | RTL 文件、规则文件 | `ok`、`findings`、`log`。只有 mandatory 违规阻断 |
| `gf_sim` | FileSet、语言、超时 | `compile.ok`、`compile.log`、`sim.pass`、`sim.log`、可选 `sim.vcd`。宿主据实际编译和 TB 自检结果给出 `sim.pass` |
| `gf_ip` | `list` / `info` / `add`、按需传入 block 和参数 | 列表、IP 元数据或新增文件及版本、`log` |
| `gf_uvm` | UVM 专用 FileSet、测试名、超时，按需启用覆盖率采集 | `pass`、`log`，按需返回 `errors`、`fatal`、覆盖率数据库路径。判定取自 UVM 结果 |
| `gf_cov` | 覆盖率数据库或 TB 计数器日志、门限或计划 | `mode`、`line`、`branch`、`toggle`、`thresholds`、`pass`、`report`。计数器模式下代码覆盖率字段为 `null` |

## 技能

| 技能 | 用途 |
|---|---|
| `gf-run` | 自然语言入口，编排设计、验证和报告 |
| `gf-rtl` | 根据冻结接口生成 RTL |
| `gf-tb` | 编写自检 TB 和测试矩阵 |
| `gf-debug` | 复现并诊断编译及仿真问题 |
| `gf-lint` | 校验 RTL 规则与违规证据 |
| `gf-ip` | 查询、复制和绑定本地 IP |
| `gf-uvm` | 使用 ModelSim 构建并执行 UVM 1.2 测试 |
| `gf-cov` | 检查代码覆盖率或 TB 功能计数 |
| `gf-protocol` | 为 RTL 与 TB 提供协议时序、端口和测试参考 |

## 第一次运行

在 DSH 输入「实现 Verilog-2001 UART 发送器。50 MHz 时钟，115200 baud，8N1，valid/ready 接口。用自检 TB 覆盖复位、角值字节和背靠背发送，并运行 Icarus 仿真。」DSH 应加载 `gf-run`，在例如 `D:\gf\runs\uart_tx_001` 下保存 RTL、TB、日志和 `report.json`。检查报告引用当前 Lint、编译和仿真日志，且 `lint.ok=true` 与 `sim.pass=true` 均来自实际工具输出。

基准可从 [UART TX](benchmarks/uart_tx.md)、[同步 FIFO](benchmarks/fifo_sync.md) 和 [流式 3×3 中值](benchmarks/median3x3.md) 复制需求运行。

```text
Preflight → Normalize → Route → Plan → Build (并行 ≤2) → Integrate
  → Verify (完整 RTL FileSet 轻量 lint → sim → uvm → cov)
  → Fix (需要时，最多 3 轮并回到 Verify) → Report
```

## 目录

```text
gateflow-skills-win7/
├── README.md
├── installers/win7-x64/                 # Icarus Verilog 与 GTKWave 离线文件
├── tools/{dut_sim.py,rtl_lint.py,lint_fix_check.py}
├── config/gf.example.json
├── skills/
│   ├── gf-run/SKILL.md
│   ├── gf-rtl/SKILL.md
│   ├── gf-tb/SKILL.md
│   ├── gf-debug/SKILL.md
│   ├── gf-lint/SKILL.md
│   ├── gf-ip/SKILL.md
│   ├── gf-uvm/SKILL.md
│   ├── gf-cov/SKILL.md
│   └── gf-protocol/
│       ├── SKILL.md
│       └── references/{uart,spi,i2c,axi4lite,axi4,axis,wishbone}.md
├── prompts/{planner,builder,integrator,fixer}.md
├── rules/{rules.md,rules.json}
├── templates/{tb_basic.v,uvm_env.md,props_basic.md}
└── benchmarks/{uart_tx,fifo_sync,median3x3}.md
```

## 范围

本包提供工作流、提示词、规则、模板、协议参考、基准、独立 DUT 仿真入口，以及 Icarus Verilog 和 GTKWave 的离线安装文件。宿主部署负责 DSH 本体、工具插件、命令入口及现有 RTL 生成器。使用前须在 Win7 宿主安装并验证所需工具。
