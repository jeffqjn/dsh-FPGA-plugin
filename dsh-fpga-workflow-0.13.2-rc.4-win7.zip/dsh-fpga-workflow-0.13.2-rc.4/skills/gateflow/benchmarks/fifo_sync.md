# 基准同步 FIFO

## 用户输入

> 实现参数化同步 FIFO，默认 8 位、深度 3。单时钟 Verilog-2001 RTL，加自检 TB。检查空、满、溢出、下溢、同时读写、绕回和复位。

## TaskSpec

```json
{"name":"fifo_sync","summary":"Parameterized synchronous FIFO","language":"verilog",
 "params":{"DATA_WIDTH":8,"DEPTH":3},
 "ports":["clk","rst_n","wr_en","wr_data[DATA_WIDTH-1:0]","rd_en",
 "rd_data[DATA_WIDTH-1:0]","rd_valid","full","empty","overflow","underflow"],
 "protocol":null,
 "assumptions":["DATA_WIDTH >= 1，DEPTH >= 2，支持非 2 次幂",
 "上升沿按采样前的 full/empty 分别决定接受写/读，无旁路",
 "rd_valid 在已接受读的寄存器更新后有效，错误标志按当拍拒绝请求产生",
 "复位清空队列与可见寄存器，同时读写且均接受时占用不变"]}
```

## 期望产物

`task_spec.json`、`plan.json`、接口文件、`fifo_sync.v`、`tb_fifo_sync.v`、VCD、阶段日志和 `report.json`。接口冻结后 RTL 和 TB 可并行编写，由该 component 的 builder 汇总为一个 FileSet。逻辑队列模型独立于 DUT 指针实现。

## 测试点

| 用例 | 自检 |
|---|---|
| 空和下溢 | 复位后 empty，读拒绝、underflow 有效、无虚假 rd_valid |
| 满和溢出 | 写满 DEPTH，再写产生 overflow，原队列内容保持 |
| 同时读写 | 非空非满二者均接受。满时拒绝写并接受读。空时拒绝读并接受写 |
| 回绕 | 多次填充与排空，至少运行深度 3 和深度 4 两种配置 |
| 有数据时复位 | 数据全部丢弃，下一轮只读出新数据 |
| 计数 | 每次接受事件更新软件队列，核对 flags、顺序和占用边界 |

## 验证

由 `gf-run` 为每种配置先执行 Lint，再执行 Icarus 自检。宿主支持顶层参数覆盖时直接传入。不支持时，为各配置生成固定参数的 TB 顶层并使用各自的 FileSet。下列命令用于已通过本轮 Lint 后的手工复现，适用于 `tb_fifo_sync` 有 `DEPTH` 参数且路径如例的运行目录。

```bat
iverilog -g2001 -Wall -s tb_fifo_sync -Ptb_fifo_sync.DEPTH=3 -o tb_d3.vvp rtl\fifo_sync.v tb\tb_fifo_sync.v
vvp tb_d3.vvp
iverilog -g2001 -Wall -s tb_fifo_sync -Ptb_fifo_sync.DEPTH=4 -o tb_d4.vvp rtl\fifo_sync.v tb\tb_fifo_sync.v
vvp tb_d4.vvp
```

两配置的自检均实际执行，队列对比、错误响应及复位正确。两配置均要求 `lint.ok=true`、`compile.ok=true` 和 `sim.pass=true`。分别保留日志与波形。

## 常见失败

| 现象 | 排查 |
|---|---|
| 深度 3 超范围 | 指针必须在 DEPTH-1 绕回 |
| 满/空同时读写不一致 | 根据采样前 flags 计算接受事件 |
| 数据错一拍 | 对齐 rd_valid 和寄存器更新后的数据 |
