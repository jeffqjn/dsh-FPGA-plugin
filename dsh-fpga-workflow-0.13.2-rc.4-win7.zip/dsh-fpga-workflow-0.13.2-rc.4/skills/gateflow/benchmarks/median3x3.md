# 基准流式 3×3 中值

## 用户输入

> 用 Verilog-2001 实现单通道 8 位灰度的流式 3×3 中值滤波。图像按行扫描、边缘不补零。输入和输出支持 valid/ready，支持连续帧。写自检 TB，用有固定种子的随机图与独立黄金模型对拍，并模拟输入空拍和输出背压。

## TaskSpec

```json
{"name":"median3x3","summary":"Streaming 3x3 median for unsigned grayscale pixels","language":"verilog",
 "params":{"IMG_WIDTH":8,"IMG_HEIGHT":6,"PIXEL_WIDTH":8},
 "ports":["clk","rst_n","in_valid","in_ready","in_pixel[PIXEL_WIDTH-1:0]","in_sof",
 "out_valid","out_ready","out_pixel[PIXEL_WIDTH-1:0]","out_sof","out_eol"],
 "protocol":null,
 "assumptions":["每帧固定尺寸且宽高均至少 3，行优先，首像素握手携带 in_sof",
 "不填充，输出 (IMG_WIDTH-2)*(IMG_HEIGHT-2) 个像素，按中心坐标行优先",
 "out_sof 跟随首输出，out_eol 跟随各输出行末，等待时载荷和标记稳定",
 "低有效同步复位丢弃未完成帧，下一首帧从新 in_sof 开始"]}
```

## 期望产物

`task_spec.json`、`plan.json`、冻结接口、`median3x3.v`、`tb_median3x3.v`、VCD、测试种子、阶段日志和 `report.json`。黄金模型从握手入队的完整图像按坐标直接取 9 点，独立排序取第 5 项。可缓存实测输出再比对，避免引入整帧等待假设。

## 测试点

| 用例 | 自检 |
|---|---|
| 最小 3×3 | 恰好 1 个输出，同时有 SOF/EOL |
| 默认 8×6 | 每帧 24 个输出，每行 6 个，坐标对应中心区域 |
| 定向图 | 递增、常量、交替最值和单点脉冲，核对无符号和边缘策略 |
| 随机图 | 固定并记录种子，至少 3 帧。每个像素与排序模型逐项相等 |
| 背压和空拍 | 事务仅由握手推进，输出等待时像素与标记稳定 |
| 复位恢复 | 部分输入后复位，仅在新帧就绪后产生对应输出 |

## 验证

通过 `gf-run` 对默认配置与最小配置先执行 Lint，再执行 Icarus 自检。宿主支持顶层参数覆盖时直接传入。不支持时，为各配置生成固定参数的 TB 顶层并使用各自的 FileSet。下列命令用于已通过本轮 Lint 后的手工复现，路径和顶层参数按 FileSet 调整。

```bat
iverilog -g2001 -Wall -s tb_median3x3 -o tb.vvp rtl\median3x3.v tb\tb_median3x3.v
vvp tb.vvp
iverilog -g2001 -Wall -s tb_median3x3 -Ptb_median3x3.IMG_WIDTH=3 -Ptb_median3x3.IMG_HEIGHT=3 -o tb_min.vvp rtl\median3x3.v tb\tb_median3x3.v
vvp tb_min.vvp
```

所有对拍、计数、标记和等待检查实际执行并排空。两种配置均有 `lint.ok=true`、`compile.ok=true`、`sim.pass=true` 和独立日志。

## 常见失败

| 现象 | 排查 |
|---|---|
| 输出数量多或少 | 追踪 3×3 窗口就绪和输出行列边界 |
| 行首/行末像素错误 | 行缓存读写地址、前一行尾部的窗口内容 |
| 背压时丢数据 | 检查像素、坐标和 SOF/EOL 是否一起停住 |
