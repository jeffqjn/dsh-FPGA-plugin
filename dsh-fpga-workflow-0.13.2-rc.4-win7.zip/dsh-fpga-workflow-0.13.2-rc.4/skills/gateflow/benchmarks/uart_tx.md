# 基准 UART TX

## 用户输入

> 实现单模块 UART TX。时钟 50 MHz，115200 baud，8N1、LSB first，valid/ready 接口。用 Verilog-2001 实现并自检，覆盖复位、角值和背靠背发送，运行 Icarus 仿真。

## TaskSpec

```json
{"name":"uart_tx","summary":"8N1 UART transmitter","language":"verilog",
 "params":{"CLK_FREQ":50000000,"BAUD_RATE":115200},
 "ports":["clk","rst_n","tx_data[7:0]","tx_valid","tx_ready","tx_out"],
 "protocol":"uart",
 "assumptions":["clk 上升沿接受 tx_valid && tx_ready",
 "同步低有效复位，中止当前帧并恢复空闲高电平",
 "每 bit 固定 CLK_FREQ / BAUD_RATE 个周期，整数商 434",
 "无发送 FIFO，完整 stop 槽结束后才重新就绪"]}
```

## 期望产物

`task_spec.json`、`plan.json`、冻结接口、`uart_tx.v`、`tb_uart_tx.v`、VCD、lint/compile/sim 日志和 `report.json`。Plan 包含 start 相对握手的时刻和恢复 ready 的时刻。文件摆放以 FileSet 为准。

## 测试点

| 用例 | 自检 |
|---|---|
| 复位 | 至少 3 拍，检查空闲高、停止旧帧、重放后能发新帧 |
| 一帧 | 从 start 边沿定时，按位中点解码 8N1，核对每个应变边沿的时刻 |
| 角值 | `00 FF 01 80 55 AA` 覆盖长连续电平、首尾位和交替位 |
| 背靠背 | valid 保持，下一个字节等待 ready。按握手队列核对帧序、完整 stop、无多余帧 |

## 验证

由 `gf-run` 先执行轻量 Lint，再跑 Icarus 自检。以下命令用于已通过本轮 Lint 后的手工复现，从 run 目录执行，并按 FileSet 替换路径。

```bat
iverilog -g2001 -Wall -s tb_uart_tx -o tb.vvp rtl\uart_tx.v tb\tb_uart_tx.v
vvp tb.vvp
```

必需用例均实际执行，接收帧与握手队列逐个匹配并排空。要求 `lint.ok=true`、`compile.ok=true` 和 `sim.pass=true`。日志记录 Lint、自检和结束标记。

## 常见失败

| 现象 | 排查 |
|---|---|
| 波特率差一拍 | 位计数从 0 到 433，与采样点一起核对 |
| 数据位反序 | 用 `01` 和 `80` 区分 LSB 与 MSB |
| 第二帧缺失 | 检查 valid 等待、ready 恢复和 stop 时长 |
