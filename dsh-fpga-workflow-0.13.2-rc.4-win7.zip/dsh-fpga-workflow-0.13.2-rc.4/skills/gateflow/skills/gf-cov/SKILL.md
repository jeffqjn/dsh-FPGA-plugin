---
name: gf-cov
description: >
  Internal — loaded by gf-run. Check code coverage or functional
  counters when a passing simulation has a coverage requirement.
---

# 覆盖率检查

先核对本轮普通 TB 仿真已通过，从 `dut_sim.py` 或宿主 `gf_sim` 取得 `sim.pass=true`。随后读取 `gf_doctor`。只有 `modelsim.gates.coverage=true` 才走 ModelSim 代码覆盖率。为 false 或缺失时 MUST 回退 TB 功能计数器，报告 `ModelSim coverage unavailable; functional counters used`。记录任何明确要求但无法满足的代码覆盖率目标。

## ModelSim 代码覆盖率

使用已通过的 UVM 运行所保存的 UCDB，或对普通自检 TB 重新运行 ModelSim。只对 RTL 插桩。UVM 包、TB 按各自文件顺序编译。以下命令使用模板顶层和文件名，实际执行替换为 FileSet。

```bat
vlib work
vlog +cover=bcesxf rtl\dut_example.v
vlog tb\tb_basic.v
vsim -c -coverage -nodpiexports -onfinish stop -l logs\cov_sim.log work.tb_basic -do "coverage save -onexit cov.ucdb; run -all; quit -f"
vcover report -output logs\cov.txt cov.ucdb
```

文本为本命令的默认报告格式。只有实机版本明确支持时才加 `vcover report -text` 选项。示例 TB 不使用 DPI，在这种设计中 `-nodpiexports` 可避免依赖 DPI wrapper 的 C/C++ 编译器。按已安装版本核对 `x` 的扩展 toggle 数据。需要标准 toggle 时使用对应 `t` 标志（如 `+cover=bcesft`）。结合 DUT 实例范围检查 line、branch、toggle。若版本仅提供 statement，且验收未明确同意以其替代 line，则记 line 缺失。排除项须保存范围、理由和原始报告。

默认门限以百分数表示，在 `config/gf.example.json` 的 modelsim 段配置。

```json
{"line":90,"branch":80,"toggle":80}
```

## TB 功能计数回退

TB 在实际命中测试点时递增计数。仿真结束逐项输出 `COV <name> <hits>`，例如 `COV fifo_full 3`。向 `gf_cov` 提供本轮 sim 日志和 Plan 的预期计数要求。MUST 检查所有必需项及最小命中数（未明确时每项至少 1），记录缺失、零命中、非法值和重复名称。计数器结果仅用于功能覆盖率验收。

## 输出

```json
{"mode":"code","line":92.1,"branch":81.0,"toggle":84.0,
 "thresholds":{"line":90,"branch":80,"toggle":80},"pass":true,"report":"logs/cov.txt"}
```

计数器模式使用 `mode="functional"`，line/branch/toggle 为 null，thresholds 使用测试点到最小命中数的映射，report 指向实际对照表。未达门限时 MUST 补测试或修复真实缺陷，MUST NOT 为凑百分比改 RTL 或丢弃计数。

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog`、`vvp`。ModelSim 2018 使用 `vlib`、`vlog`、`vsim`、`vcover`，负责 UVM、覆盖率、SVA。GTKWave 3.3.x（`gtkwave`）可选。运行目录为纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] GF 仿真已通过，覆盖率采集模式来自能力门控。
- [ ] 门限逐项有证据，报告与排除理由已落盘。

## Failure handling

数据库、日志、指标或计数缺失时记录缺项和本轮证据。覆盖率命令运行失败要标明阶段。仅能力门控关闭时走功能回退，已明确要求的代码门限仍记为未验证。
