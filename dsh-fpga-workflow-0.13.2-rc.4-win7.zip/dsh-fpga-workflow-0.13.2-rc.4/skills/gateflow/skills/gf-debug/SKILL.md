---
name: gf-debug
description: >
  Internal — loaded by gf-run. Diagnose a reproducible lint, compile,
  simulation, timeout, or protocol failure before a scoped fix.
---

# RTL 与仿真调试

读取 FileSet、冻结接口、本轮 VerifyResult 和原始日志。只在 run 目录复现，记录失败条件、首个出错的外部信号和稳定的错误标识。

## 失败分类

| 类型 | 判据 | 首查项 |
|---|---|---|
| COMPILE | `compile.ok=false`，语法或 elaboration 失败 | 第一条编译错误、语言模式、文件顺序、`tb_top`、端口和参数 |
| SIM_FAIL | 编译成功，自检比较失败或结束标记无效 | 第一个 `[FAIL]`、预期值、实测值、复位和采样时机 |
| TIMEOUT | watchdog 或宿主超时，仿真未完成 | 时钟、TB 等待条件、握手、测试时限 |
| PROTOCOL | 波形或断言证明违反约定 | 冻结协议子集、接受事件、等待期数据稳定性 |
| LINT | `lint.ok=false`，存在已核验 mandatory 违规 | 规则 ID、对应原文和上下文 |

## 定位步骤

1. MUST 用原 FileSet、仿真器、编译选项、测试种子及输入重现，保存日志。显式 DUT 仿真用原 `simulator` 参数调用 [dut_sim.py](../../tools/dut_sim.py)。生成任务的回归与调试仿真必须使用已过本轮 Lint 的 RTL；修改后先重跑 Lint。若复现结果变化，保留每次条件及结果。
2. 将范围缩到首个异常周期或最小可重复输入。用 DSH 文件读取能力在日志内查找字面量 `[FAIL]` 和 `TIMEOUT`，保留行号。
3. 先看外部信号的时钟、复位、请求、接受和响应，再追踪必要的内部状态。
4. 提出一个能由日志或波形检验的假设，向主 agent 返回失败分类、证据和建议修改范围。
5. 由 fixer 一次只修改一个根因。MUST NOT 删除断言、缩减回归或放宽预期。修完先复跑失败用例，再执行 Verify。相同错误累计出现 2 次时停止重试。

## 本地复现

以下例子使用 `gf-tb` 的模板文件，将源文件顺序及顶层替换为本轮 FileSet 的实际值。

```bat
iverilog -g2001 -Wall -s tb_basic -o tb.vvp rtl\dut_example.v tb\tb_basic.v
vvp tb.vvp
gtkwave wave.vcd
```

保留日志和波形路径。手工复现辅助定位，报告使用本轮 `gf_sim` 或 `dut_sim.py` 的结构化结果。

## 常见根因

| 现象 | 检查 |
|---|---|
| 信号全 X | 复位是否覆盖寄存器、端口是否连接、是否有多驱动 |
| 首字节错误 | 首次握手、移位顺序、采样点、分频计数边界 |
| 背靠背丢数据 | 是否同时处理完成与下一接收，是否在 ready 为低时推进 |
| 偶发失败 | TB 是否在采样沿驱动，是否固定随机种子，复位释放是否对齐 |
| 仿真不结束 | 时钟生成、watchdog、自检任务结束条件、队列是否排空 |

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog`、`vvp`。ModelSim 2018 使用 `vlib`、`vlog`、`vsim`、`vcover`，负责 UVM、覆盖率、SVA。GTKWave 3.3.x（`gtkwave`）可选。运行目录为纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] 保留复现条件和首个错误的日志或波形证据。
- [ ] 每轮仅有一个待验证根因，修复后跑原用例与回归。

## Failure handling

无法复现、缺关键证据或同错 2 次时，向 `gf-run` 返回实际结果和资料缺口。编译阶段失败时先定位编译，避免将旧波形当成本轮证据。
