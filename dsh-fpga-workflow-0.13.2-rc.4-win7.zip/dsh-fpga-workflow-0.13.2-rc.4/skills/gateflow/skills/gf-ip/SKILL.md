---
name: gf-ip
description: >
  Internal — loaded by gf-run. Query and bind a versioned local IP block
  when the design plan calls for reuse.
---

# 本地 IP 复用

从宿主的 `ip/index.json` 读取已安装 IP。以下是 UART TX 条目的格式示例，路径相对 IP 库。参数范围和跨参数约束以实际 block 版本为准。

```json
{"blocks":[{"id":"uart","version":"1.0.0","module":"uart_tx","language":"systemverilog",
 "rtl":["uart/rtl/uart_tx.sv"],"dependencies":[],
 "params":{"CLK_FREQ":{"type":"integer","default":100000000,"min":2},
           "BAUD_RATE":{"type":"integer","default":115200,"min":1}},
 "constraints":["CLK_FREQ / BAUD_RATE 的整数商至少为 2"],
 "ports":["clk","rst_n","tx_data[7:0]","tx_valid","tx_ready","tx_out"]}]}
```

## 工具动作

| 动作 | 向 `gf_ip` 提交 | 使用结果 |
|---|---|---|
| list | `action=list` | 本地 block ID 和版本 |
| info | `action=info`、block ID / 版本 | 模块、文件、依赖、参数、端口 |
| add | `action=add`、block ID / 版本、参数 | 复制到本轮 run 的文件、版本和日志 |

## Add

1. MUST 先用 info 检查实际版号、语言、端口、依赖及参数约束。参数越界或语言冲突时停止并报告。有 SV IP 时 MUST 确认 Plan 与仿真语言支持。
2. 经 `gf_ip` 把依赖和源码复制到 `D:\gf\runs\<id>\ip\<block>\`。核对真实路径、文件及哈希，记录库版本。MUST NOT 改原库、改复制的 IP 源码或自动下载。
3. 在同一 run 目录生成 `ip_bind.sv`，按冻结接口绑定参数与端口。不得通过封装隐藏 IP 兼容性问题。
4. 把 IP 与绑定模块加入 FileSet.rtl，更新模块名与自检 TB 入口。按 `gf-run` 先执行完整 FileSet 的轻量 Lint，再至少执行一次自检仿真，覆盖接线、复位和一笔事务，保留真实工具结果和日志。

```systemverilog
module ip_bind (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] tx_data,
    input  wire       tx_valid,
    output wire       tx_ready,
    output wire       tx_out
);
    localparam [31:0] CLK_FREQ  = 32'd50_000_000;
    localparam [31:0] BAUD_RATE = 32'd115_200;

    uart_tx #(.CLK_FREQ(CLK_FREQ), .BAUD_RATE(BAUD_RATE)) u_tx (
        .clk(clk), .rst_n(rst_n), .tx_data(tx_data),
        .tx_valid(tx_valid), .tx_ready(tx_ready), .tx_out(tx_out)
    );
endmodule
```

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog`、`vvp`。ModelSim 2018 使用 `vlib`、`vlog`、`vsim`、`vcover`，负责 UVM、覆盖率、SVA。GTKWave 3.3.x（`gtkwave`）可选。运行目录为纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] 版本、参数和依赖均来自宿主本地目录。
- [ ] 绑定端口和 FileSet 已核验，存在本轮 Lint 与自检仿真日志。

## Failure handling

库缺失、旧版接口与冻结接口冲突、参数非法、lint 或仿真不通过时，回传具体 block、版本和证据，由主 agent 选择本地兼容版本或提出调整需求。
