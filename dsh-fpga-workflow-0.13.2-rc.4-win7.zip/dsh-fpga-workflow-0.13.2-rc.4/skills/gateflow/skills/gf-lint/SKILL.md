---
name: gf-lint
description: >
  Internal — loaded by gf-run. Audit Verilog or SystemVerilog RTL against the
  spacecraft coding rules and return evidence-backed lint findings.
---

# RTL 规则检查

输入为 FileSet 中的 Verilog/SystemVerilog RTL、纳入评审范围的头文件及 [rules.json](../../rules/rules.json)。按 [航天器编码规范及判定口径](../../rules/rules.md) 审查，输出 `{"ok","findings"}` 和本轮日志路径。只有已核验的 `mandatory` 违规可令 `ok=false`。

## 仿真前轻量检查

生成任务默认用 `dut_sim.py --lint` 将检查和仿真串起来，也可用 `--lint-only` 检查同一份 FileSet 后再交宿主仿真。覆盖全部 `rtl` 和列入 `headers` 的 RTL 头文件。轻量模式应用规则表中的正则规则和可直接判定的结构检查，包括函数范围外的 `integer`、`initial`、`wait` 或延时、常见仿真系统任务、case 缺 default、综合指令、forever/repeat。输出含实际扫描文件及哈希、检查规则编号、部分检查和未检查条款数量。项目上下文和综合工具规则由下方完整审查判定。

## 规则格式

```json
{"rules":[
 {"id":"2.1.13","level":"mandatory","kind":"regex","pattern":"\\binitial\\b","message":"RTL 中禁止 initial 结构","fix":"用复位或时序逻辑替代 initial 初始化"},
 {"id":"2.6.2","level":"mandatory","kind":"llm","text":"case 语句必须有 default 分支。","message":"case 必须包含 default"}
]}
```

## 流程

1. 确定每个 RTL 文件与头文件的评审范围，据 FileSet.top 和工程层级确认实际顶层。按已知端口、时钟域、复位和目标器件判定规则适用性。ASIC DFT 规则默认不适用于普通 FPGA 任务。
2. 按行扫描正则，保留原始行号。匹配 `initial`、`wait` 和 `#` 时忽略注释、字符串和转义标识符，并排除参数声明或覆写。评审 `2.6.5` 时 MUST 检查原始注释中的综合指令。
3. 分批核对每个文件和对应规则，每批最多 30 条。给 LLM 带原始行号的代码和必要上下文，核对候选项及其余规则。把 `not_applicable` 和 `not_verifiable` 及其原因记入日志。依赖项目上下文的条款以实际证据为准。
4. 核验每个发现的 ID、等级、路径、行号与 `evidence`。证据 MUST 是该物理行原文，包括空白。缺失分支用结构起始行定位并核对完整结构。用规范编号而非自定义标签报告。
5. 按 `(rule_id, path, line)` 去重，mandatory 优先。先算完整阻断状态，再最多返回 50 条 findings。日志记录已查范围、缺口及截断数。规则损坏或漏查批次时向 `gf-run` 返回执行错误。

## LLM 评审提示

> 依据给定条款和实际 RTL 判定，按原编号和 level 报告有明确证据的违规。每条给出 rule_id、path、line、evidence、message 和 fix。evidence 使用原文行，fix 针对此处违规。标出依赖缺失上下文的条款，交由主 agent 写入日志。只返回 JSON。

## 输出示例

```json
{"ok":false,"findings":[{"rule_id":"2.6.2","level":"mandatory","path":"rtl/control.v",
 "line":24,"evidence":"        case (state)","message":"缺少 default 分支","fix":"为未定义状态增加恢复分支"}],
 "log":"logs/lint.log"}
```

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog`、`vvp`。ModelSim 2018 使用 `vlib`、`vlog`、`vsim`、`vcover`，负责 UVM、覆盖率、SVA。GTKWave 3.3.x（`gtkwave`）可选。运行目录为纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] 规则、语言、顶层适用性和物理证据行已核验。
- [ ] 已记录审查缺口和截断，报告用原编号与等级。

## Failure handling

无法读取完整 RTL、规则或上下文时，记录缺项和受影响的规则，交由主 agent 处理。被发现与原文不符的条目不得进入 findings。
