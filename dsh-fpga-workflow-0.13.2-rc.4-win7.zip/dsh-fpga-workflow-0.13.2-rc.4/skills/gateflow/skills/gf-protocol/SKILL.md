---
name: gf-protocol
description: >
  Internal — loaded by gf-run. Select and read the protocol reference
  before defining or testing an interface in a supported protocol family.
---

# 协议参考

从 TaskSpec 确定协议、角色和子集，MUST 先读对应 reference，再冻结端口、时序和测试。RTL 与 TB 使用同一份接口。超出参考范围的特性明确列入 Plan，必要时请用户确定约束。

| 协议 | 参考 | 方向 | 场景 |
|---|---|---|---|
| UART | [uart.md](references/uart.md) | TX → RX | 异步串行字节 |
| SPI | [spi.md](references/spi.md) | controller ↔ peripheral | 同步串行寄存器和外设 |
| I2C | [i2c.md](references/i2c.md) | controller ↔ target | 两线开漏、有地址的外设 |
| AXI4-Lite | [axi4lite.md](references/axi4lite.md) | manager ↔ subordinate | 单拍存储器映射访问 |
| AXI4-Full | [axi4.md](references/axi4.md) | manager ↔ subordinate | burst 存储器映射访问 |
| AXI-Stream | [axis.md](references/axis.md) | source → sink | 流式数据和包边界 |
| Wishbone | [wishbone.md](references/wishbone.md) | master ↔ slave | Classic 总线寄存器访问 |

## 通用约定

内部时钟与低有效复位使用 `clk`、`rst_n`。用 `s_`、`m_` 或项目已有的明确前缀区分同类接口。valid/ready 在采样沿同时为 1 才接受，等待时源端保持 valid 与载荷。开漏端只能拉低或释放，TB 建模上拉。每个接口 MUST 注明可选信号与支持子集。

## 通用测试点

1. 复位极性、释放时机和空闲状态。
2. 一次完整事务，核对边沿、位序或字节序。
3. 最小、最大与特殊数据和边界长度。
4. 连续事务，检查顺序、重复和丢失。
5. 支持时检查背压、等待和稳定性。
6. 检查定义过的错误响应及复位后的恢复。

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog`、`vvp`。ModelSim 2018 使用 `vlib`、`vlog`、`vsim`、`vcover`，负责 UVM、覆盖率、SVA。GTKWave 3.3.x（`gtkwave`）可选。运行目录为纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] 角色、子集、位宽、握手与测试被写入冻结接口或 Plan。
- [ ] RTL 与 TB 采用同一套时序。门控不可用时由自检 TB 承担可等价实现的检查。

## Failure handling

遇到资料与冻结接口冲突、角色未知或必需特性超出子集时，MUST 将冲突和影响回报 `gf-run`，由主 agent 确定接口后再继续。
