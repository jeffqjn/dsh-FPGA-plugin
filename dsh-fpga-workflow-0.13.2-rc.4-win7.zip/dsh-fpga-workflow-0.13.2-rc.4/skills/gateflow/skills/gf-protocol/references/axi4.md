# AXI4-Full

先冻结数据位宽、burst 类型及长度、大小、对齐、未完成事务和 ID 支持。建议基础子集采用对齐 INCR、固定 ID 或单未完成事务，并明确其余请求的处理。五通道独立握手沿用 AXI4-Lite 的基本原则。

## 端口

| 通道 | manager → subordinate | subordinate → manager |
|---|---|---|
| AW | awvalid、awaddr、awid、awlen[8]、awsize[3]、awburst[2] | awready |
| W | wvalid、wdata、wstrb、wlast | wready |
| B | bready | bvalid、bid、bresp[2] |
| AR | arvalid、araddr、arid、arlen[8]、arsize[3]、arburst[2] | arready |
| R | rready | rvalid、rid、rdata、rresp[2]、rlast |
| 公共 | clk、rst_n 由系统提供 | 按 Plan 补齐约定的标准属性与可选 sideband |

## 时序

```text
Two-beat write with one data stall (AWLEN=1)
posedge        1     2     3     4     5
AW handshake   *     .     .     .     .
WVALID         0     1     1     1     0
WREADY         1     1     0     1     1
WLAST          -     0     1     1     -
W handshake    .     *     .     *     .
B handshake    .     .     .     .     *
```

拍数为 LEN+1，单拍最大字节数为 2^SIZE，不能超过总线字宽。对齐 INCR 每拍地址加 2^SIZE，burst 不可跨 4 KiB 边界。若开放 FIXED/WRAP，另冻结合法长度与回绕约束。WLAST/RLAST 只标识最后一拍；出现背压时保持 LAST 和载荷。AXI4 没有 WID，写数据按写地址事务顺序关联。B 在 AW 和最后 W 接受后给出，BID/RID 对应请求 ID。

## 测试点

- 长度 1 拍、多个拍及支持的最大值，核对 LAST、地址递增及响应。
- 最后数据拍背压，多个 ID 或 outstanding 的顺序（如支持）。
- 4 KiB 邻近合法请求、字节 strobe、边界与不支持的操作。

## 常见错误

把 LEN 当拍数、按 VALID 而非握手计数、LAST 提前、跨 4 KiB、错误关联 ID。

## SVA 建议

- `wvalid && !wready |=> wvalid && $stable({wdata,wstrb,wlast})`。
- 用已接收 burst 的剩余拍数检查每次 W/R 握手的 LAST 标记。
