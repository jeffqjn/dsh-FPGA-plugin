# AXI4-Lite

单拍存储器映射接口。数据宽度 32 或 64 位。可限制未完成事务数，通过各通道 READY 实现。接口必须注明支持的映射和错误响应。

## 端口

| 通道 | manager → subordinate | subordinate → manager |
|---|---|---|
| AW | awaddr[ADDR_W]、awprot[3]、awvalid | awready |
| W | wdata[DATA_W]、wstrb[DATA_W/8]、wvalid | wready |
| B | bready | bresp[2]、bvalid |
| AR | araddr[ADDR_W]、arprot[3]、arvalid | arready |
| R | rready | rdata[DATA_W]、rresp[2]、rvalid |
| 公共 | clk、rst_n 由系统提供 | 在时钟上升沿判定握手 |

## 时序

```text
posedge        1     2     3     4     5     6
W accepted     *     .     .     .     .     .
AW accepted    .     .     *     .     .     .
BVALID         0     0     0     1     1     0
BREADY         0     0     0     0     1     1
B accepted     .     .     .     .     *     .
```

AW、W 独立握手，可先到任一项。两项均接受后才产生对应 B。接受 AR 后才返回 R。等待时保持 VALID 和本通道载荷。WSTRB 每位对应一个数据字节。响应值按地址、操作和规格约定。

## 测试点

- AW 先到、W 先到和两者同拍，地址与数据正确配对。
- 延迟 BREADY、RREADY，验证响应稳定且不重发。
- 部分字节写、空 strobe、无效地址、读写交错、复位清理挂起请求。

## 常见错误

要求 AW 与 W 同拍、写响应早于任意一项接受、忽略 WSTRB、等待 READY 后才拉高 VALID。

## SVA 建议

- `bvalid && !bready |=> bvalid && $stable(bresp)`；R 通道同理，包含 rdata。
- 在 scoreboard 维护尚未配对的 AW/W，断言每个 B 响应都有对应已接受的两项。
