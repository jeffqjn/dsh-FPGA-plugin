# AXI-Stream

仅有数据流，无地址。冻结数据位宽、每包边界、可选 sideband 与复位行为。

## 端口

| 信号 | 位宽 | 方向 | 用途 |
|---|---|---|---|
| clk / rst_n | 1 / 1 | → source 和 sink | 采样时钟与复位 |
| tvalid / tdata | 1 / DATA_W | source → sink | 载荷有效与数据 |
| tready | 1 | sink → source | 接受许可 |
| tlast | 1 | source → sink | 可选包尾 |
| tkeep / tstrb | DATA_W/8 | source → sink | 可选字节保留及位置限定 |
| tid / tdest / tuser | 配置 | source → sink | 可选标识、路由和用户信息 |

## 时序

```text
posedge       1     2     3     4     5
tvalid        0     1     1     1     1
tready        1     0     0     1     1
tdata         -     A     A     A     B
tlast         -     0     0     0     1
accepted      .     .     .     A     B(end)
```

源有数据时可拉高 TVALID，不能等 TREADY 才启动。TVALID 一旦置位，等待期间有效位和所有载荷保持稳定。包尾在 TLAST 的那拍实际接受后才生效。

## 测试点

- 单拍包、连续多拍包、背靠背包、可选部分有效字节。
- 在首拍、中间与 TLAST 注入背压，核对稳定性、排序和包尾。
- 复位与恢复，按冻结约定检查未送达的数据。

## 常见错误

忽略 TLAST 背压、每个时钟推进数据、只在 TREADY=1 时拉高 TVALID、等待时改变 TKEEP。

## SVA 建议

- `tvalid && !tready |=> tvalid && $stable({tdata,tlast,tkeep})`，删去未启用的 sideband。
- 用监视器按接口的包长约定检查每个包只出现一次已接受的 TLAST。
