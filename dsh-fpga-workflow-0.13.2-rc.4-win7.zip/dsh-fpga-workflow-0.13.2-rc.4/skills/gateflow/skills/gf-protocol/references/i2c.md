# I2C

基础子集使用 7 位地址和单 controller。Plan MUST 明确读写、repeated START、clock stretching 和错误处理的支持范围。

## 端口

| 信号 | 位宽 | 方向 | 用途 |
|---|---|---|---|
| scl | 1 | 双向开漏 | controller 拉低，支持 stretching 时 target 可保持低 |
| sda | 1 | 双向开漏 | 地址、数据和 ACK/NACK |
| clk / rst_n | 1 / 1 | → 本地逻辑 | 本地采样及复位 |
| scl_drive_low / sda_drive_low | 1 / 1 | 本地 → I/O 单元 | 可选内部封装接口 |

## 时序

```text
SCL high slots   START   bit 7   bit 6  ...  bit 0   ACK   STOP
SDA at high      1 -> 0   b7      b6    ...   b0      0    0 -> 1
driver           ctrl    sender  sender     sender  recv   ctrl
```

START/STOP 是 SCL 高时 SDA 的下降/上升。普通数据和 ACK 在 SCL 高时稳定，变化安排在低区间。首字节由地址和 R/W 组成，MSB first。第 9 拍发送端释放 SDA，由接收端拉低应答或释放产生 NACK。读最后一字节时 controller 发 NACK，再按约定结束。支持 stretching 时观察实际 SCL 已为高才推进。

## 测试点

- 空闲上拉、START、地址和 R/W，第 9 拍接收端接管。
- 地址不匹配、NACK、读末字节的 NACK、STOP 和下一事务。
- 按已支持的子集测 repeated START 与拉伸。复位后释放两条线。

## 常见错误

主动驱动高电平、忘记 ACK 期间释放 SDA、把地址左移两次、以驱动意图代替引脚实际电平。

## SVA 建议

- 本地时钟验证处于空闲时两个 drive_low 都撤销。
- 用同步采样的 SCL/SDA 检查 SCL 高期间 SDA 稳定，显式排除 START/STOP。
