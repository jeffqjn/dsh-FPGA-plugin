# SPI

冻结 SCLK 频率、CPOL/CPHA、位序、字长、CS 有效电平及相邻字如何分帧。以下例子为低有效 CS、8 位 MSB first、mode 0。

## 端口

| 信号 | 位宽 | 方向 | 用途 |
|---|---|---|---|
| sclk | 1 | controller → peripheral | 串行时钟 |
| cs_n | 1 或 N | controller → peripheral | 控制目标选中 |
| mosi | 1 | controller → peripheral | 正向数据 |
| miso | 1 | peripheral → controller | 反向数据，共享时未选中端释放 |
| clk / rst_n | 1 / 1 | → 本地逻辑 | 本地时钟及复位 |

## 时序

leading 是离开空闲电平的边沿，trailing 是返回空闲电平的边沿。CPOL 决定空闲电平。CPHA=0 在 leading 采样，首位 MUST 提前建立；CPHA=1 在 trailing 采样，首个 leading 用来移出首位。

```text
mode 0       CS setup    first bit        next bit         end
cs_n        ----\__________________________________________/---
sclk        ____________/^^^^^\__________/^^^^^\___________
sample                  ^                 ^
MOSI/MISO     [d7 stable]     [d6 stable]       [next data]
```

## 测试点

- 仅测试声明支持的四种 mode 中的模式，检查首位、末位、总边沿数和空闲电平。
- `00 FF 80 01` 双向对拍。连续字和多 CS 测试按实现声明。
- 检查 CS setup/hold 及复位时 CS 和 SCLK 的空闲状态。

## 常见错误

把所有 mode 都当成上升沿采样、CPHA=0 没预装首位、最后一位前撤销 CS、未选中端仍驱动共享 MISO。

## SVA 建议

- 在本地时钟监测活动传输期间 CS 保持有效。
- 对 controller 检查空闲时 `sclk == CPOL`，并用边沿计数器校验每字采样次数。
