# UART

范围为逻辑电平 UART 8N1，空闲 1、1 个低电平 start、8 个数据位、无校验、1 个高电平 stop。分频取整或分数分频方式、时钟与波特率 MUST 冻结。

## 端口

| 信号 | 位宽 | 方向 | 用途 |
|---|---|---|---|
| clk / rst_n | 1 / 1 | → TX 或 RX | 本地时钟与复位 |
| tx_out / rx_in | 1 | TX → RX | 异步串行线 |
| tx_data / tx_valid | 8 / 1 | 上游 → TX | 待发送字节 |
| tx_ready | 1 | TX → 上游 | 能接受字节 |
| rx_data / rx_valid | 8 / 1 | RX → 下游 | 接收到的字节 |
| rx_ready / framing_err | 1 / 1 | 下游 → RX / RX → 下游 | 可选反馈及帧错误 |

## 时序

```text
slot     idle   start  d0   d1  ...  d7   stop  idle/start
line       1      0    b0   b1  ...  b7     1        1/0
sample            ^    ^    ^        ^     ^
                each ^ near the middle of its bit slot
```

数据 LSB first。TX 在本地握手后保存字节并保持每个位的规定时长。RX 对异步输入同步，检测 start 后先核对位中央仍为低，再按位周期采样。stop 为低且支持报错时按约定给出 framing error。无缓冲 RX 要写明背压时如何处理。

## 测试点

- 空闲电平、start/stop、位时长和数据顺序。
- `00 FF 01 80 55 AA`，连续帧之间至少有完整 stop。
- 若含 RX，测短低脉冲、错误 stop 和约定的波特率误差。测复位中断及下一完整帧。

## 常见错误

把 MSB 先发、缩短 stop、计数多一拍、RX 在边沿采样、在 valid 尚未握手时覆盖字节。

## SVA 建议

- `tx_valid && !tx_ready |=> tx_valid && $stable(tx_data)`，由发送数据的上游负责。
- 每次接受事务后按冻结延迟进入 start；用帧位计数检查 stop 槽全程为高。
