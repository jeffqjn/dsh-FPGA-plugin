# Wishbone

范围为同步 Classic 单数据相位事务。冻结地址粒度、字节序、握手响应和复位。流水模式的 STALL 不在该子集内。

## 端口

| 信号 | 位宽 | 方向 | 用途 |
|---|---|---|---|
| clk / rst_n | 1 / 1 | → 双方 | 本地时钟、低有效复位，接入既有总线时按接口适配极性 |
| cyc / stb | 1 / 1 | master → slave | 总线周期及当前请求 |
| adr / dat_w | ADDR_W / DATA_W | master → slave | 地址及写数据 |
| sel / we | DATA_W/8 / 1 | master → slave | 字节选择及写使能 |
| dat_r / ack | DATA_W / 1 | slave → master | 读数据及正常结束 |
| err / rty | 1 / 1 | slave → master | 可选错误和重试结束 |

## 时序

```text
posedge         1     2     3     4
cyc/stb         0     1     1     0
addr/we/sel     -     A     A     -
ack             0     0     1     0
dat_r           -     -     Q     -
transfer        .     .     *     .
```

等待终止时维持 CYC、STB 和请求字段。上升沿在 CYC、STB 有效且收到 ACK 时完成，读数据同拍采样。支持 ERR/RTY 时按所声明的响应结束，不与 ACK 同时有效。写寄存器只在约定的接受或完成事件更新一次。

## 测试点

- 读写、立即及延迟 ACK、逐字节 SEL 和地址边界。
- 背靠背独立事务，检查延迟时不重复提交。
- 支持时检查 ERR、RTY 及复位后的空闲状态。

## 常见错误

ACK 时 CYC 已撤销、在等待周期重复写入、混淆字地址和字节地址、用一直有效的 ACK 假造响应。

## SVA 建议

- `cyc && stb && !(ack||err||rty) |=> cyc && stb && $stable({adr,we,sel,dat_w})`，未实现响应接 0。
- Classic 子集检查终止响应有效时 CYC 与 STB 有效，并检查 ACK/ERR/RTY 互斥。
