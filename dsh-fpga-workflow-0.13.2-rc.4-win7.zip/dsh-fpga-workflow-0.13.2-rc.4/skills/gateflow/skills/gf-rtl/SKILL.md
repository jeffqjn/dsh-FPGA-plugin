---
name: gf-rtl
description: >
  Internal — loaded by gf-run. Generate synthesizable RTL from the frozen
  interface when building or modifying a Verilog or SystemVerilog component.
---

# RTL 实现

## 输入与产物

输入为 `TaskSpec`、Plan 中分配的 component 和冻结接口文件。只写入 builder 指定的目录，输出 Verilog-2001 RTL。若任务要求 SystemVerilog，使用 `.sv`。将实际相对路径、SHA-256 和模块名填入 `FileSet.rtl` 与 `top`，由 builder 合入 `tb` 和 `tb_top` 后返回完整 FileSet。

协议模块 MUST 先按 `gf-protocol` 找到并阅读对应 reference，以冻结接口指定的角色、协议子集和时序实现。引用已有 IP 时沿用其接口约定。

实现前 MUST 读取 [RTL 编码与 lint 判定规范](../../rules/rules.md) 中适用条款，按目标器件和冻结接口核对。下列生成约定用于本流程。

## 强制规则

1. 模块、端口和内部信号 MUST 使用 `snake_case`。参数和局部常量 SHOULD 使用 `UPPER_SNAKE_CASE`。
2. 复位 MUST 用低有效 `rst_n`，同步或异步按照冻结接口。复位分支必须为时序寄存器赋确定值。
3. 时序块 MUST 使用 `always_ff`（SystemVerilog）或 `always @(posedge clk)`（Verilog，同步复位示例）。异步复位按需加入 `negedge rst_n`。
4. 时序块 MUST 使用非阻塞赋值 `<=`，组合块 MUST 使用阻塞赋值 `=`。
5. 组合输出和 `next_state` MUST 先给默认值并覆盖所有路径，防止隐式 latch。
6. 端口、寄存器及常量 MUST 使用明确位宽，参数派生位宽需核对最小配置和截断。有符号运算需声明符号属性。参数、局部参数和函数作用域之外的变量使用显式 packed 位宽，例如 `parameter [31:0] DEPTH = 32'd16`、`reg signed [15:0] delta`。
7. 本地逻辑 MUST 只使用一个时钟域。跨时钟需求要先明确域划分与 CDC 接口，再按 Plan 拆分组件。
8. RTL MUST NOT 使用 `initial`、`#delay` 或 `$display`。
9. 每个 `case` MUST 有 `default`，FSM 的非法态 MUST 回到已定义状态。
10. 模块名、端口名、方向、位宽、参数和时序 MUST 与冻结接口一致。

## Verilog-2001 模板

这个例子实现带使能的同步复位寄存器，也可作为 [自检模板](../../templates/tb_basic.v) 的 dummy DUT。

```verilog
`timescale 1ns/1ps
`default_nettype none
module dut_example #(
    parameter [31:0] DATA_WIDTH = 32'd8
) (
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  data_en,
    input  wire [DATA_WIDTH-1:0] data_in,
    output reg  [DATA_WIDTH-1:0] data_out
);
    always @(posedge clk) begin
        if (!rst_n)
            data_out <= {DATA_WIDTH{1'b0}};
        else if (data_en)
            data_out <= data_in;
    end
endmodule
`default_nettype wire
```

## SystemVerilog 模板

仅在 TaskSpec 要求 SystemVerilog 时使用。

```systemverilog
`default_nettype none
module data_register #(
    parameter [31:0] DATA_WIDTH = 32'd8
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 data_en,
    input  wire [DATA_WIDTH-1:0] data_in,
    output reg  [DATA_WIDTH-1:0] data_out
);
    reg [DATA_WIDTH-1:0] next_data;

    always_comb begin
        next_data = data_out;
        if (data_en)
            next_data = data_in;
    end

    always_ff @(posedge clk) begin
        if (!rst_n)
            data_out <= {DATA_WIDTH{1'b0}};
        else
            data_out <= next_data;
    end
endmodule
`default_nettype wire
```

## 两段式 FSM

第一段更新状态，第二段给出下一状态的默认值和非法态恢复路径。此片段假定模块已声明 `clk`、`rst_n`、`start`、`done`。

```verilog
localparam [1:0] IDLE = 2'd0, BUSY = 2'd1;
reg [1:0] state, next_state;

always @(posedge clk) begin
    if (!rst_n)
        state <= IDLE;
    else
        state <= next_state;
end

always @* begin
    next_state = state;
    case (state)
        IDLE: if (start) next_state = BUSY;
        BUSY: if (done)  next_state = IDLE;
        default: next_state = IDLE;
    endcase
end
```

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。快速仿真使用 Icarus Verilog 11（`iverilog`、`vvp`）。UVM、覆盖率和 SVA 使用 ModelSim 2018（`vlib`、`vlog`、`vsim`、`vcover`）。可选波形工具为 GTKWave 3.3.x（`gtkwave`）。运行路径使用纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] RTL 符合冻结的接口、复位和协议时序。
- [ ] 组合路径完整，寄存器可复位，位宽与符号经过核对。
- [ ] FileSet 中的路径、哈希和 `top` 匹配实际产物。

## Failure handling

缺少接口、参数越界或需求与冻结接口矛盾时，MUST 将具体字段及冲突返回给 `gf-run`。编译报错时保留原始日志，按主 agent 分配的范围定位和修改。
