---
name: gf-run
description: >
  Entry point for RTL design and verification when the user asks to create,
  modify, test, debug, or verify a Verilog or SystemVerilog hardware module,
  or to run hardware simulation, lint, UVM, or coverage.
---

# GateFlow Lite 入口

## 何时使用

用于新建或修改 RTL、编写自检 TB、运行指定 DUT、处理仿真失败、运行 lint、UVM 或覆盖率。生成或修改任务中，单模块也走完整流程，集成阶段记录为不适用。

```text
Preflight → Normalize → Route → Plan → Build (并行 ≤2) → Integrate
  → Verify (完整 RTL FileSet 轻量 lint → sim → uvm → cov)
  → Fix (需要时，最多 3 轮并从 lint 重验) → Report
```

## DUT 仿真器选择

| 用户意图 | 选择 |
|---|---|
| 生成或修改 RTL/TB 后自动自检 | 先做轻量 RTL Lint，再固定用 Icarus Verilog 自检 |
| 明确要求用普通 TB 给指定 DUT 做仿真 | 读取 `simulator=iverilog` 或 `simulator=modelsim`。后者也接受用户说的 ModelSim 或 QuestaSim。未指定时用宿主配置 `sim.default_simulator`，默认 `iverilog` |
| 同时生成 RTL/TB，并另外要求用 ModelSim/QuestaSim 仿真 | 先跑 Icarus 自动自检，通过后用同一普通 TB 执行显式 ModelSim 仿真，分别保留结果 |

`simulator` 是普通 DUT 仿真器参数，和 `language`、RTL 参数、UVM 与覆盖率门控独立。收到不支持的值时列出两个取值并等待选择。有额外 DUT 仿真请求时在更改或生成任务的 TaskSpec 中记录该选择。只请求生成和自动自检时，按 Icarus 流程执行。

### 使用现有 RTL 和普通 TB 仿真

1. 从现有输入确定 DUT `top`、仿真 `tb_top`、语言和两组源码。将 RTL、TB 和它们依赖的文件按原相对布局复制到可写的 ASCII `run_dir`，复用现有 FileSet 时核对实际 SHA-256 和顶层；否则按下文的 FileSet 格式生成 `fileset.json`。在 TaskSpec 记录 `simulator` 和 `language`。仅运行现有 RTL/TB 时直接调用仿真入口，无需生成 RTL/TB 或派发 builder。若还请求 lint、UVM 或覆盖率，按 Verify 的阶段顺序执行对应检查，使用该入口的结果作为普通 TB 仿真证据。
2. 使用宿主命令工具运行包内 [tools/dut_sim.py](../../tools/dut_sim.py)。将示例参数替换成实际值，传入有效配置（缺省用包内示例），按总预算限制超时。工具只需要所选仿真器的可执行文件。普通 ModelSim 仿真使用 `vlib`、`vlog`、`vsim`，不受 UVM／覆盖率门控限制。

~~~bat
python -B tools\dut_sim.py --run-dir D:\gf\runs\reg8_dut_001 --fileset fileset.json --simulator modelsim --language verilog
~~~

3. 解析脚本返回的 JSON，核对 `status`、`simulator`、`compile.ok`、`sim.pass` 和本轮日志；将实际结果写入 `report.json`。自检 TB 应输出一次 `TEST PASSED` 或 `TEST FAILED`。无有效结束证据、报错或超时都不得判通过。生成了 VCD 时核对 `sim.vcd_signals`，空波形以 `stage=waveform` 报失败。所选工具不可用时返回 `NEEDS_HUMAN` 并指出缺项，禁止自动换仿真器。仅执行实际仿真时，`attempts` 按本轮启动的仿真验证次数记录。

## 0. Preflight

- 启动 30 分钟总计时，核对本会话实际可调用的宿主工具。宿主有 `gf_doctor` 时 MUST 调用。无对应结果时，记录宿主缺项及未知能力。
- 对生成任务核对命令执行、Python、包内 Lint 规则和 Icarus 的 `iverilog`、`vvp`。可用宿主探测；没有 `gf_doctor` 时通过宿主命令工具核对配置路径或用 `iverilog -V`、`vvp -V` 验证。`gf_lint`、`gf_sim` 未注册时，轻量 Lint 和普通自检直接用随包入口。有生成需求时仍需 Plan、Build 所需的子 agent 能力。实际缺少所需可执行工具或能力时，记录并进入 Report。
- 读取 `modelsim.gates.uvm` 和 `modelsim.gates.coverage`。只有布尔 `true` 开启对应能力。未就绪的分支按 Verify 规则处理。
- 为可执行的任务分配纯 ASCII 的 `D:\gf\runs\<id>` 并检查可写。按需复制已有 RTL/TB 到 run 目录。本地 IP、已启用的 UVM 或所请求的覆盖率工具缺失时，记录缺项并停止。

## 1. Normalize

将需求整理为 `TaskSpec` 并保存在 run 目录。MUST 记录假设，`language` 默认 `verilog`。只问会影响接口、时序或验收的缺项，最多问 3 个问题。需要人工选择时停止，保留已知信息。

```json
{"name":"uart_tx","summary":"8N1 transmitter","language":"verilog",
 "params":{"CLK_FREQ":100000000,"BAUD_RATE":115200},
 "ports":["clk","rst_n","tx_data[7:0]","tx_valid","tx_ready","tx_out"],
 "protocol":"uart","assumptions":["LSB first","single clock"]}
```

## 2. Route

按需读取内部 skill 正文，文件在包内的 `skills/<name>/SKILL.md`。协议任务 MUST 先由 `gf-protocol` 定位并读取对应参考。

| 需求 | 内部 skill |
|---|---|
| RTL、接口实现 | `gf-rtl` |
| 自检、激励、scoreboard | `gf-tb` |
| 编译失败、仿真失败、超时 | `gf-debug` |
| RTL 规则检查 | `gf-lint` |
| 本地 IP 查询与绑定 | `gf-ip` |
| UVM 测试 | `gf-uvm`，受能力门控 |
| 覆盖率 | `gf-cov`，按探测结果选采集模式 |

## 3. Plan

主 agent 使用 DSH 的原生子 agent 派发和等待能力。传入对应提示词正文、输入 JSON、需要加载的 skill/协议参考以及读写范围。以本会话公布的工具为准，在支持 `subagent`、`wait_agent` 的宿主上启动后等待并收集返回。读取 [planner](../../prompts/planner.md)，传入 `TaskSpec`。MUST 核对 component ID 唯一、依赖无环、测试可判定，且逐拍期望与冻结接口时序一致。多组件的独立系统顶层也必须有接口文件。将 `Plan` 和 `interfaces` 中声明的接口文件写入 run 目录，冻结接口后才开始 Build。接口记录中锁定端口方向和位宽、参数、时钟复位及握手时序。subagent 返回 `NEEDS_HUMAN` 时进入 Report，累计提问仍以 3 个为上限。

```json
{"components":[{"id":"uart_tx","deps":[],"ports":["clk","rst_n","tx_data[7:0]","tx_valid","tx_ready","tx_out"],"interface_file":"if_uart_tx.json"}],
 "interfaces":[{"path":"if_uart_tx.json","module":"uart_tx",
 "ports":[{"name":"clk","dir":"input","width":1},{"name":"rst_n","dir":"input","width":1},
 {"name":"tx_data","dir":"input","width":8},{"name":"tx_valid","dir":"input","width":1},
 {"name":"tx_ready","dir":"output","width":1},{"name":"tx_out","dir":"output","width":1}],
 "params":{"CLK_FREQ":100000000,"BAUD_RATE":115200},
 "timing":"posedge clk, active-low reset, accept on valid && ready, idle high"}],
 "top":"uart_tx","testcases":["reset","corner_bytes","back_to_back"]}
```

## 4. Build

按 Plan 复用本地 IP 时，主 agent 先按 `gf-ip` 查询并暂存 IP，再把只读路径和冻结接口传给 builder。最终 FileSet 合入 IP、绑定模块和相应自检 TB，由 `gf_sim` 验证。

每个 component 交给一个 [builder](../../prompts/builder.md)，传入 TaskSpec、Plan、冻结接口、组件 ID、run 目录和专属写目录，例如 `components\uart_tx`。按依赖顺序运行，最多并行 2 个 builder。共享接口和其他 component 只读。

主 agent MUST 校验各返回路径相对 run 目录，解析真实路径后仍位于允许范围内。核对文件存在、实际 SHA-256、RTL 模块 `top` 和 TB 模块 `tb_top`。下面的哈希为占位符，运行结果 MUST 填写实际值。

```json
{"rtl":[{"path":"components/uart_tx/rtl/uart_tx.v","sha256":"..."}],
 "tb":[{"path":"components/uart_tx/tb/tb_uart_tx.v","sha256":"..."}],
 "top":"uart_tx","tb_top":"tb_uart_tx"}
```

## 5. Integrate

多组件时调用 [integrator](../../prompts/integrator.md)，传入已核验的组件 FileSet、Plan、接口和写目录 `integration`。只生成系统顶层与集成 TB。主 agent 合并组件 RTL/IP 与顶层 RTL，将集成 TB 用作本轮仿真入口，保留各组件 TB 供回归。重新校验合并结果，确认 `rtl` 覆盖全部参与仿真的子模块、顶层及依赖。RTL 引用的头文件用可选的 `headers` 数组列出，字段与 `rtl` 一致，供 Lint 核验。单组件直接使用 Build 的 FileSet。Build 和 Integrate 期间不启动仿真或仿真编译。

有 UVM 需求且门控开启时，主 agent 按 `gf-uvm` 为最终顶层准备独立的 UVM TB，核验文件、编译顺序及顶层。普通自检 TB 继续用于 Icarus。

## 6. Verify

1. **生成或修改的 RTL 必须先过轻量 Lint。** 主 agent 在本轮首次仿真编译前，用合并后的完整 RTL FileSet 调 `tools/dut_sim.py --lint-only`，或直接按下方命令启动带 `--lint` 的集成验证。以包内 `rules/rules.json` 的编号和等级判定。必须有本轮 `lint.ok=true`、`lint.log` 以及覆盖完整 RTL FileSet 的 SHA-256 记录，才能启动组件或集成 TB 的仿真编译。mandatory 违规进入 Fix，recommended 记到报告。缺失文件、规则、结果或日志时进入 Report。明确要求完整规则审查时，再按 `gf-lint` 做完整审查并在仿真前取得结果。
2. 自动自检用 `tools/dut_sim.py --simulator iverilog --lint`。如果仅在宿主工具中调用 `gf_sim`，主 agent MUST 先执行 `--lint-only`，核对全部待仿真的 RTL 路径和哈希，再传给 `gf_sim`。组件回归与集成使用各自的 `tb_top`，组件用到的 RTL 必须已通过本轮检查。若任一 RTL 或相关头文件改变，必须重新检查后才能继续。只有 `compile.ok=true` 且 `sim.pass=true` 才进入后续验证。
   如果用户还请求 DUT 仿真且解析后的 `simulator` 为 `modelsim`，此时用同一普通 TB 的 FileSet 调 `tools/dut_sim.py --simulator modelsim --lint`，结果另记为 `dut_sim`。选择 Icarus 且 FileSet 相同时，可复用本轮 Icarus 自检作为 DUT 仿真证据。
3. 有 UVM 需求且 `gates.uvm=true` 时调用 `gf_uvm`，要求其 `pass=true`。UVM 使用共享已核验 RTL 的独立 FileSet，`tb` 与 `tb_top` 指向 UVM 文件及顶层，按编译顺序列出。Icarus 的 FileSet 只包含普通自检 TB。门控关闭时跳过，报告 `UVM unavailable (edition/license)`。无 UVM 需求则记为 skipped。
4. 有覆盖率需求时调用 `gf_cov`。门控启用时，使用本轮 UVM 覆盖率数据库，或按 `gf-cov` 用 ModelSim 单独采集普通 TB 的覆盖率，再按门限检查。门控关闭时用本轮已通过的普通 TB 仿真日志中的计数器对照测试计划。TB 计数器 SHOULD 在 Build 时备好。报告注明所用模式和回退原因。无需求记为 skipped。

自动自检的组合命令如下，`--lint` 通过后才会启动编译。

~~~bat
python -B tools\dut_sim.py --run-dir D:\gf\runs\fifo_001 --fileset fileset.json --simulator iverilog --language verilog --lint
~~~

每轮 MUST 记录实际 `VerifyResult`。各阶段按顺序执行，失败的前置阶段阻断后续阶段。生成流程须有本轮 Lint 通过证据，以及 `dut_sim.py` 或宿主 `gf_sim` 返回的布尔值 `sim.pass=true`。使用 `dut_sim.py` 时还须核对整体 `status=PASS`，波形阶段失败也会阻断后续验证。显式 DUT 仿真必须有对应仿真器的通过证据。相关日志 MUST 落盘并在报告中列路径。MUST NOT 用主观判断替代证据，MUST NOT 删 TB 断言或放宽检查来放行。

```json
{"lint":{"ok":true,"findings":[],"log":"logs/attempt_1/lint.log"},
 "compile":{"ok":true,"log":"logs/attempt_1/compile.log"},
 "sim":{"pass":true,"log":"logs/attempt_1/sim.log","vcd":"build/wave.vcd"},
 "uvm":{"pass":true,"errors":0,"fatal":0,"log":"logs/attempt_1/uvm.log"},
 "coverage":{"mode":"code","line":92.1,"branch":81.0,"toggle":84.0,
 "thresholds":{"line":90,"branch":80,"toggle":80},"pass":true,"report":"logs/attempt_1/cov.txt"}}
```

## 7. Fix

把失败阶段的 FileSet、VerifyResult、当前诊断和允许修改的路径传入 [fixer](../../prompts/fixer.md)。MUST 先定位失败证据，每轮只修一个根因。核对 `diagnosis`、`changed`、产物与哈希，重新执行 Verify。若两份 FileSet 共用的 RTL 被修改，同步更新哈希。若宿主会覆盖日志，复跑前将日志归档到本轮的专用子目录。按阶段、根因和稳定错误标识比较失败，时间戳、行号等变化不视为新错误。

轻量 Lint 同时有多处强制违规时，每轮按以下步骤处理。

1. 主 agent 从当前 `lint.log` 的 `findings` 选一条 mandatory 发现，记录其零基 `target_index` 与 `target_finding`。把当前 FileSet 复制到本轮候选目录，保持相对路径，只授权 fixer 修改该发现所在文件。
2. 核对候选文件实际差异、接口及 TB 哈希。在候选目录更新 FileSet 哈希，跑 `dut_sim.py --lint-only` 得到新日志。其他强制违规仍存在时，本次候选 Lint 可以返回 FAIL，存下日志供下一步检查。
3. 用 [lint_fix_check.py](../../tools/lint_fix_check.py) 对照基线与候选日志。例如目标是 `findings` 第一项时执行：

~~~bat
python -B tools\lint_fix_check.py --before D:\gf\runs\fifo_001\baseline\lint.log --after D:\gf\runs\fifo_001\candidate\lint.log --target-index 0
~~~

4. 只有 `accepted=true` 才采纳候选文件及新哈希。校验另一处强制违规的增删和未授权 RTL 变更时使用日志中完整的 `mandatory_counts` 与 `source_sha256`。候选被拒绝时保留证据，用原基线执行本轮预算判断。采纳后从完整 Verify 的 Lint 阶段重跑。剩余强制违规进入下一轮，直到 Lint 通过才编译。

## 8. Report

在运行目录将 `RunReport` 写入 `report.json`，附实际文件、每阶段结果、日志路径、已探测的 ModelSim 门控和假设。为每次仿真记录实际使用的 `simulator`。`attempts` 统计已启动的 Verify 次数，含初次验证。PASS 要求所有实际请求的仿真和已启用的检查均有通过证据。FAIL 记录已证实的失败。缺失工具或证据、越界或需要选择时记为 NEEDS_HUMAN。报告分支可用 skipped、FAIL 或 pending 显示实际状态。

```json
{"status":"PASS","attempts":1,
 "files":{"rtl":["components/uart_tx/rtl/uart_tx.v"],"tb":["components/uart_tx/tb/tb_uart_tx.v"]},
 "simulator":"iverilog",
 "verify":{"lint":"PASS","sim":"PASS","uvm":"skipped","coverage":"skipped"},
 "logs":["logs/attempt_1/lint.log","logs/attempt_1/compile.log","logs/attempt_1/sim.log"],
 "notes":["UVM unavailable (edition/license)","ModelSim coverage unavailable; coverage not requested"]}
```

## 9. 停止条件

每轮修复前 MUST 检查预算。同一错误出现 2 次、3 轮修复后仍失败或达到 30 分钟时，MUST 停止重试。宿主调用的超时不得超过剩余总时长。工具、输入或产物缺失、路径越界、契约无法验证或需要人工选择时立即停止。保留已有产物与证据并进入 Report。

## 10. 环境约定

Windows 7 SP1 64-bit，Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog` / `vvp`。ModelSim 或 QuestaSim 使用 `vlib` / `vlog` / `vsim` 进行 DUT 仿真，UVM、覆盖率、SVA 以实际能力为准。GTKWave 3.3.x（`gtkwave`）可选。运行路径 MUST 为纯 ASCII，产物和日志只写入 `D:\gf\runs\<id>`，文本为 UTF-8 无 BOM。

## Checklist

- [ ] 生成任务的 Preflight 记录 Icarus 和 ModelSim 门控，Plan 已冻结接口。显式 DUT 仿真记录选择的仿真器和实际结果。
- [ ] FileSet 路径、哈希、模块顶层已校验。全部子模块和集成顶层均列在本轮仿真前的 Lint 证据中。
- [ ] 报告引用实际日志，PASS 可追溯到 `sim.pass=true`。

## Failure handling

JSON 无效、日志缺失或工具异常时，保留原始返回和已有日志，记录具体缺失字段与阶段并进入 Report。若预检在创建 run 目录前失败，或该目录无法写入，在 DSH 回答中给出等价的 RunReport 和相应原因。
