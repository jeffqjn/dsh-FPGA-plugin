---
name: gf-tb
description: >
  Internal — loaded by gf-run. Build a self-checking testbench from the frozen
  interface and test plan when a component or integrated design needs simulation.
---

# 自检 Testbench

## 输入与产物

输入为 `TaskSpec`、冻结接口、Plan 的 `testcases` 和 DUT 顶层。测试协议模块时先读 `gf-protocol` 的对应 reference。按 builder 或 integrator 分配的目录生成 TB，并用实际相对路径、SHA-256 和模块名填写 `FileSet.tb`、`tb_top`。主 agent 按 `gf-run` 对 RTL 做 Lint，再运行自检。

## 强制规则

1. TB MUST 自检。用外部可观测信号与期望比较，未知值应判为失败。
2. MUST 设置 watchdog。超时记录 `TIMEOUT`，计为错误并结束仿真。
3. MUST 产生 VCD，路径位于 run 目录内。
4. 同步激励 MUST 在 `negedge` 驱动。握手在 `posedge` 采样，当拍寄存器输出在非阻塞更新后检查。
5. 初始及运行中复位 MUST 按接口极性保持至少 3 个有效时钟周期，再于 `negedge` 释放。
6. MUST 覆盖复位、正常、角值与边界。协议错误或恢复行为按冻结的协议子集测试。
7. 终止时 MUST 根据 `errors` 仅输出一次 `TEST PASSED` 或 `TEST FAILED`。
8. 没有执行任何检查、scoreboard 仍有未对比交易或 watchdog 超时，MUST NOT 输出 PASS。
9. MUST NOT 删除检查或放宽断言来使测试通过。

## 模板与采样

使用 [templates/tb_basic.v](../../templates/tb_basic.v) 作为 Verilog-2001 骨架。将示例端口、激励和期望值换成冻结接口和测试矩阵中的实际用例。时钟用 `always #5 clk = ~clk`。`check(condition, label)` 计入已执行检查，用 `condition !== 1'b1` 把 0、X、Z 都统计为错误。watchdog 经过 `WATCHDOG_NS` 后调用同一检查与结束任务。检查当拍寄存器输出时，示例在上升沿后等待 `#1`，采样点仍位于下一次下降沿之前。

用 `gf-rtl` 的 Verilog-2001 示例作为 `rtl\dut_example.v`，将模板复制为 `tb\tb_basic.v`。本轮 RTL 通过 Lint 后，在 run 目录执行以下命令可手工复现。正式 RunReport 使用 `dut_sim.py` 或宿主 `gf_sim` 的结构化结果。

```bat
iverilog -g2001 -Wall -o tb.vvp rtl\dut_example.v tb\tb_basic.v
vvp tb.vvp
```

## 测试矩阵

| 用例 | 观察项 |
|---|---|
| 复位 | 按接口时序检查输出、状态对外表现、握手空闲值 |
| 正常 | 至少一次有效事务，按延迟约定核对结果 |
| 角值 | 最小值、最大值和首尾位型，按需加入全 0、全 1、单比特、交替位 |
| 背靠背 | 连续接受事务，检查顺序、丢失、重复及等待时稳定性 |
| 错误 | 只对接口已定义的错误或拒绝行为检查返回与状态 |
| 复位恢复 | 有活动时触发复位，按接口清理未完成事务，再发新事务 |

## Scoreboard

在输入接受事件生成期望事务并推进 `exp_q`，输出接受事件推进 `got_q`。valid/ready 接口在 `posedge` 且 `valid && ready` 时记一次。每次两队列都有内容就对比并消费队首，用 case equality 判定数据，按接口约定核对顺序。Verilog-2001 使用定长数组和读写计数，队列越界 MUST 记为错误。

给设计一个有明确上限的排空窗口。检查空队列、入队和出队总数以及额外输出。复位时只按接口定义清理事务。需要功能计数器时按测试计划输出 `COV <name> <hits>`，命中数来自实际观察。

## 常见错误

| 现象 | 调整 |
|---|---|
| 同一 `posedge` 驱动和采样导致偶发结果 | 在 `negedge` 驱动，按握手与寄存器更新的时点分别采样 |
| 仿真一直运行 | 用独立 watchdog 并限制等待条件的轮数 |
| 未检查就输出 PASS | 统计执行的检查和错误，结束前校验排空 |
| 依赖 DUT 内部信号判断功能 | 用端口和接口定义计算期望 |
| 只测 `8'h55` | 增加不同位型、边界、连续事务和复位恢复 |

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。快速仿真使用 Icarus Verilog 11（`iverilog`、`vvp`）。UVM、覆盖率和 SVA 使用 ModelSim 2018（`vlib`、`vlog`、`vsim`、`vcover`）。可选波形工具为 GTKWave 3.3.x（`gtkwave`）。运行路径使用纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] 测试矩阵能追溯到 Plan，证据来自外部端口和实际自检。
- [ ] 复位、采样时序、watchdog、VCD 和终止标记齐全。
- [ ] Scoreboard 在结束时已经排空，未知值与超时均记为失败。

## Failure handling

出现未知值、超时或数据不匹配时，MUST 保留首个失败的时刻、用例、期望值和实际值，并交给 `gf-run` 定位。若 TB 与冻结接口不一致，按接口修正激励或采样，保留测试目标和验收条件。
