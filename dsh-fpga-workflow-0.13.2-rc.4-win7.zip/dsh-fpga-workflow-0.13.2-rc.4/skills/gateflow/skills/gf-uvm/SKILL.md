---
name: gf-uvm
description: >
  Internal — loaded by gf-run. Build and run a gated UVM 1.2 test
  when verification requires ModelSim.
---

# UVM 1.2 验证

## 能力门控

先读取本轮 `gf_doctor` 结果，没有结果时调用它。只有 `modelsim.gates.uvm=true` 才进入 UVM。为 false、缺失或探测失败时结束本分支，报告 `UVM unavailable (edition/license)`，MUST NOT 编译 `uvm_pkg.sv`。Icarus 基础闭环独立运行。

## 环境结构

按 [UVM 环境模板](../../templates/uvm_env.md) 组织 `interface`、`transaction`、`driver`、`monitor`、`agent`、`env`、`test`、`scoreboard` 和 `tb_top`。组件用 UVM 1.2 经典 API 及对应 factory 注册宏。MUST 避免依赖 SV-2012 新语法。sequence 通过 sequencer/driver 驱动，monitor 从接口重建已观察事务，scoreboard 比较。需要功能覆盖率时在 monitor/scoreboard 采样。

test 成对调用 `raise_objection` / `drop_objection`，等待实际比较完成。虚接口的 `config_db` 类型、字段名与实例路径 MUST 一致。自检、排空和 watchdog 均应存在。

## ModelSim 2018

由宿主 `gf_uvm` 组织编译和运行。在纯 ASCII run 路径创建 logs 目录。以下命令假定 `UVM_HOME` 指向已安装的 UVM 1.2 根目录。使用宿主已映射的 UVM 1.2 库时采用该映射，避免同名 package 重复编译。

```bat
vlib work
vlog -sv +define+UVM_NO_DPI +incdir+"%UVM_HOME%\src" "%UVM_HOME%\src\uvm_pkg.sv"
vlog -sv +incdir+"%UVM_HOME%\src" rtl\dut_example.v tb\data_if.sv tb\env_pkg.sv tb\tb_top.sv
vsim -c -nodpiexports -onfinish stop -l logs\uvm.log work.tb_top +UVM_TESTNAME=base_test -do "run -all; quit -f"
```

此基础例子禁用 UVM 的 DPI 和模拟器的 DPI export wrapper，避免依赖 C/C++ 编译器。先核对实机支持 `-nodpiexports`。需要 DPI 的环境 MUST 使用宿主配置的库和编译器，不应用该选项。仅当覆盖率门控开启且有相关请求时，按 `gf-cov` 对 DUT 插桩并保存数据库。

## 通过判据

MUST 证明测试运行、完成自检、没有超时和错误。日志有最终 `UVM_TEST_PASSED`，或完成摘要中 `UVM_ERROR:0` 与 `UVM_FATAL:0` 均成立（允许空白），可作为宿主判定证据。编译/执行错误、非零 UVM 错误或致命项、缺比较和未到结束均拒绝通过。MUST NOT 单凭进程退出码判定。向主 agent 返回宿主结构化 `pass` 及日志路径。

## 常见问题

| 现象 | 核对 |
|---|---|
| 找不到 uvm_pkg | 门控、UVM 1.2 路径、库映射和编译顺序 |
| `vsim-7019` | 在无 DPI 的设计核对 `-nodpiexports`，在 DPI 设计核对宿主配置的 C/C++ 编译器 |
| 找不到 test / factory 类型 | 类注册宏和 `+UVM_TESTNAME` |
| run 没启动或无法结束 | objection 是否配对、monitor 是否观察到握手、watchdog |
| 虚接口为 null | config_db 类型、字段名、set/get 路径和 set 是否早于 run_test |
| 覆盖率无数据 | 门控、DUT 插桩、采样事件及 UCDB 保存 |

## 环境约定

Windows 7 SP1 64-bit。Python 3.8.10 仅标准库，PowerShell 2.0 环境下 MUST NOT 依赖其脚本逻辑。宿主入口为 `gf.cmd` → `python gf.py ...`。Icarus Verilog 11 使用 `iverilog`、`vvp`。ModelSim 2018 使用 `vlib`、`vlog`、`vsim`、`vcover`，负责 UVM、覆盖率、SVA。GTKWave 3.3.x（`gtkwave`）可选。运行目录为纯 ASCII 的 `D:\gf\runs\<id>`，文件为 UTF-8 无 BOM。

## Checklist

- [ ] 仅在 UVM 门控为 true 时编译或运行。
- [ ] 保留 UVM transcript、完成证据和实际 pass 结果。

## Failure handling

记录探测、编译、elaboration 或 test 的具体失败阶段。超时保留日志并退出，不以缺失摘要或退出码覆盖失败。
