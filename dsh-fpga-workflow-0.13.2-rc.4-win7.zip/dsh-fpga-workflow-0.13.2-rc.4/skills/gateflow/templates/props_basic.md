# 基础 SVA

示例应放入能看到冻结接口信号的 monitor 或绑定模块。信号名、采样时刻、复位语义和计数器宽度按实际接口替换。用 ModelSim 2018 前确认宿主支持所用 SVA。能力不可用时在自检 TB 中实现同等检查并记录。

```systemverilog
// Producer keeps a stalled transaction live with unchanged payload.
assert property (@(posedge clk) disable iff (!rst_n)
    out_valid && !out_ready |=> out_valid && $stable(out_data));

// Use only when the interface forbids adjacent pulse cycles.
assert property (@(posedge clk) disable iff (!rst_n)
    done_pulse |=> !done_pulse);

// Saturating counter, evaluated after the previous sampled update.
assert property (@(posedge clk) disable iff (!rst_n)
    take && count != MAX_COUNT |=> count == ($past(count) + 1'b1));
assert property (@(posedge clk) disable iff (!rst_n)
    take && count == MAX_COUNT |=> count == MAX_COUNT);

// Grants must not overlap.
assert property (@(posedge clk) disable iff (!rst_n)
    $onehot0({grant_a, grant_b}));

// Registered outputs idle after a synchronous active-low reset sample.
assert property (@(posedge clk)
    !rst_n |=> !out_valid && out_data == IDLE_DATA);
```

复位属性刻意在复位期间启用。`disable iff` 的异步中止语义要与其他属性的复位意图一致。对异步复位和组合空闲信号，应重新选择观察时刻。为每个关键 antecedent 单独计数或添加 `cover property`，确认断言有实际激励。自然语言报告引用日志里的失败时间与属性名。
