`timescale 1ns/1ps
`default_nettype none

// dut_example is an active-low synchronous-reset register with a write enable.
module tb_basic;
    localparam integer DATA_WIDTH  = 8;
    localparam integer WATCHDOG_NS = 1000;

    reg clk;
    reg rst_n;
    reg data_en;
    reg [DATA_WIDTH-1:0] data_in;
    wire [DATA_WIDTH-1:0] data_out;
    integer checks;
    integer errors;

    dut_example #(.DATA_WIDTH(DATA_WIDTH)) dut (
        .clk(clk), .rst_n(rst_n), .data_en(data_en),
        .data_in(data_in), .data_out(data_out)
    );

    always #5 clk = ~clk;

    task check;
        input condition;
        input [8*96-1:0] label;
        begin
            checks = checks + 1;
            if (condition !== 1'b1) begin
                errors = errors + 1;
                $display("[FAIL] t=%0t %0s", $time, label);
            end
        end
    endtask

    task expect_data;
        input [DATA_WIDTH-1:0] expected;
        input [8*96-1:0] label;
        begin
            if (data_out !== expected)
                $display("expected=0x%0h actual=0x%0h", expected, data_out);
            check(data_out === expected, label);
        end
    endtask

    task drive_and_check;
        input enable;
        input [DATA_WIDTH-1:0] value;
        input [DATA_WIDTH-1:0] expected;
        input [8*96-1:0] label;
        begin
            @(negedge clk);
            data_en = enable;
            data_in = value;
            @(posedge clk);
            #1;
            expect_data(expected, label);
        end
    endtask

    task finish_test;
        begin
            if (checks == 0)
                check(1'b0, "no checks executed");
            $display("checks=%0d errors=%0d", checks, errors);
            if (errors == 0)
                $display("TEST PASSED");
            else
                $display("TEST FAILED");
            $finish;
        end
    endtask

    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, tb_basic);
    end

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;
        data_en = 1'b0;
        data_in = 8'h00;
        checks = 0;
        errors = 0;

        repeat (3) @(posedge clk);
        #1;
        expect_data(8'h00, "initial reset clears the register");
        @(negedge clk);
        rst_n = 1'b1;

        drive_and_check(1'b1, 8'h35, 8'h35, "normal write");
        drive_and_check(1'b1, 8'hff, 8'hff, "back-to-back maximum");
        drive_and_check(1'b1, 8'h00, 8'h00, "back-to-back minimum");
        drive_and_check(1'b1, 8'h80, 8'h80, "top bit");
        drive_and_check(1'b0, 8'h7f, 8'h80, "disabled write holds old value");

        @(negedge clk);
        rst_n = 1'b0;
        data_en = 1'b1;
        repeat (3) @(posedge clk);
        #1;
        expect_data(8'h00, "reset overrides write enable");
        @(negedge clk);
        rst_n = 1'b1;
        data_en = 1'b0;
        drive_and_check(1'b1, 8'h01, 8'h01, "write after reset recovery");

        finish_test;
    end

    initial begin
        #WATCHDOG_NS;
        check(1'b0, "TIMEOUT: watchdog expired");
        finish_test;
    end
endmodule

`default_nettype wire
