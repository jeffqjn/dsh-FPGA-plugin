# UVM 1.2 环境模板

本例验证 [gf-rtl](../skills/gf-rtl/SKILL.md) 的带使能寄存器。保留 Verilog-2001 自检 TB 供 Icarus 独立运行。ModelSim UVM 需要本轮 `gf_doctor` 的 `modelsim.gates.uvm=true`。

| 文件 | 内容 | 编译顺序 |
|---|---|---|
| `%UVM_HOME%\src\uvm_pkg.sv` | UVM 1.2 | 1，可用宿主已映射库 |
| `rtl\dut_example.v` | DUT | 2 |
| `tb\data_if.sv` | interface | 3 |
| `tb\env_pkg.sv` | transaction、sequence、driver、monitor、agent、scoreboard、env、test | 4 |
| `tb\tb_top.sv` | DUT、VIF、时钟、watchdog、`run_test()` | 5 |

## data_if.sv

```systemverilog
interface data_if(input logic clk);
    logic rst_n;
    logic data_en;
    logic [7:0] data_in;
    wire  [7:0] data_out;
endinterface
```

## env_pkg.sv

```systemverilog
`timescale 1ns/1ps
package env_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    class data_item extends uvm_sequence_item;
        logic rst_n, en;
        logic [7:0] value, observed;
        `uvm_object_utils(data_item)
        function new(string name = "data_item");
            super.new(name);
        endfunction
    endclass

    class data_seq extends uvm_sequence #(data_item);
        `uvm_object_utils(data_seq)
        function new(string name = "data_seq");
            super.new(name);
        endfunction
        task body();
            data_item item;
            for (int i = 0; i < 2; i++) begin
                item = data_item::type_id::create("item");
                start_item(item);
                item.value = i == 0 ? 8'h35 : 8'h80;
                finish_item(item);
            end
        endtask
    endclass

    class data_driver extends uvm_driver #(data_item);
        virtual data_if vif;
        `uvm_component_utils(data_driver)
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            if (!uvm_config_db#(virtual data_if)::get(this, "", "vif", vif) || vif == null)
                `uvm_fatal("VIF", "Driver virtual interface missing")
        endfunction
        task run_phase(uvm_phase phase);
            data_item item;
            vif.data_en = 1'b0;
            vif.data_in = 8'h00;
            forever begin
                seq_item_port.get_next_item(item);
                @(negedge vif.clk);
                vif.data_in = item.value;
                vif.data_en = 1'b1;
                @(negedge vif.clk);
                vif.data_en = 1'b0;
                seq_item_port.item_done();
            end
        endtask
    endclass

    class data_monitor extends uvm_monitor;
        virtual data_if vif;
        uvm_analysis_port #(data_item) ap;
        `uvm_component_utils(data_monitor)
        function new(string name, uvm_component parent);
            super.new(name, parent);
            ap = new("ap", this);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            if (!uvm_config_db#(virtual data_if)::get(this, "", "vif", vif) || vif == null)
                `uvm_fatal("VIF", "Monitor virtual interface missing")
        endfunction
        task run_phase(uvm_phase phase);
            data_item item;
            forever begin
                @(posedge vif.clk);
                item = data_item::type_id::create("observed");
                item.rst_n = vif.rst_n;
                item.en = vif.data_en;
                item.value = vif.data_in;
                #1;
                item.observed = vif.data_out;
                ap.write(item);
            end
        endtask
    endclass

    class data_agent extends uvm_agent;
        uvm_sequencer #(data_item) seqr;
        data_driver drv;
        data_monitor mon;
        `uvm_component_utils(data_agent)
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            seqr = new("seqr", this);
            drv = data_driver::type_id::create("drv", this);
            mon = data_monitor::type_id::create("mon", this);
        endfunction
        function void connect_phase(uvm_phase phase);
            drv.seq_item_port.connect(seqr.seq_item_export);
        endfunction
    endclass

    class data_scoreboard extends uvm_scoreboard;
        uvm_analysis_imp #(data_item, data_scoreboard) input_ap;
        logic [7:0] expected;
        int seen, errors;
        `uvm_component_utils(data_scoreboard)
        function new(string name, uvm_component parent);
            super.new(name, parent);
            input_ap = new("input_ap", this);
            expected = 8'h00;
            seen = 0;
            errors = 0;
        endfunction
        function void write(data_item item);
            if (item.rst_n === 1'b0)
                expected = 8'h00;
            else if (item.rst_n === 1'b1 && item.en === 1'b1) begin
                expected = item.value;
                seen++;
            end
            if ((item.rst_n !== 1'b0 && item.rst_n !== 1'b1) ||
                (item.rst_n === 1'b1 && item.en !== 1'b0 && item.en !== 1'b1) ||
                (^expected === 1'bx) || item.observed !== expected) begin
                errors++;
                `uvm_error("CHECK", $sformatf("expected=%h actual=%h", expected, item.observed))
            end
        endfunction
    endclass

    class data_env extends uvm_env;
        data_agent agent;
        data_scoreboard sb;
        `uvm_component_utils(data_env)
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            agent = data_agent::type_id::create("agent", this);
            sb = data_scoreboard::type_id::create("sb", this);
        endfunction
        function void connect_phase(uvm_phase phase);
            agent.mon.ap.connect(sb.input_ap);
        endfunction
    endclass

    class base_test extends uvm_test;
        virtual data_if vif;
        data_env env;
        `uvm_component_utils(base_test)
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            env = data_env::type_id::create("env", this);
            if (!uvm_config_db#(virtual data_if)::get(this, "", "vif", vif) || vif == null)
                `uvm_fatal("VIF", "Test virtual interface missing")
        endfunction
        task run_phase(uvm_phase phase);
            data_seq seq;
            phase.raise_objection(this);
            repeat (3) @(posedge vif.clk);
            @(negedge vif.clk);
            vif.rst_n = 1'b1;
            seq = data_seq::type_id::create("seq");
            seq.start(env.agent.seqr);
            repeat (2) @(negedge vif.clk);
            phase.drop_objection(this);
        endtask
        function void check_phase(uvm_phase phase);
            if (env.sb.seen != 2 || env.sb.errors != 0)
                `uvm_error("COUNT", $sformatf("writes=%0d errors=%0d", env.sb.seen, env.sb.errors))
        endfunction
        function void report_phase(uvm_phase phase);
            if (env.sb.seen == 2 && env.sb.errors == 0)
                `uvm_info("RESULT", "UVM_TEST_PASSED", UVM_LOW)
        endfunction
    endclass
endpackage
```

## tb_top.sv

```systemverilog
`timescale 1ns/1ps
module tb_top;
    import uvm_pkg::*;
    import env_pkg::*;
    logic clk = 1'b0;
    always #5 clk = ~clk;
    data_if bus(clk);
    dut_example dut (.clk(clk), .rst_n(bus.rst_n), .data_en(bus.data_en),
                     .data_in(bus.data_in), .data_out(bus.data_out));
    initial begin
        bus.rst_n = 1'b0;
        uvm_config_db#(virtual data_if)::set(null, "uvm_test_top*", "vif", bus);
        run_test();
    end
    initial begin
        #1000;
        $fatal(1, "UVM watchdog expired");
    end
endmodule
```

## ModelSim 2018

由宿主在独立 run 目录中执行。先创建 logs 目录并配置 `UVM_HOME` 指向已安装的 UVM 1.2 根目录。如果使用宿主预映射的 UVM 1.2 库，使用其库映射和头文件路径。

```bat
vlib work
vlog -sv +define+UVM_NO_DPI +incdir+"%UVM_HOME%\src" "%UVM_HOME%\src\uvm_pkg.sv"
vlog -sv +incdir+"%UVM_HOME%\src" rtl\dut_example.v tb\data_if.sv tb\env_pkg.sv tb\tb_top.sv
vsim -c -nodpiexports -onfinish stop -l logs\uvm.log work.tb_top +UVM_TESTNAME=base_test -do "run -all; quit -f"
```

本模板不使用 DPI。若扩展到 DPI 设计，应使用宿主的 DPI 配置。按 [gf-uvm](../skills/gf-uvm/SKILL.md) 检查真实自检、结束摘要和宿主结果。扩充 test 时相应更新 scoreboard 的预期事务数与 watchdog。
