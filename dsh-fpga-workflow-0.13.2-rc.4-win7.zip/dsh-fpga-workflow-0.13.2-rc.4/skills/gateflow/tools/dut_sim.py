"""Run an ordinary DUT testbench with Icarus Verilog or ModelSim/QuestaSim."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time

from rtl_lint import lint_sources, mask_non_code


DEFAULT_CONFIG = Path(__file__).resolve().parents[1] / "config" / "gf.example.json"
SIMULATORS = {
    "iverilog": ("iverilog", "vvp"),
    "modelsim": ("vlib", "vlog", "vsim"),
}
RESULT_MARKER = re.compile(r"(?m)^(?:#[ \t]*)?TEST (PASSED|FAILED)[ \t]*$")
SIM_ERROR = re.compile(
    r"(?im)^(?:#[ \t]*)?[ \t]*(?:\*\*[ \t]*(?:error|fatal)\b|\[FAIL\]|(?:error|fatal)[ \t]*:|timeout\b)"
)
MODULE_NAME = r"[A-Za-z_][A-Za-z0-9_$]*"
MODULE_DECLARATION = re.compile(
    r"\b(?:module|macromodule)\s+(?:(?:automatic|static)\s+)?(" + MODULE_NAME + r")(?![A-Za-z0-9_$])"
)


def read_json(path):
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def load_sources(run_dir, fileset, group):
    entries = fileset.get(group, []) if group == "headers" else fileset[group]
    if not isinstance(entries, list) or (not entries and group != "headers"):
        raise ValueError("FileSet.{} must be a non-empty list".format(group))
    files = []
    for entry in entries:
        relative = Path(entry["path"])
        source = (run_dir / relative).resolve(strict=True)
        if relative.anchor or run_dir not in source.parents or not source.is_file():
            raise ValueError("FileSet source outside run directory or not a file: {}".format(relative))
        if hashlib.sha256(source.read_bytes()).hexdigest() != entry["sha256"].lower():
            raise ValueError("FileSet SHA-256 mismatch: {}".format(relative))
        files.append(source)
    return files


def validate_top(fileset, field, sources):
    name = fileset[field]
    if not re.fullmatch(MODULE_NAME, name):
        raise ValueError("FileSet.{} must be a simple HDL module name".format(field))
    if not any(name in MODULE_DECLARATION.findall(mask_non_code(source.read_text(encoding="utf-8")))
               for source in sources):
        raise ValueError("FileSet.{} is not declared in its sources: {}".format(field, name))
    return name


def count_vcd_signals(wave):
    count = 0
    with wave.open(encoding="ascii", errors="replace") as stream:
        for line in stream:
            fields = line.lstrip().split(maxsplit=1)
            if fields and fields[0] == "$var":
                count += 1
            if fields and fields[0] == "$enddefinitions":
                return count
    return 0


def run_lint(config, run_dir, fileset, rtl, work, result):
    result["stage"] = "lint"
    rules = Path(config.get("lint", {}).get("rules", "rules/rules.json"))
    rules = (DEFAULT_CONFIG.parents[1] / rules).resolve()
    log = work / "lint.log"
    try:
        headers = load_sources(run_dir, fileset, "headers")
        lint = lint_sources(run_dir, rtl + headers, rules)
        expected = {
            (run_dir / entry["path"]).resolve().relative_to(run_dir).as_posix(): entry["sha256"].lower()
            for entry in fileset["rtl"] + fileset.get("headers", [])
        }
        if lint["source_sha256"] != expected:
            raise ValueError("RTL changed during lint")
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        lint = {"ok": None, "mode": "lightweight", "error": str(error)}
    lint["log"] = log.relative_to(run_dir).as_posix()
    log.write_text(json.dumps(lint, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result["lint"] = lint
    if lint["ok"] is None:
        result.update(status="NEEDS_HUMAN", reason=lint["error"])
    elif not lint["ok"]:
        result.update(status="FAIL", reason="mandatory RTL lint violation")
    return lint["ok"] is True


def build_commands(simulator, executables, language, tb_top, sources, run_dir):
    if simulator == "iverilog":
        compiler, runtime = executables
        standard = "-g2001" if language == "verilog" else "-g2012"
        return [
            [compiler, standard, "-Wall", "-I", str(run_dir), "-s", tb_top,
             "-o", "dut.vvp", *sources],
        ], [runtime, "dut.vvp"]

    vlib, vlog, vsim = executables
    sv_args = ["-sv"] if language == "systemverilog" else []
    return [
        [vlib, "work"],
        [vlog, *sv_args, "+incdir+" + str(run_dir), *sources],
    ], [
        vsim, "-c", "-onfinish", "stop", "-voptargs=+acc", "work." + tb_top,
        "-do", "run -all; quit -f",
    ]


def execute(command, directory, log, deadline):
    with log.open("a", encoding="utf-8") as output:
        output.write("$ " + subprocess.list2cmdline(command) + "\n")
        output.flush()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            output.write("TIMEOUT: simulation budget exhausted\n")
            return False, "TIMEOUT"
        try:
            result = subprocess.run(
                command, cwd=str(directory), stdin=subprocess.DEVNULL,
                stdout=output, stderr=subprocess.STDOUT, timeout=remaining,
            )
        except subprocess.TimeoutExpired:
            output.write("\nTIMEOUT: simulator command exceeded the remaining budget\n")
            return False, "TIMEOUT"
        output.write("\nexit_code={}\n".format(result.returncode))
        return result.returncode == 0, "exit_code={}".format(result.returncode)


def run(args, result):
    config = read_json(args.config.resolve())
    run_dir = args.run_dir.resolve(strict=True)
    if not run_dir.is_dir() or not str(run_dir).isascii():
        raise ValueError("run directory must be an existing ASCII path")
    fileset = read_json(run_dir / args.fileset)
    result["stage"] = "fileset"
    rtl = load_sources(run_dir, fileset, "rtl")
    validate_top(fileset, "top", rtl)

    if args.lint_only:
        work = Path(tempfile.mkdtemp(prefix="rtl_lint_", dir=str(run_dir)))
        if run_lint(config, run_dir, fileset, rtl, work, result):
            result["status"] = "PASS"
        return

    sim_config = config.get("sim", {})
    simulator = args.simulator or sim_config.get("default_simulator", "iverilog")
    if simulator not in SIMULATORS:
        raise ValueError("simulator must be iverilog or modelsim")
    result["simulator"] = simulator

    language = args.language or sim_config.get("default_language", "verilog")
    if language not in ("verilog", "systemverilog"):
        raise ValueError("language must be verilog or systemverilog")
    timeout = args.timeout_seconds
    if timeout is None:
        timeout = sim_config.get("timeout_seconds", 60)
    if type(timeout) is not int or timeout <= 0:
        raise ValueError("timeout_seconds must be a positive integer")

    work = Path(tempfile.mkdtemp(prefix="dut_" + simulator + "_", dir=str(run_dir)))
    if args.lint and not run_lint(config, run_dir, fileset, rtl, work, result):
        return

    result["stage"] = "fileset"
    tb = load_sources(run_dir, fileset, "tb")
    tb_top = validate_top(fileset, "tb_top", tb)
    sources = [str(source) for source in rtl + tb]

    result["stage"] = "compile"
    tool_config = sim_config if simulator == "iverilog" else config.get("modelsim", {})
    executables = []
    for name in SIMULATORS[simulator]:
        command = tool_config.get(name, name)
        binary = shutil.which(command)
        if binary is None:
            raise FileNotFoundError("Simulator executable unavailable: {}".format(command))
        executables.append(str(Path(binary).resolve()))

    compile_log = work / "compile.log"
    sim_log = work / "sim.log"
    result["compile"]["log"] = compile_log.relative_to(run_dir).as_posix()
    compile_commands, sim_command = build_commands(
        simulator, executables, language, tb_top, sources, run_dir,
    )
    deadline = time.monotonic() + timeout
    for command in compile_commands:
        ok, reason = execute(command, work, compile_log, deadline)
        if not ok:
            result.update(status="FAIL", stage="compile", reason=reason)
            return
    result["compile"]["ok"] = True

    result["sim"]["log"] = sim_log.relative_to(run_dir).as_posix()
    ok, reason = execute(sim_command, work, sim_log, deadline)
    transcript = sim_log.read_bytes().decode("utf-8", errors="replace").replace("\r\n", "\n")
    if ok and (RESULT_MARKER.findall(transcript) != ["PASSED"] or SIM_ERROR.search(transcript)):
        ok, reason = False, "testbench did not report one clean TEST PASSED"
    result["sim"]["pass"] = ok
    result.update(status="PASS" if ok else "FAIL", stage="sim")
    if not ok:
        result["reason"] = reason

    wave = work / "wave.vcd"
    if wave.is_file():
        result["sim"]["vcd"] = wave.relative_to(run_dir).as_posix()
        result["sim"]["vcd_signals"] = count_vcd_signals(wave)
        if ok and not result["sim"]["vcd_signals"]:
            result.update(status="FAIL", stage="waveform", reason="wave.vcd contains no signal definitions")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--fileset", type=Path, required=True, help="FileSet JSON, relative to run directory")
    parser.add_argument("--simulator", choices=SIMULATORS)
    parser.add_argument("--language", choices=("verilog", "systemverilog"))
    parser.add_argument("--timeout-seconds", type=int)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    lint = parser.add_mutually_exclusive_group()
    lint.add_argument("--lint", action="store_true", help="Require lightweight RTL lint before compilation")
    lint.add_argument("--lint-only", action="store_true", help="Check RTL without starting a simulator")
    args = parser.parse_args()
    result = {
        "status": "NEEDS_HUMAN",
        "compile": {"ok": False},
        "sim": {"pass": False},
    }
    try:
        run(args, result)
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        result.update(status="NEEDS_HUMAN", reason=str(error))
    print(json.dumps(result, ensure_ascii=True))
    return {"PASS": 0, "FAIL": 1, "NEEDS_HUMAN": 2}[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
