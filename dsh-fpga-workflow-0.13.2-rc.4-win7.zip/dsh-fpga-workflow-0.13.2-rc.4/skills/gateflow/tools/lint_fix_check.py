"""Check that one lightweight lint repair resolved only its assigned finding."""

import argparse
from collections import Counter
import json
from pathlib import Path


def key(finding):
    return finding["rule_id"], finding["path"], finding["evidence"].strip()


def check_repair(before, after, target_index):
    if before["ok"] is not False or type(after["ok"]) is not bool:
        raise ValueError("Expected a failing baseline and a completed candidate lint")
    for field in ("mode", "rules", "checked_rules"):
        if before[field] != after[field]:
            raise ValueError("Lint scope changed: {}".format(field))
    if before["mode"] != "lightweight":
        raise ValueError("Only lightweight lint logs are supported")

    if not 0 <= target_index < len(before["findings"]):
        raise ValueError("Target index is outside the baseline findings")
    finding = before["findings"][target_index]
    if finding["level"] != "mandatory":
        raise ValueError("Target must be a mandatory finding")
    target = key(finding)
    baseline_hashes, candidate_hashes = before["source_sha256"], after["source_sha256"]
    if baseline_hashes.keys() != candidate_hashes.keys():
        raise ValueError("Candidate added or removed RTL files")
    changed = [path for path in baseline_hashes if baseline_hashes[path] != candidate_hashes[path]]
    if changed != [finding["path"]]:
        raise ValueError("Changed RTL paths must contain only the target file")

    expected = Counter({(rule, path, evidence): count for rule, path, evidence, count in before["mandatory_counts"]})
    actual = Counter({(rule, path, evidence): count for rule, path, evidence, count in after["mandatory_counts"]})
    if not expected[target] or actual[target] != expected[target] - 1:
        raise ValueError("Candidate must remove one occurrence of the target finding")
    expected[target] -= 1
    if +expected != actual:
        raise ValueError("Candidate also changed an unassigned mandatory finding")
    return {"accepted": True, "target_index": target_index, "target": finding, "changed": changed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", type=Path, required=True, help="Original lint.log")
    parser.add_argument("--after", type=Path, required=True, help="Candidate lint.log")
    parser.add_argument("--target-index", type=int, required=True, help="Zero-based index in original findings")
    args = parser.parse_args()
    try:
        before = json.loads(args.before.read_text(encoding="utf-8"))
        after = json.loads(args.after.read_text(encoding="utf-8"))
        result = check_repair(before, after, args.target_index)
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        result = {"accepted": False, "reason": str(error)}
    print(json.dumps(result, ensure_ascii=True))
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
