"""Fast checks on synthesizable RTL. Severity and diagnostics come from rules.json."""

from collections import Counter
import hashlib
import json
import re


NON_CODE = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\[\s\S]|[^"\\])*"|\\\S+')
DIRECTIVE = re.compile(r"^(?://|/\*)\s*((?:synthesis|synopsys)\s+(?:full_case|parallel_case))\b", re.I)
SYSTEM_TASK = re.compile(r"\$(?:display|write|monitor|strobe|stop|finish|fatal|error|warning|info)\b")
TOKEN = re.compile(r"[A-Za-z_$][\w$]*|[^\s]")
CASE_WORDS = {"case", "casex", "casez"}
STRUCTURE_RULES = {
    "2.1.2": "使用显式位宽的 packed 声明，核对符号和取值范围",
    "2.1.27": "将仿真系统任务移至 Testbench",
    "2.6.2": "补齐 default 分支及默认行为",
    "2.6.5": "去掉综合指令并完整描述 case 分支",
    "2.7.6": "使用可综合的循环或时序逻辑",
}


def mask_non_code(text):
    return NON_CODE.sub(lambda match: re.sub(r"[^\n]", " ", match[0]), text)


def parameter_hashes(tokens):
    """Return hash positions for module parameters and parameterized instances."""
    values = [token[0] for token in tokens]
    close = {}
    parens = []
    for index, value in enumerate(values):
        if value == "(":
            parens.append(index)
        elif value == ")" and parens:
            close[parens.pop()] = index
    for opening, ending in close.items():
        if opening < 2 or values[opening - 1] != "#":
            continue
        preceding = values[opening - 2]
        if opening >= 3 and values[opening - 3] in {"module", "macromodule", "interface", "program"}:
            yield tokens[opening - 1].start()
        elif (re.fullmatch(r"[A-Za-z_$][\w$]*", preceding)
              and preceding not in {"begin", "end", "initial", "always", "else", "forever", "repeat"}
              and ending + 2 < len(values)
              and re.fullmatch(r"[A-Za-z_$][\w$]*", values[ending + 1])
              and values[ending + 2] in {"(", "["}):
            yield tokens[opening - 1].start()


def find_violations(text, rules, regex_rules):
    code = mask_non_code(text)
    tokens = list(TOKEN.finditer(code))
    parameters = set(parameter_hashes(tokens))
    for rule_id, pattern in regex_rules.items():
        for match in pattern.finditer(code):
            if match.start() not in parameters:
                yield rule_id, match.start()

    if "2.1.27" in rules:
        for match in SYSTEM_TASK.finditer(code):
            yield "2.1.27", match.start()
    if "2.6.5" in rules:
        for comment in NON_CODE.finditer(text):
            directive = DIRECTIVE.match(comment[0])
            if directive:
                yield "2.6.5", comment.start() + directive.start(1)

    cases = []
    in_function = False
    for token in tokens:
        word = token[0]
        if word == "function":
            in_function = True
        elif word == "endfunction":
            in_function = False
        elif word == "integer" and not in_function and "2.1.2" in rules:
            yield "2.1.2", token.start()
        elif word in CASE_WORDS:
            cases.append(token.start())
        elif word == "default" and cases:
            cases[-1] = None
        elif word == "endcase" and cases:
            start = cases.pop()
            if start is not None and "2.6.2" in rules:
                yield "2.6.2", start
        elif word in {"forever", "repeat"} and "2.7.6" in rules:
            yield "2.7.6", token.start()


def lint_sources(run_dir, sources, rules_path):
    with rules_path.open(encoding="utf-8") as stream:
        definitions = json.load(stream)["rules"]
    if not isinstance(definitions, list) or not definitions:
        raise ValueError("rules.json must contain a non-empty rules list")
    rules = {rule["id"]: rule for rule in definitions}
    if len(rules) != len(definitions):
        raise ValueError("rules.json contains duplicate rule IDs")
    if any(rule["level"] not in {"mandatory", "recommended"} for rule in definitions):
        raise ValueError("rules.json contains an invalid rule level")
    try:
        regex_rules = {
            rule["id"]: re.compile(rule["pattern"], re.MULTILINE)
            for rule in definitions if rule["kind"] == "regex"
        }
    except re.error as error:
        raise ValueError("Invalid lint rule pattern: {}".format(error)) from error
    checked = set(regex_rules) | (rules.keys() & STRUCTURE_RULES.keys())
    if not checked:
        raise ValueError("No supported lightweight lint rules")

    findings = {}
    paths = []
    source_hashes = {}
    for source in dict.fromkeys(sources):
        path = source.relative_to(run_dir).as_posix()
        paths.append(path)
        raw = source.read_bytes()
        source_hashes[path] = hashlib.sha256(raw).hexdigest()
        text = raw.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")
        lines = text.split("\n")
        for rule_id, offset in find_violations(text, rules, regex_rules):
            rule = rules[rule_id]
            line = text.count("\n", 0, offset) + 1
            findings[(rule_id, path, line)] = {
                "rule_id": rule_id, "level": rule["level"], "path": path, "line": line,
                "evidence": lines[line - 1], "message": rule["message"],
                "fix": rule.get("fix", STRUCTURE_RULES.get(rule_id, "")),
            }

    ordered = sorted(
        findings.values(), key=lambda item: (item["level"] != "mandatory", item["path"], item["line"], item["rule_id"]),
    )
    mandatory_counts = Counter(
        (item["rule_id"], item["path"], item["evidence"].strip())
        for item in ordered if item["level"] == "mandatory"
    )
    return {
        "ok": not mandatory_counts,
        "mode": "lightweight",
        "rules": str(rules_path),
        "checked_rules": sorted(checked),
        "partial_rules": sorted(checked & {"2.1.27", "2.6.5"}),
        "unscanned_rule_count": len(rules) - len(checked),
        "scanned_files": paths,
        "source_sha256": source_hashes,
        "findings": ordered[:50],
        "mandatory_counts": [
            [rule, path, evidence, count] for (rule, path, evidence), count in mandatory_counts.items()
        ],
        "truncated_findings": max(0, len(ordered) - 50),
    }
