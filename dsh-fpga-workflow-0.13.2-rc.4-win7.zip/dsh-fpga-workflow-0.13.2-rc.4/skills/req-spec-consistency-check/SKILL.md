---
name: req-spec-consistency-check
description: 检查FPGA需求规格说明自身的文文一致性，识别前后矛盾、口径不一和不合理条款。也支持对照FEIP任务书基线、补全工程模型、预检架构输入及正式交付。
---

# FPGA需求规格说明一致性检查

用户明确要求“需求规格说明文文一致性检查”“检查规格书自身前后矛盾”或同义任务时，只对指定规格说明执行[单文档检查流程](references/internal-consistency.md)。先结构化，再逐主题交叉核验并交付带证据的问题清单。此入口直接使用规格书，不依赖任务书、FEIP包或发布确认。要求对照任务书时走下文的基线流程。

本独立分支版本2.0.0支持同级 task-validation 的 feip.direct-consistency.v1 交接包：该包跳过任务书审查与闭环，prepare 自动采用诊断入口，马上建模最新规格 Word 并 compare，不要求先修订任务书。完整保留实际匹配、偏离、遗漏与源未知项。输出一致性报告及 draft ICD；任务书未审查不伪报为 PASS，不据此正式发布。具体见同级 task-validation/references/direct-consistency.md。旧的已闭环基线仍按下面流程使用。

先读[运行接口](references/runtime.md)、[建模约束](references/modeling.md)和[检查规则](references/consistency_rules.md)。目标Windows7 SP1、PowerShell2.0、Python3.8.10，标准库脚本配合Agent宿主运行。

## 输入与交付

必需：完整taskbook-reviewed FEIP包、用户最新完整DOCX或结构等价文本。续轮还需review_state.json；有新增用户决定需decisions.json。用户自写文档和writer生成后完善的文档一视同仁，必须重新提取最新实际内容。

每轮交付review_report.md、review_state.json、内部model.json及原文证据。闭环时先交付review_packet.md、candidate_payload.json和candidate_manifest.json等待用户确认；不提前创建正式reqspec.json。

每轮还交付`icd.json`与`engineering_preflight.json`。按[ICD导出约定](references/icd.md)从同一模型派生接口、管脚、协议、时钟复位与有效需求引用。未闭环为draft，闭环未确认是candidate，正式发布为released。

用户确认当前候选后才发布reqspec-reviewed包：reqspec.json、最终检查报告.md、源/候选/确认快照及Schema。架构/仿真/确认测试readiness与一致性PASS独立，合法豁免不能自动变ready。

正式包同时包含`icd.json`与`schemas/icd.schema.json`，同一次候选确认覆盖需求和ICD，无需新增一次ICD确认。缺口与readiness随文件输出；released不表示接口双方已完成技术协商或下游一定ready。

## 执行流程

1. doctor；`prepare --baseline <任务书包> --input <最新DOCX> --output <根目录> [--previous-state <状态>] [--decisions <决定>]`。上游非PASS拒绝正式交付；明确diagnostic可只作诊断。
2. 读取新archive及model.template。Agent识别当前文档的条目、实际编号、信号、时钟、TP、矩阵、★/K和全部工程描述，建立spec_items及analysis。源B0和历史constraint不改写。
3. 建立源原子→工程需求→文档item显式映射。ID仅候选，逐义务/条件/约束/异常/判据双向核对。合法编号用错内容、拆分/合并、部分落实和多候选都要处理。
4. Agent按规则产生问题、To do、证据与建议，并完成feip.assessments.v1中15条checker规则的逐项判断；对无来源新增、变更和删除登记待用户决定。用户已明确表态的直接转录，不重复询问；新增决定必须来自prepare绑定的decision输入。
5. 维护完整台账B0/Δ/B1、当前DOCX事实和多轮历史。续轮保留稳定issue UID/stable_key、逐条复查所有旧问题；内容变化使旧决定失效时重开，不能按问题序号错套决定。
6. 按[工程补全与架构预检](references/engineering-preflight.md)从当前规格、继承的原文及受控附件补全工程对象和引用。所有原文元素有inventory去向。为architecture/simulation/confirmation视图填写有效修订、约束/VO、readiness、缺口与例外。
7. `engineering-preflight --attempt <目录> --model <Agent模型> --output <新JSON>`。按字段和证据位置逐项补齐可补内容，修改Agent模型后复验，直至所有有依据的缺口闭环。遇到新的受控资料先用`prepare --attachments`冻结，再转录。仍无依据的字段保留未知和实际阻断原因。
8. `compare --attempt <目录> --model <Agent模型> --output <新轮次目录>`。候选生成前重新执行工程预检并绑定明细。分别报告一致性和架构就绪度。架构仍有缺口时，说明受影响的条款及继续补全所需的资料。
9. 闭环后展示当前review_packet、完整candidate_payload和icd.json，询问是否确认该版本并共同生成最终reqspec.json和icd.json；引用candidate UID、摘要和已知readiness限制。这个确认沿用现有流程。
10. 收到明确确认，按运行接口记录release_confirmation.json，调用`finalize --candidate <闭环轮次> --confirmation <确认文件> --output <新发布目录>`，再validate。输入/规则/候选变化须重新检查确认；完全相同内容写盘失败重试可复用授权。

## 必须守住的边界

不生成/修改正文，不批准或删除源任务书条款；批准Δ只形成伴随有效预期。用户批准修改却未改最新DOCX时仍待修改。豁免保留实际差异，不改B1、覆盖率或设计采用值；无法唯一确定设计采用值时架构blocked。

10/11/C/D不专项检查且不自动变工程义务，但原文归档不丢；发现疑似新增规范性要求要待分类。安全标记展示缺陷与安全属性变化分别判定，不能豁免展示后降低安全属性。

输入错误、引用/身份失效、抽取不完整、未知映射、冲突有效约束、伪造决定及Schema失败不可放行。脚本检查只证明结构与已实现不变量，不能代替Agent的语义判断或真实用户授权来源。
