# 内容级一致性检查规则

| 规则 | 必查内容 | 默认结论/处置 |
|---|---|---|
| INP-001 | 包版本/摘要/同源/引用/Schema | error blocking；修复输入，不可豁免 |
| INP-002 | 上游PASS | 非PASS仅diagnostic；不可最终发布 |
| EXT-001 | 编号/图/附件/修订与结构提取完整性 | 关键未读内容EXTRACTION_INCOMPLETE；不可猜填 |
| MAP-001 | 源原子到item的确定映射 | MAPPING_UNRESOLVED；人工确认具体映射再比内容 |
| REQ-001 | 全部源原子义务的落点、条件、约束、异常 | REQ_MISSING/REQ_PARTIAL；修改、批准删除或具体豁免 |
| REQ-002 | 双向语义/数值/单位/对象/工况/安全属性偏离 | DEVIATION；回退、批准modify或具体豁免 |
| REQ-003 | 新功能/接口/性能/器件型号补全/模板新增义务 | NEW_KEY；必须批准add或删除新增，不可笼统忽略 |
| SIG-001 | 总表=子表统一信号集、方向/位宽/管脚/电平/默认 | SIGNAL_MISSING/MISMATCH；不比较器件/IP/信号名异类集合 |
| TST-001 | 源TP的对象/需求/刺激/步骤/预期/判据双向落实 | TP_MISSING/TP_DEVIATION；不能凭ID引用算覆盖 |
| IDN-001 | normalized_id、display_id、唯一机器UID | 显示缺陷可具体豁免；机器唯一性/引用不可豁免 |
| SAF-001 | ★、原子K、正文声明、第8章、附录属性 | SAFETY_TAG_BROKEN；仅部分原子关键不传播K |
| CLK-001 | 外/内部域来源、频率、关系及交互 | 未知按影响生成gap；不因同频推同步 |
| CON-001 | 同工况有效约束冲突 | 修复或批准选择唯一版本，不能同时生效后放行 |
| CLR-001 | 需用户结论但不阻断设计的澄清 | warning NEEDS_CLARIFICATION，取得结论后闭环 |
| NTC-001 | 纯描述补充、无工程影响建议 | notices；可选To do required=false |

关键性先看是否改变既有基线/设计约束/安全/验收义务，再看字段类型。器件型号补全是关键，不因“原任务书没写”归入普通补充。引用版本和进度也不能无据改掉已固化事实；模板必填不构成新增义务授权。

每个问题给一个以上可核查依据；明确矛盾优先给来源A/B并说明同对象/工况。严重度error/warning/info与blocking、resolution_required独立。To do采用supplement/confirm/modify/confirm_waiver，必需项必须闭环，可选建议不得制造终态死循环。
