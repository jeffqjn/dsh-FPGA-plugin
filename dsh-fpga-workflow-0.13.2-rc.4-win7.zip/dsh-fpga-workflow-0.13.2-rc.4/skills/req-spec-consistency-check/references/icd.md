# ICD JSON导出约定（实现1.2.0）

`compare`和`finalize`自动输出`icd.json`，无需额外命令或参数。`validate --package <目录>`同时校验核心FEIP包和ICD；正式CLI仍只接受Python3.8.10，使用标准库，PowerShell入口保持2.0语法。

## 边界与权威来源

ICD是需求级接口基线，合同标识为`FEIP-ICD/1.0.0`；核心需求协议仍为FEIP/1.0.0。仅导出模型已有事实。方向以FPGA为参照；只包含原文明确的内部接口，不推测模块划分、内部总线、同步器级数或未知管脚。

`reqspec.json`仍是完整权威需求模型。ICD复制接口工程对象及需求追溯上下文；未内嵌的源原子、归档、功能等UID须到`binding.model_path`指定的源模型解析。`source_model_required=true`表示后续skill必须同时读取并核验该源模型，不能把ICD当作无依赖的全部工程规范。

ICD不可单独编辑后作为新事实。修改先进入需求/工程模型和相应变更流程，再重新compare并导出。脚本会重建ICD并逐项比较，单独改值后重算文件摘要也不能通过validate。

## 顶层内容

| 字段 | 含义 |
|---|---|
| `binding` | baseline_uid、run_uid、stage、candidate_uid、源模型路径及SHA-256、源profile |
| `scope` | 需求级、FPGA方向参照、只保留有来源的内部接口 |
| `project` | 项目元信息、器件/配置项等基本事实 |
| `analysis` | 边界实体、模式/场景/行为、接口/信号、协议/数据格式、数据对象、全部保留约束、时钟复位电源及防护 |
| `traceability.requirements` | 完整台账与修订；保留遗漏、删除、豁免和历史信息 |
| `traceability.effective_requirements` | 有效需求/修订/落实状态引用 |
| `traceability.effective_requirement_constraint_refs` | 当前有效需求修订使用的约束UID；历史约束不能仅按数组位置作为设计采用值 |
| `traceability.mappings` | 源原子到工程义务和实际文档项映射 |
| `review` | 主模型门禁、问题、决定、缺口，以及按ICD缺口保守限制的下游视图 |
| `evidence` | 来源证据；原文文件保留在同一FEIP包 |
| `diagnostics` | ICD基础完整性缺口，对象UID、字段路径、原因及受阻用途 |
| `engineering_sha256` | 工程投影指纹；最终发布前须与已确认候选相同 |

`analysis.signals[].pins[]`原样保留device_uid、pin、bank、bit_index、evidence_refs；保留方向、位宽、IO标准、有效极性、默认值及约束引用。空管脚保持空，不生成假定值。没有Bank或未指定总线位映射时保留原值，进一步物理可实现性由架构/详细设计检查。

## 发布及可用性

- 未闭环：`stage=draft`，绑定`model.json`，candidate_uid为null。
- 闭环待确认：`stage=candidate`，绑定`candidate_payload.json`；candidate_manifest逐字节绑定ICD和模型。
- 最终发布：`stage=released`，绑定同包`reqspec.json`及同一candidate_uid。确认后的发布元数据可以变化；工程投影不得变化。

正式包还保留`candidate_icd.json`：这是用户确认过的候选ICD原始字节，其摘要必须匹配candidate_manifest中的icd.json绑定，不能被正式ICD覆盖。validate同时校验该快照与候选模型、正式工程投影的一致性。

源模型SHA-256对应UTF-8、两空格缩进、尾随换行的实际文件字节；不能只比较文件名。`package.json`另绑定ICD与Schema文件摘要。新版本checker包缺少ICD时验证失败；旧1.1.0无ICD包仍可读取。

基础诊断覆盖：未建立接口模型、接口双方不全、缺信号/协议、未知方向/位宽、外部信号缺IO标准/管脚、未知时钟复位属性、未说明的时钟对关系。缺口会将ICD下游视图限制为blocked，不提升源模型readiness；不会为了导出ICD而篡改主模型审查结论。诊断不等于电气/协议完整性证明，也不能替代Agent检查、器件资料及接口双方技术确认。

1.3.0还检查正整数位宽、同器件同管脚重复分配、时钟对同步/派生与异步的相互矛盾声明、接口相关对象的推断/未确认/拒绝/未知状态。这些对象仍保留在导出中便于审阅，但不能维持ready。物理封装可用性、Bank电气合法性、范围式管脚表达式及有条件复用仍需进一步设计审查；不能把本诊断当作厂商约束工具。

后续架构、仿真、确认测试skill读取步骤：核验包及源模型摘要 → 检查stage与自身用途的readiness/diagnostics → 按有效需求修订选择采用值 → 用相同UID建立追溯。不要直接采用历史constraint或被豁免的实际文档偏差。
