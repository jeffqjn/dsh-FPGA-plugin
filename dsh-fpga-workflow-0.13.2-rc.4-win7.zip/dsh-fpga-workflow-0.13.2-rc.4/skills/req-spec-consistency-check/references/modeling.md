# FEIP 语义建模与审查约束

修订1.1.0：任务书交接计划必须完整安置每个有效原子义务；TP标complete须具有对象、目的、刺激、步骤、预期、判据及关联需求。writer冻结requirements、analysis、verification及已知基本事实，只调整文档组织与有来源的元信息。

checker会对Agent提供的显式映射再次比较条件、输入输出、处理规则、异常、安全属性、约束运算符、数值/区间/容差，并支持s/ms/us/ns、Hz/kHz/MHz、byte/KiB/bit的同维度等价换算。结构差异产生REQ-STRUCTURED问题，不接受单独修改complete标签。此机制不理解任意自然语言，也不代替原文抽取与语义审查。已有partial/deviated结论不会仅因结构子集相同而提升为complete。

豁免须绑定当前issue指纹、对象与字段范围；旧resolved问题不能遮住当前仍存在的结构差异。每轮必须复查旧问题，明确关闭已修复的问题和关联To do，保留历史。结构问题重新出现时重开。发布目录不得位于输入快照内部。

先读随包[协议字段覆盖清单](protocol/字段与覆盖清单.md)；需要完整阶段规则时读[协议设计](protocol/协议设计.md)。Schema在protocol/schemas；不依赖工作区原协议目录。

## 不可交换的三类数据

1. source_baseline：源B0不可变，源父ID/原子ID分别存储，原文和全部约束保留。
2. requirements：工程台账，至少每个源原子义务有记录；已删除/被豁免/文档遗漏都不能删账。修订引用独立constraint UID。
3. spec_items：当前用户文档实际存在的义务，不把源条款复制成文档已落实。display_id允许缺失或错误，机器item UID仍必须唯一。

批准增改删作为独立Decision。修改建立新修订，不改B0/历史constraint。删除将effective_revision_uid置null并保留源修订；豁免不改变B1，不算覆盖。用户批准值必须核验已落实在当前文档，否则仍保留待修改。NEW_KEY必须批准新增或从文档删除，不能靠笼统忽略进入下游。

## 逐元素覆盖

prepare生成archive和pending inventory。对每个段落、表格、图/附件判断：modeled、descriptive_only、historical、out_of_scope或pending；规范性义务必须有工程引用。10/11/C/D原文不删除，不专项分析；出现疑似新增工程义务应pending分类并显式gap。

把主体/动作/对象、条件/工况、输入/处理/输出、所有量值和运算符、区间端点/开闭、容差、异常/恢复、验证方法分别保存。技术值用十进制字符串带单位，归一化仅在可靠等价时填写。未说明是unknown/null，不得默认false/0、接口方向、数量、安全属性或频率。

工程含义按analysis的context_entities、modes/scenarios、functions、behaviors、interfaces/signals/protocols/formats、data_objects、constraints、clocks/resets/power、platform_resources、dependability、assumptions保存。非标准标题下的状态机、复位、数据、异常行为也须建模；不能只保存章节摘要。

非规范性分析/建议标inference/unconfirmed，不进入有效需求。不替用户选择模块、FIFO深度、同步器或算法。已有实现限制忠实转录，设计选择交给下游架构skill登记。

## 证据及身份

所有规范性义务有evidence_refs；关键字段的混合来源用provenance精确到目标UID和字段路径。证据指向prepare冻结文件的artifact，不接受Agent填写的失效绝对路径。原archive对象不可改写，解释写在provenance/inventory。

prepare会创建`feip.assessments.v1`扩展：taskbook逐项覆盖30条STR/REQ/CON/TST规则，checker覆盖15条检查规则。Agent为每条填写pass/fail/not_applicable/unknown、具体判断依据、evidence_refs、issue_refs。pass/不适用必须有证据，fail/unknown必须有关联问题，不能只把总gate改成PASS。此扩展是阶段审查记录，核心协议消费者可以忽略；本阶段脚本会强制校验其完整性和引用。

工程req UID、revision UID、源atom UID、文档item UID不同；首次分配后持久化。章节移动、换行和显示编号变化不重新分配工程身份。normalized_id由源首次排序生成、后续只增不重排：实际配置项前缀-FREQ/IREQ/PREQ/SREQ/RREQ/OREQ-序号[-KNMR]。安全属性以原子修订为权威，不向同组非安全项传播K。

## 一致性比对

编号对齐只是候选。逐义务核对条件、约束、异常、输入输出和判据；一个父项多个原子义务必须逐项核验。一对多/多对一可以有多个spec_item_refs，但不能合并丢工程身份。编号合法却用错内容、多个候选、未知映射均需问题，不算complete。

同对象/工况下允许区间不交才是CONTRADICTION；可以同时满足但阈值不同是CONSTRAINT_MISMATCH。10ms和0.01s可靠等价不报错；≤和<、限定工况丢失必须报偏离。源TP保留ID但丢刺激/预期/判据仍未落实。

器件、IP、信号是不同对象：检查真实引用与信号总表/子表一致，不比较异类名称集合。时钟外/内部来源分开，有证据才填写频率/同步关系，同频不证明同步。

## 多轮问题与门禁

stable_key由规则、工程/文档UID、义务/字段构成，不含段落位置、问题排序或全文数值。保留旧issue UID/display_id、完整history；重开回open。每个旧问题都显式复查，不从“本轮未出现”推导resolved。

open error/blocking→FAIL；仅需澄清的open warning→NEEDS_CLARIFICATION；所有需闭环问题关闭→PASS。建议进入notices，避免永远open。ignored必须有有效具体豁免；confirmed必须有批准变更/映射且最新内容已核验。

输入损坏、混批次、机器引用失效、关键抽取不完整、未知映射、统计/Schema错误不能豁免。upstream非PASS的checker只可diagnostic。每轮原始B0和有效B1覆盖分别重算；零分母rate=null，豁免不计complete。

## 下游友好

architecture/simulation/confirmation三个view分别给readiness、理由、引用、缺口、允许/排除范围。PASS含豁免仍可能blocked；只有获允许的明确子集可以conditional，不能笼统放行。

验证方法与场景类型分开；源TP、VO、TC、RUN及执行证据分开。不可测试项必须有限制原因、版本和替代验证；测试点缺判据不是不可测试依据。需求阶段只记录有依据的义务，不能伪造仿真/板测结果。
