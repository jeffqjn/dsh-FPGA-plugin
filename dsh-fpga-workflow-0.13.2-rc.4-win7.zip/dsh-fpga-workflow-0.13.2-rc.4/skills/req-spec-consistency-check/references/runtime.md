# 离线运行接口

实现版本1.3.0；统一交换协议保持FEIP/1.0.0。正式CLI仍只接受Python 3.8.10。unknown封面元信息或自动章节缺项会生成DRAFT；全部必需信息明确后才可READY_FOR_REVIEW。输出目录必须为输入快照之外的新目录。task-validation的review自动输出需求清单.md，validate校验同版一致性；checker的compare/finalize自动导出icd.json，validate同时核验其源模型绑定与工程内容。

三个 skill 的脚本均为同版本独立副本；只需复制所需 skill 文件夹，无需其余两个 skill，也无需相邻共享库。FEIP 核心 Schema 随每包提供。运行脚本只用 Python 标准库。

## 环境

- Windows7 SP1；PowerShell2.0；Python **3.8.10**，补丁版本也必须相同。CLI 对其他版本直接报 PYTHON_RUNTIME_MISMATCH，无生产绕过开关。
- 用户安装的解释器默认 `C:\Python38\python.exe`；其他位置设置进程环境变量 `FPGA_PYTHON38`，值必须是 python.exe 完整路径。无需 py launcher、pip、python-docx、jsonschema 或 Node 全局命令。
- PowerShell入口只使用2.0语法，不依赖 PSScriptRoot、ConvertFrom-Json、Get-FileHash、Expand-Archive、Get-ChildItem -File/-Recurse 的新参数、`::new`、管道并行或新运算符。JSON解析、摘要和归档由Python完成。
- JSON/MD UTF-8无BOM；PS1纯ASCII，避免PS2读取UTF-8中文脚本的编码问题。环境变量仅影响当前进程及其子进程。

宿主现在支持execute command（或execute_command），优先直接执行Python CLI，无需Node.js包装器：

```powershell
& 'C:\Python38\python.exe' 'D:\skills\req-spec-consistency-check\scripts\cli.py' doctor
& 'C:\Python38\python.exe' 'D:\skills\req-spec-consistency-check\scripts\cli.py' self-test
```

以上是PowerShell2.0命令文本示例，由宿主的execute command工具执行；使用实际安装路径，不虚构宿主工具名或参数。若宿主支持可执行文件/参数数组，应分别传入python.exe和脚本参数。其他动作直接在cli.py后追加动作及参数即可。

也可继续使用PowerShell2.0便捷入口：

```powershell
$env:FPGA_PYTHON38 = 'C:\Python38\python.exe'
& 'D:\skills\req-spec-consistency-check\scripts\run.ps1' doctor
```


如需兼容旧JS宿主，可选调用本包scripts/run_python.js；它不是当前execute command宿主的必经入口。

```javascript
var runner = require("D:/skills/req-spec-consistency-check/scripts/run_python.js");
runner.run("doctor", []);
```


任何执行入口均须核对退出码0和本动作`FEIP_SKILL_OK:<action>`，并检查返回路径的本次产物。门禁FAIL不代表脚本执行失败，检查结果在报告及JSON中。

## 动作

| 动作 | 参数 | 说明 |
|---|---|---|
| doctor | 无 | 精确Python版本检查；记录当前OS，不声称在Win7验收过 |
| self-test | 无 | 临时目录运行结构/事务/拒绝用例，结束清理 |
| extract | --input 文件 --output JSON | 提取DOCX/TXT/MD；输出archive结构，不自动理解规范性语义 |
| internal-prepare | --input 规格文件 --output 新目录 | 单独提取当前规格书形成 structure.json，供文文一致性检查 |
| internal-report | --structure structure.json --findings 审查记录JSON --output 新Markdown路径 | 验证文内证据指向，生成单文档问题报告 |
| prepare | --input 文件 --output 根目录 [--baseline 包目录] [--previous-state 状态JSON] [--decisions 决定JSON] [--attachments 附件清单JSON] [--diagnostic] | 冻结输入并生成model.template.json，返回本次attempt目录 |
| review | --attempt 目录 --model Agent模型JSON --output 新目录 | 仅task-validation；输出taskbook-reviewed FEIP包及中文报告 |
| generate | 同上 | 仅writer；从冻结writer_plan装配完整MD及FEIP草稿包 |
| engineering-preflight | `--attempt` 目录 `--model` Agent模型JSON，或 `--package` 已有checker包；两种模式均用 `--output` 指定新的JSON路径 | 不消费attempt。已有包模式先验证原包，在内存试算类型修复和输入缺口。报告路径放在输入目录之外 |
| compare | --attempt 目录 --model Agent模型JSON --output 新目录 | 仅checker；核验基线和判断，生成候选前执行工程预检，输出并绑定`engineering_preflight.json` |
| finalize | --candidate 闭环轮次目录 --confirmation 确认JSON --output 新目录 | 仅checker；核验候选/规则/输入/授权后生成最终reqspec.json |
| validate | --package 包目录 | 校验随包文件、SHA256、Schema、引用及已实现业务不变量 |

taskbook prepare不传baseline；writer prepare不传input、必传baseline；checker二者均必传。正式checker要求上游PASS；非PASS只能显式diagnostic，不可finalize。各阶段output必须为新目录；不会覆盖用户文件。每个attempt只消费一次Agent模型；失败后重新prepare，不能覆盖旧round伪装成功。

`prepare`不是语义分析。Agent应另存model.template的编辑结果为新JSON，再调用相应动作。结构提取JSON不是有效需求台账，空模板不能审查成功。

附件清单为`[{"path":"D:/project/协议附件.docx","description":"外部协议定义"}]`。附件原字节一并冻结；DOCX/TXT/MD继续结构提取，图片/PDF等二进制标not_read并要求核实转录。附件不允许只保存外部路径后宣称已经读取。checker附件中的新增规范性义务仍按NEW_KEY/源遗漏处理，不擅自改B0。

## 决定与最后确认

本轮新增决定通过`prepare --decisions decisions.json`输入；文件为完整FEIP Decision对象数组，Agent从用户明确意见登记，不能自己发明意见。模型中的新增Decision必须逐字匹配该数组，证据关联该文件artifact。用户未表明理由/对象/目标值时保留待办，不登记生效批准。

compare闭环且准入通过时产生candidate_payload.json、review_packet.md、candidate_manifest.json，交付状态AWAITING_FINAL_CONFIRMATION；此时没有正式reqspec.json。Agent向用户展示当前审阅包及完整模型，再请求最终生成确认。

用户明确确认该版本后，记录如下文件；candidate的ID及摘要取compare返回结果，不猜填：

```json
{
  "kind": "approve_release",
  "candidate_uid": "candidate:从当前轮次读取",
  "candidate_manifest_sha256": "从当前轮次读取64位摘要",
  "actor": "当前用户（未提供姓名）",
  "confirmed_at": "带时区的实际确认时间",
  "user_quote": "用户对当前候选明确要求生成最终JSON的原话"
}
```

这是字段说明，不能把上面示例当成授权输入。程序只能核验记录与候选绑定，用户意见真实性由skill宿主保证。单项问题确认、沉默、超时、认可设计方案都不是approve_release。原文/模型/决定/规则/Schema变化须重新比较和确认。完全相同候选写入失败后的重试可以复用有效确认，无需重复询问。

失败发布目录带`.staging-.../FAILED.json`且package.status=staging；不能作为交接包。目录锁阻止同名并发发布；不自动清理别人的锁或失败资料。

## 抽取范围

支持正文段落、内容控件中的正文、表格、合并格、可恢复的十进制编号、标题样式、页眉页脚及脚注/尾注文本。原DOCX字节完整归档。

图片不做OCR；图中文字、修订未接受、嵌入对象、编号覆盖/自定义格式、域结果与文本框等标出partial。无法可靠阅读的关键内容必须阻断；提供可核查转录并保留原对象出处后重新prepare。不能把“XML可解析”当成全量工程内容已读取，也不能伪造页码。
