"""Recognize a source-retained, unreviewed comparison baseline."""
from pathlib import Path
from .base import digest, require


def verify_direct_baseline(model, directory, source):
    entries = [e for e in model["extensions"] if e["namespace"] == "feip.direct-consistency.v1"]
    if not entries:
        return False
    require(len(entries) == 1, "DIRECT_BASELINE_MARKER_INVALID")
    value = entries[0]["payload"]
    require(value.get("mode") == "direct_consistency" and value.get("taskbook_review") == "not_performed"
            and value.get("closure_required") is False and value.get("release_approved") is False,
            "DIRECT_BASELINE_MARKER_INVALID")
    require(model["source_baseline"]["status"] != "PASS", "DIRECT_BASELINE_CANNOT_CLAIM_QUALITY_PASS")
    require(value.get("specification_path") == "sources/comparison-specification.docx", "DIRECT_BASELINE_SPEC_PATH_INVALID")
    frozen = Path(directory) / value["specification_path"]
    require(frozen.is_file() and digest(frozen) == value.get("specification_sha256"), "DIRECT_BASELINE_SPEC_CHANGED")
    require(source is not None and Path(source).suffix.lower() == ".docx", "DIRECT_COMPARISON_REQUIRES_WORD_SPECIFICATION")
    # A later comparison may supply a revised specification. prepare freezes it
    # independently; the initial specification remains bound to the baseline.
    return True
