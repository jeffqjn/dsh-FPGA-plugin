"""Prepare engineering facts and report gaps before generating an ICD candidate."""
import re
from collections import Counter

from . import icd

CONSUMERS = ("architecture", "simulation", "confirmation")
ARCHITECTURE = ("architecture",)


def normalize_widths(model):
    changes = []
    for index, signal in enumerate(model["analysis"]["signals"]):
        width = signal["width"]
        value = width["value"]
        if (width["status"] == "present" and isinstance(value, str)
                and re.fullmatch(r"0*[1-9][0-9]*", value.strip())):
            width["value"] = int(value)
            changes.append({"object_uid": signal["header"]["uid"],
                            "field_path": "/analysis/signals/{}/width/value".format(index),
                            "before": value, "after": width["value"],
                            "evidence_refs": list(width["evidence_refs"])})
    return changes


def preflight(model, *, apply_gate=False):
    analysis = model["analysis"]
    project = model["meta"]["project_uid"]
    active = {r["uid"]: r for r in model["requirements"] if r["lifecycle"] == "active"}
    objects = {item.get("header", item)["uid"]: (category, index, item)
               for category, items in analysis.items() for index, item in enumerate(items)}
    evidence = {e["uid"]: e for e in model["consistency"]["evidence"]}
    findings = []

    def add(code, uid, path, action, refs=(), blocking=ARCHITECTURE, affected=()):
        locations = []
        for ref in dict.fromkeys(refs):
            if ref in evidence:
                source = evidence[ref]
                locations.append({key: source[key] for key in (
                    "uid", "artifact_uid", "element_uid", "section", "row", "column", "json_pointer")})
        item = objects[uid][2] if uid in objects else {}
        name = item.get("header", {}).get("name") or active.get(uid, {}).get("title")
        findings.append({"code": code, "object_uid": uid, "object_name": name, "field_path": path,
                         "action": action, "source_locations": locations, "affected_refs": list(affected),
                         "blocking_for": list(blocking)})

    original_icd_count = len(icd.diagnostics(model))
    changes = normalize_widths(model)
    diagnostics = icd.diagnostics(model)
    for diagnostic in diagnostics:
        uid = diagnostic["object_uid"]
        record = objects.get(uid)
        refs = record[2]["header"]["evidence_refs"] if record else []
        path = diagnostic["field_path"]
        action = diagnostic["reason"]
        if path.endswith("/direction"):
            action += "。原文明确为预留且不接出时，复核该管脚是否应归入接口的 unused_pin_policy"
        add("icd", uid, path, action, refs, diagnostic["blocking_for"])

    signals_by_interface = {}
    for signal in analysis["signals"]:
        signals_by_interface.setdefault(signal["interface_uid"], []).append(signal)
    interface_ids = {i["header"]["uid"] for i in analysis["interfaces"]}
    for index, interface in enumerate(analysis["interfaces"]):
        header = interface["header"]
        uid, refs = header["uid"], header["evidence_refs"]
        path = "/analysis/interfaces/{}".format(index)
        endpoints = {ref["uid"] for ref in interface["endpoint_refs"]}
        endpoint_categories = {"context_entities"} if interface["scope"] == "external" else {
            "context_entities", "functions", "behaviors"}
        if interface["scope"] == "unknown":
            add("interface_scope", uid, path + "/scope", "从系统边界确认接口是外部还是内部", refs)
        if len(interface["endpoint_refs"]) >= 2 and (len(endpoints) < 2 or any(
                objects.get(ref, (None,))[0] not in endpoint_categories for ref in endpoints)):
            add("endpoint_type", uid, path + "/endpoint_refs", "引用两个不同且属于系统边界或内部功能的实际端点", refs)
        members = signals_by_interface.get(uid, [])
        if set(interface["signal_refs"]) != {s["header"]["uid"] for s in members}:
            add("signal_membership", uid, path + "/signal_refs", "核对接口信号清单与信号所属接口，保持双向一致", refs)

    for index, signal in enumerate(analysis["signals"]):
        if signal["interface_uid"] not in interface_ids:
            header = signal["header"]
            add("signal_interface", header["uid"], "/analysis/signals/{}/interface_uid".format(index),
                "引用实际接口对象", header["evidence_refs"])

    effective_revisions = {r["uid"]: next(v for v in r["revisions"] if v["uid"] == r["effective_revision_uid"])
                           for r in active.values()}
    framing = [v["semantic"] for v in effective_revisions.values() if re.search(
        r"组帧|帧结构|帧字段|帧格式|数据格式|位序|字节序|frame format|bit order|byte order",
        v["semantic"]["statement"], re.IGNORECASE)]
    protocol_requirements = [r for r in active.values() if r["category"] == "protocol"]
    data_signals = [s for s in analysis["signals"] if s["role"] == "data"]
    required_objects = {
        "context_entities": (analysis["interfaces"], "从工作环境图、接口表录入双方及职责"),
        "clocks": ([s for s in analysis["signals"] if s["role"] == "clock"], "录入时钟、频率、源和时钟关系"),
        "resets": ([s for s in analysis["signals"] if s["role"] == "reset"], "录入复位极性、断言和释放条件"),
        "protocols": ([i for i in analysis["interfaces"] if i["timing_text"] or i["protocol_refs"]],
                      "依据协议和时序图录入握手、采样、触发和异常条件"),
        "formats": ([], "从组帧、编码或数据格式条款录入字段、位宽和位序"),
        "data_objects": (data_signals, "依据数据路径明确有效载荷、方向和生产消费对象"),
    }
    for category, (triggers, action) in required_objects.items():
        source_refs = [ref for item in triggers for ref in item["header"]["evidence_refs"]]
        if category == "protocols":
            applicable = bool(triggers or protocol_requirements)
            source_refs.extend(ref for r in protocol_requirements
                               for ref in effective_revisions[r["uid"]]["semantic"]["evidence_refs"])
        elif category == "formats":
            applicable = bool(framing)
            source_refs.extend(ref for semantic in framing for ref in semantic["evidence_refs"])
        else:
            applicable = bool(triggers)
        if applicable and not any(x["header"]["status"] == "present" for x in analysis[category]):
            add("analysis_missing", project, "/analysis/" + category, action, source_refs)

    for role, category in (("clock", "clocks"), ("reset", "resets")):
        definitions = [item for item in analysis[category] if item["header"]["status"] == "present"]
        if definitions:
            linked_signals = {ref for item in definitions for ref in item["signal_refs"]}
            for index, signal in enumerate(analysis["signals"]):
                header = signal["header"]
                if signal["role"] == role and header["status"] == "present" and header["uid"] not in linked_signals:
                    add("domain_signal", header["uid"], "/analysis/signals/{}".format(index),
                        "将信号关联到其时钟或复位对象，或依据原文重新分类", header["evidence_refs"])

    for index, requirement in enumerate(model["requirements"]):
        uid = requirement["uid"]
        if uid not in active:
            continue
        revision = effective_revisions[uid]
        path = "/requirements/{}/analysis_refs".format(index)
        refs = revision["semantic"]["evidence_refs"]
        linked = [objects[ref][2] for ref in requirement["analysis_refs"] if ref in objects]
        linked = [item for item in linked if item.get("header", {}).get("status", "present") == "present"]
        if not linked:
            add("requirement_trace", uid, path, "把有效条款关联到有证据的功能、接口、约束或平台对象", refs)
        for item in linked:
            if "header" in item and uid not in item["header"]["requirement_refs"]:
                add("trace_reverse", uid, path, "在对象 {} 补上有依据的反向需求引用".format(item["header"]["uid"]), refs)
    for uid, (category, index, item) in objects.items():
        header = item.get("header")
        if not header:
            continue
        path = "/analysis/{}/{}/header/requirement_refs".format(category, index)
        related = [ref for ref in header["requirement_refs"] if ref in active]
        if header["status"] == "present" and category in icd.ANALYSIS_KEYS and not any(
                ref in evidence and evidence[ref]["confirmation"] in ("evidenced", "user_confirmed")
                and evidence[ref]["origin_kind"] not in ("template", "inference") for ref in header["evidence_refs"]):
            add("object_evidence", uid, path.rsplit("/", 1)[0] + "/evidence_refs",
                "关联可回查的原文、受控附件或已记录的用户证据", header["evidence_refs"])
        if category in ("interfaces", "signals") and header["status"] == "present" and not related:
            add("object_trace", uid, path, "从实际条款建立接口或信号到有效需求的关联", header["evidence_refs"])
        for ref in related:
            if uid not in active[ref]["analysis_refs"]:
                add("trace_reverse", uid, path, "在需求 {} 补上有依据的正向工程引用".format(ref), header["evidence_refs"])

    for index, gap in enumerate(model["completeness"]["gaps"]):
        add("source_gap", gap["uid"], "/completeness/gaps/{}".format(index), gap["description"],
            gap["evidence_refs"], gap["blocking_for"], gap["affected_refs"])
    for index, point in enumerate(model["verification"]["source_test_points"]):
        if point["completeness"] in ("partial", "unknown"):
            add("test_point", point["uid"], "/verification/source_test_points/{}".format(index),
                "保留源TP状态，从受控规格补充验证义务和可执行判据。待核对字段 " + "、".join(point["missing_fields"]),
                point["evidence_refs"], ())
    for index, criterion in enumerate(model["verification"]["criteria"]):
        if not criterion["observable_refs"]:
            add("observable", criterion["uid"], "/verification/criteria/{}/observable_refs".format(index),
                "关联可观察信号、状态或可核验的分析和审查产物", criterion["evidence_refs"], ())

    consumer_status = {}
    for key in CONSUMERS:
        view = model["views"][key]
        blocking = sum(key in item["blocking_for"] for item in findings)
        readiness = "blocked" if blocking or model["consistency"]["gates"]["overall"] != "PASS" else view["readiness"]
        consumer_status[key] = {"readiness": readiness, "blocking_findings": blocking}
        if apply_gate and readiness != view["readiness"]:
            view.update(readiness=readiness, reason="工程输入预检存在阻断项或一致性门禁未通过，见 engineering_preflight.json。")
    return {"contract": "feip-engineering-preflight/1.0", "run_uid": model["protocol"]["run_uid"],
            "consistency_gate": model["consistency"]["gates"]["overall"], "consumers": consumer_status,
            "icd_diagnostics_before": original_icd_count, "icd_diagnostics_after": len(diagnostics),
            "normalizations": changes, "counts_by_code": dict(Counter(item["code"] for item in findings)),
            "findings": findings}


def summary(report):
    lines = ["\n## 工程输入预检\n",
             "位宽类型修复 {} 项，ICD 诊断从 {} 项降至 {} 项。".format(
                 len(report["normalizations"]), report["icd_diagnostics_before"], report["icd_diagnostics_after"])]
    for key, status in report["consumers"].items():
        lines.append("- `{}` 为 `{}`，预检阻断项 {}。".format(key, status["readiness"], status["blocking_findings"]))
    lines.append("\n[工程预检明细](engineering_preflight.json)记录对象、字段、来源定位和补全动作。\n")
    return "\n".join(lines)
