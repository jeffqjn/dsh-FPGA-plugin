"""Deterministic requirements-level interface export bound to its FEIP model."""
import copy
import hashlib
import json
from pathlib import Path

from . import contract
from .base import SCHEMAS, VERSION, digest, load, require

ANALYSIS_KEYS=("context_entities","modes","scenarios","behaviors","interfaces","signals","protocols","formats","data_objects","constraints","clocks","resets","power","dependability")

def model_digest(model):
    data=json.dumps(model,ensure_ascii=False,indent=2,allow_nan=False)+"\n"
    return hashlib.sha256(data.encode("utf-8")).hexdigest()

def required(model):
    # Old reviewed packages remain readable; new checker publications require ICD.
    return (model["protocol"]["producer"]=="req-spec-consistency-check" and
            tuple(int(p) for p in model["protocol"]["producer_version"].split('.')[:2]) >= (1,2))

def diagnostics(model):
    output=[]
    interfaces={i["header"]["uid"]:i for i in model["analysis"]["interfaces"]}
    def missing(uid,path,reason):
        output.append({"uid":"icd_gap:"+contract.fingerprint(uid+"|"+path)[:24],"object_uid":uid,"field_path":path,"reason":reason,"blocking_for":["architecture","simulation","confirmation"]})
    if not interfaces:
        missing(model["meta"]["project_uid"],"/analysis/interfaces","未建立接口模型；空列表不能证明接口已定义完整")
    for category in ("context_entities","interfaces","signals","protocols","formats","data_objects","clocks","resets","power"):
        for index,item in enumerate(model["analysis"][category]):
            header=item["header"]
            if header["status"] in ("missing","unknown") or header["confirmation"] in ("unconfirmed","rejected") or header["origin_kind"]=="inference":
                missing(header["uid"],"/analysis/"+category+"/"+str(index)+"/header","接口相关对象尚未形成有证据的明确事实；保留来源状态，不作为ready设计输入")
    occupied={}
    for index,interface in enumerate(model["analysis"]["interfaces"]):
        uid=interface["header"]["uid"];path="/analysis/interfaces/"+str(index)
        if len(interface["endpoint_refs"])<2:
            missing(uid,path+"/endpoint_refs","接口双方未完整定义；不得推测对端或职责")
        if not interface["signal_refs"] and not interface["protocol_refs"]:
            missing(uid,path,"接口缺少信号或协议定义")
    for index,signal in enumerate(model["analysis"]["signals"]):
        uid=signal["header"]["uid"];path="/analysis/signals/"+str(index)
        interface=interfaces.get(signal["interface_uid"])
        if signal["direction"]=="unknown":missing(uid,path+"/direction","信号方向未明确，方向以FPGA为参照")
        if signal["width"]["status"]!="present":missing(uid,path+"/width","信号位宽未明确")
        elif type(signal["width"]["value"]) is not int or signal["width"]["value"]<=0:
            missing(uid,path+"/width","信号位宽必须为正整数，present不能替代有效值检查")
        if interface and interface["scope"]=="external":
            if signal["io_standard"]["status"]!="present":missing(uid,path+"/io_standard","外部信号IO标准未明确")
            if not signal["pins"]:missing(uid,path+"/pins","外部信号未分配物理管脚")
        for pin_index,pin in enumerate(signal["pins"]):
            identity=(pin["device_uid"],pin["pin"].strip().casefold())
            if identity in occupied:
                missing(uid,path+"/pins/"+str(pin_index),"同一器件管脚重复分配："+pin["pin"]+"，先前占用"+occupied[identity]+"；不能在缺少明确复用约定时直接采用")
            else:occupied[identity]=uid
    for kind,field in (("clocks","frequency"),("resets","polarity"),("resets","assertion"),("resets","release")):
        for index,item in enumerate(model["analysis"][kind]):
            if item[field] is None or item[field]=="unknown":
                missing(item["header"]["uid"],"/analysis/"+kind+"/"+str(index)+"/"+field,"时钟或复位关键属性未明确")
    for index,clock in enumerate(model["analysis"]["clocks"]):
        for j,relation in enumerate(clock["relations"]):
            if relation["kind"]=="unknown":missing(clock["header"]["uid"],"/analysis/clocks/"+str(index)+"/relations/"+str(j),"时钟关系未知，不能根据频率比推定同步")
        for other in model["analysis"]["clocks"][index+1:]:
            one,two=clock["header"]["uid"],other["header"]["uid"]
            if not any(r["other_clock_uid"]==two for r in clock["relations"]) and not any(r["other_clock_uid"]==one for r in other["relations"]):
                missing(one,"/analysis/clocks/"+str(index)+"/relations/"+two,"时钟对未说明关系，不能从整数频率比推定同步")
            declared=[r["kind"] for r in clock["relations"] if r["other_clock_uid"]==two]+[r["kind"] for r in other["relations"] if r["other_clock_uid"]==one]
            families={"asynchronous" if kind=="asynchronous" else "synchronous" for kind in declared if kind!="unknown"}
            if len(families)>1:
                missing(one,"/analysis/clocks/"+str(index)+"/relations/"+two,"时钟对的关系声明矛盾：同步/派生与异步不能同时成立")
    return output

def engineering_fingerprint(document):
    review=copy.deepcopy(document["review"])
    review["gates"].pop("delivery_state",None)
    review["decisions"]=[d for d in review["decisions"] if d["kind"]!="approve_release"]
    return contract.fingerprint({"project":document["project"],"analysis":document["analysis"],"traceability":document["traceability"],"review":review,"diagnostics":document["diagnostics"]})

def build(model,stage,candidate_uid=None):
    require(stage in ("draft","candidate","released"),"ICD_STAGE_INVALID")
    require((candidate_uid is None)==(stage=="draft"),"ICD_CANDIDATE_BINDING_REQUIRED")
    model_path={"draft":"model.json","candidate":"candidate_payload.json","released":"reqspec.json"}[stage]
    document={"contract":"FEIP-ICD/1.0.0","producer_version":model["protocol"]["producer_version"],"synthetic":model["protocol"]["synthetic"],
        "binding":{"baseline_uid":model["protocol"]["baseline_uid"],"run_uid":model["protocol"]["run_uid"],"stage":stage,"candidate_uid":candidate_uid,"model_path":model_path,"model_sha256":model_digest(model),"model_profile":model["protocol"]["profile"],"source_model_required":True},
        "scope":{"level":"requirements","direction_perspective":"fpga","internal_interfaces":"only_if_explicit_in_source"},
        "project":{"meta":copy.deepcopy(model["meta"]),"basic_info":copy.deepcopy(model["basic_info"])},
        "analysis":{k:copy.deepcopy(model["analysis"][k]) for k in ANALYSIS_KEYS},
        "traceability":{k:copy.deepcopy(model[k] if k!="mappings" else model["traceability"][k]) for k in ("requirements","effective_requirements","mappings")},
        "review":{"gates":copy.deepcopy(model["consistency"]["gates"]),"issues":copy.deepcopy(model["consistency"]["issues"]),"decisions":copy.deepcopy(model["consistency"]["decisions"]),"gaps":copy.deepcopy(model["completeness"]["gaps"]),"consumer_views":copy.deepcopy(model["views"])},
        "evidence":copy.deepcopy(model["consistency"]["evidence"]),"diagnostics":diagnostics(model),"engineering_sha256":""}
    for key,view in document["review"]["consumer_views"].items():
        if any(key in gap["blocking_for"] for gap in document["diagnostics"]) or model["consistency"]["gates"]["overall"]!="PASS":
            view["readiness"]="blocked"
            view["reason"]="接口基础信息存在缺口或一致性门禁未通过；结合diagnostics与源模型gap审查适用范围"
    document["traceability"]["effective_requirement_constraint_refs"]=list(dict.fromkeys(c for r in model["requirements"] if r["lifecycle"]=="active" for v in r["revisions"] if v["uid"]==r["effective_revision_uid"] for c in v["semantic"]["constraint_refs"]))
    document["engineering_sha256"]=engineering_fingerprint(document)
    validate_shape(document)
    return document

def validate_shape(document):
    schema=load(SCHEMAS/"icd.schema.json")
    contract.audit_schema(schema)
    errors=contract.validate_schema(document,schema)
    require(not errors,"ICD_SCHEMA_INVALID:\n"+"\n".join(errors[:30]))

def verify(directory,model):
    directory=Path(directory)
    path=directory/"icd.json"
    require(path.is_file(),"ICD_MISSING: checker publication requires icd.json")
    actual=load(path);validate_shape(actual)
    stage="released" if model["protocol"]["profile"]=="reqspec-reviewed" else "candidate" if model["consistency"]["gates"]["delivery_state"]=="AWAITING_FINAL_CONFIRMATION" else "draft"
    candidate_uid=(model["consistency"]["release_binding"]["candidate_uid"] if stage=="released" else load(directory/"candidate_manifest.json")["candidate_uid"] if stage=="candidate" else None)
    expected=build(model,stage,candidate_uid)
    source=contract.safe_artifact(directory,actual["binding"]["model_path"])
    require(source.is_file() and digest(source)==actual["binding"]["model_sha256"],"ICD_SOURCE_DIGEST_MISMATCH")
    require(actual==expected,"ICD_MODEL_MISMATCH: regenerate ICD from the bound model; do not edit it independently")
    if stage=="released":
        snapshot=directory/"candidate_icd.json"
        require(snapshot.is_file(),"ICD_CANDIDATE_SNAPSHOT_MISSING")
        manifest=load(directory/"candidate_manifest.json")
        binding=next((p for p in manifest["bindings"] if p["path"]=="icd.json"),None)
        require(binding is not None and digest(snapshot)==binding["sha256"],"ICD_CANDIDATE_SNAPSHOT_CHANGED")
        approved=load(snapshot)
        approved_model=load(directory/"candidate_payload.json")
        require(approved==build(approved_model,"candidate",candidate_uid) and approved["engineering_sha256"]==actual["engineering_sha256"],"ICD_CONFIRMED_ENGINEERING_MISMATCH")
    return actual
