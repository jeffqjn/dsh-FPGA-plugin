"""Evidence binding and reporting for a single specification review."""
import re
from collections import Counter

from .base import digest, load, require, save
from .extract import extract

KINDS = {"conflict": "冲突", "self_conflict": "单处自相矛盾", "ambiguity": "歧义",
         "gap": "缺项", "reasonableness": "合理性"}
SEVERITIES = {"high": "高", "medium": "中", "low": "低"}


def inline_text(value):
    single_line = " ".join(value.splitlines())
    return re.sub(r"([\\`*_{}\[\]()<>!&#|~])", r"\\\1", single_line)


def prepare(source, output):
    source = source.resolve()
    require(source.is_file(), "SPECIFICATION_FILE_REQUIRED")
    require(source.suffix.lower() in (".docx", ".md", ".txt"), "UNSUPPORTED_SPECIFICATION_FORMAT")
    sha = digest(source)
    archive = extract(source, "specification", "artifact:internal-specification")
    require(digest(source) == sha, "SOURCE_CHANGED_DURING_EXTRACTION")
    output.mkdir(parents=True)
    path = output / "structure.json"
    save(path, {"source": {"name": source.name, "sha256": sha}, "archive": archive})
    return {"structure": str(path), "elements": len(archive["elements"]),
            "extraction_status": archive["extraction_status"]}


def report(structure, findings, output):
    spec, review = load(structure), load(findings)
    archive = spec["archive"]
    elements = {entry["uid"]: entry for entry in archive["elements"]}
    sections = {entry["uid"]: entry for entry in archive["sections"]}
    issues = review["findings"]
    scope = review["scope_note"].strip()
    require(scope and isinstance(issues, list), "INVALID_REVIEW_SCOPE_OR_FINDINGS")

    def locate(entry):
        element = elements.get(entry["element_uid"])
        require(element, "UNKNOWN_EVIDENCE_ELEMENT")
        row, column = entry.get("row"), entry.get("column")
        quote = entry["quote"].strip()
        require(quote, "EMPTY_EVIDENCE_QUOTE")
        cells = element["cells"]
        cell = None
        if row is not None or column is not None:
            require(type(row) is int and type(column) is int and row >= 0 and column >= 0, "INVALID_CELL_POSITION")
            matches = [c for c in cells if c["row"] <= row < c["row"] + c["row_span"]
                       and c["column"] <= column < c["column"] + c["column_span"]]
            require(len(matches) == 1, "UNKNOWN_OR_OVERLAPPING_EVIDENCE_CELL")
            cell = matches[0]
        elif element["kind"] == "table":
            matches = [c for c in cells if quote in c["text"]]
            require(len(matches) == 1, "TABLE_EVIDENCE_REQUIRES_CELL: " + entry["element_uid"])
            cell = matches[0]
        value = cell["text"] if cell else element["text"]
        require(quote in value, "EVIDENCE_QUOTE_NOT_IN_SOURCE: " + entry["element_uid"])
        detail = ""
        if cell is not None:
            row, column = cell["row"], cell["column"]
            detail = "，表格第{}行第{}列".format(row + 1, column + 1)
        section = sections.get(element["section_uid"], {})
        title = " ".join(filter(None, (section.get("number"), section.get("title", "").strip()))) or "未归入章节"
        location = "{}，{}，原文元素 {}{}".format(title, element["part"], element["order"], detail)
        return location, quote, (element["uid"], row, column)

    counts = Counter()
    blocks = []
    for index, item in enumerate(issues, 1):
        kind, severity = item["kind"], item["severity"]
        require(kind in KINDS and severity in SEVERITIES, "UNKNOWN_FINDING_CLASS")
        require(all(item[key].strip() for key in ("title", "impact", "recommendation")), "INCOMPLETE_FINDING")
        locations = [locate(entry) for entry in item["evidence"]]
        minimum = 2 if kind in ("conflict", "ambiguity") else 1
        require(len({identity for _, _, identity in locations}) >= minimum, "INSUFFICIENT_DISTINCT_EVIDENCE")
        counts[kind] += 1
        blocks.extend(["", "## {} {}".format(index, inline_text(item["title"])), "",
                       "{}等级，{}。{}".format(SEVERITIES[severity], KINDS[kind], inline_text(item["impact"])), ""])
        for location, quote, _ in locations:
            blocks.append("- {}。原文摘录「{}」".format(inline_text(location), inline_text(quote)))
        blocks.extend(["", "修改建议。{}".format(inline_text(item["recommendation"]))])
    limitations = Counter(limit for e in elements.values() for limit in e["limitations"])
    coverage = Counter(e["read_status"] for e in elements.values())
    lines = ["# 需求规格说明文文一致性检查报告", "", "审查文件为《{}》。".format(inline_text(spec["source"]["name"])),
             "", "源文件 SHA-256 为 `{}`。".format(spec["source"]["sha256"]), "", inline_text(scope), "",
             "抽取覆盖 {} 个章节标题和 {} 个原文元素，其中表格 {} 个。抽取状态为 `{}`。".format(
                 len(sections), len(elements), sum(e["kind"] == "table" for e in elements.values()),
                 archive["extraction_status"]), ""]
    lines.append("元素抽取状态为完整 {} 个、部分或未读 {} 个。".format(
        coverage["complete"], len(elements) - coverage["complete"]))
    lines.append("")
    lines.extend("- {}（{} 个元素）".format(key, count) for key, count in limitations.items())
    lines.extend("- " + limit for limit in archive["limitations"] if limit not in limitations)
    lines.append("")
    if issues:
        lines.append("记录 {} 项。{}".format(len(issues), "、".join(
            "{} {} 项".format(label, counts[kind]) for kind, label in KINDS.items() if counts[kind])))
    elif archive["extraction_status"] != "complete":
        lines.append("已审部分记录 0 项。抽取范围不完整，未覆盖内容无法判定。")
    else:
        lines.append("本轮审查范围内记录 0 项。")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(lines + blocks) + "\n")
    return {"report": str(output), "findings": len(issues), "counts": dict(counts),
            "extraction_status": archive["extraction_status"], "element_read_status": dict(coverage)}
