"""Conservative structured realization checks; no claim of arbitrary text NLP.

Agent mappings remain necessary. Once structure is supplied, changed predicates,
operators, quantity boundaries and safety attributes cannot be labelled complete.
"""
import re
from decimal import Decimal

from .base import now
from . import contract

SCALES = {"s": ("time", "1"), "ms": ("time", "0.001"), "us": ("time", "0.000001"), "ns": ("time", "0.000000001"),
          "Hz": ("frequency", "1"), "kHz": ("frequency", "1000"), "MHz": ("frequency", "1000000"),
          "byte": ("data_size", "1"), "KiB": ("data_size", "1024"), "bit": ("data_size", "0.125")}

def clean(value):
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items() if k not in ("evidence_refs", "raw_text", "normalization_basis", "confirmation")}
    if isinstance(value, list):
        return [clean(v) for v in value]
    if isinstance(value, str):
        return re.sub(r"\s+", "", value)
    return value

def quantity(value):
    unit, dimension = value["unit"], value["dimension"]
    if unit in SCALES and SCALES[unit][0] == dimension:
        return (dimension, Decimal(value["decimal"]) * Decimal(SCALES[unit][1]))
    return (dimension, unit, Decimal(value["decimal"]))

def numeric_value(value):
    if value is None:
        return None
    if value.get("kind") == "quantity":
        return quantity(value)
    if value.get("kind") == "interval":
        return ("interval", quantity(value["lower"]) if value["lower"] else None,
                quantity(value["upper"]) if value["upper"] else None, value["lower_inclusive"], value["upper_inclusive"])
    return clean(value)

def signature(constraint):
    return (constraint["parameter"], constraint["operator"], numeric_value(constraint["value"]),
            numeric_value(constraint["tolerance"]), clean(constraint["when"]))

def differences(expected, observed, constraints):
    if not observed:
        return ["document_items"]
    differences = []
    # One atomic source obligation can occupy multiple paragraphs. Quantity
    # obligations must be collectively retained; references alone prove nothing.
    actual_constraints = [constraints[c] for o in observed for c in o["constraint_refs"] if c in constraints]
    for c in expected["constraint_refs"]:
        if c not in constraints or not any(signature(constraints[c]) == signature(a) for a in actual_constraints):
            differences.append("constraint_refs/" + c)
    if len(observed) == 1:
        actual = observed[0]
        for field in ("condition", "input_refs", "output_refs", "processing_rules", "exceptions", "safety_critical", "attributes"):
            if clean(expected[field]) != clean(actual[field]):
                differences.append(field)
        # Additional constraints within a one-to-one atomic mapping also change
        # the obligation. For merged mappings the caller supplies only its subset.
        expected_signatures = [signature(constraints[c]) for c in expected["constraint_refs"] if c in constraints]
        if any(signature(a) not in expected_signatures for a in actual_constraints):
            differences.append("additional_constraints")
    else:
        for field in ("condition", "safety_critical"):
            if not any(clean(expected[field]) == clean(o[field]) for o in observed):
                differences.append(field)
    return sorted(set(differences))

def reconcile_realization(model):
    items = {i["uid"]: i for i in model["spec_items"]}
    constraints = {c["uid"]: c for c in model["analysis"]["constraints"]}
    issues = model["consistency"]["issues"]
    number = max([int(i["display_id"].split('-')[-1]) for i in issues if re.fullmatch(r"IS-\d+", i["display_id"])] or [0])
    for req in model["requirements"]:
        if req["lifecycle"] != "active":
            continue
        versions = {v["uid"]: v for v in req["revisions"]}
        expected = versions[req["effective_revision_uid"]]["semantic"]
        selected = [items[i] for i in req["spec_item_refs"] if i in items]
        observed = [i["semantic"] for i in selected]
        missing = differences(expected, observed, constraints)
        source = next((v["semantic"] for v in req["revisions"] if v["basis"] == "source"), None)
        source_diff = differences(source, observed, constraints) if source else []
        req["source_alignment"] = ("unmapped" if not selected else "deviated" if source_diff else
            req["source_alignment"] if req["source_alignment"] in ("partial", "deviated") else "complete")
        for mapping in model["traceability"]["mappings"]:
            if mapping["requirement_uid"] == req["uid"]:
                mapping["status"] = req["source_alignment"]
        if not missing:
            # Agent may have identified a semantic gap beyond deterministic fields.
            # Never promote its explicit partial/deviated finding to complete.
            continue
        req["effective_alignment"] = "unmapped" if not selected else "deviated"
        stable = "REQ-STRUCTURED|" + req["uid"]
        prior = next((i for i in issues if i["stable_key"] == stable), None)
        fingerprint = contract.fingerprint({"expected": clean(expected), "observed": clean(observed), "constraints": [clean(c) for c in constraints.values() if c["uid"] in {r for o in observed for r in o["constraint_refs"]}]})
        if prior is not None:
            if prior["evidence_fingerprint"] != fingerprint or prior["status"] == "resolved":
                if prior["status"] != "open":
                    prior["history"].append({"round": max(model["consistency"]["round"], 1), "at": now(), "from_status": prior["status"], "to_status": "open", "reason": "结构差异仍存在或证据指纹变化，重开旧处置", "decision_refs": []})
                prior["status"] = "open"
                for todo in model["consistency"]["todos"]:
                    if prior["uid"] in todo["issue_refs"]:
                        todo["status"] = "open"
            prior["evidence_fingerprint"] = fingerprint
            prior["last_seen_round"] = model["consistency"]["round"]
            prior["field_paths"] = ["/semantic/" + p for p in missing]
            prior["current_refs"] = list(dict.fromkeys(e for o in observed for e in o["evidence_refs"]))
            continue
        # Keep an existing, concrete Agent finding for this same obligation;
        # a valid scoped waiver remains a waiver and never changes alignment.
        if any(i["status"] != "resolved" and i["type"] in ("REQ_MISSING", "REQ_PARTIAL", "DEVIATION", "MAPPING_UNRESOLVED") and any(o["uid"] == req["uid"] for o in i["object_refs"]) for i in issues):
            continue
        number += 1
        issue_uid = "issue:" + contract.fingerprint(stable)[:24]
        issue_type = "REQ_MISSING" if not selected else "DEVIATION"
        issues.append({"uid": issue_uid, "display_id": "IS-{0:03d}".format(number), "stable_key": stable,
            "rule_id": "REQ-STRUCTURED", "type": issue_type, "severity": "error", "blocking": True, "resolution_required": True, "waivable": True,
            "object_refs": [{"kind": "requirement", "uid": req["uid"], "revision_uid": None}], "field_paths": ["/semantic/" + p for p in missing],
            "basis_refs": expected["evidence_refs"], "current_refs": list(dict.fromkeys(e for o in observed for e in o["evidence_refs"])),
            "summary": "结构化内容未落实：" + req["title"], "impact": "当前有效义务与文档实际条件、约束或落点不一致", "suggestion": "核对文档并修改，或登记精确批准差异/业务豁免；不得仅修改complete标签",
            "status": "open", "first_seen_round": model["consistency"]["round"], "last_seen_round": model["consistency"]["round"], "evidence_fingerprint": fingerprint,
            "history": [{"round": max(model["consistency"]["round"], 1), "at": now(), "from_status": None, "to_status": "open", "reason": "确定性字段比较发现差异", "decision_refs": []}], "decision_refs": []})
        req["issue_refs"].append(issue_uid)
        model["consistency"]["todos"].append({"uid": "todo:" + contract.fingerprint(stable)[:24], "kind": "modify", "description": "核对并落实" + req["title"],
            "issue_refs": [issue_uid], "notice_refs": [], "required": True, "status": "open", "decision_refs": [], "completion_evidence_refs": []})
