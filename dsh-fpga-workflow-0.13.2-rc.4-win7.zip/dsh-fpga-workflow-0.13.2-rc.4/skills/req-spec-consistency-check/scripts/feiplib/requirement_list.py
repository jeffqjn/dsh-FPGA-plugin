"""Designer-readable, lossless requirement catalogue derived from taskbook FEIP."""
from collections import Counter
from pathlib import Path

from .base import require
from .render import display, escape, flatten

FILENAME="需求清单.md"
CATEGORIES={"function":"功能要求","performance":"性能要求","reliability":"可靠性要求","safety":"安全要求","interface":"接口要求","protocol":"协议与数据格式要求","resource":"器件与资源要求","loading":"加载与配置要求","language":"语言要求","tool":"工具要求","ip":"IP要求","verification":"验证与验收要求","general":"通用与交付要求"}
LABELS={"header":"对象身份与状态","uid":"稳定UID","name":"名称","status":"状态","reason":"说明","requirement_refs":"关联需求","evidence_refs":"来源证据","origin_kind":"来源性质","confirmation":"确认状态","direction":"方向（以FPGA为参照）","width":"位宽","pins":"管脚映射","pin":"管脚号","bank":"Bank","bit_index":"总线位","device_uid":"所属器件","io_standard":"IO标准","active_level":"有效电平","default_value":"初始化值","frequency":"时钟频率","relations":"时钟关系","scope":"范围","source_ref":"来源对象","other_clock_uid":"对端时钟","kind":"类型","ratio":"频率比","phase":"相位","constraint_refs":"约束引用","interface_uid":"所属接口","endpoint_refs":"接口双方","signal_refs":"信号引用","protocol_refs":"协议引用","format_refs":"格式引用","parameters":"参数","timing_text":"时序要求","programming_rules":"编程规则","unused_pin_policy":"未用管脚策略","format":"交付格式","value":"取值","text":"原文说明","fields":"字段定义","offset_bits":"位偏移","width_bits":"字段位宽","byte_order":"字节序","signed":"是否有符号","encoding":"编码","allowed_values":"允许值","default":"默认值","access":"访问属性","entry":"进入条件","exit":"退出条件","polarity":"极性","assertion":"复位置位方式","release":"复位释放方式","minimum_pulse":"最小复位脉宽","initialization_rules":"初始化规则","recovery_rules":"恢复规则","voltage":"电压","rail_name":"电源名称","responsibilities":"职责","model":"型号","count":"数量","description":"说明","verification_methods":"验证方法","scenario_types":"场景类型"}

def caption(value):return str(value).replace("\r","").replace("\n"," ")

def render(model):
    registry=flatten(model)
    def named(uid):
        obj=registry.get(uid,{})
        return obj.get("normalized_id") or obj.get("header",{}).get("name") or obj.get("title") or obj.get("name") or uid
    def friendly(value):
        if isinstance(value,str) and value in registry:return named(value)+"（"+value+"）"
        if isinstance(value,dict) and set(value)=={"kind","uid","revision_uid"}:return named(value["uid"])+"（"+value["uid"]+("，修订"+value["revision_uid"] if value["revision_uid"] else "")+"）"
        return display(value)
    def nested(value,depth=0):
        pad="  "*depth
        if value is None:return [pad+"- 未单独给出；以原文及缺口记录为准。"]
        if isinstance(value,list):
            if not value:return [pad+"- 未单独结构化。"]
            return [line for v in value for line in nested(v,depth)]
        if isinstance(value,dict):
            if value.get("kind") in ("quantity","interval","bitvector","enumeration") or set(value)=={"kind","uid","revision_uid"}:
                return [pad+"- "+friendly(value)]
            output=[]
            for key,v in value.items():
                label=LABELS.get(key,key)
                if isinstance(v,(dict,list)):
                    output.append(pad+"- **"+label+"**：");output.extend(nested(v,depth+1))
                else:output.append(pad+"- "+label+"："+(friendly(v) if v is not None else "未单独给出"))
            return output
        return [pad+"- "+friendly(value).replace("\n","\n"+pad+"  ")]
    counts=Counter(r["category"] for r in model["requirements"])
    lines=["# "+caption(model["basic_info"]["product_name"]["value"] or model["meta"]["title"])+"：完整需求清单","",
        "本文件由任务书检查模型自动派生，供设计师逐项阅读；完整技术事实以同包model.json及冻结原文为依据。", "",
        "- 任务书审查状态：**"+model["source_baseline"]["status"]+"**", "- 基线：`"+model["protocol"]["baseline_uid"]+"`", "- 运行：`"+model["protocol"]["run_uid"]+"`",
        "- 数量：{0}个源父条款、{1}个源原子义务、{2}条工程台账。".format(len(model["source_baseline"]["parents"]),len(model["source_baseline"]["atomic_requirements"]),len(model["requirements"])),
        "- 使用边界：FAIL/NEEDS_CLARIFICATION表示仍有待解决项；PASS也不等于已完成架构设计、仿真或确认测试。", "",
        "## 需求分类总览","","| 类别 | 条数 |","|---|---:|"]
    for cat in list(CATEGORIES)+sorted(set(counts)-set(CATEGORIES)):
        lines.append("| "+escape(CATEGORIES.get(cat,cat))+" | "+str(counts[cat])+" |")
    parents={p["uid"]:p for p in model["source_baseline"]["parents"]}
    atoms={a["uid"]:a for a in model["source_baseline"]["atomic_requirements"]}
    constraints={c["uid"]:c for c in model["analysis"]["constraints"]}
    issues=model["consistency"]["issues"]
    for cat in list(CATEGORIES)+sorted(set(counts)-set(CATEGORIES)):
        selected=[r for r in model["requirements"] if r["category"]==cat]
        if not selected:continue
        lines += ["","## "+CATEGORIES.get(cat,cat),""]
        for req in selected:
            lines += ["### "+caption(req["normalized_id"] or req["uid"])+" "+caption(req["title"]),"", "- 台账UID：`"+req["uid"]+"`；生命周期："+req["lifecycle"],
                "- 源父条款："+'、'.join(parents[p]["source_id"] for p in req["source_parent_refs"]),"- 源原子："+'、'.join(atoms[a]["source_id"] for a in req["source_atomic_refs"])]
            for revision in req["revisions"]:
                sem=revision["semantic"]
                lines += ["", "#### "+("当前有效义务" if revision["uid"]==req["effective_revision_uid"] else "保留修订")+"（"+revision["uid"]+"）","", "- 修订依据："+revision["basis"],"- 安全关键："+("是" if sem["safety_critical"] is True else "否" if sem["safety_critical"] is False else "待明确")+"；属性："+''.join(sem["attributes"]),"", *["> "+s for s in sem["statement"].splitlines()], "",
                    "- 主体／动作／对象："+'／'.join(str(sem[k] or "未单列") for k in ("subject","action","object")), "- 适用条件："+(sem["condition"]["text"] if sem["condition"] else "未单列，见义务原文。")]
                for label,key in (("输入","input_refs"),("输出","output_refs"),("处理规则","processing_rules"),("异常与恢复","exceptions")):
                    lines += ["", "**"+label+"**："]+nested(sem[key])
                lines += ["", "**定量及逻辑约束**："]
                if not sem["constraint_refs"]:lines.append("未单列约束对象；技术值仍保留在义务原文中。")
                for uid in sem["constraint_refs"]:
                    c=constraints[uid]
                    lines += ["", "- "+c["parameter"]+"："+{"le":"≤","lt":"<","ge":"≥","gt":">","eq":"=","range":"区间","in":"属于集合"}.get(c["operator"],c["operator"])+" "+display(c["value"])+"；约束UID："+uid,
                        "  - 约束原文："+c["raw_text"],"  - 生效条件："+(c["when"]["text"] if c["when"] else "未另列，见原文")]
                    if c["tolerance"] is not None:lines.append("  - 容差："+display(c["tolerance"]))
                    if c["normalized"] is not None:lines += ["  - 归一化值："+display(c["normalized"]),"  - 换算依据："+str(c["normalization_basis"])]
                lines += ["", "- 验证方法："+'、'.join(sem["verification_methods"]), "- 证据："+'、'.join(sem["evidence_refs"])]
            tests=[t for t in model["verification"]["source_test_points"] if req["uid"] in t["requirement_refs"]]
            lines += ["", "**关联源测试要点**："]
            for tp in tests:
                lines += ["", "- "+tp["source_id"]+" "+tp["title"]+"；完整性："+tp["completeness"],"  - 前置："+'；'.join(tp["preconditions"]),"  - 刺激："+str(tp["stimulus"] or "待明确"),"  - 步骤："+str(tp["procedure"] or "待明确"),"  - 预期："+str(tp["expected_result"] or "待明确"),"  - 通过判据："+str(tp["pass_criteria"] or "待明确"),"  - 场景："+'、'.join(tp["scenario_types"])]
            if not tests:lines.append("未关联完整源测试要点；参见验证义务与问题记录，不默认为已覆盖。")
            related=[i for i in issues if any(o["uid"] in [req["uid"]]+req["source_atomic_refs"]+req["source_parent_refs"] for o in i["object_refs"])]
            lines += ["", "**问题与待解决项**："]
            lines += ["- "+i["display_id"]+"（"+i["status"]+"）："+i["summary"]+"；影响："+i["impact"]+"；建议："+i["suggestion"] for i in related] or ["未登记关联问题；不代表已完成后续验证。"]
    lines += ["", "## 工程定义与约束明细", "", "以下保留全部已建模工程定义；来源、确认状态和未知值随对象显示。推断或未确认内容不能自动作为已批准设计输入。"]
    for category,objects in model["analysis"].items():
        if objects:
            lines += ["", "### "+{"context_entities":"系统边界与外部实体","interfaces":"接口","signals":"信号与管脚","protocols":"协议","formats":"数据格式","constraints":"全部约束（含保留历史）","clocks":"时钟","resets":"复位","power":"电源","functions":"功能分析","modes":"模式","behaviors":"行为","data_objects":"数据对象","platform_resources":"平台与资源","dependability":"安全可靠性","assumptions":"假设","scenarios":"场景"}.get(category,category),""]+nested(objects)
    lines += ["", "## 验证、验收及交付资料",""]+nested({"verification":model["verification"],"acceptance":model["acceptance"]})
    lines += ["", "## 基本事实、完整性及下游可用性", ""]+nested({"basic_info":model["basic_info"],"system_overview":model["system_overview"],"gaps":model["completeness"]["gaps"],"views":model["views"],"todos":model["consistency"]["todos"]})
    lines += ["", "## 全部问题",""]+nested(issues)
    lines += ["", "## 源父条款原文保留", ""]
    for p in model["source_baseline"]["parents"]:lines += ["### "+caption(p["source_id"])+" "+caption(p["title"]),"", *["> "+s for s in p["raw_text"].splitlines()],""]
    return '\n'.join(lines)+'\n'

def required(model):
    return model["protocol"]["producer"]=="task-validation" and tuple(int(v) for v in model["protocol"]["producer_version"].split('.')[:2])>=(1,3)

def verify(directory,model):
    path=Path(directory)/FILENAME
    require(path.is_file(),"REQUIREMENT_LIST_MISSING")
    require(path.read_text(encoding="utf-8")==render(model),"REQUIREMENT_LIST_MODEL_MISMATCH: regenerate from the same taskbook model")
