"""Agent-assisted taskbook review, Markdown writing and reviewed release."""
import argparse
import json
import platform
import shutil
import sys
from pathlib import Path

from . import contract
from .base import SKILL, SCHEMAS, check_model, digest, effective, gate, known_artifacts, load, now, publish, require, save, text, uid, verify_inputs, verify_package
from .checks import checker_quality, ensure_frozen, merge_previous, report, revision_checks, source_quality, state
from .extract import extract
from .prepare import prepare
from .render import display, render
from . import engineering, icd

KINDS = {"task-validation": "taskbook", "req-spec-gen": "writer", "req-spec-consistency-check": "checker"}

def runtime_fingerprint():
    paths = [p for p in (SKILL / "scripts").rglob("*") if p.suffix in (".py", ".js", ".ps1")] + list(SCHEMAS.rglob("*.json")) + list((SKILL / "templates").glob("*.json")) + list((SKILL / "references").rglob("*.md")) + [SKILL / "SKILL.md"]
    return {p.relative_to(SKILL).as_posix(): digest(p) for p in paths if "__pycache__" not in p.parts}

def read_model(attempt, filename):
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    model = load(filename)
    # Shape first, so failed Agent output cannot crash a semantic check halfway.
    from .base import schema_model
    schema_model(model)
    ensure_frozen(model, attempt, info)
    revision_checks(model)
    return model, info

def bind_submission(attempt, filename, info):
    submitted = attempt / "inputs/agent_model.json"
    require(not submitted.exists(), "ATTEMPT_ALREADY_CONSUMED: prepare a fresh attempt")
    submitted.parent.mkdir(exist_ok=True)
    shutil.copyfile(str(filename), str(submitted))
    info["input_bindings"].append({"path": "inputs/agent_model.json", "sha256": digest(submitted)})
    info["original_inputs"].append({"path": str(Path(filename).resolve()), "sha256": digest(filename)})
    save(attempt / "attempt.json", info)

def accept_model(attempt, filename):
    attempt = Path(attempt)
    model, info = read_model(attempt, filename)
    bind_submission(attempt, filename, info)
    return model, info

def review(attempt, filename, output):
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "taskbook" and model["protocol"]["profile"] == "taskbook-reviewed", "REVIEW_PROFILE_INVALID")
    effective(model)
    source_quality(model)
    check_model(model, known_artifacts(attempt))
    from .requirement_list import FILENAME, render as render_requirement_list
    result = publish(output, model, attempt, known_artifacts(attempt), {"taskbook_review.md": report(model, "任务书完备性审查报告"), FILENAME: render_requirement_list(model)})
    result["requirement_list_path"] = str(Path(output) / FILENAME)
    return result

def generation_state(model):
    if model["consistency"]["gates"]["overall"] == "FAIL":
        return "BLOCKED"
    unknown = any(f["status"] in ("missing", "unknown") for f in model["basic_info"].values())
    unknown = unknown or any(isinstance(f, dict) and f.get("status") in ("missing", "unknown") for f in model["meta"].values())
    unknown = unknown or any(s["handling"] == "auto" and s["status"] in ("missing", "unknown") for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"])
    pending = bool(model["completeness"]["gaps"]) or any(i["status"] == "open" for i in model["consistency"]["issues"])
    return "DRAFT" if unknown or pending or model["source_baseline"]["status"] != "PASS" else "READY_FOR_REVIEW"

def generate(attempt, filename, output):
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "writer", "GENERATE_REQUIRES_WRITER_ATTEMPT")
    model["protocol"].update(profile="reqspec-draft", producer="req-spec-gen")
    effective(model)
    gate(model)
    # Upstream NEEDS_CLARIFICATION remains a draft, never promoted silently.
    model["consistency"]["gates"]["generation_state"] = generation_state(model)
    require(model["consistency"]["gates"]["generation_state"] != "BLOCKED", "GENERATION_BLOCKED: resolve blocking baseline/content issues")
    check_model(model, known_artifacts(attempt))
    markdown = render(model)
    result = publish(output, model, attempt, known_artifacts(attempt), {"需求规格说明.md": markdown, "生成检查报告.md": report(model, "需求规格说明生成检查")})
    result["generation_state"] = model["consistency"]["gates"]["generation_state"]
    return result

def checker_model(attempt, filename):
    model, info = read_model(attempt, filename)
    require(info["kind"] == "checker", "CHECKER_ATTEMPT_REQUIRED")
    model["protocol"].update(profile="reqspec-draft", producer="req-spec-consistency-check")
    merge_previous(model, attempt)
    effective(model)
    checker_quality(model)
    revision_checks(model)
    closed = model["consistency"]["gates"]["overall"] == "PASS" and model["source_baseline"]["status"] == "PASS" and not any(i["status"] == "open" for i in model["consistency"]["issues"]) and not any(t["required"] and t["status"] != "closed" for t in model["consistency"]["todos"])
    model["consistency"]["gates"]["delivery_state"] = "AWAITING_FINAL_CONFIRMATION" if closed else "REVIEWING"
    check_model(model, known_artifacts(attempt))
    return model, info, closed

def engineering_preflight(package, attempt, filename, output):
    require((package is not None and attempt is None and filename is None) or
            (package is None and attempt is not None and filename is not None),
            "PREFLIGHT_REQUIRES_PACKAGE_OR_ATTEMPT_AND_MODEL")
    if package is not None:
        model, _ = verify_package(package)
        require(model["protocol"]["producer"] == "req-spec-consistency-check", "CHECKER_PACKAGE_REQUIRED")
    else:
        model, _, _ = checker_model(attempt, filename)
    resolved = output.resolve()
    for source in (package, attempt, filename):
        if source is not None:
            source = source.resolve()
            require(resolved != source and source not in resolved.parents, "PREFLIGHT_OUTPUT_OVERLAPS_INPUT")
    result = engineering.preflight(model)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    return {"output": str(output), "consistency_gate": result["consistency_gate"], "consumers": result["consumers"],
            "icd_diagnostics_before": result["icd_diagnostics_before"], "icd_diagnostics_after": result["icd_diagnostics_after"],
            "counts_by_code": result["counts_by_code"]}

def compare(attempt, filename, output):
    attempt = Path(attempt)
    model, info, closed = checker_model(attempt, filename)
    preflight = engineering.preflight(model, apply_gate=True)
    check_model(model, known_artifacts(attempt))
    destination = Path(output).resolve()
    require(destination != attempt.resolve() and attempt.resolve() not in destination.parents, "OUTPUT_INSIDE_SOURCE")
    require(not destination.exists(), "OUTPUT_EXISTS: use a new output directory")
    bind_submission(attempt, filename, info)
    save(attempt / "engineering_preflight.json", preflight)
    engineering_summary = engineering.summary(preflight)
    save(attempt / "review_state.json", state(model))
    report_text = report(model, "需求规格说明一致性检查报告") + engineering_summary
    if info.get("direct_consistency"):
        active = [r for r in model["requirements"] if r["lifecycle"] == "active"]
        matched = sum(r["effective_alignment"] == "complete" for r in active)
        report_text = "# 双 Word 直接一致性审查\n\n任务书质量审查：未执行；不要求先修改或闭环任务书。本轮已经执行任务书原子义务与规格实际条目的匹配。上游质量门禁状态不等同于本轮匹配结果。\n\n有效需求：{0}；完整匹配：{1}；其余需检查：{2}。源未知、偏离和遗漏按下列证据报告，不模拟关闭。\n\n".format(len(active), matched, len(active)-matched) + report_text
    text(attempt / "review_report.md", report_text)
    if closed:
        candidate_uid = uid("candidate")
        save(attempt / "candidate_payload.json", model)
        save(attempt / "icd.json", icd.build(model, "candidate", candidate_uid))
        save(attempt / "runtime_fingerprint.json", runtime_fingerprint())
        packet = report(model, "最终生成确认审阅包") + engineering_summary + "\n候选ID：`" + candidate_uid + "`\n\n请审阅candidate_payload.json及icd.json中的完整台账、接口、管脚、缺口、例外和下游可用性，再明确确认是否发布该候选的reqspec.json与icd.json。两文件共享本次候选确认；单项问题确认不代替最终确认。\n"
        text(attempt / "review_packet.md", packet)
        bindings = [{"path": p.relative_to(attempt).as_posix(), "sha256": digest(p)} for p in sorted(attempt.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
        save(attempt / "candidate_manifest.json", {"contract": "feip-candidate/1.0", "candidate_uid": candidate_uid, "created_at": now(),
            "baseline_uid": model["protocol"]["baseline_uid"], "bindings": bindings})
    else:
        save(attempt / "icd.json", icd.build(model, "draft"))
    result = publish(output, model, attempt, known_artifacts(attempt))
    result["delivery_state"] = model["consistency"]["gates"]["delivery_state"]
    if info.get("direct_consistency"):
        all_matched = all(r["effective_alignment"] == "complete" for r in model["requirements"] if r["lifecycle"] == "active")
        result["comparison_status"] = "MATCHED" if all_matched and model["consistency"]["gates"]["local"] == "PASS" else "DIFFERENCES_FOUND" if any(i["status"] == "open" for i in model["consistency"]["issues"]) else "INCOMPLETE"
        result["taskbook_review"] = "not_performed"
    result["icd_path"] = str(Path(output) / "icd.json")
    result["engineering_preflight_path"] = str(Path(output) / "engineering_preflight.json")
    result["architecture_readiness"] = preflight["consumers"]["architecture"]["readiness"]
    if closed:
        result["candidate_manifest_sha256"] = digest(Path(output) / "candidate_manifest.json")
        result["candidate_uid"] = candidate_uid
    return result

def finalize(candidate, confirmation_file, output):
    candidate = Path(candidate)
    verify_package(candidate)
    verify_inputs(candidate)
    manifest = load(candidate / "candidate_manifest.json")
    for binding in manifest["bindings"]:
        path = contract.safe_artifact(candidate, binding["path"])
        require(path.is_file() and digest(path) == binding["sha256"], "CANDIDATE_CHANGED: " + binding["path"])
    require(runtime_fingerprint() == load(candidate / "runtime_fingerprint.json"), "RULES_OR_SCHEMA_CHANGED: recheck and request a new candidate confirmation")
    confirmation = load(confirmation_file)
    require(confirmation.get("kind") == "approve_release" and confirmation.get("candidate_uid") == manifest["candidate_uid"], "FINAL_CONFIRMATION_REQUIRED")
    require(confirmation.get("candidate_manifest_sha256") == digest(candidate / "candidate_manifest.json"), "CONFIRMATION_CANDIDATE_DIGEST_MISMATCH")
    require(all(isinstance(confirmation.get(k), str) and confirmation[k].strip() for k in ("actor", "confirmed_at", "user_quote")), "CONFIRMATION_INCOMPLETE")
    model = load(candidate / "candidate_payload.json")
    require(model["consistency"]["gates"]["delivery_state"] == "AWAITING_FINAL_CONFIRMATION", "CANDIDATE_NOT_CLOSED")
    checker_quality(model)
    require(model["consistency"]["gates"]["overall"] == "PASS" and not any(i["status"] == "open" for i in model["consistency"]["issues"]), "FINALIZE_NOT_CLOSED")
    # Stage new publication metadata separately. Never modify the accepted round.
    import tempfile
    with tempfile.TemporaryDirectory(prefix="feip-finalize-") as temp_name:
        stage = Path(temp_name) / "candidate"
        shutil.copytree(str(candidate), str(stage))
        # Retain the exact ICD bytes covered by the user's candidate confirmation.
        shutil.copyfile(str(candidate / "icd.json"), str(stage / "candidate_icd.json"))
        confirmation_path = stage / "release_confirmation.json"
        shutil.copyfile(str(confirmation_file), str(confirmation_path))
        known = known_artifacts(stage)
        manifest_art = uid("artifact")
        confirmation_art = uid("artifact")
        known[manifest_art] = "candidate_manifest.json"
        known[confirmation_art] = "release_confirmation.json"
        approval_uid, evidence_uid = uid("decision"), uid("evidence")
        model["consistency"]["evidence"].append({"uid": evidence_uid, "artifact_uid": confirmation_art, "json_pointer": "/user_quote", "part": None,
            "element_uid": None, "section": None, "table": None, "row": None, "column": None, "page": None,
            "quote": confirmation["user_quote"], "origin_kind": "user_supplied", "confirmation": "user_confirmed"})
        model["consistency"]["decisions"].append({"uid": approval_uid, "kind": "approve_release", "operation": None,
            "baseline_uid": model["protocol"]["baseline_uid"], "object_refs": [], "field_paths": [], "issue_refs": [], "before": None, "after": None,
            "reason": "用户确认当前已展示候选并要求生成最终JSON", "actor": confirmation["actor"], "decided_at": confirmation["confirmed_at"],
            "user_quote": confirmation["user_quote"], "user_evidence_refs": [evidence_uid], "target_fingerprint": confirmation["candidate_manifest_sha256"], "status": "active", "supersedes": []})
        model["consistency"]["release_binding"] = {"candidate_uid": manifest["candidate_uid"], "candidate_manifest_artifact_uid": manifest_art,
            "candidate_manifest_sha256": confirmation["candidate_manifest_sha256"], "release_confirmation_decision_uid": approval_uid}
        model["consistency"]["gates"]["delivery_state"] = "RELEASED"
        model["protocol"]["profile"] = "reqspec-reviewed"
        check_model(model, list(known) + [manifest["candidate_uid"]])
        final_icd = icd.build(model, "released", manifest["candidate_uid"])
        require(final_icd["engineering_sha256"] == load(candidate / "icd.json")["engineering_sha256"], "ICD_ENGINEERING_CHANGED: recheck and confirm a new candidate")
        preflight = load(candidate / "engineering_preflight.json")
        final_report = report(model, "最终一致性检查报告") + engineering.summary(preflight)
        result = publish(output, model, stage, known, {"最终检查报告.md": final_report, "icd.json": final_icd}, final=True)
        result["icd_path"] = str(Path(output) / "icd.json")
        result["engineering_preflight_path"] = str(Path(output) / "engineering_preflight.json")
        result["architecture_readiness"] = preflight["consumers"]["architecture"]["readiness"]
    return result

def run(argv=None):
    kind = KINDS[SKILL.name]
    parser = argparse.ArgumentParser(description="FEIP offline Agent-assisted skill runtime")
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("doctor")
    sub.add_parser("self-test")
    p = sub.add_parser("prepare")
    p.add_argument("--input", type=Path)
    p.add_argument("--baseline", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--previous-state", type=Path)
    p.add_argument("--decisions", type=Path)
    p.add_argument("--attachments", type=Path)
    p.add_argument("--diagnostic", action="store_true")
    p = sub.add_parser("extract")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("internal-prepare")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("internal-report")
    p.add_argument("--structure", type=Path, required=True)
    p.add_argument("--findings", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    for action in ("review", "generate", "compare"):
        p = sub.add_parser(action)
        p.add_argument("--attempt", type=Path, required=True)
        p.add_argument("--model", type=Path, required=True)
        p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("engineering-preflight")
    p.add_argument("--package", type=Path)
    p.add_argument("--attempt", type=Path)
    p.add_argument("--model", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("finalize")
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--confirmation", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("validate")
    p.add_argument("--package", type=Path, required=True)
    args = parser.parse_args(argv)
    allowed = {"taskbook": ("review",), "writer": ("generate",), "checker": ("compare", "finalize")}
    if args.action in ("review", "generate", "compare", "finalize"):
        require(args.action in allowed[kind], "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
    if args.action == "doctor":
        return {"python": platform.python_version(), "platform": platform.platform(), "target": "Windows 7 SP1 / PowerShell 2.0 / Python 3.8.10", "dependencies": "standard-library-only"}
    if args.action == "self-test":
        from .selftest import self_test
        return self_test()
    if args.action == "prepare":
        require(kind == "writer" or args.input is not None, "SOURCE_INPUT_REQUIRED")
        return prepare(kind, args.output, args.input, args.baseline, args.previous_state, args.decisions, args.diagnostic, args.attachments)
    if args.action == "extract":
        archive = extract(args.input, "taskbook" if kind == "taskbook" else "specification", "artifact:extract-input")
        save(args.output, archive)
        return {"output": str(args.output), "extraction_status": archive["extraction_status"]}
    if args.action == "review":
        return review(args.attempt, args.model, args.output)
    if args.action in ("internal-prepare", "internal-report"):
        require(kind == "checker", "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
        from . import internal_review
        if args.action == "internal-prepare":
            return internal_review.prepare(args.input, args.output)
        return internal_review.report(args.structure, args.findings, args.output)
    if args.action == "generate":
        return generate(args.attempt, args.model, args.output)
    if args.action == "compare":
        return compare(args.attempt, args.model, args.output)
    if args.action == "engineering-preflight":
        require(kind == "checker", "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
        return engineering_preflight(args.package, args.attempt, args.model, args.output)
    if args.action == "finalize":
        return finalize(args.candidate, args.confirmation, args.output)
    if args.action == "validate":
        model, manifest = verify_package(args.package)
        return {"valid": True, "profile": model["protocol"]["profile"], "package_uid": manifest["package_uid"], "icd_valid": True if (args.package / "icd.json").is_file() else None}
