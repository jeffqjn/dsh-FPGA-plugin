"use strict";
var child = require("child_process");
var fs = require("fs");
var path = require("path");
var actions = ["doctor", "prepare", "extract", "review", "generate", "compare", "finalize", "validate", "self-test"];
function run(action, args) {
  if (actions.indexOf(action) < 0 || !Array.isArray(args)) { throw new Error("Invalid action/arguments"); }
  args.forEach(function (arg) {
    if (typeof arg !== "string" || /[\0\r\n]/.test(arg)) { throw new Error("Invalid argument"); }
  });
  var python = process.env.FPGA_PYTHON38 || "C:\\Python38\\python.exe";
  if (!fs.existsSync(python)) { throw new Error("Set FPGA_PYTHON38 to Python 3.8.10 python.exe"); }
  var env = {};
  Object.keys(process.env).forEach(function (key) { env[key] = process.env[key]; });
  env.PYTHONUTF8 = "1"; env.PYTHONIOENCODING = "utf-8"; env.PYTHONDONTWRITEBYTECODE = "1";
  // File + argument vector: no cmd.exe, shell string, or PowerShell dependency.
  var output = child.execFileSync(python, [path.join(__dirname, "cli.py"), action].concat(args), {
    cwd: path.resolve(__dirname, ".."), env: env, encoding: "utf8", windowsHide: true,
    timeout: 300000, maxBuffer: 16 * 1024 * 1024
  });
  if (output.indexOf("FEIP_SKILL_OK:" + action) < 0) { throw new Error("Success marker missing"); }
  return {ok: true, action: action, output: output};
}
module.exports = {run: run};
if (require.main === module) {
  try { process.stdout.write(run(process.argv[2], process.argv.slice(3)).output); }
  catch (error) { process.stderr.write(String(error.message) + "\n"); process.exitCode = 2; }
}
