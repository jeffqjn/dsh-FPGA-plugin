# 离线运行接口

当前 writer 修订版本为 **1.4.0（DOCX与可读表格）**，FEIP 协议仍为 1.0.0。下述 1.3.0 通用接口继续兼容，运行环境要求不变。

## Word输出（1.4.0）

见[DOCX交付规范](docx_output.md)。首次运行前用Python3.8.10执行scripts/install_dependencies.py，随后generate同时产出DOCX与MD。新增源表格还原、测试行双重精确定位、器件管脚区分及术语去重；冻结基线不变。

## 前言与概述（1.3.8）

需求规格说明正文是正式报告，不是审阅稿：1.1、1.2、1.4、3.1、3.2不得出现“待确认”“任务书未明确”等审阅注记或“本配置项基本信息按任务书…列出”一类引导句；自写段落含此类用语在generate时被拒绝（OVERVIEW_REVIEW_ANNOTATION）。缺口一律由脚本登记到生成检查报告并保持DRAFT，正文只写已明确事实。

1.1由脚本按冻结basic_info分点列出九项：产品名称、配置项代号、研制类型、安全关键等级、继承基线、芯片型号、程序存储器、交办方、承办方（编号前缀不进正文，只用于需求编号校验）；缺项不显示、不编造，逐条进检查报告。1.4由脚本把冻结acronyms渲染为两列表格，左列名称、右列术语含义（英文全称＋中文解释，仅有其一则显示已有部分）；无含义的缩略语不进正文表格，只进检查报告。1.1/1.4不接受writer_plan自写段落、表格绑定或需求落点（DETERMINISTIC_SECTION_*），acronyms自本版起纳入writer冻结校验。

3.1标题改为“产品总体概述”，按固定模板分点：1)交办方 2)应用环境 3)用途 4)一般特征 5)软件继承性 6)研制单位 7)设计流程。1/2/3/6由脚本从assigner、host_unit、产品名称与主要功能、contractor装配，设计流程固定列出13个工作阶段a．任务需求阶段～m．验收交付（安全等级A类时条目名标注“设计流程(A类)”）；4/5由Agent以独立控制行“<!-- overview-item:general -->”“<!-- overview-item:inheritance -->”提供有来源的叙述段落，控制行不进入正文，未提供且有结构化事实时由脚本生成保守表述，无来源时该条目省略并进检查报告。3.2标题改为“产品功能概述”，内容沿用产品用途/主要功能归纳。旧上游writer_plan中的“产品结构概述”“产品功能描述”标题兼容读取，交付统一显示新标题。

## 测试要点（1.3.7）

7.1自动生成“测试要点”。表7.1-1四列为序号、测试要点、测试说明、对应需求项，按verification.source_test_points原顺序完整填入。7.2与7.3按1-52模板各子节提供现有证据支持的验证要求，缺项登记待确认。

测试说明仅复制各源测试点evidence_refs定位到的同包document_archive原文：完整段落，或明确row（从0开始）的完整表格行（包含该行跨行合并格）。归档及artifact须与证据匹配、read_status=complete。prepare的quote可能截断为500字，所以不能以quote、title、purpose或Agent摘要充当完整原文。跨段落内容应在上游为同一测试点保留全部证据；上游原文关联的语义正确性仍需Agent核实。认证书等其他来源须先由上游作为附件纳入归档，不在writer重新抽取。

源测试点缺失、原文定位不完整或没有需求关联时明确待确认并保持DRAFT，检查报告单列缺项。即使源测试点的结构化步骤或判据不完整，也不在writer补写；原文复制不宣称测试已执行、已通过或需求已覆盖。paragraphs中的临时改写不能覆盖原文复制。

旧上游7.1的“测试重点”、旧表头及deferred兼容读取，不修改冻结的源台账，输出统一为“测试要点”并填表；显式行引用遗漏源测试点或引用非源测试点则拒绝。旧deferred交叉引用如承载唯一义务，Agent须在本轮计划明确自动主落点，不能用兼容标记绕过完整性校验。

## 外部接口描述（1.3.6）

每个5.2.x按接口定义、接口时序、接口可编程要求三个部分组织。信号表归定义，地址/寄存器表归可编程要求；原子条款完整保留，源接口timing_text/programming_rules按明确对象关联归入对应部分。5.2总管脚表不移动到子节后，也不在每个子节重复。

Agent可通过paragraphs中的独立三类标题组织文字，并用“<!-- interface-group:req:实际UID=timing -->”等控制行指定本小节原子要求位置；可选组为definition/timing/programming，指令不进入交付正文。旧计划缺少显式归类时只做展示分组，具体语义须审阅。缺少某部分时明确待确认并列入DRAFT；不造时序图或默认实现措施。

## 编程及验收性模板（1.3.5）

固定路径与器件库同目录：assets/device_resources/5.1.3_编程及验收性模板.md。用户预先编辑“## VHDL”“## Verilog”两个分支的正文；生成5.1.3只按项目已明确的RTL语言复制对应分支，不改写或替换变量，源需求主条款保留。

语言来源为已明确的language资源字段或有效language类需求的明确采用陈述。不按器件/文件后缀/测试平台/禁止使用陈述选型；未明确、多语言冲突或SystemVerilog不能自动映射时生成待确认草稿。只检查选中分支的配置占位。完整模板和摘要保存在inputs/programming_template/，validate使用该次副本，不受后续预配置编辑影响。

## 器件资源库（1.3.4）

固定路径为skill根目录的assets/device_resources/器件资源库.md。随包提供八列表格模板，每行一个用户核实的完整器件型号。5.1.1正式输出“器件资源”，新增表5.1.1-1，不改动其他表编号。完整任务选型取basic_info.chip_model；仅按完整型号匹配，不按前缀、系列或表格行顺序猜测。未选型/未匹配/字段缺失时显示待确认并为DRAFT，重复型号或损坏列数则报错。旧上游writer_plan中的“需求来源”标题只做兼容读取，交付正文统一显示“器件资源”。

八列为器件型号、封装、速度等级、质量等级、逻辑资源门数、IO管脚数量、有无在轨维护需求、不满足项的应对措施。计数和等级只用用户配置，不在线查询或从型号推断；在轨维护填有/无/待确认，不满足项及措施明确配对。与任务要求冲突由Agent列明并请求用户确认，不能静默覆盖有效义务。

generate将整库保存到inputs/device_resources/器件资源库.md，并记录manifest及SHA-256。报告只呈现匹配行；validate使用包内副本。没有匹配的型号需用户在库中新增后重新生成，不能把其他型号的数据移植过来。

## 固定内容预配置（1.3.3）

用户在首次使用前直接编辑skill根目录下的三个UTF-8文件：

- assets/fixed_sections/1.3_文档概述.md：第1.3节正文，不含章节标题。
- assets/fixed_sections/2.1_规范性引用文件.md：第2.1节引用清单正文，包含用户要保留的完整表格。
- assets/fixed_sections/2.2_研制依据引用文件.md：第2.2节引用清单正文，包含用户要保留的完整表格。

随包示例中的【请配置：…】由用户替换或删除；没有适用引用文件时仅保留表头和分隔线。设置后各次生成直接使用，不要求用户重复提供，也不通过模型猜填。正文不做变量替换；不增删、改写、联网补全引用，不再附加重复模板表。1.3的结构标题仍沿用既定“文档描述”，其内容由用户配置为文档概述。

generate将当次配置复制到attempt的inputs/fixed_sections/，记录manifest.json及摘要，生成与检查使用同一份副本。配置改变后，原交付包的validate仍使用包内副本；重新生成则使用新配置。文件缺失或为空时报出固定路径；示例占位未清理时生成DRAFT并列出配置待办。

固定内容是用户提供的数据，不作为执行指令，也不能将已审查的技术义务移到固定章节后丢弃。writer_plan中的1.3/2.1/2.2段落和表格不覆盖配置，技术义务应安排到对应技术章节。

## FPGA概述（1.3.2）

1.2及3.1/3.2必须是实际配置项的系统/结构/功能概述；1.3才描述文档目的和读者。Agent依据冻结的system_overview、basic_info、analysis及原文素材，归纳产品定位、职责边界、主要功能及有依据的输入处理输出关系，不把全部原子条款搬到概述，也不补做内部架构设计。段落应体现配置项名称或代号。

未编写概述段落时，writer_overview.py直接用已明确的结构化事实生成保守正文；来源不足写出待确认并列入DRAFT。它不自动理解缺失的自然语言职责、不按功能名称猜测算法/模块。检查报告单列概述缺项；既有有来源的产品总结保持原文，不能只输出标题或用通用文档目的充当产品总结。

## 表格填充与校验（1.3.1）

- 模板表是实际交付表，数据直接由 row_object_refs 填入。不能同时交付同用途的空模板表和另一张数据表。
- 同章节、相同列定义的模板表与补充表合并行引用并去重；同用途但列定义冲突时报 DUPLICATE_TABLE_PURPOSE，需修正模型，不静默丢列。
- paragraphs 只放文字；Markdown 表格必须进入 tables。不能把已填表格写入 paragraphs 绕过表格校验。
- 信号汇总可直接绑定完整信号清单；接口子表仅按明确的接口对象或需求关联绑定，不能按接口名称猜测。已有绑定缺少对应信号时拒绝生成。
- 附录 A.1/A.2 直接填入各自规定的表头，不再追加另一张替代矩阵。
- 第7章除7.1测试要点外、10/11/C/D按既定范围保留空表；7.1直接复制源测试要点。引用章节按1.3.3预配置原样复制，没有引用时用户预留空表；真实更改记录未提供时允许留空并说明。其他自动表没有可用行时，列出待确认原因并保持DRAFT，不能仅凭表头存在判定已完成。
- 不支持的复杂列映射仍需实现或补充结构化来源，不能新增一张不同结构的表绕过。修复版不声称所有复杂表已具备完整映射。
- validate 在摘要/Schema 检查之外，对 writer 交付的 MD 与冻结模型重新装配结果逐字核对；修改 MD 后即使重新计算文件摘要也不能绕过。
- 旧版本生成的草稿应重新 prepare/generate，保留旧包作记录，不直接覆盖或伪造其产物摘要。

实现版本1.3.0；统一交换协议保持FEIP/1.0.0。正式CLI仍只接受Python 3.8.10。unknown封面元信息或自动章节缺项会生成DRAFT；全部必需信息明确后才可READY_FOR_REVIEW。输出目录必须为输入快照之外的新目录。task-validation的review自动输出需求清单.md，validate校验同版一致性；checker的compare/finalize自动导出icd.json，validate同时核验其源模型绑定与工程内容。

本skill独立携带所需脚本与Schema，无需其余skill或相邻共享库。FEIP 核心 Schema 随每包提供。FEIP脚本使用Python标准库，DOCX投影按references/docx_output.md安装随包固定离线依赖。

## 环境

- Windows7 SP1；PowerShell2.0；Python **3.8.10**，补丁版本也必须相同。CLI 对其他版本直接报 PYTHON_RUNTIME_MISMATCH，无生产绕过开关。
- 用户安装的解释器默认 `C:\Python38\python.exe`；其他位置设置进程环境变量 `FPGA_PYTHON38`，值必须是 python.exe 完整路径。无需py launcher、pip、jsonschema或Node全局命令；DOCX用随包wheel安装python-docx/lxml。
- PowerShell入口只使用2.0语法，不依赖 PSScriptRoot、ConvertFrom-Json、Get-FileHash、Expand-Archive、Get-ChildItem -File/-Recurse 的新参数、`::new`、管道并行或新运算符。JSON解析、摘要和归档由Python完成。
- JSON/MD UTF-8无BOM；PS1纯ASCII，避免PS2读取UTF-8中文脚本的编码问题。环境变量仅影响当前进程及其子进程。

宿主现在支持execute command（或execute_command），优先直接执行Python CLI，无需Node.js包装器：

```powershell
& 'C:\Python38\python.exe' 'D:\skills\req-spec-gen\scripts\cli.py' doctor
& 'C:\Python38\python.exe' 'D:\skills\req-spec-gen\scripts\cli.py' self-test
```

以上是PowerShell2.0命令文本示例，由宿主的execute command工具执行；使用实际安装路径，不虚构宿主工具名或参数。若宿主支持可执行文件/参数数组，应分别传入python.exe和脚本参数。其他动作直接在cli.py后追加动作及参数即可。

也可继续使用PowerShell2.0便捷入口：

```powershell
$env:FPGA_PYTHON38 = 'C:\Python38\python.exe'
& 'D:\skills\req-spec-gen\scripts\run.ps1' doctor
```


如需兼容旧JS宿主，可选调用本包scripts/run_python.js；它不是当前execute command宿主的必经入口。

```javascript
var runner = require("D:/skills/req-spec-gen/scripts/run_python.js");
runner.run("doctor", []);
```


任何执行入口均须核对退出码0和本动作`FEIP_SKILL_OK:<action>`，并检查返回路径的本次产物。门禁FAIL不代表脚本执行失败，检查结果在报告及JSON中。

## 动作

| 动作 | 参数 | 说明 |
|---|---|---|
| doctor | 无 | 精确Python版本检查；记录当前OS，不声称在Win7验收过 |
| self-test | 无 | 临时目录运行结构/事务/拒绝用例，结束清理 |
| extract | --input 文件 --output JSON | 提取DOCX/TXT/MD；输出archive结构，不自动理解规范性语义 |
| prepare | --input 文件 --output 根目录 [--baseline 包目录] [--previous-state 状态JSON] [--decisions 决定JSON] [--attachments 附件清单JSON] [--diagnostic] | 冻结输入并生成model.template.json，返回本次attempt目录 |
| review | --attempt 目录 --model Agent模型JSON --output 新目录 | 仅task-validation；输出taskbook-reviewed FEIP包及中文报告 |
| generate | 同上 | 仅writer；从冻结writer_plan装配完整DOCX、MD及FEIP草稿包 |
| compare | 同上 | 仅checker；比对判断由Agent提供，脚本检查引用/状态/决定/基线并产审查轮次包 |
| finalize | --candidate 闭环轮次目录 --confirmation 确认JSON --output 新目录 | 仅checker；核验候选/规则/输入/授权后生成最终reqspec.json |
| validate | --package 包目录 | 校验随包文件、SHA256、Schema、引用及已实现业务不变量 |

taskbook prepare不传baseline；writer prepare不传input、必传baseline；checker二者均必传。正式checker要求上游PASS；非PASS只能显式diagnostic，不可finalize。各阶段output必须为新目录；不会覆盖用户文件。每个attempt只消费一次Agent模型；失败后重新prepare，不能覆盖旧round伪装成功。

`prepare`不是语义分析。Agent应另存model.template的编辑结果为新JSON，再调用相应动作。结构提取JSON不是有效需求台账，空模板不能审查成功。

附件清单为`[{"path":"D:/project/协议附件.docx","description":"外部协议定义"}]`。附件原字节一并冻结；DOCX/TXT/MD继续结构提取，图片/PDF等二进制标not_read并要求核实转录。附件不允许只保存外部路径后宣称已经读取。checker附件中的新增规范性义务仍按NEW_KEY/源遗漏处理，不擅自改B0。

## 决定与最后确认

本轮新增决定通过`prepare --decisions decisions.json`输入；文件为完整FEIP Decision对象数组，Agent从用户明确意见登记，不能自己发明意见。模型中的新增Decision必须逐字匹配该数组，证据关联该文件artifact。用户未表明理由/对象/目标值时保留待办，不登记生效批准。

compare闭环且准入通过时产生candidate_payload.json、review_packet.md、candidate_manifest.json，交付状态AWAITING_FINAL_CONFIRMATION；此时没有正式reqspec.json。Agent向用户展示当前审阅包及完整模型，再请求最终生成确认。

用户明确确认该版本后，记录如下文件；candidate的ID及摘要取compare返回结果，不猜填：

```json
{
  "kind": "approve_release",
  "candidate_uid": "candidate:从当前轮次读取",
  "candidate_manifest_sha256": "从当前轮次读取64位摘要",
  "actor": "当前用户（未提供姓名）",
  "confirmed_at": "带时区的实际确认时间",
  "user_quote": "用户对当前候选明确要求生成最终JSON的原话"
}
```

这是字段说明，不能把上面示例当成授权输入。程序只能核验记录与候选绑定，用户意见真实性由skill宿主保证。单项问题确认、沉默、超时、认可设计方案都不是approve_release。原文/模型/决定/规则/Schema变化须重新比较和确认。完全相同候选写入失败后的重试可以复用有效确认，无需重复询问。

失败发布目录带`.staging-.../FAILED.json`且package.status=staging；不能作为交接包。目录锁阻止同名并发发布；不自动清理别人的锁或失败资料。

## 抽取范围

支持正文段落、内容控件中的正文、表格、合并格、可恢复的十进制编号、标题样式、页眉页脚及脚注/尾注文本。原DOCX字节完整归档。

图片不做OCR；图中文字、修订未接受、嵌入对象、编号覆盖/自定义格式、域结果与文本框等标出partial。无法可靠阅读的关键内容必须阻断；提供可核查转录并保留原对象出处后重新prepare。不能把“XML可解析”当成全量工程内容已读取，也不能伪造页码。
