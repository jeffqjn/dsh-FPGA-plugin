"""Offline FEIP skill runtime, Python 3.8.10 / Windows 7 SP1."""
