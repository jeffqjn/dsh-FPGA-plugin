"""附录C/D固定技术要素检查表：要素行取自模板，是否适用/是否符合由Agent判定并受校验。"""
import copy
import io
import json

from .assurance import NOT_CONFORMED, RESULT_COLUMN, checklist, column_values, counts, judgements, warnings
from .base import Failure
from .render import render
from .template_layout import ASSURANCE_COLUMNS


def item(key, applicable, conform, sections, result):
    return "<!-- assurance-item:" + json.dumps(
        {"key": key, "applicable": applicable, "conform": conform, "sections": sections, "result": result},
        ensure_ascii=False) + " -->"


def judged(seed):
    """Pretend the Agent judged every fixed item, as a writer_plan would carry it."""
    model = copy.deepcopy(seed)
    sections = {section["number"]: section for view in model["document_views"]
                if view["role"] == "writer_plan" for section in view["sections"]}
    for number, total, cited in (("C", 18, "5.4"), ("D", 6, "5.2")):
        sections[number]["paragraphs"] = [item(number + str(index), "适用", "符合", [cited], "已在本节提出相应要求")
                                          for index in range(1, total + 1)]
    sections["C"]["paragraphs"][3] = item("C4", "适用", "待确认", ["7.3.3"], "7.3.3尚未形成不可测试项清单，来源未明确")
    sections["C"]["paragraphs"][14] = item("C15", "不涉及", NOT_CONFORMED, [], "本配置项不含在轨维护功能，不涉及本项")
    return model


def run_tests(seed):
    results = []

    def rejects(code, action):
        try:
            action()
        except (Failure, ValueError) as error:
            assert code in str(error), str(error)
        else:
            raise AssertionError("expected rejection: " + code)
        results.append(code)

    sections = checklist()
    # 模板附录C为18项检查项、附录D为6项检查项；分类固定，不随项目增删。
    assert len(sections["C"]["rows"]) == 18 and len(sections["D"]["rows"]) == 6
    assert {row["category"] for row in sections["C"]["rows"]} == {"过程控制", "编程实现", "测试验证要素"}
    assert {row["category"] for row in sections["D"]["rows"]} == {"开发设计"}
    results.append("appendix-cd-checklist-rows-taken-from-template-without-project-trimming")

    model = judged(seed)
    md = render(model)
    c_block = md.split("## 附录C ", 1)[1].split("## 附录D ", 1)[0]
    d_block = md.split("## 附录D ", 1)[1]
    assert "表C-1 通用技术要素确认检查表" in c_block and "表D-1 专用技术要素确认检查表" in d_block
    assert "人工填写。" not in c_block and "人工填写。" not in d_block
    header = "| " + " | ".join(ASSURANCE_COLUMNS) + " |"
    assert c_block.count(header) == 1 and d_block.count(header) == 1
    assert c_block.count("\n| --- |") == 1 and d_block.count("\n| --- |") == 1
    assert ("| 1 | 过程控制 | 新状态识别与控制 | 在需求分析阶段，对新状态进行标识、分解、分析"
            " | 需求规格说明 | 适用 | 符合 | 5.4：已在本节提出相应要求 |  |") in c_block
    assert "| 15 | 过程控制 | 在轨维护设计 |" in c_block and "| 不涉及 | " + NOT_CONFORMED + " |" in c_block
    assert "| 适用 | 待确认 | 7.3.3尚未形成不可测试项清单，来源未明确 |" in c_block
    assert c_block.count("| 适用 | 符合 |") == 16
    assert len([row for row in c_block.splitlines() if row.startswith("| ")]) == 20
    assert len([row for row in d_block.splitlines() if row.startswith("| ")]) == 8
    results.append("appendix-cd-agent-judgement-fills-applicability-conformity-and-result")

    tally = counts(model)
    assert tally == {"适用": 23, "不适用": 0, "不涉及": 1, "符合": 22, "不符合": 0, "待确认": 1, "未提交": 0}, tally
    notes = warnings(model)
    assert len(notes) == 1 and notes[0].startswith("附录C 不可测试项分析与控制") and "待确认" in notes[0]
    results.append("appendix-cd-tally-and-open-items-reported-for-review")

    from docx import Document
    from .docx_writer import build
    document = Document(io.BytesIO(build(md, model)))
    table = next(item for item in document.tables if len(item.columns) == len(ASSURANCE_COLUMNS))
    assert len(table.rows) == 20
    # 模板两行表头：分组行横向合并5～7列，其余列竖向跨行。
    assert table.rows[0].cells[5].text == "设计师检查要点" == table.rows[0].cells[7].text
    assert table.rows[0].cells[0].text == "序号" and table.rows[0].cells[8].text == ASSURANCE_COLUMNS[8]
    assert table.rows[1].cells[7].text == ASSURANCE_COLUMNS[7]
    assert [table.rows[2].cells[index].text for index in (5, 6, 7, 8)] == ["适用", "符合", "5.4：已在本节提出相应要求", ""]
    assert table.rows[16].cells[2].text == "在轨维护设计" and table.rows[16].cells[5].text == "不涉及"
    assert table.rows[19].cells[1].text == "测试验证要素"
    assert table.rows[0]._tr.xpath("./w:trPr/w:tblHeader") and table.rows[1]._tr.xpath("./w:trPr/w:tblHeader")
    results.append("appendix-cd-docx-keeps-template-group-header-and-repeat-header-rows")

    from docx.oxml.ns import qn
    body = list(document.element.body)
    rows_of = lambda element: len(element.xpath('./w:tr'))
    c_index = next(index for index, element in enumerate(body)
                   if element.tag == qn('w:tbl') and rows_of(element) == 20)
    d_index = next(index for index, element in enumerate(body)
                   if element.tag == qn('w:tbl') and rows_of(element) == 8)
    text_of = lambda element: ''.join(element.itertext())
    assert text_of(body[c_index - 1]).startswith("表C-1") and "共18项" in text_of(body[c_index - 2])
    assert text_of(body[c_index - 3]).startswith("附录C")
    # 标题、说明、表题随表进入横向节，避免标题留在前一纵向页。
    assert body[c_index - 4].xpath('./w:pPr/w:sectPr')
    assert text_of(body[d_index - 3]).startswith("附录D")
    # 附录C与附录D同为宽表，连续排在同一横向节，不再来回切换纸张方向。
    assert not body[d_index - 4].xpath('./w:pPr/w:sectPr')
    results.append("appendix-cd-heading-note-and-caption-travel-with-the-wide-table")

    # 未提交判定时如实标“待确认”，不臆造结论，并全部登记。
    plain = copy.deepcopy(seed)
    section = {item["number"]: item for view in plain["document_views"] if view["role"] == "writer_plan"
               for item in view["sections"]}["C"]
    section["paragraphs"] = []
    cells = column_values("C", ASSURANCE_COLUMNS, section, plain)
    assert [row[5] for row in cells] == ["待确认"] * 18 and [row[6] for row in cells] == [NOT_CONFORMED] * 18
    assert all(row[8] == "" for row in cells)
    assert len(warnings(plain)) == 24
    assert counts(plain)["未提交"] == 24
    results.append("appendix-cd-missing-judgement-stays-pending-and-is-counted")

    broken = copy.deepcopy(seed)
    target = {item["number"]: item for view in broken["document_views"] if view["role"] == "writer_plan"
              for item in view["sections"]}["C"]

    def with_lines(*lines):
        target["paragraphs"] = list(lines)
        return column_values("C", ASSURANCE_COLUMNS, target, broken)

    rejects("ASSURANCE_SECTION_PROSE_NOT_ALLOWED", lambda: with_lines("本项符合要求。"))
    rejects("ASSURANCE_ITEM_UNKNOWN_KEY", lambda: with_lines(item("C99", "适用", "符合", ["5.4"], "无")))
    rejects("ASSURANCE_ITEM_DUPLICATE_KEY", lambda: with_lines(item("C1", "适用", "符合", ["5.4"], "无"),
                                                               item("C1", "适用", "符合", ["5.4"], "无")))
    rejects("ASSURANCE_ITEM_APPLICABILITY_INVALID", lambda: with_lines(item("C1", "部分适用", "符合", ["5.4"], "无")))
    rejects("ASSURANCE_ITEM_CONFORMITY_MUST_BE_DASH",
            lambda: with_lines(item("C1", "不适用", "符合", ["5.4"], "无")))
    rejects("ASSURANCE_ITEM_CONFORMITY_INVALID", lambda: with_lines(item("C1", "适用", "基本符合", ["5.4"], "无")))
    rejects("ASSURANCE_ITEM_SECTIONS_REQUIRED", lambda: with_lines(item("C1", "适用", "符合", [], "无")))
    rejects("ASSURANCE_ITEM_RESULT_REQUIRED", lambda: with_lines(item("C1", "适用", "符合", ["5.4"], "  ")))
    rejects("ASSURANCE_SECTION_UNKNOWN", lambda: with_lines(item("C1", "适用", "符合", ["9.9"], "无")))
    target["paragraphs"] = [item("C1", "适用", "符合", ["7.3.3"], "无")]
    next(item for view in broken["document_views"] if view["role"] == "writer_plan"
         for item in view["sections"] if item["number"] == "7.3.3")["status"] = "unknown"
    rejects("ASSURANCE_SECTION_NOT_SUBSTANTIVE",
            lambda: column_values("C", ASSURANCE_COLUMNS, target, broken))
    results.append("appendix-cd-rejects-prose-unknown-keys-and-unsupported-conclusions")
    return results
