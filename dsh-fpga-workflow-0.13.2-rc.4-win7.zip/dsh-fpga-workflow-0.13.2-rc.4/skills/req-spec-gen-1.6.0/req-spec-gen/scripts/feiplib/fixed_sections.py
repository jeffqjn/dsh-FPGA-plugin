"""Verbatim, user-maintained sections and immutable per-run configuration copies."""
import re
from pathlib import Path

from .base import SKILL, digest, load, require, save, text, verify_inputs


FILES = {"1.3": "1.3_文档概述.md", "2.1": "2.1_规范性引用文件.md", "2.2": "2.2_研制依据引用文件.md"}
CONFIG_DIR = SKILL / "assets/fixed_sections"


def read(directory=None):
    directory = Path(directory) if directory is not None else CONFIG_DIR
    result = {}
    for number, filename in FILES.items():
        path = directory / filename
        require(path.is_file(), "FIXED_SECTION_FILE_MISSING: " + str(path))
        content = path.read_text(encoding="utf-8-sig")
        require(bool(content.strip()), "FIXED_SECTION_FILE_EMPTY: " + str(path))
        result[number] = content
    return result


def warnings(content):
    return [number + "：固定配置仍含【请配置：…】占位，请编辑 assets/fixed_sections/" + FILES[number]
            for number, value in content.items() if re.search(r"【请配置[^】]*】", value)]


def freeze(attempt):
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    require(info["kind"] == "writer", "GENERATE_REQUIRES_WRITER_ATTEMPT")
    require(not (attempt / "inputs/agent_model.json").exists(), "ATTEMPT_ALREADY_CONSUMED: prepare a fresh attempt")
    content = read()
    folder = attempt / "inputs/fixed_sections"
    require(not folder.exists(), "FIXED_SECTION_SNAPSHOT_EXISTS: prepare a fresh attempt")
    folder.mkdir(parents=True)
    bindings = []
    for number, filename in FILES.items():
        source = CONFIG_DIR / filename
        target = folder / filename
        text(target, content[number])
        binding = {"section": number, "file": filename, "sha256": digest(target)}
        bindings.append(binding)
        info["input_bindings"].append({"path": target.relative_to(attempt).as_posix(), "sha256": binding["sha256"]})
        info["original_inputs"].append({"path": str(source.resolve()), "sha256": digest(source)})
    manifest = folder / "manifest.json"
    save(manifest, {"contract": "reqspec-fixed-sections/1.0", "files": bindings})
    info["input_bindings"].append({"path": manifest.relative_to(attempt).as_posix(), "sha256": digest(manifest)})
    save(attempt / "attempt.json", info)
    return content


def frozen(package):
    folder = Path(package) / "inputs/fixed_sections"
    manifest = load(folder / "manifest.json")
    require(manifest.get("contract") == "reqspec-fixed-sections/1.0", "FIXED_SECTION_MANIFEST_INVALID")
    expected = {(number, filename) for number, filename in FILES.items()}
    entries = manifest.get("files", [])
    require(len(entries) == len(FILES) and {(b["section"], b["file"]) for b in entries} == expected,
            "FIXED_SECTION_MANIFEST_INVALID")
    for binding in entries:
        path = folder / binding["file"]
        require(path.is_file() and digest(path) == binding["sha256"], "FIXED_SECTION_SNAPSHOT_CHANGED: " + binding["file"])
    return read(folder)
