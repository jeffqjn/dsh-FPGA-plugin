"""Exact section copy, model precedence, and snapshot integrity regression checks."""
import copy

from .base import Failure, digest, save, text
from .fixed_sections import FILES, frozen, read, warnings
from .render import render


def run_tests(seed, root):
    folder = root / "fixed-config-test"
    folder.mkdir()
    custom = {"1.3": "用户固定正文：{{产品名称}}不做替换。\n\n第二段按用户原文保留。\n",
              "2.1": "| 文件编号 | 文件名称 |\n| --- | --- |\n| TEST-STD | 用户指定文件V2 |\n",
              "2.2": "| 文件编号 | 文件名称（版本号） |\n| --- | --- |\n"}
    for number, filename in FILES.items():
        text(folder / filename, custom[number])
    content = read(folder)
    assert content == custom and not warnings(content)
    model = copy.deepcopy(seed)
    sections = {s["number"]: s for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"]}
    for number in FILES:
        sections[number]["paragraphs"] = ["模型临时生成的内容不应覆盖用户固定配置。"]
    md = render(model, content)
    for value in custom.values():
        assert md.count(value) == 1
    assert "模型临时生成的内容" not in md and "模板表2\n" not in md and "模板表3\n" not in md
    assert "{{产品名称}}" in md and "TEST-STD" in md
    results = ["fixed-sections-copied-once-verbatim-without-model-override-or-variable-substitution"]
    sections["1.3"]["primary_requirement_refs"] = ["req:latency"]
    try:
        render(model, content)
    except Failure as exc:
        assert "FIXED_SECTION_REQUIREMENT_PLACEMENT" in str(exc)
    else:
        raise AssertionError("fixed-section copy silently dropped a normative obligation")
    results.append("fixed-section-copy-cannot-hide-normative-requirement-placement")

    configured = dict(content)
    configured["1.3"] = "【请配置：用户文档概述】"
    assert len(warnings(configured)) == 1 and "1.3" in warnings(configured)[0]
    results.append("starter-placeholders-reported-as-configuration-pending")
    first = folder / FILES["1.3"]
    first.unlink()
    try:
        read(folder)
    except Failure as exc:
        assert "FIXED_SECTION_FILE_MISSING" in str(exc)
    else:
        raise AssertionError("missing fixed content accepted")
    text(first, "\n")
    try:
        read(folder)
    except Failure as exc:
        assert "FIXED_SECTION_FILE_EMPTY" in str(exc)
    else:
        raise AssertionError("empty fixed content accepted")
    results.append("missing-and-empty-fixed-files-rejected-with-specific-path")

    snapshot = root / "fixed-snapshot-test/inputs/fixed_sections"
    snapshot.mkdir(parents=True)
    entries = []
    for number, filename in FILES.items():
        text(snapshot / filename, custom[number])
        entries.append({"section": number, "file": filename, "sha256": digest(snapshot / filename)})
    save(snapshot / "manifest.json", {"contract": "reqspec-fixed-sections/1.0", "files": entries})
    assert frozen(snapshot.parents[1]) == custom
    text(snapshot / FILES["2.1"], "changed")
    try:
        frozen(snapshot.parents[1])
    except Failure as exc:
        assert "FIXED_SECTION_SNAPSHOT_CHANGED" in str(exc)
    else:
        raise AssertionError("changed snapshot accepted")
    results.append("fixed-section-snapshot-digest-verified")
    return results
