"""Interface section layout and preservation of source obligations."""
import copy

from .base import Failure, SKILL, load
from .interface_layout import groups, missing, warnings
from .render import render
from .writer_tables import resolve


def run_tests(seed):
    model = copy.deepcopy(seed)
    template = load(SKILL / "templates/document_structure.json")
    plan = next(v for v in model["document_views"] if v["role"] == "writer_plan")
    next(s for s in plan["sections"] if s["number"] == "5.4")["primary_requirement_refs"] = []
    for suffix, statement in (("definition", "DATA为单向输入信号。"), ("programming", "控制寄存器允许软件配置使能位。")):
        req = copy.deepcopy(seed["requirements"][0])
        req.update(uid="req:" + suffix, normalized_id="TEST-IREQ-" + ("2" if suffix == "definition" else "3"), category="interface")
        req["revisions"][0]["semantic"].update(statement=statement, constraint_refs=[])
        model["requirements"].append(req)
    model["analysis"]["signals"] = [{"header": {"uid": "signal:data", "name": "DATA", "reason": None}, "interface_uid": "interface:external", "direction": "input", "width": 1, "pins": [], "io_standard": None, "default_value": None}]
    model["analysis"]["interfaces"] = [{"header": {"uid": "interface:external", "name": "虚构外部接口", "status": "present", "requirement_refs": []}, "scope": "external", "timing_text": ["DATA在CLK上升沿采样。"], "programming_rules": ["使能配置仅在接口空闲时修改。"]}]
    section = {"uid": "sectionview:external", "number": "5.2.1", "title": "与外部设备接口", "status": "present", "handling": "auto", "reason": None,
               "primary_requirement_refs": ["req:definition", "req:latency", "req:programming"], "cross_requirement_refs": [],
               "spec_item_refs": [], "object_refs": [{"kind": "interface", "uid": "interface:external", "revision_uid": None}], "material_element_refs": [],
               "paragraphs": [], "tables": [{"uid": "tableview:external", "caption": t["caption"], "columns": t["columns"], "row_object_refs": [], "evidence_refs": []} for t in template["tables"] if t["section"] == "5.2.1"]}
    pos = next(i for i, s in enumerate(plan["sections"]) if s["number"] == "5.3")
    plan["sections"].insert(pos, section)
    md = render(model)
    body = md.split("#### 5.2.1 ", 1)[1].split("### 5.3 ", 1)[0]
    assert body.count("**接口定义**") == body.count("**接口时序**") == body.count("**接口可编程要求**") == 1
    assert body.index("**接口定义**") < body.index("表5.2-2") < body.index("**接口时序**") < body.index("**接口可编程要求**")
    results = ["external-interface-three-block-order-and-signal-table-under-definition"]
    assert body.index("DATA为单向输入") < body.index("**接口时序**")
    assert body.index("**接口时序**") < body.index("不大于10 ms") < body.index("**接口可编程要求**")
    assert body.index("控制寄存器允许") > body.index("**接口可编程要求**")
    for value in ("TEST-IREQ-2", "TEST-PREQ-1", "TEST-IREQ-3"):
        assert body.count("〔" + value + "〕") == 1
    assert "DATA在CLK上升沿采样。" in body and "使能配置仅在接口空闲时修改。" in body
    assert "参见需求" not in body
    results.append("interface-source-clauses-metadata-and-numeric-bounds-preserved-once")
    assert md.index("表5.2-1") < md.index("#### 5.2.1") and not warnings(model)
    results.append("global-pin-summary-retained-before-interface-details")

    section["paragraphs"] = ["<!-- interface-group:req:definition=programming -->", "**接口时序**", "来源明确的时序说明。"]
    grouped = groups(section, resolve(section, template, model), model)
    assert "req:definition" in grouped["programming"]["requirements"]
    assert "来源明确的时序说明。" in grouped["timing"]["paragraphs"]
    assert "interface-group" not in render(model)
    results.append("agent-explicit-placement-overrides-presentation-fallback-without-visible-directives")
    section["paragraphs"] = ["<!-- interface-group:req:unknown=timing -->"]
    try:
        render(model)
    except Failure as exc:
        assert "INTERFACE_GROUP_UNKNOWN_REQUIREMENT" in str(exc)
    else:
        raise AssertionError("unknown interface placement accepted")
    results.append("invalid-interface-placement-rejected")
    section["paragraphs"] = []
    no_data = copy.deepcopy(section)
    no_data.update(primary_requirement_refs=[], cross_requirement_refs=[], object_refs=[])
    no_data["tables"] = []
    assert len(missing(no_data, groups(no_data, [], model))) == 3
    no_data.update(status="not_applicable", reason="来源已明确本接口不适用")
    assert not missing(no_data, groups(no_data, [], model))
    results.append("missing-interface-content-is-pending-not-invented-as-none")
    return results
