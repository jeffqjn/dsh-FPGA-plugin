"""Product overview regression tests using explicitly synthetic source facts."""
import copy

from .base import Failure, fact
from .render import render
from .writer_overview import paragraphs, terms_table, warnings


def run_tests(seed):
    model = copy.deepcopy(seed)
    model["basic_info"]["product_name"] = fact("虚构采集控制FPGA")
    model["basic_info"]["config_item_code"] = fact("DEMO01")
    model["basic_info"]["development_type"] = fact("III类")
    model["basic_info"]["safety_level"] = fact("A")
    model["basic_info"]["maintenance_base"] = fact("虚构基线FPGA V2.00")
    model["basic_info"]["chip_model"] = fact("虚构器件-A")
    model["basic_info"]["program_memory"] = fact("虚构PROM")
    model["basic_info"]["assigner"] = fact("虚构总体部")
    model["basic_info"]["contractor"] = fact("虚构研制所")
    model["system_overview"]["host_unit"] = fact("虚构采集单机")
    model["system_overview"]["main_functions"] = fact("数据采集、时间标记、安全门控")
    model["system_overview"]["long_term_power_on"] = fact(False)
    model["acronyms"] = [
        {"uid": "acronym:fpga", "abbreviation": "FPGA", "full_name": fact("Field Programmable Gate Array"),
         "meaning": fact("现场可编程门阵列"), "evidence_refs": []},
        {"uid": "acronym:prm", "abbreviation": "PRM", "full_name": fact(), "meaning": fact("伪距测量"), "evidence_refs": []},
        {"uid": "acronym:nomeaning", "abbreviation": "NOMEANING", "full_name": fact(), "meaning": fact(), "evidence_refs": []},
    ]
    sections = {s["number"]: s for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"]}
    original = copy.deepcopy(model)
    result = []

    basic = "\n".join(paragraphs(sections["1.1"], model))
    assert "1) 产品名称：虚构采集控制FPGA" in basic and "2) 配置项代号：DEMO01" in basic
    assert "9) 承办方：虚构研制所" in basic
    assert "本配置项基本信息" not in basic and "按任务书" not in basic and "待确认" not in basic
    assert "编号前缀" not in basic
    result.append("basic-info-listed-point-by-point-without-lead-in")

    system = "\n".join(paragraphs(sections["1.2"], model))
    assert "DEMO01" in system and "虚构采集单机" in system and "非长期开机" in system
    assert "待确认" not in system and "未明确" not in system
    result.append("system-overview-states-only-confirmed-facts")

    terms = "\n".join(terms_table(model))
    assert terms.startswith("| 名称 | 术语含义 |")
    assert "| FPGA | Field Programmable Gate Array，现场可编程门阵列 |" in terms
    assert "| PRM | 伪距测量 |" in terms
    assert "NOMEANING" not in terms
    result.append("terms-rendered-as-two-column-table")

    overview = "\n".join(paragraphs(sections["3.1"], model))
    assert "1) 交办方：虚构总体部" in overview
    assert "2) 应用环境：虚构采集单机" in overview
    assert "3) 用途：固化在虚构采集控制FPGA（DEMO01）产品上，用于实现数据采集、时间标记、安全门控的功能。" in overview
    assert "5) 软件继承性：本产品研制类型为III类，继承基线为虚构基线FPGA V2.00。" in overview
    assert "6) 研制单位：虚构研制所" in overview
    assert "7) 设计流程(A类)：FPGA产品的设计研制过程一般经历以下13个工作阶段：" in overview
    assert "a．任务需求阶段" in overview and "m．验收交付" in overview
    assert "4)" not in overview and "一般特征" not in overview
    assert "待确认" not in overview
    result.append("product-overview-follows-fixed-seven-item-template")

    functions = "\n".join(paragraphs(sections["3.2"], model))
    assert "DEMO01" in functions and "数据采集、时间标记、安全门控" in functions
    assert "以下概述" not in functions and "待确认" not in functions
    result.append("function-overview-keeps-product-usage-summary")

    assert model == original
    result.append("overview-rendering-does-not-mutate-frozen-model")

    product = copy.deepcopy(sections["3.1"])
    product["paragraphs"] = ["<!-- overview-item:general -->",
                             "FPGA产品内部首先生成时标信号，统一各模块协同工作。",
                             "<!-- overview-item:inheritance -->",
                             "本产品在虚构基线FPGA V2.00版本上进行III类更改。"]
    authored = "\n".join(paragraphs(product, model))
    assert "4) 一般特征：FPGA产品内部首先生成时标信号，统一各模块协同工作。" in authored
    assert "5) 软件继承性：本产品在虚构基线FPGA V2.00版本上进行III类更改。" in authored
    assert "overview-item" not in authored
    result.append("agent-narrated-items-placed-into-fixed-template-positions")

    authored_case = copy.deepcopy(sections["3.2"])
    authored_case["paragraphs"] = ["DEMO01负责采集数据，并按已有约束完成时间标记和安全门控。"]
    assert "DEMO01负责采集数据" in "\n".join(paragraphs(authored_case, model))
    result.append("agent-authored-product-summary-preserved")

    authored_case["paragraphs"] = ["本文档用于说明需求条款和编写要求。"]
    try:
        paragraphs(authored_case, model)
    except Failure as exc:
        assert "OVERVIEW_NOT_PRODUCT_SPECIFIC" in str(exc)
    else:
        raise AssertionError("document-purpose boilerplate accepted as FPGA overview")
    result.append("document-purpose-only-paragraph-rejected-as-product-overview")

    annotated = copy.deepcopy(sections["1.2"])
    annotated["paragraphs"] = ["本FPGA位于虚构采集单机。", "任务书未明确该FPGA是否长期开机工作，待确认。"]
    try:
        paragraphs(annotated, model)
    except Failure as exc:
        assert "OVERVIEW_REVIEW_ANNOTATION" in str(exc)
    else:
        raise AssertionError("review annotation accepted in the report body")
    result.append("review-annotations-rejected-in-report-body")

    unmarked = copy.deepcopy(sections["3.1"])
    unmarked["paragraphs"] = ["FPGA产品内部首先生成时标信号。"]
    try:
        paragraphs(unmarked, model)
    except Failure as exc:
        assert "OVERVIEW_ITEM_UNMARKED" in str(exc)
    else:
        raise AssertionError("unmarked narration accepted in 3.1")
    result.append("unmarked-3-1-narration-rejected")

    unknown = copy.deepcopy(seed)
    unknown_sections = {s["number"]: s for v in unknown["document_views"] if v["role"] == "writer_plan" for s in v["sections"]}
    assert "\n".join(paragraphs(unknown_sections["1.1"], unknown)) == ""
    assert "\n".join(terms_table(unknown)).count("\n") == 1
    assert "\n".join(paragraphs(unknown_sections["3.2"], unknown)) == ""
    assert warnings(unknown)
    result.append("missing-overview-facts-reported-not-invented")

    fallback = copy.deepcopy(model)
    fallback["system_overview"]["main_functions"] = fact()
    fallback["analysis"]["functions"] = [{"header": {"name": "源功能一", "status": "present"}, "parent_function_uid": None},
                                         {"header": {"name": "源功能子项", "status": "present"}, "parent_function_uid": "function:root"}]
    summary = "\n".join(paragraphs(sections["3.2"], fallback))
    assert "源功能一" in summary and "源功能子项" not in summary
    result.append("overview-fallback-uses-source-top-level-function-labels")

    md = render(model)
    front = md.split("### 1.1 ", 1)[1].split("### 1.2 ", 1)[0]
    assert "1) 产品名称：虚构采集控制FPGA" in front and "待确认" not in front
    terms_md = md.split("### 1.4 ", 1)[1].split("## 2 ", 1)[0]
    assert "| 名称 | 术语含义 |" in terms_md and "| FPGA |" in terms_md and "NOMEANING" not in terms_md
    overview_md = md.split("### 3.1 ", 1)[1].split("### 3.2 ", 1)[0]
    assert "虚构总体部" in overview_md and "设计流程(A类)" in overview_md and "m．验收交付" in overview_md
    assert "待确认" not in overview_md and "TEST-PREQ-1" not in overview_md
    result.append("rendered-front-matter-is-formal-report-body")
    return result
