"""HDL choice, verbatim branch copy, and frozen-template regression tests."""
import copy

from .base import Failure, digest, fact, save, text
from .programming_template import body, frozen, read, selection, warnings
from .render import render


def run_tests(seed, root):
    path = root / "synthetic-programming-template.md"
    source = "# 用户说明，不应进入报告\n\n## VHDL\n\nVHDL_ONLY：用户固定条款。\n\n## Verilog\n\nVERILOG_ONLY：{{自定义字段}}不自动替换。\n"
    text(path, source)
    templates = read(path)
    model = copy.deepcopy(seed)
    req = model["requirements"][0]
    req["category"] = "language"
    req["revisions"][0]["semantic"]["statement"] = "本项目采用Verilog-2001，归档工具选项。"
    assert selection(model)[0] == "Verilog"
    md = render(model, language_templates=templates)
    section = md.split("#### 5.1.3 ", 1)[1].split("#### 5.1.4 ", 1)[0]
    assert section.count(templates["Verilog"]) == 1
    assert "VHDL_ONLY" not in section and "用户说明" not in section and "{{自定义字段}}" in section
    results = ["verilog-version-selects-verilog-branch-and-copies-user-body-verbatim"]

    structured = copy.deepcopy(seed)
    structured["analysis"]["platform_resources"] = [{"kind": "language", "header": {"status": "present"}, "model": fact("VHDL-2008")}]
    assert selection(structured)[0] == "VHDL" and body(structured, templates) == templates["VHDL"]
    results.append("explicit-structured-project-language-selects-vhdl-branch")

    req["revisions"][0]["semantic"]["statement"] = "使用VHDL或Verilog。"
    assert selection(model)[0] is None and warnings(model, templates)
    assert "待确认" in body(model, templates) and "VHDL_ONLY" not in body(model, templates)
    unsupported = copy.deepcopy(structured)
    unsupported["analysis"]["platform_resources"][0]["model"] = fact("SystemVerilog")
    assert selection(unsupported)[0] is None
    results.append("ambiguous-and-systemverilog-project-language-not-guessed")

    req["revisions"][0]["semantic"]["statement"] = "禁止使用VHDL；本项目采用Verilog-2001；测试平台使用VHDL。"
    assert selection(model)[0] == "Verilog"
    req["revisions"][0]["semantic"]["statement"] = "禁止使用VHDL。"
    assert selection(model)[0] is None
    req["revisions"][0]["semantic"]["statement"] = "使用VHDL。"
    req["lifecycle"] = "deleted_approved"
    req["effective_revision_uid"] = None
    assert selection(model)[0] is None
    results.append("negative-testbench-and-deleted-statements-do-not-select-project-language")

    configured = dict(templates)
    configured["Verilog"] = "【请配置：Verilog条款】"
    assert not warnings(structured, configured)
    configured["VHDL"] = "【请配置：VHDL条款】"
    assert warnings(structured, configured)
    results.append("only-selected-hdl-branch-placeholder-is-a-project-pending-item")

    text(path, "## VHDL\nA\n## VHDL\nB\n## Verilog\nC\n")
    try:
        read(path)
    except Failure as exc:
        assert "DUPLICATE_BRANCH" in str(exc)
    else:
        raise AssertionError("duplicate language branch accepted")
    text(path, "## VHDL\nA\n")
    try:
        read(path)
    except Failure as exc:
        assert "BRANCH_MISSING" in str(exc)
    else:
        raise AssertionError("missing language branch accepted")
    results.append("missing-and-duplicate-language-branches-rejected")

    folder = root / "programming-snapshot-test/inputs/programming_template"
    folder.mkdir(parents=True)
    target = folder / "5.1.3_编程及验收性模板.md"
    text(target, source)
    save(folder / "manifest.json", {"contract": "reqspec-programming-template/1.0", "file": target.name, "sha256": digest(target)})
    assert frozen(folder.parents[1]) == templates
    text(target, "changed")
    try:
        frozen(folder.parents[1])
    except Failure as exc:
        assert "SNAPSHOT_CHANGED" in str(exc)
    else:
        raise AssertionError("changed language template snapshot accepted")
    results.append("programming-template-snapshot-hash-validated")
    return results
