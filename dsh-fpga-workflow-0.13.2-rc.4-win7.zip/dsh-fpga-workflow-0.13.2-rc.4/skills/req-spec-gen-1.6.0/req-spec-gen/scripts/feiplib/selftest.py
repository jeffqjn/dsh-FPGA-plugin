"""Meaningful deterministic checks in a temporary directory, no LLM or network."""
import copy
import tempfile
import zipfile
from pathlib import Path

from . import contract
from .base import SKILL, Failure, digest, load, now, save, text, verify_package
from .checks import assessments, merge_previous, revision_checks
from .extract import extract
from .prepare import prepare
from .workflow import compare, finalize, generate, review

def agent_source(attempt):
    model = load(Path(attempt) / "model.template.json")
    model["protocol"]["synthetic"] = True
    model["meta"]["title"] = "自测需求规格说明（虚构）"
    ev = model["consistency"]["evidence"][0]["uid"]
    semantic = {"statement": "有效命令响应时间不大于10 ms。", "subject": "FPGA", "action": "响应", "object": "有效命令", "condition": None,
        "input_refs": [], "output_refs": [], "processing_rules": [], "exceptions": [], "constraint_refs": ["constraint:latency10"],
        "verification_methods": ["simulation"], "safety_critical": False, "attributes": [], "evidence_refs": [ev]}
    model["source_baseline"]["parents"] = [{"uid": "parent:ur1", "source_id": "UR-1", "generated_id": False, "title": "响应时间", "category": "performance", "raw_text": semantic["statement"], "evidence_refs": [ev]}]
    model["source_baseline"]["atomic_requirements"] = [{"uid": "atom:ur101", "source_id": "UR-1-01", "parent_uid": "parent:ur1", "category": "performance", "semantic": semantic, "evidence_refs": [ev]}]
    model["requirements"] = [{"uid": "req:latency", "normalized_id": "TEST-PREQ-1", "title": "响应时间", "category": "performance", "source_parent_refs": ["parent:ur1"], "source_atomic_refs": ["atom:ur101"],
        "revisions": [{"uid": "rev:source", "ordinal": 1, "basis": "source", "semantic": semantic, "supersedes_revision_uid": None, "decision_refs": [], "created_at": now()}], "effective_revision_uid": "rev:source", "lifecycle": "active",
        "spec_item_refs": [], "analysis_refs": [], "source_alignment": "unmapped", "effective_alignment": "unmapped", "issue_refs": [], "decision_refs": [], "waiver_refs": []}]
    model["analysis"]["constraints"] = [{"uid": "constraint:latency10", "parameter": "latency", "operator": "le", "raw_text": "不大于10 ms", "value": {"kind": "quantity", "decimal": "10", "unit": "ms", "dimension": "time"},
        "normalized": None, "normalization_basis": None, "tolerance": None, "applies_to": [{"kind": "requirement", "uid": "req:latency", "revision_uid": "rev:source"}], "when": None, "evidence_refs": [ev]}]
    tp_ev = next(e["uid"] for e in model["consistency"]["evidence"] if "TP-A-001" in e["quote"])
    model["verification"]["source_test_points"] = [{"uid": "testpoint:tp1", "source_id": "TP-A-001", "title": "响应时间", "requirement_refs": ["req:latency"], "scenario_types": ["normal"], "object": "FPGA", "purpose": "响应时间", "preconditions": [],
        "stimulus": "发送有效命令", "procedure": "测量响应时间", "expected_result": "不大于10 ms", "pass_criteria": "<=10ms", "completeness": "complete", "missing_fields": [], "evidence_refs": [tp_ev]}]
    model["source_baseline"]["test_point_refs"] = ["testpoint:tp1"]
    for entry in model["completeness"]["content_inventory"]:
        entry.update(disposition="modeled", normative=True, object_refs=[{"kind": "atom", "uid": "atom:ur101", "revision_uid": None}], reason="自测示例义务")
    structure = load(SKILL / "templates/document_structure.json")
    plan = {"uid": "documentview:writer", "role": "writer_plan", "template_artifact_uid": None, "document_artifact_uid": None, "sections": []}
    for number in structure["required_sections"]:
        from .writer_tables import policy as section_policy
        policy = section_policy(number, model)
        plan["sections"].append({"uid": "sectionview:s" + number, "number": number, "title": structure["titles"][number], "status": "present", "handling": policy, "reason": None,
            "primary_requirement_refs": ["req:latency"] if number == "5.4" else [], "cross_requirement_refs": [], "spec_item_refs": [], "object_refs": [], "material_element_refs": [], "paragraphs": [],
            "tables": [{"uid": "tableview:" + t["id"], "caption": t["caption"], "columns": t["columns"], "row_object_refs": [], "evidence_refs": []} for t in structure["tables"] if t["section"] == number]})
    model["document_views"] = [plan]
    for ext in model["extensions"]:
        if ext["namespace"] == "feip.assessments.v1":
            for row in ext["payload"]["rules"]:
                row.update(status="pass", rationale="虚构自测预先给定的语义判断，不代表真实任务书验收", evidence_refs=[ev])
    return model

def self_test():
    results = []
    def rejects(name, function):
        try:
            function()
        except (ValueError, KeyError, OSError):
            results.append(name)
        else:
            raise AssertionError("negative case accepted: " + name)
    with tempfile.TemporaryDirectory(prefix="feip-selftest-") as name:
        root = Path(name)
        source = root / "任务书.txt"
        text(source, "UR-1 有效命令响应时间不大于10 ms。\nTP-A-001 发送有效命令，测量响应时间，<=10ms通过。\n")
        prep = prepare("taskbook", root / "input", source)
        attempt = Path(prep["attempt"])
        agent = agent_source(attempt)
        from .table_selftest import run_tests
        results.extend(run_tests(agent))
        from .overview_selftest import run_tests as overview_tests
        results.extend(overview_tests(agent))
        from .fixed_selftest import run_tests as fixed_tests
        results.extend(fixed_tests(agent, root))
        from .device_selftest import run_tests as device_tests
        results.extend(device_tests(agent, root))
        from .programming_selftest import run_tests as programming_tests
        results.extend(programming_tests(agent, root))
        from .interface_selftest import run_tests as interface_tests
        results.extend(interface_tests(agent))
        from .source_test_points_selftest import run_tests as source_point_tests
        results.extend(source_point_tests(agent))
        from .assurance_selftest import run_tests as assurance_tests
        results.extend(assurance_tests(agent))
        from .docx_selftest import run_tests as docx_tests
        results.extend(docx_tests(agent, root))
        from .template_selftest import run_tests as template_tests
        results.extend(template_tests(agent))
        agent_file = root / "agent.json"
        save(agent_file, agent)
        source_pkg = root / "source-package"
        review(attempt, agent_file, source_pkg)
        verify_package(source_pkg)
        results.append("taskbook-native-feip-package")
        rejects("existing-output-never-overwritten", lambda: review(attempt, agent_file, source_pkg))
        writer_prep = prepare("writer", root / "writer", baseline=source_pkg)
        writer_model = load(Path(writer_prep["template"]))
        writer_file = root / "writer-agent.json"
        save(writer_file, writer_model)
        writer_pkg = root / "writer-package"
        generate(writer_prep["attempt"], writer_file, writer_pkg)
        md = (writer_pkg / "需求规格说明.md").read_text(encoding="utf-8")
        assert "不大于10 ms" in md and "7.3.4" in md and "人工填写" in md and "A.2" in md
        results.append("writer-complete-md-and-trace")
        from . import fixed_sections
        from . import device_resources
        from . import programming_template
        previous_config = fixed_sections.CONFIG_DIR
        previous_catalog = device_resources.CATALOG_PATH
        previous_language_template = programming_template.TEMPLATE_PATH
        try:
            fixed_sections.CONFIG_DIR = root / "installation-config-not-available"
            device_resources.CATALOG_PATH = root / "installation-device-catalog-not-available.md"
            programming_template.TEMPLATE_PATH = root / "installation-language-template-not-available.md"
            verify_package(writer_pkg)
        finally:
            fixed_sections.CONFIG_DIR = previous_config
            device_resources.CATALOG_PATH = previous_catalog
            programming_template.TEMPLATE_PATH = previous_language_template
        results.append("delivered-package-validation-uses-snapshot-not-current-installed-config")
        # Rehashing a malformed report must not bypass model/render validation.
        manifest_file = writer_pkg / "package.json"
        manifest_bytes = manifest_file.read_bytes()
        markdown_file = writer_pkg / "需求规格说明.md"
        markdown_bytes = markdown_file.read_bytes()
        text(markdown_file, md + "\n| 信号名称 | 信号方向 |\n| --- | --- |\n")
        manifest = load(manifest_file)
        entry = next(a for a in manifest["artifacts"] if a["path"] == "需求规格说明.md")
        entry.update(sha256=digest(markdown_file), size_bytes=markdown_file.stat().st_size)
        save(manifest_file, manifest)
        rejects("rehashing-duplicate-empty-table-cannot-bypass-validation", lambda: verify_package(writer_pkg))
        markdown_file.write_bytes(markdown_bytes)
        manifest_file.write_bytes(manifest_bytes)
        verify_package(writer_pkg)
        spec = root / "完整需求.txt"
        text(spec, "5.4 性能需求\nTEST-PREQ-1 有效命令响应时间不大于10 ms。\n")
        check_prep = prepare("checker", root / "checker", spec, source_pkg)
        check_model = load(Path(check_prep["template"]))
        spec_archive = next(a for a in check_model["document_archive"] if a["role"] == "specification")
        paragraph = spec_archive["elements"][-1]
        check_model["spec_items"] = [{"uid": "item:latency", "display_id": "TEST-PREQ-1", "section_uid": paragraph["section_uid"], "source_atomic_refs": ["atom:ur101"],
            "semantic": copy.deepcopy(check_model["requirements"][0]["revisions"][0]["semantic"]), "element_refs": [paragraph["uid"]], "issue_refs": [], "decision_refs": []}]
        check_model["requirements"][0].update(spec_item_refs=["item:latency"], source_alignment="complete", effective_alignment="complete")
        check_model["traceability"]["mappings"] = [{"uid": "mapping:one", "source_atomic_uid": "atom:ur101", "requirement_uid": "req:latency", "spec_item_refs": ["item:latency"], "status": "complete",
            "constraint_refs": ["constraint:latency10"], "uncovered_aspects": [], "evidence_refs": check_model["spec_items"][0]["semantic"]["evidence_refs"], "decision_refs": [], "matched_by": "semantic"}]
        for entry in check_model["completeness"]["content_inventory"]:
            if entry["disposition"] == "pending":
                entry.update(disposition="modeled", normative=True, object_refs=[{"kind": "spec_item", "uid": "item:latency", "revision_uid": None}], reason="自测文档落点")
        ev = check_model["consistency"]["evidence"][-1]["uid"]
        for ext in check_model["extensions"]:
            if ext["namespace"] == "feip.assessments.v1" and ext["payload"]["stage"] == "checker":
                for row in ext["payload"]["rules"]:
                    row.update(status="pass", rationale="虚构自测语义预置", evidence_refs=[ev])
        check_file = root / "checker-agent.json"
        save(check_file, check_model)
        round_dir = root / "round1"
        compared = compare(check_prep["attempt"], check_file, round_dir)
        assert compared["delivery_state"] == "AWAITING_FINAL_CONFIRMATION"
        assert not (round_dir / "reqspec.json").exists()
        results.append("checker-closes-without-premature-release")
        confirmation = root / "confirmation.json"
        save(confirmation, {"kind": "approve_release", "candidate_uid": compared["candidate_uid"], "candidate_manifest_sha256": compared["candidate_manifest_sha256"],
            "actor": "虚构自测用户", "confirmed_at": now(), "user_quote": "虚构测试：确认当前候选并生成最终JSON。"})
        released = root / "release"
        finalize(round_dir, confirmation, released)
        final_model, _ = verify_package(released)
        assert final_model["protocol"]["profile"] == "reqspec-reviewed" and (released / "reqspec.json").exists()
        results.append("confirmed-final-json-release")
        bad_confirm = root / "wrong-confirmation.json"
        changed = load(confirmation)
        changed["candidate_manifest_sha256"] = "0" * 64
        save(bad_confirm, changed)
        rejects("confirmation-wrong-candidate", lambda: finalize(round_dir, bad_confirm, root / "badrelease"))
        original = spec.read_bytes()
        text(spec, "changed after confirmation")
        rejects("input-change-invalidates-confirmation", lambda: finalize(round_dir, confirmation, root / "badrelease2"))
        spec.write_bytes(original)
        altered_path = round_dir / "candidate_payload.json"
        original = altered_path.read_bytes()
        altered_path.write_bytes(original + b"\n")
        rejects("candidate-byte-change-rejected", lambda: finalize(round_dir, confirmation, root / "badrelease3"))
        altered_path.write_bytes(original)
        rejects("unsafe-package-path", lambda: contract.safe_artifact(root, "../outside"))
        rejects("duplicate-json-keys", lambda: contract.object_pairs([("x", 1), ("x", 2)]))
        # DOCX parser must traverse content controls and retain merged-table metadata.
        docx = root / "test.docx"
        xml = '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:sdt><w:sdtContent><w:p><w:r><w:t>inside content control</w:t></w:r></w:p></w:sdtContent></w:sdt><w:tbl><w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr><w:p><w:r><w:t>merged</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:p><w:del><w:r><w:delText>old requirement</w:delText></w:r></w:del></w:p></w:body></w:document>'
        with zipfile.ZipFile(str(docx), "w") as z:
            z.writestr("word/document.xml", xml)
        archived = extract(docx, "specification", "artifact:test")
        assert any(e["text"] == "inside content control" for e in archived["elements"])
        assert next(e for e in archived["elements"] if e["kind"] == "table")["cells"][0]["column_span"] == 2
        assert archived["extraction_status"] == "partial"
        results.append("docx-content-control-merge-and-tracked-change")
        # Core model rejects missing source atom retention, including waived requirements.
        invalid = copy.deepcopy(final_model)
        invalid["requirements"] = []
        artifact_ids = [a["uid"] for a in load(released / "package.json")["artifacts"]]
        assert contract.semantic_checks(invalid, artifact_ids)
        results.append("source-retention-negative")
        unknown = copy.deepcopy(agent)
        unknown["extensions"][0]["payload"]["rules"][0].update(status="unknown", issue_refs=[])
        rejects("unknown-rule-cannot-silently-pass", lambda: assessments(unknown, "taskbook"))
        # Validate actual add/modify/delete revision invariants, without forging a user session.
        trial = copy.deepcopy(agent)
        before = copy.deepcopy(trial["requirements"][0]["revisions"][0]["semantic"])
        after = copy.deepcopy(before)
        after.update(statement="有效命令响应时间不大于20 ms。", constraint_refs=["constraint:latency20"])
        c20 = copy.deepcopy(trial["analysis"]["constraints"][0])
        c20.update(uid="constraint:latency20", raw_text="不大于20 ms", value={"kind": "quantity", "decimal": "20", "unit": "ms", "dimension": "time"})
        trial["analysis"]["constraints"].append(c20)
        change = {"uid": "decision:modify", "status": "active", "kind": "approve_change", "operation": "modify", "object_refs": [{"kind": "requirement", "uid": "req:latency", "revision_uid": None}], "before": before, "after": after}
        trial["consistency"]["decisions"] = [change]
        r = trial["requirements"][0]
        r["revisions"].append({"uid": "rev:modified", "ordinal": 2, "basis": "approved_change", "semantic": after, "supersedes_revision_uid": "rev:source", "decision_refs": ["decision:modify"], "created_at": now()})
        r["effective_revision_uid"] = "rev:modified"
        revision_checks(trial)
        assert trial["source_baseline"]["atomic_requirements"][0]["semantic"] == before
        results.append("approved-modify-preserves-b0")
        bad_before = copy.deepcopy(trial)
        bad_before["consistency"]["decisions"][0]["before"] = after
        rejects("modify-wrong-before-rejected", lambda: revision_checks(bad_before))
        add_model = copy.deepcopy(trial)
        added = copy.deepcopy(add_model["requirements"][0])
        added.update(uid="req:new", normalized_id="TEST-PREQ-2", source_parent_refs=[], source_atomic_refs=[],
            revisions=[{"uid": "rev:added", "ordinal": 1, "basis": "approved_change", "semantic": after, "supersedes_revision_uid": None, "decision_refs": ["decision:add"], "created_at": now()}], effective_revision_uid="rev:added")
        add_model["requirements"].append(added)
        add_model["consistency"]["decisions"].append(dict(change, uid="decision:add", operation="add", object_refs=[{"kind": "requirement", "uid": "req:new", "revision_uid": None}], before=None))
        revision_checks(add_model)
        results.append("approved-add-independent-engineering-identity")
        delete_model = copy.deepcopy(trial)
        delete_model["consistency"]["decisions"].append(dict(change, uid="decision:delete", operation="delete", before=after, after=None))
        delete_model["requirements"][0].update(lifecycle="deleted_approved", effective_revision_uid=None, decision_refs=["decision:delete"])
        revision_checks(delete_model)
        assert delete_model["requirements"][0]["revisions"][0]["semantic"] == before
        results.append("approved-delete-retains-source-history")
        # Stable issue identity survives changed evidence and reopens stale waivers.
        history_dir = root / "history-attempt/inputs"
        history_dir.mkdir(parents=True)
        prior_issue = {"uid": "issue:stable", "display_id": "IS-001", "stable_key": "REQ-002|req:latency|latency", "status": "ignored", "evidence_fingerprint": "a" * 64,
            "history": [], "decision_refs": [], "first_seen_round": 1, "last_seen_round": 1}
        save(history_dir / "previous_state.json", {"baseline_uid": trial["protocol"]["baseline_uid"], "round": 1, "issues": [prior_issue]})
        current = copy.deepcopy(trial)
        current["consistency"]["issues"] = [dict(prior_issue, evidence_fingerprint="b" * 64)]
        merge_previous(current, history_dir.parent)
        assert current["consistency"]["issues"][0]["uid"] == "issue:stable" and current["consistency"]["issues"][0]["status"] == "open"
        results.append("changed-evidence-reopens-stable-issue")
    return {"tests": len(results), "passed": results, "synthetic": True, "scope": "deterministic helpers; Agent semantics and Win7/PS2 host need acceptance"}
