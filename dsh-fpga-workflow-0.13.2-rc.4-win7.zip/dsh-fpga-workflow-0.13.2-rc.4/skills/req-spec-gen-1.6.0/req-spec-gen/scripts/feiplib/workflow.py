"""Agent-assisted taskbook review, Markdown writing and reviewed release."""
import argparse
import copy
import platform
import shutil
import sys
from pathlib import Path

from . import contract
from .base import SKILL, SCHEMAS, VERSION, check_model, digest, effective, gate, known_artifacts, load, now, publish, require, save, text, uid, verify_inputs, verify_package
from .checks import checker_quality, ensure_frozen, merge_previous, report, revision_checks, source_quality, state
from .extract import extract
from .prepare import prepare
from .render import display, render
from . import icd

KINDS = {"task-validation": "taskbook", "req-spec-gen": "writer", "req-spec-consistency-check": "checker"}

def runtime_fingerprint():
    paths = [p for p in (SKILL / "scripts").rglob("*") if p.suffix in (".py", ".js", ".ps1")] + list(SCHEMAS.rglob("*.json")) + list((SKILL / "templates").glob("*.json")) + list((SKILL / "references").rglob("*.md")) + [SKILL / "SKILL.md"]
    return {p.relative_to(SKILL).as_posix(): digest(p) for p in paths if "__pycache__" not in p.parts}

def accept_model(attempt, filename):
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    model = load(filename)
    # Shape first, so failed Agent output cannot crash a semantic check halfway.
    from .base import schema_model
    schema_model(model)
    ensure_frozen(model, attempt, info)
    revision_checks(model)
    submitted = attempt / "inputs/agent_model.json"
    require(not submitted.exists(), "ATTEMPT_ALREADY_CONSUMED: prepare a fresh attempt")
    submitted.parent.mkdir(exist_ok=True)
    shutil.copyfile(str(filename), str(submitted))
    info["input_bindings"].append({"path": "inputs/agent_model.json", "sha256": digest(submitted)})
    info["original_inputs"].append({"path": str(Path(filename).resolve()), "sha256": digest(filename)})
    save(attempt / "attempt.json", info)
    return model, info

def review(attempt, filename, output):
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "taskbook" and model["protocol"]["profile"] == "taskbook-reviewed", "REVIEW_PROFILE_INVALID")
    effective(model)
    source_quality(model)
    check_model(model, known_artifacts(attempt))
    from .requirement_list import FILENAME, render as render_requirement_list
    result = publish(output, model, attempt, known_artifacts(attempt), {"taskbook_review.md": report(model, "任务书完备性审查报告"), FILENAME: render_requirement_list(model)})
    result["requirement_list_path"] = str(Path(output) / FILENAME)
    return result

def generation_state(model, fixed_content=None, device_catalog=None, language_templates=None):
    from .template_layout import is_verification_group, warnings as template_warnings
    from .fixed_sections import FILES, read as read_fixed, warnings as fixed_warnings
    fixed_content = read_fixed() if fixed_content is None else fixed_content
    from . import device_resources
    device_catalog = device_resources.read() if device_catalog is None else device_catalog
    from . import programming_template
    language_templates = programming_template.read() if language_templates is None else language_templates
    if model["consistency"]["gates"]["overall"] == "FAIL":
        return "BLOCKED"
    unknown = any(f["status"] in ("missing", "unknown") for f in model["basic_info"].values())
    unknown = unknown or any(isinstance(f, dict) and f.get("status") in ("missing", "unknown") for f in model["meta"].values())
    unknown = unknown or any(
        s["handling"] == "auto" and s["number"] not in FILES and s["number"] not in ("5.1.1", "5.1.3")
        and not is_verification_group(model, s["number"]) and s["status"] in ("missing", "unknown")
        for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"]
    )
    pending = bool(model["completeness"]["gaps"]) or any(i["status"] == "open" for i in model["consistency"]["issues"])
    from .writer_tables import warnings as table_warnings
    from .writer_overview import warnings as overview_warnings
    from .interface_layout import warnings as interface_warnings
    from .source_test_points import warnings as test_point_warnings
    from .assurance import warnings as assurance_warnings
    return "DRAFT" if unknown or pending or fixed_warnings(fixed_content) or device_resources.warnings(model, device_catalog) or programming_template.warnings(model, language_templates) or table_warnings(model) or overview_warnings(model) or interface_warnings(model) or test_point_warnings(model) or template_warnings(model) or assurance_warnings(model) or model["source_baseline"]["status"] != "PASS" else "READY_FOR_REVIEW"

def generate(attempt, filename, output):
    from .docx_writer import dependencies, build
    docx_dependencies = dependencies()
    from .fixed_sections import freeze, warnings as fixed_warnings
    fixed_content = freeze(attempt)
    from . import device_resources
    device_catalog = device_resources.freeze(attempt)
    from . import programming_template
    language_templates = programming_template.freeze(attempt)
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "writer", "GENERATE_REQUIRES_WRITER_ATTEMPT")
    model["protocol"].update(profile="reqspec-draft", producer="req-spec-gen", producer_version=VERSION)
    effective(model)
    gate(model)
    # Upstream NEEDS_CLARIFICATION remains a draft, never promoted silently.
    model["consistency"]["gates"]["generation_state"] = generation_state(model, fixed_content, device_catalog, language_templates)
    require(model["consistency"]["gates"]["generation_state"] != "BLOCKED", "GENERATION_BLOCKED: resolve blocking baseline/content issues")
    check_model(model, known_artifacts(attempt))
    markdown = render(model, fixed_content, device_catalog, language_templates)
    from .writer_tables import warnings as table_warnings
    notes = table_warnings(model)
    table_report = "\n## 表格填充检查\n\n" + ("\n".join("- " + n for n in notes) if notes else "表格绑定检查通过；约定暂缓、人工及可选空表按范围保留。") + "\n"
    from .writer_overview import warnings as overview_warnings
    overview_notes = overview_warnings(model)
    table_report += "\n## 前言与概述检查\n\n1.1按冻结基本信息分点列出，1.4按冻结acronyms生成“名称｜术语含义”两列表格，1.2/3.1/3.2按冻结事实或Agent有来源的总结生成正式报告正文；缺口只登记于本报告并保持DRAFT，正文不含“待确认”等审阅注记。\n\n" + ("\n".join("- " + n for n in overview_notes) if overview_notes else "1.1、1.2、1.4、3.1、3.2素材齐全，未发现缺项；内容仍需语义审阅。") + "\n"
    fixed_notes = fixed_warnings(fixed_content)
    table_report += "\n## 固定内容配置\n\n1.3、2.1、2.2直接复制预配置MD正文，未做改写、变量替换或另行补表。本次副本与摘要保存于inputs/fixed_sections/。\n\n" + ("\n".join("- " + n for n in fixed_notes) if fixed_notes else "三个固定配置已读取，未发现示例配置占位。") + "\n"
    device_notes = device_resources.warnings(model, device_catalog)
    table_report += "\n## 器件资源配置\n\n任务选型：" + (device_resources.selected_model(model) or "待确认") + "。按完整型号精确匹配用户配置的器件资源库，未自动推定封装、速度/质量等级或资源数。本次资源库及摘要保存于inputs/device_resources/。在轨维护及不满足项措施按用户配置展示，仍须核对其对本任务的适用性，不改写原需求。\n\n" + ("\n".join("- " + n for n in device_notes) if device_notes else "已匹配一个器件条目，八项配置已填写。") + "\n"
    language_notes = programming_template.warnings(model, language_templates)
    table_report += "\n## 编程及验收性模板\n\n选用语言：" + (programming_template.selection(model)[0] or "待确认") + "。复制对应用户模板正文，不改写、不替换变量；源需求主条款保持。本次模板副本及摘要保存于inputs/programming_template/。\n\n" + ("\n".join("- " + n for n in language_notes) if language_notes else "已选中唯一语言分支，未发现该分支的配置占位。") + "\n"
    from .interface_layout import warnings as interface_warnings
    interface_notes = interface_warnings(model)
    table_report += "\n## 接口章节组织\n\n各5.2.x按接口定义、接口时序、接口可编程要求组织；信号表归接口定义，地址/寄存器表归可编程要求。归类只调整位置，原条款和数值保持。\n\n" + ("\n".join("- " + n for n in interface_notes) if interface_notes else "三个部分已按现有来源组织；具体语义分类仍需审阅。") + "\n"
    from .source_test_points import warnings as test_point_warnings
    test_notes = test_point_warnings(model)
    table_report += "\n## 测试要点原文复制\n\n7.1测试要点直接复制同一交接包内源测试要点关联的完整归档段落或表格行。表7.1-1保留源标识和对应需求编号。\n\n" + ("\n".join("- " + n for n in test_notes) if test_notes else "源测试要点已全部填入表7.1-1，测试执行与结论仍以验证记录为依据。") + "\n"
    from .template_layout import warnings as template_warnings, follows_function_example, review_rows
    layout_notes = template_warnings(model)
    table_report += "\n## 1-52模板检查\n\n功能单元对应任务书功能父项，复杂功能按技术职责细分。仿真验证和板级确认按各节列出适用证据与缺项。\n\n" + ("\n".join("- " + n for n in layout_notes) if layout_notes else "当前结构未发现功能字段和验证章节缺项。") + "\n"
    from .assurance import checklist as assurance_checklist, counts as assurance_counts, warnings as assurance_warnings
    assurance = assurance_checklist()
    tally = assurance_counts(model)
    assessment_notes = assurance_warnings(model)
    table_report += ("\n## 附录C/D技术要素检查表\n\n"
                     "附录C、附录D按1-52模板固定技术要素清单逐行生成；要素行不随项目裁剪，也不由Agent改写。"
                     "表C-1共" + str(len(assurance["C"]["rows"])) + "项、表D-1共" + str(len(assurance["D"]["rows"])) + "项检查项。"
                     "“检查项”“落实文件”取自模板；“是否适用”“是否符合”“检查结果”由执行Agent按冻结交接包逐项判定并列出所在章节。\n\n"
                     "判定统计：适用" + str(tally["适用"]) + "项（符合" + str(tally["符合"]) + "、不符合" + str(tally["不符合"])
                     + "、待确认" + str(tally["待确认"]) + "），不适用" + str(tally["不适用"]) + "项，不涉及"
                     + str(tally["不涉及"]) + "项，未提交" + str(tally["未提交"]) + "项。"
                     "“配置项级软件产品保证工程师验证结果”列保持空白，由配置项级产保工程师签署；签署不改变已冻结的技术义务。\n\n"
                     + ("\n".join("- " + note for note in assessment_notes) if assessment_notes else "全部检查项均已判定并列出所在章节。") + "\n")
    if follows_function_example(model):
        from .render import escape
        rows = list(review_rows(model))
        if rows:
            table_report += ("\n## 功能分解待设计师审阅\n\n"
                             "编制时已依据任务书和冻结条款提出分解。请核对各单元的职责边界、输入与输出、触发与异常条件，以及条款归属。"
                             "图5.3-1展示产品包含的功能单元。各单元的处理关系见正文，接口和数据流图仍需以确认的连接资料为依据。\n\n"
                             "| 任务书功能项 | 待审阅的末级功能 | 主落点需求编号 |\n"
                             "| --- | --- | --- |\n")
            table_report += "".join("| " + " | ".join(escape(value) for value in row) + " |\n" for row in rows)
    table_report += '\n## Word投影检查\n\n使用python-docx生成DOCX，正文、表格与MD使用同一冻结模型；validate对DOCX全部OOXML部件重新装配核对。宽表使用横向页，重复表头。原子表格按同包完整原文精确还原；测试表缺行号时仅允许源编号与测试对象双重精确唯一匹配。机器UID保留在FEIP中，正文使用名称及正式编号。\n'
    result = publish(output, model, attempt, known_artifacts(attempt), {"需求规格说明.md": markdown, '需求规格说明.docx': build(markdown, model),
        'docx_projection.json': {'version': VERSION, 'dependencies': docx_dependencies}, "生成检查报告.md": report(model, "需求规格说明生成检查") + table_report})
    result['docx_path'] = str(Path(output) / '需求规格说明.docx')
    result["generation_state"] = model["consistency"]["gates"]["generation_state"]
    return result

def compare(attempt, filename, output):
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "checker", "COMPARE_REQUIRES_CHECKER_ATTEMPT")
    model["protocol"].update(profile="reqspec-draft", producer="req-spec-consistency-check")
    merge_previous(model, attempt)
    effective(model)
    checker_quality(model)
    revision_checks(model)
    closed = model["consistency"]["gates"]["overall"] == "PASS" and model["source_baseline"]["status"] == "PASS" and not any(i["status"] == "open" for i in model["consistency"]["issues"]) and not any(t["required"] and t["status"] != "closed" for t in model["consistency"]["todos"])
    model["consistency"]["gates"]["delivery_state"] = "AWAITING_FINAL_CONFIRMATION" if closed else "REVIEWING"
    check_model(model, known_artifacts(attempt))
    attempt = Path(attempt)
    save(attempt / "review_state.json", state(model))
    text(attempt / "review_report.md", report(model, "需求规格说明一致性检查报告"))
    if closed:
        candidate_uid = uid("candidate")
        save(attempt / "candidate_payload.json", model)
        save(attempt / "icd.json", icd.build(model, "candidate", candidate_uid))
        save(attempt / "runtime_fingerprint.json", runtime_fingerprint())
        packet = report(model, "最终生成确认审阅包") + "\n候选ID：`" + candidate_uid + "`\n\n请审阅candidate_payload.json及icd.json中的完整台账、接口、管脚、缺口、例外和下游可用性，再明确确认是否发布该候选的reqspec.json与icd.json。两文件共享本次候选确认；单项问题确认不代替最终确认。\n"
        text(attempt / "review_packet.md", packet)
        bindings = [{"path": p.relative_to(attempt).as_posix(), "sha256": digest(p)} for p in sorted(attempt.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
        save(attempt / "candidate_manifest.json", {"contract": "feip-candidate/1.0", "candidate_uid": candidate_uid, "created_at": now(),
            "baseline_uid": model["protocol"]["baseline_uid"], "bindings": bindings})
    else:
        save(attempt / "icd.json", icd.build(model, "draft"))
    result = publish(output, model, attempt, known_artifacts(attempt))
    result["delivery_state"] = model["consistency"]["gates"]["delivery_state"]
    result["icd_path"] = str(Path(output) / "icd.json")
    if closed:
        result["candidate_manifest_sha256"] = digest(Path(output) / "candidate_manifest.json")
        result["candidate_uid"] = candidate_uid
    return result

def finalize(candidate, confirmation_file, output):
    candidate = Path(candidate)
    verify_package(candidate)
    verify_inputs(candidate)
    manifest = load(candidate / "candidate_manifest.json")
    for binding in manifest["bindings"]:
        path = contract.safe_artifact(candidate, binding["path"])
        require(path.is_file() and digest(path) == binding["sha256"], "CANDIDATE_CHANGED: " + binding["path"])
    require(runtime_fingerprint() == load(candidate / "runtime_fingerprint.json"), "RULES_OR_SCHEMA_CHANGED: recheck and request a new candidate confirmation")
    confirmation = load(confirmation_file)
    require(confirmation.get("kind") == "approve_release" and confirmation.get("candidate_uid") == manifest["candidate_uid"], "FINAL_CONFIRMATION_REQUIRED")
    require(confirmation.get("candidate_manifest_sha256") == digest(candidate / "candidate_manifest.json"), "CONFIRMATION_CANDIDATE_DIGEST_MISMATCH")
    require(all(isinstance(confirmation.get(k), str) and confirmation[k].strip() for k in ("actor", "confirmed_at", "user_quote")), "CONFIRMATION_INCOMPLETE")
    model = load(candidate / "candidate_payload.json")
    require(model["consistency"]["gates"]["delivery_state"] == "AWAITING_FINAL_CONFIRMATION", "CANDIDATE_NOT_CLOSED")
    checker_quality(model)
    require(model["consistency"]["gates"]["overall"] == "PASS" and not any(i["status"] == "open" for i in model["consistency"]["issues"]), "FINALIZE_NOT_CLOSED")
    # Stage new publication metadata separately. Never modify the accepted round.
    import tempfile
    with tempfile.TemporaryDirectory(prefix="feip-finalize-") as temp_name:
        stage = Path(temp_name) / "candidate"
        shutil.copytree(str(candidate), str(stage))
        # Retain the exact ICD bytes covered by the user's candidate confirmation.
        shutil.copyfile(str(candidate / "icd.json"), str(stage / "candidate_icd.json"))
        confirmation_path = stage / "release_confirmation.json"
        shutil.copyfile(str(confirmation_file), str(confirmation_path))
        known = known_artifacts(stage)
        manifest_art = uid("artifact")
        confirmation_art = uid("artifact")
        known[manifest_art] = "candidate_manifest.json"
        known[confirmation_art] = "release_confirmation.json"
        approval_uid, evidence_uid = uid("decision"), uid("evidence")
        model["consistency"]["evidence"].append({"uid": evidence_uid, "artifact_uid": confirmation_art, "json_pointer": "/user_quote", "part": None,
            "element_uid": None, "section": None, "table": None, "row": None, "column": None, "page": None,
            "quote": confirmation["user_quote"], "origin_kind": "user_supplied", "confirmation": "user_confirmed"})
        model["consistency"]["decisions"].append({"uid": approval_uid, "kind": "approve_release", "operation": None,
            "baseline_uid": model["protocol"]["baseline_uid"], "object_refs": [], "field_paths": [], "issue_refs": [], "before": None, "after": None,
            "reason": "用户确认当前已展示候选并要求生成最终JSON", "actor": confirmation["actor"], "decided_at": confirmation["confirmed_at"],
            "user_quote": confirmation["user_quote"], "user_evidence_refs": [evidence_uid], "target_fingerprint": confirmation["candidate_manifest_sha256"], "status": "active", "supersedes": []})
        model["consistency"]["release_binding"] = {"candidate_uid": manifest["candidate_uid"], "candidate_manifest_artifact_uid": manifest_art,
            "candidate_manifest_sha256": confirmation["candidate_manifest_sha256"], "release_confirmation_decision_uid": approval_uid}
        model["consistency"]["gates"]["delivery_state"] = "RELEASED"
        model["protocol"]["profile"] = "reqspec-reviewed"
        check_model(model, list(known) + [manifest["candidate_uid"]])
        final_icd = icd.build(model, "released", manifest["candidate_uid"])
        require(final_icd["engineering_sha256"] == load(candidate / "icd.json")["engineering_sha256"], "ICD_ENGINEERING_CHANGED: recheck and confirm a new candidate")
        result = publish(output, model, stage, known, {"最终检查报告.md": report(model, "最终一致性检查报告"), "icd.json": final_icd}, final=True)
        result["icd_path"] = str(Path(output) / "icd.json")
    return result

def run(argv=None):
    kind = KINDS[SKILL.name]
    parser = argparse.ArgumentParser(description="FEIP offline Agent-assisted skill runtime")
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("doctor")
    sub.add_parser("self-test")
    p = sub.add_parser("prepare")
    p.add_argument("--input", type=Path)
    p.add_argument("--baseline", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--previous-state", type=Path)
    p.add_argument("--decisions", type=Path)
    p.add_argument("--attachments", type=Path)
    p.add_argument("--diagnostic", action="store_true")
    p = sub.add_parser("extract")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    for action in ("review", "generate", "compare"):
        p = sub.add_parser(action)
        p.add_argument("--attempt", type=Path, required=True)
        p.add_argument("--model", type=Path, required=True)
        p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("finalize")
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--confirmation", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("validate")
    p.add_argument("--package", type=Path, required=True)
    args = parser.parse_args(argv)
    allowed = {"taskbook": ("review",), "writer": ("generate",), "checker": ("compare", "finalize")}
    if args.action in ("review", "generate", "compare", "finalize"):
        require(args.action in allowed[kind], "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
    if args.action == "doctor":
        from .docx_writer import dependencies
        return {"python": platform.python_version(), "platform": platform.platform(), "target": "Windows 7 SP1 / PowerShell 2.0 / Python 3.8.10", "dependencies": dependencies()}
    if args.action == "self-test":
        from .selftest import self_test
        return self_test()
    if args.action == "prepare":
        require(kind == "writer" or args.input is not None, "SOURCE_INPUT_REQUIRED")
        return prepare(kind, args.output, args.input, args.baseline, args.previous_state, args.decisions, args.diagnostic, args.attachments)
    if args.action == "extract":
        archive = extract(args.input, "taskbook" if kind == "taskbook" else "specification", "artifact:extract-input")
        save(args.output, archive)
        return {"output": str(args.output), "extraction_status": archive["extraction_status"]}
    if args.action == "review":
        return review(args.attempt, args.model, args.output)
    if args.action == "generate":
        return generate(args.attempt, args.model, args.output)
    if args.action == "compare":
        return compare(args.attempt, args.model, args.output)
    if args.action == "finalize":
        return finalize(args.candidate, args.confirmation, args.output)
    if args.action == "validate":
        model, manifest = verify_package(args.package)
        return {"valid": True, "profile": model["protocol"]["profile"], "package_uid": manifest["package_uid"], "icd_valid": True if (args.package / "icd.json").is_file() else None}
