"""Formal front-matter and overview sections assembled from frozen facts."""
import re

from .base import require


# Sections whose prose is assembled or validated here.
SECTIONS = ("1.1", "1.2", "3.1", "3.2")
# Report-facing sections that must never carry review-process annotations.
OVERVIEW_NUMBERS = ("1.1", "1.2", "1.4", "3.1", "3.2")

# 1.1 basic configuration-item facts, in report order.
BASIC_INFO_ITEMS = (
    ("product_name", "产品名称"),
    ("config_item_code", "配置项代号"),
    ("development_type", "研制类型"),
    ("safety_level", "安全关键等级"),
    ("maintenance_base", "继承基线"),
    ("chip_model", "芯片型号"),
    ("program_memory", "程序存储器"),
    ("assigner", "交办方"),
    ("contractor", "承办方"),
)

# 3.1 fixed template items, in report order.
TEMPLATE_LABELS = ("交办方", "应用环境", "用途", "一般特征", "软件继承性", "研制单位", "设计流程")

# 3.1 items the Agent may narrate from archived sources; frozen facts cover the rest.
OVERVIEW_ITEM_LABELS = {"general": "一般特征", "inheritance": "软件继承性"}

DESIGN_STAGES = ("任务需求阶段", "需求分析阶段", "概要设计阶段", "详细设计阶段", "仿真验证计划阶段",
                 "测试床编制阶段", "前仿真阶段", "综合、布局布线阶段", "后仿真阶段", "FPGA编程下载阶段",
                 "设计确认阶段", "第三方验证阶段", "验收交付")

TERMS_COLUMNS = ("名称", "术语含义")

# Process language never belongs in the delivered report body.
REVIEW_MARKERS = ("待确认", "待补", "未明确", "需确认", "请确认", "请补充")


def fact_value(container, name):
    value = container.get(name, {})
    return value.get("value") if value.get("status") == "present" else None


def words(value):
    if value is None:
        return ""
    if isinstance(value, list):
        return "、".join(str(v) for v in value)
    return str(value).strip().rstrip("。；")


def escape_cell(value):
    return str(value).replace("|", "\\|").replace("\r", "").replace("\n", "<br>")


def separated(lines):
    """One listed point per paragraph so Markdown keeps the items apart."""
    result = []
    for line in lines:
        if result:
            result.append("")
        result.append(line)
    return result


def identity(model):
    basic = model["basic_info"]
    name = words(fact_value(basic, "product_name"))
    code = words(fact_value(basic, "config_item_code"))
    return name + ("（" + code + "）" if code and code != name else "") if name else code or "本FPGA"


def function_summary(model):
    summary = words(fact_value(model["system_overview"], "main_functions"))
    if summary:
        return summary
    # Preserve source labels; no invented grouping, modules, algorithms or flow.
    names = list(dict.fromkeys(f["header"]["name"] for f in model["analysis"]["functions"]
                               if f["parent_function_uid"] is None and f["header"]["status"] == "present"))
    return "、".join(names)


def reject_review_language(number, lines):
    for line in lines:
        for marker in REVIEW_MARKERS:
            require(marker not in line,
                    "OVERVIEW_REVIEW_ANNOTATION: 需求规格说明是正式报告，" + number +
                    "正文不得出现“" + marker + "”等审阅过程用语；缺口由生成检查报告登记，不在正文留注记")


def basic_info_lines(model):
    # No lead-in sentence: the listed facts are the whole section body.
    # Each fact keeps its fixed template position; missing facts leave a gap
    # that is reported in the generation check report instead of the body.
    lines = []
    for index, (field, label) in enumerate(BASIC_INFO_ITEMS, 1):
        value = words(fact_value(model["basic_info"], field))
        if value:
            lines.append("{0}) {1}：{2}".format(index, label, value))
    return lines


def terms_table(model):
    lines = ["| " + " | ".join(TERMS_COLUMNS) + " |",
             "| " + " | ".join("---" for _ in TERMS_COLUMNS) + " |"]
    for entry in model["acronyms"]:
        meaning = "，".join(dict.fromkeys(m for m in (words(fact_value(entry, "full_name")),
                                        words(fact_value(entry, "meaning"))) if m))
        if not meaning:
            continue
        lines.append("| " + escape_cell(entry.get("abbreviation", "")) + " | " + escape_cell(meaning) + " |")
    return lines


def authored_items(section):
    """Agent narration for 3.1, keyed by control line; directives stay out of the body."""
    keys = "|".join(OVERVIEW_ITEM_LABELS)
    result = {}
    current = None
    for paragraph in section["paragraphs"]:
        directive = re.fullmatch(r"\s*<!-- overview-item:(" + keys + r") -->\s*", paragraph)
        if directive:
            current = directive.group(1)
            result.setdefault(current, [])
            continue
        require(not paragraph.strip().startswith("<!-- overview-item:"),
                "OVERVIEW_ITEM_DIRECTIVE_INVALID: " + section["number"])
        if not paragraph.strip():
            continue
        require(current is not None,
                "OVERVIEW_ITEM_UNMARKED: 3.1的自写叙述必须以 <!-- overview-item:" + keys +
                " --> 行开头标注所属条目；交办方/应用环境/用途/研制单位/设计流程由脚本从冻结事实生成，不要自写")
        result[current].append(paragraph)
    for lines in result.values():
        reject_review_language("3.1", lines)
    return result


def a_class(model):
    level = fact_value(model["basic_info"], "safety_level")
    return isinstance(level, str) and level.strip().upper().startswith("A")


def inheritance_lines(model):
    basic = model["basic_info"]
    parts = []
    development = words(fact_value(basic, "development_type"))
    if development:
        parts.append("研制类型为" + development)
    base = words(fact_value(basic, "maintenance_base"))
    if base:
        parts.append("继承基线为" + base)
    return ["本产品" + "，".join(parts) + "。"] if parts else []


def product_overview_entries(section, model):
    """The fixed 3.1 template; each item keeps its template position.
    Unsourced items are omitted and reported, never annotated in the body."""
    basic, overview = model["basic_info"], model["system_overview"]
    subject = identity(model)
    authored = authored_items(section)
    entries = []
    assigner = words(fact_value(basic, "assigner"))
    if assigner:
        entries.append((1, "交办方", [assigner]))
    host = words(fact_value(overview, "host_unit"))
    if host:
        entries.append((2, "应用环境", [host]))
    functions = function_summary(model)
    if functions:
        target = subject if "fpga" in subject.lower() else subject + " FPGA"
        entries.append((3, "用途", ["固化在" + target + "产品上，用于实现" + functions + "的功能。"]))
    if authored.get("general"):
        entries.append((4, "一般特征", authored["general"]))
    inheritance = authored.get("inheritance") or inheritance_lines(model)
    if inheritance:
        entries.append((5, "软件继承性", inheritance))
    contractor = words(fact_value(basic, "contractor"))
    if contractor:
        entries.append((6, "研制单位", [contractor]))
    label = "设计流程(A类)" if a_class(model) else "设计流程"
    entries.append((7, label, ["FPGA产品的设计研制过程一般经历以下13个工作阶段："]
                    + [letter + "．" + stage for letter, stage in zip("abcdefghijklm", DESIGN_STAGES)]))
    return entries


def product_overview_lines(section, model):
    lines = []
    for number, label, entry_lines in product_overview_entries(section, model):
        for offset, line in enumerate(entry_lines):
            if lines:
                lines.append("")
            lines.append(("{0}) {1}：".format(number, label) if offset == 0 else "") + line)
    return lines


def paragraphs(section, model):
    number = section["number"]
    if number not in SECTIONS:
        return section["paragraphs"]
    basic, overview = model["basic_info"], model["system_overview"]
    if number == "1.1":
        return separated(basic_info_lines(model))
    if number == "3.1":
        return product_overview_lines(section, model)
    authored = [p for p in section["paragraphs"] if p.strip()]
    if authored:
        # This is a limited structural guard, not a substitute for semantic review.
        reject_review_language(number, authored)
        anchors = [words(fact_value(basic, k)) for k in ("product_name", "config_item_code")]
        anchors += [words(fact_value(overview, "main_functions"))]
        anchors = [a for a in anchors if a]
        require(not anchors or any(a in "\n".join(authored) for a in anchors),
                "OVERVIEW_NOT_PRODUCT_SPECIFIC: summarize the actual FPGA in " + number)
        return separated(authored)
    subject = identity(model)
    functions = function_summary(model)
    result = []
    if number == "1.2":
        host = words(fact_value(overview, "host_unit"))
        composition = words(fact_value(overview, "subsystem_composition"))
        result.append(subject + ("位于" + host if host else "") + "。")
        if composition:
            result.append("上级系统/分系统组成概况：" + composition + "。")
        if functions:
            result.append(subject + "的主要功能包括：" + functions + "。")
        power = fact_value(overview, "long_term_power_on")
        if power is not None:
            result.append("工作方式：" + ("长期开机工作。" if power is True else "非长期开机工作。"))
    elif functions:
        result.append(subject + "的主要功能包括：" + functions + "。")
    return separated(result)


def basic_info_notes(model):
    notes = ["1.1：交接包未明确“" + label + "”，正文未列该条目。"
             for field, label in BASIC_INFO_ITEMS if fact_value(model["basic_info"], field) is None]
    if fact_value(model["basic_info"], "numbering_prefix") is None:
        notes.append("1.1：交接包未明确需求编号前缀，需求编号前缀校验待确认。")
    return notes


def terms_notes(model):
    if not model["acronyms"]:
        return ["1.4：交接包未提供术语和缩略语素材，正文仅保留表头。"]
    notes = []
    for entry in model["acronyms"]:
        if not words(fact_value(entry, "full_name")) and not words(fact_value(entry, "meaning")):
            notes.append("1.4：缩略语“" + str(entry.get("abbreviation", "")) + "”缺少全称及含义，正文未列该条目。")
    return notes


def missing(section, model):
    number = section["number"]
    notes = []
    if number == "1.2":
        if identity(model) == "本FPGA":
            notes.append("1.2：交接包缺少配置项名称或代号。")
        if not function_summary(model):
            notes.append("1.2：交接包缺少有来源的主要功能概述素材，正文未写功能概括。")
        if fact_value(model["system_overview"], "long_term_power_on") is None:
            notes.append("1.2：交接包未明确是否长期开机工作，正文未写工作方式。")
    elif number == "3.1":
        present = {position for position, _, _ in product_overview_entries(section, model)}
        for position, label in enumerate(TEMPLATE_LABELS, 1):
            if position not in present:
                notes.append("3.1：缺少有来源的“" + label + "”内容，正文未列该条目。")
    elif number == "3.2":
        if identity(model) == "本FPGA":
            notes.append("3.2：交接包缺少配置项名称或代号。")
        if not function_summary(model):
            notes.append("3.2：交接包缺少有来源的主要功能概述素材，正文未写功能概括。")
    return notes


def warnings(model):
    notes = []
    notes.extend(basic_info_notes(model))
    notes.extend(terms_notes(model))
    for view in model["document_views"]:
        if view["role"] == "writer_plan":
            for section in view["sections"]:
                number = section["number"]
                if number in SECTIONS:
                    paragraphs(section, model)
                if number in OVERVIEW_NUMBERS and section["status"] in ("missing", "unknown"):
                    notes.append(number + "：上游交接计划标注本节状态为" + section["status"] +
                                 "（" + (section["reason"] or "未注明原因") + "），正文按已明确事实编写，缺口以本报告为准。")
                notes.extend(missing(section, model))
    return notes
