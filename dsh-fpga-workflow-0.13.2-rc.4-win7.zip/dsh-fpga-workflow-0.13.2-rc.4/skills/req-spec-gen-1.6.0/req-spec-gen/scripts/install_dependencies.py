"""Install pinned bundled wheels locally; no pip, network, admin rights or modern Python."""
import hashlib
import json
import shutil
import struct
import sys
import uuid
from pathlib import Path
from zipfile import ZipFile


def main():
    if sys.version_info[:3] != (3, 8, 10):
        raise ValueError('PYTHON_RUNTIME_MISMATCH: requires Python 3.8.10')
    root = Path(__file__).resolve().parents[1]
    wheels = root / 'assets/offline-wheels'
    pins = json.loads((wheels / 'manifest.json').read_text(encoding='utf-8'))
    suffix = 'win_amd64' if struct.calcsize('P') == 8 else 'win32'
    names = ['python_docx-1.1.2-py3-none-any.whl', 'typing_extensions-4.12.2-py3-none-any.whl',
             'lxml-4.9.3-cp38-cp38-' + suffix + '.whl']
    destination = root / '.deps'
    if destination.exists():
        sys.path.insert(0, str(destination))
        import docx
        import lxml
        if docx.__version__ == '1.1.2' and lxml.__version__ == '4.9.3':
            print('DEPENDENCIES_OK: ' + str(destination))
            return
        raise ValueError('DEPENDENCY_DIRECTORY_EXISTS: preserve it and use a clean skill copy')
    staging = root / ('.deps-staging-' + uuid.uuid4().hex)
    staging.mkdir()
    try:
        for name in names:
            path = wheels / name
            if hashlib.sha256(path.read_bytes()).hexdigest() != pins[name]:
                raise ValueError('DEPENDENCY_HASH_MISMATCH: ' + name)
            with ZipFile(str(path)) as archive:
                for member in archive.infolist():
                    target = (staging / member.filename).resolve()
                    if staging.resolve() not in target.parents:
                        raise ValueError('UNSAFE_WHEEL_PATH')
                archive.extractall(str(staging))
        staging.rename(destination)
    except Exception:
        shutil.rmtree(str(staging))
        raise
    sys.path.insert(0, str(destination))
    from docx import Document
    Document()
    print('DEPENDENCIES_OK: ' + str(destination))


if __name__ == '__main__':
    main()
