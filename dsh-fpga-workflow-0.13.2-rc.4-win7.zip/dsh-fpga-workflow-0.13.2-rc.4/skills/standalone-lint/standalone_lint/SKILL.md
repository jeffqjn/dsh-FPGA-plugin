---
name: standalone-lint
description: Non-interactive, read-only coding-rule audit of Verilog, SystemVerilog, and VHDL RTL, including mixed-language projects. Selects the rule catalog by source extension, assigns one child agent per file, validates batch coverage, and delivers a final findings report. Do not use for modifying RTL, compiling, simulating, synthesizing, or advancing a design flow.
---

# Standalone RTL Code Rule Lint

Use this read-only audit when the user provides existing Verilog/SystemVerilog files and wants a complete code-rule check without advancing any design flow (G0-G5) and without an architecture contract. One persistent coordinator owns scope, state, coverage, and reporting. Each assignment covers one source file. A worker handles only that source and can hand off remaining batches after an accepted checkpoint.

## Non-negotiable rules

1. Work offline using available local artifacts. Run the audit without user interaction. Do not ask the user questions, request files or approvals, ask for confirmation, or wait for a reply at any stage. Keep status in the task state and deliver findings and limitations in one final report.
2. Read and inspect the RTL as supplied. Do not modify, reformat, compile, elaborate, simulate, or synthesize it. Write only to:

   ```text
   analysis/standalone_lint/<task_id>/
   reports/standalone_lint/<task_id>/
   ```

3. Use `scripts/standalone_lint_workflow.py` as the authoritative workflow driver. Do not substitute an Agent-authored file list, rule count, or completion claim for its frozen manifests and validators.
4. Local lint tools are used only as supplementary evidence. They cannot add/remove canonical rules, decide semantic compliance, or replace the file-by-rule matrix.
5. Record findings, source locations, evidence, and verification gaps in the audit report. Limit the report to observed code and its rule compliance. Omit remediation steps, replacement code, and speculative consequences.
6. Use the host's existing permissions. Treat denied reads or writes as audit limitations and use another already-permitted tool or output path within the stated scope when possible. Do not invoke permission or workspace repair tools, change ACLs or security settings, or escalate access.

## Inputs and scope

- Exact RTL files/directories. Optional inputs include file list, top, defines, includes, and local vendor libraries.
- Match `.v`, `.sv`, `.vh`, and `.svh` to the Verilog/SystemVerilog catalog and `.vhd` and `.vhdl` to the VHDL catalog, case-insensitively. Use an identified project ruleset for its matching language, or the bundled catalog selected by the driver.
- Resolve scope from the request and local artifacts. When a missing dependency affects individual checks, record the affected rows as `not_verifiable` and continue. If the source scope cannot be determined or a required input prevents the audit, report the limitation and the coverage reached.

## Procedure

1. Follow the [coordinator workflow](references/standalone-lint.md) to run `prepare`, freeze the sources and language catalogs, and create a deterministic queue. Cover each source × its own catalog, including rules that are `not_applicable`.
2. Dispatch one child agent per source file. Reuse that child for the file's successive batches while it has context room. In DeepSeek Harness with a 32,768-token output ceiling, start with one live child, at most 10 rules per batch, and an 8 KiB rule-chunk budget. Use `release` for a reservation whose worker never started.
3. Use the [worker prompt](assets/templates/worker_prompt.md). Give the child the assigned source, language, and current batch only. After the child writes the result, collect it before loading the next chunk. Keep all unrelated rule text and full matrices out of the worker context.
4. Collect child results using the host's wait tool or automatic task-result messages. An automatic callback resumes the same audit without user input. Before `accept-batch`, verify each `fail` against the exact rule, cited source, and established scope facts, including top-level status. For an interrupted child, accept any valid results and `requeue` remaining work. Only a replacement for that same file can resume it. If the host cannot collect child results without user intervention, record the affected files as incomplete and deliver the available report.
5. Once all batches for a source have been accepted, run `complete`. The driver assembles its canonical matrix and checks the frozen inputs. Close the worker when its work ends, and dispatch another source when a host slot is free.
6. Run the driver's `report` command after the queue drains. It validates coverage internally, renders size-checked Markdown parts from accepted results, and merges them locally. Deliver the report and issue-card paths with a short coverage and findings summary. Keep full reports, issue lists, and matrix data out of model-generated replies and write-tool arguments.

## Coordinator persistence and completion

The coordinator retains its checkpoint through validation and report delivery. The audit completes when all of the following are true:

- the source and rule manifests remain valid;
- every source has a validated complete rule matrix;
- global coverage validation passes with zero missing/duplicate/unfinished pairs;
- the consolidated report has been delivered to the user.

End the turn only after delivering the report. For a prepared task blocked before full coverage, use `report --blocker "<reason>"` to deliver accepted findings and unchecked scope. If preparation or report writing is blocked, give a short final summary of the available findings and limitations.

The final report is an independent audit and never substitutes for any design-flow gate (G0-G5).
