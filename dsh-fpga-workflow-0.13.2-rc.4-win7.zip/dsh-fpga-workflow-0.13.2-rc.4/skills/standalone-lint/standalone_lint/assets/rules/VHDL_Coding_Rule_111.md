# 航天器产品 VHDL 语言编程约定

Q/W－Q－80－20―01A―2025

## 1 范围

本标准规定了航天器产品 VHDL 硬件描述语言编程的准则、基本设计约束规则和 RTL 描述风格规则。

本标准适用于采用 VHDL 硬件描述语言进行开发的航天器产品，其他产品可参照使用。

## 2 规范性引用文件

下列文件中的条款通过本标准的引用而成为本标准的条款。凡是注日期的引用文件，其随后所有的修改单(不包含勘误的内容)或修订版均不适用于本标准。然而，鼓励根据本标准达成协议的各方研究是否可使用这些文件的最新版本。凡是不注日期的引用文件，其最新版本适用于本标准。

SJ 20777 电子设计硬件描述语言 VHDL

## 3 术语和定义

SJ 20777 确立的术语和定义适用于本标准。

## 4 缩略语

下列缩略语适用于本标准。

- ASIC——application specific integrated circuit ，专用集成电路；
- FPGA——field programmable gate array，现场可编程门阵列；
- RTL——register transfer level ，寄存器传输级；
- SDF——standard delay format， 标准延时格式文件；
- VHDL——very-high-speed integrated circuit hardware description language，超高速集成电路硬件描述语言。

## 5 准则

航天器产品VHDL硬件描述语言编程约定的规则分为强制类和推荐类。强制类为应执行的规则，推荐类为参考执行的规则。

## 6 规则

### 6.1 基本设计约束

#### 6.1.1 声明定义

##### 6.1.1.1 强制类

###### 6.1.1.1.1 声明定义时，只能使用字母、数字和下划线“`_`”，且首字符应是字母，末字符不应使用下划线，不应连续使用下划线，不应使用任何转义字符。

**违背示例1：**

```vhdl
signal \~!@#$%^&:-)\ : integer; -- 违背：信号名\~!@#$%^&:-)\违背要求
```

**违背示例2：**

```vhdl
signal \signal\ : bit := '1'; -- 违背：信号名\signal\包含“\”
```

###### 6.1.1.1.2 声明定义时，不应使用 Verilog(System Verilog)、VHDL、EDIF 和 SDF 中的关键词，同时也不应使用单独的“VDD”、“VSS”、“VCC”、“GND”或“VREF”（大写、小写或大小写混合）。

**违背示例1：**

```vhdl
entity task is; -- 违背：实体名task属于“Verilog”关键词
    ...
end task
```

**违背示例2：**

```vhdl
attribute const : string; -- 违背：属性名const属于“System Verilog”关键词
attribute const of signal1 : signal is "true";
```

**违背示例3：**

```vhdl
variable GND : bit; -- 违背：变量名GND为单独的“GND”
```

###### 6.1.1.1.3 不应通过使用英文字母大小写来区分相同的名字。

##### 6.1.1.2 推荐类

###### 6.1.1.2.1 实体名、端口名、实例名、信号名、变量名、函数名长度宜在 2 到 32 个字符之间。

###### 6.1.1.2.2 时钟信号的命名宜以 `clk_`开始，以时钟频率或时钟用途标识结束。

###### 6.1.1.2.3 复位信号的命名宜以 `rst_/reset_`开始，以 p/n 结束，“p”代表高电平复位，“n”代表低电平复位。

###### 6.1.1.2.4 宜避免出现仅定义未使用的端口和信号。

**违背示例：**

```vhdl
entity sig_ent is
port(
    rst_n : in std_logic;
    clk : in std_logic;
    cnt_out : out std_logic_vector(5 downto 0)
);
end sig_ent;
architecture rtl of sig_ent is
    signal s_count : std_logic_vector(5 downto 0);
    signal cnt : std_logic_vector(5 downto 0); -- 违背：信号cnt仅定义未使用
begin
    cnt_out <= s_count(5 downto 0);
    process(rst_n,clk)
    begin
        if(rst_n = ’0’)then
            s_count <= (others => ’0’);
        elsif(clk’event and clk = ’1’) then
            s_count <= s_count + 1;
        end if;
    end process;
end rtl;
```

###### 6.1.1.2.5 实体描述和 RTL 结构体描述宜在同一文件，且实体描述宜在 RTL 结构体描述之前。

如实体和 RTL 结构体在不同文件中描述，则编译过程中应考虑编译次序，而在同一文件中描述可避免此问题。

**遵循示例：**

```vhdl
-- 遵循1：实体tof和结构体rtl在同一个文件内描述
entity top is
    ...
end top;
architecture rtl of top is -- 遵循2：结构体rtl在实体top之后被声明
begin
    ...
end rtl;
```

**违背示例：**

```vhdl
architecture rtl of top is  -- 违背：结构体rtl在实体top之前被声明
begin
    ...
end rtl;
entity top is
    ...
end top;
```

#### 6.1.2 基本单元设计

##### 6.1.2.1 强制类

###### 6.1.2.1.1 不应在组合逻辑电路中使用反馈。

**违背示例：**

```vhdl
entity top is
port(
    data : in std_logic;
    sel : in std_logic;
    Q : inout std_logic
);
end top;

architecture rtl of top is
    signal temp : std_logic_vector(2 downto 0);
begin
    temp(0) <= data and temp(2);
    temp(1) <= temp(0) xor data;
    temp(2) <= data when sel = '0' else temp(1); -- 违背：temp(2)为组合逻辑电路反馈
    Q <= temp(2);
end rtl;
```

![组合逻辑反馈电路](vhdl-111-figures/p03-01.png)

###### 6.1.2.1.2 不应使用基本单元（如 AND，OR）生成锁存器或触发器。

**违背示例：**

```vhdl
entity ff is
port(
    data0 : in std_logic;
    data1 : in std_logic;
    Q : out std_logic
);
end ff;

architecture rtl of ff is
    signal temp0 : std_logic;
    signal temp1 : std_logic;
begin
    temp0 <= data0 and temp1;
    temp1 <= temp0 or data1; -- 违背：类似RS锁存器的组合电路描述
    Q <= temp1;
end rtl;
```

![使用基本单元构成的锁存电路](vhdl-111-figures/p03-02.png)

#### 6.1.3 复位

##### 6.1.3.1 强制类

###### 6.1.3.1.1 禁止将寄存器的输出反馈到该寄存器的异步复位(置位)端。

同一个寄存器的输出信号不应经过组合逻辑后再反馈回该寄存器的异步复位(置位)端。

###### 6.1.3.1.2 禁止使用有竞争冒险情况的组合逻辑输出作为复位信号。

组合逻辑作为复位信号时应该被同步，避免组合逻辑产生毛刺导致误复位。

**违背示例：**

```vhdl
...
rst_n <= rst_a and rst_b;
process(clk, rst_n) -- 违背：使用组合逻辑输出作为复位信号
begin
    if(rst_n = '0') then
...
```

###### 6.1.3.1.3 不应同时使用异步置位和异步复位。

同时使用异步置位和异步复位将在控制线中生成多余逻辑。

**违背示例：**

```vhdl
process(clk, reset, set)
begin
    if(reset = '1') then --违背1：同时使用异步复位和异步置位控制
        q_reg <= '0';
    elsif(set = '1') then --违背2：同时使用异步复位和异步置位控制
        q_reg <= '1';
    elsif(clk'event and clk = '1') then
        g_reg <= data;
    end if;
end process;
```

###### 6.1.3.1.4 触发器和输出端口在复位过程中应有确定值。

###### 6.1.3.1.5 异步复位条件的左端应为信号，不应为表达式。

##### 6.1.3.2 推荐类

###### 6.1.3.2.1 不宜将同一个复位信号同时作为同步复位和异步复位使用。

一个复位信号同时作为同步复位和异步复位，综合时可能出现非正常结果。同时包含异步复位和同步复位在逻辑综合和布局布线中也可能导致其他问题。

**违背示例：**

```vhdl
entity top is
port(
    clk : in std_logic;
    reset : in std_logic; -- 违背1：信号reset被同时用于同步和异步信号线
    d1 : in std_logic;
    d2 : in std_logic;
    q1 : out std_logic;
    q2 : out std_logic
);
end top;
architecture rtl of top is
begin
    process(clk)
    begin
        if(clk'event and clk = '0') then
            if(reset = '1') then -- 违背2：连接到同步复位端
                q1 <= '0';
            else
                q1 <= d1;
            end if;
        end if;
    end process;
    process(clk, reset) -- 违背3：连接到异步复位端
    begin
        if(reset = '1') then
            q2 <= '0';
        elsif(clk'event and clk = '0') then
            q2 <= d2;
        end if;
    end process;
end rtl;
```

![同一复位信号用于同步复位和异步复位](vhdl-111-figures/p05-01.png)

###### 6.1.3.2.2 不宜将置位/复位信号作为他用，只能作为复位使用。

**违背示例：**

```vhdl
entity dff is
port(
    ...
    reset : in std_logic;
    ...
);
end dff;
architecture rtl of dff is
begin
    ...
    process(reset) -- 违背：全局复位reset被连接到时钟端
    begin
        if(rising_edge(reset)) then
            Q <= data;
        end if;
    end process;
    ...
end rtl;
```

###### 6.1.3.2.3 触发器的异步复位宜使用全局复位，其他信号不宜连接到异步复位端。

###### 6.1.3.2.4 宜使用复位操作对寄存器进行初始化，不宜采用声明初始化方式。

**违背示例：**

```vhdl
signal S_test : std_logic_vector(1 downto 0) := "10"; -- 违背：使用了声明初始化方式
```

###### 6.1.3.2.5 同一个复位(置位)信号宜使用唯一的有效电平。

在设计中使用复位(置位)信号的两个有效电平，不能保证各模块同时复位(置位)。

**遵循示例:**

```vhdl
-- 遵循：使用同一电平复位
```

![使用同一有效电平复位](vhdl-111-figures/p06-01.png)

**违背示例：**

```vhdl
-- 违背：使用不同电平复位
```

![使用不同有效电平复位](vhdl-111-figures/p06-02.png)

#### 6.1.4 时钟

##### 6.1.4.1 强制类

###### 6.1.4.1.1 禁止时钟信号再汇聚。

时钟信号再汇聚，即时钟信号经过不同路径后进行组合逻辑处理产生一个信号作为时钟信号，再汇聚路径易导致时钟路径上发生时序冲突。

**违背示例：**

```vhdl
entity example_ent is
port(
    clk : in std_logic;
    rst_n : in std_logic;
    sel1 : in std_logic;
    sel2 : in std_logic;
    din : in std_logic;
    dout : out std_logic
);
end example_ent;

architecture rtl of example_ent is
    signal clk1 : std_logic;
    signal clk2 : std_logic;
    signal clk_sel : std_logic;
begin
    clk1 <= sel1 and clk;
    clk2 <= sel2 or clk;
    clk_sel <= clk1 and clk2; -- 违背：此处的时钟信号在时钟网络上发生了再汇聚

    process(rst_n,clk_sel)
    begin
        if(rst_n= '0') then
            dout <= '0';
        elsif(clk_sel'event and clk_sel = '1') then
            dout <= din;
        end if;
    end process;
end rtl;
```

![时钟信号再汇聚电路](vhdl-111-figures/p07-01.png)

###### 6.1.4.1.2 禁止时钟信号连接到多路选择器的控制端。

**违背示例：**

```vhdl
entity example_ent is
port(
    clk : in std_logic;
    d_in : in std_logic;
    d_out : out std_logic
);
end example_ent;
...
d_out <= d_in when clk = '1' else '0'; -- 违背：时钟信号连接到多路选择器的控制端
...
```

##### 6.1.4.2 推荐类

###### 6.1.4.2.1 FPGA 内部不宜使用门控时钟。

使用门控时钟易因毛刺引起误触发，产生逻辑错误。

**违背示例：**

```vhdl
entity example_ent is
port(
    clk : in std_logic;
    ...
    clk_out : out std_logic
);
end example_ent;

...
signal s1 : std_logic;
...
clk_out <= clk and s1;-- 违背：由输入时钟、控制信号经与门产生门控时钟，容易产生毛刺
```

###### 6.1.4.2.2 不宜将一个触发器的输出连接至另一个触发器的时钟端。

一个触发器的输出连接至另一个触发器的时钟端时，时钟树综合工具将无法考虑时钟树的平衡，可采用时钟网络驱动等措施。

**违背示例：**

```vhdl
entity sr is
port(
    clk : in std_logic;
    reset : in std_logic;
    data_a : in std_logic;
    data_b : in std_logic;
    Q: out std_logic
);
end sr;

architecture rtl of sr is
    signal trf12: std_logic;
begin
    process(clk, reset)
    begin
        if(reset = '1') then
            trf12 <= '0';
        elsif(clk'event and clk = '1') then
            trf12 <= data_a;
        end if;
    end process;

    process(trf12, reset)
    begin
        if(reset = '1') then
            Q <= '0';
        elsif(trf12'event and trf12 = '1') then -- 违背：时钟端被另一触发器的输出所驱动
            Q <= data_b;
        end if;
    end process;
end rtl;
```

###### 6.1.4.2.3 时钟信号宜仅能连接至触发器的时钟端。

**违背示例：**

```vhdl
entity top is
port(
    clk_a : in std_logic;
    clk_b : in std_logic;
    data : std_logic;
    Q1 : out std_logic;
    Q2 : out std_logic
);
end top;

architecture rtl of top is
begin
    process(clk_a)
    begin
        if(clk_a'event and clk_a = '1') then
            Q1 <= data;
        end if;
    end process;

    process(clk_b)
    begin
        if(clk_b'event and clk_b = '1') then
            Q2 <= clk_a; -- 违背：全局时钟信号clk_a被连接至触发器Q2的数据输入端
        end if;
    end process;
end rtl;
```

###### 6.1.4.2.4 不宜在同一设计中同时使用同一时钟的上升沿和下降沿。

FPGA 单元库中一般只有一种工作于上升沿或下降沿类型的触发器，不宜同时使用两种相反沿触发器。

**违背示例：**

```vhdl
entity top is
port(
    clk : in std_logic;
    din : in std_logic;
    dout1 : out std_logic;
    dout2 : out std_logic
);
end top;

architecture rtl of top is
begin
    process(clk)
    begin
        if(falling_edge(clk)) then  -- 违背1：时钟信号clk的上升沿和下降沿同时被使用
            dout1 <= din;
        end if;
    end process;

    process(clk)
    begin
        if(rising_edge(clk)) then -- 违背2：时钟信号clk的上升沿和下降沿同时被使用
            dout2 <= din;
        end if;
    end process;
end rtl;
```

###### 6.1.4.2.5 不宜将组合逻辑的输出作为时钟信号。

组合逻辑容易产生毛刺，作为时钟控制信号时引起触发器的错误翻转。

**违背示例：**

```vhdl
entity example_ent is
port(
    a_in : in std_logic;
    b_in : in std_logic;
    d_in : in std_logic;
    d_out : out std_logic
);
end example_ent;

architecture rtl of example_ent is
    signal clk : std_logic;
begin
    clk <= a_in and b_in;

    process(clk)
    begin
        if(clk’event and clk = ’1’) then -- 违背：时钟信号clk为组合逻辑产生
            d_out <= d_in;
        end if;
    end process;
end rtl;
```

###### 6.1.4.2.6 全局时钟宜使用全局时钟布线资源。

###### 6.1.4.2.7 不宜在同一同步时钟域内的时钟路径上插入反相器或缓冲器。

同一同步时钟域内，在时钟路径上插入反相器或缓冲器，会增加时钟信号的偏移，引起时序错误，并使时序余量变小。

#### 6.1.5 异步电路处理

##### 6.1.5.1 强制类

###### 6.1.5.1.1 不应将组合逻辑置于两个时钟域之间。

为确保同步电路正常工作，跨时钟域的信号从源域至同步电路的第一个触发器间不应经过任何组合逻辑。

**违背示例：**

![两个时钟域之间放置组合逻辑](vhdl-111-figures/p10-01.png)

###### 6.1.5.1.2 不应在同步电路的第一级触发器之后设置反馈循环。

存在数据反馈时，亚稳态可能影响锁存数据从而导致电路的功能错误。

**违背示例：**

![同步电路第一级触发器之后的反馈循环](vhdl-111-figures/p10-02.png)

###### 6.1.5.1.3 不应在同步电路的采数触发器和下一个触发器之间放置逻辑。

如将组合逻辑放置在同步电路的两个触发器之间，由于第二个触发器对组合逻辑产生的短时脉冲波形干扰敏感，极大地增加了传播一个伪有效值至目的逻辑的风险，从而导致同步电路失效。

**违背示例：**

![两个同步触发器之间放置组合逻辑](vhdl-111-figures/p10-03.png)

###### 6.1.5.1.4 对跨时钟域信号，应采取同步处理措施。

异步信号未经同步使用，可能产生亚稳态，引起错误。

###### 6.1.5.1.5 异步复位释放时，应采用同步释放的方式。

在异步复位释放时应采用同步释放的方式，避免异步复位释放时的亚稳态。

### 6.2 RTL 描述风格

#### 6.2.1 语法约束

##### 6.2.1.1 强制类

###### 6.2.1.1.1 敏感信号列表应齐全，无遗漏、无冗余。

组合进程块中，所有出现在赋值语句右边的信号和条件表达式中的所有信号，都应被定义在敏感列表中，避免敏感信号多余或缺失。

时序进程块中，敏感信号列表一定要包含时钟和其他异步控制信号，应避免出现不必要的信号。

**违背示例：**

```vhdl
process(D1, D2) --违背1：敏感信号列表不完整
begin
    if(SEL = '0') then -- 违背2：信号SEL被读取，但未在敏感信号列表中
        Q <= D1;
    else
        Q <= D2;
    end if;
end process;
```

###### 6.2.1.1.2 使用 integer 时应定义范围（函数(function)定义中除外）。

integer 的默认位宽是 32 位，被比较时，一些逻辑综合工具可能生成 32 位宽的比较器，位宽可能宽于算术或逻辑操作所需，所以任何时候使用 integer 时均应定义范围。

###### 6.2.1.1.3 端口连接应通过名字描述连接而不应通过位置连接。

在进行端口例化时，应采取名称映射的方式，避免位置映射，利于提高程序的可读性和可维护性。

**遵循示例：**

```vhdl
reset_filter_inst : reset_filter -- 遵循：端口例化采取名称映射
port map(
    reset_in => reset_in,
    clk => clk,
    reset_out => reset_out
);
```

**违背示例：**

```vhdl
reset_filter_inst : reset_filter -- 违背：端口例化采取位置映射
port map(
    reset_in,
    clk,
    reset_out
);
```

端口连接的位宽应一致。

###### 6.2.1.1.4 端口连接时不应使用表达式（拼接符除外）。

**遵循示例：**

```vhdl
s_ctrl <= ctrll or ctrl2; -- 遵循
MUX2x1_inst : MUX2x1
port map(
    ctrl => s_ctrl,
    din1 => din1,
    din2 => din2,
    dout => dout
);
```

**违背示例：**

```vhdl
MUX2x1_inst : MUX2x1
port map(
    ctrl => ctrll or ctrl2, -- 违背：端口连接使用表达式
    din1 => din1,
    din2 => din2,
    dout => dout
);
```

###### 6.2.1.1.5 不应给输入端口赋初始值。

**违背示例：**

```vhdl
library ieee;
use ieee.std_logic_1164.all;

entity counter is
port(
    clk : in std_logic;
    en : in std_logic := '1'; -- 违背1：端口en被赋予了初始值
    rst : in std_logic;
    cnt : out std_logic_vector(7 downto 0) := "00000000"  -- 违背2：端口cnt被赋予了初始值
);
end counter;
```

###### 6.2.1.1.6 例化时禁止输入端口悬空。

在进行例化时，输入端口应有确定的输入关系，不应悬空。

###### 6.2.1.1.7 不应在函数声明中使用嵌套。

**违背示例：**

```vhdl
function parent (p1, p2 : std_logic) return std_logic is
    function nested (n1,n2 : std_logic) return std_logic is -- 违背：使用了嵌套函数nested
        variable nested_res: std_logic;
    begin
        ...
    end nested;

    variable parent_res: std_logic;
begin
    ...
end parent;
```

###### 6.2.1.1.8 在函数中，应使用函数内部定义的信号，不应使用全局信号。

禁止在函数定义内部使用全局信号。一些逻辑综合工具不支持这样的描述，可能会生成带有缺陷的电路。

**违背示例：**

```vhdl
function f_sel(signal arg : std_logic_vector(0 to 3))
return std_logic_vector is
    variable a : std_logic_vector(x'range);
    variable b : std_logic_vector(x'range);
begin
    ...
    case(SEL_1) is  -- 违背：信号SEL_1不是函数输入或本地信号
        when "0001" => a := pow_n(arg, 1);
        ...
        when others => a := pow_n(arg, 7);
    end case;
    ...
end function;
```

###### 6.2.1.1.9 不应使用用户自定义属性。

用户自定义属性可能被逻辑综合工具忽略，因此不应使用。

**违背示例：**

```vhdl
attribute port num : integer;
attribute port_num of model : entity is 5; -- 违背：使用了用户自定义属性
```

###### 6.2.1.1.10 数组索引应只能使用常数或信号名。

数组索引不应有任何操作符表达式，只能使用常量或信号名。类型转换函数、并置、位选择和简单的函数调用在绝大多数情况下可以安全使用，使用简单信号作为索引表达式可避免生成冗余逻辑。

**违背示例：**

```vhdl
architecture rtl of e_fstl is
    signal src_samp : integer range 0 to 15;
begin
    ...
    res_cntp_1 <= inp_nonproc(src_samp + 2 ); -- 违背：索引表达式使用了操作符
    ...
end rtl;
```

###### 6.2.1.1.11 使用标准包 IEEE.std_logic_1164。

VHDL 描述应使用标准包 IEEE.std_logic_1164，因为它包含了 std_logic 和 std_logic_vector 类型定义，RTL 设计需要这些类型。

**遵循示例：**

```vhdl
library ieee;
use ieee.std_logic_1164.all; -- 遵循：使用IEEE.std_logic_1164

entity DFF is
    ...
end DFF;
architecture rtl of DFF is
    ...
end rtl;
```

###### 6.2.1.1.12 顶层模块 I/O 端口应仅能使用 std_logic，std_logic_vector。

###### 6.2.1.1.13 在结构体内应仅能使用 std_logic，std_logic_vector，integer，boolean，unsigned， signed 和基于上述类型的用户自定义类型。

在结构体内，除了使用 std_logic，std_logic_vector，只能使用 integer，boolean，unsigned， signed 或用户自定义类型。

**违背示例：**

```vhdl
package types is
    constant c0 : bit := '0'; -- 违背1：常量c0使用了被禁止使用的数据类型bit
    type my_time is array(natural) of time; -- 违背2：类型type基于被禁止使用的数据类型time
    ...
end types;
```

###### 6.2.1.1.14 不应使用 bit 或 bit_vector 数据类型。

在 VHDL 中有 bit 和 bit_vector 数据类型，但是这两种类型不应使用。bit 仅有’0’ and ‘1’然而 std_logic 能够处理 9 值，例如：当’X’传播时就会产生一个漏洞或被忽略，可能会导致一个意外的仿真结果。

**违背示例：**

```vhdl
    package func_pack is
    function bit2bit(s : bit_vector ) return bit is -- 违背1：函数bit2bit返回bit数据类型
        variable tmp : bit_vector; -- 违背2：变量tmp是bit_vector数据类型
    begin
        ...
    end function;
    ...
end func_pack;
```

###### 6.2.1.1.15 不应使用属性 enum_encoding。

Design Compiler 支持使用属性 enum_encoding 将枚举类型字符串编码为算术值。通过使用该属性，实际的逻辑值能够赋给用户定义的值。但某些综合工具可能不支持该属性，无法进行逻辑综合。

**违背示例：**

```vhdl
library synopsys;
use synopsys.attributes.all;
attribute ENUM_ENCODING of my_enc : type is "001 010 100";-- 违背：使用了enum_encoding属性
```

###### 6.2.1.1.16 多位信号、变量定义时应设置位宽（函数(function)定义中除外）。

如不定义std_logic_vector的范围，仿真过程中可能发生范围定义错误。综合工具也可能基于对位宽的理解来生成门级电路，导致与仿真器的理解不同。

**遵循示例：**

```vhdl
function f1(a, b : std_logic_vector ) return std_logic_vector is -- 遵循：在函数定义中除外
begin
    ...
end function;
```

**违背示例：**

```vhdl
entity model is
port(
    in1 : in std_logic_vector; -- 违背：接口信号in1声明中没有定义范围
    in2 : in std_logic_vector(7 downto 0);
    ...
);
end model;
```

###### 6.2.1.1.17 不应使用 buffer 类型和 linkage 类型的端口。

在 RTL 描述中，只允许使用 in、out 和 inout 端口模式。为了内部重用端口值，可先将值赋予一个内部声明的信号，再将此信号赋予声明为 out 的端口，从而避免使用 buffer 类型端口。根据 RTL 描述的要求，无法确认的端口在现实中是不存在的，所以，也不应使用 linkage 类型端口。

**违背示例：**

```vhdl
library ieee;
use ieee.std_logic_1164.all;
entity counter is
port(
    clk : in std_logic;
    en : in std_logic;
    rst : in std_logic;
    cnt : buffer std_logic -- 违背：使用了buffer类型端口
);
end counter;
```

###### 6.2.1.1.18 端口的模式描述应完整。

VHDL 语言允许删除端口的模式描述，此时端口模式默认为 in。但是，端口模式描述可能被错误删除而导致出现其它模式，可能致使编译错误或被忽略。所以端口模式应描述完整，使得定义明确。

**违背示例：**

```vhdl
component dff is
port(
    clk : std_logic; -- 违背1：端口clk的模式描述不完整
    d : std_logic; -- 违背2：端口d的模式描述不完整
    q : out std_logic
);
end component;
```

###### 6.2.1.1.19 不应使用移位函数。

VHDL’93 支持移位函数（如 sll 和 srl），但某些逻辑综合工具并不支持，且绝大多数工具在综合时只支持移位数为常量。使用这些函数还会带来其他问题，如综合结果会因为移位函数赋值的位置不同而不同等。

**遵循示例：**

```vhdl
process(clk)
begin
    if(clk'event and clk = '1') then
        A <= (A(6 downto 0)& B); -- 遵循
    end if;
end process;
```

**违背示例：**

```vhdl
process(clk)
begin
    if(clk'event and clk = '1') then
        A <= A sll 1; -- 违背：使用移位函数sll，结果会因为赋值顺序的不同而造成差异
        A(0) <= B;
    end if;
end process;
```

###### 6.2.1.1.20 集合(aggregate) 应仅能使用直接赋值。

对于集合的理解依赖于仿真和逻辑综合工具。集合使用非直接赋值时可能发生非期望的语法错误。

**违背示例：**

```vhdl
signal X : std_logic_vector(7 downto 0);
signal Y : std_logic_vector(3 downto 0);
signal B : std_logic_vector(3 downto 0);
signal EN : std_logic;

X <= B & (others => EN); -- 违背1：赋值给低位的(others => EN)的向量范围不确定

Y <= B and (others => EN); -- 违背2：参与与运算的(others => EN)的向量范围不确定
```

###### 6.2.1.1.21 函数定义的集合中应仅能使用单独的 others 值。

函数定义的集合中，others 和其他值共同使用时，会导致一些仿真器和逻辑综合工具出错。

**违背示例：**

```vhdl
function f_calc(... ) return std_logic_vector is
    variable TMP : std_logic_vector(TS'range);
begin
    ...
    TMP := ('0', others => '1'); -- 违背：TMP赋了一个不仅包含others的集合
    ...
end function;
```

###### 6.2.1.1.22 应仅能使用 range、length、left、right、high、low、reverse_range 和 event 属性。

**违背示例：**

```vhdl
if (not CLK'stable and CLK = '0') then -- 违背：使用了属性stable
    q <= d;
end if;
```

###### 6.2.1.1.23 在 RTL 描述中不应使用配置（configuration）。

在RTL描述中使用配置，可能导致逻辑综合的问题。

**违背示例：**

```vhdl
architecture struc of model is
    for inst1: gate_xor use -- 违背1：使用了配置
    entity work.gate_xor(beh)
    port map(in1 => in1, in2 => in2, gout => gout);
    for inst2: gate_and use -- 违背2：使用了配置
    entity work.gate_and(beh)
    port map(in1, open, gout);
begin
    lable1 : gate_xor port map(a, b, res);
    lable2 : gate_and port map(a, b, c);
end struc;
```

###### 6.2.1.1.24 在 RTL 描述中不应使用存取（access）类型。

**违背示例：**

```vhdl
type int_pointer is access integer; -- 违背：在RTL描述中使用了存取类型access
```

###### 6.2.1.1.25 在 RTL 描述中不应使用别名（alias）类型。

**违背示例：**

```vhdl
entity model is
    ...
end model;

architecture rtl of model is
    signal word : std_logic_vector(15 downto 0);
    alias low_byte is word(7 downto 0); -- 违背：使用了别名alias
    ...
begin
    ...
end rtl;
```

###### 6.2.1.1.26 RTL 描述中不应在信号赋值中使用波形。

**违背示例：**

```vhdl
s <= reject 15 ns inertial 8 after 20 ns，16 after 41 ns; -- 违背：使用了波形
```

###### 6.2.1.1.27 RTL 描述中应不使用共享变量（shared variable）。

**违背示例：**

```vhdl
entity model is
    ...
    shared variable var1 : bit; -- 违背1：实体model中包括1个共享变量
end model;

architecture rtl of model is
    shared variable var2 : integer; -- 违背2：结构体beh中包括1个共享变量
    ...
begin
    process ( ... )
        variable var3 : bit;
    begin
        ...
    end process;
    ...
end rtl;
```

###### 6.2.1.1.28 在 RTL 描述中应不使用过程（procedure）。

过程描述支持多重输出且对信号立即赋值，此行为在综合后将不可预计。

**违背示例：**

```vhdl
entity model is
    ...
end model;
architecture rtl of model is
    procedure proc(
        din : in bit_vector(31 downto 0);
        res1 : out bit;
        res2 : out bit
    ) is
    begin
        ...
    end;
begin
    process(...)
    begin
        proc(d, q1, q2);  -- 违背：使用了过程procedure
        ...
    end process;
end rtl;
```

###### 6.2.1.1.29 不应在整数、实数和无符号整数之间使用隐式转换。

在整数、实数、无符号整数任何两种类型之间进行隐式转换。

**遵循示例：**

```vhdl
...
    signal u1 : unsigned(3 downto 0);
    signal int1 : integer range 0 to 15;
    ...

    int1 <= to_integer(u1); -- 遵循：使用转换函数进行不同数据类型之间的转换
    ...
```

**违背示例：**

```vhdl
...
signal u1 : unsigned(3 downto 0);
signal int1 : integer range 0 to 15;
...
int1 <= u1; -- 违背：将无符号数隐式转化为整数
...
```

##### 6.2.1.2 推荐类

###### 6.2.1.2.1 顶层模块宜只进行模块例化。

层次型设计要求顶层为内部的互连和模块的调用，尽量避免再形成胶合逻辑，有利于更有效的综合。

###### 6.2.1.2.2 条件信号赋值语句（when....else）不宜超过 5 级。

条件赋值语句的级数影响生成电路的性能。当一个 when-else 语句级数过深时，逻辑综合工具会生成复杂的、带优先级的逻辑，且电路规模会显著增大。

**违背示例：**

```vhdl
architecture arch of e_enc is
begin
    -- 违背：条件信号赋值语句有6级
    Q <= "111" when A = "000" else
         "101" when A = "001" else
         "110" when A = "010" else
         "011" when A = "011" else
         "010" when A = "100" else
         "000";
end arch;
```

###### 6.2.1.2.3 不宜在函数内条件语句的分支处返回。

使用临时变量计算变量结果后，在函数定义的末尾返回，可提高代码的可读性及可维护性。

**违背示例：**

```vhdl
function ar_prog (a : in integer) return integer is
begin
    if(a > 0) then
        return ar_prog(a - 1) + a; -- 违背1：使用了返回语句
    else
        return a; -- 违背2：使用了返回语句
    end if;
end function;
```

###### 6.2.1.2.4 宜使用 std_logic 或 std_logic_unsigned。

“numeric_std”是类似于 std_logic_arith 的 IEEE 标准包，但目前部分工具可能不支持，所以不推荐使用。

宜通过链接基本包（“ieee.std_logic_arith”或“ieee.std_logic_ unsigned”）来使用标准类型向量的算术操作和类型转换功能

**违背示例：**

```vhdl
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all; -- 违背：实体DFF使用了ieee_numeric_std
entity DFF is
    ...
end DFF;
```

###### 6.2.1.2.5 在 RTL 描述中不宜使用块（block）。

RTL中的块语句依赖于工具或描述风格，其中卫式语句和块不被综合工具支持，因此在RTL描述中不宜使用。

**违背示例：**

```vhdl
entity model is
    ...
end model;
architecture rtl of model is
    ...
begin
    block1 : block is -- 违背1：使用了块语句block
    begin

        block2 : block is -- 违背2：使用了块语句block
        begin
        ...
        end block block2;
        ...
    end block block1;
end rtl;
```

###### 6.2.1.2.6 RTL 描述中不宜使用记录（record）。

记录的特点是具有不同的数据类型单元。一般，这些数据类型单元在综合过程中会被分割至单一模块中，所以记录无法一直被逻辑综合工具支持，更多时候会被用于仿真而不是综合。

**违背示例：**

```vhdl
entity model is
    ...
end model;

architecture rtl of model is
    type date is record -- 违背：使用了记录record
        day : integer;
        month : string(1 to 10);
    end record;
    signal curr_day : date;
    ...
begin
    ...
end rtl;
```

###### 6.2.1.2.7 RTL 描述中不宜使用 bus 和 register 类型。

大多数的逻辑综合工具不支持 bus、register 类型，在 RTL 描述中不建议使用。

**违背示例：**

```vhdl
entity model is
    ...
end model;
architecture rtl of model is
    signal pulled_up : bit bus; -- 违背1：使用了bus类型
    signal dyn_storage : bit register; -- 违背2：使用了register类型
    ...
begin
    ...
end rtl;
```

###### 6.2.1.2.8 例化时未使用的输出端口宜采用“open”说明。

例化时，如存在不需使用的输出端口，宜采用“open”说明。

**遵循示例：**

```vhdl
component example_ent is
port(
    a_in : in std_logic;
    b_in : in std_logic;
    c_out : out std_logic;
    d_out : out std_logic
);
end component;

example_ent_inst : example_ent
port map(
    a_in => s_a,
    b_in => s_b,
    c_out => s_c,
    d_out => open -- 遵循：未使用的端口采用open说明
);
```

###### 6.2.1.2.9 宜在约束文件中对设计的每个时钟进行定义并添加周期约束。

宜在约束文件中对设计的每个时钟进行定义，并设置其时钟周期。

#### 6.2.2 组合逻辑

##### 6.2.2.1 强制类

###### 6.2.2.1.1 避免生成锁存器。

在组合逻辑的进程块中，信号应在每个可能的分支均赋值，避免生成不期望的锁存器。

**违背示例：**

```vhdl
process(g_op, a, b, c)
begin
    if(g_op) then -- 违背：信号y没有在所有条件下赋值，可能会生成锁存器
        y <= a and b and c;
    end if;
end process;
```

###### 6.2.2.1.2 组合逻辑进程语句中不应使用 wait 语句。

wait 语句不应用于进程语句。尽管 wait 能够声明触发器，但不支持使用这种描述方法，以避免造成混淆。

**违背示例：**

```vhdl
process begin
    YOUT <= A and B;
    wait on A,B; -- 违背：使用了wait 语句
end process;
```

##### 6.2.2.2 推荐类

###### 6.2.2.2.1 在 RTL 描述中不宜使用 with-select。

RTL 描述中不宜使用with-select。

不推荐使用并发信号选择赋值。在一个进程内，可使用等价描述来替代 with-select。

#### 6.2.3 时序逻辑

##### 6.2.3.1 强制类

###### 6.2.3.1.1 同一进程只应使用单一时钟，单一沿。

**违背示例 1：**

```vhdl
process(clk1, clk2)
begin
    if(clk1'event and clk1 = '1') then -- 违背1：同一进程使用两个时钟clk1和clk2
        D <= Q;
    end if;
    if(clk2'event and clk2 = '1') then -- 违背2：同一进程使用两个时钟clk1和clk2
        D <= Q;
    end if;
end process;
```

**违背示例 2：**

```vhdl
process(clk)
begin
    if(clk'event and clk = '1') then -- 违背1：同一进程使用clk上升沿和下降沿
        D <= Q;
    end if;
    if(clk'event and clk = '0') then -- 违背2：同一进程使用clk上升沿和下降沿
        D <= Q;
    end if;
end process;
```

###### 6.2.3.1.2 描述时钟事件时不应使用 wait 语句。

VHDL可使用if语句和wait语句等两种方式描述触发器。基于if语句的描述风格更清晰和准确。因为无法使用wait语句描述异步复位，所以不应采用wait语句描述触发器。

**违背示例：**

```vhdl
process begin
    wait until rising_edge(clk); -- 违背：基于wait语句描述的触发器
        Q <= data;
    if(sync_set = '1') then
        Q <= '1';
    end if;
end process;
```

##### 6.2.3.2 推荐类

###### 6.2.3.2.1 触发器的输入不宜为常数。

触发器避免输入固定值，由此可避免设计测试工具出错。否则执行扫描逻辑转化为扫描触发器时，扫描可能无法正确执行。

**违背示例：**

```vhdl
process(START, RESET_X)
begin
    if(RESET_X = '0') then
        Q <= '0';
    elsif(START'event and START = '1') then
        Q <= '1'; -- 违背：触发器输入固定值
    end if;
end process;
```

![输入端固定为常数的触发器](vhdl-111-figures/p20-01.png)

###### 6.2.3.2.2 在时序逻辑声明中宜使用信号赋值，不宜使用变量赋值。

对于可综合代码，宜使用信号而不是变量来确保 RTL 和门级仿真的一致。在顺序 VHDL 块中，使用变量不一定会生成寄存器。

**遵循示例 1：**

```vhdl
process(clk)
    begin
        if(clk'event and clk = '1') then
            B <= A;
            C <= B; -- 遵循：使用信号赋值
        end if;
    end process;
```

![遵循示例 1 的时序电路](vhdl-111-figures/p21-01.png)

**违背示例 1：**

```vhdl
process(clk)
    variable B : std_logic;
begin
    if(clk'event and clk = '1') then
        B := A;
        C <= B; -- 违背：变量赋值给触发器，未生成寄存器
    end if;
end process;
```

![违背示例 1 的时序电路](vhdl-111-figures/p21-02.png)

**违背示例 2：**

```vhdl
process(clk)
    variable B : std_logic;
begin
    if(clk'event and clk = '1') then
        C <= B; -- 违背：变量赋值给触发器，生成寄存器
        B := A;
    end if;
end process;
```

![违背示例 2 的时序电路](vhdl-111-figures/p21-03.png)

#### 6.2.4 三态缓冲器

##### 6.2.4.1 强制类

###### 6.2.4.1.1 除三态以外，不应使用多重驱动。

除非使用三态，否则一个信号不能同时有两个以上（含两个）的驱动。

**违背示例：**

```vhdl
architecture rtl of top is
    signal DS_STATUS : std_logic;
begin
    ...
    DS_STATUS <= C_RS; -- 违背1：信号DS_STATUS非三态驱动1，使用了多重驱动
    ...
    DS_STATUS <= F_RS; -- 违背2：信号DS_STATUS非三态驱动2，使用了多重驱动
    ...
end rtl;
```

###### 6.2.4.1.2 不应将 inout 信号直接连接至声明为 input 或 output 的信号。

将inout信号直接连接至input或output信号时，逻辑综合会生成一些在RTL描述中不存在的路径，造成RTL和门级行为不一致。

**违背示例：**

```vhdl
library ieee;
use ieee.std_logic_1164.all;

entity top is
port(
    in1 : in std_logic;
    enb: in std_logic;
    out_data: out std_logic;
    io: inout std_logic
);
end entity;

architecture rtl of top is
begin
    io <= in1; -- 违背1：inout端口io直接连接到输入端口
    out_data <= io; -- 违背2：inout端口io直接连接到输出端口
end rtl;
```

###### 6.2.4.1.3 不应将三态信号作为 if 表达式的条件判断。

为满足 RTL 和门级仿真一致性的需求，应考虑三态信号中 x 值的传递。当一个被用于 if 表达式的条件判断语句信号值包含 z 值，将执行 else 分支。通常，通过逻辑门以后 z 值会变成 x 值，但此时将变成一个固定值。所以，传递 x 值会导致 RTL 和门级仿真不一致，因此应避免使用三态信号作为 if 表达式的条件判断。

**违背示例：**

```vhdl
d_bs <= 'Z' when sel = '0' else chan_a;

process(...)
begin
    if(d_bs = '1') then -- 违背：使用了三态信号d_bs作为if表达式的条件判断
        ...
    else
        ...
    end if;
end process;
```

###### 6.2.4.1.4 禁止使用内部三态。

##### 6.2.4.2 推荐类

###### 6.2.4.2.1 不宜使用组合逻辑的输出控制三态门。

组合逻辑易由于竞争冒险产生毛刺，不宜使用组合逻辑输出作为使能控制三态门。

**违背示例：**

```vhdl
entity example_ent is
port(
    a_in : in std_logic;
    b_in : in std_logic;
    d_in : in std_logic;
    d_out : out std_logic
);
end example_ent;
...
signal S_c : std_logic;
S_c <= a_in xor b_in;
d_out <= d_in when S_c = '0' else 'Z'; -- 违背：使用组合逻辑的输出控制三态门
```

###### 6.2.4.2.2 三态节点的使能端和输入端不宜被同一信号源驱动。

#### 6.2.5 进程

##### 6.2.5.1 强制类

###### 6.2.5.1.1 不应在一个进程中使用多个 event control 段。

当 process 语句存在多个 event control 段时，会造成不同综合工具的综合差异，不利于代码的移植。

**违背示例：**

```vhdl
 ...
signal S_a : std_logic;
signal S_b : std_logic;
signal S_r : std_logic;
...
process(S_a,S_b)
begin
    if(S_a’event and S_a = '1') then
        if(S_b’event and S_b = '1') then -- 违背：在一个进程中使用了多个event control段
            S_r = S_a xor S_b;
        end if;
    end if;
end process;
```

##### 6.2.5.2 推荐类

###### 6.2.5.2.1 一个单独的进程包含的语句不宜超过 200 条。

为提高代码可读性，宜保持每一个单独的进程结构中语句数不多于 200 条。

**违背示例：**

```vhdl
-- line #270
process(...)
begin
    ...  -- 违背：进程语句有284行
--  line #554
end process;
```

###### 6.2.5.2.2 在同一个进程中的组合逻辑中，不宜引用一个被赋值的信号。

同一组合逻辑中，一个信号不宜既被赋值又被引用。否则，不仅降低代码可读性，而且会降低仿真效率。

**违背示例：**

```vhdl
process(Data_in， Data_accum)
begin
    temp <= Data_in;  -- 违背1：信号temp在同一进程中被赋值和引用
    Q <= Data_accum + temp; -- 违背2：信号temp在同一进程中被赋值和引用
end process;
```

###### 6.2.5.2.3 不宜在同一个进程声明中使用多重 if 或 case 语句。

同一进程中使用多重 if 或 case 语句时，如果这些语句之间存在关联，由于进程语句的顺序处理，可能生成不必要的优先级电路。为了避免此问题，可将每一个块置于独立的进程中。

**违背示例：**

```vhdl
process(SEL, X_IN, Z_IN, TMP_STORAGE)
begin
    -- if语句在顺序块中。
    if(SEL = '1') then
        TMP_STORAGE <= X_IN + Z_IN;
    else
        TMP_STORAGE <= X_IN - Z_IN;
    end if
    LO_B = TMP_STORAGE[31];

    if(TMP_STORAGE(7 downto 0) = X"00") then -- 违背1：同一个顺序块描述2个以上的if或case语句
        Z_REG <= '1';
    else
        Z_REG <= '0';
    end if
    if(LO_B = '1' and Z_REG = '0') then -- 违背2：同一个顺序块描述2个以上的if或case语句
        X_REG <= '1';
    else
        X_REG <= '0';
    end if

    R_REG <= TMP_STORAGE(30 downto 0);
end process;
```

#### 6.2.6 分支语句

##### 6.2.6.1 强制类

###### 6.2.6.1.1 禁止描述各种配置模式下均不可能执行的条件。

永远不会被执行的代码往往是潜在错误产生的根源。

###### 6.2.6.1.2 在 case 声明中描述状态不全的情况下应有‘others’分支。

应描述 case 语句中选择表达式所有可能的状态，否则应提供 others 选项，并在 case 语句所有状态均无法满足时执行，因此应增加 others 选项，以避免什么都不执行的状况出现。

**违背示例：**

```vhdl
case sel is -- 违背：case描述不全时，缺少others分支
    when "0001" => out1 <= "00";
    when "0010" => out1 <= "01";
    when "0100" => out1 <= "10";
    when "1000" => out1 <= "11";
end case;
```

###### 6.2.6.1.3 case 语句的所有分支表达式数据位宽应一致。

###### 6.2.6.1.4 case 语句的分支不应使用变量或者变量表达式。

**违背示例：**

```vhdl
case(Va) is
    when "01" : Vb = Va;
    when "10" : Vb = Va + 1;
    when "Vc + Vd" : Vb = 1; -- 违背：使用变量或者变量表达式作为case语句的分支
    ...
end case
```

#### 6.2.7 循环语句

##### 6.2.7.1 强制类

###### 6.2.7.1.1 禁止在 for 循环的循环体中修改循环变量。

**违背示例：**

```vhdl
SUM : for i in 1 to 3 loop
   i := i + 1; -- 违背：在循环体内修改循环变量
end loop SUM;
```

###### 6.2.7.1.2 for 循环的起始和终止条件应为常量。

**遵循示例：**

```vhdl
SUM : for i in 1 to 3 loop – 遵循：用于控制循环终止条件的参数为常量
    sum := sum + i;
end loop SUM;
```

###### 6.2.7.1.3 应避免死循环。

无限循环的代码无法进行综合。

###### 6.2.7.1.4 复位部分和逻辑部分禁止出现在同一个 for 循环中。

**遵循示例：**

```vhdl
process(clk, nrst) is
begin
     if(nrst = '0') then
         for i in 0 to 3 loop -- 遵循：复位部分使用单独for循环
              out[i] <= '0';
         end loop;
     elsif(clk'event and clk = '1') then
         for i in 0 to 3 loop -- 遵循：逻辑部分使用单独for循环
              out[i] <= in[i];
         end loop;
     end if;
end process;
```

**违背示例：**

```vhdl
process(clk, nrst) is
begin
     for i in 0 to 3 loop -- 违背：复位部分和逻辑部分出现在同一个for循环
         if(nrst = '0') then
              out[i] <= '0';
         elsif(clk'event and clk = '1') then
              out[i] <= in[i];
         end if;
     end loop;
end process;
```

###### 6.2.7.1.5 在 for 循环中不应使用 exit 和 next 循环控制语句。

**违背示例：**

```vhdl
process(DIN,MODE)
    variable F : std_logic;
begin
    F := '0';
    for I in 0 to 3 loop
        if(MODE = '1' and I < 2) then
            next; -- 违背：使用了next循环控制语句来控制循环
        end if;
        F := F xor DIN(I);
    end loop;
    DOUT <= F;
end process;
```

##### 6.2.7.2 推荐类

###### 6.2.7.2.1 在 RTL 描述中不宜使用 while 循环。

循环次数应是确定的（循环数量应被预先定义或声明），如循环次数不确定或由动态生成，将不可综合。使用 while 循环时，退出循环的条件通常无法用于计算循环次数，将导致不可综合，所以不推荐使用，而推荐使用 for 循环（for 循环的次数是确定的，但也应遵循一些限制条件）。

**违背示例：**

```vhdl
variable res : integer := '1';

while(i < expon) loop -- 违背：在RTL描述中使用了不可综合的while循环
    res := res * arg;
    i := i + 1;
end loop;
```

###### 6.2.7.2.2 不宜使用 for 语句对非循环变量或常量进行算术运算。

for 语句中包含非循环变量和常数的数学运算时，会极大地增加数学运算面积，若必须使用需经过谨慎评估。

**遵循示例：**

```vhdl
TMP <= SIG_A + SIG_B; -- 遵循：将数学运算放置在循环体外
for i in 0 to 15 loop
    SIG_Z(i) <= TMP;
end loop;
```

**违背示例：**

```vhdl
for i in 0 to 15 loop -- 违背：包含非循环变量或常数的数学运算，需要16倍数学运算面积
    SIG_Z(i) <= SIG_A + SIG_B;
end loop;
```

#### 6.2.8 操作符

##### 6.2.8.1 强制类

###### 6.2.8.1.1 不应比较 X、Z、U、-、W、H、L 及？值。

尽管 RTL 仿真支持 X、Z、U、-、W、H、L 及？值的比较，但逻辑综合工具会忽略对这些值的比较，导致 RTL 和门级仿真的差异。

**违背示例 1：**

```vhdl
if(A = "XX") then -- 违背：使用了"XX"进行比较，会造成RTL和门级仿真的不一致
   ...
end if;
```

**违背示例 2：**

```vhdl
entity top_ent is
port(
    D_in : in std_logic;
    D_out : out std_logic
);
end top_ent;
...
signal S_Ctrl_in : std_logic;
...

D_out <= D_in when S_Ctrl_in = ’Z’ else ’1’; -- 违背：条件表达式中使用"Z"状态进行判断
...
```

**违背示例 3：**

```vhdl
entity top_ent is
port(
    D_in : in std_logic;
    D_out : out std_logic
);
end top_ent;
...
signal S_Ctrl_in : std_logic_vector(2 downto 0);
...

D_out <= D_in when (S_Ctrl_in = "1? 0") else ’1’; -- 违背：条件表达式中应使用"?"状态进行判断
...
```

###### 6.2.8.1.2 不应给信号赋值“X”。

赋值X被视为不关心（don’t-care），逻辑综合工具将生成带有未知值的电路（0或1），导致RTL和门级仿真结果不一致，应避免这种危险的描述。

**违背示例：**

```vhdl
entity ENCODER is
port(
    A : in std_logic_vector(7 downto 0);
    Y : out std_logic_vector(2 downto 0)
);
end ENCODER;
architecture RTL of ENCODER is
begin
    process (A) begin
        case A is
            when "01111111" => Y <= "000";
            when "10111111" => Y <= "001";
            when "11011111" => Y <= "010";
            when "11101111" => Y <= "011";
            when "11110111" => Y <= "100";
            when "11111011" => Y <= "101";
            when "11111101" => Y <= "110";
            when "11111110" => Y <= "111";
            when others => Y <= "XXX"; -- 违背：使用‘X’将带有生成未知值的电路
        end case;
    end process;
end RTL;
```

![向信号赋值 X 的示例电路](vhdl-111-figures/p27-01.png)

###### 6.2.8.1.3 不应在算数操作中使用包含 X、Z 值。

**违背示例：**

```vhdl
entity basic_ent is
port(
    clk : in std_logic;
    reset : in std_logic;
     a : in std_logic_vector(3 downto 0);
    b : out std_logic_vector(3 downto 0)
);
end basic_ent;

architecture rtl of basic_ent is
begin
    process(clk, reset)
    begin
        if(reset = '1') then
            b <= (others => '1');
        elsif(clk'event and clk = '1') then
            b <= a + 'X'; -- 违背：算数运算中使用了'X'
        end if;
    end process;
end rtl;
```

###### 6.2.8.1.4 进行关系运算的操作数位宽应一致。

如果关系操作数位宽不同，位宽较窄的操作数会填充 0，这种扩展容易导致误解和错误。

**违背示例：**

```vhdl
entity basic_ent is
port(
    A : in std_logic_vector(3 downto 0);
    B : in std_logic_vector(3 downto 0);
    Q : out std_logic_vector(1 downto 0)
);
end basic_ent;
architecture rtl of basic_ent is
begin
    basic_block : block is begin
        process(A) is
            variable T : std_logic_vector(5 downto 1);
            variable W : std_logic_vector(15 downto 1);
            variable R : boolean;
            variable E : std_logic_vector(10 downto 1);
        begin
            if(T = E) then -- 违背1："="右边10位与左边5位宽度不一致
                Q <= "11";
            elsif((W <= E) >= R) then -- 违背2："<="右边10位与左边15位宽度不一致
                Q <= "00";
            end if;
        end process;
    end block;
end rtl;
```

###### 6.2.8.1.5 位操作符左右两端位宽应一致。

**遵循示例：**

```vhdl
signal a : std_logic_vector(7 downto 0);
signal b : std_logic_vector(7 downto 0);
signal c : std_logic_vector(7 downto 0);
c <= a or b; -- 遵循：按位or运算左右两端位宽不一致，均为8位
```

**违背示例：**

```vhdl
signal a : std_logic_vector(7 downto 0);
signal b : std_logic_vector(5 downto 0);
signal c : std_logic_vector(7 downto 0);
c <= a or b; -- 违背：按位or运算左右两端位宽不一致，左端为8位，右端为6位
```

###### 6.2.8.1.6 在有符号数学运算中，应保证每一个有符号操作数都与目的数位宽一致。

有符号数学运算时注意符号位扩展和位宽。

**违背示例：**

```vhdl
entity ad_bs is
port(
    A : in signed(3 downto 0);
    B : in signed(3 downto 0);
    SUM : out signed(4 downto 0)
);
end entity;
architecture rtl of ad_bs is
begin
    SUM <= A + B; -- 违背：有符号数表达式宽度为4，小于赋值目标的位宽5
end rtl;
```

###### 6.2.8.1.7 不应在同一条语句中混用有符号操作数和无符号操作数。

应注意符号数和无符号数之间的操作，清晰区分有符号数和无符号数的数学运算，避免混乱及位宽调整引入的潜在问题。

**违背示例：**

```vhdl
entity add_s is
port(
    arg_a : in unsigned(2 downto 0);
    arg_b : in signed(2 downto 0);
    y_out : out std_logic_vector(2 downto 0)
);
end add_s;
architecture rtl of add_s is
begin
    y_out <= arg_a + arg_b; -- 违背：混用了符号操作数和符号操作数
end rtl;
```

###### 6.2.8.1.8 常量赋值右端应为固定值或已经定义的常量，不应为变量表达式。

设计中所有的常量应为固定值或已经定义的常量，否则被声明或赋值的常量在编译期间无法参与计算。

##### 6.2.8.2 推荐类

###### 6.2.8.2.1 除非操作数为 2，否则不宜使用/、mod、rem、`**`、abs 操作符。

绝大多数逻辑综合工具不支持除“/”，所以不宜使用。除非是除以2的幂（如2、4、8、16），因只有一个移位操作，所以可使用除。当“`**`”操作符左边的操作数是2时也可使用。

**违背示例：**

```vhdl
procedure pow2 (x : integer; y : out integer) is
begin
    y := x ** 2; -- 违背：使用了**操作符，左边操作数不是常数2
end pow2;
```

###### 6.2.8.2.2 宜使用 std_logic_vector(conv_unsigned(ARG ， SIZE)) 将 integer 转换为 std_logic_vector。

宜在RTL描述中使用conv_std_logic_vector函数，为保证与其他编译器（如Design Compiler）兼容，宜使用std_logic_vector(conv_unsigned(ARG， SIZE))将integer转换为std_logic_vector。

**遵循示例：**

```vhdl
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
constant A_INT : integer := 129;
signal C : std_logic;

C <= std_logic_vector(conv_unsigned(A_INT, 8)); -- 遵循：使用std_logic_vector (conv_unsigned(,))
```

**违背示例：**

```vhdl
constant A_INT : integer := 129;
signal C : std_logic;

C <= conv_std_logic_vector(A_INT, 8); -- 违背：使用了conv_std_logic_vector
```

###### 6.2.8.2.3 VHDL’93 中不宜使用 To_stdlogicvector 函数。

VHDL’87中只有bit_vector支持符号系统“x”。从VHDL’93开始，std_logic_vector也支持符号系统“x”。因此无法判断“x”为std_logic_vector或bit_vector。

**违背示例：**

```vhdl
Q <= To_StdLogicVector(X"3F");-- 违背：使用了To_stdlogicvector函数
```

###### 6.2.8.2.4 信号和变量宜在赋值后使用。

信号在使用前应赋值，以保证其使用时具有确定的状态。

**违背示例：**

```vhdl
entity example_ent is
port(
    SEL_in : in std_logic;
    DATA_out : out std_logic
);
end example_ent;

architecture rtl of example_ent is
    signal S_tmp : std_logic;
begin
    process(SEL_in,S_tmp)
    begin
        if(SEL_in = '1') then
            DATA_out <= S_tmp; -- 违背：S_tmp信号在使用前没有赋值
        else
            DATA_out <= '0';
        end if;
    end process;
end rtl;
```

#### 6.2.9 状态机

##### 6.2.9.1 强制类

###### 6.2.9.1.1 状态机在上电时应进入明确的初始状态。

应使用全局复位信号使状态机初始化为已知的合法状态。

**遵循示例：**

```vhdl
process(rst_n, clk)
begin
    if(rst_n = ’0’) then
       current_state_r <= IDLE; -- 遵循：状态机初始化为IDLE状态
    elsif(rising_edge(clk)) then
        ...
    end if;
end process;
```

###### 6.2.9.1.2 状态机应处理所有状态。

###### 6.2.9.1.3 状态机禁止出现死锁状态和不可达状态。

###### 6.2.9.1.4 应对状态机综合属性进行适当的设置，确保对无效状态的处理综合有效。

对状态机综合属性进行适当的设置，确保状态机综合后包含对无效状态的处理，可通过在综合设置中通过勾选安全模式或代码中增加综合属性约束等方式进行设置。

**遵循示例：**

```vhdl
type state is (s0,s1,s2,s3,s4,s5);
signal nstate : state;
signal cstate : state;

attribute syn_encoding of cstate : signal is "safe,gray"; -- 遵循：合理增加综合属性设置
```

###### 6.2.9.1.5 不应使用 enum_encoding 属性分配状态。

VHDL 的 FSM 不应为状态分配而采用枚举类型定义状态，应根据需要在综合时选择状态分配方式，避免对逻辑综合工具的依赖。

**违背示例：**

```vhdl
library synopsys;
use synopsys.attributes.all;

package FSM is
    type FSM_states is (start, stop, next_digit);
    attribute enum_encoding of FSM_states: type is "100 010 001"; -- 违背：使用了enum_encoding
end package;
```

##### 6.2.9.2 推荐类

###### 6.2.9.2.1 状态机宜使用三个进程：时序逻辑进程定义现态寄存器、组合逻辑进程定义次态逻辑、组合逻辑进程定义输出逻辑。

**遵循示例：**

```vhdl
-- 五状态mealy状态机：
library ieee;
use ieee.std_logic_1164.all;

entity mealy is
port(
    clock : in std_logic;
    reset : in std_logic;
    data_out : out std_logic;
    data_in : in std_logic_vector(1 downto 0)
);
end mealy;

architecture behave of mealy is
    type state_values is (st0, st1, st2, st3, st4);
    signal pres_state : state_values;
    signal next_state : state_values;
begin

     statereg: process(clock, reset) -- 遵循1：时序逻辑进程定义现态寄存器
     begin
          if(reset = '0') then
               pres_state <= st0;
          elsif(clock'event and clock ='1') then
               pres_state <= next_state;
          end if;
     end process statereg;


    fsm: process(pres_state, data_in) -- 遵循2：组合逻辑进程定义次态逻辑
    begin
        case pres_state is
            when st0 =>
                case data_in is
                    when "00" => next_state <= st0;
                    when "01" => next_state <= st4;
                    when "10" => next_state <= st1;
                    when "11" => next_state <= st2;
                    when others => next_state <= st0;
                end case;
            when st1 =>
                case data_in is
                    when "00" => next_state <= st0;
                    when "10" => next_state <= st2;
                    when others => next_state <= st1;
                end case;
            when st2 =>
                case data_in is
                    when "00" => next_state <= st1;
                    when "01" => next_state <= st1;
                    when "10" => next_state <= st3;
                    when "11" => next_state <= st3;
                    when others => next_state <= st1;
                end case;
            when st3 =>
                case data_in is
                    when "01" => next_state <= st4;
                    when "11" => next_state <= st4;
                    when others => next_state <= st3;
                end case;
            when st4 =>
                case data_in is
                    when "11" => next_state <= st4;
                    when others => next_state <= st0;
                end case;
            when others =>
                next_state <= st0;
        end case;
    end fsm;

    outputs: process(pres_state, data_in) -- 遵循3：组合逻辑进程定义输出逻辑
    begin
        case pres_state is
            when st0 =>
                case data_in is
                    when "00" => data_out <= '0';
                    when others => data_out <= '1';
                end case;
            when st1 =>
                data_out <= '0';
            when st2 =>
                case data_in is
                    when "00" => data_out <= '0';
                    when "01" => data_out <= '0';
                    when others => data_out <= '1';
                end case;
            when st3 =>
                data_out <= '1';
            when st4 =>
                case data_in is
                    when "10" => data_out <= '1';
                    when "11" => data_out <= '1';
                    when others => data_out <= '0';
                end case;
            when others =>
                data_out <= '0';
        end case;
    end outputs;
end behave;.
```

#### 6.2.10 ASIC 可测试设计

##### 6.2.10.1 强制类

###### 6.2.10.1.1 时钟应能被外部输入端口直接控制。

**违背示例：**

```vhdl
entity dff is
port (
    clk : in std_logic;
    data : in std_logic;
    q : out std_logic
);
end dff;
architecture basic of dff is
begin
    process(clk) is
    begin
        if(clk'event and clk = '1') then
            q <= data;
        end if;
    end process;
end basic;

entity top is
port (
    clk : in std_logic;
    gate : in std_logic;
    data1 : in std_logic;
    data2 : in std_logic;
    out1: out std_logic;
    out2: out std_logic
);
end top;

architecture basic of top is
    signal clk_gate : std_logic;
begin
    clk_gate <= clk or gate;

    u_dff_1 : entity dff
    port map(
        clk => clk,
        data => data1,
        q => out1
    );

    u_dff_2 : entity dff
    port map(
        clk => clk_gate, -- 违背：时钟输入无法直接被外部输入的控制
        data => data2,
        q => out2
    );
end basic;
```

###### 6.2.10.1.2 从多个不同时钟系统进行选择时，在测试过程中应能选择其中一个时钟。

**违背示例：**

```vhdl
entity dff is
port(
    CLK : in std_logic;
    D: in std_logic;
    Q: out std_logic
);
end dff;

architecture basic of dff is
begin
    process(CLK) is
    begin
        if(CLK'event and CLK = '1') then
            Q <= D;
        end if;
    end process;
end basic;

entity mux2x1 is
port (
    IN1 : in std_logic;
    IN2 : in std_logic;
    SEL : in std_logic;
    Q: out std_logic
);
end mux2x1;

architecture basic of mux2x1 is
begin
    process(SEL, IN1, IN2) is
    begin
        if(SEL = '1') then -- 违背1：外部端口无法控制时钟系统的选择
            Q <= IN1;
        else
            Q <= IN2;
        end if;
    end process;
end basic;

entity top is
port(
    CLK1 : in std_logic; -- 违背2：信号top.CLK1是可选的时钟系统
    CLK2 : in std_logic; -- 违背3：信号top.CLK2是可选的时钟系统
    CLK3 : in std_logic;
    SEL : in std_logic;
    D : in std_logic;
    Q1 : out std_logic;
    Q2 : out std_logic
);
end entity;

architecture basic of top is
    signal mux_out : std_logic;
    signal D_n : std_logic;
    signal ff_out : std_logic;
begin
    D_n <= not D;
    DFF1 : entity dff
    port map(
        CLK => mux_out,
        D => D_n,
        Q => Q1
    );
    DFF2 : entity dff
    port map(
        CLK => mux_out,
        D => D,
        Q => Q2
    );
    DFF3 : entity dff
    port map(
        CLK => CLK3,
        D => SEL,
        Q => ff_out
    );
    MUX : entity mux2x1
    port map(
        IN1 => CLK1,
        IN2 => CLK2,
        SEL => ff_out,
        Q => mux_out
    );
end basic;
```

![多个时钟系统的选择电路](vhdl-111-figures/p35-01.png)

###### 6.2.10.1.3 复位应能被外部输入端口直接控制。

**违背示例：**

```vhdl
entity dff is
port(
    clk : in std_logic;
    rst : in std_logic;
    data : in std_logic;
    q : out std_logic
);
end dff;

architecture basic of dff is
begin
    process(clk, rst) is
    begin
        if(rst) then
            q <= '1';
        elsif(clk'event and clk = '1') then
            q <= data;
        end if;
    end process;
end basic;

entity top is
port(
    clk : in std_logic;
    rst : in std_logic;
    gate : in std_logic;
    data1 : in std_logic;
    data2 : in std_logic;
    out1 : out std_logic;
    out2 : out std_logic
);
end top;

architecture basic of top is
    signal rst_gate : std_logic;
begin
    rst_gate <= rst and gate;

    dff_1 : entity dff
    port map(
        clk => clk,
        rst => rst,
        data => data1,
        q => out1
    );

    dff_2 : entity dff
    port map(
        clk => clk,
        rst => rst_gate, -- 违背：异步复位无法直接被外部输入端口控制
        data => data2,
        q => out2
    );
end basic;
```

###### 6.2.10.1.4 不应混合使用时钟和复位。

**违背示例：**

```vhdl
entity dff is
port (
    D : in std_logic;
    CLK : in std_logic;
    RESET : in std_logic;
    Q : out std_logic
);
end dff;

architecture dff_rtl of dff is
begin
    process(CLK, RESET) is
    begin
        if(RESET) then
            Q <= '1';
        elsif(RISING_EDGE(CLK)) then
            Q <= D;
        end if;
    end process;
end dff_rtl;

entity mux is
port(
    in1 : in std_logic;
    in2 : in std_logic;
    sel : in std_logic;
    out1 : out std_logic
);
end mux;

architecture mux_rtl of mux is
begin
    out1 <= in1 when sel = '1' else in2;
end mux_rtl;

entity top is
port (
    in1 : in std_logic;
    in2 : in std_logic;
    in3 : in std_logic;
    clk1 : in std_logic;
    clk2 : in std_logic;
    reset : in std_logic;
    sel : in std_logic;
    out1 : out std_logic;
    out2 : out std_logic
);
end entity;

architecture top_rtl of top is
    signal mux_to_ff1 : std_logic;
    signal mux_to_ff2 : std_logic;
begin
    mux_to_ff2 <= clk1 when sel = '1' else in3;

    MUX_INSTANCE : entity mux
    port map(
        in1 => clk1,
        in2 => in2,
        sel => sel,
        out1 => mux_to_ff1
    );
    DFF_INSTANCE1 : entity dff -- 违背1：clk1连接到top. DFF_INSTANCE1时钟端
    port map(
        D => in1,
        CLK => mux_to_ff1,
        RESET => reset,
        Q => out1
    );

    DFF_INSTANCE2 : entity dff-- 违背2：clk1连接到top. DFF_INSTANCE2异步复位端
    port map(
        D => in1,
        CLK => clk2,
        RESET => mux_to_ff2,
        Q => out2
    );
end top_rtl;
```

![时钟和复位混用的示例电路](vhdl-111-figures/p38-01.png)

###### 6.2.10.1.5 不应将触发器的输出直接连接至触发器的异步复位端或置位端。

**违背示例：**

```vhdl
entity dff is
port (
    D : in std_logic;
    CLK : in std_logic;
    SET : in std_logic;
    RESET : in std_logic;
    Q : inout std_logic;
    Qn : out std_logic
);
end dff;

architecture dff_rtl of dff is
begin
    process(CLK, SET, RESET) is
    begin
        if(SET = '1') then
            Q <= '1';
        elsif(RESET = '1') then
            Q <= '0';
        elsif(RISING_EDGE(CLK)) then
            Q <= D;
        end if;
    end process;

    Qn <= not Q;
end dff_rtl;

entity top is
port (
    CLK : in std_logic;
    D : in std_logic;
    SET : in std_logic;
    RESET : in std_logic;
    Q : inout std_logic;
    Qn : out std_logic
);
end entity;

architecture top_rtl of top is
    signal CTRL_from_FF1_out : std_logic;
    signal WIRE_from_FF1_out : std_logic;
begin
    U1 : entity dff
    port map(
        CLK => CLK,
        D => D,
        SET => SET,
        RESET => RESET,
        Q => WIRE_from_FF1_out ,
        Qn => CTRL_from_FF1_out
    );
    U2 : entity dff
    port map(
        CLK => CLK,
        D => WIRE_from_FF1_out,
        SET => CTRL_from_FF1_out, -- 违背：异步置位端被触发器top.U1.Q的输出驱动
        RESET => RESET,
        Q => Q,
        Qn =>Qn
    );
end top_rtl;
```

#### 6.2.11 版面设计

##### 6.2.11.1 强制类

###### 6.2.11.1.1 不应出现空模块，每个模块应至少包含一个输入端口和一个输出端口。

**违背示例：**

```vhdl
entity example_ent is
port(
    -- 违背：没有定义端口
);
end example_ent;
```

###### 6.2.11.1.2 不应采用向量的方式定义一组时钟信号。

**违背示例：**

```vhdl
entity fd32 is
port(
    clk : in std_logic_vector(1 downto 0); -- 违背：采用向量的方式定义了一组时钟信号
    nrst : in std_logic;
    d_1 : in std_logic;
    d_2 : in std_logic;
    q_1 : out std_logic;
    q_2 : out std_logic;
);
end fd32;

architecture rtl of fd32 is
begin
    process(clk(0), nrst) is
    begin
        if(nrst = '0') then
            q_1 <= '1';
        elsif(clk(0)'event and clk(0) = '1') then
            q_1 <= d_1;
        end if;
    end process;

     process(clk(1), nrst) is
    begin
        if(nrst = '0') then
            q_2 <= '1';
        elsif(clk(1)'event and clk(1) = '1') then
            q_2 <= d_2;
        end if;
    end process;
end rtl;
```

##### 6.2.11.2 推荐类

###### 6.2.11.2.1 一个文件宜对应一个设计模块。

###### 6.2.11.2.2 模块名和文件名宜保持一致。

模块名和文件名应保持一致，确保文档和代码之间交叉引用以及模块调用例化的正确性。

###### 6.2.11.2.3 向量有效位顺序定义宜从大到小。

---
