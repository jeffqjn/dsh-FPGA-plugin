# Standalone Lint Coordinator Workflow

Use `scripts/standalone_lint_workflow.py` from the skill directory. The driver freezes inputs and validates results. The coordinator operates the host's worker pool and delivers the audit report.

## Commands

Set `<root>` to the project root and `<id>` to a new task ID. Pass a directory in `--source-root` and use repeated `--exclude` patterns as needed to match the requested scope. Every command takes the same project root and task ID. Artifact paths in its JSON output are relative to the project root.

```text
python <driver> prepare --project-root <root> --task-id <id> --source-root <scope> --max-workers 1 --rule-batch-size 10 --rule-batch-bytes 8192
python <driver> dispatch --project-root <root> --task-id <id> --count 1
python <driver> accept-batch --project-root <root> --task-id <id> --assignment-id <assignment> --batch-id <batch>
python <driver> complete --project-root <root> --task-id <id> --assignment-id <assignment>
python <driver> status --project-root <root> --task-id <id>
python <driver> report --project-root <root> --task-id <id>
```

`prepare` selects the bundled Verilog/SystemVerilog or VHDL catalog by file extension and freezes each used ruleset separately. The VHDL catalog uses the numbered rules under chapter 6 of the bundled 航天器产品 VHDL 语言编程约定 and includes local figure paths. Override a catalog with `--rule-file` for Verilog/SystemVerilog or `--vhdl-rule-file` for VHDL. Overrides use the corresponding bundled Markdown structure. Each source gets only its own catalog's rules, and coverage sums the expected pairs across languages.

The command above uses the conservative batch settings for the intranet host. The generic driver defaults are 25 rules and 16 KiB per rule chunk. If a single rule exceeds the selected limit, the driver identifies it before generating the task. Choose a byte budget that fits that rule. The per-source `rule_batches` index contains rule IDs and chunk paths. The full `rule_catalog.json` is for the driver.

## Dispatch and checkpoint

- In the intranet DeepSeek Harness, start with one live child. Collect its result through the host's wait tool or automatic task-result callbacks. Raise `--max-workers` only when the host can reliably collect child results without user input. The driver allows up to eight active assignments. Treat `status.available_slots` as reservation capacity and track live host workers separately.
- Launch one child for the source returned by `dispatch`. Give it the [batch prompt](../assets/templates/worker_prompt.md) with the assignment's `language`, source and first pending batch. Supply only local context needed for the assigned source. For each child response, request only the batch ID and path after its one JSON write. Keep each result within 8,192 UTF-8 bytes and avoid large tool arguments. This leaves room for reasoning under the host's 32,768-token ceiling, which also includes tool arguments.
- On receipt of the child's batch output, run `accept-batch`, then send the next pending batch to the same child. When the host resumes via a task-result callback, recover the active assignment with `status` as needed and continue from its pending batches. Keep callback replies empty or minimal until the report is ready. If neither wait nor automatic continuation is available, record the affected scope as incomplete and report what was accepted. Do not use a user reply as the continuation mechanism.
- Establish top-level status from the request or available project hierarchy before dispatch. Pass the determination with each batch and preserve it across retries. If it is unknown, require `not_verifiable` on top-only rules and review both the applicability and cited evidence before accepting a violation.
- Run `accept-batch` after each result. It checks the current assignment, frozen source and rule inputs, exact batch membership, and result fields, then atomically saves a checkpoint. Repeating acceptance for an already accepted batch on the current active assignment returns `already_accepted`. A corrected unaccepted result can be written to the same assigned path and submitted again.
- When resuming a coordinator session, use `status` to recover active assignment paths and pending batch IDs. The assignment file supplies the corresponding rule and result paths.
- Keep at most one live child per file. Only replace a child when it cannot continue, and only for that same file after accepting its valid results. Use relevant source ranges to control context on large files, while tracing relationships across regions when the rule requires it.
- Run `complete` when all batches are accepted. An assignment with an empty `pending_batches` list can be completed immediately. The driver writes `matrices/<source_id>.json` and marks the source complete. Use `dispatch` when a host slot becomes free.

## Recovery

```text
python <driver> release --project-root <root> --task-id <id> --assignment-id <assignment> --reason "Host worker limit reached before launch"
python <driver> requeue --project-root <root> --task-id <id> --assignment-id <assignment> --kind worker_lost --reason "Worker exited before finishing"
python <driver> unblock --project-root <root> --task-id <id> --source-id <source> --reason "Reduced the work per worker turn"
```

- Use `release` only for a worker that never started, including when the host refuses the spawn. This returns the source to the queue without using its retry allowance. Wait for a slot to free up before trying again when the host reports a capacity limit.
- For a started worker that fails, stop it or confirm it has exited. Inspect its assigned output paths and accept any complete, valid results before calling `requeue`. If every batch is accepted, finish with `complete`. Use `worker_lost` for a worker that disappeared, `invalid_result` for a result the worker could not correct, or `worker_failed` for other execution failures. A new assignment gets new write paths and lists only pending batches. An old assignment's late result cannot replace an accepted checkpoint.
- `--max-requeues` is set during `prepare` and defaults to two retries after the initial execution. An exhausted source becomes `blocked` and prevents global coverage closure. After addressing the failure, use `unblock` with the source ID and a concrete reason. It records the reason and grants extra requeues for that source with `--additional-requeues` (default 1), retaining its accepted batches and previous retry count.
- Recover within existing permissions and the declared output scope. Avoid permission repair, ACL changes, and escalation. Continue with other sources when a source remains blocked. Record unresolved blockers in the final report.

## Report and close

Use `report` as the normal final step. It runs global coverage validation internally and renders the accepted canonical matrices. For incomplete coverage it includes valid accepted checkpoints. It writes `Standalone_Lint_Report.md` and `issue_cards.md` under `reports/standalone_lint/<task_id>/` by generating parts under `parts/` and merging each file locally in part order. The command returns compact JSON with paths and counts. It keeps rule coverage and code compliance distinct and lists `not_verifiable` rows as verification gaps.

Each UTF-8 part is limited to 8,192 bytes by default. `--part-bytes` can lower that cap to 256 bytes. This is a local file budget, independent of the model tokenizer. The script writes and merges the content without sending it through model output. On a host with a 32,768-token output ceiling, pass paths and short options to tools, keep evidence and rationale concise in each audit batch, and deliver the merged file paths with a brief summary. For GLM-5.3 in DeepSeek Harness, start with `prepare --max-workers 1 --rule-batch-size 10 --rule-batch-bytes 8192`.

For a prepared task with unresolved blockers, run `report --blocker "<reason>"` after all possible checks are done. If preparation could not start or report files could not be written, give a short final summary of the available findings, coverage and blocker. Deliver the results without asking questions or waiting for a response. See the [skill's completion conditions](../SKILL.md#coordinator-persistence-and-completion).

Existing tasks prepared with the original whole-matrix workflow can still finish using their original assignment output and `complete`. Start a fresh task ID to use batch checkpoints. The retained PowerShell YAML matrix generator is legacy and outside the Python workflow.
