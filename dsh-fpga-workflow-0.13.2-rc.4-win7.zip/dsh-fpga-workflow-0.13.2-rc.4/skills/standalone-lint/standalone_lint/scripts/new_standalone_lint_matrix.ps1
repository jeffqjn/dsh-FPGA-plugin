<#
.SYNOPSIS
Legacy YAML matrix generator retained for existing callers.
Use standalone_lint_workflow.py for new audits and batch checkpoints.
#>
param(
  [Parameter(Mandatory = $true)]
  [string]$RuleFile,

  [Parameter(Mandatory = $true)]
  [string]$SourceFile,

  [Parameter(Mandatory = $true)]
  [string]$OutputFile,

  [Parameter(Mandatory = $true)]
  [string]$TaskId
)

$ErrorActionPreference = 'Stop'

$resolvedRuleFile = (Resolve-Path -LiteralPath $RuleFile).Path
$resolvedSourceFile = (Resolve-Path -LiteralPath $SourceFile).Path
$ruleLines = Get-Content -LiteralPath $resolvedRuleFile -Encoding UTF8

$mandatoryLabel = -join @(
  [char]0x5F3A,
  [char]0x5236,
  [char]0x7C7B
)
$advisoryLabel = -join @(
  [char]0x63A8,
  [char]0x8350,
  [char]0x7C7B
)

$currentLevel = 'mandatory'
$rules = @()
for ($index = 0; $index -lt $ruleLines.Count; $index += 1) {
  $line = $ruleLines[$index]
  if ($line -match '^#####\s+' -and $line.Contains($mandatoryLabel)) {
    $currentLevel = 'mandatory'
    continue
  }
  if ($line -match '^#####\s+' -and $line.Contains($advisoryLabel)) {
    $currentLevel = 'advisory'
    continue
  }
  if ($line -match '^\*\*(?<id>[0-9]+(?:\.[0-9]+)+)\s+(?<title>.+?)\*\*$') {
    $rules += [ordered]@{
      id = $Matches.id
      title = $Matches.title
      line = $index + 1
      level = $currentLevel
    }
  }
}

$higherOrderIds = @(
  'HIGHER-CDC',
  'HIGHER-COMB-FEEDBACK',
  'HIGHER-UNUSED-UNDRIVEN',
  'HIGHER-PARAMETERIZATION',
  'HIGHER-NAMING-CONSISTENCY'
)
$higherOrderRules = @()
$lastExplicitRuleLine = ($rules | Select-Object -Last 1).line
$inHigherOrderSection = $false
for ($index = $lastExplicitRuleLine; $index -lt $ruleLines.Count; $index += 1) {
  $line = $ruleLines[$index]
  if ($line -match '^#{2,3}\s+') {
    if ($line.Contains('HIGHER') -or $line -match ([string][char]0x7B2C + [string][char]0x4E09 + [string][char]0x90E8 + [string][char]0x5206)) {
      $inHigherOrderSection = $true
      continue
    }
    if ($inHigherOrderSection) {
      break
    }
  }
  if (-not $inHigherOrderSection) {
    continue
  }
  if ($line -match '^(?<sequence>[1-5])\.\s+\*\*(?<title>.+?)\*\*') {
    $sequenceIndex = [int]$Matches.sequence - 1
    $higherOrderRules += [ordered]@{
      id = $higherOrderIds[$sequenceIndex]
      title = $Matches.title
      line = $index + 1
    }
  }
}
if ($higherOrderRules.Count -ne $higherOrderIds.Count) {
  throw "Expected $($higherOrderIds.Count) higher-order items but found $($higherOrderRules.Count)."
}

foreach ($higherRule in $higherOrderRules) {
  $rules += [ordered]@{
    id = $higherRule.id
    title = $higherRule.title
    line = $higherRule.line
    level = 'higher_order'
  }
}

$duplicateIds = @(
  $rules.id |
    Group-Object |
    Where-Object Count -gt 1
)
if ($duplicateIds.Count -gt 0) {
  throw "Duplicate rule IDs found in rule source: $($duplicateIds.Name -join ', ')"
}

$outputParent = Split-Path -Parent $OutputFile
if ($outputParent -and -not (Test-Path -LiteralPath $outputParent)) {
  New-Item -ItemType Directory -Path $outputParent -Force | Out-Null
}

$yaml = New-Object System.Collections.Generic.List[string]
$yaml.Add(('task_id: "{0}"' -f $TaskId))
$yaml.Add(('source_file: "{0}"' -f $resolvedSourceFile.Replace('\', '/')))
$yaml.Add(('source_sha256: "{0}"' -f (Get-FileHash -Algorithm SHA256 -LiteralPath $resolvedSourceFile).Hash))
$yaml.Add('rule_source:')
$yaml.Add(('  path: "{0}"' -f $resolvedRuleFile.Replace('\', '/')))
$yaml.Add(('  sha256: "{0}"' -f (Get-FileHash -Algorithm SHA256 -LiteralPath $resolvedRuleFile).Hash))
$yaml.Add(('  explicit_rule_count: {0}' -f ($rules.Count - $higherOrderRules.Count)))
$yaml.Add(('  higher_order_item_count: {0}' -f $higherOrderRules.Count))
$yaml.Add(('  total_rule_count: {0}' -f $rules.Count))
$yaml.Add('rules:')
foreach ($rule in $rules) {
  $safeTitle = $rule.title.Replace('"', '''')
  $yaml.Add(('  - rule_id: "{0}"' -f $rule.id))
  $yaml.Add(('    title: "{0}"' -f $safeTitle))
  $yaml.Add(('    source_line: {0}' -f $rule.line))
  $yaml.Add(('    level: {0}' -f $rule.level))
  $yaml.Add('    status: null')
  $yaml.Add('    evidence: []')
  $yaml.Add('    rationale: null')
}
$yaml.Add('closure:')
$yaml.Add(('  expected_rule_count: {0}' -f $rules.Count))
$yaml.Add('  actual_rule_count: null')
$yaml.Add('  missing_rule_count: null')
$yaml.Add('  duplicate_rule_count: null')
$yaml.Add('  invalid_status_count: null')
$yaml.Add('  report_fail_count_matches_matrix: false')
$yaml.Add('  coverage_complete: false')

Set-Content -LiteralPath $OutputFile -Value $yaml -Encoding UTF8

[ordered]@{
  output_file = (Resolve-Path -LiteralPath $OutputFile).Path
  rule_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $resolvedRuleFile).Hash
  explicit_rule_count = $rules.Count - $higherOrderRules.Count
  higher_order_item_count = $higherOrderRules.Count
  total_rule_count = $rules.Count
} | ConvertTo-Json
