#!/usr/bin/env python3
"""Deterministic offline workflow for full-source, full-rule RTL audits.

The coordinator uses this script to freeze inputs, reserve file assignments,
and accept batch results. All persisted JSON is UTF-8 and replaced atomically.
"""

from __future__ import annotations

import argparse
from collections import Counter
import contextlib
import datetime as dt
import fnmatch
import hashlib
from html import escape
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
from typing import Any, Iterable, TextIO


SCHEMA_VERSION = 1
VERILOG_SUFFIXES = {".v", ".sv", ".vh", ".svh"}
RTL_LANGUAGES = {
    **dict.fromkeys(VERILOG_SUFFIXES, "verilog"),
    ".vhd": "vhdl",
    ".vhdl": "vhdl",
}
RULES_DIRECTORY = Path(__file__).resolve().parent.parent / "assets" / "rules"
DEFAULT_RULE_FILES = {
    "verilog": RULES_DIRECTORY / "RTL_Coding_Rule.md",
    "vhdl": RULES_DIRECTORY / "VHDL_Coding_Rule_111.md",
}
VALID_STATUSES = {"pass", "fail", "not_applicable", "not_verifiable"}
MAX_WORKERS_HARD_LIMIT = 8
DEFAULT_MAX_REQUEUES = 2
DEFAULT_RULE_BATCH_BYTES = 16 * 1024
MAX_BATCH_RESULT_BYTES = 8192
MAX_REPORT_PART_BYTES = 8192
HIGHER_IDS = (
    "HIGHER-CDC",
    "HIGHER-COMB-FEEDBACK",
    "HIGHER-UNUSED-UNDRIVEN",
    "HIGHER-PARAMETERIZATION",
    "HIGHER-NAMING-CONSISTENCY",
)


class WorkflowError(RuntimeError):
    """A controlled workflow failure suitable for a concise CLI response."""


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_digest(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _read_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            return json.load(stream)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise WorkflowError(f"Cannot read valid UTF-8 JSON: {path}: {exc}") from exc


def _is_inside(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=True))
        return True
    except (OSError, ValueError):
        return False


def _require_inside(path: Path, root: Path, label: str) -> Path:
    resolved = path.resolve(strict=False)
    if not _is_inside(resolved, root):
        raise WorkflowError(f"{label} must stay inside project_root: {resolved}")
    return resolved


@contextlib.contextmanager
def _atomic_text_writer(path: Path, project_root: Path) -> Iterable[TextIO]:
    target = _require_inside(path, project_root, "write target")
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=str(target.parent),
            prefix=f".{target.name}.",
            suffix=".tmp",
            delete=False,
        ) as stream:
            temp_name = stream.name
            yield stream
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, target)
    except Exception:
        if temp_name:
            with contextlib.suppress(OSError):
                os.unlink(temp_name)
        raise


def _atomic_write_json(path: Path, value: Any, project_root: Path) -> None:
    with _atomic_text_writer(path, project_root) as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


@contextlib.contextmanager
def _task_lock(task_dir: Path, project_root: Path) -> Iterable[None]:
    lock = _require_inside(task_dir / ".workflow.lock", project_root, "lock file")
    lock.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + 10.0
    while True:
        try:
            descriptor = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                payload = json.dumps(
                    {"pid": os.getpid(), "created_at": _utc_now()},
                    ensure_ascii=False,
                ).encode("utf-8")
                os.write(descriptor, payload)
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            break
        except FileExistsError:
            try:
                stale = time.time() - lock.stat().st_mtime > 120.0
            except FileNotFoundError:
                continue
            if stale:
                with contextlib.suppress(FileNotFoundError):
                    lock.unlink()
                continue
            if time.monotonic() >= deadline:
                raise WorkflowError(f"Workflow state is busy: {lock}")
            time.sleep(0.05)
    try:
        yield
    finally:
        with contextlib.suppress(FileNotFoundError):
            lock.unlink()


def _project_root(raw: str) -> Path:
    root = Path(raw).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise WorkflowError(f"project_root is not a directory: {root}")
    return root


def _task_dir(root: Path, task_id: str) -> Path:
    if (
        not task_id
        or task_id in {".", ".."}
        or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", task_id)
    ):
        raise WorkflowError(
            "task_id must be 1-128 ASCII letters, digits, dots, underscores, or hyphens"
        )
    return _require_inside(
        root / "analysis" / "standalone_lint" / task_id,
        root,
        "task directory",
    )


def _relative(path: Path, root: Path) -> str:
    return path.resolve(strict=False).relative_to(root).as_posix()


def _source_root(raw: str | None, project_root: Path) -> Path:
    candidate = Path(raw).expanduser() if raw else project_root
    if not candidate.is_absolute():
        candidate = project_root / candidate
    candidate = candidate.resolve(strict=True)
    if not candidate.is_dir() or not _is_inside(candidate, project_root):
        raise WorkflowError("source_root must be an existing directory inside project_root")
    return candidate


def _is_excluded(relative_project: str, relative_source: str, patterns: list[str]) -> bool:
    return any(
        fnmatch.fnmatchcase(relative_project, pattern)
        or fnmatch.fnmatchcase(relative_source, pattern)
        for pattern in patterns
    )


def _discover_sources(
    project_root: Path,
    source_root: Path,
    patterns: list[str],
    task_dir: Path,
    extensions: Iterable[str] = RTL_LANGUAGES,
) -> list[Path]:
    found: list[Path] = []
    for path in source_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in extensions:
            continue
        resolved = path.resolve(strict=True)
        if not _is_inside(resolved, project_root):
            raise WorkflowError(f"RTL source escapes project_root through a link: {path}")
        if _is_inside(resolved, task_dir):
            continue
        relative_project = _relative(resolved, project_root)
        relative_source = _relative(resolved, source_root)
        if _is_excluded(relative_project, relative_source, patterns):
            continue
        found.append(resolved)
    unique = {str(path).casefold(): path for path in found}
    if len(unique) != len(found):
        raise WorkflowError("Case-insensitive duplicate RTL source paths were found")
    return sorted(unique.values(), key=lambda value: _relative(value, project_root).casefold())


def _read_utf8_markdown(path: Path) -> tuple[str, list[str]]:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        raise WorkflowError(f"Rule Markdown must be valid UTF-8: {path}: {exc}") from exc
    return text, text.splitlines()


def _extract_rules(rule_path: Path, language: str) -> list[dict[str, Any]]:
    _, lines = _read_utf8_markdown(rule_path)
    explicit_pattern = re.compile(
        r"^\s*\*\*(?P<id>[0-9]+(?:\.[0-9]+)+)\s+(?P<title>.+?)\*\*\s*$"
        if language == "verilog"
        else r"^######\s+(?P<id>6\.[12](?:\.[0-9]+){3})\s+(?P<title>.+?)\s*$"
    )
    matches: list[tuple[int, re.Match[str], str]] = []
    current_level = "mandatory"
    in_fence = False
    for index, line in enumerate(lines):
        if re.match(r"^\s*```", line):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if re.match(r"^#{3,5}\s+", line):
            heading = re.sub(r"^#{3,6}\s+", "", line).strip().casefold()
            if "强制类" in heading or "mandatory" in heading:
                current_level = "mandatory"
            elif "推荐类" in heading or "advisory" in heading:
                current_level = "advisory"
        match = explicit_pattern.match(line)
        if match:
            matches.append((index, match, current_level))
    if not matches:
        raise WorkflowError(f"No numbered {language} rules were found in {rule_path}")

    rules: list[dict[str, Any]] = []
    for position, (index, match, level) in enumerate(matches):
        next_index = matches[position + 1][0] if position + 1 < len(matches) else len(lines)
        block_end = next_index
        for cursor in range(index + 1, next_index):
            if re.match(r"^#{2,5}\s+" if language == "vhdl" else r"^#{2,4}\s+", lines[cursor]):
                block_end = cursor
                break
        text = "\n".join(lines[index:block_end]).strip()
        rules.append(
            {
                "rule_id": match.group("id"),
                "title": match.group("title").strip(),
                "source_line": index + 1,
                "level": level,
                "scope": "file",
                "text": text,
            }
        )

    if language == "verilog":
        rules.extend(_extract_verilog_higher_rules(lines))
    ids = [rule["rule_id"] for rule in rules]
    duplicates = sorted(rule_id for rule_id, count in Counter(ids).items() if count > 1)
    if duplicates:
        raise WorkflowError(f"Duplicate rule IDs: {', '.join(duplicates)}")
    return rules


def _extract_verilog_higher_rules(lines: list[str]) -> list[dict[str, Any]]:
    rules = []
    higher_start = next(
        (
            index
            for index, line in enumerate(lines)
            if re.match(r"^#{2,3}\s+", line)
            and ("第三部分" in line or "通用高阶" in line or "higher" in line.casefold())
        ),
        None,
    )
    if higher_start is None:
        raise WorkflowError("The five higher-order review items section was not found")
    higher_pattern = re.compile(r"^\s*([1-5])\.\s+\*\*(.+?)\*\*")
    higher_matches: list[tuple[int, re.Match[str]]] = []
    for index in range(higher_start + 1, len(lines)):
        if index > higher_start + 1 and re.match(r"^#{2}\s+", lines[index]):
            break
        match = higher_pattern.match(lines[index])
        if match:
            higher_matches.append((index, match))
    sequences = [int(match.group(1)) for _, match in higher_matches]
    if sequences != [1, 2, 3, 4, 5]:
        raise WorkflowError(
            "Expected exactly five ordered higher-review items numbered 1 through 5"
        )
    for position, (index, match) in enumerate(higher_matches):
        end = higher_matches[position + 1][0] if position + 1 < 5 else len(lines)
        for cursor in range(index + 1, end):
            if re.match(r"^#{2}\s+", lines[cursor]):
                end = cursor
                break
        rules.append(
            {
                "rule_id": HIGHER_IDS[position],
                "title": match.group(2).rstrip("：:").strip(),
                "source_line": index + 1,
                "level": "higher_order",
                "scope": "file",
                "text": "\n".join(lines[index:end]).strip(),
            }
        )

    return rules


def _matrix_template(
    task_id: str,
    source: dict[str, Any],
    rule_catalog: dict[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "task_id": task_id,
        "source_id": source["source_id"],
        "source_path": source["path"],
        "source_sha256": source["sha256"],
        **({"language": source["language"]} if "language" in source else {}),
        "rule_source_sha256": rule_catalog["rule_source"]["sha256"],
        "rule_catalog_sha256": rule_catalog["catalog_sha256"],
        "rules": [
            {
                "rule_id": rule["rule_id"],
                "title": rule["title"],
                "source_line": rule["source_line"],
                "level": rule["level"],
                "status": None,
                "evidence": [],
                "rationale": None,
            }
            for rule in rule_catalog["rules"]
        ],
        "closure": {
            "expected_rule_count": len(rule_catalog["rules"]),
            "coverage_complete": False,
        },
    }


def _rule_chunks(
    rules: list[dict[str, Any]], max_rules: int, max_bytes: int
) -> Iterable[list[dict[str, Any]]]:
    chunk: list[dict[str, Any]] = []
    size = 3  # An empty JSON array and its final newline.
    for rule in rules:
        # Each entry is indented two extra spaces inside the array.
        entry = json.dumps(rule, ensure_ascii=False, indent=2)
        entry_size = len(entry.encode("utf-8")) + 2 * (entry.count("\n") + 1)
        if entry_size + 5 > max_bytes:
            raise WorkflowError(
                f"Rule {rule['rule_id']} exceeds --rule-batch-bytes; "
                "raise the limit to fit this rule"
            )
        separator = 2 if chunk else 0
        if chunk and (len(chunk) == max_rules or size + separator + entry_size > max_bytes):
            yield chunk
            chunk = []
            size = 3
        if chunk:
            size += 2  # Comma and newline.
        else:
            size += 2  # Newlines around the first entry, inside the brackets.
        chunk.append(rule)
        size += entry_size
    if chunk:
        yield chunk


def _queue_summary(queue: dict[str, Any]) -> dict[str, Any]:
    counts = {name: 0 for name in ("queued", "active", "completed", "blocked")}
    for item in queue["items"]:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
    active = counts.get("active", 0)
    return {
        "counts": counts,
        "active": active,
        "max_active": queue["max_active"],
        "max_active_observed": queue["max_active_observed"],
        "available_slots": max(0, queue["max_active"] - active),
        "all_completed": counts.get("completed", 0) == len(queue["items"]),
    }


def _meaningful(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set)):
        return any(_meaningful(item) for item in value)
    if isinstance(value, dict):
        return bool(value) and any(_meaningful(item) for item in value.values())
    return True


def _nonempty_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _validate_batch_fields(row: dict[str, Any], rule_id: str) -> list[str]:
    status = row.get("status")
    if not isinstance(status, str) or status not in VALID_STATUSES:
        return [f"invalid_or_empty_status:{rule_id}"]
    errors = []
    evidence = row.get("evidence", [])
    if not isinstance(evidence, list) or any(
        not isinstance(item, dict)
        or set(item) != {"location", "detail"}
        or not _nonempty_text(item["location"])
        or not _nonempty_text(item["detail"])
        for item in evidence
    ):
        errors.append(f"invalid_evidence:{rule_id}:{status}")
    elif status in {"pass", "fail"} and not evidence:
        errors.append(f"missing_evidence:{rule_id}:{status}")
    rationale = row.get("rationale")
    if status != "pass" or rationale is not None:
        if not _nonempty_text(rationale):
            errors.append(f"missing_or_invalid_rationale:{rule_id}:{status}")
    return errors


def _validate_matrix(
    matrix: Any,
    source: dict[str, Any],
    catalog: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    if not isinstance(matrix, dict):
        return ["matrix_not_object"]
    if matrix.get("schema_version") != SCHEMA_VERSION:
        errors.append("matrix_schema_version_mismatch")
    expected_meta = {
        "task_id": catalog["task_id"],
        "source_id": source["source_id"],
        "source_path": source["path"],
        "source_sha256": source["sha256"],
        "rule_source_sha256": catalog["rule_source"]["sha256"],
        "rule_catalog_sha256": catalog["catalog_sha256"],
    }
    if "language" in source:
        expected_meta["language"] = source["language"]
    for key, expected in expected_meta.items():
        if matrix.get(key) != expected:
            errors.append(f"matrix_{key}_mismatch")
    rows = matrix.get("rules")
    if not isinstance(rows, list):
        return errors + ["matrix_rules_not_list"]
    expected_rules = {rule["rule_id"]: rule for rule in catalog["rules"]}
    actual_ids: list[str] = []
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            errors.append(f"row_{index}_not_object")
            continue
        rule_id = row.get("rule_id")
        if not isinstance(rule_id, str):
            errors.append(f"row_{index}_missing_rule_id")
            continue
        actual_ids.append(rule_id)
        expected_rule = expected_rules.get(rule_id)
        if expected_rule is None:
            errors.append(f"unexpected_rule:{rule_id}")
            continue
        for key in ("title", "source_line", "level"):
            if row.get(key) != expected_rule[key]:
                errors.append(f"rule_identity_changed:{rule_id}:{key}")
        if "batches" in catalog:
            errors.extend(_validate_batch_fields(row, rule_id))
            continue
        status = row.get("status")
        if not isinstance(status, str) or status not in VALID_STATUSES:
            errors.append(f"invalid_or_empty_status:{rule_id}")
            continue
        if status in {"pass", "fail"} and not _meaningful(row.get("evidence")):
            errors.append(f"missing_evidence:{rule_id}:{status}")
        if status in {"fail", "not_applicable", "not_verifiable"} and not _meaningful(
            row.get("rationale")
        ):
            errors.append(f"missing_rationale:{rule_id}:{status}")
    duplicate_ids = sorted({rule_id for rule_id in actual_ids if actual_ids.count(rule_id) > 1})
    for rule_id in duplicate_ids:
        errors.append(f"duplicate_rule:{rule_id}")
    missing_ids = [rule_id for rule_id in expected_rules if rule_id not in actual_ids]
    for rule_id in missing_ids:
        errors.append(f"missing_rule:{rule_id}")
    closure = matrix.get("closure")
    if not isinstance(closure, dict):
        errors.append("matrix_closure_missing")
    else:
        if closure.get("expected_rule_count") != len(expected_rules):
            errors.append("matrix_closure_rule_count_mismatch")
        if closure.get("coverage_complete") is not True:
            errors.append("matrix_closure_not_confirmed")
    return errors


def _load_runtime(root: Path, task_id: str) -> tuple[Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    task_dir = _task_dir(root, task_id)
    catalog = _read_json(task_dir / "rule_catalog.json")
    manifest = _read_json(task_dir / "source_manifest.json")
    queue = _read_json(task_dir / "queue_state.json")
    for name, value in (("catalog", catalog), ("manifest", manifest), ("queue", queue)):
        if not isinstance(value, dict) or value.get("task_id") != task_id:
            raise WorkflowError(f"Invalid {name} for task {task_id}")
    return task_dir, catalog, manifest, queue


def _catalogs_by_language(catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return catalog.get("languages", {"verilog": catalog})


def _source_catalog(catalog: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    language = RTL_LANGUAGES[Path(source["path"]).suffix.lower()]
    if source.get("language", language) != language:
        raise WorkflowError(f"Frozen source language mismatch: {source['path']}")
    selected = _catalogs_by_language(catalog).get(language)
    if selected is None or selected.get("language", language) != language:
        raise WorkflowError(f"No frozen {language} catalog for {source['path']}")
    return selected


def _catalog_integrity(catalog: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    rules = catalog.get("rules")
    if not isinstance(rules, list):
        return ["rule_catalog_rules_not_list"]
    if catalog.get("catalog_sha256") != _canonical_digest(rules):
        errors.append("rule_catalog_digest_changed")
    source = catalog.get("rule_source", {})
    raw_path = source.get("resolved_path")
    if not isinstance(raw_path, str) or not Path(raw_path).is_file():
        errors.append("rule_source_missing")
    elif _sha256(Path(raw_path)) != source.get("sha256"):
        errors.append("rule_source_hash_changed")
    for figure in source.get("figures", []):
        path = Path(figure["resolved_path"])
        if not path.is_file() or _sha256(path) != figure["sha256"]:
            errors.append(f"rule_figure_changed:{path.name}")
    ids = [rule.get("rule_id") for rule in rules if isinstance(rule, dict)]
    if len(ids) != len(rules) or len(set(ids)) != len(ids):
        errors.append("rule_catalog_ids_invalid_or_duplicate")
    if "batches" in catalog:
        batches = catalog["batches"]
        if not isinstance(batches, list) or not batches or any(
            not isinstance(batch, dict)
            or batch.get("batch_id") != f"BATCH-{index:04d}"
            or not isinstance(batch.get("rule_ids"), list)
            or not batch["rule_ids"]
            for index, batch in enumerate(batches, start=1)
        ):
            errors.append("rule_batches_invalid")
        elif [rule_id for batch in batches for rule_id in batch["rule_ids"]] != ids:
            errors.append("rule_batch_coverage_mismatch")
    return errors


def _source_integrity(root: Path, source: dict[str, Any]) -> list[str]:
    path = root / source.get("path", "")
    if not _is_inside(path, root) or not path.is_file():
        return [f"source_missing:{source.get('source_id')}"]
    if _sha256(path) != source.get("sha256"):
        return [f"source_hash_changed:{source.get('source_id')}"]
    return []


def _rule_chunk_path(task_dir: Path, catalog: dict[str, Any], batch_id: str) -> Path:
    directory = task_dir / "rule_chunks"
    if "language" in catalog:
        directory /= catalog["language"]
    return directory / f"{batch_id}.json"


def _checkpoint_path(task_dir: Path, source_id: str, batch_id: str) -> Path:
    return task_dir / "checkpoints" / source_id / f"{batch_id}.json"


def _batch_result_path(task_dir: Path, source_id: str, assignment_id: str, batch_id: str) -> Path:
    return task_dir / "workers" / source_id / assignment_id / f"{batch_id}.json"


def _pending_batch_ids(
    task_dir: Path, catalog: dict[str, Any], source_id: str
) -> list[str]:
    return [
        batch["batch_id"]
        for batch in catalog["batches"]
        if not _checkpoint_path(task_dir, source_id, batch["batch_id"]).is_file()
    ]


def _prepare_catalog(
    root: Path, args: argparse.Namespace, language: str, created_at: str
) -> tuple[dict[str, Any], list[list[dict[str, Any]]]]:
    configured = args.rule_file if language == "verilog" else args.vhdl_rule_file
    rule_path = Path(configured).expanduser() if configured else DEFAULT_RULE_FILES[language]
    rule_path = rule_path.resolve(strict=True)
    if not rule_path.is_file():
        raise WorkflowError(f"Rule source is not a file: {rule_path}")
    rules = _extract_rules(rule_path, language)
    figures = {}
    if language == "vhdl":
        for rule in rules:
            rule_figures = []
            for name in re.findall(r"!\[[^\]]*\]\((vhdl-111-figures/[^)]+)\)", rule["text"]):
                path = _require_inside(rule_path.parent / name, rule_path.parent, "rule figure")
                if not path.is_file():
                    raise WorkflowError(f"Missing VHDL rule figure: {path}")
                figures[name] = {"path": name, "resolved_path": str(path), "sha256": _sha256(path)}
                rule_figures.append(str(path))
            if rule_figures:
                rule["figure_paths"] = rule_figures
    chunks = list(_rule_chunks(rules, args.rule_batch_size, args.rule_batch_bytes))
    batches = [
        {
            "batch_id": f"BATCH-{index:04d}",
            "rule_ids": [rule["rule_id"] for rule in chunk],
        }
        for index, chunk in enumerate(chunks, start=1)
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "task_id": args.task_id,
        "created_at": created_at,
        "language": language,
        "rule_source": {
            "path": _relative(rule_path, root) if _is_inside(rule_path, root) else str(rule_path),
            "resolved_path": str(rule_path),
            "sha256": _sha256(rule_path),
            "figures": list(figures.values()),
        },
        "total_rule_count": len(rules),
        "rules": rules,
        "batches": batches,
        "result_max_bytes": MAX_BATCH_RESULT_BYTES,
        "catalog_sha256": _canonical_digest(rules),
    }, chunks


def command_prepare(args: argparse.Namespace) -> dict[str, Any]:
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    max_workers = args.max_workers
    if not 1 <= max_workers <= MAX_WORKERS_HARD_LIMIT:
        raise WorkflowError("max_workers must be between 1 and 8")
    if args.rule_batch_size < 1:
        raise WorkflowError("rule_batch_size must be positive")
    if args.rule_batch_bytes < 1:
        raise WorkflowError("rule_batch_bytes must be positive")
    if args.max_requeues < 0:
        raise WorkflowError("max_requeues must be non-negative")
    if task_dir.exists() and any(task_dir.iterdir()):
        raise WorkflowError(f"Task directory is not empty; refusing to overwrite: {task_dir}")
    source_root = _source_root(args.source_root, root)
    patterns = list(args.exclude or [])
    sources = _discover_sources(root, source_root, patterns, task_dir)
    if not sources:
        raise WorkflowError("No .v/.sv/.vh/.svh/.vhd/.vhdl files were found in source_root")
    created_at = _utc_now()
    source_records = [
        {
            "source_id": f"SRC-{index:06d}",
            "path": _relative(path, root),
            "suffix": path.suffix.lower(),
            "language": RTL_LANGUAGES[path.suffix.lower()],
            "size_bytes": path.stat().st_size,
            "sha256": _sha256(path),
        }
        for index, path in enumerate(sources, start=1)
    ]
    source_counts = Counter(source["language"] for source in source_records)
    catalogs = {}
    chunks_by_language = {}
    for language in sorted(source_counts):
        catalogs[language], chunks_by_language[language] = _prepare_catalog(
            root, args, language, created_at
        )
    rule_catalog = {
        "schema_version": SCHEMA_VERSION,
        "task_id": args.task_id,
        "created_at": created_at,
        "languages": catalogs,
    }
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "task_id": args.task_id,
        "created_at": created_at,
        "project_root": str(root),
        "source_root": _relative(source_root, root) or ".",
        "extensions": sorted(RTL_LANGUAGES),
        "exclude_patterns": patterns,
        "source_count": len(source_records),
        "sources": source_records,
    }
    worker_batches = {}
    for language, catalog in catalogs.items():
        worker_batches[language] = []
        for batch, chunk in zip(catalog["batches"], chunks_by_language[language]):
            chunk_path = _rule_chunk_path(task_dir, catalog, batch["batch_id"])
            _atomic_write_json(chunk_path, chunk, root)
            worker_batches[language].append({**batch, "rule_path": _relative(chunk_path, root)})
    items: list[dict[str, Any]] = []
    for source in source_records:
        matrix_rel = f"analysis/standalone_lint/{args.task_id}/matrices/{source['source_id']}.json"
        batch_rel = f"analysis/standalone_lint/{args.task_id}/rule_batches/{source['source_id']}.json"
        catalog = catalogs[source["language"]]
        matrix = _matrix_template(args.task_id, source, catalog)
        batch = {
            "schema_version": SCHEMA_VERSION,
            "task_id": args.task_id,
            "source": source,
            "rule_catalog_sha256": catalog["catalog_sha256"],
            "rule_count": catalog["total_rule_count"],
            "batches": worker_batches[source["language"]],
        }
        _atomic_write_json(root / matrix_rel, matrix, root)
        _atomic_write_json(root / batch_rel, batch, root)
        items.append(
            {
                "source_id": source["source_id"],
                "source_path": source["path"],
                "matrix_path": matrix_rel,
                "batch_path": batch_rel,
                "attempt_matrix_path": None,
                "status": "queued",
                "assignment_id": None,
                "worker_id": None,
                "dispatched_at": None,
                "completed_at": None,
                "requeue_count": 0,
                "last_reason": None,
            }
        )
    queue = {
        "schema_version": SCHEMA_VERSION,
        "task_id": args.task_id,
        "created_at": created_at,
        "updated_at": created_at,
        "max_active": max_workers,
        "hard_max_active": MAX_WORKERS_HARD_LIMIT,
        "max_active_observed": 0,
        "max_requeues": args.max_requeues,
        "next_assignment_number": 1,
        "items": items,
    }
    _atomic_write_json(task_dir / "rule_catalog.json", rule_catalog, root)
    _atomic_write_json(task_dir / "source_manifest.json", manifest, root)
    _atomic_write_json(task_dir / "queue_state.json", queue, root)
    language_counts = {
        language: {
            "source_count": source_counts[language],
            "rule_count": catalog["total_rule_count"],
            "rule_batch_count": len(catalog["batches"]),
            "rule_source": catalog["rule_source"]["path"],
        }
        for language, catalog in catalogs.items()
    }
    return {
        "command": "prepare",
        "task_id": args.task_id,
        "task_dir": _relative(task_dir, root),
        "source_count": len(sources),
        "rule_count": sum(entry["rule_count"] for entry in language_counts.values()),
        "rule_batch_size": args.rule_batch_size,
        "rule_batch_bytes": args.rule_batch_bytes,
        "rule_batch_count": sum(entry["rule_batch_count"] for entry in language_counts.values()),
        "languages": language_counts,
        "max_requeues": args.max_requeues,
        "expected_pair_count": sum(
            entry["source_count"] * entry["rule_count"] for entry in language_counts.values()
        ),
        "max_active": max_workers,
        **_queue_summary(queue),
    }


def _reserve_queued(
    root: Path,
    task_id: str,
    queue: dict[str, Any],
    catalog: dict[str, Any],
    manifest: dict[str, Any],
    requested_count: int,
    requested_workers: list[str],
) -> list[dict[str, Any]]:
    """Reserve queued sources and give each assignment isolated output paths."""
    task_dir = _task_dir(root, task_id)
    active_workers = {
        item["worker_id"] for item in queue["items"] if item["status"] == "active"
    }
    if len(requested_workers) != len(set(requested_workers)):
        raise WorkflowError("Each --worker value must be unique")
    conflict = [worker for worker in requested_workers if worker in active_workers]
    if conflict:
        raise WorkflowError(f"Workers already active: {', '.join(conflict)}")
    capacity = min(_queue_summary(queue)["available_slots"], requested_count)
    queued = [item for item in queue["items"] if item["status"] == "queued"]
    count = min(capacity, len(queued))
    if requested_workers:
        count = min(count, len(requested_workers))
    assignments: list[dict[str, Any]] = []
    for offset, item in enumerate(queued[:count]):
        number = queue["next_assignment_number"]
        queue["next_assignment_number"] += 1
        assignment_id = f"ASG-{number:06d}"
        worker_id = (
            requested_workers[offset]
            if requested_workers
            else f"lint-agent-{number:06d}"
        )
        dispatched_at = _utc_now()
        source_id = item["source_id"]
        source = _source_by_id(manifest, source_id)
        source_catalog = _source_catalog(catalog, source)
        attempt_matrix_rel = None
        if "batches" in source_catalog:
            pending = []
            for batch_id in _pending_batch_ids(task_dir, source_catalog, source_id):
                result_path = _batch_result_path(task_dir, source_id, assignment_id, batch_id)
                pending.append({
                    "batch_id": batch_id,
                    "rule_path": _relative(_rule_chunk_path(task_dir, source_catalog, batch_id), root),
                    "result_path": _relative(result_path, root),
                })
            output = {
                "pending_batches": pending,
                "accepted_batch_count": len(source_catalog["batches"]) - len(pending),
                "write_scope": [batch["result_path"] for batch in pending],
            }
            if "result_max_bytes" in source_catalog:
                output["result_max_bytes"] = source_catalog["result_max_bytes"]
            if pending:
                (root / pending[0]["result_path"]).parent.mkdir(parents=True, exist_ok=True)
        else:
            # Version 1 tasks prepared before batch checkpoints use full matrices.
            attempt_matrix = task_dir / "workers" / source_id / assignment_id / "matrix.json"
            attempt_matrix_rel = _relative(attempt_matrix, root)
            _atomic_write_json(attempt_matrix, _matrix_template(task_id, source, source_catalog), root)
            output = {"matrix_path": attempt_matrix_rel, "write_scope": [attempt_matrix_rel]}
        item.update(
            {
                "status": "active",
                "assignment_id": assignment_id,
                "worker_id": worker_id,
                "attempt_matrix_path": attempt_matrix_rel,
                "dispatched_at": dispatched_at,
                "completed_at": None,
            }
        )
        assignment_rel = (
            f"analysis/standalone_lint/{task_id}/assignments/{assignment_id}.json"
        )
        assignment = {
            "schema_version": SCHEMA_VERSION,
            "task_id": task_id,
            "assignment_id": assignment_id,
            "worker_id": worker_id,
            "status": "active",
            "dispatched_at": dispatched_at,
            "source_id": item["source_id"],
            "source_path": item["source_path"],
            **({"language": source["language"], "rule_source": source_catalog["rule_source"]["path"]}
               if "language" in source else {}),
            "batch_path": item["batch_path"],
            "accepted_matrix_path": item["matrix_path"],
            **output,
        }
        _atomic_write_json(root / assignment_rel, assignment, root)
        assignments.append({**assignment, "assignment_path": assignment_rel})
    active_count = sum(item["status"] == "active" for item in queue["items"])
    if active_count > queue["max_active"] or active_count > MAX_WORKERS_HARD_LIMIT:
        raise WorkflowError("Internal active-worker limit violation")
    queue["max_active_observed"] = max(queue["max_active_observed"], active_count)
    queue["updated_at"] = _utc_now()
    return assignments


def command_dispatch(args: argparse.Namespace) -> dict[str, Any]:
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    with _task_lock(task_dir, root):
        _, catalog, manifest, queue = _load_runtime(root, args.task_id)
        catalog_errors = {
            language: _catalog_integrity(selected)
            for language, selected in _catalogs_by_language(catalog).items()
        }
        for item in queue["items"]:
            if item["status"] != "queued":
                continue
            source = _source_by_id(manifest, item["source_id"])
            language = source.get("language", "verilog")
            errors = catalog_errors[language]
            if errors:
                if "languages" not in catalog:
                    raise WorkflowError("Dispatch rejected: " + ", ".join(errors))
                item.update(status="blocked", last_failure_kind="rule_integrity",
                            last_reason=f"{language}: " + ", ".join(errors))
        assignments = _reserve_queued(
            root,
            args.task_id,
            queue,
            catalog,
            manifest,
            args.count,
            list(args.worker or []),
        )
        _atomic_write_json(task_dir / "queue_state.json", queue, root)
        return {
            "command": "dispatch",
            "task_id": args.task_id,
            "assignments": assignments,
            **_queue_summary(queue),
        }


def _find_assignment(queue: dict[str, Any], assignment_id: str) -> dict[str, Any]:
    items = [item for item in queue["items"] if item.get("assignment_id") == assignment_id]
    if len(items) != 1:
        raise WorkflowError(f"Expected one current queue item for assignment: {assignment_id}")
    return items[0]


def _source_by_id(manifest: dict[str, Any], source_id: str) -> dict[str, Any]:
    matches = [source for source in manifest.get("sources", []) if source.get("source_id") == source_id]
    if len(matches) != 1:
        raise WorkflowError(f"Expected one source manifest record: {source_id}")
    return matches[0]


def _update_assignment_file(
    root: Path,
    task_id: str,
    assignment_id: str,
    status: str,
    **extra: Any,
) -> None:
    path = root / f"analysis/standalone_lint/{task_id}/assignments/{assignment_id}.json"
    assignment = _read_json(path)
    assignment["status"] = status
    assignment["updated_at"] = _utc_now()
    assignment.update(extra)
    _atomic_write_json(path, assignment, root)


def _validate_batch_rows(rows: Any, rule_ids: list[str]) -> list[str]:
    if not isinstance(rows, list):
        return ["batch_result_not_array"]
    expected = set(rule_ids)
    seen = set()
    errors = []
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or not _nonempty_text(row.get("rule_id")):
            errors.append(f"invalid_result_row:{index}")
            continue
        rule_id = row["rule_id"]
        if rule_id not in expected:
            errors.append(f"unexpected_rule:{rule_id}")
            continue
        if rule_id in seen:
            errors.append(f"duplicate_rule:{rule_id}")
        seen.add(rule_id)
        if row.keys() - {"rule_id", "status", "evidence", "rationale"}:
            errors.append(f"unexpected_result_fields:{rule_id}")
        errors.extend(_validate_batch_fields(row, rule_id))
    errors.extend(f"missing_rule:{rule_id}" for rule_id in rule_ids if rule_id not in seen)
    return errors


def _checkpoint_identity(
    catalog: dict[str, Any], source: dict[str, Any], batch_id: str
) -> dict[str, Any]:
    return {
        "task_id": catalog["task_id"],
        "source_id": source["source_id"],
        "source_sha256": source["sha256"],
        "rule_catalog_sha256": catalog["catalog_sha256"],
        "batch_id": batch_id,
    }


def _read_checkpoint(
    path: Path, identity: dict[str, Any], rule_ids: list[str]
) -> dict[str, Any]:
    checkpoint = _read_json(path)
    if not isinstance(checkpoint, dict) or any(
        checkpoint.get(key) != value for key, value in identity.items()
    ):
        raise WorkflowError(f"Checkpoint identity mismatch: {path}")
    errors = _validate_batch_rows(checkpoint.get("results"), rule_ids)
    if errors:
        raise WorkflowError(f"Invalid checkpoint {path}: " + ", ".join(errors))
    return checkpoint


def command_accept_batch(args: argparse.Namespace) -> dict[str, Any]:
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    with _task_lock(task_dir, root):
        _, catalog, manifest, queue = _load_runtime(root, args.task_id)
        item = _find_assignment(queue, args.assignment_id)
        if item["status"] != "active":
            raise WorkflowError(f"Assignment is not active: {args.assignment_id}")
        source = _source_by_id(manifest, item["source_id"])
        catalog = _source_catalog(catalog, source)
        if "batches" not in catalog:
            raise WorkflowError("This task uses legacy matrix submissions; use complete")
        errors = _catalog_integrity(catalog) + _source_integrity(root, source)
        if errors:
            raise WorkflowError("Batch rejected: " + ", ".join(errors))
        batch = next(
            (batch for batch in catalog["batches"] if batch["batch_id"] == args.batch_id), None
        )
        if batch is None:
            raise WorkflowError(f"Unknown batch: {args.batch_id}")
        batch_id = batch["batch_id"]
        rule_ids = batch["rule_ids"]
        source_id = source["source_id"]
        identity = _checkpoint_identity(catalog, source, batch_id)
        checkpoint_path = _require_inside(
            _checkpoint_path(task_dir, source_id, batch_id), task_dir, "checkpoint path"
        )
        if checkpoint_path.exists():
            _read_checkpoint(checkpoint_path, identity, rule_ids)
            result = "already_accepted"
        else:
            rule_path = _require_inside(_rule_chunk_path(task_dir, catalog, batch_id), task_dir, "rule chunk")
            rules_by_id = {rule["rule_id"]: rule for rule in catalog["rules"]}
            if _read_json(rule_path) != [rules_by_id[rule_id] for rule_id in rule_ids]:
                raise WorkflowError(f"Rule chunk does not match the frozen catalog: {batch_id}")
            result_path = _batch_result_path(task_dir, source_id, args.assignment_id, batch_id)
            if _require_inside(result_path, task_dir, "batch result path") != result_path:
                raise WorkflowError("Batch result must be at its assigned path")
            limit = catalog.get("result_max_bytes")
            if limit is not None and result_path.is_file() and result_path.stat().st_size > limit:
                raise WorkflowError(f"Batch result exceeds {limit} UTF-8 bytes; shorten evidence and rationale")
            rows = _read_json(result_path)
            errors = _validate_batch_rows(rows, rule_ids)
            if errors:
                raise WorkflowError("Batch rejected: " + ", ".join(errors))
            _atomic_write_json(checkpoint_path, {
                **identity,
                "assignment_id": args.assignment_id,
                "accepted_at": _utc_now(),
                "results": rows,
            }, root)
            result = "accepted"
        return {
            "command": "accept-batch",
            "task_id": args.task_id,
            "source_id": source_id,
            "assignment_id": args.assignment_id,
            "batch_id": batch_id,
            "result": result,
        }


def _assemble_matrix(
    task_dir: Path, catalog: dict[str, Any], source: dict[str, Any]
) -> dict[str, Any]:
    source_id = source["source_id"]
    results = {}
    missing = []
    for batch in catalog["batches"]:
        batch_id = batch["batch_id"]
        path = _require_inside(_checkpoint_path(task_dir, source_id, batch_id), task_dir, "checkpoint")
        if not path.is_file():
            missing.append(batch_id)
            continue
        checkpoint = _read_checkpoint(
            path, _checkpoint_identity(catalog, source, batch_id), batch["rule_ids"]
        )
        results.update({row["rule_id"]: row for row in checkpoint["results"]})
    if missing:
        raise WorkflowError("Missing accepted batches: " + ", ".join(missing))
    matrix = _matrix_template(catalog["task_id"], source, catalog)
    for row in matrix["rules"]:
        result = results[row["rule_id"]]
        row.update(
            status=result["status"],
            evidence=result.get("evidence", []),
            rationale=result.get("rationale"),
        )
    matrix["closure"]["coverage_complete"] = True
    return matrix


def command_complete(args: argparse.Namespace) -> dict[str, Any]:
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    with _task_lock(task_dir, root):
        _, catalog, manifest, queue = _load_runtime(root, args.task_id)
        item = _find_assignment(queue, args.assignment_id)
        source = _source_by_id(manifest, item["source_id"])
        catalog = _source_catalog(catalog, source)
        batched = "batches" in catalog
        already_completed = batched and item["status"] == "completed"
        if item["status"] != "active" and not already_completed:
            raise WorkflowError(f"Assignment is not active: {args.assignment_id}")
        errors = _catalog_integrity(catalog) + _source_integrity(root, source)
        if errors:
            raise WorkflowError("Completion rejected: " + "; ".join(sorted(set(errors))))
        canonical_path = _require_inside(root / item["matrix_path"], task_dir, "canonical matrix")
        if already_completed:
            matrix = _read_json(canonical_path)
        elif batched:
            matrix = _assemble_matrix(task_dir, catalog, source)
        else:
            attempt_path = item.get("attempt_matrix_path")
            if not isinstance(attempt_path, str):
                raise WorkflowError("Active assignment has no isolated attempt matrix")
            matrix_path = _require_inside(root / attempt_path, task_dir, "attempt matrix path")
            matrix = _read_json(matrix_path)
        errors.extend(_validate_matrix(matrix, source, catalog))
        errors = sorted(set(errors))
        if errors:
            raise WorkflowError(
                "Completion rejected; assignment remains active: " + "; ".join(errors)
            )
        if not already_completed:
            _atomic_write_json(canonical_path, matrix, root)
            completed_at = _utc_now()
            _update_assignment_file(
                root, args.task_id, args.assignment_id, "completed", completed_at=completed_at
            )
            item.update(status="completed", completed_at=completed_at)
            queue["updated_at"] = completed_at
            _atomic_write_json(task_dir / "queue_state.json", queue, root)
        replacement_assignments = []
        if not batched:
            replacement_assignments = _reserve_queued(root, args.task_id, queue, catalog, manifest, 1, [])
            _atomic_write_json(task_dir / "queue_state.json", queue, root)
        return {
            "command": "complete",
            "task_id": args.task_id,
            "assignment_id": args.assignment_id,
            "source_id": item["source_id"],
            "source_path": item["source_path"],
            "result": "completed",
            "replacement_assignments": replacement_assignments,
            **_queue_summary(queue),
            "spawn_replacement_now": bool(replacement_assignments),
        }


def command_end_assignment(args: argparse.Namespace) -> dict[str, Any]:
    release = args.command == "release"
    reason = args.reason.strip()
    if not reason:
        raise WorkflowError(f"{args.command} --reason must not be empty")
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    with _task_lock(task_dir, root):
        _, catalog, manifest, queue = _load_runtime(root, args.task_id)
        item = _find_assignment(queue, args.assignment_id)
        if item["status"] != "active":
            raise WorkflowError(f"Assignment is not active: {args.assignment_id}")
        prior_worker = item["worker_id"]
        if release:
            source = _source_by_id(manifest, item["source_id"])
            if "batches" not in _source_catalog(catalog, source):
                raise WorkflowError("Legacy assignments use requeue")
            assignment = _read_json(task_dir / "assignments" / f"{args.assignment_id}.json")
            for batch in assignment["pending_batches"]:
                if (root / batch["result_path"]).exists() or _checkpoint_path(
                    task_dir, item["source_id"], batch["batch_id"]
                ).exists():
                    raise WorkflowError("Assignment has batch output; use requeue for a started worker")
        retry_limit = queue.get("max_requeues", DEFAULT_MAX_REQUEUES) + item.get("extra_requeues", 0)
        failure_kind = "not_started" if release else args.kind
        if release:
            new_status = "queued"
        elif item["requeue_count"] >= retry_limit:
            new_status = "blocked"
        else:
            item["requeue_count"] += 1
            new_status = "queued"
        item.update(
            {
                "status": new_status,
                "last_reason": reason,
                "last_failure_kind": failure_kind,
                "worker_id": None,
                "assignment_id": None,
                "attempt_matrix_path": None,
                "dispatched_at": None,
                "completed_at": None,
            }
        )
        queue["updated_at"] = _utc_now()
        _update_assignment_file(
            root,
            args.task_id,
            args.assignment_id,
            "released" if release else new_status,
            reason=reason,
            failure_kind=failure_kind,
            prior_worker=prior_worker,
            requeue_count=item["requeue_count"],
        )
        _atomic_write_json(task_dir / "queue_state.json", queue, root)
        return {
            "command": args.command,
            "task_id": args.task_id,
            "assignment_id": args.assignment_id,
            "source_id": item["source_id"],
            "result": new_status,
            "failure_kind": failure_kind,
            "requeue_count": item["requeue_count"],
            **_queue_summary(queue),
        }


def command_unblock(args: argparse.Namespace) -> dict[str, Any]:
    reason = args.reason.strip()
    if not reason or args.additional_requeues < 1:
        raise WorkflowError("unblock requires a reason and positive --additional-requeues")
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    with _task_lock(task_dir, root):
        _, catalog, manifest, queue = _load_runtime(root, args.task_id)
        item = next(
            (item for item in queue["items"] if item["source_id"] == args.source_id), None
        )
        if item is None or item["status"] != "blocked":
            raise WorkflowError(f"Source is not blocked: {args.source_id}")
        source = _source_by_id(manifest, args.source_id)
        errors = _catalog_integrity(_source_catalog(catalog, source)) + _source_integrity(root, source)
        if errors:
            raise WorkflowError("Unblock rejected: " + ", ".join(errors))
        now = _utc_now()
        item.setdefault("unblock_history", []).append({
            "at": now,
            "reason": reason,
            "prior_reason": item["last_reason"],
            "additional_requeues": args.additional_requeues,
        })
        item["extra_requeues"] = item.get("extra_requeues", 0) + args.additional_requeues
        item.update(status="queued", last_reason=reason)
        queue["updated_at"] = now
        _atomic_write_json(task_dir / "queue_state.json", queue, root)
        return {
            "command": "unblock",
            "task_id": args.task_id,
            "source_id": args.source_id,
            "result": "queued",
            **_queue_summary(queue),
        }


def command_status(args: argparse.Namespace) -> dict[str, Any]:
    root = _project_root(args.project_root)
    task_dir, catalog, manifest, queue = _load_runtime(root, args.task_id)
    active = [
        {
            "source_id": item["source_id"],
            "source_path": item["source_path"],
            "assignment_id": item["assignment_id"],
            "worker_id": item["worker_id"],
        }
        for item in queue["items"]
        if item["status"] == "active"
    ]
    for assignment in active:
        source = _source_by_id(manifest, assignment["source_id"])
        source_catalog = _source_catalog(catalog, source)
        if "language" in source:
            assignment["language"] = source["language"]
        if "batches" in source_catalog:
            assignment_id = assignment["assignment_id"]
            assignment["assignment_path"] = _relative(
                task_dir / "assignments" / f"{assignment_id}.json", root
            )
            assignment["pending_batch_ids"] = _pending_batch_ids(
                task_dir, source_catalog, assignment["source_id"]
            )
    blocked = [
        {
            "source_id": item["source_id"],
            "source_path": item["source_path"],
            "reason": item["last_reason"],
            "failure_kind": item.get("last_failure_kind"),
            "requeue_count": item["requeue_count"],
        }
        for item in queue["items"]
        if item["status"] == "blocked"
    ]
    return {
        "command": "status",
        "task_id": args.task_id,
        **_queue_summary(queue),
        "active_assignments": active,
        "blocked_sources": blocked,
    }


def command_validate(args: argparse.Namespace) -> tuple[dict[str, Any], bool]:
    root = _project_root(args.project_root)
    task_dir, catalog, manifest, queue = _load_runtime(root, args.task_id)
    catalogs = _catalogs_by_language(catalog)
    errors = [
        f"{language}:{error}" if "languages" in catalog else error
        for language, source_catalog in catalogs.items()
        for error in _catalog_integrity(source_catalog)
    ]
    sources = manifest.get("sources", [])
    if manifest.get("source_count") != len(sources):
        errors.append("source_manifest_count_mismatch")
    source_ids = [source.get("source_id") for source in sources if isinstance(source, dict)]
    if len(source_ids) != len(sources) or len(set(source_ids)) != len(source_ids):
        errors.append("source_manifest_ids_invalid_or_duplicate")
    for source in sources:
        errors.extend(_source_integrity(root, source))

    try:
        frozen_root = _source_root(manifest.get("source_root"), root)
        current_sources = _discover_sources(
            root,
            frozen_root,
            list(manifest.get("exclude_patterns", [])),
            task_dir,
            set(manifest.get("extensions", VERILOG_SUFFIXES)),
        )
        frozen_paths = {source["path"] for source in sources}
        current_paths = {_relative(path, root) for path in current_sources}
        for path in sorted(frozen_paths - current_paths):
            errors.append(f"frozen_source_missing:{path}")
        for path in sorted(current_paths - frozen_paths):
            errors.append(f"new_unreviewed_source:{path}")
    except WorkflowError as exc:
        errors.append(f"source_rediscovery_failed:{exc}")

    queue_items = queue.get("items", [])
    queue_source_ids = [item.get("source_id") for item in queue_items if isinstance(item, dict)]
    if len(queue_source_ids) != len(queue_items) or set(queue_source_ids) != set(source_ids):
        errors.append("queue_source_set_mismatch")
    if any(item.get("status") != "completed" for item in queue_items):
        errors.append("queue_not_fully_completed")
    if queue.get("max_active", 0) > MAX_WORKERS_HARD_LIMIT:
        errors.append("configured_max_active_exceeds_8")
    if queue.get("max_active_observed", 0) > MAX_WORKERS_HARD_LIMIT:
        errors.append("max_active_observed_exceeds_8")
    if queue.get("max_active_observed", 0) > queue.get("max_active", 0):
        errors.append("max_active_observed_exceeds_configuration")

    expected_pairs = set()
    language_counts = {
        language: {"source_count": 0, "rule_count": len(source_catalog["rules"])}
        for language, source_catalog in catalogs.items()
    }
    items_by_source = {item["source_id"]: item for item in queue_items if isinstance(item, dict)}
    queue_source_counts = Counter(queue_source_ids)
    actual_pairs: list[tuple[str, str]] = []
    for source in sources:
        source_id = source["source_id"]
        source_catalog = _source_catalog(catalog, source)
        language_counts[source.get("language", "verilog")]["source_count"] += 1
        expected_pairs.update((source_id, rule["rule_id"]) for rule in source_catalog["rules"])
        if queue_source_counts[source_id] != 1:
            continue
        matrix_path = _require_inside(root / items_by_source[source_id]["matrix_path"], root, "matrix path")
        try:
            matrix = _read_json(matrix_path)
        except WorkflowError as exc:
            errors.append(str(exc))
            continue
        matrix_errors = _validate_matrix(matrix, source, source_catalog)
        errors.extend(f"{source['source_id']}:{error}" for error in matrix_errors)
        if isinstance(matrix, dict) and isinstance(matrix.get("rules"), list):
            for row in matrix["rules"]:
                if isinstance(row, dict) and isinstance(row.get("rule_id"), str):
                    actual_pairs.append((source["source_id"], row["rule_id"]))
    duplicate_pairs = sorted(pair for pair, count in Counter(actual_pairs).items() if count > 1)
    for source_id, rule_id in duplicate_pairs:
        errors.append(f"duplicate_pair:{source_id}:{rule_id}")
    actual_pair_set = set(actual_pairs)
    for source_id, rule_id in sorted(expected_pairs - actual_pair_set):
        errors.append(f"missing_pair:{source_id}:{rule_id}")
    for source_id, rule_id in sorted(actual_pair_set - expected_pairs):
        errors.append(f"unexpected_pair:{source_id}:{rule_id}")

    errors = sorted(set(errors))
    passed = not errors
    result = {
        "command": "validate",
        "task_id": args.task_id,
        "source_count": len(sources),
        "rule_count": sum(counts["rule_count"] for counts in language_counts.values()),
        "languages": language_counts,
        "expected_pair_count": len(expected_pairs),
        "actual_pair_count": len(actual_pairs),
        "duplicate_pair_count": len(duplicate_pairs),
        "max_active_observed": queue.get("max_active_observed"),
        "coverage_complete": passed,
        "errors": errors,
        **_queue_summary(queue),
    }
    return result, passed


def _report_rows(
    root: Path, task_dir: Path, catalog: dict[str, Any], source: dict[str, Any],
    item: dict[str, Any] | None,
) -> Iterable[dict[str, Any]]:
    if _source_integrity(root, source):
        return
    if item and item["status"] == "completed":
        path = _require_inside(root / item["matrix_path"], task_dir, "canonical matrix")
        try:
            matrix = _read_json(path)
        except WorkflowError:
            matrix = None
        if not _validate_matrix(matrix, source, catalog):
            yield from matrix["rules"]
            return
    rules = {rule["rule_id"]: rule for rule in catalog["rules"]}
    source_id = source["source_id"]
    for batch in catalog.get("batches", []):
        batch_id = batch["batch_id"]
        path = _require_inside(_checkpoint_path(task_dir, source_id, batch_id), task_dir, "checkpoint")
        if not path.is_file():
            continue
        try:
            checkpoint = _read_checkpoint(
                path, _checkpoint_identity(catalog, source, batch_id), batch["rule_ids"]
            )
        except WorkflowError:
            continue
        for row in checkpoint["results"]:
            yield {**rules[row["rule_id"]], **row}


def _markdown_text(value: Any) -> str:
    # Keep source text and evidence literal when rendered as Markdown.
    return re.sub(r"([\\`*_\[\]|~])", r"\\\1", escape(" ".join(str(value).split()), quote=False))


def _finding_lines(source_path: str, row: dict[str, Any]) -> Iterable[str]:
    yield f"#### {_markdown_text(row['rule_id'])} · {_markdown_text(row['title'])}\n\n"
    yield f"- 文件：{_markdown_text(source_path)}\n"
    yield f"- 规则级别：{_markdown_text(row['level'])}\n"
    evidence = row.get("evidence")
    if isinstance(evidence, list) and all(
        isinstance(entry, dict) and {"location", "detail"} <= entry.keys() for entry in evidence
    ):
        for entry in evidence:
            yield f"- {_markdown_text(entry['location'])}：{_markdown_text(entry['detail'])}\n"
    elif _meaningful(evidence):
        yield f"- 证据：{_markdown_text(evidence)}\n"
    if _meaningful(row.get("rationale")):
        yield f"- 判定理由：{_markdown_text(row['rationale'])}\n"
    yield "\n"


def _report_parts(lines: Iterable[str], limit: int) -> Iterable[str]:
    buffer = bytearray()
    for line in lines:
        data = line.encode("utf-8")
        if buffer and len(buffer) + len(data) > limit:
            yield buffer.decode("utf-8")
            buffer.clear()
        start = 0
        while len(data) - start > limit:
            end = start + limit
            while data[end] & 0xC0 == 0x80:
                end -= 1
            yield data[start:end].decode("utf-8")
            start = end
        buffer.extend(data[start:])
    if buffer:
        yield buffer.decode("utf-8")


def _write_report(
    path: Path, lines: Iterable[str], limit: int, root: Path
) -> dict[str, Any]:
    if _require_inside(path, root, "merged report") != path:
        raise WorkflowError(f"Merged report must be at its assigned path: {path}")
    parts_dir = path.parent / "parts" / path.stem
    parts = []
    largest = 0
    for index, part in enumerate(_report_parts(lines, limit), start=1):
        part_path = parts_dir / f"part-{index:06d}.md"
        if _require_inside(part_path, root, "report part") != part_path:
            raise WorkflowError(f"Report part must be at its assigned path: {part_path}")
        with _atomic_text_writer(part_path, root) as stream:
            stream.write(part)
        parts.append(part_path)
    with _atomic_text_writer(path, root) as stream:
        for part_path in parts:
            data = part_path.read_bytes()
            if not 0 < len(data) <= limit:
                raise WorkflowError(f"Report part exceeds its byte budget: {part_path}")
            largest = max(largest, len(data))
            stream.write(data.decode("utf-8"))
    for old_part in parts_dir.glob("part-*.md"):
        if re.fullmatch(r"part-\d{6,}\.md", old_part.name) and old_part not in parts:
            old_part.unlink()
    return {
        "path": _relative(path, root),
        "parts_directory": _relative(parts_dir, root),
        "part_count": len(parts),
        "largest_part_bytes": largest,
    }


def _report_lines(
    validation: dict[str, Any], counts: Counter, failures: Counter,
    scope: list[tuple[str, str, int, int, str]], findings: list[tuple[str, dict[str, Any]]],
    rule_sources: dict[str, str], blocker: str,
) -> Iterable[str]:
    expected = validation["expected_pair_count"]
    reviewed = sum(counts.values())
    complete = validation["coverage_complete"] and reviewed == expected
    coverage = "完整" if complete else "未完成"
    if failures["mandatory"]:
        conclusion = "已发现强制类违规"
    elif not complete or counts["not_verifiable"]:
        conclusion = "已核实项目中未发现强制类违规，仍有未核实项"
    else:
        conclusion = "未发现强制类违规"
    yield (
        f"# 独立 RTL 编码规则审查报告\n\n"
        f"- 任务：{_markdown_text(validation['task_id'])}\n"
        f"- 覆盖：{coverage}，已记录 {reviewed}/{expected} 对\n"
        f"- 结论：{conclusion}\n\n"
        "| 通过 | 违规 | 不适用 | 未验证 | 未检查 |\n"
        "|---:|---:|---:|---:|---:|\n"
        f"| {counts['pass']} | {counts['fail']} | {counts['not_applicable']} | "
        f"{counts['not_verifiable']} | {max(0, expected - reviewed)} |\n\n"
        f"- 违规分布：强制类 {failures['mandatory']}，推荐类 {failures['advisory']}，"
        f"高阶审查项 {failures['higher_order']}\n\n"
    )
    yield "## 规则文件\n\n"
    for language, path in rule_sources.items():
        yield f"- {language}：{_markdown_text(path)}\n"
    yield "\n"
    yield "## 文件覆盖\n\n"
    for path, language, checked, expected_for_source, reason in scope:
        yield f"- {_markdown_text(path)}（{language}）：{checked}/{expected_for_source} 对\n"
        if reason:
            yield f"  - 覆盖限制：{_markdown_text(reason)}\n"
    if not complete:
        yield "\n## 覆盖限制\n\n"
        if blocker:
            yield f"- {_markdown_text(blocker)}\n"
        diagnostics = Counter()
        for error in validation["errors"]:
            if error.startswith(("frozen_source_missing:", "new_unreviewed_source:", "source_rediscovery_failed:")):
                yield f"- {_markdown_text(error)}\n"
            else:
                category = error.split(":", 2)
                diagnostics[category[1] if error.startswith("SRC-") else category[0]] += 1
        for diagnostic, count in sorted(diagnostics.items()):
            yield f"- {_markdown_text(diagnostic)}：{count}\n"
    for status, title in (("fail", "违规"), ("not_verifiable", "未验证项")):
        yield f"\n## {title}\n\n"
        if not counts[status]:
            yield "无。\n"
        for path, row in findings:
            if row["status"] == status:
                yield from _finding_lines(path, row)


def _issue_lines(findings: list[tuple[str, dict[str, Any]]]) -> Iterable[str]:
    yield "# RTL 违规问题卡\n\n"
    for path, row in findings:
        if row["status"] == "fail":
            yield from _finding_lines(path, row)


def command_report(args: argparse.Namespace) -> dict[str, Any]:
    if not 256 <= args.part_bytes <= MAX_REPORT_PART_BYTES:
        raise WorkflowError(f"--part-bytes must be between 256 and {MAX_REPORT_PART_BYTES}")
    root = _project_root(args.project_root)
    task_dir = _task_dir(root, args.task_id)
    if not (task_dir / "queue_state.json").is_file():
        raise WorkflowError("Report requires a prepared task")
    report_dir = root / "reports" / "standalone_lint" / args.task_id
    if _require_inside(report_dir, root, "report directory") != report_dir:
        raise WorkflowError("Report directory must be at its assigned path")
    with _task_lock(task_dir, root):
        _, catalog, manifest, queue = _load_runtime(root, args.task_id)
        validation, _ = command_validate(args)
        items = {item["source_id"]: item for item in queue["items"]}
        counts = Counter()
        failures = Counter()
        scope = []
        findings = []
        catalogs = _catalogs_by_language(catalog)
        catalog_errors = {language: _catalog_integrity(selected) for language, selected in catalogs.items()}
        for source in manifest["sources"]:
            item = items.get(source["source_id"])
            language = source.get("language", "verilog")
            selected = _source_catalog(catalog, source)
            checked = 0
            if not catalog_errors[language]:
                for row in _report_rows(root, task_dir, selected, source, item):
                    status = row["status"]
                    checked += 1
                    counts[status] += 1
                    if status == "fail":
                        failures[row["level"]] += 1
                    if status in {"fail", "not_verifiable"}:
                        findings.append((source["path"], row))
            reason = item.get("last_reason") if item and item["status"] == "blocked" else None
            scope.append((source["path"], language, checked, len(selected["rules"]), reason or ""))
        report = _write_report(
            report_dir / "Standalone_Lint_Report.md",
            _report_lines(validation, counts, failures, scope, findings,
                          {language: selected["rule_source"]["path"] for language, selected in catalogs.items()},
                          args.blocker),
            args.part_bytes, root,
        )
        issues = _write_report(report_dir / "issue_cards.md", _issue_lines(findings), args.part_bytes, root)
        return {
            "command": "report",
            "task_id": args.task_id,
            "coverage_complete": (
                validation["coverage_complete"]
                and sum(counts.values()) == validation["expected_pair_count"]
            ),
            "expected_pair_count": validation["expected_pair_count"],
            "languages": validation["languages"],
            "reviewed_pair_count": sum(counts.values()),
            "status_counts": {status: counts[status] for status in sorted(VALID_STATUSES)},
            "failure_counts": dict(failures),
            "part_bytes_limit": args.part_bytes,
            "report": report,
            "issue_cards": issues,
        }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Offline full-source x full-rule standalone RTL audit workflow"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    def common(subparser: argparse.ArgumentParser) -> None:
        subparser.add_argument("--project-root", required=True)
        subparser.add_argument("--task-id", required=True)

    prepare = subparsers.add_parser("prepare", help="Freeze RTL/rules and create matrices")
    common(prepare)
    prepare.add_argument("--rule-file", help="Override the Verilog/SystemVerilog rule Markdown")
    prepare.add_argument("--vhdl-rule-file", help="Override the VHDL rule Markdown")
    prepare.add_argument("--source-root", default=None)
    prepare.add_argument("--exclude", action="append", default=[])
    prepare.add_argument("--max-workers", type=int, default=8)
    prepare.add_argument("--rule-batch-size", type=int, default=25)
    prepare.add_argument("--rule-batch-bytes", type=int, default=DEFAULT_RULE_BATCH_BYTES)
    prepare.add_argument("--max-requeues", type=int, default=DEFAULT_MAX_REQUEUES)

    dispatch = subparsers.add_parser("dispatch", help="Reserve queued files for agents")
    common(dispatch)
    dispatch.add_argument("--worker", action="append", default=[])
    dispatch.add_argument("--count", type=int, default=MAX_WORKERS_HARD_LIMIT)

    accept_batch = subparsers.add_parser("accept-batch", help="Validate and checkpoint one batch")
    common(accept_batch)
    accept_batch.add_argument("--assignment-id", required=True)
    accept_batch.add_argument("--batch-id", required=True)

    complete = subparsers.add_parser("complete", help="Assemble and validate one file matrix")
    common(complete)
    complete.add_argument("--assignment-id", required=True)

    requeue = subparsers.add_parser("requeue", help="Release a failed assignment for retry")
    common(requeue)
    requeue.add_argument("--assignment-id", required=True)
    requeue.add_argument("--reason", required=True)
    requeue.add_argument(
        "--kind", choices=("worker_failed", "worker_lost", "invalid_result"), default="worker_failed"
    )

    release = subparsers.add_parser("release", help="Return an unstarted assignment without a retry")
    common(release)
    release.add_argument("--assignment-id", required=True)
    release.add_argument("--reason", required=True)

    unblock = subparsers.add_parser("unblock", help="Return one blocked source to the queue")
    common(unblock)
    unblock.add_argument("--source-id", required=True)
    unblock.add_argument("--reason", required=True)
    unblock.add_argument("--additional-requeues", type=int, default=1)

    status = subparsers.add_parser("status", help="Show queue and available reservation slots")
    common(status)

    validate = subparsers.add_parser("validate", help="Validate global source x rule closure")
    common(validate)

    report = subparsers.add_parser("report", help="Render bounded report parts and merge locally")
    common(report)
    report.add_argument("--part-bytes", type=int, default=MAX_REPORT_PART_BYTES)
    report.add_argument("--blocker", default="", help="Known reason for incomplete coverage")
    return parser


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = _parser()
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            result = command_prepare(args)
            passed = True
        elif args.command == "dispatch":
            if args.count < 1:
                raise WorkflowError("dispatch --count must be positive")
            result = command_dispatch(args)
            passed = True
        elif args.command == "accept-batch":
            result = command_accept_batch(args)
            passed = True
        elif args.command == "complete":
            result = command_complete(args)
            passed = True
        elif args.command in {"requeue", "release"}:
            result = command_end_assignment(args)
            passed = result["result"] != "blocked"
        elif args.command == "unblock":
            result = command_unblock(args)
            passed = True
        elif args.command == "status":
            result = command_status(args)
            passed = True
        elif args.command == "report":
            result = command_report(args)
            passed = True
        else:
            result, passed = command_validate(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if passed else 2
    except WorkflowError as exc:
        print(
            json.dumps(
                {"command": getattr(args, "command", None), "ok": False, "error": str(exc)},
                ensure_ascii=False,
                indent=2,
            ),
            file=sys.stderr,
        )
        return 2
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(
            json.dumps(
                {
                    "command": getattr(args, "command", None),
                    "ok": False,
                    "error": f"Invalid workflow data or filesystem operation: {exc}",
                },
                ensure_ascii=False,
                indent=2,
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
