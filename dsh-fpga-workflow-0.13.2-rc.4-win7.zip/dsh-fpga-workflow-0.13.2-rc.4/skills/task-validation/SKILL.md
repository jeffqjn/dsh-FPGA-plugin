---
name: task-validation
description: 分块审查FPGA研制任务书，支持子Agent并行局部审查、增量复核和用户确认的补充信息；支持指定缺项暂缓和初版架构，收到生成请求并与用户确认本版未明确项后生成FEIP交接包和需求清单。
---

# FPGA任务书分块审查与交接包确认

明确缺失且用户当前无法提供的信息，可经批准按问题UID标记“待补充”，继续审查和初版架构。正式交接包的生成需要用户先提出生成请求，再确认本版没有其他未明确项，并同意开始生成。

[skill功能测试模式](references/skill-test.md)仅在用户明确要求测试时可模拟闭环。先向用户展示本版未明确项及拟模拟范围，收到用户明确确认后才能生成独立测试包。

本版2.3.1。指定缺项暂缓、四视图初版架构和从对话纳入补充材料，见[初版架构与补充更新](references/provisional.md)。优先用 delta_template，核对证据回显；用 review-reopen 在新目录修正已发布审查，保留原快照。旧attempt须按[运行接口](references/runtime.md)重新prepare；插图见[插图核验](references/illustrations.md)。

先读[分块审查接口](references/batching.md)和[审查规则](references/review_rules.md)。参数/授权记录按需查[运行接口](references/runtime.md)。每个Agent只读分派的任务包及必要原文，不整份读取原文归档、工程Schema、review_source.txt或model.template.json。每个片段完成即提交，恢复时以磁盘checkpoint为准。

输入为任务书DOCX或保留章节/表格顺序的TXT/MD及用户明确提供的附件。缺图、附件未读或关键抽取缺失必须列问题，不能默认为完整。目标Windows7 SP1、PowerShell2.0、Python3.8.10，仅标准库。先用宿主execute command执行准确解释器路径下的cli.py doctor，核对退出码和FEIP_SKILL_OK:doctor；不使用未经核实的解释器。

## 审查与问题闭环

1. `prepare --input <任务书> --output <根目录> [--attachments <附件清单JSON>] [--chunk-chars 4000]`。返回当前小模板及阅读包，默认按约4000正文字符预算分块。
2. 有多个待审局部块且宿主支持子Agent时，启用[并行局部审查](references/batching.md#并行局部审查与增量复核)，最多8路，受宿主并发上限约束。主Agent按task_uid分派，并负责串行review-submit。其余情况顺序执行。每块优先读取delta_template和本块原文，另存精简片段JSON；reviewed=true必须基于实际阅读。检查需求质量及测试要点，记录问题位置、影响、建议、关闭依据和对象索引；依赖其他章节/附件时用review-read分页调取原文并将unit加入scope_unit_refs。长段落/表格续片须结合条件、表头及合并关系核查。
3. 局部块完成后依次处理structure、quality、consistency、coverage四组全局任务。用 `review-read --task global:<组> --view <视图> [--entry <UID>]` 按需查询问题索引、源目录、局部摘要和抽取目标。问题状态与当前证据由其所属任务更新，其他组可引用已登记的问题UID。沿目录和对象索引回查原文，交叉检查时钟、复位、接口、协议、验收与测试判据。不得由局部通过推导全局通过。此阶段不建立完整工程台账、正式编号、writer_plan或需求清单。
4. 提交全部任务后执行`review --attempt <目录> --output <新审查目录>`及validate。报告逐项展示位置、影响、修改建议及关闭证据。分类明确：资料确实未给是 missing_information；多个来源互相冲突是 contradiction；图或附件未读是 unread_evidence；其余为 other。不能凭缺省、严重级别或“非阻断”字段自行放行。
5. 用户无法补充时，列出建议暂缓的缺项UID、原因、影响、补充条件及关联待办，请用户批准明确范围。只要确属缺少信息，原记录为 open、deferred 或标有 blocking=true 均可提请批准。经批准后，按 architecture-status 的 pending 清单列为“待补充”，并按 blockers 核对初版架构还需解决的问题。确认无剩余阻断后生成并验证四视图初版架构。对依赖缺项的模块或接口，标注影响及待定参数，按已明确的资料推进其余部分。正式交接包仍须真实闭环。
6. 用户提供新信息时，先分析归类、目标章节/模块、拟写文本、关联问题及影响；展示提案并征求确认。只有确认后执行 supplement-apply 生成版本化修改文档及补充附件，随原任务书和旧审查状态重新prepare，增量复核并更新交接包、架构及修改文档。旧快照保留；发生冲突时复核后才能关闭，不能以新消息自动覆盖旧要求。附件或源文修订也用`--previous-state <上轮目录/review_state.json>`复核；默认重做四组全局检查。
7. 所有问题及待办关闭、30条规则pass/not_applicable、源内容全覆盖且抽取缺失已解决后，状态为AWAITING_STRUCTURE_CONFIRMATION。若尚未为本版出具初版架构，先生成并验证。收到生成交接包的请求后，展示输入版本、审查报告和当前未明确项（含待补充项及影响）。清单为空时明确写“本版未发现未明确项”，并请用户确认本版有无其他未明确项、是否开始生成。有未明确项时先按清单澄清、复核，再请用户确认更新后的版本。

## 用户确认后生成交接包

收到生成请求后须等待用户对本版清单的明确答复。初始请求、沉默或只批准暂缓的回复均不构成交接确认。用户提出新信息时，更新并复核相应版本后重新确认。得到确认后连续完成生成与校验。同版有效确认可用于续跑。

1. 确认后按[运行接口](references/runtime.md#任务书交接包用户确认)登记 approve_taskbook_structuring，绑定本版审查UID和摘要，保留生成请求与后续确认的实际原话。收到确认后才执行建模 prepare。
2. 这时才读[分批建模接口](references/model-batching.md)与[建模约束](references/modeling.md)。执行`prepare --input <同版任务书> --output <新根目录> --closed-review <闭环目录> --confirmation <授权JSON>`，有附件时传同版附件清单。脚本维护完整模板，Agent只读取当前片段。
3. 循环model-next/model-submit，按块建立源父/原子义务、工程需求修订、分析对象、inventory和验证覆盖。提交时脚本先检查证据、UID及源语义；失败按报告只修相关片段，不全量重新生成/重提。以submit返回的progress推进，不重复轮询model-status或无目标sleep。model-schema按字段导出所需Schema；model-read分页查询既有UID并关联，避免重复对象。新normalized_id先留null，源前缀明确后脚本最终统一编号。未给出的技术事实保持unknown。
4. 局部模型完成后先执行[model-preflight快速预检](references/preflight.md)，valid=true才进入meta、basic_info、system_overview、acceptance、views五组小任务。领取/提交meta时会自动强制此门禁，同版结果缓存复用。公共信息任务只填本组fields；源对象、placements和章节素材在局部片段中完成。修正局部模型后旧meta过期，但领取新任务会保留旧fields作为待复核草稿，不从空白重写或手改摘要强行提交。脚本装配唯一writer_plan及30条审查判断；测试覆盖逐义务判断，不凭ID引用或虚构结果。
5. `structure --attempt <目录> --output <新FEIP目录> --architecture <本版已验证初版架构目录>`：脚本合并、编号、校验和渲染，再validate。缺片、冲突UID、失效引用、未闭环或gap均不得发布。发现新的源问题写new_issues并返回审查，完成复核并取得用户对新版的确认后继续生成。

全部校验通过后交付package.json、model.json、taskbook_review.md、[需求清单.md](references/requirement-list.md)、本版初版架构、原文及补充快照、结构归档和随包Schema（taskbook-reviewed）。用户确认的真实性及语义判断由Agent负责。
