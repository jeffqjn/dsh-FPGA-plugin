# 分批执行与增量复查（2.3.1）

脚本负责提取、分块、版本比较、进度、合并、编号及MD渲染，Agent负责语义判断。局部审查可由主Agent分派给子Agent。正式结构化要求真实闭环，[初版架构](provisional.md)在独立目录先行，使用单独门禁。

## 审查任务包与提交

```text
prepare --input <任务书> --output <根目录> [--attachments <附件清单JSON>] [--chunk-chars 4000]
review-status --attempt <本轮目录> [--pending-local]
review-next --attempt <本轮目录> [--task chunk:...或global:...]
review-submit --attempt <本轮目录> --model <另存的本任务JSON>
review --attempt <本轮目录> --output <新的审查目录>
validate --package <审查目录>
```

prepare返回的template/reading均指向当前小任务。默认status返回完成数、复用数和下一任务。默认next从磁盘恢复下一未完成任务，显式指定`--task`可准备指定任务包。填模板后另存片段提交。技术中断可在同一attempt继续，源输入改变后必须新prepare。

默认约4000字符预算，可在1000～12000调整。以章节/段落为边界打包，不混不同章节和附件；表格按行保留列、合并范围等信息，长行/长段落显式分成连续片段，原文完整归档。预算含估算的定位开销，不等于token上限。阅读包用u00001/e00001等本轮短编号代替长UID；脚本维护映射，提交后存储完整UID，避免抄写和重复元信息。续片不是独立新要求；需核查ctx指向的相关片段、条件、表头及合并关系。

局部片段字段：

- 保持contract、run_uid、task_uid、basis_sha256；summary简述本块检查结果，建议不超过500字。
- reviewed_unit_refs须覆盖当前块全部unit（模板使用u短编号）；inspected_rule_ids保留所列REQ和TST规则，实际逐条检查，不以保留列表代替判断。
- scope_unit_refs默认本块unit。只要判断依赖另章或附件，先读取原文并加入依赖unit；以后该内容变化会撤销本块复用。
- subjects记录审查对象索引：`{"key":"clock:外部时钟CLK_A","unit_refs":["unit:..."]}`。名称含角色/对象，不把不同CPU、接口或同频时钟合成一个对象。这里只作原文索引，不预建工程设计模型。
- issues/todos沿用[轻量记录格式](review-stage.md)，证据填e短编号或完整element UID，不填u编号。保持问题ID与描述；关闭须有本轮证据和理由。previous_evidence_refs仅为旧版参考，不是当前有效证据。

修正已提交片段时，先用 `review-next --task <task_uid>` 重新领取当前模板，从该模板合入更正。沿用新取模板的 `basis_sha256` 和既有依赖范围，按实际阅读增补依赖。若提交 `changes.issues` 或 `changes.todos`，数组需包含该集合的已有条目。更改描述时将 `description_rev` 从缺省的 1 加一，脚本补记原描述和证据。误报可用本轮证据和理由关闭，保留原 UID。详见[版本与精简提交](review-improvements.md)。

## 并行局部审查与增量复核

1. 主Agent完成doctor和prepare，用`review-status --attempt <目录> --pending-local`取得`pending_local_tasks`。它只列本轮缺失或过期的局部任务，已完成和有效复用的任务无需重派。并发数取8、宿主可用子Agent名额和待派发任务数三者的最小值。多个任务时调用宿主实际提供的子Agent接口，只有一块或者宿主不支持时沿用顺序执行。
2. 主Agent在本轮输出根目录下准备独立工作文件，放在attempt目录之外。每个在途`task_uid`只派给一个子Agent，用`review-next --task <task_uid>`获取任务包。交付给子Agent的输入包括解释器/CLI、attempt、`task_uid`、原文阅读包、delta模板、审查规则及独立工作目录。逐块分派，避免一次把全文、全量模板或会话历史传入子Agent。
3. 子Agent实际阅读本块和所需上下文，填写独立delta。分页调用`review-read`时每页使用同一子Agent工作目录里的新文件，例如`--unit u00001 --offset 0 --output <工作目录/page-01.txt>`。取到下一页偏移后继续查询，并把影响判断的外部unit登记到`scope_unit_refs`。默认`read.txt`用于顺序调用。每个任务独立命名新问题和待办UID，保留已有UID。长JSON按字段或条目分次写入，再保存完整片段。子Agent只回传`task_uid`、文件路径和需要协调的跨块问题。
4. 主Agent核对片段绑定、证据和跨块重复发现，串行`review-submit`并核对`evidence_preview`。成功后腾出名额继续分派。遇单次模型输出截断或中断，先检查本任务片段及checkpoint，完整片段可直接校验提交，只重派缺失或未完成任务。续跑先查磁盘进度并核对遗留片段，对仍在运行的同一任务等待或结束旧执行后再派。一次写入仍容易截断时，分次记录同一个块的所见并组装为完整片段，保持块内原文覆盖。

## 全局审查与发布

全部局部块后依次执行 structure（STR）、quality（REQ）、consistency（CON）、coverage（TST）。每组填写本组的规则 checks、问题与待办，structure 还填 extraction_checks。next 返回可用视图和条目数。按规则所需查视图，可用 `--entry` 取单条。以下分别按问题 UID、局部任务 UID 查询，原文仍用 subject 或 unit 调取。

```text
review-read --attempt <目录> --task global:consistency --view issue_index --entry issue:R1-001
review-read --attempt <目录> --task global:coverage --view source_catalog --offset 0 --limit 4000
review-read --attempt <目录> --task global:quality --view local_summaries --entry chunk:...
review-read --attempt <目录> --task global:structure --view extraction_targets
review-read --attempt <目录> --subject clock:CLK_A --offset 0 --limit 4000
review-read --attempt <目录> --unit u00001 --offset 0 --limit 4000
```

视图每行一个 JSON 条目。长条目可跨页，按返回的 `next_offset` 续读，拼接后解析。局部摘要给出问题 UID，问题描述和归属可在 issue_index 单查。视图按当前有效 checkpoint 生成。省略 `--view` 可查询兼容的完整 JSON。对象索引和摘要用于找原文，判断冲突和覆盖须核查相关条款、条件和测试判据。未索引对象也应按目录发现。global 的 checks.evidence_refs 使用 element UID，fail/unknown 关联 open 问题。

全局上下文的issue_index列出历史/本轮问题UID、owner_task和registered_in_current_round。旧全局问题由原全局组复核；原局部块已消失或旧格式无责任信息时交给quality。checks.issue_refs可引用已登记的历史UID，即使其责任组尚未提交；不用为满足引用校验把同一问题复制到多个组。历史状态仅供定位，责任组仍须提交本轮状态、证据和关闭理由；最终汇总检查fail/unknown是否关联本轮open问题，历史closed不会自动放行。新发现的问题先在本组issues登记，再引用其uid。

GLOBAL_RULE_ISSUE_REFERENCE_INVALID会列出rule和unknown_issue_uids。核对issue_index中的uid，不能用显示编号、todo UID、e/u原文编号或拼错的ID。只有真实登记的问题可引用，不通过清空未解决问题或把规则改pass消除报错。

最后review不传--model，脚本要求所有局部/全局checkpoint均完整且同版，合并后重算闭环门禁。不会生成需求交付物。原整份--model入口保留兼容旧的小文档调用，不作为大文档默认执行方式。

## 多轮修改：安全复用局部结果

新prepare传`--previous-state <上轮审查目录/review_state.json>`。脚本在已核验的旧记录上比较正文、章节、抽取状态和显式依赖，重映射仍可唯一匹配的原文证据。整份文件摘要变化不会使全部局部条款身份失效。

本块/其上下文变化、重复文本无法唯一定位、规则/脚本变化时不复用；表格任意行变化会保守地重审整表。变化使同章分块边界移动时也可能扩大重审。四组全局判断每轮重做，以发现新增交叉关系。未受影响的旧closed问题可沿版本核验证据复用，open问题必须解决；必要时用next --task重取其所属块。改变已提交局部结果会自动使当前全局checkpoint过期。

复用保存了检查结果，并不等于用户修改自动正确；影响范围不确定时增加scope依赖或复查相关块。旧问题原所属块已消失时，转交global:quality复核，不删除历史问题。所有问题与待办闭环后，收到用户生成请求才展示本版未明确项清单，等待用户明确确认后再开始建模。

闭环后即读取[分批建模接口](model-batching.md)并开始生成。
