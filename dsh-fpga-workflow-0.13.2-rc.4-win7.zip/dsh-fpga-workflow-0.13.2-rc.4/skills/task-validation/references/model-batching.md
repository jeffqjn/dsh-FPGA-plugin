# 闭环后的自动分批建模（2.0.0）

正常模式要求审查闭环，收到用户生成请求后展示本版未明确项，再取得用户确认。明确测试请求按[测试模式](skill-test.md)确认本版模拟范围。

取得本版用户确认后，连续执行到structure发布。


```text
prepare --input <同版任务书> --output <新根目录> --closed-review <闭环目录> --confirmation <确认JSON>
model-status --attempt <建模目录>
model-next --attempt <建模目录> [--task model:...]
model-schema --attempt <建模目录> --path /analysis/interfaces
model-read --attempt <建模目录> --path /requirements --offset 0 --limit 4000
model-submit --attempt <建模目录> --model <另存片段JSON>
model-preflight --attempt <建模目录>
structure --attempt <建模目录> --output <新FEIP目录>
```

有附件时prepare必须传同版--attachments。建模输出比源文本大，脚本将建模块预算限制为最多1500字符、每块最多4个源单元，给模型输出预留空间；可将--chunk-chars降到1000。model-schema首先返回紧凑字段/类型指南，完整约束保留在schema_path和提交校验器中，不需整份阅读工程Schema。模型引用使用当前片段给出的完整UID与evidence映射，审查阶段短编号不直接写入FEIP对象。model-read按next_offset分页查既有对象；`--path /source-index`查源目录，`--path /source-unit/unit:...`调取续片。公共信息也可用`review-read --attempt <建模目录>/closed_review --subject <对象键>`查询原审查索引。

建模片段字段：

- contract、run_uid、task_uid、basis_sha256不改；covered_unit_refs覆盖本任务源片段。
- collections是JSON Pointer到“本次新增条目数组”的映射，例如`/requirements`、`/source_baseline/parents`、`/analysis/constraints`。只填写本块实际对象；相同UID复用同一内容，不能用不同值静默覆盖。guide列出允许路径，schema按路径查询。
- fields只在对应的公共信息任务填写，按meta/basic_info/system_overview/acceptance/views分组；不许改protocol、冻结原文、源摘要或审批信息。
- inventory逐项描述本块涉及element的规范性、落地引用和处理理由。表格/长段落跨块时各片保留本片引用，脚本合并到同一原文元素；任何片仍pending都阻止最终生成。
- placements条目为`{"requirement_uid":"req:...","section":"5.4","role":"main"}`，role可为main/cross/deferred。每个有效义务一个主落点；deferred仅用于模板规定的deferred/manual章节。
- section_notes按章节号提交status/reason及object_refs/material_element_refs/paragraphs/tables；脚本保留标准章节和表结构，冲突时报具体路径，不擅自选值。
- new_issues记录结构化中新发现的源问题。提交后本attempt锁定为RETURN_TO_REVIEW；不能删除发现记录、改另一片或直接传整模型来绕过。返回新一轮审查，闭环后展示新版并重新取得用户确认，再继续生成。

## 提交检查与meta前预检

model-submit在保存checkpoint前检查本片空证据、失效evidence UID、同片源语义不一致、重复UID及完整源编号，并利用对象摘要索引检查跨片冲突，失败输出JSON/MD诊断路径。只修报告指定的任务；不要重新生成或重提全部局部片段。跨片前向引用可稍后补齐；跨片atom/revision同步修订可分次提交，pending_cross_fragment_checks会立即提示暂时差异，进入meta前必须消除。

全部局部片段完成后执行model-preflight，汇总仍有的结构、引用、证据、源语义、台账保留、inventory和落点问题；详见[快速预检接口](preflight.md)。next/submit领取或提交meta时自动要求局部预检通过，同版结果缓存，不重复做全量结构检查。状态LOCAL_MODEL_INVALID时读报告并定点修正，不去反复填五个meta。FEIP_SKILL_OK只表示命令执行完成，必须检查valid及state。

五个meta任务只填写各自fields，不允许新增collections/inventory/placements/section_notes；这些内容须在局部任务阶段完成。局部变化仍会使五个meta的旧basis过期。model-next返回recheck_required=true时，模板已保留旧fields作为草稿并更新版本绑定；核对受影响信息后再提交，不直接修改旧文件的basis或盲目确认旧值。完全相同内容的重复提交不使meta过期。

局部任务先完成并通过预检，再依次处理五组公共信息小任务。脚本转用已确认的30条审查判断及证据，无须Agent再次抄写；仍须如实报告新发现。修改局部模型片段会撤销依赖旧片段的公共信息checkpoint，旧字段保留为待复核草稿。

建议新normalized_id先留null，使用稳定UID关联跨片对象；最终在源编号前缀已明确时由脚本按类别统一编号，保留已有合法编号。前缀未知不补造。脚本合并writer_plan、校验全量追溯和门禁，最后一次性输出model.json与需求清单.md；缺片、未闭环、冲突引用或缺授权记录均不发布。

## writer交接

脚本建立13章/4附录及全部子标题。第7章及子节deferred；10/11/C/D为manual。每条有效义务一个主落点，其余章节交叉引用。规范性内容进入B0，描述性内容保留archive/material_element_refs。不提前为空白章节生成结论，不丢测试素材。

系统/平台、接口/信号、状态行为、数据格式、时钟复位、安全可靠、验收交付、进度和图表素材均有去向。时钟角色/来源/关系、安全属性、器件数量/型号和编号前缀需要证据，不伪填技术值或XYXY。
