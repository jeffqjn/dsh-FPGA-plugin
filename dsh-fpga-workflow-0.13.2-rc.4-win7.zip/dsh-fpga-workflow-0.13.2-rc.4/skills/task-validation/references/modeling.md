# FEIP 语义建模与审查约束

正常模式在审查闭环、用户提出生成请求并确认本版未明确项后使用。[skill功能测试模式](skill-test.md)使用本版模拟范围的专用确认。1.7.0采用model-next/model-submit按源块建模，通过model-preflight局部预检后再处理五组公共信息；按model-schema请求所需字段，model-read分页查对象，不读取/重写完整model.template。完整模型、writer_plan与审查证据由脚本装配，正常structure要求PASS、全部问题/待办关闭且无gap。正常模式new_issues锁定本attempt返回审查，闭环并获得新版确认后继续。

修订1.1.0：任务书交接计划必须完整安置每个有效原子义务；TP标complete须具有对象、目的、刺激、步骤、预期、判据及关联需求。writer冻结requirements、analysis、verification及已知基本事实，只调整文档组织与有来源的元信息。

checker会对Agent提供的显式映射再次比较条件、输入输出、处理规则、异常、安全属性、约束运算符、数值/区间/容差，并支持s/ms/us/ns、Hz/kHz/MHz、byte/KiB/bit的同维度等价换算。结构差异产生REQ-STRUCTURED问题，不接受单独修改complete标签。此机制不理解任意自然语言，也不代替原文抽取与语义审查。已有partial/deviated结论不会仅因结构子集相同而提升为complete。

豁免须绑定当前issue指纹、对象与字段范围；旧resolved问题不能遮住当前仍存在的结构差异。每轮必须复查旧问题，明确关闭已修复的问题和关联To do，保留历史。结构问题重新出现时重开。发布目录不得位于输入快照内部。

字段与章节映射按需检索随包[协议字段覆盖清单](protocol/字段与覆盖清单.md)的相关类别；本块所需类型用model-schema --path导出，不先读全量Schema。只有需核实具体协议约束时检索[协议设计](protocol/协议设计.md)相关段落。下文checker/一致性比对内容用于下游，任务书建模优先读取源保留、逐元素覆盖、证据身份和下游view约束。

## 不可交换的三类数据

1. source_baseline：源B0不可变，源父ID/原子ID分别存储，原文和全部约束保留。
2. requirements：工程台账，至少每个源原子义务有记录；已删除/被豁免/文档遗漏都不能删账。修订引用独立constraint UID。
3. spec_items：当前用户文档实际存在的义务，不把源条款复制成文档已落实。display_id允许缺失或错误，机器item UID仍必须唯一。

源父对象按正文中实际定义的完整UR编号及条款身份登记，不能只按UR/UR-XN等公共前缀或chunk编号合并不同条款。目录中的UR通常是导航索引，附录A测试表中的UR通常是需求引用，不因此重复建立parent；测试点建立源测试对象并关联已有需求。若附录确实增加新的规范性义务，应明确识别并报告，不能统一忽略。

同一UR的多条件/多variant拆为不同原子义务，父对象只登记一次，完整保留该条款原文与证据。后续分片引用已有parent UID，不重建只有本片局部原文的同UID父对象。需要补齐父对象时回到其登记片段更新完整内容；不同完整UR编号使用不同父UID。原子语义和对应source修订必须连同真实evidence_refs保持完全一致，不能写固定空证据或靠取第一个重复对象消除冲突。

批准增改删作为独立Decision。修改建立新修订，不改B0/历史constraint。删除将effective_revision_uid置null并保留源修订；豁免不改变B1，不算覆盖。用户批准值必须核验已落实在当前文档，否则仍保留待修改。NEW_KEY必须批准新增或从文档删除，不能靠笼统忽略进入下游。

## 逐元素覆盖

prepare生成archive和pending inventory。对每个段落、表格、图/附件判断：modeled、descriptive_only、historical、out_of_scope或pending；规范性义务必须有工程引用。10/11/C/D原文不删除，不专项分析；出现疑似新增工程义务应pending分类并显式gap。

把主体/动作/对象、条件/工况、输入/处理/输出、所有量值和运算符、区间端点/开闭、容差、异常/恢复、验证方法分别保存。技术值用十进制字符串带单位，归一化仅在可靠等价时填写。未说明是unknown/null，不得默认false/0、接口方向、数量、安全属性或频率。

工程含义按analysis的context_entities、modes/scenarios、functions、behaviors、interfaces/signals/protocols/formats、data_objects、constraints、clocks/resets/power、platform_resources、dependability、assumptions保存。非标准标题下的状态机、复位、数据、异常行为也须建模；不能只保存章节摘要。

非规范性分析/建议标inference/unconfirmed，不进入有效需求。不替用户选择模块、FIFO深度、同步器或算法。已有实现限制忠实转录，设计选择交给下游架构skill登记。

## 证据及身份

所有规范性义务有evidence_refs；关键字段的混合来源用provenance精确到目标UID和字段路径。证据指向prepare冻结文件的artifact，不接受Agent填写的失效绝对路径。原archive对象不可改写，解释写在provenance/inventory。

prepare会创建`feip.assessments.v1`扩展：taskbook逐项覆盖30条STR/REQ/CON/TST规则，checker覆盖15条检查规则。Agent为每条填写pass/fail/not_applicable/unknown、具体判断依据、evidence_refs、issue_refs。pass/不适用必须有证据，fail/unknown必须有关联问题，不能只把总gate改成PASS。此扩展是阶段审查记录，核心协议消费者可以忽略；本阶段脚本会强制校验其完整性和引用。

工程req UID、revision UID、源atom UID、文档item UID不同；首次分配后持久化。章节移动、换行和显示编号变化不重新分配工程身份。normalized_id由源首次排序生成、后续只增不重排：实际配置项前缀-FREQ/IREQ/PREQ/SREQ/RREQ/OREQ-序号[-KNMR]。安全属性以原子修订为权威，不向同组非安全项传播K。

## 一致性比对

编号对齐只是候选。逐义务核对条件、约束、异常、输入输出和判据；一个父项多个原子义务必须逐项核验。一对多/多对一可以有多个spec_item_refs，但不能合并丢工程身份。编号合法却用错内容、多个候选、未知映射均需问题，不算complete。

同对象/工况下允许区间不交才是CONTRADICTION；可以同时满足但阈值不同是CONSTRAINT_MISMATCH。10ms和0.01s可靠等价不报错；≤和<、限定工况丢失必须报偏离。源TP保留ID但丢刺激/预期/判据仍未落实。

器件、IP、信号是不同对象：检查真实引用与信号总表/子表一致，不比较异类名称集合。时钟外/内部来源分开，有证据才填写频率/同步关系，同频不证明同步。

## 多轮问题与门禁

stable_key由规则、工程/文档UID、义务/字段构成，不含段落位置、问题排序或全文数值。保留旧issue UID/display_id、完整history；重开回open。每个旧问题都显式复查，不从“本轮未出现”推导resolved。

open error/blocking→FAIL；仅需澄清的open warning→NEEDS_CLARIFICATION；所有需闭环问题关闭→PASS。建议进入notices，避免永远open。ignored必须有有效具体豁免；confirmed必须有批准变更/映射且最新内容已核验。

输入损坏、混批次、机器引用失效、关键抽取不完整、未知映射、统计/Schema错误不能豁免。upstream非PASS的checker只可diagnostic。每轮原始B0和有效B1覆盖分别重算；零分母rate=null，豁免不计complete。

## 下游友好

architecture/simulation/confirmation三个view分别给readiness、理由、引用、缺口、允许/排除范围。PASS含豁免仍可能blocked；只有获允许的明确子集可以conditional，不能笼统放行。

验证方法与场景类型分开；源TP、VO、TC、RUN及执行证据分开。不可测试项必须有限制原因、版本和替代验证；测试点缺判据不是不可测试依据。需求阶段只记录有依据的义务，不能伪造仿真/板测结果。
