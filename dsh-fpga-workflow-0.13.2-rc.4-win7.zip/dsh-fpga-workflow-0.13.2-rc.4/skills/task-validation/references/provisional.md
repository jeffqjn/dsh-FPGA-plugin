# 初版架构与对话补充

审查原状态保持真实。暂缓只放行初版架构；`structure` 的正式门禁不变。初版交接目录包含 `architecture_handoff.json`、`初版架构.md`、本轮纳入审查的确认补充文档，无 FEIP 发布清单。

## 指定缺项暂缓

1. 在审查片段的 issue 上登记 `category`（`missing_information`、`contradiction`、`unread_evidence`、`other`，旧记录缺省 other）。属于缺少信息的开放问题可直接提请暂缓，即使原记录为 open 或 blocking=true。旧记录如把单纯缺项归错类别，按证据修正后重新发布审查。依赖同一缺项的待办可标 `deferred` 并一并提请批准，独立未完成的工作保持 open。
2. 当用户说明当前无法补充时，展示拟暂缓的精确UID和关联待办，请用户确认。没有明确批准就不登记；不影响其他无关审查。已确认后保存：

```json
{
  "kind": "approve_architecture_deferral",
  "review_uid": "本轮已发布审查的UID",
  "review_state_sha256": "本轮已发布审查的SHA256",
  "issue_uids": ["issue:R1-001"],
  "todo_uids": [],
  "actor": "实际确认人",
  "confirmed_at": "实际确认时间，含时区",
  "user_quote": "明确批准上述范围的用户原话"
}
```

todo_uids 只列用户明确批准暂缓、且关联上述缺项的待办。未列出的待办仍阻断。同一版本可续跑；审查版本变化后重新核对剩余缺项与影响，并针对该版本确认，旧记录不得复用。未知参数仍未知；矛盾、未读资料和其他开放项不可伪装为缺项。因缺项导致的规则 fail/unknown 必须真实关联全部原因；已知一致性失败（CON-* fail）及未解决的抽取限制始终阻断。

```text
architecture-status --review <已发布审查> [--deferral <暂缓批准JSON>]
architecture-draft --review <已发布审查> --model <架构候选JSON> --output <新初版交接目录> [--deferral <暂缓批准JSON>]
architecture-validate --review <已发布审查> --draft <初版交接目录>
```

status 返回本轮版本绑定、实际阻断项 blockers、仍可提请批准的 deferral_candidates，以及已批准的 pending 和 pending_todos。后两类保留原始审查状态，作为初版架构的“待补充”清单。ARCHITECTURE_READY 时编制初版架构。候选对象包括原样复制的 review_uid、review_state_sha256 和 views。views 的四个键均为非空数组：

| 键 | 内容 |
|---|---|
| information_flow | 谁发命令、配置、状态或告警，传给谁，如何反馈 |
| data_flow | 数据输入、主要处理/缓存/转换路径、输出 |
| design_architecture | FPGA与板外边界、主要功能块及已知的时钟/复位/接口关系 |
| module_responsibilities | 每个拟定模块的职责、输入输出与上下游边界 |

每行形如 `{"description":"从上游接口接收数据，宽度待补充","basis":"proposed","evidence_refs":["当前源元素UID"],"pending_refs":["issue:R1-001"]}`。basis=source 须有真实源证据且无待补充引用；引用 partial 元素时须一并引用与该元素对应的已核验转录。proposed 是基于证据或缺项的设计建议，unknown 须关联待补充UID。使用方向明确的箭头或短句，避免仅列模块名。不要为凑齐栏目发明接口、频率、位宽、时序或模块选型。正式闭环且取得本版用户交接确认后，以本版验证过的目录传给 `structure --architecture` 一起归档；旧版初版架构保留作历史。

## 对话信息归类、确认、更新

1. 对照当前已发布审查及设计，逐条拆分用户输入。说明它属于需求/接口/四视图/验证/项目的哪一部分，列出现有位置、拟写文本、关联问题及修改影响；无法归类或与既有来源冲突时，明确缺什么或哪条应取代哪条，先澄清。普通说明、建议、设问和当前测试输入不能默认当成工程事实。
2. 编写并向用户展示同一份可审阅提案，含 review_uid、review_state_sha256 和 items。示例单项：

```json
{
  "uid": "sup:R2-001",
  "section": "interfaces",
  "target": "第4.2节 / 外部控制接口",
  "operation": "clarify",
  "source_quote": "用户提供的实际原话",
  "proposed_text": "用户需要确认的准确写入文本",
  "impact": "影响的模块、验证判据或相邻章节",
  "issue_refs": ["issue:R1-001"]
}
```

section 可取 requirements、interfaces、information_flow、data_flow、design_architecture、module_responsibilities、verification、project；operation 为 add、clarify 或 replace，替换项须指明旧条款和取代范围。尚无已发布审查时先暂存提案并继续审查，确认须绑定最终提案与发布版本。用户仅确认一部分时，先缩减并核对精确提案范围，不能批准混合文件。
3. 明确确认后，登记 kind=approve_taskbook_supplement，review_uid、review_state_sha256 与本轮一致，proposal_sha256 为用户确认的提案文件SHA256，附 actor、confirmed_at、user_quote。修改提案需重新确认。
4. 执行 `supplement-apply --review <已发布审查> --proposal <提案JSON> --confirmation <确认JSON> --output <新修改目录>`。输出补充与修改记录MD、批准记录JSON、合并后的附件清单。以原任务书、该 `--attachments`、返回的 `--previous-state` 启动新审查。原始DOCX保留作证据；生效修改在有明确目标章节的补充与修改文档中体现。仅“确认写入”内容供技术复核；确认引语、影响和未采纳的原话仅为追溯材料。收录补充不等同于关闭问题；规范性变更须核对证据和冲突，跨模块影响也要检查。若还有冲突，交付已确认修改记录和阻断清单，继续复核，不提前发布架构或正式包。
5. 复核后重新生成本版初版架构/待补充清单；批准补充作为源附件进入初版和正式交接包。脚本按摘要冻结修改文档、原提案字节及确认记录；内容有变时重新提案。下一轮会继承先前已确认的补充，显式提供新附件清单时也不得删除旧记录。正式建模时若本轮审查含附件，传本轮审查目录下的 `inputs/attachments.json`。对同一审查版本有多条输入时合成一个提案，或在纳入上一条补充的新版本上继续，避免从同一旧版并行分叉遗漏补充。
