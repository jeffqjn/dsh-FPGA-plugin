# 审查效率与证据改进（1.9.0）

deferred 表示待定，仍是未闭环。2.1.0允许指定缺项经用户批准后推进[初版架构](provisional.md)；正式FEIP须全部闭环，并在生成请求后取得本版用户确认。双 Word 直接比较属于另一个独立目录。

## 精简提交

prepare/review-next 同时返回 delta_template 和兼容的完整 template。优先读取前者：

```json
{
  "contract": "taskbook-review-delta/1.0",
  "run_uid": "run:从当前返回值取得",
  "task_uid": "chunk:从当前返回值取得",
  "basis_sha256": "从当前返回值取得",
  "reviewed": true,
  "changes": {"summary": "本片真实检查结论", "issues": [], "todos": []}
}
```

reviewed=true 是 Agent 对已读完整当前分片、按局部规则检查的显式声明，不能未读先填。脚本补回机械字段，不自动生成语义判断。全局仍须明确提交 checks；structure 组还须明确填写 extraction_checks。跨章节阅读须用 changes.scope_unit_refs 加入已读单元；原文查询仍用 review-read。

issues/todos 若在 changes 出现，是该集合的全量替换，必须包含已有和历史条目；不出现则保留当前模板条目。subjects 省略保留模板值。run_uid、task_uid、basis_sha256 不得省略或手改，旧 delta 仍会被拒绝。重提不删除问题，历史证据不能充当本版关闭证据。

## 证据定位与回显

issue/todo 可增加 location（给用户的章节/表号/图号说明）及 evidence_locations：

```json
{"unit_uid":"u00231","row":3,"label":"表4-3 CMD_RST"}
```

放入 evidence_locations 数组，配合原 evidence_refs。unit_uid 可用当前短号，row 为零起始行号；报告显示含表头的一起始行号。脚本核对单元、源元素和已读范围一致；提交结果 evidence_preview 回显真实文本前80字、类型和行号。Agent 必须核对回显与问题是否相关，合法 UID 不证明语义相关；脚本不以词语重合假装完成语义核验。

## 修订与恢复

同一问题保持稳定 UID。description 改变时，description_rev 从缺省1增至2、3……；脚本保存 description_history，原描述与旧证据仍可追溯。不允许无修订号更换问题含义。跨轮旧问题优先迁到相同源单元或唯一相同章节的分片，无法唯一定位时保守交给 quality，仍须复核，不能自动关闭。

```text
review-reopen --attempt <已发布审查目录> --output <全新恢复工作目录>
```

review-unpublish 为同一动作的兼容别名，仍必须指定全新目录。恢复保留 checkpoints、历史和父审查绑定，只修相关任务后发布新版本；原发布目录、旧审批和交付物不变。不能直接编辑已发布目录。局部变化返回 invalidates 和 stale_tasks，按清单复核全局。原样重提不失效；不以自动重填替代全局复核。全局计算本已延迟到领取/提交，不另加无实际收益的 --defer-global。

## 插图、转录和分块

见[插图核验](illustrations.md)。附件清单可写 role=transcription，默认仍是 attachment。不超过20000正文字符的转录附件合并成一个证据任务，仍须阅读和关联；不允许据角色丢掉图中独有的规范性义务。源分片保留完整行和续片，避免同章节不足300字符时只因标题再碎分。prepare 返回任务数与紧凑提交提示。

## 可选全局复用与环境检查

prepare 可加 --incremental-global，默认关闭。当前实现仅在全部源文件摘要、所有局部记录依赖和规则均未变且局部完整复用时保留全局结论，并在报告标记；修改任何源内容仍复查四组。没有经证实的全局依赖范围时，不按“附近章节没改”猜测某组可复用。

doctor --output <已存在工作目录> 核验写入与临时文件清理、FPGA_PYTHON38 与实际解释器一致，并输出 skill 根目录、CLI、版本。问题编号建议 issue:R<首次发现轮次>-NNN；已有 UID 不重编号。报告首页显示严重度统计、待定数、阻断项和跨轮新增/关闭/重开/仍开清单。
