# 轻量审查记录接口（1.7.0）

默认使用[分批接口](batching.md)。prepare只返回当前小片段的模板/阅读包，完整结构归档、review_source.txt及review.template.json由脚本维护；以下为最终汇总记录字段，正常分批执行不需要Agent整份填写。review-submit接收当前片段，最后review自动合并。原review --model仅保留旧小文档兼容。轻量记录用于审查闭环，不是工程台账。

- `contract`、`run_uid`保持模板值；`summary`填写本轮审查范围和结论。
- `reviewed_element_refs`列出全部已阅读元素UID，须与所有归档元素一一对应，含空行和标题。图/附件未读情况另用抽取检查明确记录，不因列入清单就声称已理解。
- `checks`保留30条规则。每条填`status`（pass/fail/unknown/not_applicable）、`rationale`、`evidence_refs`、`issue_refs`。所有判断须有原文证据；缺项判断可引用应出现该内容的章节或全文范围。fail/unknown须关联open问题。
- `extraction_checks`保留每份归档。抽取完整时填`status=complete`及依据；partial/not_read只能填unresolved或verified_transcription。后者须说明核验范围，`transcription_map`逐项填写 `{"target_ref":"受限源元素或归档UID","evidence_refs":["转录元素UID"]}`，顶层 `evidence_refs` 为映射所引证据的并集。目标清单见 `review-read --task global:structure` 的 `extraction_targets`，须全覆盖；证据只可来自本轮 role=transcription 的其他完整可读附件。对应关系的真实性由Agent核验。
- `issues`逐项记录`uid`、`description`、`status`（open/closed/deferred）、`category`（见[初版架构](provisional.md)，缺省other）、`severity`（error/warning/info）、`blocking`（布尔）、`evidence_refs`、`impact`、`recommendation`。closed还必须有`closure_reason`和`closure_evidence_refs`。不以ignored/waived/confirmed代替闭环；纯建议可写summary。
- `todos`记录`uid`、`issue_uid`、`description`、`status`、`evidence_refs`；closed必须有`closure_reason`和`closure_evidence_refs`。正式FEIP前所有待办均须关闭。

跨轮用`--previous-state <上轮目录/review_state.json>`保留问题/待办ID与描述；不能删除旧项或复用ID表达另一问题。旧轮记录作为冻结输入保留。脚本可复用内容、章节、规则和依赖均未变化且证据可唯一重定位的局部结论；其余任务重查，四组全局每轮重做。open问题仍需关闭，不能由复用自动变closed。

`review`重算状态：有open问题、未关闭待办、未通过规则或未解决抽取限制时为REVIEWING；全部闭环时为AWAITING_STRUCTURE_CONFIRMATION，表示本版已闭环，等待用户确认。只发布`review_state.json`、`taskbook_review.md`与审查材料，没有`package.json`、`model.json`或`需求清单.md`。`validate`校验记录、引用、源摘要及文件完整性，不代替Agent语义审查。

`taskbook_review.md`面向用户阅读：未闭环问题优先，每项展示编号、状态、严重程度、阻断标记、问题描述、关联规则、原文章节/结构元素定位及节选、影响和修改建议；已闭环项附关闭依据与证据。待办逐项展示关联问题、内容和闭环证据，规则结果以表格展示。结构元素序号不是Word页码或段落编号。无问题/待办时明确写无；不得把issues/todos的JSON直接当成报告正文。完整机器记录保留在`review_state.json`，报告渲染不改变问题状态或确认门禁。

收到生成请求后展示本轮报告、源版本和未明确项。清单为空也须请用户确认有无其他未明确项并同意开始。收到明确答复后按[运行接口](runtime.md)登记确认，再建模和发布。
