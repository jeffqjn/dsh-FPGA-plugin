# 离线运行接口（2.3.1）

正式交接包在审查闭环、用户提出生成请求并确认本版未明确项后开始生成。[指定缺项暂缓、初版架构与对话补充](provisional.md)可在审查中推进。

统一交换协议保持FEIP/1.0.0。正式CLI只接受Python 3.8.10。默认分块审查、保存进度并增量复查。只有当前用户明确声明进行skill功能测试时可用[测试旁路](skill-test.md)，不自动启用。prepare返回当前小任务的template/reading；完整归档和模板由脚本维护，Agent不必阅读。结构化采用单片前置校验及[meta前快速预检](preflight.md)。structure最终发布FEIP包及需求清单；测试包的PASS仅为模拟放行。输出目录必须为输入快照之外的新目录。分批操作详见[分批执行接口](batching.md)。

task-validation为独立skill，部署时复制本skill文件夹。FEIP核心协议保持兼容，运行脚本只用Python标准库。

升级后保留旧审查目录，使用已导出的review_state.json作为previous-state，在新目录重新prepare当前DOCX。旧attempt和授权因规则摘要变化失效。

## 环境

- Windows7 SP1；PowerShell2.0；Python **3.8.10**，补丁版本也必须相同。CLI 对其他版本直接报 PYTHON_RUNTIME_MISMATCH，无生产绕过开关。
- 用户安装的解释器默认 `C:\Python38\python.exe`；其他位置设置进程环境变量 `FPGA_PYTHON38`，值必须是 python.exe 完整路径。无需 py launcher、pip、python-docx、jsonschema 或 Node 全局命令。
- PowerShell入口只使用2.0语法，不依赖 PSScriptRoot、ConvertFrom-Json、Get-FileHash、Expand-Archive、Get-ChildItem -File/-Recurse 的新参数、`::new`、管道并行或新运算符。JSON解析、摘要和归档由Python完成。
- JSON/MD 输出使用 UTF-8 无 BOM。`review-submit --model` 也兼容带 UTF-8 BOM 的审查片段。PS1 使用纯 ASCII。环境变量仅影响当前进程及其子进程。

宿主现在支持execute command（或execute_command），优先直接执行Python CLI，无需Node.js包装器：

```powershell
& 'C:\Python38\python.exe' 'D:\skills\task-validation\scripts\cli.py' doctor
& 'C:\Python38\python.exe' 'D:\skills\task-validation\scripts\cli.py' self-test
```

以上是PowerShell2.0命令文本示例，由宿主的execute command工具执行；使用实际安装路径，不虚构宿主工具名或参数。若宿主支持可执行文件/参数数组，应分别传入python.exe和脚本参数。其他动作直接在cli.py后追加动作及参数即可。

也可继续使用PowerShell2.0便捷入口：

```powershell
$env:FPGA_PYTHON38 = 'C:\Python38\python.exe'
& 'D:\skills\task-validation\scripts\run.ps1' doctor
```



任何执行入口均须核对退出码0和本动作`FEIP_SKILL_OK:<action>`，并检查返回路径的本次产物。门禁FAIL不代表脚本执行失败，检查结果在报告及JSON中。

## 动作

| 动作 | 参数 | 说明 |
|---|---|---|
| doctor | 无 | 精确Python版本检查；记录当前OS，不声称在Win7验收过 |
| self-test | 无 | 临时目录运行结构/事务/拒绝用例，结束清理 |
| extract | --input 文件 --output JSON | 提取DOCX/TXT/MD；输出archive结构，不自动理解规范性语义 |
| prepare | --input 文件 --output 根目录 [--previous-state 上轮review_state.json] [--attachments 附件清单JSON] [--chunk-chars 4000] | 冻结、分块、按版本复用有效局部检查；返回当前小任务 |
| review-status / review-next | --attempt 目录；status可加--pending-local；next可加--task 任务ID | 查询进度、获取待审局部任务列表或指定任务包 |
| review-submit | --attempt 目录 --model 本任务片段JSON | 验证并保存checkpoint；更正保留历史，自动撤销过期全局结论 |
| review-read | --attempt 目录 --unit unit:... 或--subject 对象键 或--task global:... [--view 视图名 [--entry UID]] [--offset 0] [--limit 4000] [--output 新文件] | 按字符分页读取原文或全局上下文，返回 next_offset。并行读取时每页指定独立文件 |
| review | --attempt 目录 --output 新目录 [--model 完整轻量记录JSON] | 默认合并全部checkpoint，仅审查/闭环报告；--model仅兼容旧小文档调用 |
| architecture-status / architecture-draft / architecture-validate | 见[初版架构接口](provisional.md) | 核验本轮暂缓范围及阻断，生成和验证独立初版架构交接 |
| supplement-apply | --review 已发布审查 --proposal 提案JSON --confirmation 用户确认JSON --output 新目录 | 冻结确认信息，生成修改文档和包含补充的附件清单 |
| prepare | --input 文件 --output 根目录 --closed-review 闭环目录 --confirmation 用户确认JSON [--attachments 同版附件清单JSON] [--chunk-chars 4000] | 校验审查闭环和本版用户确认后创建建模分片 |
| prepare（仅skill功能测试） | --input 文件 --output 测试根目录 --closed-review 本版审查目录 --confirmation 专用测试确认JSON --skill-test [--attachments 同版附件清单JSON] | 用户要求测试并确认本版模拟范围后，生成标记synthetic的测试模型。详见[测试接口](skill-test.md) |
| model-status / model-next | --attempt 目录；next可加--task 任务ID | 查询/恢复建模进度；公共信息分五组处理 |
| model-submit | --attempt 目录 --model 本任务片段JSON | 校验片段形状、证据、UID与语义并保存，返回progress；普通模式new_issues锁定本attempt返回审查，已授权测试模式保留发现历史并继续 |
| model-preflight | --attempt 建模目录 | 只读预检已保存的局部模型，一次汇总问题到JSON/MD；valid=true才可进入五meta，结果按局部摘要缓存；可诊断兼容旧attempt |
| model-schema | --attempt 目录 --path /analysis/interfaces等允许路径 | 仅导出该字段/集合及依赖Schema |
| model-read | --attempt 目录 --path /requirements等路径 [--offset 0] [--limit 4000] | 分页查询已提交对象，避免重复建UID |
| structure | --attempt 已授权建模目录 --output 新目录 [--architecture 同版已验证架构目录] [--model 完整Agent模型JSON] | 合并全部分片、编号、校验和渲染；普通模式缺授权/缺片/新问题均不发布；附架构时验证版本；测试模式仅模拟语义门禁 |
| generate | --attempt 目录 --model Agent模型JSON --output 新目录 | 仅writer；从冻结writer_plan装配完整MD及FEIP草稿包 |
| compare | --attempt 目录 --model Agent模型JSON --output 新目录 | 仅checker；Agent判断，脚本核验并产轮次包 |
| finalize | --candidate 闭环轮次目录 --confirmation 确认JSON --output 新目录 | 仅checker；核验候选/规则/输入/授权后生成最终reqspec.json |
| validate | --package 审查目录或FEIP包目录 | 自动识别并核验文件摘要、引用、闭环状态或FEIP业务不变量 |

taskbook prepare不传baseline/decisions/diagnostic。局部结果按内容/章节/显式依赖复用，模糊匹配与变更保守重审，四组全局每轮重做。writer/checker原参数不变。output为新目录；分批checkpoint可在同一attempt继续或修正（旧值归档），最终review/structure只消费一次汇总模型；源输入改变必须新prepare。

`prepare`不是语义分析。按next提供的小模板另存并submit，不编辑冻结归档或完整模板。review/structure默认由脚本装配，不要求Agent抄写全文、全量元素ID、30条规则或大JSON。空模板、缺片、未完整检查不能闭环。详见[轻量记录字段](review-stage.md)与[分批接口](batching.md)。

附件清单为`[{"path":"D:/project/协议附件.docx","description":"外部协议定义"}]`。附件原字节一并冻结；DOCX/TXT/MD继续结构提取，图片/PDF等二进制标not_read并要求核实转录。附件不允许只保存外部路径后宣称已经读取。checker附件中的新增规范性义务仍按NEW_KEY/源遗漏处理，不擅自改B0。

## 决定与授权记录

### 任务书交接包用户确认

所有问题及待办关闭、全部规则pass/not_applicable、源内容已阅读且抽取缺失已解决后，review返回AWAITING_STRUCTURE_CONFIRMATION及本版review_uid、review_state_sha256。收到用户生成请求后，展示本版报告和当前未明确项，清单为空时也明确告知。等待用户明确确认本版没有其他未明确项且同意开始生成，再登记：

```json
{
  "kind": "approve_taskbook_structuring",
  "review_uid": "从当前闭环审查结果读取",
  "review_state_sha256": "从当前结果读取64位摘要",
  "actor": "实际确认人",
  "confirmed_at": "实际收到确认的时间，含时区",
  "request_quote": "用户最初要求生成交接包的实际原话",
  "user_quote": "用户看过本版清单后明确确认并同意开始的实际原话",
  "review_items_confirmed": true
}
```

字段按实际对话填写。宿主负责确认先收到生成请求、再展示当前清单、最后收到明确答复。脚本验证闭环状态、确认字段、时间与版本绑定。收到确认前不执行建模prepare。源输入、附件、审查或规则变化，以及建模中新发现未明确项，都须复核并取得新版确认。同一版本的失败重试可以使用有效的原确认。

### 下游checker确认

本轮新增决定通过`prepare --decisions decisions.json`输入；文件为完整FEIP Decision对象数组，Agent从用户明确意见登记，不能自己发明意见。模型中的新增Decision必须逐字匹配该数组，证据关联该文件artifact。用户未表明理由/对象/目标值时保留待办，不登记生效批准。

compare闭环且准入通过时产生candidate_payload.json、review_packet.md、candidate_manifest.json，交付状态AWAITING_FINAL_CONFIRMATION；此时没有正式reqspec.json。Agent向用户展示当前审阅包及完整模型，再请求最终生成确认。

用户明确确认该版本后，记录如下文件；candidate的ID及摘要取compare返回结果，不猜填：

```json
{
  "kind": "approve_release",
  "candidate_uid": "candidate:从当前轮次读取",
  "candidate_manifest_sha256": "从当前轮次读取64位摘要",
  "actor": "当前用户（未提供姓名）",
  "confirmed_at": "带时区的实际确认时间",
  "user_quote": "用户对当前候选明确要求生成最终JSON的原话"
}
```

这是字段说明，不能把上面示例当成授权输入。程序只能核验记录与候选绑定，用户意见真实性由skill宿主保证。单项问题确认、沉默、超时、认可设计方案都不是approve_release。原文/模型/决定/规则/Schema变化须重新比较和确认。完全相同候选写入失败后的重试可以复用有效确认，无需重复询问。

失败发布目录带`.staging-.../FAILED.json`且package.status=staging；不能作为交接包。目录锁阻止同名并发发布；不自动清理别人的锁或失败资料。

## 抽取范围

支持正文段落、内容控件中的正文、表格、合并格、可恢复的十进制编号、标题样式、页眉页脚及脚注/尾注文本。原DOCX字节完整归档。

图片不做OCR；图中文字、修订未接受、嵌入对象、编号覆盖/自定义格式、域结果与文本框等标出partial。嵌入对象保留所在文档部件、章节/表格位置、关系ID和包内目标（可读时），抽取器不打开或执行对象。无法可靠阅读的关键内容必须阻断；提供可核查转录并保留原对象出处后重新prepare。不能把“XML可解析”当成全量工程内容已读取，也不能伪造页码。
