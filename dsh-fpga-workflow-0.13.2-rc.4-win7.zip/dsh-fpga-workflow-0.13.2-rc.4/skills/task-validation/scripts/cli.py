"""Offline skill CLI; deliberately rejects every Python except 3.8.10."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from feiplib.base import check_runtime
from feiplib.workflow import run

def main():
    try:
        check_runtime()
        result = run()
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        print("FEIP_SKILL_OK:" + sys.argv[1])
        return 0
    except Exception as exc:
        print("FEIP_SKILL_ERROR: " + str(exc), file=sys.stderr)
        return 2

if __name__ == "__main__":
    sys.exit(main())
