"""I/O, version, transactional package publication and contract integration."""
import copy
import json
import os
import platform
import shutil
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

from . import contract

SKILL = Path(__file__).resolve().parents[2]
SCHEMAS = SKILL / "references/protocol/schemas"
contract.ROOT = SKILL / "references/protocol"
VERSION = "2.3.1"

class Failure(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise Failure(message)

def uid(kind):
    return kind + ":" + uuid.uuid4().hex

def now():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")

def check_runtime():
    require(sys.version_info[:3] == (3, 8, 10), "PYTHON_RUNTIME_MISMATCH: requires exactly Python 3.8.10; got " + platform.python_version())

def load(path):
    return contract.read_json(Path(path))

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    # Keep the staging name independent of the destination name for legacy Windows paths.
    temp = path.with_name(".tmp-" + uuid.uuid4().hex[:16])
    stream = temp.open("x", encoding="utf-8", newline="\n")
    try:
        with stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()

def text(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(value)

def digest(path):
    return contract.sha_file(Path(path))

def schema_model(model):
    schema = load(SCHEMAS / "engineering.schema.json")
    contract.audit_schema(schema)
    errors = contract.validate_schema(model, schema)
    require(not errors, "MODEL_SCHEMA_INVALID:\n" + "\n".join(errors[:40]))

def known_artifacts(attempt):
    info = load(Path(attempt) / "attempt.json")
    return {a["uid"]: a["path"] for a in info["artifacts"]}

def verify_inputs(attempt):
    attempt = Path(attempt)
    info = load(attempt / "attempt.json")
    for binding in info["input_bindings"]:
        path = contract.safe_artifact(attempt, binding["path"])
        require(path.is_file() and digest(path) == binding["sha256"], "STALE_INPUT: " + binding["path"])
    # Detect external edits after prepare, not only edits to frozen copies.
    for original in info["original_inputs"]:
        path = Path(original["path"])
        require(path.is_file() and digest(path) == original["sha256"], "ORIGINAL_INPUT_CHANGED: " + str(path))
    return info

def verify_package(directory):
    errors = contract.validate_package(Path(directory))
    require(not errors, "PACKAGE_INVALID:\n" + "\n".join(errors[:40]))
    manifest = load(Path(directory) / "package.json")
    artifact = next(a for a in manifest["artifacts"] if a["uid"] == manifest["model_artifact_uid"])
    model = load(contract.safe_artifact(Path(directory), artifact["path"]))
    from . import icd
    if icd.required(model) or (Path(directory) / "icd.json").is_file():
        icd.verify(directory, model)
    from . import requirement_list
    if requirement_list.required(model):
        requirement_list.verify(directory, model)
    return model, manifest

def register_files(root, model, known, model_filename):
    # All files are retained; inherited artifact UIDs remain valid.
    by_path = {v: k for k, v in known.items()}
    artifacts = []
    for path in sorted(Path(root).rglob("*")):
        if not path.is_file() or path == Path(root) / "package.json" or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(root).as_posix()
        role = "engineering-model" if relative == model_filename else "supporting-artifact"
        artifact_uid = by_path.get(relative, "artifact:" + contract.fingerprint(model["protocol"]["run_uid"] + "|" + relative)[:24])
        artifacts.append({"uid": artifact_uid, "role": role, "path": relative, "media_type": "application/json" if path.suffix == ".json" else "application/octet-stream",
            "sha256": digest(path), "size_bytes": path.stat().st_size, "required": True})
    model_art = next(a for a in artifacts if a["path"] == model_filename)
    return {"protocol_version": "1.0.0", "package_uid": uid("package"), "profile": model["protocol"]["profile"],
        "run_uid": model["protocol"]["run_uid"], "status": "complete", "synthetic": model["protocol"]["synthetic"],
        "created_at": now(), "model_artifact_uid": model_art["uid"], "parent_packages": [], "artifacts": artifacts,
        "subject_binding": [], "schema_artifact_refs": [a["uid"] for a in artifacts if a["path"].startswith("schemas/")],
        "candidate_uid": model["consistency"]["release_binding"]["candidate_uid"] if model["consistency"]["release_binding"] else None}

def publish(output, model, sources_root, known, extras=None, final=False):
    output = Path(output).resolve()
    sources_root = Path(sources_root).resolve()
    require(output != sources_root and sources_root not in output.parents,
            "OUTPUT_INSIDE_SOURCE: publication must be outside its source snapshot")
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.exists(), "OUTPUT_EXISTS: use a new output directory")
    lock_path = output.parent / ("." + output.name + ".lock")
    try:
        lock = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise Failure("OUTPUT_LOCKED: " + str(lock_path))
    staging = output.parent / (output.name + ".staging-" + uuid.uuid4().hex)
    try:
        os.close(lock)
        shutil.copytree(str(sources_root), str(staging))
        # Copy fresh schema bytes, with no dependency on a sibling skill.
        for schema in SCHEMAS.glob("*.json"):
            destination = staging / "schemas" / schema.name
            destination.parent.mkdir(exist_ok=True)
            shutil.copyfile(str(schema), str(destination))
        extras = dict(extras or {})
        from .skill_test import NAMESPACE, banner, report as test_report
        if any(e["namespace"] == NAMESPACE for e in model["extensions"]):
            require(model["protocol"]["synthetic"] is True, "SKILL_TEST_MARKER_REQUIRED")
            extras["测试模式说明.md"] = test_report(model)
            for relative, value in list(extras.items()):
                if relative.endswith(".md") and isinstance(value, str) and "【仅供skill功能测试】" not in value:
                    extras[relative] = banner(model) + value
        for relative, value in extras.items():
            destination = contract.safe_artifact(staging, relative)
            if isinstance(value, str):
                text(destination, value)
            elif isinstance(value, bytes):
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(value)
            else:
                save(destination, value)
        model_filename = "reqspec.json" if final else "model.json"
        save(staging / model_filename, model)
        manifest = register_files(staging, model, known, model_filename)
        info_path = staging / "attempt.json"
        if info_path.exists():
            info = load(info_path)
            if info.get("parent_package"):
                manifest["parent_packages"] = [info["parent_package"]]
        save(staging / "package.json", manifest)
        verify_package(staging)
        os.rename(str(staging), str(output))
    except Exception as exc:
        if staging.exists():
            save(staging / "FAILED.json", {"status": "staging-failed", "error": str(exc)})
            # Do not leave a complete manifest on a failed attempt.
            package_file = staging / "package.json"
            if package_file.exists():
                package = load(package_file)
                package["status"] = "staging"
                save(package_file, package)
        raise
    finally:
        lock_path.unlink()
    return {"output": str(output), "profile": model["protocol"]["profile"], "package_sha256": digest(output / "package.json")}

def fact(value=None, reason="来源未明确", evidence=()):
    return {"status": "unknown" if value is None else "present", "value": value,
        "reason": reason if value is None else None, "evidence_refs": list(evidence)}

def gate(model):
    items = [x for x in model["consistency"]["issues"] if x["status"] == "open"]
    gates = model["consistency"]["gates"]
    gates["blocking_issue_refs"] = sorted(x["uid"] for x in items if x["blocking"])
    gates["local"] = "FAIL" if any(x["blocking"] or x["severity"] == "error" for x in items) else "NEEDS_CLARIFICATION" if items else "PASS"
    gates["upstream"] = model["source_baseline"]["status"]
    gates["overall"] = gates["local"] if gates["admission"] == "READY" else "FAIL"
    gates["has_exceptions"] = any(d["status"] == "active" and d["kind"] in ("approve_change", "waive_issue") for d in model["consistency"]["decisions"])
    return gates

def effective(model):
    model["effective_requirements"] = [{"requirement_uid": r["uid"], "revision_uid": r["effective_revision_uid"],
        "alignment": r["effective_alignment"], "waiver_refs": r["waiver_refs"]} for r in model["requirements"] if r["lifecycle"] == "active"]
    metrics = [m for m in model["traceability"]["metrics"] if m["name"] not in ("b0_document_realization", "b1_document_realization")]
    atoms = model["source_baseline"]["atomic_requirements"]
    mappings = model["traceability"]["mappings"]
    b0 = sum(any(m["source_atomic_uid"] == a["uid"] and m["status"] == "complete" for m in mappings) for a in atoms)
    values = model["effective_requirements"]
    for name, covered, total in (("b0_document_realization", b0, len(atoms)), ("b1_document_realization", sum(x["alignment"] == "complete" for x in values), len(values))):
        metrics.append({"name": name, "basis": "atomic obligations; waivers never count as complete", "covered": covered, "total": total, "rate": None if total == 0 else covered / total})
    model["traceability"]["metrics"] = metrics
    for view in model["views"].values():
        view["requirement_refs"] = copy.deepcopy(values)

def check_model(model, artifact_uids):
    schema_model(model)
    errors = contract.semantic_checks(model, artifact_uids)
    require(not errors, "MODEL_INVARIANT_INVALID:\n" + "\n".join(errors[:40]))
