"""Synthetic behavioral tests for bounded packets, incremental review and model assembly."""
import copy
import json
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import batches, model_batches
from .base import Failure, load, save, text, verify_package
from .prepare import prepare
from .review_stage import review


def finish_review(attempt, root, conflict=False):
    manifest = load(Path(attempt) / "review-work/manifest.json")
    ref = manifest["units"][0]["element_uid"]
    while not batches.status(attempt)["complete"]:
        task = batches.next_task(attempt)
        payload = load(task["template"])
        payload["summary"] = "虚构分块检查，预设判断仅用于脚本测试"
        for item in payload["issues"] + payload["todos"]:
            item.update(status="closed", evidence_refs=[ref], closure_reason="虚构本轮已核验修订", closure_evidence_refs=[ref])
        if payload["task_uid"].startswith("chunk:"):
            payload["subjects"] = [{"key": "clock:synthetic", "unit_refs": payload["reviewed_unit_refs"][:1]}]
        else:
            for check in payload["checks"]:
                check.update(status="pass", rationale="虚构跨块检查完成", evidence_refs=[ref], issue_refs=[])
            if "extraction_checks" in payload:
                for check in payload["extraction_checks"]:
                    check.update(status="complete", rationale="虚构文本已完整读取")
            if conflict and payload["task_uid"] == "global:consistency":
                payload["issues"].append({"uid": "issue:cross", "description": "虚构跨章时钟冲突", "status": "open", "severity": "error", "blocking": True,
                                          "evidence_refs": [ref], "impact": "虚构影响", "recommendation": "统一虚构时钟值"})
                payload["checks"][0].update(status="fail", issue_refs=["issue:cross"])
        filename = root / "current-review-fragment.json"
        save(filename, payload)
        batches.submit(attempt, filename)


def fill_model_fragment(attempt, task, full_model, first=False):
    payload = load(task["template"])
    if not model_batches.is_metadata(payload["task_uid"]):
        inventory = {r["element_uid"]: r for r in full_model["completeness"]["content_inventory"]}
        payload["inventory"] = [inventory[r["element_uid"]] for r in payload["inventory"]]
        if first:
            manifest = load(Path(attempt) / "model-work/manifest.json")
            payload["collections"] = {p: model_batches.get(full_model, p) for p in manifest["collection_paths"] if model_batches.get(full_model, p)}
            payload["placements"] = [{"requirement_uid": "req:latency", "section": "5.4", "role": "main"}]
    else:
        payload["fields"] = {p: model_batches.get(full_model, p) for p in payload["fields"]}
    return payload


def batch_tests(root):
    root.mkdir()
    results = []

    def rejects(name, function, contains=None):
        try:
            function()
        except (ValueError, KeyError, OSError) as exc:
            if contains:
                assert contains in str(exc), (name, str(exc))
            results.append(name)
        else:
            raise AssertionError("negative case accepted: " + name)

    source = root / "large.txt"
    content = "\n".join("# %d 第%d章\n%s" % (chapter, chapter, "\n".join("UR-%d-%d FPGA应按命令%d处理输入并输出规定结果。" % (chapter, row, row) for row in range(18))) for chapter in range(1, 7))
    text(source, content)
    prep = prepare("taskbook", root / "review-input", source, chunk_chars=1000)
    attempt = Path(prep["attempt"])
    manifest = load(attempt / "review-work/manifest.json")
    assert len(manifest["chunks"]) > 6
    assert all(c["chars"] <= 1000 for c in manifest["chunks"])
    assert len([r for c in manifest["chunks"] for r in c["unit_refs"]]) == len(manifest["units"])
    assert not (attempt / "model.template.json").exists()
    assert load(prep["template"])["contract"] == "taskbook-review-fragment/1.0"
    results.append("source-partition-is-bounded-and-exhaustive-without-modeling")
    pending = batches.status(attempt, pending_local=True)["pending_local_tasks"]
    assert pending == [chunk["uid"] for chunk in manifest["chunks"]]
    packets = [batches.next_task(attempt, task_uid) for task_uid in pending[:2]]
    assert len({packet["delta_template"] for packet in packets}) == 2
    units = [chunk["unit_refs"][0] for chunk in manifest["chunks"][:2]]
    expected = [Path(batches.read_units(attempt, unit)["path"]).read_text(encoding="utf-8") for unit in units]
    assert expected[0] != expected[1]
    pages = [root / ("worker-%d/page.txt" % index) for index in range(len(units))]
    with ThreadPoolExecutor(max_workers=2) as workers:
        reads = [workers.submit(batches.read_units, attempt, unit, output=page) for unit, page in zip(units, pages)]
        assert [Path(read.result()["path"]) for read in reads] == pages
    rejects("parallel-review-page-cannot-overwrite-existing-file", lambda: batches.read_units(attempt, units[1], output=pages[0]))
    assert [page.read_text(encoding="utf-8") for page in pages] == expected
    results.append("parallel-review-workers-read-isolated-evidence-pages")
    rejects("model-batches-unavailable-before-closure-confirmation", lambda: model_batches.next_task(attempt))
    rejects("unreviewed-global-stage-cannot-start", lambda: batches.next_task(attempt, "global:consistency"))
    task = batches.next_task(attempt)
    payload = load(task["template"])
    payload["summary"] = "虚构首块预设检查"
    ref = manifest["units"][0]["element_uid"]
    payload["issues"] = [{"uid": "issue:retained", "description": "虚构已关闭的历史项", "status": "closed", "severity": "warning", "blocking": False,
                          "evidence_refs": ["e00001"], "impact": "虚构影响", "recommendation": "虚构建议", "closure_reason": "虚构已核验", "closure_evidence_refs": ["e00001"]}]
    payload["subjects"] = [{"key": "e00001", "unit_refs": ["u00001"]}]
    fragment_file = root / "fragment.json"
    bad = copy.deepcopy(payload)
    bad["reviewed_unit_refs"] = []
    save(fragment_file, bad)
    rejects("review-packet-cannot-skip-units", lambda: batches.submit(attempt, fragment_file))
    save(fragment_file, payload)
    fragment_file.write_bytes(b"\xef\xbb\xbf" + fragment_file.read_bytes())
    batches.submit(attempt, fragment_file)
    assert not (attempt / "review-work/checkpoints" / batches.filename(task["task_uid"])).read_bytes().startswith(b"\xef\xbb\xbf")
    results.append("review-accepts-utf8-bom-and-writes-bom-free-checkpoint")
    stored = batches.checkpoints(attempt, manifest)[payload["task_uid"]]["payload"]
    assert stored["issues"][0]["evidence_refs"] == [ref] and stored["subjects"][0]["key"] == "e00001"
    assert stored["subjects"][0]["unit_refs"] == [manifest["units"][0]["uid"]]
    results.append("short-evidence-and-unit-aliases-preserve-full-trace-without-changing-object-names")
    erase = copy.deepcopy(payload)
    erase["issues"] = []
    save(root / "erase-issue.json", erase)
    rejects("checkpoint-correction-cannot-delete-a-recorded-problem", lambda: batches.submit(attempt, root / "erase-issue.json"))
    assert batches.status(attempt)["chunks_done"] == 1
    assert batches.next_task(attempt)["task_uid"] != task["task_uid"]
    results.append("review-progress-resumes-from-disk-without-repeating-first-packet")
    rejects("incomplete-review-cannot-publish-or-request-confirmation", lambda: review(attempt, None, root / "premature"))
    finish_review(attempt, root)
    context = batches.read_units(attempt, task_uid="global:consistency", offset=0, limit=500)
    assert len(Path(context["path"]).read_text(encoding="utf-8")) <= 500 and context["next_offset"] == 500
    results.append("cross-chapter-context-is-paginated")
    task_context = "global:structure"
    structure = batches.next_task(attempt, task_context)
    malformed = load(structure["delta_template"])
    malformed["reviewed"] = True
    malformed["changes"]["todos"] = [{"uid": "todo:broken", "issue_uid": "issue:retained", "description": "虚构待办"}]
    save(fragment_file, malformed)
    rejects("missing-todo-fields-point-to-task-and-item",
            lambda: batches.submit(attempt, fragment_file),
            "task=global:structure; path=todos[0]; item=todo:broken; missing=evidence_refs,status")
    for view, entry in (("issue_index", "issue:retained"), ("local_summaries", task["task_uid"]),
                        ("source_catalog", task["task_uid"])):
        offset, parts = 0, []
        while offset is not None:
            page = batches.read_units(attempt, task_uid=task_context, offset=offset, limit=55,
                                      view=view, entry_uid=entry)
            assert page["view"] == view and page["matched_entries"] == 1
            parts.append(Path(page["path"]).read_text(encoding="utf-8"))
            offset = page["next_offset"]
        row = json.loads("".join(parts))
        assert row[batches.CONTEXT_VIEWS[view]] == entry
        if view == "local_summaries":
            assert row["issue_uids"] == ["issue:retained"] and "issues" not in row
    extraction = batches.read_units(attempt, task_uid=task_context, view="extraction_targets")
    assert extraction["matched_entries"] == 1
    rejects("extraction-context-view-requires-structure-group",
            lambda: batches.read_units(attempt, task_uid="global:quality", view="extraction_targets"))
    results.append("global-context-views-support-individual-entries-and-pagination")
    checkpoint = attempt / "review-work/checkpoints" / batches.filename(task["task_uid"])
    original_checkpoint = checkpoint.read_bytes()
    damaged = load(checkpoint)
    damaged["payload"]["summary"] = "corrupt"
    save(checkpoint, damaged)
    rejects("modified-review-checkpoint-is-rejected", lambda: batches.status(attempt))
    checkpoint.write_bytes(original_checkpoint)
    first_review = review(attempt, None, root / "review1")
    assert first_review["state"] == "AWAITING_STRUCTURE_CONFIRMATION"
    assert not (root / "review1/model.json").exists() and not (root / "review1/需求清单.md").exists()
    results.append("finished-batches-only-produce-review-not-demand-deliverables")
    # Change one chapter: unchanged chunks survive full-document hash/element ID changes.
    text(source, content.replace("UR-6-9 FPGA应按命令9", "UR-6-9 FPGA应按修订后的命令9"))
    prep2 = prepare("taskbook", root / "revision", source, previous_state=root / "review1/review_state.json", chunk_chars=1000)
    progress = batches.status(prep2["attempt"])
    assert 0 < progress["reused_chunks"] < progress["chunks_total"] and progress["global_done"] == 0
    old_element = manifest["units"][0]["element_uid"]
    new_manifest = load(Path(prep2["attempt"]) / "review-work/manifest.json")
    new_element = new_manifest["units"][0]["element_uid"]
    assert old_element != new_element
    reused = batches.checkpoints(prep2["attempt"], new_manifest)[task["task_uid"]]["payload"]
    assert reused["issues"][0]["evidence_refs"] == [new_element]
    results.append("unchanged-packet-reuse-remaps-source-evidence-and-invalidates-global-checks")
    finish_review(prep2["attempt"], root, conflict=True)
    second_review = review(prep2["attempt"], None, root / "review2")
    assert second_review["state"] == "REVIEWING"
    results.append("cross-chapter-conflict-still-blocks-after-local-packets-pass")
    # Scope dependencies: unchanged local text is invalidated when its explicitly read context changes.
    context_source = root / "dependencies.txt"
    text(context_source, "# 1 主条款\nFPGA使用外部时钟。\n# 2 时钟参数\n时钟频率为10 MHz。")
    dp = prepare("taskbook", root / "dependency-input", context_source, chunk_chars=1000)
    dm = load(Path(dp["attempt"]) / "review-work/manifest.json")
    dt = batches.next_task(dp["attempt"])
    dv = load(dt["template"])
    dv["summary"] = "虚构检查并显式读取另章时钟参数"
    dv["scope_unit_refs"] += dm["chunks"][-1]["unit_refs"]
    save(fragment_file, dv)
    batches.submit(dp["attempt"], fragment_file)
    finish_review(dp["attempt"], root)
    review(dp["attempt"], None, root / "dependency-review")
    text(context_source, "# 1 主条款\nFPGA使用外部时钟。\n# 2 时钟参数\n时钟频率为20 MHz。")
    dp2 = prepare("taskbook", root / "dependency-next", context_source, previous_state=root / "dependency-review/review_state.json", chunk_chars=1000)
    dm2 = load(Path(dp2["attempt"]) / "review-work/manifest.json")
    assert dt["task_uid"] not in batches.checkpoints(dp2["attempt"], dm2)
    results.append("changed-explicit-context-invalidates-unchanged-local-packet")
    # Table rows and oversized clauses remain fully represented in bounded continuations.
    docx = root / "table.docx"
    rows = "".join('<w:tr><w:tc><w:p><w:r><w:t>signal-%d</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>%s</w:t></w:r></w:p></w:tc></w:tr>' % (i, "x" * (1800 if i == 2 else 20)) for i in range(35))
    with zipfile.ZipFile(str(docx), "w") as archive:
        archive.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl>' + rows + '</w:tbl></w:body></w:document>')
    tp = prepare("taskbook", root / "table-input", docx, chunk_chars=1000)
    tm = load(Path(tp["attempt"]) / "review-work/manifest.json")
    assert all(len(u["text"]) <= 650 and len(u["context_unit_refs"]) <= 3 for u in tm["units"])
    assert {u["row"] for u in tm["units"]} == set(range(35))
    assert any(u["parts"] > 1 for u in tm["units"])
    assert "x" * 1800 in "".join(u["text"] for u in tm["units"])
    results.append("large-table-and-long-cell-split-without-losing-text-or-row-context")
    # Model fragments are only available after a current closed review and explicit confirmation.
    from .review_selftest import confirmed_prepare
    from .selftest import agent_source
    from .workflow import structure
    small = root / "model-source.txt"
    text(small, "UR-1 有效命令响应时间不大于10 ms。\nTP-A-001 发送有效命令，测量响应时间，<=10ms通过。\n" + "\n".join("说明素材%d：虚构分片运行样本。" % i for i in range(10)))
    mp = confirmed_prepare(root / "model-case", small)
    ma = Path(mp["attempt"])
    model_manifest = load(ma / "model-work/manifest.json")
    assert len(model_manifest["source"]["chunks"]) >= 3 and all(len(c["unit_refs"]) <= 4 for c in model_manifest["source"]["chunks"])
    results.append("model-packets-reserve-output-space-by-limiting-source-units")
    full = agent_source(ma)
    full["requirements"][0]["normalized_id"] = None
    ev = full["consistency"]["evidence"][0]["uid"]
    full["basic_info"]["numbering_prefix"].update(status="present", value="TEST", reason=None, evidence_refs=[ev])
    rejects("incomplete-model-fragments-cannot-render-demand-md", lambda: structure(ma, None, root / "early-model-output"))
    schema_part = model_batches.export_schema(ma, "/requirements")
    assert schema_part["bytes"] < (Path(__file__).resolve().parents[2] / "references/protocol/schemas/engineering.schema.json").stat().st_size
    results.append("model-schema-export-is-limited-to-requested-collection")
    mt = model_batches.next_task(ma)
    mv = fill_model_fragment(ma, mt, full, first=True)
    invalid = copy.deepcopy(mv)
    invalid["collections"]["/protocol"] = []
    save(fragment_file, invalid)
    rejects("model-fragment-cannot-modify-protocol-or-frozen-source", lambda: model_batches.submit(ma, fragment_file))
    save(fragment_file, mv)
    model_batches.submit(ma, fragment_file)
    first_model_task = mv["task_uid"]
    assert model_batches.status(ma)["fragments_done"] == 1
    while not model_batches.status(ma)["complete"]:
        task = model_batches.next_task(ma)
        save(fragment_file, fill_model_fragment(ma, task, full))
        model_batches.submit(ma, fragment_file)
    results.append("model-fragments-resume-and-small-metadata-tasks-complete-independently")
    read = model_batches.read_model(ma, "/requirements", limit=200)
    assert len(Path(read["path"]).read_text(encoding="utf-8")) <= 200
    results.append("model-cross-references-can-be-read-with-bounded-pagination")
    correction = load(model_batches.next_task(ma, first_model_task)["template"])
    correction["section_notes"] = {"5.4": {"status": "present", "reason": "虚构性能素材已核实"}}
    save(fragment_file, correction)
    model_batches.submit(ma, fragment_file)
    assert model_batches.status(ma)["fragments_done"] == len(load(ma / "model-work/manifest.json")["source"]["chunks"])
    results.append("local-model-edit-invalidates-metadata-derived-from-old-fragments")
    while not model_batches.status(ma)["complete"]:
        task = model_batches.next_task(ma)
        save(fragment_file, fill_model_fragment(ma, task, full))
        model_batches.submit(ma, fragment_file)
    output = root / "batched-feip"
    structure(ma, None, output)
    final, package = verify_package(output)
    assert final["requirements"][0]["normalized_id"] == "TEST-PREQ-1"
    assert "有效命令响应时间不大于10 ms" in (output / "需求清单.md").read_text(encoding="utf-8")
    assert final["source_baseline"]["status"] == "PASS"
    results.append("confirmed-fragments-assemble-number-validate-and-render-json-and-md")
    # Recording a new source issue permanently blocks this confirmation, even after fragment correction.
    issue_prep = confirmed_prepare(root / "discovery", small)
    it = model_batches.next_task(issue_prep["attempt"])
    iv = fill_model_fragment(issue_prep["attempt"], it, agent_source(issue_prep["attempt"]), first=True)
    iv["new_issues"] = [{"description": "虚构结构化时新发现的源歧义"}]
    save(fragment_file, iv)
    model_batches.submit(issue_prep["attempt"], fragment_file)
    assert model_batches.status(issue_prep["attempt"])["state"] == "RETURN_TO_REVIEW"
    iv["new_issues"] = []
    save(fragment_file, iv)
    model_batches.submit(issue_prep["attempt"], fragment_file)
    assert model_batches.next_task(issue_prep["attempt"])["state"] == "RETURN_TO_REVIEW"
    rejects("discovered-source-issue-cannot-be-erased-to-reuse-old-confirmation", lambda: structure(issue_prep["attempt"], None, root / "blocked-discovery"), "MODEL_DISCOVERED_ISSUES")
    return results
