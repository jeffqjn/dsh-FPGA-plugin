"""Bounded source packets, resumable review checkpoints and conservative reuse."""
import copy
import json
from collections import Counter
from pathlib import Path

from . import contract
from .base import digest, load, now, require, save, text, verify_inputs

GROUPS = {"structure": ["STR-%03d" % i for i in range(1, 11)],
          "quality": ["REQ-%03d" % i for i in range(1, 9)],
          "consistency": ["CON-%03d" % i for i in range(1, 7)],
          "coverage": ["TST-%03d" % i for i in range(1, 7)]}
CONTEXT_VIEWS = {"issue_index": "uid", "source_catalog": "uid",
                 "local_summaries": "task_uid", "extraction_targets": "archive_uid"}


def fingerprint(value):
    return contract.fingerprint(value)


def filename(task_uid):
    import re
    require(isinstance(task_uid, str) and re.match(r"^(?:chunk|global|model):[a-z0-9_-]+$", task_uid), "BATCH_TASK_ID_INVALID")
    return task_uid.replace(":", "-") + ".json"


def source_manifest(archives, budget=4000, max_units=120):
    """Never discard source. Long elements/rows continue in explicit bounded units."""
    require(isinstance(budget, int) and 1000 <= budget <= 12000, "CHUNK_CHARS_MUST_BE_1000_TO_12000")
    units = []
    for slot, archive in enumerate(archives):
        sections = {s["uid"]: s for s in archive["sections"]}

        def section_path(section_uid):
            result, seen = [], set()
            while section_uid:
                require(section_uid not in seen, "SOURCE_SECTION_CYCLE")
                seen.add(section_uid)
                section = sections[section_uid]
                result.insert(0, [section["number"], section["title"]])
                section_uid = section["parent_uid"]
            return result

        table_number = 0
        for element in archive["elements"]:
            section = section_path(element["section_uid"])
            element_text_fingerprint = fingerprint(element["text"])
            pieces = []
            if element["kind"] == "table" and element["cells"]:
                table_number += 1
                rows = max(c["row"] + c["row_span"] for c in element["cells"])
                # Render anchors once. Span metadata remains explicit; no repeated table text.
                for row in range(rows):
                    cells = [c for c in element["cells"] if c["row"] == row]
                    rendered = "\n".join("col={0};row_span={1};col_span={2}: {3}".format(c["column"], c["row_span"], c["column_span"], c["text"]) for c in cells)
                    pieces.append((row, rendered or "[merged-cell continuation row]"))
            else:
                pieces = [(None, element["text"])]
            element_units = []
            for row, rendered in pieces:
                # Preserve every character, including long clauses/cells. Continuation is not a new obligation.
                segment_size = max(500, budget - 350)
                segments = [rendered[i:i + segment_size] for i in range(0, len(rendered), segment_size)] or [""]
                whole_piece = fingerprint(rendered) if len(segments) > 1 else None
                for part, content in enumerate(segments):
                    identity = {"slot": slot, "section": section, "kind": element["kind"], "part": element["part"],
                                "text": content, "limits": element["limitations"], "read_status": element["read_status"],
                                "continuation": [part, len(segments)], "whole_piece": whole_piece}
                    unit = {"identity": fingerprint(identity), "element_uid": element["uid"], "archive_slot": slot,
                            "section": section, "kind": element["kind"], "row": row, "table_number": table_number if row is not None else None,
                            "part": part, "parts": len(segments), "text": content, "read_status": element["read_status"],
                            "limitations": element["limitations"], "context_unit_refs": []}
                    element_units.append(unit)
            # Table context changes invalidate all its rows, including changes to merged cells/header meaning.
            table_context = fingerprint([(u["identity"], u["row"]) for u in element_units]) if element["kind"] == "table" else None
            for unit in element_units:
                unit["identity"] = fingerprint([unit["identity"], table_context])
                unit["element_group"] = fingerprint([slot, section, element["kind"], table_number if table_context else element_text_fingerprint])
            units.extend(element_units)
    counts = Counter(u["identity"] for u in units)
    occurrences = Counter()
    for unit in units:
        key = unit["identity"]
        occurrences[key] += 1
        unit["uid"] = "unit:" + key[:24] + ("-%d" % occurrences[key] if counts[key] > 1 else "")
        unit["reusable"] = counts[key] == 1
    element_refs = list(dict.fromkeys(u["element_uid"] for u in units))
    element_aliases = {"e%05d" % (i + 1): ref for i, ref in enumerate(element_refs)}
    for index, unit in enumerate(units):
        unit["alias"] = "u%05d" % (index + 1)
    groups = {}
    for unit in units:
        groups.setdefault(unit["element_group"], []).append(unit["uid"])
    positions = {ref: index for refs in groups.values() for index, ref in enumerate(refs)}
    for unit in units:
        related = groups[unit["element_group"]]
        if unit["kind"] == "table" or unit["parts"] > 1:
            position = positions[unit["uid"]]
            unit["context_unit_refs"] = list(dict.fromkeys(r for r in [related[0]] + related[max(0, position - 1):position + 2] if r != unit["uid"]))
    chunks, current, size = [], [], 0

    def flush():
        if current:
            refs = [u["uid"] for u in current]
            chunks.append({"uid": "chunk:" + fingerprint(refs)[:24], "unit_refs": refs,
                           "section": current[0]["section"], "archive_slot": current[0]["archive_slot"],
                           "chars": sum(len(u["text"]) for u in current), "reusable": all(u["reusable"] for u in current)})

    for unit in units:
        boundary = current and (unit["section"] != current[0]["section"] or unit["archive_slot"] != current[0]["archive_slot"] or
                                unit["kind"] == "heading" and size >= 300 or len(current) >= max_units or size + len(unit["text"]) + 30 * (len(current) + 1) > budget)
        if boundary:
            flush()
            current, size = [], 0
        current.append(unit)
        size += len(unit["text"])
    flush()
    return {"contract": "taskbook-chunks/1.0", "budget_chars": budget, "units": units, "chunks": chunks, "element_aliases": element_aliases}


def remap(value, mapping):
    if isinstance(value, str):
        return mapping.get(value, value)
    if isinstance(value, list):
        return [remap(v, mapping) for v in value]
    if isinstance(value, dict):
        return {k: remap(v, mapping) for k, v in value.items()}
    return value


def aliases(manifest, reverse=False):
    result = dict(manifest["element_aliases"])
    result.update({u["alias"]: u["uid"] for u in manifest["units"]})
    return {v: k for k, v in result.items()} if reverse else result


def translate_refs(value, mapping, key=None):
    # Never translate names, descriptions or quoted technical strings that resemble an alias.
    if isinstance(value, str):
        return mapping.get(value, value) if key and (key.endswith("_refs") or key in ("unit_uid", "target_ref")) else value
    if isinstance(value, list):
        return [translate_refs(v, mapping, key) for v in value]
    if isinstance(value, dict):
        return {k: translate_refs(v, mapping, k) for k, v in value.items()}
    return value


def initialize(attempt, info, budget=4000, previous=None):
    attempt = Path(attempt)
    manifest = source_manifest([load(attempt / p) for p in info["archives"]], budget)
    from .review_updates import compact_transcriptions
    compact_transcriptions(manifest, info)
    manifest["run_uid"] = info["run_uid"]
    manifest["prior_owners"] = {}
    manifest["prior_locations"] = {}
    work = attempt / "review-work"
    (work / "checkpoints").mkdir(parents=True)
    unit_map = {u["uid"]: u for u in manifest["units"]}
    short = aliases(manifest, reverse=True)
    old_manifest, old_chunks, old_units, previous_root = None, {}, {}, None
    if previous:
        previous_root = Path(previous).parent
        if (previous_root / "review-work/manifest.json").is_file():
            old_manifest = load(previous_root / "review-work/manifest.json")
            old_chunks = {c["uid"]: c for c in old_manifest["chunks"]}
            old_units = {u["uid"]: u for u in old_manifest["units"]}
            # Keep global issue ownership too; old global issues must not all move to quality.
            for task_uid, checkpoint in all_checkpoints(previous_root, old_manifest).items():
                for key in ("issues", "todos"):
                    for item in checkpoint["payload"][key]:
                        manifest["prior_owners"].setdefault(item["uid"], task_uid)
                        old_refs = set(item.get("evidence_refs", []))
                        old_chunk = old_chunks.get(task_uid)
                        manifest["prior_locations"][item["uid"]] = {"sections": [u["section"] for u in old_units.values() if u["element_uid"] in old_refs] or ([old_chunk["section"]] if old_chunk else []),
                            "identities": [u["identity"] for u in old_units.values() if u["element_uid"] in old_refs]}
    mapping = {}
    for unit in manifest["units"]:
        old = old_units.get(unit["uid"])
        if old and unit["reusable"] and old["reusable"]:
            old_element = old["element_uid"]
            mapped = mapping.get(old_element)
            if mapped is None or mapped == unit["element_uid"]:
                mapping[old_element] = unit["element_uid"]
            else:
                mapping[old_element] = "ambiguous-old-element"
    reused = []
    for chunk in manifest["chunks"]:
        chunk["packet_path"] = "review-work/chunks/" + filename(chunk["uid"]).replace(".json", ".txt")
        lines = ["# " + chunk["uid"], "Section: " + json.dumps(chunk["section"], ensure_ascii=False),
                 "Read continuation/table context with review-read; this packet is not a standalone requirement."]
        for ref in chunk["unit_refs"]:
            unit = unit_map[ref]
            label = "[{0}] {1} {2}".format(unit["alias"], short[unit["element_uid"]], unit["kind"][:1])
            if unit["row"] is not None:
                label += " row=" + str(unit["row"])
            if unit["parts"] > 1:
                label += " piece=%d/%d" % (unit["part"] + 1, unit["parts"])
            if unit["context_unit_refs"]:
                label += " ctx=" + ",".join(short[r] for r in unit["context_unit_refs"])
            lines += ["", label, unit["text"]]
            if unit["read_status"] != "complete" or unit["limitations"]:
                lines.append("read=" + unit["read_status"] + "; limits=" + json.dumps(unit["limitations"], ensure_ascii=False))
        text(attempt / chunk["packet_path"], "\n".join(lines) + "\n")
        old_checkpoint = previous_root / "review-work/checkpoints" / filename(chunk["uid"]) if previous_root else None
        if old_checkpoint and old_checkpoint.is_file() and chunk["uid"] in old_chunks:
            old = load(old_checkpoint)
            submitted = old["payload"]
            needed = set(submitted["scope_unit_refs"])
            issue_evidence = [r for item in submitted["issues"] + submitted["todos"] for key in ("evidence_refs", "closure_evidence_refs") for r in item.get(key, [])]
            same_policy = load(previous_root / "attempt.json")["policy_binding"] == info["policy_binding"]
            safe = same_policy and chunk["reusable"] and needed <= set(unit_map) and all(unit_map[r]["reusable"] for r in needed) and all(r in mapping and mapping[r] != "ambiguous-old-element" for r in issue_evidence)
            for issue in submitted["issues"]:
                manifest["prior_owners"][issue["uid"]] = chunk["uid"]
            for todo in submitted["todos"]:
                manifest["prior_owners"][todo["uid"]] = chunk["uid"]
            if safe and old.get("basis") == local_basis(old_manifest, old_chunks[chunk["uid"]], submitted["scope_unit_refs"]):
                payload = remap(submitted, mapping)
                payload["run_uid"] = info["run_uid"]
                reused.append((chunk, payload, old))
    # Preserve global ownership, otherwise recover local ownership from exact unchanged units or section paths.
    from .review_updates import route_previous
    route_previous(manifest)
    save(work / "manifest.json", manifest)
    for chunk, payload, old in reused:
        payload["basis_sha256"] = local_basis(manifest, chunk, payload["scope_unit_refs"])
        save(work / "checkpoints" / filename(chunk["uid"]), {"basis": payload["basis_sha256"], "payload": payload, "payload_sha256": fingerprint(payload), "saved_at": now(), "reused_from": old["saved_at"]})
    for path in [work / "manifest.json"] + list((work / "chunks").glob("*.txt")):
        info["input_bindings"].append({"path": path.relative_to(attempt).as_posix(), "sha256": digest(path)})
    from .review_updates import reuse_globals
    reused_globals = reuse_globals(attempt, info, manifest, previous_root, old_manifest, mapping)
    info["batching"] = {"manifest": "review-work/manifest.json"}
    save(attempt / "attempt.json", info)
    return {"chunks": len(manifest["chunks"]), "reused_chunks": len(reused), "reused_globals": reused_globals, "budget_chars": budget,
            "estimated_chunk_metadata_bytes": sum(len(json.dumps(c, ensure_ascii=False)) for c in manifest["chunks"]),
            "compact_submission": "taskbook-review-delta/1.0; mechanical unit lists are omitted"}


def workspace(attempt):
    from .review_stage import policy_binding
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    require(info.get("kind") == "taskbook-review" and info.get("batching"), "BATCH_REVIEW_ATTEMPT_REQUIRED")
    require(info["policy_binding"] == policy_binding(), "REVIEW_POLICY_CHANGED: prepare again")
    return attempt, info, load(attempt / info["batching"]["manifest"])


def local_basis(manifest, chunk, scope):
    units = {u["uid"]: u for u in manifest["units"]}
    return fingerprint({"chunk": chunk["uid"], "scope": [(r, units[r]["identity"]) for r in sorted(scope)]})


def checkpoints(attempt, manifest):
    valid = {}
    chunks = {c["uid"]: c for c in manifest["chunks"]}
    for task_uid, chunk in chunks.items():
        path = Path(attempt) / "review-work/checkpoints" / filename(task_uid)
        if path.is_file():
            record = load(path)
            payload = record["payload"]
            require(record.get("payload_sha256") == fingerprint(payload), "REVIEW_CHECKPOINT_CORRUPT")
            try:
                basis = local_basis(manifest, chunk, payload["scope_unit_refs"])
            except KeyError:
                continue
            if record["basis"] == basis and payload["basis_sha256"] == basis:
                valid[task_uid] = record
    return valid


def global_basis(manifest, local):
    return fingerprint({"manifest": manifest, "local": {k: v["payload"] for k, v in sorted(local.items())}})


def all_checkpoints(attempt, manifest):
    local = checkpoints(attempt, manifest)
    result = dict(local)
    if len(local) == len(manifest["chunks"]):
        basis = global_basis(manifest, local)
        for group in GROUPS:
            task_uid = "global:" + group
            path = Path(attempt) / "review-work/checkpoints" / filename(task_uid)
            if path.is_file():
                record = load(path)
                require(record.get("payload_sha256") == fingerprint(record["payload"]), "REVIEW_CHECKPOINT_CORRUPT")
                if record["basis"] == basis and record["payload"]["basis_sha256"] == basis:
                    result[task_uid] = record
    return result


def review_owner(manifest, item_uid):
    current_ids = {c["uid"] for c in manifest["chunks"]} | {"global:" + g for g in GROUPS}
    owner = manifest["prior_owners"].get(item_uid, "global:quality")
    return owner if owner in current_ids else "global:quality"


def issue_registry(attempt, manifest, payload=None):
    """Issue identity spans rounds; only current submissions establish current status."""
    registry = {}
    previous_path = Path(attempt) / "inputs/previous_state.json"
    if previous_path.is_file():
        for issue in load(previous_path)["record"]["issues"]:
            registry[issue["uid"]] = {"issue": issue, "current": False, "owner": review_owner(manifest, issue["uid"])}
    submitted = [(task_uid, row["payload"]) for task_uid, row in all_checkpoints(attempt, manifest).items()
                 if payload is None or task_uid != payload["task_uid"]]
    if payload is not None:
        submitted.append((payload["task_uid"], payload))
    for task_uid, record in submitted:
        for issue in record["issues"]:
            prior = registry.get(issue["uid"])
            if prior is not None:
                from .review_updates import reconcile
                reconcile(prior["issue"], issue, task_uid)
            registry[issue["uid"]] = {"issue": issue, "current": True, "owner": task_uid}
    return registry


def prior_items(attempt, manifest, task_uid):
    path = Path(attempt) / "inputs/previous_state.json"
    if not path.exists():
        return {"issues": [], "todos": []}
    previous = load(path)["record"]
    result = {}
    for key in ("issues", "todos"):
        result[key] = []
        for item in previous[key]:
            owner = review_owner(manifest, item["uid"])
            if owner == task_uid:
                copied = copy.deepcopy(item)
                # Old IDs are evidence history, not valid references in the new input.
                copied["previous_evidence_refs"] = copied.get("evidence_refs", [])
                copied["evidence_refs"] = []
                copied.pop("closure_evidence_refs", None)
                result[key].append(copied)
    return result


def status(attempt, pending_local=False):
    attempt, info, manifest = workspace(attempt)
    valid = all_checkpoints(attempt, manifest)
    tasks = [c["uid"] for c in manifest["chunks"]] + ["global:" + g for g in GROUPS]
    pending = [t for t in tasks if t not in valid]
    stale = [t for t in pending if (attempt / "review-work/checkpoints" / filename(t)).exists()]
    result = {"stale_tasks": stale, "chunks_total": len(manifest["chunks"]), "chunks_done": sum(c["uid"] in valid for c in manifest["chunks"]),
              "global_total": len(GROUPS), "global_done": sum("global:" + g in valid for g in GROUPS),
              "reused_chunks": sum(bool(v.get("reused_from")) for v in valid.values()), "next_task": pending[0] if pending else None,
              "complete": not pending}
    if pending_local:
        result["pending_local_tasks"] = [t for t in pending if t.startswith("chunk:")]
    return result


def global_context(attempt, info, manifest, valid, group, view=None):
    context = {} if view else {"group": group}
    if view in (None, "issue_index"):
        registry = issue_registry(attempt, manifest)
        context["issue_index"] = [
            {"uid": issue_uid, "description": entry["issue"]["description"], "status": entry["issue"]["status"],
             "owner_task": entry["owner"], "registered_in_current_round": entry["current"],
             "status_basis": "current_submission" if entry["current"] else "previous_round_pending_recheck"}
            for issue_uid, entry in registry.items()
        ]
    if view in (None, "source_catalog"):
        context["source_catalog"] = [{"uid": c["uid"], "section": c["section"], "packet": c["packet_path"]}
                                     for c in manifest["chunks"]]
    if view in (None, "local_summaries"):
        summaries = []
        for chunk in manifest["chunks"]:
            task_uid = chunk["uid"]
            payload = valid[task_uid]["payload"]
            entry = {"task_uid": task_uid, "summary": payload["summary"], "subjects": payload["subjects"]}
            if view:
                entry["issue_uids"] = [issue["uid"] for issue in payload["issues"]]
            else:
                entry["issues"] = payload["issues"]
            summaries.append(entry)
        context["local_summaries"] = summaries
    if group == "structure" and view in (None, "extraction_targets"):
        from .review_stage import extraction_targets
        context["extraction_targets"] = [{"archive_uid": a["uid"], "target_refs": extraction_targets(a)}
                                         for a in (load(attempt / p) for p in info["archives"])]
    return context


def next_task(attempt, task_uid=None, write=True):
    attempt, info, manifest = workspace(attempt)
    valid = all_checkpoints(attempt, manifest)
    tasks = [c["uid"] for c in manifest["chunks"]] + ["global:" + g for g in GROUPS]
    if task_uid is None:
        task_uid = next((t for t in tasks if t not in valid), None)
    if task_uid is None:
        return {"complete": True, "next": "review --attempt ... --output ..."}
    require(task_uid in tasks, "UNKNOWN_REVIEW_TASK")
    chunk = next((c for c in manifest["chunks"] if c["uid"] == task_uid), None)
    template = {"contract": "taskbook-review-fragment/1.0", "run_uid": info["run_uid"], "task_uid": task_uid,
                "summary": "", "issues": [], "todos": []}
    if chunk:
        template.update(basis_sha256=local_basis(manifest, chunk, chunk["unit_refs"]), scope_unit_refs=chunk["unit_refs"],
                        reviewed_unit_refs=chunk["unit_refs"], inspected_rule_ids=GROUPS["quality"] + GROUPS["coverage"], subjects=[])
        reading = chunk["packet_path"]
    else:
        require(all(c["uid"] in valid for c in manifest["chunks"]), "LOCAL_REVIEW_NOT_COMPLETE")
        group = task_uid.split(":")[1]
        template.update(basis_sha256=global_basis(manifest, {c["uid"]: valid[c["uid"]] for c in manifest["chunks"]}),
                        checks=[{"rule_id": r, "status": "unknown", "rationale": "", "evidence_refs": [], "issue_refs": []} for r in GROUPS[group]])
        if group == "structure":
            template["extraction_checks"] = load(attempt / "review.template.json")["extraction_checks"]
        if write:
            context = global_context(attempt, info, manifest, valid, group)
            context_path = "review-work/context/" + filename(task_uid)
            save(attempt / context_path, translate_refs(context, aliases(manifest, reverse=True)))
            reading = str(Path(context_path).with_suffix(".txt"))
            index = ["Global task: " + task_uid, "Use review-read --task " + task_uid + " --view <name> [--entry <uid>].",
                     "Read original evidence with review-read --unit or --subject."]
            index.extend("%s: %d" % (name, len(context[name])) for name in CONTEXT_VIEWS if name in context)
            text(attempt / reading, "\n".join(index) + "\n")
    template.update(prior_items(attempt, manifest, task_uid))
    checkpoint_path = attempt / "review-work/checkpoints" / filename(task_uid)
    if checkpoint_path.is_file() and task_uid not in valid:
        old_payload = load(checkpoint_path)["payload"]
        for key in ("issues", "todos"):
            existing_ids = {i["uid"] for i in template[key]}
            template[key] += [copy.deepcopy(i) for i in old_payload[key] if i["uid"] not in existing_ids]
    if task_uid in valid:
        template = valid[task_uid]["payload"]
    if not write:
        return {"template_data": template}
    target = attempt / "review-work/tasks" / filename(task_uid)
    save(target, translate_refs(template, aliases(manifest, reverse=True)))
    compact = {"contract": "taskbook-review-delta/1.0", "run_uid": template["run_uid"], "task_uid": task_uid,
               "basis_sha256": template["basis_sha256"], "reviewed": False,
               "changes": {k: template[k] for k in ("summary", "issues", "todos", "checks", "extraction_checks") if k in template}}
    compact_path = target.with_name(target.stem + ".delta.json")
    save(compact_path, translate_refs(compact, aliases(manifest, reverse=True)))
    return {"task_uid": task_uid, "delta_template": str(compact_path), "template": str(target), "reading": str(attempt / reading), "already_done": task_uid in valid,
            "note": "Fill a separate JSON and use the current template when resubmitting. For global context use review-read --task <id> --view <name> [--entry <uid>]. Verify original evidence with --unit or --subject."}


def read_units(attempt, unit_uid=None, subject=None, offset=0, limit=4000, task_uid=None, output=None, view=None, entry_uid=None):
    attempt, info, manifest = workspace(attempt)
    require(isinstance(offset, int) and offset >= 0 and 1 <= limit <= 12000, "REVIEW_READ_RANGE_INVALID")
    units = {u["uid"]: u for u in manifest["units"]}
    short = aliases(manifest, reverse=True)
    require(not view or task_uid, "REVIEW_CONTEXT_VIEW_REQUIRES_GLOBAL_TASK")
    require(not entry_uid or view, "REVIEW_CONTEXT_ENTRY_REQUIRES_VIEW")
    if task_uid:
        require(task_uid in ["global:" + g for g in GROUPS], "GLOBAL_CONTEXT_TASK_REQUIRED")
        group = task_uid.split(":")[1]
        require(view is None or (view in CONTEXT_VIEWS and (view != "extraction_targets" or group == "structure")),
                "REVIEW_CONTEXT_VIEW_INVALID_FOR_GROUP: " + str(view))
        valid = all_checkpoints(attempt, manifest)
        require(all(c["uid"] in valid for c in manifest["chunks"]), "LOCAL_REVIEW_NOT_COMPLETE")
        context = translate_refs(global_context(attempt, info, manifest, valid, group, view), short)
        if view:
            rows = context[view]
            if entry_uid:
                rows = [row for row in rows if row[CONTEXT_VIEWS[view]] == entry_uid]
                require(rows, "REVIEW_CONTEXT_ENTRY_NOT_FOUND: " + entry_uid)
            content = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in rows)
        else:
            content = json.dumps(context, ensure_ascii=False, indent=2) + "\n"
        selected = []
    elif unit_uid:
        unit_uid = aliases(manifest).get(unit_uid, unit_uid)
        require(unit_uid in units, "UNKNOWN_SOURCE_UNIT")
        selected = [units[unit_uid]]
    else:
        require(bool(subject), "REVIEW_READ_UNIT_OR_SUBJECT_REQUIRED")
        refs = set()
        for record in checkpoints(attempt, manifest).values():
            for entry in record["payload"]["subjects"]:
                if entry["key"] == subject:
                    refs.update(entry["unit_refs"])
        selected = [u for u in manifest["units"] if u["uid"] in refs]
    if not task_uid:
        content = "\n\n".join("[{0}] element={1};context={2}\n{3}".format(u["alias"], short[u["element_uid"]], ",".join(short[r] for r in u["context_unit_refs"]), u["text"]) for u in selected)
    page = content[offset:offset + limit]
    if output is None:
        target = attempt / "review-work/read.txt"
        text(target, page)
    else:
        target = Path(output).resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(page)
    result = {"path": str(target), "total_chars": len(content), "offset": offset, "next_offset": offset + limit if offset + limit < len(content) else None,
              "unit_refs": [u["alias"] for u in selected[:20]], "matched_units": len(selected)}
    if view:
        result.update(view=view, matched_entries=len(rows))
    return result


def submit(attempt, model_file):
    attempt, info, manifest = workspace(attempt)
    require(not (attempt / "inputs/agent_review.json").exists(), "REVIEW_ALREADY_PUBLISHED")
    payload = translate_refs(contract.read_json(Path(model_file), encoding="utf-8-sig"), aliases(manifest))
    from .review_updates import expand, reconcile, evidence_preview
    if payload.get("contract") == "taskbook-review-delta/1.0":
        payload = expand(payload, next_task(attempt, payload.get("task_uid"), write=False)["template_data"])
    before = all_checkpoints(attempt, manifest)
    require(payload.get("contract") == "taskbook-review-fragment/1.0" and payload.get("run_uid") == info["run_uid"], "REVIEW_FRAGMENT_BINDING_INVALID")
    task_uid = payload["task_uid"]
    template = next_task(attempt, task_uid, write=False)["template_data"]
    require(set(payload) == set(template), "REVIEW_FRAGMENT_FIELDS_INVALID: task=" + task_uid + "; missing=" + str(sorted(set(template)-set(payload))) + "; unexpected=" + str(sorted(set(payload)-set(template))))
    require(payload["basis_sha256"] == template["basis_sha256"], "REVIEW_FRAGMENT_STALE")
    from .review_stage import nonempty
    require(nonempty(payload["summary"]) and len(payload["summary"]) <= 2000, "REVIEW_FRAGMENT_SUMMARY_REQUIRED_OR_TOO_LONG")
    units = {u["uid"]: u for u in manifest["units"]}
    elements = {u["element_uid"] for u in manifest["units"]}
    if task_uid.startswith("chunk:"):
        chunk = next(c for c in manifest["chunks"] if c["uid"] == task_uid)
        scope = payload["scope_unit_refs"]
        require(set(payload["reviewed_unit_refs"]) == set(chunk["unit_refs"]) and len(payload["reviewed_unit_refs"]) == len(chunk["unit_refs"]), "REVIEW_FRAGMENT_COVERAGE_INCOMPLETE")
        require(set(chunk["unit_refs"]) <= set(scope) <= set(units), "REVIEW_FRAGMENT_SCOPE_INVALID")
        require(set(payload["inspected_rule_ids"]) == set(GROUPS["quality"] + GROUPS["coverage"]), "REVIEW_LOCAL_RULES_INCOMPLETE")
        for entry in payload["subjects"]:
            require(nonempty(entry["key"]) and entry["unit_refs"] and set(entry["unit_refs"]) <= set(scope), "REVIEW_SUBJECT_INVALID")
        basis = local_basis(manifest, chunk, scope)
        # The supplied basis binds the original packet; additional read dependencies are recorded here.
        payload["basis_sha256"] = basis
    else:
        basis = template["basis_sha256"]
        group = task_uid.split(":")[1]
        require({c["rule_id"] for c in payload["checks"]} == set(GROUPS[group]) and len(payload["checks"]) == len(GROUPS[group]), "GLOBAL_RULES_INCOMPLETE")
        for check in payload["checks"]:
            require(check["status"] in ("pass", "fail", "unknown", "not_applicable") and nonempty(check["rationale"]), "GLOBAL_RULE_JUDGMENT_REQUIRED")
            require(check["evidence_refs"] and set(check["evidence_refs"]) <= elements, "GLOBAL_RULE_EVIDENCE_INVALID")
        if group == "structure":
            require("extraction_checks" in payload, "GLOBAL_EXTRACTION_CHECKS_REQUIRED")
    # Validate issues at save time, rather than discovering malformed rows after a long review.
    for key in ("issues", "todos"):
        fields = {"uid", "description", "status", "evidence_refs"}
        fields.update({"issue_uid"} if key == "todos" else {"severity", "blocking", "impact", "recommendation"})
        require(isinstance(payload[key], list), "FRAGMENT_COLLECTION_INVALID: task=" + task_uid + "; collection=" + key)
        seen = set()
        for index, item in enumerate(payload[key]):
            location = "task=" + task_uid + "; path=%s[%d]" % (key, index)
            require(isinstance(item, dict), "FRAGMENT_ITEM_INVALID: " + location + "; expected object")
            missing = sorted(fields - item.keys())
            require(not missing, "FRAGMENT_ITEM_FIELDS_MISSING: " + location + "; item=" + str(item.get("uid")) + "; missing=" + ",".join(missing))
            require(nonempty(item["uid"]) and item["uid"] not in seen, "FRAGMENT_ITEM_IDS_INVALID: " + location + "; item=" + str(item["uid"]))
            seen.add(item["uid"])
            require(nonempty(item["description"]) and item["status"] in ("open", "closed", "deferred") and item["evidence_refs"] and set(item["evidence_refs"]) <= elements, "FRAGMENT_ITEM_INVALID: task=" + task_uid + "; item=" + str(item.get("uid")) + "; fields=description/status/evidence_refs; evidence_refs=" + str(item.get("evidence_refs")))
            if item["status"] == "closed":
                require(nonempty(item.get("closure_reason")) and item.get("closure_evidence_refs") and set(item["closure_evidence_refs"]) <= elements, "FRAGMENT_CLOSURE_EVIDENCE_REQUIRED: task=" + task_uid + "; item=" + item["uid"] + "; fields=closure_reason/closure_evidence_refs")
            if key == "issues":
                from .review_stage import ISSUE_CATEGORIES
                require(item.get("category", "other") in ISSUE_CATEGORIES, "REVIEW_ISSUE_CATEGORY_INVALID")
                require(item["severity"] in ("error", "warning", "info") and isinstance(item["blocking"], bool) and nonempty(item["impact"]) and nonempty(item["recommendation"]), "FRAGMENT_ISSUE_DETAILS_INVALID")
    if task_uid.startswith("global:"):
        registry = issue_registry(attempt, manifest, payload)
        for check in payload["checks"]:
            require(isinstance(check["issue_refs"], list) and all(isinstance(r, str) for r in check["issue_refs"]),
                    "GLOBAL_RULE_ISSUE_REFERENCE_INVALID: rule=" + check["rule_id"] + "; issue_refs must be a list of issue UIDs")
            missing = sorted(set(check["issue_refs"]) - set(registry))
            require(not missing, "GLOBAL_RULE_ISSUE_REFERENCE_INVALID: rule=" + check["rule_id"] +
                    "; unknown_issue_uids=" + json.dumps(missing, ensure_ascii=False) + "; see issue_index in review-read --task " + task_uid)
            if check["status"] in ("fail", "unknown"):
                # A later owner may still need to reopen/close a historical issue. The final
                # assembled record rechecks against current status; history never grants PASS.
                require(any(registry[r]["issue"]["status"] != "closed" or not registry[r]["current"] for r in check["issue_refs"]),
                        "GLOBAL_FAILED_RULE_REQUIRES_OPEN_ISSUE: " + check["rule_id"])
    required = prior_items(attempt, manifest, task_uid)
    existing_path = attempt / "review-work/checkpoints" / filename(task_uid)
    if existing_path.is_file():
        previous_submission = load(existing_path)["payload"]
        for key in ("issues", "todos"):
            required[key] += previous_submission[key]
    for key in ("issues", "todos"):
        current = {i["uid"]: i for i in payload[key]}
        for old in required[key]:
            require(old["uid"] in current, "PREVIOUS_FRAGMENT_ITEM_DROPPED_OR_CHANGED: task=" + task_uid + "; item=" + old["uid"])
            reconcile(old, current[old["uid"]], task_uid)
    previews = evidence_preview(payload, manifest)
    path = attempt / "review-work/checkpoints" / filename(task_uid)
    if path.exists():
        prior = load(path)
        if prior["payload"] == payload:
            return {"saved": True, "task_uid": task_uid, "unchanged": True, "invalidates": [], "evidence_preview": previews}
        save(attempt / "review-work/history" / (filename(task_uid) + "." + fingerprint(prior)[:16]), prior)
    save(path, {"basis": basis, "payload": payload, "payload_sha256": fingerprint(payload), "saved_at": now()})
    after = all_checkpoints(attempt, manifest)
    return {"saved": True, "task_uid": task_uid, "invalidates": sorted(t for t in before if t.startswith("global:") and t not in after),
            "evidence_preview": previews, "progress": status(attempt)}


def assemble(attempt):
    attempt, info, manifest = workspace(attempt)
    saved = all_checkpoints(attempt, manifest)
    tasks = [c["uid"] for c in manifest["chunks"]] + ["global:" + g for g in GROUPS]
    require(all(t in saved for t in tasks), "REVIEW_BATCHES_INCOMPLETE_OR_STALE: missing_or_stale_tasks=" + str([t for t in tasks if t not in saved]))
    record = load(attempt / "review.template.json")
    record["summary"] = "分块审查和跨章节核对已完成；局部结论按源版本核验后复用。"
    record["reviewed_element_refs"] = list(dict.fromkeys(u["element_uid"] for u in manifest["units"]))
    record["checks"], record["issues"], record["todos"] = [], [], []
    for task in tasks:
        payload = saved[task]["payload"]
        for key in ("issues", "todos"):
            existing = {i["uid"]: i for i in record[key]}
            for item in payload[key]:
                require(item["uid"] not in existing or existing[item["uid"]] == item, "CONFLICTING_REVIEW_FRAGMENT_ITEMS")
                if item["uid"] not in existing:
                    record[key].append(item)
                    existing[item["uid"]] = item
        if task.startswith("global:"):
            record["checks"].extend(payload["checks"])
            if task == "global:structure":
                record["extraction_checks"] = payload["extraction_checks"]
    from .review_stage import check_record
    check_record(record, info, attempt)
    target = attempt / "review-work/assembled-review.json"
    save(target, record)
    return target
