"""FEIP design reference validator; Python 3.8+, standard library only.

Implements the closed schema subset shipped with FEIP, NOT arbitrary JSON Schema.
No semantic NLP, unit-conversion proof, execution engine, or approval authority.
"""
import argparse
import ast
import copy
import hashlib
import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
KEYWORDS = {"$schema", "$id", "$defs", "$ref", "title", "description", "type", "required", "properties",
            "additionalProperties", "items", "minItems", "uniqueItems", "minLength", "minimum", "maximum", "pattern", "enum", "const", "anyOf"}

def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result

def reject_constant(text):
    raise ValueError("non-finite JSON value: " + text)

def read_json(path, encoding="utf-8"):
    return json.loads(path.read_text(encoding=encoding), object_pairs_hook=object_pairs, parse_constant=reject_constant)

def sha_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()

def schema_nodes(schema):
    yield schema
    for key in ("properties", "$defs"):
        for value in schema.get(key, {}).values():
            yield from schema_nodes(value)
    for value in schema.get("anyOf", []):
        yield from schema_nodes(value)
    for key in ("items", "additionalProperties"):
        if isinstance(schema.get(key), dict):
            yield from schema_nodes(schema[key])

def audit_schema(schema):
    for node in schema_nodes(schema):
        unsupported = set(node) - KEYWORDS
        if unsupported:
            raise ValueError("unsupported schema keywords: " + ", ".join(sorted(unsupported)))
        if "$ref" in node:
            resolve_ref(schema, node["$ref"])

def resolve_ref(root, pointer):
    if not pointer.startswith("#/"):
        raise ValueError("only local schema refs supported: " + pointer)
    result = root
    for part in pointer[2:].split("/"):
        result = result[part.replace("~1", "/").replace("~0", "~")]
    return result

def is_type(value, kind):
    return {"object": lambda: isinstance(value, dict), "array": lambda: isinstance(value, list),
            "string": lambda: isinstance(value, str), "boolean": lambda: isinstance(value, bool),
            "null": lambda: value is None, "integer": lambda: isinstance(value, int) and not isinstance(value, bool),
            "number": lambda: isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)}[kind]()

def validate_schema(value, schema, root=None, path="$"):
    root = schema if root is None else root
    if "$ref" in schema:
        return validate_schema(value, resolve_ref(root, schema["$ref"]), root, path)
    errors = []
    if "anyOf" in schema:
        branches = [validate_schema(value, item, root, path) for item in schema["anyOf"]]
        if all(branches):
            errors.append(path + ": no anyOf branch matched; " + "; ".join(min(branches, key=len)[:3]))
        return errors
    kinds = schema.get("type")
    if kinds is not None and not any(is_type(value, k) for k in (kinds if isinstance(kinds, list) else [kinds])):
        return [path + ": invalid type, expected " + str(kinds)]
    if "const" in schema and (type(value) is not type(schema["const"]) or value != schema["const"]):
        errors.append(path + ": const mismatch")
    if "enum" in schema and not any(type(value) is type(v) and value == v for v in schema["enum"]):
        errors.append(path + ": invalid enum")
    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value:
                errors.append(path + ": missing " + key)
        props = schema.get("properties", {})
        for key, item in value.items():
            if key in props:
                errors.extend(validate_schema(item, props[key], root, path + "/" + key))
            elif schema.get("additionalProperties") is False:
                errors.append(path + ": unexpected property " + key)
            elif isinstance(schema.get("additionalProperties"), dict):
                errors.extend(validate_schema(item, schema["additionalProperties"], root, path + "/" + key))
    elif isinstance(value, list):
        if schema.get("uniqueItems") and len({json.dumps(v, sort_keys=True, ensure_ascii=False) for v in value}) != len(value):
            errors.append(path + ": duplicate array items")
        if len(value) < schema.get("minItems", 0):
            errors.append(path + ": too few items")
        if "items" in schema:
            for index, item in enumerate(value):
                errors.extend(validate_schema(item, schema["items"], root, path + "/" + str(index)))
    elif isinstance(value, str):
        if len(value) < schema.get("minLength", 0):
            errors.append(path + ": too short")
        if "pattern" in schema and re.search(schema["pattern"], value) is None:
            errors.append(path + ": pattern mismatch")
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        for key, invalid in (("minimum", lambda x: value < x), ("maximum", lambda x: value > x)):
            if key in schema and invalid(schema[key]):
                errors.append(path + ": " + key + " violated")
    return errors

def walk(value, path="$"):
    if isinstance(value, dict):
        yield path, value
        for key, item in value.items():
            # Opaque audit snapshots and delta payloads have separate identity scopes.
            if key not in ("content", "before", "after", "payload"):
                yield from walk(item, path + "/" + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk(item, path + "/" + str(index))

def semantic_checks(model, artifact_uids=()):
    errors = []
    registry = {uid: {} for uid in artifact_uids}
    registry[model["protocol"]["run_uid"]] = model["protocol"]
    registry[model["source_baseline"]["baseline_uid"]] = model["source_baseline"]
    registry.setdefault(model["source_baseline"]["upstream_run_uid"], {})
    registry[model["meta"]["project_uid"]] = model["meta"]
    if model["consistency"]["release_binding"]:
        registry[model["consistency"]["release_binding"]["candidate_uid"]] = {}
    for path, node in walk(model):
        if "uid" in node and set(node) != {"kind", "uid", "revision_uid"}:
            uid = node["uid"]
            if uid in registry:
                errors.append(path + ": duplicate UID " + uid)
            registry[uid] = node
    # Explicit references are resolvable, including all chapter/verification links.
    for path, node in walk(model):
        for key, value in node.items():
            if key.endswith("_refs") and isinstance(value, list):
                if len([x for x in value if isinstance(x, str)]) != len(set(x for x in value if isinstance(x, str))):
                    errors.append(path + "/" + key + ": duplicate references")
                for uid in value:
                    if isinstance(uid, str) and uid not in registry and key != "parent_package_refs":
                        errors.append(path + "/" + key + ": unknown reference " + uid)
                expected_prefix = {
                    "requirement_refs": "req", "primary_requirement_refs": "req", "cross_requirement_refs": "req",
                    "source_atomic_refs": "atom", "source_parent_refs": "parent", "constraint_refs": "constraint",
                    "spec_item_refs": "item", "decision_refs": "decision", "waiver_refs": "decision",
                    "issue_refs": "issue", "evidence_refs": "evidence", "basis_refs": "evidence", "current_refs": "evidence",
                    "user_evidence_refs": "evidence", "element_refs": "element", "material_element_refs": "element",
                    "signal_refs": "signal", "interface_refs": "interface", "protocol_refs": "protocol",
                    "format_refs": "format", "mode_refs": "mode", "behavior_refs": "behavior", "clock_refs": "clock",
                    "criterion_refs": "criterion", "acceptance_criterion_refs": "criterion", "exit_criterion_refs": "criterion",
                    "obligation_refs": "obligation", "case_refs": "case", "dependency_case_refs": "case",
                    "environment_refs": "environment", "instrument_refs": "instrument", "measurement_refs": "measurement",
                    "test_point_refs": "testpoint", "artifact_refs": "artifact", "evidence_artifact_refs": "artifact",
                    "dut_artifact_refs": "artifact", "fixture_artifact_refs": "artifact", "dataset_artifact_refs": "artifact",
                    "reference_model_artifact_refs": "artifact", "implementation_artifact_refs": "artifact",
                    "gap_refs": "gap", "notice_refs": "notice", "deliverable_refs": "deliverable"}.get(key)
                if expected_prefix and any(isinstance(uid, str) and not uid.startswith(expected_prefix + ":") for uid in value):
                    errors.append(path + "/" + key + ": wrong reference namespace; expected " + expected_prefix)
            if key.endswith("_uid") and value is not None and key not in ("uid",):
                if value not in registry:
                    errors.append(path + "/" + key + ": unknown reference " + value)
        if set(node) == {"kind", "uid", "revision_uid"}:
            if node["uid"] not in registry:
                errors.append(path + ": unknown typed reference " + node["uid"])
            aliases = {"requirement": "req", "revision": "rev", "artifact": "artifact", "spec_item": "item"}
            if node["uid"].split(":")[0] != aliases.get(node["kind"], node["kind"]):
                errors.append(path + ": reference kind/UID mismatch")
            if node["revision_uid"] is not None:
                owner = registry.get(node["uid"], {})
                if node["kind"] != "requirement" or node["revision_uid"] not in [r["uid"] for r in owner.get("revisions", [])]:
                    errors.append(path + ": revision not owned by typed requirement reference")
        if {"status", "value", "reason", "evidence_refs"} == set(node):
            if node["status"] != "present" and node["value"] is not None:
                errors.append(path + ": non-present Fact must have null value")
            if node["status"] == "present" and node["value"] is None:
                errors.append(path + ": present Fact must have a value")
            if node["status"] != "present" and not node["reason"]:
                errors.append(path + ": non-present Fact requires reason")
        if "header" in node and node["header"]["status"] in ("not_applicable", "out_of_scope"):
            if not node["header"]["reason"] or not node["header"]["evidence_refs"]:
                errors.append(path + ": excluded entity needs reason/evidence")
        if "decided_at" in node or "created_at" in node:
            for key in ("decided_at", "created_at"):
                if key in node:
                    try:
                        parsed = datetime.fromisoformat(node[key].replace("Z", "+00:00"))
                        if parsed.utcoffset() is None:
                            raise ValueError("timezone missing")
                    except ValueError:
                        errors.append(path + ": invalid timestamp " + key)
    if model["protocol"]["baseline_uid"] != model["source_baseline"]["baseline_uid"]:
        errors.append("protocol baseline differs from source_baseline")
    decisions = {x["uid"]: x for x in model["consistency"]["decisions"]}
    active = {uid: x for uid, x in decisions.items() if x["status"] == "active"}
    for uid, dec in decisions.items():
        if dec["baseline_uid"] != model["protocol"]["baseline_uid"]:
            errors.append(uid + ": decision belongs to different baseline")
        if dec["kind"] == "approve_change":
            op = dec["operation"]
            if op is None or (op == "add" and dec["before"] is not None) or (op == "delete" and dec["after"] is not None):
                errors.append(uid + ": malformed change operation")
            if op in ("add", "modify") and dec["after"] is None:
                errors.append(uid + ": change after snapshot required")
            if op in ("modify", "delete") and dec["before"] is None:
                errors.append(uid + ": change before snapshot required")
            if dec["target_fingerprint"] != fingerprint(dec["after"]):
                errors.append(uid + ": change fingerprint differs from approved after snapshot")
        elif dec["operation"] is not None:
            errors.append(uid + ": non-change decision must have operation=null")
        if not dec["user_quote"].strip() or not dec["actor"].strip():
            errors.append(uid + ": decision lacks user evidence/actor")
        for evidence_uid in dec["user_evidence_refs"]:
            if evidence_uid in registry and registry[evidence_uid].get("origin_kind") != "user_supplied":
                errors.append(uid + ": approval evidence must be user_supplied")
    atoms = {x["uid"]: x for x in model["source_baseline"]["atomic_requirements"]}
    for label, records in (("source atom", model["source_baseline"]["atomic_requirements"]), ("source parent", model["source_baseline"]["parents"])):
        original_ids = [x["source_id"] for x in records]
        if len(original_ids) != len(set(original_ids)):
            errors.append(label + ": duplicate original source ID")
    retained = set()
    expected_effective = []
    display_ids = []
    for req in model["requirements"]:
        uid = req["uid"]
        retained.update(req["source_atomic_refs"])
        if req["normalized_id"] is not None:
            display_ids.append(req["normalized_id"])
            if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*-(FREQ|IREQ|PREQ|SREQ|RREQ|OREQ)-[1-9][0-9]*(?:-K?N?M?R?)?", req["normalized_id"]) is None or req["normalized_id"].endswith("-"):
                errors.append(uid + ": invalid normalized_id")
        versions = {r["uid"]: r for r in req["revisions"]}
        for rev in req["revisions"]:
            if rev["basis"] == "source" and len(req["source_atomic_refs"]) == 1:
                atom = atoms.get(req["source_atomic_refs"][0])
                if atom and rev["semantic"] != atom["semantic"]:
                    errors.append(uid + ": source revision changed B0 semantics")
            if rev["basis"] == "approved_change":
                applicable = [active[d] for d in rev["decision_refs"] if d in active and active[d]["kind"] == "approve_change"]
                if not applicable or not any(d["after"] == rev["semantic"] and any(o["uid"] == uid for o in d["object_refs"]) for d in applicable):
                    errors.append(uid + ": approved revision missing matching active change")
            safety = rev["semantic"]["safety_critical"]
            if (safety is True) != ("K" in rev["semantic"]["attributes"]):
                errors.append(uid + ": safety-critical semantic/K attributes mismatch")
        if req["lifecycle"] == "active":
            if req["effective_revision_uid"] not in versions:
                errors.append(uid + ": effective revision not owned by requirement")
            expected_effective.append({"requirement_uid": uid, "revision_uid": req["effective_revision_uid"],
                                       "alignment": req["effective_alignment"], "waiver_refs": req["waiver_refs"]})
        else:
            if req["effective_revision_uid"] is not None:
                errors.append(uid + ": deleted requirement still has effective revision")
            if not any(d in active and active[d]["kind"] == "approve_change" and active[d]["operation"] == "delete" for d in req["decision_refs"]):
                errors.append(uid + ": deletion lacks approval")
    if set(atoms) - retained:
        errors.append("requirement retention lost source atoms: " + str(sorted(set(atoms) - retained)))
    if len(set(display_ids)) != len(display_ids):
        errors.append("normalized_id must be globally unique")
    ordered = lambda values: sorted(values, key=lambda x: x["requirement_uid"])
    if ordered(expected_effective) != ordered(model["effective_requirements"]):
        errors.append("effective_requirements differs from ledger")
    effective_pairs = {(r["requirement_uid"], r["revision_uid"]) for r in expected_effective}
    for view_name, view in model["views"].items():
        pairs = {(r["requirement_uid"], r["revision_uid"]) for r in view["requirement_refs"]}
        if not pairs.issubset(effective_pairs):
            errors.append(view_name + ": consumer view uses non-effective revision")
        if view_name == "architecture" and pairs != effective_pairs:
            errors.append("architecture view omits effective requirement (including unmapped obligations)")
        if view["readiness"] == "ready" and view["gap_refs"]:
            errors.append(view_name + ": ready view has unresolved gaps")
        if view["readiness"] == "conditional" and (not view["allowed_refs"] or not view["excluded_refs"] or not view["decision_refs"]):
            errors.append(view_name + ": conditional scope requires allowed/excluded refs and decision")
    issues = {x["uid"]: x for x in model["consistency"]["issues"]}
    for uid, issue in issues.items():
        ds = [active[d] for d in issue["decision_refs"] if d in active]
        if issue["status"] == "ignored" and (not issue["waivable"] or not any(d["kind"] == "waive_issue" and uid in d["issue_refs"] for d in ds)):
            errors.append(uid + ": ignored issue lacks valid scoped waiver")
        if issue["status"] == "confirmed" and not any(d["kind"] in ("approve_change", "confirm_mapping", "accept_notice") and uid in d["issue_refs"] for d in ds):
            errors.append(uid + ": confirmed issue lacks valid decision")
    gates = model["consistency"]["gates"]
    open_issues = [x for x in issues.values() if x["status"] == "open"]
    blockers = sorted(x["uid"] for x in open_issues if x["blocking"])
    if sorted(gates["blocking_issue_refs"]) != blockers:
        errors.append("gate blocking_issue_refs mismatch")
    local = "FAIL" if any(x["blocking"] or x["severity"] == "error" for x in open_issues) else "NEEDS_CLARIFICATION" if open_issues else "PASS"
    if gates["local"] is not None and gates["local"] != local:
        errors.append("local gate mismatch")
    overall = gates["local"] if gates["admission"] == "READY" else "FAIL"
    if gates["overall"] != overall:
        errors.append("overall gate mismatch")
    if gates["upstream"] != model["source_baseline"]["status"]:
        errors.append("upstream gate differs from source baseline")
    exceptions = any(d["kind"] in ("approve_change", "waive_issue") for d in active.values())
    if gates["has_exceptions"] != exceptions:
        errors.append("has_exceptions differs from active change/waiver decisions")
    if model["protocol"]["profile"] == "reqspec-reviewed":
        if gates["upstream"] != "PASS" or gates["overall"] != "PASS" or open_issues:
            errors.append("reqspec-reviewed profile requires closed PASS review")
        if any(x["required"] and x["status"] != "closed" for x in model["consistency"]["todos"]):
            errors.append("reqspec-reviewed has open required todo")
        binding = model["consistency"]["release_binding"]
        if binding is None or binding["release_confirmation_decision_uid"] not in active or active[binding["release_confirmation_decision_uid"]]["kind"] != "approve_release":
            errors.append("reqspec-reviewed lacks final release approval")
        elif active[binding["release_confirmation_decision_uid"]]["target_fingerprint"] != binding["candidate_manifest_sha256"]:
            errors.append("release approval fingerprint differs from candidate manifest")
    elements = {e["uid"] for a in model["document_archive"] for e in a["elements"]}
    inv = [x["element_uid"] for x in model["completeness"]["content_inventory"]]
    if set(inv) != elements or len(inv) != len(set(inv)):
        errors.append("content_inventory must account for each archived element exactly once")
    for node in model["completeness"]["content_inventory"]:
        if node["disposition"] == "modeled" and not node["object_refs"]:
            errors.append(node["element_uid"] + ": modeled content has no engineering object")
    for metric in model["traceability"]["metrics"]:
        expected = None if metric["total"] == 0 else metric["covered"] / metric["total"]
        if metric["covered"] > metric["total"] or metric["rate"] != expected:
            errors.append(metric["name"] + ": coverage arithmetic mismatch")
        if metric["name"] == "b1_document_realization":
            count = sum(x["alignment"] == "complete" for x in expected_effective)
            if (metric["covered"], metric["total"]) != (count, len(expected_effective)):
                errors.append("B1 coverage differs from ledger alignments")
    obligations = {x["uid"]: x for x in model["verification"]["obligations"]}
    cases = {x["uid"]: x for x in model["verification"]["test_cases"]}
    runs = {x["uid"]: x for x in model["verification"]["executions"]}
    for vo in obligations.values():
        if (vo["requirement_uid"], vo["revision_uid"]) not in effective_pairs:
            # Historical evidence belongs in prior immutable packages, not current planning.
            errors.append(vo["uid"] + ": obligation targets non-effective requirement revision")
        if vo["testability"] == "not_testable" and (not vo["limitation"] or not vo["alternative_methods"] or not vo["applicable_versions"]):
            errors.append(vo["uid"] + ": not_testable lacks limitation/alternative/version")
    for case in cases.values():
        if (case["kind"] == "simulation") != (case["simulation"] is not None):
            errors.append(case["uid"] + ": simulation payload mismatch")
        if (case["kind"] == "confirmation") != (case["confirmation"] is not None):
            errors.append(case["uid"] + ": confirmation payload mismatch")
    for run in runs.values():
        case = cases.get(run["case_uid"])
        if case and run["case_revision"] != case["revision"]:
            errors.append(run["uid"] + ": execution case revision mismatch")
        if case and run["requirement_refs"] != case["requirement_refs"]:
            errors.append(run["uid"] + ": execution requirement revision mismatch")
        if run["result"] == "pass":
            results = {r["criterion_uid"]: r for r in run["criterion_results"]}
            if not case or set(results) != set(case["criterion_refs"]) or any(r["result"] != "pass" or not r["evidence_artifact_refs"] for r in results.values()):
                errors.append(run["uid"] + ": pass requires all case criteria with evidence")
            if not run["started_at"] or not run["finished_at"] or not run["dut_artifact_refs"] or not run["evidence_artifact_refs"]:
                errors.append(run["uid"] + ": pass execution lacks build/time/evidence")
    for claim in model["verification"]["coverage_claims"]:
        vo, case = obligations.get(claim["obligation_uid"]), cases.get(claim["case_uid"])
        if not vo or not case:
            continue  # Reference error already emitted.
        if case["status"] != "ready":
            errors.append(claim["uid"] + ": draft/retired case cannot support a coverage claim")
        if claim["obligation_uid"] not in case["obligation_refs"] or claim["criterion_uid"] not in case["criterion_refs"] or claim["criterion_uid"] not in vo["criterion_refs"]:
            errors.append(claim["uid"] + ": claim not supported by obligation/case criteria")
        if (claim["requirement_uid"], claim["revision_uid"]) != (vo["requirement_uid"], vo["revision_uid"]) or claim["method"] != vo["method"] or claim["scenario_type"] not in vo["scenario_types"]:
            errors.append(claim["uid"] + ": claim method/scenario/requirement mismatch")
        if claim["state"] != "planned":
            run = runs.get(claim["execution_uid"])
            if not run or run["case_uid"] != case["uid"]:
                errors.append(claim["uid"] + ": executed coverage lacks matching run")
            elif claim["state"] == "passed" and not any(r["criterion_uid"] == claim["criterion_uid"] and r["result"] == "pass" and r["evidence_artifact_refs"] for r in run["criterion_results"]):
                errors.append(claim["uid"] + ": passed claim lacks criterion evidence")
    if any(x["critical"] for x in model["extensions"]):
        errors.append("reference validator has no registered critical extension handlers")
    return errors

def safe_artifact(root, relative):
    if "\\" in relative or ":" in relative or relative.startswith("/") or any(x in ("..", ".", "") for x in relative.split("/")):
        raise ValueError("unsafe artifact path: " + relative)
    candidate = (root / PurePosixPath(relative)).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError:
        raise ValueError("artifact escapes package root: " + relative)
    return candidate

def validate_package(directory):
    schema = read_json(ROOT / "schemas/engineering.schema.json")
    package_schema = read_json(ROOT / "schemas/package.schema.json")
    audit_schema(schema)
    audit_schema(package_schema)
    manifest = read_json(directory / "package.json")
    errors = validate_schema(manifest, package_schema)
    if errors:
        return errors
    paths, artifact_map = set(), {}
    for artifact in manifest["artifacts"]:
        if artifact["uid"] in artifact_map or artifact["path"] in paths:
            errors.append("duplicate artifact UID/path")
        artifact_map[artifact["uid"]] = artifact
        paths.add(artifact["path"])
        path = safe_artifact(directory, artifact["path"])
        if not path.is_file():
            if artifact["required"]:
                errors.append("missing artifact " + artifact["path"])
        elif sha_file(path) != artifact["sha256"] or path.stat().st_size != artifact["size_bytes"]:
            errors.append("artifact digest/size mismatch: " + artifact["path"])
    model_artifact = artifact_map.get(manifest["model_artifact_uid"])
    if not model_artifact:
        return errors + ["model artifact not in manifest"]
    model = read_json(safe_artifact(directory, model_artifact["path"]))
    shape = validate_schema(model, schema)
    if shape:
        return errors + shape
    for key in ("profile", "run_uid", "synthetic"):
        if manifest[key] != model["protocol"][key]:
            errors.append("manifest/model " + key + " mismatch")
    for binding in manifest["subject_binding"]:
        artifact = artifact_map.get(binding["artifact_uid"])
        if not artifact or artifact["sha256"] != binding["sha256"]:
            errors.append("subject binding digest mismatch")
    for uid in manifest["schema_artifact_refs"]:
        if uid not in artifact_map:
            errors.append("unknown schema artifact " + uid)
    errors.extend(semantic_checks(model, artifact_map))
    for snapshot in model["source_baseline"]["raw_snapshots"]:
        artifact = artifact_map.get(snapshot["artifact_uid"])
        if artifact and read_json(safe_artifact(directory, artifact["path"])) != snapshot["content"]:
            errors.append("raw snapshot differs from source file: " + snapshot["role"])
        if snapshot["schema_version"] == "1.0":
            legacy = read_json(ROOT / "schemas/legacy" / (snapshot["role"] + ".schema.json"))
            audit_schema(legacy)
            errors.extend(validate_schema(snapshot["content"], legacy))
        else:
            errors.append("reference validator has no source snapshot schema handler for " + snapshot["schema_version"])
    snapshots = model["source_baseline"]["raw_snapshots"]
    if snapshots and (len(snapshots) != 3 or {s["role"] for s in snapshots} != {"requirements", "test_points", "traceability"}):
        errors.append("legacy snapshot import requires exactly the three original roles")
    source_artifact = artifact_map.get(model["source_baseline"]["source_document_artifact_uid"])
    if source_artifact and source_artifact["sha256"] != model["source_baseline"]["source_sha256"]:
        errors.append("source baseline document digest mismatch")
    if manifest["status"] != "complete":
        errors.append("package is staging; not a committed handoff")
    return errors

def self_test():
    directory = ROOT / "examples/engineering-demo"
    errors = validate_package(directory)
    if errors:
        raise AssertionError("valid fixture failed: " + str(errors[:20]))
    other_errors = validate_package(ROOT / "examples/taskbook-demo")
    if other_errors:
        raise AssertionError("taskbook fixture failed: " + str(other_errors[:20]))
    original = read_json(directory / "model.json")
    manifest = read_json(directory / "package.json")
    artifacts = [a["uid"] for a in manifest["artifacts"]]
    cases = []
    def negative(name, mutate):
        data = copy.deepcopy(original)
        mutate(data)
        if not semantic_checks(data, artifacts):
            raise AssertionError("negative case accepted: " + name)
        cases.append(name)
    negative("lost source requirement", lambda x: x["requirements"].clear())
    negative("waiver cannot change effective view", lambda x: x["effective_requirements"][0].update(revision_uid="rev:latency-source"))
    negative("unapproved active revision", lambda x: x["consistency"]["decisions"][0].update(status="stale"))
    negative("invalid source snapshot semantics", lambda x: x["source_baseline"]["atomic_requirements"][0]["semantic"].update(statement="silently changed"))
    negative("false unknown", lambda x: x["basic_info"]["chip_model"].update(value=False))
    negative("missing inventory", lambda x: x["completeness"]["content_inventory"].clear())
    negative("bad coverage arithmetic", lambda x: x["traceability"]["metrics"][0].update(rate=0.5))
    negative("missing pass evidence", lambda x: x["verification"]["executions"][0]["criterion_results"][0]["evidence_artifact_refs"].clear())
    negative("old case revision", lambda x: x["verification"]["executions"][0].update(case_revision=2))
    negative("wrong verification method", lambda x: x["verification"]["coverage_claims"][0].update(method="board_test"))
    negative("final release without approval", lambda x: x["protocol"].update(profile="reqspec-reviewed"))
    negative("omitted active requirement in architecture", lambda x: x["views"]["architecture"]["requirement_refs"].clear())
    negative("unresolved gap declared ready", lambda x: x["views"]["architecture"].update(readiness="ready"))
    negative("dangling reference", lambda x: x["requirements"][0]["analysis_refs"].append("function:missing"))
    negative("wrong reference namespace", lambda x: x["requirements"][0]["source_atomic_refs"].append("evidence:taskbook"))
    negative("draft case cannot claim coverage", lambda x: x["verification"]["test_cases"][0].update(status="draft"))
    negative("exceptions cannot be hidden", lambda x: x["consistency"]["gates"].update(has_exceptions=False))
    for invalid in ("../escape", "D:/escape", "/escape", "assets/../escape", "assets\\escape"):
        try:
            safe_artifact(directory, invalid)
            raise AssertionError("unsafe path accepted")
        except ValueError:
            pass
    for source in ('{"x":1,"x":2}', '{"x":NaN}'):
        try:
            json.loads(source, object_pairs_hook=object_pairs, parse_constant=reject_constant)
            raise AssertionError("invalid JSON accepted")
        except ValueError:
            pass
    # Syntax compatibility only; it does not substitute for Win7 runtime validation.
    for path in (ROOT / "scripts").glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 8))
    print("PASS: 2 positive packages; {0} semantic negatives; 5 path cases; duplicate/NaN rejection; Python 3.8 grammar".format(len(cases)))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path, nargs="?")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    try:
        if args.self_test:
            self_test()
            return 0
        if args.package is None:
            parser.error("package directory required")
        errors = validate_package(args.package)
        if errors:
            print("\n".join(errors))
            return 1
        print("FEIP_VALIDATION_OK (structure and implemented deterministic invariants only)")
        return 0
    except (OSError, ValueError, KeyError, TypeError, AssertionError) as exc:
        print("FEIP_VALIDATION_ERROR: " + str(exc), file=sys.stderr)
        return 2

if __name__ == "__main__":
    sys.exit(main())
