"""Two/three-round DOCX regressions for global references to historical issues."""
import copy
import zipfile
from pathlib import Path

from . import batches
from .base import load, save
from .prepare import prepare
from .review_stage import review


def issue_reference_tests(root):
    root.mkdir()
    results = []
    source = root / "任务书.docx"
    fragment_file = root / "fragment.json"

    def write_docx(value):
        with zipfile.ZipFile(str(source), "w") as archive:
            archive.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>' + value + '</w:t></w:r></w:p></w:body></w:document>')

    def filled(attempt):
        payload = load(batches.next_task(attempt)["template"])
        payload["summary"] = "虚构多轮DOCX复现；规则预置，仅验证引用及闭环边界"
        for item in payload["issues"] + payload["todos"]:
            item.update(status="closed", evidence_refs=["e00001"], closure_reason="虚构本轮源修订已核实", closure_evidence_refs=["e00001"])
        for check in payload.get("checks", []):
            check.update(status="pass", rationale="虚构已复核本轮源文", evidence_refs=["e00001"], issue_refs=[])
        for check in payload.get("extraction_checks", []):
            check.update(status="complete", rationale="测试DOCX文字完整抽取")
        return payload

    def submit(attempt, payload):
        save(fragment_file, payload)
        return batches.submit(attempt, fragment_file)

    def local_review(attempt):
        while batches.status(attempt)["chunks_done"] < batches.status(attempt)["chunks_total"]:
            submit(attempt, filled(attempt))

    def rejects(name, function, *messages):
        try:
            function()
        except (ValueError, KeyError, OSError) as exc:
            assert all(m in str(exc) for m in messages), (name, str(exc))
            results.append(name)
        else:
            raise AssertionError("negative case accepted: " + name)

    write_docx("产品用于数据处理，FPGA职责和约束待明确。")
    first = prepare("taskbook", root / "first", source)
    while not batches.status(first["attempt"])["complete"]:
        payload = filled(first["attempt"])
        if payload["task_uid"].startswith("global:"):
            group = payload["task_uid"].split(":")[1]
            issue_uid = "issue:old_" + group
            payload["issues"] = [{"uid": issue_uid, "description": "虚构待明确项：" + group, "status": "open", "severity": "warning", "blocking": False,
                                  "evidence_refs": ["e00001"], "impact": "虚构工程影响", "recommendation": "修订源条款"}]
            payload["checks"][0].update(status="fail", issue_refs=[issue_uid])
            if group == "quality":
                payload["todos"] = [{"uid": "todo:old_quality", "issue_uid": issue_uid, "description": "虚构需求质量修订待办", "status": "open", "evidence_refs": ["e00001"]}]
        submit(first["attempt"], payload)
    assert review(first["attempt"], None, root / "review1")["state"] == "REVIEWING"

    write_docx("产品用于数据处理，FPGA负责采集与帧校验，相关约束已明确。")
    second = prepare("taskbook", root / "second", source, previous_state=root / "review1/review_state.json")
    local_review(second["attempt"])
    payload = filled(second["attempt"])
    assert payload["task_uid"] == "global:structure"
    assert {i["uid"] for i in payload["issues"]} == {"issue:old_structure"}
    context = load(Path(second["attempt"]) / "review-work/context/global-structure.json")
    index = {i["uid"]: i for i in context["issue_index"]}
    assert index["issue:old_quality"]["owner_task"] == "global:quality" and not index["issue:old_quality"]["registered_in_current_round"]
    results.append("second-docx-round-preserves-global-owner-and-exposes-pending-issue-index")
    bad = copy.deepcopy(payload)
    bad["checks"][0]["issue_refs"] = ["issue:typo"]
    rejects("unknown-global-issue-still-rejected-with-rule-and-uid", lambda: submit(second["attempt"], bad), "GLOBAL_RULE_ISSUE_REFERENCE_INVALID", "STR-001", "issue:typo")
    bad["checks"][0]["issue_refs"] = ["todo:old_quality"]
    rejects("todo-id-cannot-be-used-as-issue-reference", lambda: submit(second["attempt"], bad), "GLOBAL_RULE_ISSUE_REFERENCE_INVALID", "todo:old_quality")
    all_uids = ["issue:old_" + g for g in batches.GROUPS]
    payload["checks"][0]["issue_refs"] = all_uids
    submit(second["attempt"], payload)
    results.append("early-global-group-can-reference-prior-issues-owned-by-later-groups")
    while not batches.status(second["attempt"])["complete"]:
        payload = filled(second["attempt"])
        group = payload["task_uid"].split(":")[1]
        assert {i["uid"] for i in payload["issues"]} == {"issue:old_" + group}
        payload["checks"][0]["issue_refs"] = all_uids
        submit(second["attempt"], payload)
    assert review(second["attempt"], None, root / "review2")["state"] == "AWAITING_STRUCTURE_CONFIRMATION"
    final = load(root / "review2/review_state.json")["record"]
    assert {i["uid"] for i in final["issues"]} == set(all_uids) and all(i["status"] == "closed" for i in final["issues"])
    assert all(t["status"] == "closed" for t in final["todos"])
    assert not (root / "review2/model.json").exists() and not (root / "review2/需求清单.md").exists()
    results.append("four-global-groups-close-second-docx-round-without-premature-demand-output")

    write_docx("产品用于数据处理，新增工况使需求质量问题需要重新核查。")
    third = prepare("taskbook", root / "third", source, previous_state=root / "review2/review_state.json")
    local_review(third["attempt"])
    payload = filled(third["attempt"])
    payload["checks"][0].update(status="fail", issue_refs=["issue:old_quality"])
    submit(third["attempt"], payload)
    while not batches.status(third["attempt"])["complete"]:
        payload = filled(third["attempt"])
        if payload["task_uid"] == "global:quality":
            issue = payload["issues"][0]
            issue.update(status="open")
            issue.pop("closure_reason", None)
            issue.pop("closure_evidence_refs", None)
            payload["checks"][0].update(status="fail", issue_refs=[issue["uid"]])
        submit(third["attempt"], payload)
    assert review(third["attempt"], None, root / "review3")["state"] == "REVIEWING"
    results.append("historical-closed-issue-can-await-later-owner-reopening-with-final-gate-preserved")

    invalid = prepare("taskbook", root / "invalid-status", source, previous_state=root / "review2/review_state.json")
    local_review(invalid["attempt"])
    payload = filled(invalid["attempt"])
    payload["checks"][0].update(status="unknown", issue_refs=["issue:old_quality"])
    submit(invalid["attempt"], payload)
    while not batches.status(invalid["attempt"])["complete"]:
        submit(invalid["attempt"], filled(invalid["attempt"]))
    rejects("pending-reference-does-not-bypass-final-current-round-status-check", lambda: review(invalid["attempt"], None, root / "invalid-review"), "REVIEW_FAILED_RULE_REQUIRES_OPEN_ISSUE")

    # Older whole-record reviews have no checkpoint ownership information.
    from .review_selftest import synthetic_record
    legacy = prepare("taskbook", root / "legacy", source)
    record = synthetic_record(legacy)
    element = record["reviewed_element_refs"][0]
    record["issues"] = [{"uid": "issue:legacy", "description": "虚构旧格式问题", "status": "open", "severity": "warning", "blocking": False,
                         "evidence_refs": [element], "impact": "虚构影响", "recommendation": "修订"}]
    record["checks"][0].update(status="fail", issue_refs=["issue:legacy"])
    save(root / "legacy-record.json", record)
    review(legacy["attempt"], root / "legacy-record.json", root / "legacy-review")
    write_docx("产品职责已明确，虚构旧格式问题已修订。")
    migrated = prepare("taskbook", root / "migrated", source, previous_state=root / "legacy-review/review_state.json")
    local_review(migrated["attempt"])
    payload = filled(migrated["attempt"])
    assert not payload["issues"]
    payload["checks"][0]["issue_refs"] = ["issue:legacy"]
    submit(migrated["attempt"], payload)
    while not batches.status(migrated["attempt"])["complete"]:
        submit(migrated["attempt"], filled(migrated["attempt"]))
    assert review(migrated["attempt"], None, root / "migrated-review")["state"] == "AWAITING_STRUCTURE_CONFIRMATION"
    results.append("legacy-review-with-quality-fallback-allows-earlier-group-history-reference")
    return results
