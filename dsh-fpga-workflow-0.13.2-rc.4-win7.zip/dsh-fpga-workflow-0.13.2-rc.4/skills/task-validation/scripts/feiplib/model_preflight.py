"""Incremental fragment diagnostics and cached local-model preflight, without an LLM."""
from pathlib import Path
from time import perf_counter

from . import contract
from .base import SKILL, digest, load, require, save, text

FORMAT = "taskbook-model-preflight/1.0"
OPAQUE = ("content", "before", "after", "payload")


def walk(value, path=()):
    if isinstance(value, dict):
        yield path, value
        for key, item in value.items():
            if key not in OPAQUE:
                yield from walk(item, path + (key,))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk(item, path + (index,))


def location(path):
    return "/" + "/".join(str(p).replace("~", "~0").replace("/", "~1") for p in path)


def at(value, path):
    for key in path:
        value = value[key]
    return value


def problem(code, task, path, message, **details):
    return dict(code=code, task_uid=task, checkpoint="model-work/checkpoints/" + task.replace(":", "-") + ".json" if task else "",
                path=location(path), message=message, **details)


def definitions(payload):
    rows = []
    for pointer, values in payload.get("collections", {}).items():
        for index, value in enumerate(values):
            start = ("collections", pointer, index)
            owner = value.get("uid", value.get("header", {}).get("uid")) if isinstance(value, dict) else None
            owned_headers = set()
            for path, node in walk(value, start):
                if set(node) == {"kind", "uid", "revision_uid"}:
                    continue
                if "header" in node and isinstance(node["header"], dict) and "uid" in node["header"]:
                    identity = node["header"]["uid"]
                    owned_headers.add(path + ("header",))
                elif path not in owned_headers and "uid" in node:
                    identity = node["uid"]
                else:
                    continue
                rows.append({"uid": identity, "collection": pointer, "path": list(path), "signature": contract.fingerprint(node),
                             "owner_uid": owner, "relative_path": list(path[len(start):])})
    return rows


def summary(payload):
    return {"definitions": definitions(payload), "source_ids": [
        {"collection": pointer, "source_id": row["source_id"], "uid": row["uid"], "path": ["collections", pointer, index]}
        for pointer in ("/source_baseline/parents", "/source_baseline/atomic_requirements")
        for index, row in enumerate(payload.get("collections", {}).get(pointer, []))]}


def cached(path, key):
    if path.is_file():
        try:
            value = load(path)
            if value.get("key") == key and value.get("sha256") == contract.fingerprint(value["data"]):
                return value["data"]
        except (KeyError, ValueError, OSError, TypeError):
            pass
    return None


def cache(path, key, data):
    save(path, {"key": key, "sha256": contract.fingerprint(data), "data": data})


def checker_key(manifest):
    from .model_batches import manifest_basis
    return contract.fingerprint([FORMAT, digest(__file__), digest(Path(__file__).with_name("model_batches.py")),
                                 digest(SKILL / "references/protocol/schemas/engineering.schema.json"), manifest_basis(manifest)])


def local_key(manifest, records):
    return contract.fingerprint([checker_key(manifest), {k: v["payload_sha256"] for k, v in records.items() if not k.startswith("model:meta-")}])


def peek(attempt, manifest, records):
    """A progress query never launches a full preflight after each local repair."""
    prior = cached(Path(attempt) / "model-work/preflight-cache.json", local_key(manifest, records))
    if prior and Path(prior["report_json"]).is_file() and Path(prior["report_md"]).is_file():
        return dict(prior, cache_hit=True)
    return None


def summaries(attempt, manifest, records):
    key = checker_key(manifest)
    path = Path(attempt) / "model-work/preflight-index.json"
    old = cached(path, key) or {}
    result = {}
    for task, row in records.items():
        previous = old.get(task)
        if previous and previous["payload_sha256"] == row["payload_sha256"]:
            result[task] = previous
        else:
            result[task] = {"payload_sha256": row["payload_sha256"], "summary": summary(row["payload"])}
    return result


def update_index(attempt, manifest, records, index=None):
    index = summaries(attempt, manifest, records) if index is None else index
    cache(Path(attempt) / "model-work/preflight-index.json", checker_key(manifest), index)


def intrinsic(payload, base):
    """Only rules decidable from one fragment and frozen evidence; forward object refs are allowed."""
    task, errors = payload["task_uid"], []
    evidence = {e["uid"] for e in base["consistency"]["evidence"]}
    for path, node in walk(payload):
        refs = node.get("evidence_refs")
        if isinstance(refs, list) and any(ref not in evidence for ref in refs):
            errors.append(problem("MODEL_EVIDENCE_REFERENCE_INVALID", task, path + ("evidence_refs",),
                                  "证据必须使用冻结模型的evidence UID。", unknown_refs=[r for r in refs if r not in evidence]))
        if set(node) == {"status", "value", "reason", "evidence_refs"}:
            if (node["status"] == "present") != (node["value"] is not None) or node["status"] != "present" and not node["reason"]:
                errors.append(problem("MODEL_FACT_INVALID", task, path, "已知事实须有value；未知事实须为null并注明原因。"))
    for index, row in enumerate(payload.get("inventory", [])):
        if row["normative"] is True and row["disposition"] in ("descriptive_only", "historical"):
            errors.append(problem("MODEL_NORMATIVE_DISPOSITION_INVALID", task, ("inventory", index), "规范性义务不能仅归为描述或历史素材。"))
    for pointer in ("/source_baseline/parents", "/source_baseline/atomic_requirements"):
        for index, row in enumerate(payload.get("collections", {}).get(pointer, [])):
            semantic = row.get("semantic", row)
            if not semantic.get("evidence_refs"):
                suffix = ("semantic", "evidence_refs") if "semantic" in row else ("evidence_refs",)
                errors.append(problem("SOURCE_ATOM_EVIDENCE_MISSING" if "semantic" in row else "SOURCE_PARENT_EVIDENCE_MISSING",
                    task, ("collections", pointer, index) + suffix, "源条款/原子义务必须有非空来源证据。", uid=row["uid"]))
    for index, req in enumerate(payload.get("collections", {}).get("/requirements", [])):
        for number, rev in enumerate(req["revisions"]):
            if rev["basis"] == "source" and not rev["semantic"]["evidence_refs"]:
                errors.append(problem("SOURCE_REVISION_EVIDENCE_MISSING", task,
                    ("collections", "/requirements", index, "revisions", number, "semantic", "evidence_refs"),
                    "源修订必须保留其原子义务的真实证据。", uid=req["uid"]))
    for index, point in enumerate(payload.get("collections", {}).get("/verification/source_test_points", [])):
        if point["completeness"] == "complete" and (not point["requirement_refs"] or point["missing_fields"] or
                not all(isinstance(point.get(k), str) and point[k].strip() for k in
                        ("object", "purpose", "stimulus", "procedure", "expected_result", "pass_criteria"))):
            errors.append(problem("TEST_POINT_INCOMPLETE", task, ("collections", "/verification/source_test_points", index),
                                  "complete测试要点缺少必要字段或关联需求。", uid=point["uid"]))
    return errors


def changed_fields(left, right, path="", result=None):
    result = [] if result is None else result
    if len(result) >= 16 or left == right:
        return result
    if isinstance(left, dict) and isinstance(right, dict):
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                result.append(path + "/" + key)
            else:
                changed_fields(left[key], right[key], path + "/" + key, result)
            if len(result) >= 16:
                break
    else:
        result.append(path or "/")
    return result


def collisions(index, payloads, only=None):
    identities, sources, errors = {}, {}, []
    for task, entry in index.items():
        for row in entry["summary"]["definitions"]:
            old = identities.get(row["uid"])
            if old and (old[1]["signature"] != row["signature"] or old[1]["collection"] != row["collection"] or
                        old[1]["owner_uid"] != row["owner_uid"] or old[1]["relative_path"] != row["relative_path"]):
                if only is None or task == only or old[0] == only:
                    fields = changed_fields(at(payloads[old[0]], old[1]["path"]), at(payloads[task], row["path"]))
                    errors.append(problem("MODEL_UID_CONFLICT", task, tuple(row["path"]), "相同UID对应不同对象内容或集合。",
                        uid=row["uid"], other_task_uid=old[0], other_path=location(old[1]["path"]), differing_fields=fields))
            else:
                identities.setdefault(row["uid"], (task, row))
        for row in entry["summary"]["source_ids"]:
            key = (row["collection"], row["source_id"])
            old = sources.get(key)
            if old and old[1]["uid"] != row["uid"] and (only is None or task == only or old[0] == only):
                errors.append(problem("MODEL_SOURCE_ID_CONFLICT", task, tuple(row["path"]), "相同完整源编号建立了不同UID的对象。",
                    uid=row["uid"], source_id=row["source_id"], other_task_uid=old[0], other_path=location(old[1]["path"])))
            else:
                sources.setdefault(key, (task, row))
    return errors, identities


def semantic_pairs(payloads, only=None, same_fragment=False):
    atoms, errors = {}, []
    for task, payload in payloads.items():
        for index, atom in enumerate(payload.get("collections", {}).get("/source_baseline/atomic_requirements", [])):
            atoms[atom["uid"]] = (task, atom)
    for task, payload in payloads.items():
        for index, req in enumerate(payload.get("collections", {}).get("/requirements", [])):
            refs = req["source_atomic_refs"]
            if len(refs) != 1 or refs[0] not in atoms:
                continue
            atom_task, atom = atoms[refs[0]]
            if same_fragment and atom_task != task or only is not None and only not in (task, atom_task):
                continue
            for number, rev in enumerate(req["revisions"]):
                if rev["basis"] == "source" and rev["semantic"] != atom["semantic"]:
                    errors.append(problem("MODEL_SOURCE_SEMANTIC_MISMATCH", task,
                        ("collections", "/requirements", index, "revisions", number, "semantic"),
                        "源修订与源atom语义必须完全相等，包含evidence_refs。", uid=req["uid"], other_task_uid=atom_task,
                        atom_uid=atom["uid"], differing_fields=changed_fields(rev["semantic"], atom["semantic"])))
    return errors


def write_report(attempt, name, result):
    from .review_report import markdown
    root = Path(attempt) / "model-work/diagnostics"
    json_path, md_path = root / (name + ".json"), root / (name + ".md")
    save(json_path, result)
    lines = ["# 局部建模快速检查", "", "- 结果：" + ("通过" if result["valid"] else "待修正"),
             "- 问题数：" + str(len(result["errors"])), "", "本报告仅检查建模数据结构，不代替任务书语义审查或结构化授权。", ""]
    for issue in result["errors"]:
        lines += ["## " + markdown(issue["code"]), "", "- 任务：" + markdown(issue["task_uid"] or "全局"),
                  "- 文件：" + markdown(issue["checkpoint"]), "- 字段：" + markdown(issue["path"]),
                  "- 说明：" + markdown(issue["message"])]
        for key, label in (("uid", "对象UID"), ("other_task_uid", "关联任务"), ("other_path", "关联字段"),
                           ("differing_fields", "差异字段"), ("unknown_refs", "无效引用")):
            if key in issue:
                lines += ["- " + label + "：" + markdown("、".join(issue[key]) if isinstance(issue[key], list) else issue[key])]
        lines += [""]
    text(md_path, "\n".join(lines) + "\n")
    return str(json_path), str(md_path)


def check_submission(attempt, manifest, records, base, payload):
    task = payload["task_uid"]
    index = summaries(attempt, manifest, records)
    index[task] = {"payload_sha256": contract.fingerprint(payload), "summary": summary(payload)}
    payloads = {k: v["payload"] for k, v in records.items()}
    payloads[task] = payload
    errors = intrinsic(payload, base) + collisions(index, payloads, only=task)[0]
    frozen_ids = {node["uid"] for _, node in walk(base) if "uid" in node and set(node) != {"kind", "uid", "revision_uid"}}
    for row in index[task]["summary"]["definitions"]:
        if row["uid"] in frozen_ids:
            errors.append(problem("MODEL_UID_CONFLICT", task, tuple(row["path"]), "新对象UID与冻结模型已有对象重复。", uid=row["uid"]))
    errors += semantic_pairs({task: payload}, same_fragment=True)
    if errors:
        report, _ = write_report(attempt, "submit-errors", {"valid": False, "errors": errors})
        require(False, "MODEL_FRAGMENT_PREFLIGHT_FAILED: " + errors[0]["code"] + "; errors=" + str(len(errors)) + "; report=" + report)
    # Cross-task source revisions may temporarily disagree during a multi-fragment
    # correction. Report them immediately; the pre-meta gate rejects unresolved pairs.
    pending = semantic_pairs(payloads, only=task)
    return index, pending


def read_local(attempt):
    """Diagnostic-only path: works on an old attempt without granting generation authorization."""
    attempt = Path(attempt)
    info = load(attempt / "attempt.json")
    require(info.get("kind") == "taskbook", "MODEL_PREFLIGHT_REQUIRES_MODEL_ATTEMPT")
    from .model_batches import ModelManifest, manifest_basis
    from .batches import filename
    manifest = ModelManifest(load(attempt / "model-work/manifest.json"))
    basis = manifest_basis(manifest)
    require(manifest["template_sha256"] == digest(attempt / "model.template.json"), "MODEL_TEMPLATE_CHANGED")
    records = {}
    for chunk in manifest["source"]["chunks"]:
        task = "model:" + chunk["uid"].split(":")[1]
        path = attempt / "model-work/checkpoints" / filename(task)
        if path.exists():
            row = load(path)
            require(row["payload_sha256"] == contract.fingerprint(row["payload"]), "MODEL_CHECKPOINT_CORRUPT: " + task)
            require(row["payload"]["run_uid"] == manifest["run_uid"] and row["payload"]["task_uid"] == task,
                    "MODEL_CHECKPOINT_STALE: " + task)
            require(row["payload"]["basis_sha256"] == basis, "MODEL_CHECKPOINT_STALE: " + task)
            records[task] = row
    return manifest, records, load(attempt / "model.template.json")


def run(attempt, manifest=None, records=None, base=None):
    started = perf_counter()
    if manifest is None:
        manifest, records, base = read_local(attempt)
    local = {k: v for k, v in records.items() if not k.startswith("model:meta-")}
    expected = {"model:" + c["uid"].split(":")[1] for c in manifest["source"]["chunks"]}
    key = local_key(manifest, local)
    cache_path = Path(attempt) / "model-work/preflight-cache.json"
    prior = peek(attempt, manifest, local)
    if prior:
        return dict(prior, cache_hit=True, elapsed_seconds=round(perf_counter() - started, 4))
    errors = [problem("LOCAL_MODEL_FRAGMENTS_INCOMPLETE", task, (), "尚未提交本局部片段。") for task in sorted(expected - set(local))]
    payloads = {k: v["payload"] for k, v in local.items()}
    base = load(Path(attempt) / "model.template.json") if base is None else base
    # Old attempts also get shape diagnostics, using the same schema object once.
    from .model_batches import schema_at
    usable = {}
    for task, payload in payloads.items():
        shape_errors = []
        for pointer, value in payload.get("collections", {}).items():
            if pointer not in manifest["collection_paths"]:
                shape_errors.append(problem("MODEL_IMMUTABLE_PATH", task, ("collections", pointer), "不允许写此集合。"))
                continue
            node, schema = schema_at(pointer)
            findings = contract.validate_schema(value, node, schema)
            if findings:
                shape_errors.append(problem("MODEL_FRAGMENT_SCHEMA_INVALID", task, ("collections", pointer), "；".join(findings[:8])))
        errors += shape_errors
        if not shape_errors:
            usable[task] = payload
            errors += intrinsic(payload, base)
    rows = {k: local[k] for k in usable}
    index = summaries(attempt, manifest, rows)
    found, identities = collisions(index, usable)
    errors += found + semantic_pairs(usable)
    registry = {node["uid"] for _, node in walk(base) if "uid" in node}
    for identity, (task, row) in identities.items():
        if identity in registry:
            errors.append(problem("MODEL_UID_CONFLICT", task, tuple(row["path"]), "局部对象UID与冻结对象重复。", uid=identity))
    registry.update(identities)
    registry.update((base["protocol"]["run_uid"], base["protocol"]["baseline_uid"], base["meta"]["project_uid"]))
    registry.update(u["uid"] for u in manifest["source"]["units"])
    info = load(Path(attempt) / "attempt.json")
    registry.update(a["uid"] for a in info["artifacts"])
    for task, payload in usable.items():
        for path, node in walk(payload):
            for field, value in node.items():
                refs = value if field.endswith("_refs") and isinstance(value, list) else [value] if field.endswith("_uid") and value is not None and field not in ("run_uid", "task_uid") else []
                for ref in refs:
                    if isinstance(ref, str) and ref not in registry and field != "parent_package_refs":
                        errors.append(problem("MODEL_REFERENCE_INVALID", task, path + (field,), "局部模型完成后仍有失效引用。", unknown_refs=[ref]))
            if set(node) == {"kind", "uid", "revision_uid"} and node["uid"] not in registry:
                errors.append(problem("MODEL_REFERENCE_INVALID", task, path + ("uid",), "对象引用未登记。", unknown_refs=[node["uid"]]))
        for pointer, values in payload.get("collections", {}).items():
            if pointer.endswith("_refs"):
                for ref in values:
                    if isinstance(ref, str) and ref not in registry:
                        errors.append(problem("MODEL_REFERENCE_INVALID", task, ("collections", pointer), "引用集合含未登记对象。", unknown_refs=[ref]))
    errors += whole_local_checks(usable, base, manifest)
    result = {"contract": FORMAT, "valid": not errors, "local_total": len(expected), "local_done": len(local),
              "error_count": len(errors), "errors": errors, "cache_hit": False,
              "elapsed_seconds": round(perf_counter() - started, 4)}
    result["report_json"], result["report_md"] = write_report(attempt, "local-preflight", result)
    cache(cache_path, key, result)
    update_index(attempt, manifest, rows, index)
    return result


def whole_local_checks(payloads, base, manifest):
    errors, atoms, requirements, inventory, placements = [], {}, {}, {}, {}
    template = load(Path(__file__).resolve().parents[2] / "templates/document_structure.json")
    sections = set(template["required_sections"])
    for task, payload in payloads.items():
        for row in payload.get("collections", {}).get("/source_baseline/atomic_requirements", []):
            atoms[row["uid"]] = task
        for req in payload.get("collections", {}).get("/requirements", []):
            requirements[req["uid"]] = (task, req)
        for row in payload.get("inventory", []):
            inventory.setdefault(row["element_uid"], []).append((task, row))
        for index, row in enumerate(payload.get("placements", [])):
            if row["section"] not in sections or row["role"] not in ("main", "cross", "deferred"):
                errors.append(problem("MODEL_PLACEMENT_INVALID", task, ("placements", index), "落点章节或类型不合法。"))
            number = row["section"]
            manual = number == "7" or number.startswith("7.") or number in ("10", "11", "C", "D")
            if row["role"] in ("main", "deferred") or row["role"] == "cross" and manual:
                placements.setdefault(row["requirement_uid"], []).append((task, row))
        for number in payload.get("section_notes", {}):
            if number not in sections:
                errors.append(problem("MODEL_SECTION_NOTE_INVALID", task, ("section_notes", number), "未知章节。"))
    if not atoms:
        errors.append(problem("EMPTY_BASELINE", "", (), "尚未建立任何源原子义务。"))
    retained = {r for _, req in requirements.values() for r in req["source_atomic_refs"]}
    for atom in sorted(set(atoms) - retained):
        errors.append(problem("MODEL_SOURCE_ATOM_UNRETAINED", atoms[atom], (), "源原子义务未进入工程需求台账。", uid=atom))
    for identity, (task, req) in requirements.items():
        if req["lifecycle"] != "active":
            continue
        rows = placements.get(identity, [])
        # Identical repeated placements are deduplicated by final assembly.
        values = {(r["section"], r["role"]) for _, r in rows}
        if len(values) != 1:
            errors.append(problem("MODEL_REQUIREMENT_PLACEMENT_INVALID", task, (), "有效需求须有唯一主落点或明确deferred落点。", uid=identity))
        elif rows and rows[0][1]["role"] == "deferred":
            number = rows[0][1]["section"]
            if not (number == "7" or number.startswith("7.") or number in ("10", "11", "C", "D")):
                errors.append(problem("MODEL_DEFERRED_PLACEMENT_INVALID", rows[0][0], (), "仅保留/人工章节可使用deferred。", uid=identity))
    expected = {row["element_uid"] for row in base["completeness"]["content_inventory"]}
    for element in sorted(expected - set(inventory)):
        errors.append(problem("MODEL_SOURCE_ELEMENTS_OMITTED", "", (), "原文元素未进入inventory。", uid=element))
    for element, rows in inventory.items():
        for task, row in rows:
            if row["disposition"] == "pending":
                errors.append(problem("MODEL_INVENTORY_STILL_PENDING", task, (), "原文元素分类仍为pending。", uid=element))
    return errors


def require_valid(result):
    require(result["valid"], "MODEL_LOCAL_PREFLIGHT_FAILED: errors=" + str(result["error_count"]) + "; report=" + result["report_md"])
