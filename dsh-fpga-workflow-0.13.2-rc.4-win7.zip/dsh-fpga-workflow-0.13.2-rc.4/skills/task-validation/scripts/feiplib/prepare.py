"""Freeze all inputs and create a schema-shaped Agent editing model."""
import copy
import shutil
from pathlib import Path

from . import contract
from .base import SKILL, VERSION, digest, fact, load, now, require, save, uid, verify_package
from .extract import extract

def prepare(kind, output, source=None, baseline=None, previous_state=None, decisions=None, diagnostic=False, attachments=None, closed_review=None, confirmation=None, chunk_chars=4000, skill_test=False, incremental_global=False):
    require(isinstance(skill_test, bool), "SKILL_TEST_FLAG_INVALID")
    require(not skill_test or kind == "taskbook" and closed_review and confirmation, "SKILL_TEST_REQUIRES_REVIEW_AND_EXPLICIT_AUTHORIZATION")
    if kind == "taskbook":
        from .review_stage import authorize, prepare_review
        require(baseline is None and decisions is None and not diagnostic, "TASKBOOK_REVIEW_OPTIONS_INVALID")
        require(bool(closed_review) == bool(confirmation), "STRUCTURE_REQUIRES_CLOSED_REVIEW_AND_CONFIRMATION")
        if not closed_review:
            return prepare_review(source, output, attachments, previous_state, chunk_chars, incremental_global)
        require(previous_state is None, "STRUCTURE_USE_CONFIRMED_CLOSED_REVIEW")
        authorize(closed_review, confirmation, source, attachments, skill_test=skill_test)
    run_uid = uid("run")
    attempt = Path(output).resolve() / "attempts" / run_uid.split(":")[1]
    if closed_review:
        reviewed_root = Path(closed_review).resolve()
        require(attempt != reviewed_root and reviewed_root not in attempt.parents and attempt not in reviewed_root.parents,
                "STRUCTURE_OUTPUT_INSIDE_REVIEW: use a separate output root")
    attempt.mkdir(parents=True, exist_ok=False)
    info = {"contract": "feip-skill-attempt/1.0", "kind": kind, "run_uid": run_uid, "created_at": now(),
        "artifacts": [], "input_bindings": [], "original_inputs": [], "parent_package": None, "diagnostic": diagnostic}

    def remember(path, relative, artifact_uid):
        destination = attempt / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(str(path), str(destination))
        info["artifacts"].append({"uid": artifact_uid, "path": relative})
        info["input_bindings"].append({"path": relative, "sha256": digest(destination)})
        info["original_inputs"].append({"path": str(Path(path).resolve()), "sha256": digest(path)})
        return destination

    inherited = None
    additional_archives = []
    if baseline:
        inherited, manifest = verify_package(baseline)
        require(inherited["protocol"]["profile"] == "taskbook-reviewed", "BASELINE_PROFILE: must be taskbook-reviewed")
        gates = inherited["consistency"]["gates"]
        if kind == "writer":
            require(gates["overall"] != "FAIL" and not gates["blocking_issue_refs"], "WRITER_UPSTREAM_BLOCKED")
        else:
            require(gates["overall"] == "PASS" or diagnostic, "CHECKER_UPSTREAM_NOT_PASS: diagnostic mode only")
        for art in manifest["artifacts"]:
            remember(contract.safe_artifact(Path(baseline), art["path"]), "inherited/" + art["path"], art["uid"])
        remember(Path(baseline) / "package.json", "inherited/package.json", uid("artifact"))
        info["parent_package"] = {"package_uid": manifest["package_uid"], "manifest_sha256": digest(Path(baseline) / "package.json")}
    require(kind == "taskbook" or inherited is not None, "BASELINE_REQUIRED")
    if source:
        source = Path(source).resolve()
        artifact_uid = uid("artifact")
        frozen = remember(source, "sources/current" + source.suffix.lower(), artifact_uid)
        archive = extract(frozen, "taskbook" if kind == "taskbook" else "specification", artifact_uid)
        save(attempt / "document_structure.json", archive)
        info["input_bindings"].append({"path": "document_structure.json", "sha256": digest(attempt / "document_structure.json")})
        info["source_artifact_uid"] = artifact_uid
    else:
        archive = None
    if previous_state:
        remember(Path(previous_state), "inputs/previous_state.json", uid("artifact"))
    if decisions:
        artifact_uid = uid("artifact")
        remember(Path(decisions), "inputs/user_decisions.json", artifact_uid)
        info["user_decisions_artifact_uid"] = artifact_uid
    if attachments:
        remember(Path(attachments), "inputs/attachments.json", uid("artifact"))
        records = load(attachments)
        require(isinstance(records, list), "ATTACHMENTS_MANIFEST_EXPECTED_ARRAY")
        for index, record in enumerate(records):
            path = Path(record["path"]).resolve()
            artifact_uid = uid("artifact")
            frozen = remember(path, "attachments/{0:03d}{1}".format(index, path.suffix.lower()), artifact_uid)
            if path.suffix.lower() in (".docx", ".txt", ".md"):
                additional_archives.append(extract(frozen, "attachment", artifact_uid))
            else:
                additional_archives.append({"uid": uid("archive"), "artifact_uid": artifact_uid, "role": "attachment", "extraction_status": "not_read", "sections": [],
                    "elements": [{"uid": uid("element"), "kind": "attachment", "part": "binary", "section_uid": None, "order": 0,
                        "text": record.get("description", path.name), "numbering": None, "cells": [], "asset_artifact_uid": artifact_uid,
                        "read_status": "unreadable", "limitations": ["binary attachment requires verified engineering transcription"]}], "limitations": ["not semantically extracted"]})
    if inherited:
        model = copy.deepcopy(inherited)
        model["protocol"].update(profile="reqspec-draft", run_uid=run_uid, producer="req-spec-gen" if kind == "writer" else "req-spec-consistency-check", producer_version=VERSION, created_at=now())
        model["protocol"]["parent_package_refs"] = [info["parent_package"]["package_uid"]]
        model["consistency"]["release_binding"] = None
        model["consistency"]["gates"]["delivery_state"] = "REVIEWING"
        model["consistency"]["gates"]["admission"] = "DIAGNOSTIC_ONLY" if diagnostic or model["source_baseline"]["status"] != "PASS" and kind == "checker" else "READY"
        model["consistency"]["round"] = 1
    else:
        schema = load(SKILL / "references/protocol/schemas/engineering.schema.json")
        model = {name: [] for name in ("acronyms", "reference_documents", "change_log", "document_archive", "requirements", "spec_items", "effective_requirements", "design_objects", "document_views", "extensions")}
        model["protocol"] = {"name": "FEIP", "version": "1.0.0", "profile": "taskbook-reviewed", "run_uid": run_uid,
            "baseline_uid": uid("baseline"), "producer": "task-validation", "producer_version": VERSION, "created_at": now(),
            "capabilities": ["source-retention", "field-provenance", "effective-requirements", "writer-routing"], "parent_package_refs": [], "synthetic": False}
        model["meta"] = {"project_uid": uid("project"), "title": "任务书审查模型"}
        model["meta"].update({key: fact() for key in ("document_number", "version", "date", "author", "reviewer", "approver")})
        model["basic_info"] = {key: fact() for key in schema["$defs"]["BasicInfo"]["properties"]}
        model["system_overview"] = {key: fact() for key in schema["$defs"]["SystemOverview"]["properties"]}
        model["acceptance"] = {"criterion_refs": [], "deliverables": [], "milestones": [], "configuration_rules": [], "third_party": fact(), "evidence_refs": []}
        model["analysis"] = {key: [] for key in schema["$defs"]["Analysis"]["properties"]}
        model["verification"] = {key: [] for key in schema["$defs"]["Verification"]["properties"]}
        model["source_baseline"] = {"baseline_uid": model["protocol"]["baseline_uid"], "upstream_run_uid": run_uid,
            "source_document_artifact_uid": info["source_artifact_uid"], "source_sha256": digest(attempt / ("sources/current" + Path(source).suffix.lower())),
            "status": "FAIL", "raw_snapshots": [], "parents": [], "atomic_requirements": [], "interface_refs": [], "test_point_refs": [], "upstream_issue_refs": []}
        model["traceability"] = {"relations": [], "mappings": [], "metrics": []}
        model["consistency"] = {"round": 1, "gates": {"admission": "READY", "upstream": "FAIL", "local": "FAIL", "overall": "FAIL", "blocking_issue_refs": [],
            "has_exceptions": False, "generation_state": None, "delivery_state": "REVIEWING"}, "issues": [], "decisions": [], "todos": [], "notices": [], "evidence": [], "provenance": [], "release_binding": None}
        model["completeness"] = {"checks": [], "content_inventory": [], "gaps": []}
        model["views"] = {key: {"readiness": "blocked", "reason": "尚未完成语义建模与输入可用性审查", "requirement_refs": [], "object_refs": [], "constraint_refs": [],
            "obligation_refs": [], "case_refs": [], "gap_refs": [], "waiver_refs": [], "decision_refs": [], "allowed_refs": [], "excluded_refs": []} for key in ("architecture", "simulation", "confirmation")}
    if archive:
        model["document_archive"] = [a for a in model["document_archive"] if a["role"] != archive["role"]]
    info["extracted_archives"] = []
    for index, new_archive in enumerate(([archive] if archive else []) + additional_archives):
        model["document_archive"].append(new_archive)
        relative = "structures/archive-{0:03d}.json".format(index)
        save(attempt / relative, new_archive)
        info["input_bindings"].append({"path": relative, "sha256": digest(attempt / relative)})
        info["extracted_archives"].append(relative)
        for element in new_archive["elements"]:
            model["consistency"]["evidence"].append({"uid": uid("evidence"), "artifact_uid": new_archive["artifact_uid"], "json_pointer": None,
                "part": element["part"], "element_uid": element["uid"], "section": None, "table": None, "row": None, "column": None, "page": None,
                "quote": element["text"][:500], "origin_kind": "taskbook" if kind == "taskbook" else "spec_document", "confirmation": "evidenced"})
            model["completeness"]["content_inventory"].append({"element_uid": element["uid"], "disposition": "pending", "normative": None, "object_refs": [], "reason": "待Agent逐项识别与关联"})
    if kind in ("taskbook", "checker"):
        assessment_art = uid("artifact")
        remember(SKILL / "references/protocol/schemas/assessments.schema.json", "schemas/assessments.schema.json", assessment_art)
        rules = (["STR-{0:03d}".format(i) for i in range(1, 11)] + ["REQ-{0:03d}".format(i) for i in range(1, 9)] +
                 ["CON-{0:03d}".format(i) for i in range(1, 7)] + ["TST-{0:03d}".format(i) for i in range(1, 7)]) if kind == "taskbook" else [
                     "INP-001", "INP-002", "EXT-001", "MAP-001", "REQ-001", "REQ-002", "REQ-003", "SIG-001", "TST-001", "IDN-001", "SAF-001", "CLK-001", "CON-001", "CLR-001", "NTC-001"]
        model["extensions"].append({"namespace": "feip.assessments.v1", "schema_artifact_uid": assessment_art, "critical": False,
            "payload": {"stage": kind, "rules": [{"rule_id": r, "status": "unknown", "rationale": "待Agent检查", "evidence_refs": [], "issue_refs": []} for r in rules]}})
    if kind == "taskbook":
        # Freeze both the reviewed source version and its subsequent user approval.
        shutil.copytree(str(closed_review), str(attempt / "closed_review"))
        for path in (attempt / "closed_review").rglob("*"):
            if path.is_file():
                info["input_bindings"].append({"path": path.relative_to(attempt).as_posix(), "sha256": digest(path)})
        remember(Path(confirmation), "inputs/structure_confirmation.json", uid("artifact"))
        if skill_test:
            info["skill_test"] = True
            from .skill_test import initialize
            initialize(attempt, info, model, remember)
    save(attempt / "attempt.json", info)
    save(attempt / "model.template.json", model)
    if kind == "taskbook":
        from .model_batches import initialize
        progress = initialize(attempt, info, model, chunk_chars)
        from .model_batches import next_task
        first = next_task(attempt)
        return {"attempt": str(attempt), "template": first.get("template"), "reading": first.get("reading"), "guide": first.get("guide"), "batch_progress": progress,
                "skill_test": skill_test, "test_only": skill_test,
                "next": "model-next --attempt <attempt>; fill only the current fragment, not the full model"}
    return {"attempt": str(attempt), "template": str(attempt / "model.template.json"), "next": "Agent semantic modeling required"}
