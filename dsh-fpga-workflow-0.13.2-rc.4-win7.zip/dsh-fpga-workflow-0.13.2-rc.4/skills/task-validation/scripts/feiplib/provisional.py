"""Version-bound draft architecture and approved prompt supplements."""
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

from .base import Failure, digest, load, require, save, text
from .review_report import markdown
from .review_stage import architecture_deferral_candidate, nonempty, verify_review

M = markdown
ARCH = "taskbook-architecture-draft/1.0"
SUP = "taskbook-approved-supplement/1.0"
SECTIONS = {"requirements": "需求与约束", "interfaces": "外部接口与协议", "information_flow": "信息流",
            "data_flow": "数据流", "design_architecture": "设计架构", "module_responsibilities": "模块分工",
            "verification": "验证与验收", "project": "项目与交付"}
VIEWS = ("information_flow", "data_flow", "design_architecture", "module_responsibilities")


def binding(review, state):
    return {"review_uid": state["review_uid"], "review_state_sha256": digest(review / "review_state.json")}


def approval(document, kind, bound, state):
    require(isinstance(document, dict) and document.get("kind") == kind and
            all(document.get(k) == v for k, v in bound.items()), "APPROVAL_WRONG_KIND_OR_REVIEW")
    require(all(nonempty(document.get(k)) for k in ("actor", "user_quote", "confirmed_at")), "APPROVAL_EVIDENCE_REQUIRED")
    try:
        value = document["confirmed_at"]
        confirmed = datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)
    except ValueError as exc:
        raise Failure("APPROVAL_TIME_INVALID") from exc
    require(confirmed.utcoffset() is not None and confirmed >= datetime.fromisoformat(state["created_at"]),
            "APPROVAL_MUST_FOLLOW_REVIEW")


def gate(review, state, decision):
    record = state["record"]
    issues = {i["uid"]: i for i in record["issues"] if i["status"] != "closed"}
    candidates = {uid: issue for uid, issue in issues.items() if architecture_deferral_candidate(issue)}
    approved = set()
    approved_todos = set()
    if decision is not None:
        approval(decision, "approve_architecture_deferral", binding(review, state), state)
        refs = decision.get("issue_uids")
        require(isinstance(refs, list) and refs and all(nonempty(r) for r in refs) and len(set(refs)) == len(refs),
                "DEFERRAL_REQUIRES_EXACT_ISSUE_UIDS")
        require(set(refs) <= candidates.keys(), "DEFERRAL_ONLY_FOR_CURRENT_MISSING_INFORMATION")
        approved = set(refs)
        todos = decision.get("todo_uids", [])
        eligible_todos = {t["uid"] for t in record["todos"] if t["status"] == "deferred" and t["issue_uid"] in approved}
        require(isinstance(todos, list) and all(nonempty(t) for t in todos) and len(set(todos)) == len(todos)
                and set(todos) <= eligible_todos, "DEFERRAL_TODO_SCOPE_INVALID")
        approved_todos = set(todos)
    blockers = [{"type": "issue", "uid": i} for i in sorted(set(issues) - approved)]
    for todo in record["todos"]:
        if todo["status"] != "closed" and todo["uid"] not in approved_todos:
            blockers.append({"type": "todo", "uid": todo["uid"]})
    for check in record["checks"]:
        if check["status"] in ("fail", "unknown"):
            # A known failed consistency check must be fixed; unknown consistency may be
            # due solely to a missing parameter. Other failures must reference only approved gaps.
            if (check["status"] == "fail" and check["rule_id"].startswith("CON-")) or not (
                    check["issue_refs"] and set(check["issue_refs"]) <= approved):
                blockers.append({"type": "rule", "uid": check["rule_id"]})
    blockers.extend({"type": "extraction", "uid": c["archive_uid"]} for c in record["extraction_checks"]
                    if c["status"] == "unresolved")
    pending = [i for i in issues.values() if i["uid"] in approved]
    return {"status": "ARCHITECTURE_BLOCKED" if blockers else "ARCHITECTURE_READY",
            **binding(review, state), "blockers": blockers, "pending": pending,
            "deferral_candidates": [item for uid, item in candidates.items() if uid not in approved],
            "pending_todos": [t for t in record["todos"] if t["uid"] in approved_todos]}


def context(review):
    review = Path(review).resolve()
    return review, verify_review(review)


def status(review, decision=None):
    review, state = context(review)
    return gate(review, state, load(decision) if decision else None)


def validate_views(views, state, review):
    require(isinstance(views, dict) and set(views) == set(VIEWS), "ARCHITECTURE_FOUR_VIEWS_REQUIRED")
    elements = set(state["record"]["reviewed_element_refs"])
    issues = {i["uid"] for i in state["record"]["issues"] if i["status"] != "closed"}
    info = load(review / "attempt.json")
    partial = {e["uid"] for p in info["archives"] for e in load(review / p)["elements"] if e["read_status"] != "complete"}
    transcribed = {entry["target_ref"]: set(entry["evidence_refs"]) for check in state["record"]["extraction_checks"]
                   if check["status"] == "verified_transcription" for entry in check.get("transcription_map", [])}
    for key, entries in views.items():
        require(isinstance(entries, list) and entries, "ARCHITECTURE_VIEW_EMPTY: " + key)
        for row in entries:
            require(isinstance(row, dict) and set(row) == {"description", "basis", "evidence_refs", "pending_refs"}
                    and nonempty(row["description"]) and row["basis"] in ("source", "proposed", "unknown"),
                    "ARCHITECTURE_ROW_INVALID: " + key)
            for field, allowed in (("evidence_refs", elements), ("pending_refs", issues)):
                refs = row[field]
                require(isinstance(refs, list) and all(nonempty(r) and r in allowed for r in refs),
                        "ARCHITECTURE_REFERENCE_INVALID: " + field)
            require((row["basis"] == "unknown" and row["pending_refs"]) or
                    (row["basis"] == "source" and row["evidence_refs"] and not row["pending_refs"]) or
                    (row["basis"] == "proposed" and (row["evidence_refs"] or row["pending_refs"])),
                    "ARCHITECTURE_BASIS_REQUIRED: " + key)
            if row["basis"] == "source":
                refs = set(row["evidence_refs"])
                require(all(refs & transcribed.get(r, set()) for r in refs & partial),
                        "ARCHITECTURE_PARTIAL_SOURCE_REQUIRES_MATCHED_TRANSCRIPTION: " + key)


def architecture_markdown(document):
    labels = {"source": "源资料明确", "proposed": "设计建议", "unknown": "待补充"}
    lines = ["# 初版架构设计", "", "供方案讨论；未定参数不得作为设计或验收依据。",
             "", "审查版本：" + M(document["review_uid"])]
    for key in VIEWS:
        lines += ["", "## " + SECTIONS[key], ""]
        for row in document["views"][key]:
            refs = row["evidence_refs"] + row["pending_refs"]
            lines.append("- **" + labels[row["basis"]] + "**：" + M(row["description"]) + "（" + M("、".join(refs)) + "）")
    lines += ["", "## 已批准待补充", ""]
    for item in document["pending"]:
        lines.append("- " + M(item["uid"]) + "：" + M(item["description"]) + "；影响：" + M(item["impact"]) +
                     "；补充建议：" + M(item["recommendation"]))
    for item in document["pending_todos"]:
        lines.append("- " + M(item["uid"]) + "：" + M(item["description"]) + "（关联 " + M(item["issue_uid"]) + "）")
    if not document["pending"]:
        lines.append("无。")
    return "\n".join(lines) + "\n"


def attachments(review):
    previous = review / "inputs/attachments.json"
    return load(previous) if previous.is_file() else []


def approved_documents(review):
    files = {}
    for i, item in enumerate(attachments(review)):
        if item.get("kind") == SUP:
            name = "{:03d}".format(i)
            files["approved-supplements/" + name + ".md"] = (review / "attachments" / (name + ".md")).read_text(encoding="utf-8")
            for suffix in ("-proposal.json", "-approval.json"):
                path = "approved-supplements/" + name + suffix
                files[path] = (review / "inputs" / path).read_bytes()
    return files


def check_supplement_manifest(records, prior_root, prior_state):
    prior = [item for item in attachments(prior_root) if item.get("kind") == SUP] if prior_root else []
    current = [item for item in records if item.get("kind") == SUP]
    require(all(item in current for item in prior), "APPROVED_SUPPLEMENT_CANNOT_BE_DROPPED")
    require(len({item.get("path") for item in current}) == len(current), "SUPPLEMENT_ATTACHMENT_DUPLICATE")
    for item in current:
        if item not in prior:
            require(prior_state and all(item.get(k) == v for k, v in binding(prior_root, prior_state).items()),
                    "SUPPLEMENT_ATTACHMENT_REQUIRES_BOUND_PREVIOUS_STATE")
        require(Path(item["path"]).suffix.lower() == ".md" and all(nonempty(item.get(k)) for k in
                ("sha256", "proposal_path", "proposal_sha256", "approval_path", "approval_sha256")),
                "SUPPLEMENT_ATTACHMENT_DIGEST_REQUIRED")


def supplement_markdown(proposal, signed):
    lines = ["# 已确认补充与修改记录", "", "审查版本：" + M(proposal["review_uid"]),
             "", "确认：" + M(signed["actor"]) + " · " + M(signed["confirmed_at"]) + " · " + M(signed["user_quote"]),
             "", "提案摘要：" + M(signed["proposal_sha256"]),
             "", "纳入下一版审查的补充附件。需复核矛盾、影响范围及关闭证据。"]
    for row in proposal["items"]:
        lines += ["", "## " + M(row["uid"]) + " · " + SECTIONS[row["section"]], "",
                  "- 修改位置：" + M(row["target"]), "- 操作：" + M(row["operation"]),
                  "- 用户提供：" + M(row["source_quote"]), "- 确认写入：" + M(row["proposed_text"]),
                  "- 影响：" + M(row["impact"]), "- 关联问题：" + M("、".join(row["issue_refs"]) or "无")]
    return "\n".join(lines) + "\n"


def verify_supplement_files(item, doc, proposal_file, approval_file, prior_state):
    require(all(digest(path) == item[key] for path, key in ((doc, "sha256"), (proposal_file, "proposal_sha256"),
                (approval_file, "approval_sha256"))), "APPROVED_SUPPLEMENT_CHANGED: " + item["path"])
    proposal, signed = read_proposal(proposal_file.read_bytes()), load(approval_file)
    bound = {k: item[k] for k in ("review_uid", "review_state_sha256")}
    require(isinstance(proposal, dict) and set(proposal) == set(bound) | {"items"} and
            all(proposal[k] == v for k, v in bound.items()), "SUPPLEMENT_WRONG_REVIEW")
    require(isinstance(signed, dict) and signed.get("kind") == "approve_taskbook_supplement" and
            signed.get("proposal_sha256") == item["proposal_sha256"] and
            all(signed.get(k) == v for k, v in bound.items()) and
            all(nonempty(signed.get(k)) for k in ("actor", "user_quote", "confirmed_at")),
            "SUPPLEMENT_ATTACHMENT_APPROVAL_INVALID")
    if signed["review_uid"] == prior_state["review_uid"]:
        approval(signed, "approve_taskbook_supplement", dict(bound, proposal_sha256=item["proposal_sha256"]), prior_state)
    validate_supplement_items(proposal["items"], prior_state)
    require(doc.read_text(encoding="utf-8") == supplement_markdown(proposal, signed), "SUPPLEMENT_ATTACHMENT_CONTENT_MISMATCH")


def publish_directory(output, review, writer):
    output = Path(output).resolve()
    require(not output.exists() and review not in output.parents and output not in review.parents,
            "DRAFT_OUTPUT_REQUIRES_NEW_SEPARATE_DIRECTORY")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".task-validation-", dir=str(output.parent)) as temp:
        staging = Path(temp) / "snapshot"
        staging.mkdir()
        writer(staging, output)
        os.rename(str(staging), str(output))
    return str(output)


def architecture(review, model, output, decision=None):
    review, state = context(review)
    decision = load(decision) if decision else None
    eligibility = gate(review, state, decision)
    require(not eligibility["blockers"], "ARCHITECTURE_BLOCKED: " + str(eligibility["blockers"]))
    candidate = load(model)
    bound = binding(review, state)
    require(isinstance(candidate, dict) and set(candidate) == set(bound) | {"views"} and
            all(candidate[k] == v for k, v in bound.items()), "ARCHITECTURE_WRONG_REVIEW")
    validate_views(candidate["views"], state, review)
    document = {"contract": ARCH, **candidate, "status": "PROVISIONAL", "pending": eligibility["pending"],
                "pending_todos": eligibility["pending_todos"], "deferral_approval": decision}

    def write(root, _):
        save(root / "architecture_handoff.json", document)
        text(root / "初版架构.md", architecture_markdown(document))
        for path, content in approved_documents(review).items():
            if isinstance(content, bytes):
                (root / path).parent.mkdir(parents=True, exist_ok=True)
                (root / path).write_bytes(content)
            else:
                text(root / path, content)
    return {"output": publish_directory(output, review, write), "status": "PROVISIONAL",
            "pending_issue_uids": [p["uid"] for p in document["pending"]]}


def verify_architecture(review, draft):
    review, state = context(review)
    draft = Path(draft)
    filename = "architecture_handoff.json"
    raw = (draft / filename).read_text(encoding="utf-8")
    document = load(draft / filename)
    bound = binding(review, state)
    require(isinstance(document, dict) and set(document) == set(bound) | {
            "contract", "status", "views", "pending", "pending_todos", "deferral_approval"} and
            document["contract"] == ARCH and document["status"] == "PROVISIONAL" and
            all(document[k] == v for k, v in bound.items()), "ARCHITECTURE_WRONG_REVIEW")
    eligibility = gate(review, state, document["deferral_approval"])
    require(not eligibility["blockers"] and document["pending"] == eligibility["pending"] and
            document["pending_todos"] == eligibility["pending_todos"], "ARCHITECTURE_PENDING_MISMATCH")
    validate_views(document["views"], state, review)
    files = {"初版架构.md": architecture_markdown(document), **approved_documents(review)}
    for path, expected in files.items():
        actual = (draft / path).read_bytes() if isinstance(expected, bytes) else (draft / path).read_text(encoding="utf-8")
        require(actual == expected, "ARCHITECTURE_ARTIFACT_MISMATCH: " + path)
    return {filename: raw, **files}


def read_proposal(raw):
    from .contract import object_pairs, reject_constant
    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=object_pairs, parse_constant=reject_constant)


def validate_supplement_items(items, state):
    require(isinstance(items, list) and items, "SUPPLEMENT_ITEMS_REQUIRED")
    issue_uids = {i["uid"] for i in state["record"]["issues"]}
    seen = set()
    for row in items:
        require(isinstance(row, dict) and set(row) == {"uid", "section", "target", "operation", "source_quote",
                "proposed_text", "impact", "issue_refs"} and
                all(nonempty(row[k]) for k in ("uid", "target", "source_quote", "proposed_text", "impact")) and
                isinstance(row["section"], str) and row["section"] in SECTIONS and row["operation"] in ("add", "clarify", "replace"),
                "SUPPLEMENT_ITEM_INVALID")
        require(row["uid"] not in seen, "SUPPLEMENT_DUPLICATE_UID")
        seen.add(row["uid"])
        require(isinstance(row["issue_refs"], list) and all(nonempty(i) and i in issue_uids for i in row["issue_refs"]),
                "SUPPLEMENT_UNKNOWN_ISSUE")
    return sorted(seen)


def supplement(review, proposal_path, confirmation, output):
    review, state = context(review)
    # Parse and hash the same byte snapshot so approval cannot attach to different content.
    import hashlib
    raw = Path(proposal_path).read_bytes()
    proposal = read_proposal(raw)
    bound = binding(review, state)
    require(isinstance(proposal, dict) and set(proposal) == set(bound) | {"items"} and
            all(proposal[k] == v for k, v in bound.items()), "SUPPLEMENT_WRONG_REVIEW")
    signed = load(confirmation)
    approval(signed, "approve_taskbook_supplement",
             dict(bound, proposal_sha256=hashlib.sha256(raw).hexdigest()), state)
    seen = validate_supplement_items(proposal["items"], state)
    approved = {"contract": SUP, **proposal, "approval": signed, "status": "APPROVED_FOR_REVIEW"}
    def write(root, final):
        name = "补充与修改记录.md"
        text(root / name, supplement_markdown(proposal, signed))
        (root / "proposal.json").write_bytes(raw)
        save(root / "approval.json", signed)
        save(root / "supplement.json", approved)
        prior = attachments(review)
        save(root / "attachments.json", prior + [{"path": str(final / name), "description": "经用户确认的补充与修改记录",
                                                  "kind": SUP, **bound, "sha256": digest(root / name),
                                                  "proposal_path": str(final / "proposal.json"), "proposal_sha256": digest(root / "proposal.json"),
                                                  "approval_path": str(final / "approval.json"), "approval_sha256": digest(root / "approval.json")}])
    return {"output": publish_directory(output, review, write), "status": approved["status"],
            "previous_state": str(review / "review_state.json"), "supplement_uids": seen}
