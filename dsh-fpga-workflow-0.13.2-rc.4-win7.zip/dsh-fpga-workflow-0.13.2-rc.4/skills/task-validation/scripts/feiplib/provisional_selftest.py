"""Exercise approval, evidence, and publication boundaries with fictional inputs."""
import copy
import zipfile
from pathlib import Path

from .base import Failure, digest, load, now, save, text
from .prepare import prepare
from .provisional import VIEWS, architecture, status, supplement, verify_architecture
from .review_selftest import synthetic_confirmation, synthetic_record
from .review_stage import authorize, review, verify_review


def candidate(result, element, pending=None):
    return {
        "review_uid": result["review_uid"], "review_state_sha256": result["review_state_sha256"],
        "views": {view: [{"description": "测试：上游 → FPGA → 下游；参数以已审输入为准",
                          "basis": "proposed", "evidence_refs": [element], "pending_refs": pending or []}]
                  for view in VIEWS}}


def tests(root):
    root.mkdir()
    source = root / "任务书.txt"
    text(source, "1 数据链路\nFPGA接收上游数据并发送给下游。\n")
    model, approval_file, proposal_file = (root / n for n in ("model.json", "approval.json", "proposal.json"))
    results = []

    def rejects(name, error, call):
        try:
            call()
        except Failure as exc:
            assert error in str(exc), str(exc)
        else:
            raise AssertionError("unexpected acceptance: " + name)
        results.append(name)

    def publish(name, change, previous=None, attachment=None):
        prepared = prepare("taskbook", root / (name + "-work"), source, previous_state=previous, attachments=attachment)
        record = synthetic_record(prepared)
        change(record, Path(prepared["attempt"]))
        save(model, record)
        directory = root / name
        result = review(prepared["attempt"], model, directory)
        return directory, result, record

    def issues(record, _, contradiction=False, todo_status="deferred", missing_status="deferred"):
        ref = record["reviewed_element_refs"][-1]
        issue = {"uid": "issue:width", "category": "missing_information", "status": missing_status,
                 "description": "数据位宽尚未给出", "impact": "暂不能确定端口位宽", "recommendation": "补充接口位宽",
                 "severity": "warning", "blocking": True, "evidence_refs": [ref]}
        record["issues"] = [issue]
        record["todos"] = [{"uid": "todo:width", "issue_uid": "issue:width", "status": todo_status,
                            "description": "核实位宽", "evidence_refs": [ref]}]
        record["checks"][10].update(status="unknown", issue_refs=["issue:width"])
        if contradiction:
            record["issues"].append(dict(issue, uid="issue:conflict", category="contradiction", description="两个来源冲突"))
            record["checks"][18].update(status="fail", issue_refs=["issue:conflict"])

    def grant(result, **overrides):
        decision = {"kind": "approve_architecture_deferral", "review_uid": result["review_uid"],
                    "review_state_sha256": result["review_state_sha256"], "issue_uids": ["issue:width"],
                    "todo_uids": ["todo:width"], "actor": "虚构测试用户", "confirmed_at": now(),
                    "user_quote": "虚构批准：暂缓位宽问题和核实待办。"}
        decision.update(overrides)
        save(approval_file, decision)
        return decision

    review_dir, outcome, record = publish("missing", issues)
    element = record["reviewed_element_refs"][-1]
    old_hash = digest(review_dir / "review_state.json")
    assert status(review_dir)["status"] == "ARCHITECTURE_BLOCKED"
    results.append("unapproved-missing-and-deferred-todo-still-block-draft")
    grant(outcome, todo_uids=[])
    assert status(review_dir, approval_file)["blockers"] == [{"type": "todo", "uid": "todo:width"}]
    results.append("approving-issue-does-not-implicitly-approve-todo")

    for name, kwargs, code in (
            ("wrong-review", {"review_uid": "review:other"}, "APPROVAL_WRONG_KIND_OR_REVIEW"),
            ("wrong-review-bytes", {"review_state_sha256": "0" * 64}, "APPROVAL_WRONG_KIND_OR_REVIEW"),
            ("wrong-kind", {"kind": "approve_skill_test_structuring"}, "APPROVAL_WRONG_KIND_OR_REVIEW"),
            ("empty-quote", {"user_quote": " "}, "APPROVAL_EVIDENCE_REQUIRED"),
            ("early-approval", {"confirmed_at": "2000-01-01T00:00:00+00:00"}, "APPROVAL_MUST_FOLLOW_REVIEW"),
            ("invalid-time", {"confirmed_at": "yesterday"}, "APPROVAL_TIME_INVALID"),
            ("unspecified-scope", {"issue_uids": []}, "DEFERRAL_REQUIRES_EXACT_ISSUE_UIDS"),
            ("duplicate-scope", {"issue_uids": ["issue:width", "issue:width"]}, "DEFERRAL_REQUIRES_EXACT_ISSUE_UIDS"),
            ("unknown-issue", {"issue_uids": ["issue:unknown"]}, "DEFERRAL_ONLY_FOR_CURRENT_MISSING_INFORMATION"),
            ("unknown-todo", {"todo_uids": ["todo:unknown"]}, "DEFERRAL_TODO_SCOPE_INVALID")):
        grant(outcome, **kwargs)
        rejects("draft-rejects-" + name, code, lambda: status(review_dir, approval_file))

    draft = root / "draft"
    grant(outcome)
    value = candidate(outcome, element, ["issue:width"])
    save(model, value)
    architecture(review_dir, model, draft, approval_file)
    files = verify_architecture(review_dir, draft)
    assert "todo:width" in files["初版架构.md"] and "issue:width" in files["初版架构.md"]
    assert digest(review_dir / "review_state.json") == old_hash and not (draft / "package.json").exists()
    results.append("approved-specified-gap-publishes-four-views-without-altering-review")
    open_gap, open_outcome, open_record = publish("open-gap", lambda r, p: issues(r, p, missing_status="open"))
    assert status(open_gap)["deferral_candidates"] == open_record["issues"]
    grant(open_outcome)
    ready = status(open_gap, approval_file)
    assert ready["status"] == "ARCHITECTURE_READY" and ready["pending"][0]["uid"] == "issue:width"
    open_draft = root / "open-gap-draft"
    save(model, candidate(open_outcome, open_record["reviewed_element_refs"][-1], ["issue:width"]))
    architecture(open_gap, model, open_draft, approval_file)
    assert "issue:width" in verify_architecture(open_gap, open_draft)["初版架构.md"]
    assert verify_review(open_gap)["state"] == "REVIEWING"
    assert verify_review(open_gap)["record"]["issues"][0]["status"] == "open"
    results.append("approved-open-missing-information-does-not-block-draft-or-close-the-review")
    grant(outcome)
    save(model, value)
    rejects("deferral-cannot-release-feip", "STRUCTURE_REQUIRES_ALL_ISSUES_CLOSED",
            lambda: authorize(review_dir, approval_file, source))
    rejects("draft-cannot-overwrite-existing-snapshot", "DRAFT_OUTPUT_REQUIRES_NEW_SEPARATE_DIRECTORY",
            lambda: architecture(review_dir, model, draft, approval_file))
    for name, transform, code in (
            ("missing-view", lambda v: v["views"].pop("data_flow"), "ARCHITECTURE_FOUR_VIEWS_REQUIRED"),
            ("empty-view", lambda v: v["views"].update(data_flow=[]), "ARCHITECTURE_VIEW_EMPTY"),
            ("made-up-evidence", lambda v: v["views"]["data_flow"][0].update(evidence_refs=["element:fake"]), "ARCHITECTURE_REFERENCE_INVALID"),
            ("made-up-pending", lambda v: v["views"]["data_flow"][0].update(pending_refs=["issue:fake"]), "ARCHITECTURE_REFERENCE_INVALID"),
            ("unknown-without-gap", lambda v: v["views"]["data_flow"][0].update(basis="unknown", pending_refs=[]), "ARCHITECTURE_BASIS_REQUIRED"),
            ("source-asserts-unknown", lambda v: v["views"]["data_flow"][0].update(basis="source"), "ARCHITECTURE_BASIS_REQUIRED")):
        changed = copy.deepcopy(value)
        transform(changed)
        save(model, changed)
        destination = root / ("bad-" + name)
        rejects("architecture-rejects-" + name, code, lambda: architecture(review_dir, model, destination, approval_file))
        assert not destination.exists()
    text(draft / "初版架构.md", "被改写")
    rejects("published-draft-detects-rendered-document-tampering", "ARCHITECTURE_ARTIFACT_MISMATCH",
            lambda: verify_architecture(review_dir, draft))

    conflict, conflict_result, _ = publish("conflict", lambda r, p: issues(r, p, contradiction=True))
    grant(conflict_result, issue_uids=["issue:width", "issue:conflict"])
    rejects("deferral-rejects-contradiction-in-approved-list", "DEFERRAL_ONLY_FOR_CURRENT_MISSING_INFORMATION",
            lambda: status(conflict, approval_file))
    grant(conflict_result)
    assert {x["uid"] for x in status(conflict, approval_file)["blockers"]} == {"issue:conflict", "CON-001"}
    results.append("unresolved-contradiction-blocks-even-with-valid-gap-approval")
    open_todo, open_result, _ = publish("open-todo", lambda r, p: issues(r, p, todo_status="open"))
    grant(open_result)
    rejects("open-work-cannot-be-approved-as-deferred", "DEFERRAL_TODO_SCOPE_INVALID", lambda: status(open_todo, approval_file))

    def unresolved(r, p):
        issues(r, p)
        r["extraction_checks"][1].update(status="unresolved", rationale="测试：未读取二进制附件")

    binary, manifest = root / "unread.png", root / "unread.json"
    binary.write_bytes(b"synthetic unread attachment")
    save(manifest, [{"path": str(binary)}])
    unread, unread_result, _ = publish("unread", unresolved, attachment=manifest)
    grant(unread_result)
    assert {b["type"] for b in status(unread, approval_file)["blockers"]} == {"extraction"}
    results.append("unread-attachment-cannot-be-deferred-as-missing-information")

    proposal = {"review_uid": outcome["review_uid"], "review_state_sha256": outcome["review_state_sha256"],
                "items": [{"uid": "sup:width", "section": "interfaces", "target": "1 数据链路 / 输入",
                           "operation": "clarify", "source_quote": "虚构：输入是16位。", "proposed_text": "输入位宽为16位。",
                           "impact": "接收模块和接口验收", "issue_refs": ["issue:width"]}]}
    save(proposal_file, proposal)
    signed = grant(outcome, kind="approve_taskbook_supplement", proposal_sha256=digest(proposal_file))
    changed = copy.deepcopy(proposal)
    changed["items"][0]["proposed_text"] = "输入位宽为32位。"
    save(proposal_file, changed)
    supplement_dir = root / "supplement"
    rejects("editing-approved-proposal-requires-reconfirmation", "APPROVAL_WRONG_KIND_OR_REVIEW",
            lambda: supplement(review_dir, proposal_file, approval_file, supplement_dir))
    save(proposal_file, proposal)
    rejects("supplement-approval-cannot-be-reused-on-another-review", "SUPPLEMENT_WRONG_REVIEW",
            lambda: supplement(conflict, proposal_file, approval_file, supplement_dir))
    changed["items"].append(copy.deepcopy(changed["items"][0]))
    save(proposal_file, changed)
    save(approval_file, dict(signed, proposal_sha256=digest(proposal_file)))
    rejects("supplement-rejects-duplicate-change-ids", "SUPPLEMENT_DUPLICATE_UID",
            lambda: supplement(review_dir, proposal_file, approval_file, supplement_dir))
    assert not supplement_dir.exists()
    save(proposal_file, proposal)
    save(approval_file, signed)
    supplement(review_dir, proposal_file, approval_file, supplement_dir)
    supplement_doc = supplement_dir / "补充与修改记录.md"
    supplement_bytes = supplement_doc.read_bytes()
    assert "输入位宽为16位" in supplement_bytes.decode("utf-8")
    assert verify_review(review_dir)["state"] == "REVIEWING" and digest(review_dir / "review_state.json") == old_hash
    results.append("approved-supplement-preserves-published-review-and-produces-evidence")
    text(supplement_doc, "替换为未经批准的另一项要求。")
    rejects("review-rejects-edited-approved-supplement-document", "APPROVED_SUPPLEMENT_CHANGED",
            lambda: prepare("taskbook", root / "modified-supplement", source,
                            previous_state=review_dir / "review_state.json", attachments=supplement_dir / "attachments.json"))
    supplement_doc.write_bytes(supplement_bytes)
    rejects("review-rejects-claimed-approved-supplement-without-parent", "SUPPLEMENT_ATTACHMENT_REQUIRES_BOUND_PREVIOUS_STATE",
            lambda: prepare("taskbook", root / "orphan-supplement", source, attachments=supplement_dir / "attachments.json"))

    def close(r, p):
        attachment = load(p / "structures/archive-001.json")
        found = next(e["uid"] for e in attachment["elements"] if "输入位宽为16位" in e["text"])
        for row in r["issues"] + r["todos"]:
            row.update(evidence_refs=r["reviewed_element_refs"][:1], status="closed",
                       closure_reason="自测：核对了确认补充", closure_evidence_refs=[found])

    revised, revision, revised_record = publish("revised", close, previous=review_dir / "review_state.json",
                                               attachment=supplement_dir / "attachments.json")
    assert revision["state"] == "AWAITING_STRUCTURE_CONFIRMATION"
    grant(outcome)
    rejects("revision-invalidates-old-deferral", "APPROVAL_WRONG_KIND_OR_REVIEW", lambda: status(revised, approval_file))
    save(model, candidate(revision, revised_record["reviewed_element_refs"][-1]))
    new_draft = root / "revised-draft"
    architecture(revised, model, new_draft)
    files = verify_architecture(revised, new_draft)
    assert "输入位宽为16位" in files["approved-supplements/000.md"]
    assert files["approved-supplements/000-proposal.json"] == proposal_file.read_bytes()
    assert load(new_draft / "approved-supplements/000-approval.json") == signed
    save(approval_file, synthetic_confirmation(revision))
    authorize(revised, approval_file, source, supplement_dir / "attachments.json")
    results.append("re-reviewed-supplement-enters-versioned-handoff-and-allows-real-closure")
    save(manifest, [])
    rejects("later-revision-cannot-drop-confirmed-supplement", "APPROVED_SUPPLEMENT_CANNOT_BE_DROPPED",
            lambda: prepare("taskbook", root / "drop-supplement", source,
                            previous_state=revised / "review_state.json", attachments=manifest))
    inherited = prepare("taskbook", root / "inherit-supplement", source, previous_state=revised / "review_state.json")
    assert (Path(inherited["attempt"]) / "attachments/000.md").read_bytes() == supplement_bytes
    results.append("later-review-inherits-confirmed-supplement-when-manifest-is-omitted")

    # A readable transcript needs an explicit link to the exact partial source element.
    docx, transcript = root / "field.docx", root / "field.txt"
    with zipfile.ZipFile(str(docx), "w") as container:
        container.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:fldSimple w:instr="DOCPROPERTY X"><w:r><w:t>old</w:t></w:r></w:fldSimple></w:p><w:p><w:fldSimple w:instr="DOCPROPERTY Y"><w:r><w:t>other</w:t></w:r></w:fldSimple></w:p></w:body></w:document>')
    text(transcript, "虚构逐项核验：X为32位，Y为16位。\n")
    save(manifest, [{"path": str(transcript), "role": "transcription"}])
    prep = prepare("taskbook", root / "partial-work", docx, attachments=manifest)
    partial = synthetic_record(prep)
    targets, ref = partial["reviewed_element_refs"][:2], partial["reviewed_element_refs"][-1]
    partial["extraction_checks"][0].update(status="verified_transcription", rationale="虚构：逐项对应两个字段",
                                         evidence_refs=[ref], transcription_map=[{"target_ref": targets[0], "evidence_refs": [ref]}])
    save(model, partial)
    rejects("one-of-two-partial-elements-cannot-clear-extraction", "REVIEW_TRANSCRIPTION_MUST_COVER_EACH_TARGET",
            lambda: review(prep["attempt"], model, root / "incomplete-transcription"))
    partial["extraction_checks"][0]["transcription_map"].append({"target_ref": targets[1], "evidence_refs": [ref]})
    save(model, partial)
    partial_review = root / "transcribed-field"
    out = review(prep["attempt"], model, partial_review)
    design = candidate(out, targets[0])
    design["views"]["data_flow"][0].update(basis="source")
    save(model, design)
    rejects("architecture-cannot-cite-partial-source-alone", "ARCHITECTURE_PARTIAL_SOURCE_REQUIRES_MATCHED_TRANSCRIPTION",
            lambda: architecture(partial_review, model, root / "bare-source-draft"))
    design["views"]["data_flow"][0]["evidence_refs"].append(ref)
    save(model, design)
    architecture(partial_review, model, root / "matched-source-draft")
    results.append("architecture-accepts-partial-source-with-its-verified-transcription")
    return results
