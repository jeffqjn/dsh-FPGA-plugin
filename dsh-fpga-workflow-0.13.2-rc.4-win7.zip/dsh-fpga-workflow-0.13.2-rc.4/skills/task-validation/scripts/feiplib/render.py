"""Deterministic Markdown assembly from the frozen canonical model."""
from .base import SKILL, load, require

def display(value):
    if value is None:
        return "待确认"
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, list):
        return "；".join(display(x) for x in value)
    if isinstance(value, dict):
        if "status" in value and "value" in value:
            return display(value["value"]) if value["status"] == "present" else "待确认（" + (value["reason"] or value["status"]) + "）"
        if value.get("kind") == "quantity":
            return value["decimal"] + " " + value["unit"]
        if value.get("kind") == "interval":
            return ("[" if value["lower_inclusive"] else "(") + display(value["lower"]) + ", " + display(value["upper"]) + ("]" if value["upper_inclusive"] else ")")
        if value.get("kind") == "bitvector":
            return "{0}'base{1}:{2}".format(value["width"], value["radix"], value["literal"])
        if value.get("kind") == "enumeration":
            return display(value["members"])
        if "text" in value:
            return value["text"]
        return value.get("name", value.get("uid", "已结构化记录"))
    return str(value)

def escape(value):
    return display(value).replace("|", "\\|").replace("\r", "").replace("\n", "<br>")

def flatten(model):
    found = {}
    def visit(value):
        if isinstance(value, dict):
            # Typed references are links, never authoritative objects. Headers are
            # indexed through their owner so signal/clock fields remain available.
            if set(value) == {"kind", "uid", "revision_uid"}:
                return
            if "uid" in value:
                found[value["uid"]] = value
            if "header" in value:
                found[value["header"]["uid"]] = value
            for key, item in value.items():
                if key not in ("header", "before", "after", "raw_snapshots", "payload"):
                    visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
    visit(model)
    return found

def requirement_text(req, registry):
    if req["effective_revision_uid"] is None:
        return []
    sem = next(r["semantic"] for r in req["revisions"] if r["uid"] == req["effective_revision_uid"])
    lines = ["", "**{0} {1}**".format(req["normalized_id"] or "待确认编号", req["title"]), "", sem["statement"]]
    if sem["safety_critical"]:
        lines += ["", "本功能属于安全关键功能（本条原子需求为安全关键要求）。" if req["category"] == "function" else "本条原子需求属于安全关键要求。"]
    if sem["condition"]:
        lines += ["", "适用条件：" + sem["condition"]["text"]]
    for label, values in (("输入", sem["input_refs"]), ("输出", sem["output_refs"])):
        if values:
            lines += ["", label + "：" + "、".join(v["uid"] for v in values)]
    for item in sem["processing_rules"]:
        lines += ["", "处理：" + item]
    for constraint_uid in sem["constraint_refs"]:
        c = registry[constraint_uid]
        lines += ["", "约束：" + c["raw_text"] + ("；条件：" + c["when"]["text"] if c["when"] else "")]
    for exception in sem["exceptions"]:
        lines += ["", "异常处理：" + exception]
    return lines

def render(model):
    views = [v for v in model["document_views"] if v["role"] == "writer_plan"]
    require(len(views) == 1, "WRITER_PLAN_REQUIRED: exactly one writer_plan")
    plan = views[0]
    template = load(SKILL / "templates/document_structure.json")
    numbers = [s["number"] for s in plan["sections"]]
    require(len(numbers) == len(set(numbers)), "DUPLICATE_SECTION_NUMBER")
    require(set(template["required_sections"]).issubset(numbers), "MISSING_TEMPLATE_SECTION")
    order = [numbers.index(n) for n in template["required_sections"]]
    require(order == sorted(order), "SECTION_ORDER_INVALID")
    registry = flatten(model)
    reqs = {r["uid"]: r for r in model["requirements"]}
    primary = []
    lines = ["# " + model["meta"]["title"], "", "生成状态：" + str(model["consistency"]["gates"]["generation_state"]), ""]
    for section in plan["sections"]:
        number = section["number"]
        expected = "deferred" if number == "7" or number.startswith("7.") else "manual" if number in ("10", "11", "C", "D") else "auto"
        require(section["handling"] == expected, "SECTION_HANDLING_INVALID: " + number)
        if number in template["titles"]:
            require(section["title"] == template["titles"][number], "TEMPLATE_TITLE_CHANGED: " + number)
        for item in (t for t in template["tables"] if t["section"] == number):
            require(any(t["caption"] == item["caption"] and t["columns"] == item["columns"] for t in section["tables"]), "TEMPLATE_TABLE_MISSING_OR_CHANGED: " + item["id"])
        section_title = section["title"]
        if number.startswith("5.3."):
            for req_uid in section["primary_requirement_refs"] + section["cross_requirement_refs"]:
                req = reqs[req_uid]
                if req["effective_revision_uid"] and any(v["uid"] == req["effective_revision_uid"] and v["semantic"]["safety_critical"] is True for v in req["revisions"]):
                    section_title = section_title.rstrip("★") + "★"
                    break
        lines += ["#" * min(number.count(".") + 2, 6) + " " + number + " " + section_title, ""]
        if expected in ("deferred", "manual"):
            require(not section["paragraphs"] and not section["primary_requirement_refs"], "DEFERRED_MANUAL_CONTENT_NOT_EMPTY")
            lines += ["本阶段暂缓，保留结构。" if expected == "deferred" else "人工填写。", ""]
        else:
            lines += section["paragraphs"] + [""]
            if section["status"] in ("missing", "unknown"):
                lines += ["待确认：" + (section["reason"] or "来源未明确"), ""]
            for req_uid in section["primary_requirement_refs"]:
                primary.append(req_uid)
                require(req_uid in reqs, "UNKNOWN_PRIMARY_REQUIREMENT")
                lines += requirement_text(reqs[req_uid], registry)
            for req_uid in section["cross_requirement_refs"]:
                lines += ["参见需求 " + (reqs[req_uid]["normalized_id"] or req_uid) + "。", ""]
        for table in section["tables"]:
            lines += [table["caption"], "", "| " + " | ".join(escape(c) for c in table["columns"]) + " |", "| " + " | ".join("---" for _ in table["columns"]) + " |"]
            require(not table["row_object_refs"] or expected == "auto", "MANUAL_TABLE_MUST_BE_EMPTY")
            if table["row_object_refs"]:
                # Structured rows are emitted as supplementary detail, not guessed column associations.
                # Agent supplies no duplicate engineering values; references remain authoritative.
                for index, row in enumerate(table["row_object_refs"]):
                    obj = registry[row["uid"]]
                    values = table_row(obj, index + 1, table["columns"], reqs)
                    lines.append("| " + " | ".join(escape(v) for v in values) + " |")
            lines += [""]
        if number in ("A.1", "A.2"):
            lines += ["| 工程需求 | 源父ID | 源原子ID | 规格说明编号 | 文档落实 | 属性 |", "| --- | --- | --- | --- | --- | --- |"]
            atoms = {a["uid"]: a["source_id"] for a in model["source_baseline"]["atomic_requirements"]}
            parents = {p["uid"]: p["source_id"] for p in model["source_baseline"]["parents"]}
            for req in model["requirements"]:
                attributes = next((v["semantic"]["attributes"] for v in req["revisions"] if v["uid"] == req["effective_revision_uid"]), [])
                lines += ["| " + " | ".join(escape(v) for v in (req["title"], [parents[p] for p in req["source_parent_refs"]], [atoms[a] for a in req["source_atomic_refs"]], req["normalized_id"], req["effective_alignment"], "".join(attributes))) + " |"]
            lines += [""]
        if number in ("8.1", "8.2"):
            for req in model["requirements"]:
                if req["category"] == "function" and any(v["uid"] == req["effective_revision_uid"] and v["semantic"]["safety_critical"] is True for v in req["revisions"]):
                    lines += ["- 安全关键功能：{0} {1}；设计/测试要求参见该需求及已有来源材料。".format(req["normalized_id"], req["title"])]
            lines += [""]
    require(len(primary) == len(set(primary)), "REQUIREMENT_DEFINED_MULTIPLE_TIMES")
    included = {r["uid"] for r in model["requirements"] if r["lifecycle"] == "active"}
    deferred = set()
    for section in plan["sections"]:
        if section["handling"] in ("deferred", "manual"):
            deferred.update(section["cross_requirement_refs"])
    require(included == set(primary) | deferred, "WRITER_REQUIREMENT_OMISSION: every active requirement needs a main placement or explicit deferred/manual reference")
    return "\n".join(lines) + "\n"

def table_row(obj, index, columns, requirements):
    name = obj.get("header", {}).get("name", obj.get("title", obj.get("name", "")))
    semantic = next((r["semantic"] for r in obj.get("revisions", []) if r["uid"] == obj.get("effective_revision_uid")), {})
    values = {"序号": index, "信号名称": name, "信号标识": obj.get("header", {}).get("uid", ""), "信号方向": obj.get("direction"),
        "信号位宽": obj.get("width"), "管脚分配": [p["pin"] for p in obj.get("pins", [])], "电平标准": obj.get("io_standard"),
        "初始化状态": obj.get("default_value"), "备注": obj.get("header", {}).get("reason"), "器件名称": name,
        "器件型号": obj.get("model"), "个数": obj.get("count"), "功能概述": obj.get("responsibilities", []),
        "需求标识": obj.get("normalized_id"), "描述": semantic.get("statement", obj.get("title")), "需求名称": obj.get("title"),
        "信号定义": name,
        "文件编号": obj.get("identifier"), "文件名称": obj.get("title"), "版本": obj.get("version"),
        "时钟域名称": name, "时钟频率/频率": obj.get("frequency"), "和其它时钟关系": [r["kind"] for r in obj.get("relations", [])],
        "IP模块": name, "类型": obj.get("kind"), "功能": name, "参数": [p["name"] + ":" + display(p["value"] or p["text"]) for p in obj.get("parameters", [])],
        "版本号": obj.get("version"), "关键数据名称": name, "重点关注": obj.get("validity_rules", [])}
    require(all(c in values for c in columns), "TABLE_SELECTOR_NOT_SUPPORTED: leave empty and use sourced paragraphs for columns " + str([c for c in columns if c not in values]))
    return [values[c] for c in columns]
