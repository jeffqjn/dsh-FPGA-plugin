"""Readable Markdown for lightweight review records; JSON remains in review_state."""
import html
from pathlib import Path

from .base import load


def markdown(value):
    value = html.escape(str(value), quote=False)
    for char in ("\\", "`", "*", "_", "[", "]", "|"):
        value = value.replace(char, "\\" + char)
    return "<br>".join(value.splitlines())


def render(record, state, info, root):
    locations = {}
    kinds = {"heading": "标题", "paragraph": "段落", "table": "表格", "figure": "图", "attachment": "嵌入对象或附件"}
    for index, path in enumerate(info["archives"]):
        archive = load(Path(root) / path)
        sections = {s["uid"]: " ".join(filter(None, (s["number"], s["title"]))) for s in archive["sections"]}
        source = "任务书 " + Path(info["source_path"]).name if index == 0 else "附件 " + str(index)
        for element in archive["elements"]:
            section = sections.get(element["section_uid"], "未归入章节")
            location = "{0} / {1} / {2} / 结构元素序号 {3} / {4} / {5}".format(
                source, section, kinds.get(element["kind"], element["kind"]), element["order"] + 1,
                element["part"], element["uid"])
            excerpt = element["text"]
            if len(excerpt) > 240:
                excerpt = excerpt[:240] + "…（节选）"
            locations[element["uid"]] = markdown(location) + ("；原文：“" + markdown(excerpt) + "”" if excerpt else "")

    def evidence(refs):
        return "<br>".join(locations[ref] for ref in refs)

    statuses = {"deferred": "待定（仍未闭环）", "open": "未闭环", "closed": "已闭环", "pass": "通过", "fail": "不通过",
                "unknown": "待明确", "not_applicable": "不适用"}
    issues, todos = record["issues"], record["todos"]
    label = "审查中，仍需闭环" if state == "REVIEWING" else "全部闭环，等待用户确认交接范围"
    lines = ["# 任务书审查与问题闭环报告", "", "- 状态：" + label + "（" + state + "）",
             "- 摘要：" + markdown(record["summary"]),
             "- 问题：{0} 项未闭环，{1} 项已闭环。".format(
                 sum(i["status"] != "closed" for i in issues), sum(i["status"] == "closed" for i in issues)),
             "- 待办：{0} 项未闭环，{1} 项已闭环。".format(
                 sum(t["status"] != "closed" for t in todos), sum(t["status"] == "closed" for t in todos)), "",
             "本轮仅审查与闭环，尚未生成结构化任务书。", ""]
    from .review_updates import report_overview
    lines += report_overview(record, info, root) + ["## 问题清单", ""]
    if not issues:
        lines += ["本轮未登记问题。", ""]
    ordered = sorted(issues, key=lambda i: (i["status"] == "closed", not i["blocking"],
                                          {"error": 0, "warning": 1, "info": 2}[i["severity"]]))
    for issue in ordered:
        rules = [c["rule_id"] for c in record["checks"] if issue["uid"] in c["issue_refs"]]
        lines += ["### " + markdown(issue["uid"]), "", "- 状态：" + statuses[issue["status"]],
                  "- 分类：" + {"missing_information": "缺少信息", "contradiction": "源资料矛盾",
                                "unread_evidence": "证据未读", "other": "其他"}[issue.get("category", "other")],
                  "- 严重程度：" + {"error": "错误", "warning": "警告", "info": "提示"}[issue["severity"]],
                  "- 正式交付阻断标记：" + ("是" if issue["blocking"] else "否（仍须闭环后才可正式结构化）"),
                  "- 问题描述：" + markdown(issue["description"]),
                  "- 描述修订：" + str(issue.get("description_rev", 1)),
                  "- 精确位置：" + markdown(issue.get("location", "未补充；参见下列源证据")),
                  "- 关联规则：" + ("、".join(markdown(r) for r in rules) or "无"),
                  "- 原文位置及证据：" + evidence(issue["evidence_refs"]),
                  "- 影响：" + markdown(issue["impact"]), "- 修改建议：" + markdown(issue["recommendation"])]
        if issue.get("evidence_locations"):
            from .review_updates import location_lines
            lines += location_lines(issue, root)
        if issue.get("description_history"):
            lines += ["- 历史描述：" + markdown("；".join(str(h["description_rev"]) + ": " + h["description"] for h in issue["description_history"]))]
        if issue["status"] == "closed":
            lines += ["- 关闭依据：" + markdown(issue["closure_reason"]),
                      "- 关闭证据：" + evidence(issue["closure_evidence_refs"])]
        lines += [""]
    lines += ["## 待办清单", ""]
    if not todos:
        lines += ["本轮无待办事项。", ""]
    for todo in sorted(todos, key=lambda t: t["status"] == "closed"):
        lines += ["### " + markdown(todo["uid"]), "", "- 状态：" + statuses[todo["status"]],
                  "- 关联问题：" + markdown(todo["issue_uid"]), "- 待办内容：" + markdown(todo["description"]),
                  "- 原文位置及证据：" + evidence(todo["evidence_refs"])]
        if todo["status"] == "closed":
            lines += ["- 关闭依据：" + markdown(todo["closure_reason"]),
                      "- 关闭证据：" + evidence(todo["closure_evidence_refs"])]
        lines += [""]
    lines += ["## 抽取限制与核验", ""]
    extraction = {c["archive_uid"]: c for c in record["extraction_checks"]}
    for path in info["archives"]:
        archive = load(Path(root) / path)
        check = extraction[archive["uid"]]
        partial_count = sum(e["read_status"] != "complete" for e in archive["elements"])
        lines += ["- " + markdown(archive["uid"]) + "：" + markdown(check["status"]) +
                  "；受限元素 " + str(partial_count) + "；" + markdown(check["rationale"])]
        lines += ["  - " + markdown(limitation) for limitation in archive["limitations"]]
    lines += [""]
    lines += ["## 规则检查", "", "| 规则 | 状态 | 判断依据 | 关联问题 | 证据元素 |",
              "| --- | --- | --- | --- | --- |"]
    for check in record["checks"]:
        values = (check["rule_id"], statuses[check["status"]], check["rationale"],
                  "、".join(check["issue_refs"]) or "无", "、".join(check["evidence_refs"]))
        lines += ["| " + " | ".join(markdown(v) for v in values) + " |"]
    if state == "AWAITING_STRUCTURE_CONFIRMATION":
        lines += ["", "所有已登记问题和待办均已闭环。收到交接包生成请求后，请用户确认本版有无其他未明确项，再开始生成。"]
    return "\n".join(lines) + "\n"
