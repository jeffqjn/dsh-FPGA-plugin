"""Lightweight taskbook review and version-bound user confirmation for FEIP modeling."""
import copy
import json
import shutil
from pathlib import Path

from .base import SKILL, VERSION, digest, load, now, require, save, text, uid, verify_inputs
from .extract import extract

CONTRACT = "taskbook-review/1.0"
ISSUE_CATEGORIES = ("missing_information", "contradiction", "unread_evidence", "other")
RULES = (["STR-{0:03d}".format(i) for i in range(1, 11)] +
         ["REQ-{0:03d}".format(i) for i in range(1, 9)] +
         ["CON-{0:03d}".format(i) for i in range(1, 7)] +
         ["TST-{0:03d}".format(i) for i in range(1, 7)])


def policy_binding():
    paths = [SKILL / "SKILL.md"] + list((SKILL / "references").rglob("*.md")) + list((SKILL / "scripts").rglob("*.py"))
    paths += list((SKILL / "references/protocol/schemas").rglob("*.json")) + list((SKILL / "templates").glob("*.json"))
    return {p.relative_to(SKILL).as_posix(): digest(p) for p in paths}


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def architecture_deferral_candidate(issue):
    return issue["status"] != "closed" and issue.get("category") == "missing_information"


def extraction_targets(archive):
    return ([archive["uid"]] if archive["limitations"] or archive["extraction_status"] == "not_read" else []) + [
        e["uid"] for e in archive["elements"] if e["read_status"] != "complete"]


def prepare_review(source, output, attachments=None, previous_state=None, chunk_chars=4000, incremental_global=False):
    source = Path(source).resolve()
    from .provisional import SUP, attachments as prior_attachments, check_supplement_manifest, verify_supplement_files
    prior, prior_root = None, None
    if previous_state:
        previous_state = Path(previous_state).resolve()
        require(previous_state.name == "review_state.json", "PREVIOUS_STATE_MUST_NAME_PUBLISHED_REVIEW_STATE")
        prior_root = previous_state.parent
        prior = verify_review(prior_root, check_originals=False)
        if not attachments and any(r.get("kind") == SUP for r in prior_attachments(prior_root)):
            attachments = prior_root / "inputs/attachments.json"
    attempt = Path(output).resolve() / "attempts" / uid("review").split(":")[1]
    attempt.mkdir(parents=True, exist_ok=False)
    info = {"contract": CONTRACT, "kind": "taskbook-review", "review_version": VERSION, "run_uid": uid("run"), "created_at": now(),
            "artifacts": [], "input_bindings": [], "original_inputs": [], "source_path": str(source), "policy_binding": policy_binding()}

    def freeze(path, relative):
        path = Path(path).resolve()
        dest = attempt / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(str(path), str(dest))
        info["input_bindings"].append({"path": relative, "sha256": digest(dest)})
        info["original_inputs"].append({"path": str(path), "sha256": digest(path)})
        return dest

    sources = [(source, "sources/current" + source.suffix.lower())]
    info["incremental_global"] = bool(incremental_global)
    info["attachment_roles"] = {}
    records = []
    if attachments:
        records = load(freeze(attachments, "inputs/attachments.json"))
        require(isinstance(records, list) and all(isinstance(r, dict) and nonempty(r.get("path")) for r in records),
                "ATTACHMENTS_MANIFEST_EXPECTED_ARRAY")
        for i, r in enumerate(records):
            require(r.get("role", "attachment") in ("attachment", "transcription"), "ATTACHMENT_ROLE_INVALID: index=" + str(i))
            info["attachment_roles"][str(i+1)] = r.get("role", "attachment")
        sources += [(Path(r["path"]).resolve(), "attachments/{0:03d}{1}".format(i, Path(r["path"]).suffix.lower())) for i, r in enumerate(records)]
    check_supplement_manifest(records, prior_root, prior)
    archives, reading = [], []
    for index, (path, relative) in enumerate(sources):
        frozen = freeze(path, relative)
        if index and records[index - 1].get("kind") == SUP:
            row = records[index - 1]
            prefix = "inputs/approved-supplements/{:03d}".format(index - 1)
            proposal_file = freeze(row["proposal_path"], prefix + "-proposal.json")
            approval_file = freeze(row["approval_path"], prefix + "-approval.json")
            verify_supplement_files(row, frozen, proposal_file, approval_file, prior)
        if frozen.suffix.lower() in (".docx", ".txt", ".md"):
            archive = extract(frozen, "taskbook" if index == 0 else "attachment", "artifact:review-" + str(index))
        else:
            archive = {"uid": "archive:binary-" + str(index), "extraction_status": "not_read", "sections": [],
                       "elements": [], "limitations": ["binary attachment requires verified transcription"]}
        archive_path = "structures/archive-{0:03d}.json".format(index)
        save(attempt / archive_path, archive)
        info["input_bindings"].append({"path": archive_path, "sha256": digest(attempt / archive_path)})
        archives.append(archive_path)
        reading += ["# " + relative, "Extraction: " + archive["extraction_status"], "Limitations: " + json.dumps(archive["limitations"], ensure_ascii=False)]
        for element in archive["elements"]:
            reading += ["", "[{0}] {1}; section={2}; part={3}; read={4}".format(element["uid"], element["kind"], element["section_uid"], element["part"], element["read_status"]), element["text"]]
            if element["cells"]:
                reading.append("Cells: " + json.dumps(element["cells"], ensure_ascii=False, separators=(",", ":")))
            if element["limitations"]:
                reading.append("Limitations: " + json.dumps(element["limitations"], ensure_ascii=False))
    info["archives"] = archives
    info["source_bindings"] = copy.deepcopy(info["original_inputs"])
    if previous_state:
        freeze(previous_state, "inputs/previous_state.json")
    record = {"contract": CONTRACT, "run_uid": info["run_uid"], "summary": "", "reviewed_element_refs": [],
              "checks": [{"rule_id": r, "status": "unknown", "rationale": "", "evidence_refs": [], "issue_refs": []} for r in RULES],
              "extraction_checks": [{"archive_uid": load(attempt / p)["uid"], "status": "unresolved", "rationale": "", "evidence_refs": []} for p in archives],
              "issues": copy.deepcopy(prior["record"]["issues"]) if prior else [],
              "todos": copy.deepcopy(prior["record"]["todos"]) if prior else []}
    text(attempt / "review_source.txt", "\n".join(reading) + "\n")
    info["input_bindings"].append({"path": "review_source.txt", "sha256": digest(attempt / "review_source.txt")})
    save(attempt / "attempt.json", info)
    save(attempt / "review.template.json", record)
    from .batches import initialize
    progress = initialize(attempt, info, chunk_chars, previous_state)
    from .batches import next_task
    first = next_task(attempt)
    return {"attempt": str(attempt), "delta_template": first.get("delta_template"), "template": first.get("template"), "reading": first.get("reading"),
            "batch_progress": progress, "next": "review-next --attempt <attempt>; read one packet, submit and resume; do not read the full archive/model"}


def check_record(record, info, root):
    require(record.get("contract") == CONTRACT and record.get("run_uid") == info["run_uid"], "LIGHTWEIGHT_REVIEW_REQUIRED")
    require(set(record) == {"contract", "run_uid", "summary", "reviewed_element_refs", "checks", "extraction_checks", "issues", "todos"}, "REVIEW_FIELDS_INVALID")
    require(nonempty(record["summary"]), "REVIEW_SUMMARY_REQUIRED")
    archives = [load(Path(root) / p) for p in info["archives"]]
    elements = {e["uid"]: e for a in archives for e in a["elements"]}

    def evidence(refs):
        require(isinstance(refs, list) and bool(refs) and all(isinstance(r, str) and r in elements for r in refs), "REVIEW_EVIDENCE_REQUIRED")

    reviewed = record["reviewed_element_refs"]
    require(len(reviewed) == len(set(reviewed)) and set(reviewed) == set(elements), "REVIEW_SOURCE_ELEMENTS_NOT_FULLY_REVIEWED")
    issues, todos = record["issues"], record["todos"]
    for items in (issues, todos):
        require(isinstance(items, list) and len({i["uid"] for i in items}) == len(items), "REVIEW_IDS_INVALID")
        for item in items:
            require(nonempty(item["uid"]) and item["status"] in ("open", "closed", "deferred") and nonempty(item["description"]), "REVIEW_ITEM_INVALID")
            evidence(item["evidence_refs"])
            if item["status"] == "closed":
                require(nonempty(item.get("closure_reason")), "REVIEW_CLOSURE_REASON_REQUIRED")
                evidence(item.get("closure_evidence_refs"))
    issue_ids = {i["uid"] for i in issues}
    open_ids = {i["uid"] for i in issues if i["status"] != "closed"}
    for issue in issues:
        require(issue.get("category", "other") in ISSUE_CATEGORIES, "REVIEW_ISSUE_CATEGORY_INVALID")
        require(issue["severity"] in ("error", "warning", "info") and isinstance(issue["blocking"], bool), "REVIEW_ISSUE_SEVERITY_INVALID")
        require(nonempty(issue.get("impact")) and nonempty(issue.get("recommendation")), "REVIEW_ISSUE_DETAILS_REQUIRED")
    for todo in todos:
        require(todo.get("issue_uid") in issue_ids, "REVIEW_TODO_ISSUE_INVALID")
    checks = record["checks"]
    require(len(checks) == len(RULES) and {c["rule_id"] for c in checks} == set(RULES), "REVIEW_RULES_INCOMPLETE")
    for check in checks:
        require(check["status"] in ("pass", "fail", "unknown", "not_applicable") and nonempty(check["rationale"]), "REVIEW_RULE_JUDGMENT_REQUIRED")
        evidence(check["evidence_refs"])
        require(isinstance(check["issue_refs"], list) and set(check["issue_refs"]) <= issue_ids, "REVIEW_RULE_ISSUE_INVALID")
        if check["status"] in ("fail", "unknown"):
            require(bool(set(check["issue_refs"]) & open_ids), "REVIEW_FAILED_RULE_REQUIRES_OPEN_ISSUE: " + check["rule_id"])
    extraction = record["extraction_checks"]
    require(len(extraction) == len(archives) and {c["archive_uid"] for c in extraction} == {a["uid"] for a in archives}, "REVIEW_EXTRACTION_CHECKS_INCOMPLETE: expected_archive_uids=" + str([a["uid"] for a in archives]) + "; actual_archive_uids=" + str([c["archive_uid"] for c in extraction]))
    for archive in archives:
        check = next(c for c in extraction if c["archive_uid"] == archive["uid"])
        require(nonempty(check["rationale"]), "REVIEW_EXTRACTION_RATIONALE_REQUIRED")
        if archive["extraction_status"] == "complete":
            require(check["status"] == "complete", "REVIEW_EXTRACTION_STATUS_INVALID")
        elif check["status"] == "verified_transcription":
            evidence(check["evidence_refs"])
            current = info.get("review_version") is not None
            other = {e["uid"] for i, a in enumerate(archives)
                     if a["uid"] != archive["uid"] and a["extraction_status"] == "complete" and
                     (not current or info["attachment_roles"].get(str(i)) == "transcription") for e in a["elements"]}
            require(set(check["evidence_refs"]) <= other, "REVIEW_TRANSCRIPT_MUST_REFERENCE_READABLE_ATTACHMENT")
            if current:
                mapped = check.get("transcription_map")
                require(isinstance(mapped, list) and all(isinstance(x, dict) and set(x) == {"target_ref", "evidence_refs"}
                        and nonempty(x["target_ref"]) and isinstance(x["evidence_refs"], list) and x["evidence_refs"]
                        and all(nonempty(r) and r in other for r in x["evidence_refs"]) for x in mapped),
                        "REVIEW_TRANSCRIPTION_MAP_INVALID")
                require(len(mapped) == len(extraction_targets(archive)) and
                        {x["target_ref"] for x in mapped} == set(extraction_targets(archive)),
                        "REVIEW_TRANSCRIPTION_MUST_COVER_EACH_TARGET")
                require(set(check["evidence_refs"]) == {r for x in mapped for r in x["evidence_refs"]},
                        "REVIEW_TRANSCRIPTION_EVIDENCE_MISMATCH")
        else:
            require(check["status"] == "unresolved" and open_ids, "REVIEW_UNREAD_INPUT_REQUIRES_OPEN_ISSUE")
    previous = Path(root) / "inputs/previous_state.json"
    if previous.exists():
        old = load(previous)["record"]
        for name in ("issues", "todos"):
            current = {i["uid"]: i for i in record[name]}
            for item in old[name]:
                require(item["uid"] in current, "REVIEW_PREVIOUS_ITEM_DROPPED")
                from .review_updates import reconcile
                reconcile(item, current[item["uid"]])
    closed = (not open_ids and all(t["status"] == "closed" for t in todos) and
              all(c["status"] in ("pass", "not_applicable") for c in checks) and
              all(c["status"] != "unresolved" for c in extraction))
    return "AWAITING_STRUCTURE_CONFIRMATION" if closed else "REVIEWING"


def review(attempt, filename, output):
    attempt, output = Path(attempt), Path(output).resolve()
    if filename is None:
        from .batches import assemble
        filename = assemble(attempt)
    info = verify_inputs(attempt)
    require(info.get("kind") == "taskbook-review", "LIGHTWEIGHT_REVIEW_ATTEMPT_REQUIRED")
    require(info["policy_binding"] == policy_binding(), "REVIEW_POLICY_CHANGED: prepare again")
    record = load(filename)
    state = check_record(record, info, attempt)
    require(not output.exists() and output != attempt.resolve() and attempt.resolve() not in output.parents, "REVIEW_OUTPUT_MUST_BE_NEW_AND_OUTSIDE_ATTEMPT")
    require(not (attempt / "inputs/agent_review.json").exists(), "ATTEMPT_ALREADY_CONSUMED: prepare again")
    save(attempt / "inputs/agent_review.json", record)
    # A review directory is diagnostic data, never a FEIP/downstream package.
    shutil.copytree(str(attempt), str(output))
    from .review_report import render
    text(output / "taskbook_review.md", render(record, state, info, output))
    bindings = [{"path": p.relative_to(output).as_posix(), "sha256": digest(p)} for p in output.rglob("*") if p.is_file()]
    result = {"contract": CONTRACT, "review_uid": uid("review"), "created_at": now(), "state": state, "record": record,
              "bindings": bindings, "source_path": info["source_path"], "source_bindings": info["source_bindings"], "policy_binding": info["policy_binding"]}
    save(output / "review_state.json", result)
    return {"output": str(output), "state": state, "review_uid": result["review_uid"], "review_state_sha256": digest(output / "review_state.json")}


def verify_review(directory, check_originals=True):
    from . import contract
    directory = Path(directory)
    result = load(directory / "review_state.json")
    require(result["contract"] == CONTRACT, "REVIEW_CONTRACT_INVALID")
    for binding in result["bindings"]:
        path = contract.safe_artifact(directory, binding["path"])
        require(path.is_file() and digest(path) == binding["sha256"], "REVIEW_ARTIFACT_CHANGED")
    info = load(directory / "attempt.json")
    require(result["record"] == load(directory / "inputs/agent_review.json"), "REVIEW_RECORD_CHANGED")
    require(result["policy_binding"] == info["policy_binding"] and result["source_bindings"] == info["source_bindings"], "REVIEW_BINDING_CHANGED")
    require(result["source_path"] == info["source_path"], "REVIEW_SOURCE_BINDING_CHANGED")
    require(result["state"] == check_record(result["record"], info, directory), "REVIEW_STATE_INVALID")
    if check_originals:
        require(result["policy_binding"] == policy_binding(), "REVIEW_POLICY_CHANGED: review again")
        for binding in result["source_bindings"]:
            path = Path(binding["path"])
            require(path.is_file() and digest(path) == binding["sha256"], "REVIEW_SOURCE_CHANGED: review again")
    return result


def authorize(directory, confirmation_file, source, attachments=None, skill_test=False):
    directory = Path(directory).resolve()
    result = verify_review(directory)
    confirmation = load(confirmation_file)
    require(isinstance(confirmation, dict), "STRUCTURE_CONFIRMATION_REQUIRED")
    if skill_test:
        from .skill_test import check_authorization
        check_authorization(confirmation)
    else:
        require(result["state"] == "AWAITING_STRUCTURE_CONFIRMATION", "STRUCTURE_REQUIRES_ALL_ISSUES_CLOSED")
        require(confirmation.get("kind") == "approve_taskbook_structuring", "STRUCTURE_CONFIRMATION_REQUIRED")
    require(confirmation.get("review_uid") == result["review_uid"] and confirmation.get("review_state_sha256") == digest(directory / "review_state.json"), "STRUCTURE_CONFIRMATION_WRONG_REVIEW")
    require(all(nonempty(confirmation.get(k)) for k in ("actor", "confirmed_at", "request_quote", "user_quote")),
            "STRUCTURE_CONFIRMATION_EVIDENCE_REQUIRED")
    require(confirmation.get("review_items_confirmed") is True, "STRUCTURE_REVIEW_ITEMS_CONFIRMATION_REQUIRED")
    require(confirmation["request_quote"].strip() != confirmation["user_quote"].strip(),
            "STRUCTURE_SEPARATE_USER_CONFIRMATION_REQUIRED")
    from datetime import datetime
    try:
        value = confirmation["confirmed_at"]
        confirmed = datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)
        created = datetime.fromisoformat(result["created_at"])
    except (ValueError, TypeError):
        raise ValueError("STRUCTURE_CONFIRMATION_TIME_INVALID")
    require(confirmed.utcoffset() is not None, "STRUCTURE_CONFIRMATION_TIME_INVALID")
    require(confirmed >= created, "STRUCTURE_CONFIRMATION_MUST_FOLLOW_REVIEW")
    require(str(Path(source).resolve()) == result["source_path"], "STRUCTURE_SOURCE_MISMATCH")
    # The frozen attachment manifest, when present, is part of the reviewed version.
    frozen_manifest = directory / "inputs/attachments.json"
    require(bool(attachments) == frozen_manifest.exists(), "STRUCTURE_ATTACHMENTS_MISMATCH")
    if attachments:
        require(digest(attachments) == digest(frozen_manifest), "STRUCTURE_ATTACHMENTS_MISMATCH")
    return result


def verify_structure_attempt(attempt):
    attempt = Path(attempt)
    require((attempt / "inputs/structure_confirmation.json").is_file(), "STRUCTURE_CONFIRMATION_REQUIRED")
    info = load(attempt / "attempt.json")
    source = info["original_inputs"][0]["path"]
    attachments = attempt / "inputs/attachments.json"
    return authorize(attempt / "closed_review", attempt / "inputs/structure_confirmation.json", source,
                     attachments if attachments.exists() else None, skill_test=info.get("skill_test") is True)
