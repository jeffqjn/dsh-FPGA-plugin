"""Behavioral regressions for the MD-driven independent review fork."""
import copy
import os
import zipfile
from pathlib import Path
from . import batches
from .base import digest, load, save, text
from .prepare import prepare
from .review_stage import review, verify_review
from .review_updates import doctor, reopen


def run_tests(root):
    root.mkdir()
    result = []
    def rejected(label, function, code):
        try:
            function()
        except (ValueError, KeyError, OSError) as exc:
            assert code in str(exc), (label, str(exc))
            result.append(label)
        else:
            raise AssertionError(label + " unexpectedly accepted")
    source = root / "source.docx"
    xml = '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>说明：复位接口</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>信号</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>要求</w:t></w:r></w:p></w:tc></w:tr><w:tr><w:tc><w:p><w:r><w:t>CMD_RST</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>脉宽待定</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>'
    with zipfile.ZipFile(str(source), "w") as archive:
        archive.writestr("word/document.xml", xml)
        archive.writestr("word/styles.xml", '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:styleId="Heading1"><w:name w:val="Heading 1"/></w:style></w:styles>')
        archive.writestr("word/media/test.emf", b"fictional-media-only-not-renderable")
    prep = prepare("taskbook", root / "work", source)
    attempt = Path(prep["attempt"])
    task = batches.next_task(attempt)
    delta = load(task["delta_template"])
    assert "reviewed_unit_refs" not in delta and not delta["reviewed"]
    result.append("delta-template-omits-mechanical-unit-arrays-and-requires-explicit-reviewed-assertion")
    manifest = load(attempt / "review-work/manifest.json")
    unit = next(u for u in manifest["units"] if u["kind"] == "table" and u["row"] == 1)
    delta["reviewed"] = True
    item = {"uid": "issue:R1-001", "description": "复位脉宽待定", "status": "deferred", "severity": "warning", "blocking": False,
            "evidence_refs": [unit["element_uid"]], "impact": "尚不能形成测试判据", "recommendation": "明确源值", "location": "复位接口表第2行",
            "evidence_locations": [{"unit_uid": unit["alias"], "row": 1}]}
    delta["changes"] = {"summary": "虚构已逐行检查，待定项保持未闭环", "issues": [item], "todos": []}
    file = root / "fragment.json"
    unreviewed = copy.deepcopy(delta);unreviewed["reviewed"] = False
    save(root / "bad.json", unreviewed)
    rejected("delta-without-reading-assertion-rejected", lambda: batches.submit(attempt, root / "bad.json"), "REVIEW_DELTA_REQUIRES_EXPLICIT_REVIEW_ASSERTION")
    save(file, delta)
    response = batches.submit(attempt, file)
    assert any(p["row"] == 1 and "CMD_RST" in p["text"] for p in response["evidence_preview"])
    result.append("delta-submit-preserves-full-checkpoint-and-echoes-exact-table-row")
    bad = copy.deepcopy(delta);bad["basis_sha256"] = "0" * 64;save(root / "bad.json", bad)
    rejected("stale-delta-rejected-without-rebinding-current-task", lambda: batches.submit(attempt, root / "bad.json"), "REVIEW_DELTA_STALE")
    bad = copy.deepcopy(delta);bad["changes"]["issues"][0]["evidence_locations"][0]["row"] = 999;save(root / "bad.json", bad)
    rejected("wrong-table-row-location-rejected", lambda: batches.submit(attempt, root / "bad.json"), "REVIEW_LOCATION_ROW_MISMATCH")
    bad = copy.deepcopy(delta)
    other = next(u for u in manifest["units"] if u["element_uid"] != unit["element_uid"])
    bad["changes"]["issues"][0]["evidence_locations"] = [{"unit_uid": other["uid"]}]
    save(root / "bad.json", bad)
    rejected("valid-but-unrelated-element-location-rejected", lambda: batches.submit(attempt, root / "bad.json"), "REVIEW_LOCATION_EVIDENCE_MISMATCH")
    bad = copy.deepcopy(delta);bad["changes"]["issues"][0]["description"] = "新描述";save(root / "bad.json", bad)
    rejected("description-change-without-explicit-revision-rejected", lambda: batches.submit(attempt, root / "bad.json"), "DESCRIPTION_REV_REQUIRED")
    delta["changes"]["issues"][0].update(description="复位脉宽已知待方案明确", description_rev=2)
    save(file, delta);batches.submit(attempt, file)
    current = load(attempt / "review-work/checkpoints" / batches.filename(delta["task_uid"]))["payload"]["issues"][0]
    assert current["description_history"][0]["description"] == "复位脉宽待定"
    result.append("description-revision-preserves-original-wording-and-stable-uid")
    while not batches.status(attempt)["complete"]:
        task = batches.next_task(attempt)
        d = load(task["delta_template"]);d["reviewed"] = True
        d["changes"]["summary"] = "虚构已完成当前检查，待定问题保留"
        for check in d["changes"].get("checks", []):
            check.update(status="pass", rationale="虚构确定性测试预设", evidence_refs=[unit["element_uid"]], issue_refs=[])
        for check in d["changes"].get("extraction_checks", []):
            check.update(status="complete", rationale="虚构DOCX文本完整")
        save(file, d);batches.submit(attempt, file)
    output = root / "review1"
    published = review(attempt, None, output)
    assert published["state"] == "REVIEWING"
    report = (output / "taskbook_review.md").read_text(encoding="utf-8")
    assert "其中待定" in report and "本轮关闭" in report and "CMD_RST" in report.replace(chr(92), "") and "第 2 行" in report
    result.append("deferred-remains-unclosed-and-report-shows-summary-diff-and-exact-row")
    rejected("deferred-review-cannot-start-normal-structuring", lambda: prepare("taskbook", root / "illegal-structure", source, closed_review=output, confirmation=file), "STRUCTURE_REQUIRES_ALL_ISSUES_CLOSED")
    before = digest(output / "inputs/agent_review.json")
    recovered = root / "recovered"
    reopen(output, recovered)
    assert digest(output / "inputs/agent_review.json") == before and not (recovered / "inputs/agent_review.json").exists()
    assert batches.status(recovered)["complete"]
    result.append("published-review-recovery-forks-checkpoints-without-mutating-original")
    task = batches.next_task(recovered, delta["task_uid"])
    d = load(task["delta_template"]);d["reviewed"] = True
    d["changes"]["summary"] = "虚构复核已补齐"
    d["changes"]["issues"][0].update(status="closed", closure_reason="虚构源修订已经核验", closure_evidence_refs=[unit["element_uid"]])
    save(file, d);changed = batches.submit(recovered, file)
    assert set(changed["invalidates"]) == {"global:" + g for g in batches.GROUPS}
    assert set(changed["progress"]["stale_tasks"]) == set(changed["invalidates"])
    result.append("local-correction-explicitly-reports-four-invalidated-global-tasks")
    save(file, d);same = batches.submit(recovered, file)
    assert same["unchanged"] and same["invalidates"] == []
    result.append("identical-review-resubmit-does-not-invalidate-globals")
    from .batch_selftest import finish_review
    finish_review(recovered, root)
    second = root / "review2"
    review(recovered, None, second)
    verify_review(second)
    renewed = prepare("taskbook", root / "reuse", source, previous_state=second / "review_state.json", incremental_global=True)
    assert batches.status(renewed["attempt"])["global_done"] == 4
    result.append("explicit-incremental-global-reuses-only-completely-unchanged-source-and-dependencies")
    normal = prepare("taskbook", root / "default-reuse", source, previous_state=second / "review_state.json")
    assert batches.status(normal["attempt"])["global_done"] == 0
    result.append("global-reuse-is-off-by-default")
    with zipfile.ZipFile(str(source), "w") as archive:
        archive.writestr("word/document.xml", xml.replace("脉宽待定", "脉宽改为200ms"))
        archive.writestr("word/styles.xml", '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:styleId="Heading1"><w:name w:val="Heading 1"/></w:style></w:styles>')
        archive.writestr("word/media/test.emf", b"fictional-media-only-not-renderable")
    modified = prepare("taskbook", root / "changed", source, previous_state=second / "review_state.json", incremental_global=True)
    current_manifest = load(Path(modified["attempt"]) / "review-work/manifest.json")
    assert batches.status(modified["attempt"])["global_done"] == 0
    assert current_manifest["prior_owners"]["issue:R1-001"] in {c["uid"] for c in current_manifest["chunks"]}
    result += ["source-change-never-reuses-old-global-conclusions", "changed-local-packet-recovers-issue-owner-from-source-identity-instead-of-quality-fallback"]
    transcript = root / "transcript.md"
    text(transcript, "# 1 插图A\n说明A。\n# 2 插图B\n说明B。\n")
    attachments = root / "attachments.json"
    save(attachments, [{"path": str(transcript), "role": "transcription"}])
    attached = prepare("taskbook", root / "attached", source, attachments=attachments)
    m = load(Path(attached["attempt"]) / "review-work/manifest.json")
    groups = [c for c in m["chunks"] if c["archive_slot"] == 1]
    assert len(groups) == 1 and groups[0]["transcription_evidence_task"]
    assert len(groups[0]["unit_refs"]) == len([u for u in m["units"] if u["archive_slot"] == 1])
    result.append("small-transcription-attachment-has-one-evidence-task-with-no-source-unit-loss")
    from .media import extract_media
    extracted = extract_media(source, root / "media")
    assets = load(extracted["manifest"])["assets"]
    assert len(assets) == 1 and assets[0]["transcription_status"] == "not_performed"
    assert (root / "media" / assets[0]["path"]).read_bytes() == b"fictional-media-only-not-renderable"
    result.append("media-extraction-retains-byte-identity-and-does-not-claim-render-or-transcription")
    assert doctor(root)["write_test"] == "passed" and not list(root.glob(".feip-write-probe-*"))
    result.append("doctor-tests-output-write-and-cleans-probe")
    old_env = os.environ.get("FPGA_PYTHON38")
    try:
        os.environ["FPGA_PYTHON38"] = str(root / "wrong-python.exe")
        rejected("doctor-rejects-mismatched-configured-interpreter", lambda: doctor(root), "DOCTOR_INTERPRETER_ENV_MISMATCH")
    finally:
        if old_env is None:
            os.environ.pop("FPGA_PYTHON38", None)
        else:
            os.environ["FPGA_PYTHON38"] = old_env
    return result
