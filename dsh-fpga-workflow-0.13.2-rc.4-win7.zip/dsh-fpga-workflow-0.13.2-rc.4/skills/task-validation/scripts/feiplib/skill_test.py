"""Opt-in, version-bound simulation of review closure for downstream skill tests."""
import copy
import re
from pathlib import Path

from . import contract
from .base import SCHEMAS, digest, load, require, save, uid

NAMESPACE = "feip.skill-test.v1"
NOTICE = "仅供skill功能测试：问题为模拟闭环，原任务书问题未实际解决，不能作为正式工程输入。"


def check_authorization(value):
    require(value.get("kind") == "approve_skill_test_structuring" and value.get("test_only") is True
            and value.get("simulate_closure") is True, "SKILL_TEST_EXPLICIT_AUTHORIZATION_REQUIRED")
    quote = value.get("request_quote", "")
    require(isinstance(quote, str), "SKILL_TEST_USER_DECLARATION_REQUIRED")
    normalized = re.sub(r"\s+", "", quote).lower()
    require(any(s in normalized for s in ("对skill进行测试", "进行skill测试", "测试skill功能")),
            "SKILL_TEST_USER_DECLARATION_REQUIRED: user must explicitly declare skill testing")
    require(not re.search(r"(?:不要|禁止|不允许|并非|不是|不能|无需|无须|不)(?:再|现在|是|在|要|对|需要|准备|打算|进行|做|开展)*(?:skill(?:进行)?测试|测试skill功能)", normalized),
            "SKILL_TEST_NEGATED_DECLARATION")
    require(not any(s in normalized for s in ("是否", "能否", "要不要", "如果", "假如")), "SKILL_TEST_DECLARATION_NOT_AFFIRMATIVE")


def marker(model):
    rows = [e for e in model["extensions"] if e["namespace"] == NAMESPACE]
    require(len(rows) == 1, "SKILL_TEST_MARKER_REQUIRED")
    return rows[0]


def initialize(attempt, info, model, remember):
    attempt = Path(attempt)
    review = load(attempt / "closed_review/review_state.json")
    authorization = load(attempt / "inputs/structure_confirmation.json")
    check_authorization(authorization)
    schema_uid = uid("artifact")
    remember(SCHEMAS / "skill-test.schema.json", "schemas/skill-test.schema.json", schema_uid)
    review_artifact = uid("artifact")
    info["artifacts"].append({"uid": review_artifact, "path": "closed_review/review_state.json"})
    payload = {"test_only": True, "notice": NOTICE, "review_uid": review["review_uid"],
               "review_state_sha256": digest(attempt / "closed_review/review_state.json"),
               "source_review_artifact_uid": review_artifact, "authorization": authorization,
               "real_review_state": review["state"], "source_issues": copy.deepcopy(review["record"]["issues"]),
               "source_todos": copy.deepcopy(review["record"]["todos"]),
               "source_checks": copy.deepcopy(review["record"]["checks"]),
               "extraction_checks": copy.deepcopy(review["record"]["extraction_checks"]), "model_before_simulation": None}
    model["protocol"]["synthetic"] = True
    model["extensions"].append({"namespace": NAMESPACE, "schema_artifact_uid": schema_uid, "critical": False, "payload": payload})
    evidence = {e["element_uid"]: e["uid"] for e in model["consistency"]["evidence"]}
    issue_ids = {}
    for issue in review["record"]["issues"]:
        identity = "issue:skill-test-" + contract.fingerprint(issue["uid"])[:20]
        issue_ids[issue["uid"]] = identity
        refs = [evidence[r] for r in issue["evidence_refs"] if r in evidence]
        rules = [c["rule_id"] for c in review["record"]["checks"] if issue["uid"] in c["issue_refs"]]
        model["consistency"]["issues"].append({"uid": identity, "display_id": issue["uid"], "stable_key": "skill-test|" + issue["uid"],
            "rule_id": rules[0] if rules else "SKILL-TEST", "type": "SKILL_TEST_SIMULATED_CLOSURE", "severity": issue["severity"],
            "blocking": issue["blocking"], "resolution_required": True, "waivable": False, "object_refs": [], "field_paths": [],
            "basis_refs": refs, "current_refs": refs, "summary": "【skill测试模拟闭环】" + issue["description"], "impact": issue["impact"],
            "suggestion": issue["recommendation"], "status": "resolved", "first_seen_round": 1, "last_seen_round": 1,
            "evidence_fingerprint": contract.fingerprint(issue["evidence_refs"]), "history": [], "decision_refs": []})
    for todo in review["record"]["todos"]:
        model["consistency"]["todos"].append({"uid": "todo:skill-test-" + contract.fingerprint(todo["uid"])[:20], "kind": "supplement",
            "description": "【skill测试模拟闭环】" + todo["description"], "issue_refs": [issue_ids[todo["issue_uid"]]], "notice_refs": [],
            "required": True, "status": "closed", "decision_refs": [], "completion_evidence_refs": []})


def verify_marker(model, attempt):
    from .review_stage import verify_structure_attempt
    verify_structure_attempt(attempt)
    info = load(Path(attempt) / "attempt.json")
    require(info.get("skill_test") is True and model["protocol"]["synthetic"] is True, "SKILL_TEST_MARKER_REQUIRED")
    actual = marker(model)
    expected = marker(load(Path(attempt) / "model.template.json"))
    require({k: v for k, v in actual.items() if k != "payload"} == {k: v for k, v in expected.items() if k != "payload"},
            "SKILL_TEST_MARKER_CHANGED")
    require({k: v for k, v in actual["payload"].items() if k != "model_before_simulation"} ==
            {k: v for k, v in expected["payload"].items() if k != "model_before_simulation"}, "SKILL_TEST_CONTEXT_CHANGED")
    errors = contract.validate_schema(actual["payload"], load(SCHEMAS / "skill-test.schema.json"))
    require(not errors, "SKILL_TEST_CONTEXT_INVALID: " + str(errors[:4]))
    return actual["payload"]


def project_model(model, attempt):
    """Project closure in the test model only; never rewrite the real review record."""
    payload = verify_marker(model, attempt)
    if payload["model_before_simulation"] is None:
        payload["model_before_simulation"] = {"issues": copy.deepcopy(model["consistency"]["issues"]),
            "todos": copy.deepcopy(model["consistency"]["todos"]), "gaps": copy.deepcopy(model["completeness"]["gaps"]),
            "assessments": [copy.deepcopy(e["payload"]) for e in model["extensions"] if e["namespace"] == "feip.assessments.v1"],
            "original_title": model["meta"]["title"], "original_product_name": copy.deepcopy(model["basic_info"]["product_name"]),
            "discoveries": load(Path(attempt) / "model-work/test-discoveries.json") if (Path(attempt) / "model-work/test-discoveries.json").exists() else []}
    # Keep the catalogue byte-compatible with downstream renderers: place the
    # test label in displayed model titles, rather than changing its MD template.
    label = "【仅供skill功能测试】"
    if not model["meta"]["title"].startswith(label):
        model["meta"]["title"] = label + model["meta"]["title"]
    product = model["basic_info"]["product_name"]
    if product["status"] == "present" and isinstance(product["value"], str) and not product["value"].startswith(label):
        product["value"] = label + product["value"]
    for issue in model["consistency"]["issues"]:
        if issue["status"] == "open":
            issue["status"] = "resolved"
            issue["summary"] = "【skill测试模拟闭环】" + issue["summary"]
    for todo in model["consistency"]["todos"]:
        if todo["status"] != "closed":
            todo["status"] = "closed"
            todo["description"] = "【skill测试模拟闭环】" + todo["description"]
    for extension in model["extensions"]:
        if extension["namespace"] == "feip.assessments.v1":
            for row in extension["payload"]["rules"]:
                if row["status"] in ("fail", "unknown"):
                    row.update(status="pass", rationale="【skill测试模拟放行，非实际通过】" + row["rationale"])


def record_discoveries(attempt, payload):
    path = Path(attempt) / "model-work/test-discoveries.json"
    rows = load(path) if path.exists() else []
    row = {"task_uid": payload["task_uid"], "new_issues": copy.deepcopy(payload["new_issues"])}
    if row not in rows:
        rows.append(row)
        save(path, rows)


def banner(model):
    return "> **【仅供skill功能测试】** " + NOTICE + "\n\n" if any(e["namespace"] == NAMESPACE for e in model["extensions"]) else ""


def report(model):
    from .review_report import markdown
    payload = marker(model)["payload"]
    authorization = payload["authorization"]
    lines = ["# skill测试模式说明", "", banner(model).strip(), "", "- 原始审查状态：" + payload["real_review_state"],
             "- 用户测试请求：" + markdown(authorization.get("request_quote", authorization["user_quote"]))]
    if "request_quote" in authorization:
        lines.append("- 用户确认：" + markdown(authorization["user_quote"]))
    lines += ["- 原始审查记录随包保留，由扩展的source_review_artifact_uid定位（原始问题状态保留）。", "",
             "## 原始问题与模拟处理", "", "| 问题 | 原始状态 | 描述 | 测试处理 |", "| --- | --- | --- | --- |"]
    for issue in payload["source_issues"]:
        lines += ["| " + " | ".join(markdown(v) for v in (issue["uid"], issue["status"], issue["description"], "仅在测试模型中模拟闭环")) + " |"]
    lines += ["", "## 原始待办", ""]
    lines += ["- " + markdown(t["uid"] + "（" + t["status"] + "）：" + t["description"]) for t in payload["source_todos"]] or ["无。"]
    lines += ["", "## 建模期间的发现", ""]
    simulation = payload["model_before_simulation"] or {}
    for row in simulation.get("discoveries", []):
        for issue in row["new_issues"]:
            description = issue.get("description", str(issue)) if isinstance(issue, dict) else str(issue)
            lines += ["- " + markdown(description) + "（仅测试模拟放行）"]
    for issue in simulation.get("issues", []):
        if issue["status"] == "open":
            lines += ["- " + markdown(issue["display_id"] + "：" + issue["summary"]) + "（仅测试模拟闭环）"]
    for gap in simulation.get("gaps", []):
        lines += ["- 保留缺口：" + markdown(gap["description"])]
    lines += ["", "完整模拟前记录与原始规则结果保留在model.json的feip.skill-test.v1扩展中。", "",
              "正常使用必须回到原始审查记录，真实关闭全部问题后重新确认并生成；本测试输出不能作为真实闭环依据。", ""]
    return "\n".join(lines)
