"""Agent-assisted taskbook review, Markdown writing and reviewed release."""
import argparse
import copy
import platform
import shutil
import sys
from pathlib import Path

from . import contract
from .base import SKILL, SCHEMAS, check_model, digest, effective, gate, known_artifacts, load, now, publish, require, save, text, uid, verify_inputs, verify_package
from .checks import checker_quality, ensure_frozen, merge_previous, report, revision_checks, source_quality, state
from .extract import extract
from .prepare import prepare
from .render import display, render
from . import icd

KINDS = {"task-validation": "taskbook", "req-spec-gen": "writer", "req-spec-consistency-check": "checker"}

def runtime_fingerprint():
    paths = [p for p in (SKILL / "scripts").rglob("*") if p.suffix in (".py", ".js", ".ps1")] + list(SCHEMAS.rglob("*.json")) + list((SKILL / "templates").glob("*.json")) + list((SKILL / "references").rglob("*.md")) + [SKILL / "SKILL.md"]
    return {p.relative_to(SKILL).as_posix(): digest(p) for p in paths if "__pycache__" not in p.parts}

def accept_model(attempt, filename):
    attempt = Path(attempt)
    info = verify_inputs(attempt)
    model = load(filename)
    if info.get("skill_test") is True:
        from .skill_test import project_model
        project_model(model, attempt)
    # Shape first, so failed Agent output cannot crash a semantic check halfway.
    from .base import schema_model
    schema_model(model)
    ensure_frozen(model, attempt, info)
    revision_checks(model)
    submitted = attempt / "inputs/agent_model.json"
    require(not submitted.exists(), "ATTEMPT_ALREADY_CONSUMED: prepare a fresh attempt")
    submitted.parent.mkdir(exist_ok=True)
    shutil.copyfile(str(filename), str(submitted))
    info["input_bindings"].append({"path": "inputs/agent_model.json", "sha256": digest(submitted)})
    info["original_inputs"].append({"path": str(Path(filename).resolve()), "sha256": digest(filename)})
    save(attempt / "attempt.json", info)
    return model, info

def structure(attempt, filename, output, architecture_draft=None):
    from .review_stage import verify_structure_attempt
    verify_structure_attempt(attempt)
    test_mode = load(Path(attempt) / "attempt.json").get("skill_test") is True
    extras = {}
    if architecture_draft:
        from .provisional import verify_architecture
        require(not test_mode, "ARCHITECTURE_DRAFT_NOT_FOR_SIMULATED_CLOSURE")
        extras = verify_architecture(Path(attempt) / "closed_review", architecture_draft)
    require(test_mode or not (Path(attempt) / "model-work/return-to-review.json").exists(), "MODEL_DISCOVERED_ISSUES: resolve issues and obtain user confirmation for the revised review")
    if filename is None:
        from .model_batches import assemble
        filename = assemble(attempt)
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "taskbook" and model["protocol"]["profile"] == "taskbook-reviewed", "REVIEW_PROFILE_INVALID")
    effective(model)
    source_quality(model, skill_test=test_mode)
    check_model(model, known_artifacts(attempt))
    require(model["source_baseline"]["status"] == "PASS" and model["consistency"]["gates"]["overall"] == "PASS"
            and not any(i["status"] == "open" for i in model["consistency"]["issues"])
            and not any(t["status"] != "closed" for t in model["consistency"]["todos"])
            and (test_mode or not model["completeness"]["gaps"])
            and all(r["status"] in ("pass", "not_applicable") for e in model["extensions"]
                    if e["namespace"] == "feip.assessments.v1" and e["payload"].get("stage") == "taskbook" for r in e["payload"]["rules"]),
            "STRUCTURE_DISCOVERED_UNRESOLVED_ISSUES: resolve issues and obtain user confirmation for the revised review")
    from .requirement_list import FILENAME, render as render_requirement_list
    extras.update({"taskbook_review.md": report(model, "任务书完备性审查报告"), FILENAME: render_requirement_list(model)})
    result = publish(output, model, attempt, known_artifacts(attempt), extras)
    result["requirement_list_path"] = str(Path(output) / FILENAME)
    if test_mode:
        result.update(skill_test=True, test_only=True, notice="仅供skill功能测试；问题为模拟闭环，不能作为正式工程输入。")
    return result


def review(attempt, filename, output):
    from .review_stage import review as review_only
    return review_only(attempt, filename, output)

def generation_state(model):
    if model["consistency"]["gates"]["overall"] == "FAIL":
        return "BLOCKED"
    unknown = any(f["status"] in ("missing", "unknown") for f in model["basic_info"].values())
    unknown = unknown or any(isinstance(f, dict) and f.get("status") in ("missing", "unknown") for f in model["meta"].values())
    unknown = unknown or any(s["handling"] == "auto" and s["status"] in ("missing", "unknown") for v in model["document_views"] if v["role"] == "writer_plan" for s in v["sections"])
    pending = bool(model["completeness"]["gaps"]) or any(i["status"] == "open" for i in model["consistency"]["issues"])
    return "DRAFT" if unknown or pending or model["source_baseline"]["status"] != "PASS" else "READY_FOR_REVIEW"

def generate(attempt, filename, output):
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "writer", "GENERATE_REQUIRES_WRITER_ATTEMPT")
    model["protocol"].update(profile="reqspec-draft", producer="req-spec-gen")
    effective(model)
    gate(model)
    # Upstream NEEDS_CLARIFICATION remains a draft, never promoted silently.
    model["consistency"]["gates"]["generation_state"] = generation_state(model)
    require(model["consistency"]["gates"]["generation_state"] != "BLOCKED", "GENERATION_BLOCKED: resolve blocking baseline/content issues")
    check_model(model, known_artifacts(attempt))
    markdown = render(model)
    result = publish(output, model, attempt, known_artifacts(attempt), {"需求规格说明.md": markdown, "生成检查报告.md": report(model, "需求规格说明生成检查")})
    result["generation_state"] = model["consistency"]["gates"]["generation_state"]
    return result

def compare(attempt, filename, output):
    model, info = accept_model(attempt, filename)
    require(info["kind"] == "checker", "COMPARE_REQUIRES_CHECKER_ATTEMPT")
    model["protocol"].update(profile="reqspec-draft", producer="req-spec-consistency-check")
    merge_previous(model, attempt)
    effective(model)
    checker_quality(model)
    revision_checks(model)
    closed = model["consistency"]["gates"]["overall"] == "PASS" and model["source_baseline"]["status"] == "PASS" and not any(i["status"] == "open" for i in model["consistency"]["issues"]) and not any(t["required"] and t["status"] != "closed" for t in model["consistency"]["todos"])
    model["consistency"]["gates"]["delivery_state"] = "AWAITING_FINAL_CONFIRMATION" if closed else "REVIEWING"
    check_model(model, known_artifacts(attempt))
    attempt = Path(attempt)
    save(attempt / "review_state.json", state(model))
    text(attempt / "review_report.md", report(model, "需求规格说明一致性检查报告"))
    if closed:
        candidate_uid = uid("candidate")
        save(attempt / "candidate_payload.json", model)
        save(attempt / "icd.json", icd.build(model, "candidate", candidate_uid))
        save(attempt / "runtime_fingerprint.json", runtime_fingerprint())
        packet = report(model, "最终生成确认审阅包") + "\n候选ID：`" + candidate_uid + "`\n\n请审阅candidate_payload.json及icd.json中的完整台账、接口、管脚、缺口、例外和下游可用性，再明确确认是否发布该候选的reqspec.json与icd.json。两文件共享本次候选确认；单项问题确认不代替最终确认。\n"
        text(attempt / "review_packet.md", packet)
        bindings = [{"path": p.relative_to(attempt).as_posix(), "sha256": digest(p)} for p in sorted(attempt.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
        save(attempt / "candidate_manifest.json", {"contract": "feip-candidate/1.0", "candidate_uid": candidate_uid, "created_at": now(),
            "baseline_uid": model["protocol"]["baseline_uid"], "bindings": bindings})
    else:
        save(attempt / "icd.json", icd.build(model, "draft"))
    result = publish(output, model, attempt, known_artifacts(attempt))
    result["delivery_state"] = model["consistency"]["gates"]["delivery_state"]
    result["icd_path"] = str(Path(output) / "icd.json")
    if closed:
        result["candidate_manifest_sha256"] = digest(Path(output) / "candidate_manifest.json")
        result["candidate_uid"] = candidate_uid
    return result

def finalize(candidate, confirmation_file, output):
    candidate = Path(candidate)
    verify_package(candidate)
    verify_inputs(candidate)
    manifest = load(candidate / "candidate_manifest.json")
    for binding in manifest["bindings"]:
        path = contract.safe_artifact(candidate, binding["path"])
        require(path.is_file() and digest(path) == binding["sha256"], "CANDIDATE_CHANGED: " + binding["path"])
    require(runtime_fingerprint() == load(candidate / "runtime_fingerprint.json"), "RULES_OR_SCHEMA_CHANGED: recheck and request a new candidate confirmation")
    confirmation = load(confirmation_file)
    require(confirmation.get("kind") == "approve_release" and confirmation.get("candidate_uid") == manifest["candidate_uid"], "FINAL_CONFIRMATION_REQUIRED")
    require(confirmation.get("candidate_manifest_sha256") == digest(candidate / "candidate_manifest.json"), "CONFIRMATION_CANDIDATE_DIGEST_MISMATCH")
    require(all(isinstance(confirmation.get(k), str) and confirmation[k].strip() for k in ("actor", "confirmed_at", "user_quote")), "CONFIRMATION_INCOMPLETE")
    model = load(candidate / "candidate_payload.json")
    require(model["consistency"]["gates"]["delivery_state"] == "AWAITING_FINAL_CONFIRMATION", "CANDIDATE_NOT_CLOSED")
    checker_quality(model)
    require(model["consistency"]["gates"]["overall"] == "PASS" and not any(i["status"] == "open" for i in model["consistency"]["issues"]), "FINALIZE_NOT_CLOSED")
    # Stage new publication metadata separately. Never modify the accepted round.
    import tempfile
    with tempfile.TemporaryDirectory(prefix="feip-finalize-") as temp_name:
        stage = Path(temp_name) / "candidate"
        shutil.copytree(str(candidate), str(stage))
        # Retain the exact ICD bytes covered by the user's candidate confirmation.
        shutil.copyfile(str(candidate / "icd.json"), str(stage / "candidate_icd.json"))
        confirmation_path = stage / "release_confirmation.json"
        shutil.copyfile(str(confirmation_file), str(confirmation_path))
        known = known_artifacts(stage)
        manifest_art = uid("artifact")
        confirmation_art = uid("artifact")
        known[manifest_art] = "candidate_manifest.json"
        known[confirmation_art] = "release_confirmation.json"
        approval_uid, evidence_uid = uid("decision"), uid("evidence")
        model["consistency"]["evidence"].append({"uid": evidence_uid, "artifact_uid": confirmation_art, "json_pointer": "/user_quote", "part": None,
            "element_uid": None, "section": None, "table": None, "row": None, "column": None, "page": None,
            "quote": confirmation["user_quote"], "origin_kind": "user_supplied", "confirmation": "user_confirmed"})
        model["consistency"]["decisions"].append({"uid": approval_uid, "kind": "approve_release", "operation": None,
            "baseline_uid": model["protocol"]["baseline_uid"], "object_refs": [], "field_paths": [], "issue_refs": [], "before": None, "after": None,
            "reason": "用户确认当前已展示候选并要求生成最终JSON", "actor": confirmation["actor"], "decided_at": confirmation["confirmed_at"],
            "user_quote": confirmation["user_quote"], "user_evidence_refs": [evidence_uid], "target_fingerprint": confirmation["candidate_manifest_sha256"], "status": "active", "supersedes": []})
        model["consistency"]["release_binding"] = {"candidate_uid": manifest["candidate_uid"], "candidate_manifest_artifact_uid": manifest_art,
            "candidate_manifest_sha256": confirmation["candidate_manifest_sha256"], "release_confirmation_decision_uid": approval_uid}
        model["consistency"]["gates"]["delivery_state"] = "RELEASED"
        model["protocol"]["profile"] = "reqspec-reviewed"
        check_model(model, list(known) + [manifest["candidate_uid"]])
        final_icd = icd.build(model, "released", manifest["candidate_uid"])
        require(final_icd["engineering_sha256"] == load(candidate / "icd.json")["engineering_sha256"], "ICD_ENGINEERING_CHANGED: recheck and confirm a new candidate")
        result = publish(output, model, stage, known, {"最终检查报告.md": report(model, "最终一致性检查报告"), "icd.json": final_icd}, final=True)
        result["icd_path"] = str(Path(output) / "icd.json")
    return result

def run(argv=None):
    kind = KINDS[SKILL.name]
    parser = argparse.ArgumentParser(description="FEIP offline Agent-assisted skill runtime")
    sub = parser.add_subparsers(dest="action", required=True)
    p = sub.add_parser("doctor")
    p.add_argument("--output", type=Path)
    p = sub.add_parser("review-reopen", aliases=["review-unpublish"])
    p.add_argument("--attempt", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    for action in ("architecture-status", "architecture-draft", "architecture-validate", "supplement-apply"):
        p = sub.add_parser(action)
        p.add_argument("--review", type=Path, required=True)
        if action in ("architecture-status", "architecture-draft"):
            p.add_argument("--deferral", type=Path)
        if action in ("architecture-draft", "supplement-apply"):
            p.add_argument("--output", type=Path, required=True)
        if action == "architecture-draft":
            p.add_argument("--model", type=Path, required=True)
        if action == "architecture-validate":
            p.add_argument("--draft", type=Path, required=True)
        if action == "supplement-apply":
            p.add_argument("--proposal", type=Path, required=True)
            p.add_argument("--confirmation", type=Path, required=True)
    sub.add_parser("self-test")
    p = sub.add_parser("prepare")
    p.add_argument("--input", type=Path)
    p.add_argument("--baseline", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--previous-state", type=Path)
    p.add_argument("--decisions", type=Path)
    p.add_argument("--attachments", type=Path)
    p.add_argument("--diagnostic", action="store_true")
    p.add_argument("--closed-review", type=Path)
    p.add_argument("--confirmation", type=Path)
    p.add_argument("--chunk-chars", type=int, default=4000)
    p.add_argument("--incremental-global", action="store_true")
    p.add_argument("--skill-test", action="store_true", help="Explicitly authorized skill testing only; requires a bound test authorization in --confirmation")
    p = sub.add_parser("extract-media")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("extract")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    for action in ("review", "structure", "generate", "compare"):
        p = sub.add_parser(action)
        p.add_argument("--attempt", type=Path, required=True)
        p.add_argument("--model", type=Path, required=action not in ("review", "structure"))
        p.add_argument("--output", type=Path, required=True)
        if action == "structure":
            p.add_argument("--architecture", type=Path)
    for action in ("review-status", "review-next", "review-submit", "review-read"):
        p = sub.add_parser(action)
        p.add_argument("--attempt", type=Path, required=True)
        if action == "review-status":
            p.add_argument("--pending-local", action="store_true")
        if action == "review-submit":
            p.add_argument("--model", type=Path, required=True)
        if action in ("review-next", "review-read"):
            p.add_argument("--task")
        if action == "review-read":
            p.add_argument("--unit")
            p.add_argument("--subject")
            p.add_argument("--view", choices=("issue_index", "source_catalog", "local_summaries", "extraction_targets"))
            p.add_argument("--entry", help="select one entry by UID within the global context view")
            p.add_argument("--offset", type=int, default=0)
            p.add_argument("--limit", type=int, default=4000)
            p.add_argument("--output", type=Path, help="write this page to a new, caller-specific file")
    for action in ("model-status", "model-next", "model-submit", "model-read", "model-schema", "model-preflight"):
        p = sub.add_parser(action)
        p.add_argument("--attempt", type=Path, required=True)
        if action == "model-next":
            p.add_argument("--task")
        if action == "model-submit":
            p.add_argument("--model", type=Path, required=True)
        if action in ("model-read", "model-schema"):
            p.add_argument("--path", required=True)
        if action == "model-read":
            p.add_argument("--offset", type=int, default=0)
            p.add_argument("--limit", type=int, default=4000)
    p = sub.add_parser("finalize")
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--confirmation", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("validate")
    p.add_argument("--package", type=Path, required=True)
    args = parser.parse_args(argv)
    allowed = {"taskbook": ("review", "structure"), "writer": ("generate",), "checker": ("compare", "finalize")}
    if args.action in ("review", "structure", "generate", "compare", "finalize"):
        require(args.action in allowed[kind], "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
    if args.action.startswith(("architecture-", "supplement-")):
        require(kind == "taskbook", "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
        from . import provisional
        if args.action == "architecture-status":
            return provisional.status(args.review, args.deferral)
        if args.action == "architecture-draft":
            return provisional.architecture(args.review, args.model, args.output, args.deferral)
        if args.action == "architecture-validate":
            provisional.verify_architecture(args.review, args.draft)
            return {"valid": True, "status": "PROVISIONAL"}
        return provisional.supplement(args.review, args.proposal, args.confirmation, args.output)
    if args.action in ("review-reopen", "review-unpublish"):
        require(kind == "taskbook", "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
        from .review_updates import reopen
        return reopen(args.attempt, args.output)
    if args.action.startswith("review-"):
        require(kind == "taskbook", "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
        from . import batches
        if args.action == "review-status":
            return batches.status(args.attempt, args.pending_local)
        if args.action == "review-next":
            return batches.next_task(args.attempt, args.task)
        if args.action == "review-submit":
            return batches.submit(args.attempt, args.model)
        return batches.read_units(args.attempt, args.unit, args.subject, args.offset, args.limit, args.task, args.output, args.view, args.entry)
    if args.action.startswith("model-"):
        require(kind == "taskbook", "ACTION_NOT_SUPPORTED_BY_THIS_SKILL")
        from . import model_batches
        if args.action == "model-preflight":
            from .model_preflight import run as preflight
            result = preflight(args.attempt)
            return {k: v for k, v in result.items() if k != "errors"}
        if args.action == "model-status":
            return model_batches.status(args.attempt)
        if args.action == "model-next":
            return model_batches.next_task(args.attempt, args.task)
        if args.action == "model-submit":
            return model_batches.submit(args.attempt, args.model)
        if args.action == "model-read":
            return model_batches.read_model(args.attempt, args.path, args.offset, args.limit)
        return model_batches.export_schema(args.attempt, args.path)
    if args.action == "doctor":
        from .review_updates import doctor
        return doctor(args.output)
    if args.action == "self-test":
        from .selftest import self_test
        return self_test()
    if args.action == "prepare":
        require(kind == "writer" or args.input is not None, "SOURCE_INPUT_REQUIRED")
        require(kind == "taskbook" or not (args.closed_review or args.confirmation), "STRUCTURE_ONLY_SUPPORTED_BY_TASKBOOK")
        return prepare(kind, args.output, args.input, args.baseline, args.previous_state, args.decisions, args.diagnostic, args.attachments, args.closed_review, args.confirmation, args.chunk_chars, args.skill_test, args.incremental_global)
    if args.action == "extract-media":
        from .media import extract_media
        return extract_media(args.input, args.output)
    if args.action == "extract":
        archive = extract(args.input, "taskbook" if kind == "taskbook" else "specification", "artifact:extract-input")
        save(args.output, archive)
        return {"output": str(args.output), "extraction_status": archive["extraction_status"]}
    if args.action == "review":
        return review(args.attempt, args.model, args.output)
    if args.action == "structure":
        return structure(args.attempt, args.model, args.output, args.architecture)
    if args.action == "generate":
        return generate(args.attempt, args.model, args.output)
    if args.action == "compare":
        return compare(args.attempt, args.model, args.output)
    if args.action == "finalize":
        return finalize(args.candidate, args.confirmation, args.output)
    if args.action == "validate":
        if (args.package / "review_state.json").is_file() and not (args.package / "package.json").exists():
            from .review_stage import verify_review
            result = verify_review(args.package)
            return {"valid": True, "contract": result["contract"], "state": result["state"]}
        model, manifest = verify_package(args.package)
        return {"valid": True, "profile": model["protocol"]["profile"], "package_uid": manifest["package_uid"], "icd_valid": True if (args.package / "icd.json").is_file() else None}
