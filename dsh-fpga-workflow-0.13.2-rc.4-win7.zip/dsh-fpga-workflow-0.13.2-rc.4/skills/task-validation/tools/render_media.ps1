param([Parameter(Mandatory=$true)][string]$InputDirectory,
      [Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$mediaInput = [System.IO.Path]::GetFullPath($InputDirectory)
$mediaOutput = [System.IO.Path]::GetFullPath($OutputDirectory)
if (-not [System.IO.Directory]::Exists($mediaInput)) { throw 'Input directory not found' }
if ([System.IO.Directory]::Exists($mediaOutput)) { throw 'Output directory must be new' }
[System.IO.Directory]::CreateDirectory($mediaOutput) | Out-Null
foreach ($mediaFile in [System.IO.Directory]::GetFiles($mediaInput)) {
    $mediaExt = [System.IO.Path]::GetExtension($mediaFile).ToLowerInvariant()
    if (($mediaExt -ne '.emf') -and ($mediaExt -ne '.wmf')) { continue }
    $mediaImage = $null
    $mediaBitmap = $null
    $mediaGraphics = $null
    try {
        $mediaImage = [System.Drawing.Image]::FromFile($mediaFile)
        if (($mediaImage.Width -le 0) -or ($mediaImage.Height -le 0)) { throw 'Invalid image size' }
        $mediaScale = [Math]::Min(3.0, 2400.0 / [Math]::Max($mediaImage.Width, $mediaImage.Height))
        $mediaWidth = [Math]::Max(1, [int]($mediaImage.Width * $mediaScale))
        $mediaHeight = [Math]::Max(1, [int]($mediaImage.Height * $mediaScale))
        $mediaBitmap = New-Object System.Drawing.Bitmap($mediaWidth, $mediaHeight)
        $mediaGraphics = [System.Drawing.Graphics]::FromImage($mediaBitmap)
        $mediaGraphics.Clear([System.Drawing.Color]::White)
        $mediaGraphics.DrawImage($mediaImage, 0, 0, $mediaWidth, $mediaHeight)
        $mediaTarget = [System.IO.Path]::Combine($mediaOutput, [System.IO.Path]::GetFileNameWithoutExtension($mediaFile) + '.png')
        $mediaBitmap.Save($mediaTarget, [System.Drawing.Imaging.ImageFormat]::Png)
        Write-Output $mediaTarget
    } finally {
        if ($mediaGraphics -ne $null) { $mediaGraphics.Dispose() }
        if ($mediaBitmap -ne $null) { $mediaBitmap.Dispose() }
        if ($mediaImage -ne $null) { $mediaImage.Dispose() }
    }
}
