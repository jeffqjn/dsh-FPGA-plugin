<div align="center">
  <h1>test-spec-gen</h1>
  <p><strong>Turn confirmation test procedures and a FEIP package into review-ready FPGA confirmation test plan and report documents, driven by controlled templates</strong></p>
  <p>Python 3.8.10 · offline on Windows 7 SP1 · standard library only · version 1.0.0</p>
  <p><a href="README.md">中文</a> · <a href="#quick-start">Quick Start</a> · <a href="#when-to-use">When to use</a> · <a href="#inputs-outputs-and-workflow">Inputs &amp; outputs</a></p>
</div>

This skill consumes only upstream deliverables: the `test-specification` family (`test_specification.json` required; `verification_plan.json`, `coverage_report.json` and `RTM.csv` recommended) and one FEIP package (`taskbook-reviewed` or `reqspec-reviewed`). It renders the 1-58 plan template and the 1-59 report template into DOCX and Markdown, plus a gap list and a product-assurance self-check table. It does **not** re-extract the taskbook, re-review requirements, reorder verification obligations, or fill in any measured results — result fields are always `-`.

## Quick Start

```text
Use the test-spec-gen skill to produce the confirmation test plan and report.
Input: <dir containing test_specification.json>, <taskbook-reviewed or reqspec-reviewed package>
Output: <output dir> with 确认测试计划.docx/.md, 确认测试报告.docx/.md, 缺口清单.md and the generation check report
```

Shortest path: `inspect` the inputs and digests, then `both` to emit plan and report in one pass, then pass the nine validation gates.

## When to use

**Use it when**

- Test procedures exist and formal plan and report documents are needed.
- A plan already exists and only the report must be generated or refreshed (incremental mode).
- Appendix E/F product-assurance verdicts and the gap list must ship with the documents.

**Do not use it when**

- `test_specification.json` does not exist yet — run the confirmation procedures skill first.
- You want measured conclusions: this skill produces no measured data and always writes `-`.
- You want to change template structure: templates are controlled; structural changes are a reviewed decision, out of scope here.

## Inputs, outputs and workflow

| Stage | What happens | Output |
| --- | --- | --- |
| 1 Validate input | `inspect` confirms FEIP profile and state, case and evidence counts, whether the normalised digest matches the coverage report, and `design_status` / `execution_status`. The digest is recomputed with `json.dumps(sort_keys=True, separators=(',',':'))`, not a file hash | Validation result and error codes |
| 2 Generate plan and report | `both` emits both; `plan` or `report` emit one. Everything is written by slot anchors; a missing anchor raises `TEMPLATE_ANCHOR_MISSING` and stops | Plan DOCX/MD, report DOCX/MD |
| 3 Self-check and close | Appendix E/F are judged by `rules/conformance_rules.json` into `符合` / `不符合` / `不适用` / `待实测`; every `不符合` must also appear in `缺口清单.md` | Assurance table, gap list |
| 4 Deliver | Publish only after nine gates: anchors, residual placeholders, heading structure, numbering, data completeness, digest, reopen, inputs unchanged, determinism; then compare against the template section by section — class C invariants must have zero violations | Complete delivery |

## Commands

```powershell
python scripts\cli.py doctor
python scripts\cli.py inspect --source <FEIP package> --spec <test_specification.json> [--coverage coverage_report.json] [--rtm RTM.csv]
python scripts\cli.py both --source <FEIP package> --spec <test_specification.json> --out <output dir>
python scripts\cli.py plan|report --source <FEIP package> --spec <test_specification.json> --out <output dir>
python scripts\cli.py section --docx <file.docx> --list
python scripts\cli.py section --docx <file.docx> --heading 3.3 --max-chars 800
```

`scripts\run.ps1` is the PowerShell entry (Windows 7, set `FPGA_PYTHON38`). Documents are always written by scripts, never through the conversation; use `section` to read specific headings.

## Highlights

- **One input, two documents** — the plan comes first, the report second, because four appendix F check objects live in the plan.
- **Slot-anchor writes only** — a missing anchor stops the run instead of guessing block positions.
- **Nine gates before publishing** — anchors, placeholders, headings, numbering, completeness, digest, reopen, inputs unchanged, determinism.
- **Programmatic assurance verdicts** — appendix E/F emit `符合`/`不符合`/`不适用`/`待实测`; every mismatch is forced into the gap list.
- **No measured results** — result fields stay `-`; the skill delivers reviewable plans and reports only.

## More

- Contract, fields and error codes: [`references/contract.md`](references/contract.md)
- Slot map and template defects: [`references/slot-map.md`](references/slot-map.md), [`references/template-defects.md`](references/template-defects.md)
- Incremental mode: [`references/incremental.md`](references/incremental.md)
- Offline runtime: [`references/runtime.md`](references/runtime.md)
