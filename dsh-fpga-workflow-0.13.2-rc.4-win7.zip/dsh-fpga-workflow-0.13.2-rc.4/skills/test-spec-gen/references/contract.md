# 输入与产物契约（1.0.0）

本文件是 `test-spec-gen` 的输入、产物与错误码契约。凡与实现冲突处，**以实现为准**：输入解析见 `scripts/confdoc/contract.py`、`spec.py`、`feip.py`，动作与退出码见 `scripts/cli.py`，产物与校验门见 `scripts/confdoc/assemble.py`。

## 1. 输入

| 参数 | 必需性 | 类型 | 解析位置 | 说明 |
|---|---|---|---|---|
| `--source` | 必需 | 目录 | `feip.FeipPackage` | FEIP 统一 JSON 交接包；`profile` 必须为 `taskbook-reviewed` 或 `reqspec-reviewed` |
| `--spec` | 必需 | 文件 | `spec.Specification` | `test_specification.json`，顶层 `schema_version` 必须为 `"2.0"` |
| `--plan` | 建议 | 文件 | `contract.input_path` | `verification_plan.json`；缺省在 `--spec` 同目录探测 |
| `--coverage` | 建议 | 文件 | `contract.input_path` | `coverage_report.json`；缺省同目录探测 |
| `--rtm` | 建议 | 文件 | `contract.input_path` | `RTM.csv`；缺省同目录探测 |
| `--plan-docx` | 可选 | 文件 | `assemble.publish` | 已发布计划 docx，仅 `report` 动作使用，见 [incremental.md](incremental.md) |
| `--out` | 生成动作必需 | 目录 | `assemble.publish` | 必须不存在；不得落在任何输入目录内 |
| `--no-markdown` | 可选 | 开关 | `contract.Options` | 关掉 `确认测试计划.md`/`确认测试报告.md` 导出（默认导出） |
| `--case-table` | 可选 | `1`/`2` | `cli.build_parser` | 目前仅做取值校验，实现固定使用**模板1**（`plan_content._case_table_prototype` 自动识别） |
| `--dry-run` | 可选 | 开关 | `cli.dispatch` | 只建上下文不落盘，输出统计 JSON |

### 1.1 FEIP 包的定位规则

`feip.FeipPackage` 依次尝试，任一步成功即停止：

1. 读 `<source>\package.json`；若 `model_artifact_uid` 存在，取 `artifacts[]` 中 `role=="engineering-model"` 且 `uid` 与之相等的条目，按 `path` 打开；
2. 否则取 `artifacts[]` 中第一个 `role=="engineering-model"` 的条目；
3. 回退 `<source>\model.json`；
4. 回退目录下任意大小写形式的 `model.json`（不递归）；
5. 全失败报 `FEIP_PACKAGE_INVALID`。

`package.json` 缺失不会立即失败（`_load_manifest` 返回 `None`），但 `profile` 校验随即失败，因此实际等价于必须有清单。`profile` 不在白名单内同样报 `FEIP_PACKAGE_INVALID`。

### 1.2 缺省探测的固定文件名

`contract.INPUT_FILE_NAMES`：`test_specification.json`、`verification_plan.json`、`coverage_report.json`、`RTM.csv`。显式路径优先；显式路径不存在报 `INPUT_NOT_FOUND`，**不会**静默回落到探测。探测不到不报错，只按缺省降级。

## 2. 输入校验与错误码

`Specification.validate()` 依次执行 status⇔open_items、method 分流、追溯闭包、规范化摘要四项；前三项失败即中止生成。

| 校验 | 规则 | 失败码 | 是否阻断 |
|---|---|---|---|
| 文件存在 | `--spec` 指向的文件存在 | `SPEC_NOT_FOUND` | 阻断 |
| 版本 | `schema_version == "2.0"` | `SPEC_VERSION_UNSUPPORTED` | 阻断 |
| 非空 | `test_cases`、`evidence_procedures` 至少一个非空 | `SPEC_EMPTY` | 阻断 |
| 条目标识 | 每条必须有 `test_case_id` / `procedure_id` | `SPEC_ITEM_INVALID` | 阻断 |
| status⇔open_items | `bool(open_items) == (status != "READY")` 双向 | `SPEC_STATUS_INCONSISTENT` | 阻断 |
| method 分流 | 用例 `method ∈ {board_test,system_test}`；证据程序 ∈ `{inspection,analysis,timing_analysis,review}` | `SPEC_METHOD_MISMATCH` | 阻断 |
| 追溯闭包 | 条目的 `obligation_ids` 必须在计划中存在，且其需求集合等于条目的 `requirement_uids` | `SPEC_TRACE_BROKEN` | 阻断 |
| RTM 表头 | 至少含 `RTM_COLUMNS[:7]` 七列 | `RTM_INVALID` | 阻断 |
| 摘要 | 规范化 sha256 与 `coverage_report.specification_sha256` 相等 | `SPEC_DIGEST_MISMATCH` | **仅警告** |
| FEIP 包 | 目录存在、`profile` 合法、`model.json` 可定位 | `FEIP_PACKAGE_INVALID` | 阻断 |
| 模板 | `templates/plan.docx`、`templates/report.docx` 存在 | `TEMPLATE_MISSING` | 阻断 |
| 选项 | 动作所需参数齐全（`--source`/`--spec`/`--out`） | `OPTION_REQUIRED` | 阻断 |

缺 `--plan` 时记警告 `PLAN_MISSING`，义务级校验跳过；缺 `--coverage` 记 `COVERAGE_MISSING`；覆盖报告无 `specification_sha256` 记 `COVERAGE_DIGEST_ABSENT`。三条都写进 `生成检查报告.md` 的“警告”节，不阻断。

### 2.1 “规范化摘要”口径

`base.canonical_sha256(payload)` = `sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))`。**不是文件字节哈希**，两者在本样本上确实不同：

| 口径 | 实测值（`_build/try14/package.json`） |
|---|---|
| 文件字节 sha256（`inputs.specification`） | `65c2c783333d0ef9ebac8db0b3a2b93399b8313331c13aec063b152c67344be5` |
| 规范化摘要（`specification_sha256`） | `4fed8f0841c5cf530214b37bf993e3bed55f5ad17cf4d42e1d1972c805f4ff46` |

因此覆盖报告里记录的 `specification_sha256` 只能用规范化口径复算；用文件哈希比对必然不符。

## 3. FEIP 事实信封与取值规则

`feip.fact_of` 把所有字段统一成信封 `{status,value,reason,evidence_refs,text}`，`status ∈ {present,unknown,conflict,absent}`：

| status | 文档写法 | 缺口登记 | 短语常量（`contract.py`） |
|---|---|---|---|
| `present` | 直接写 `text`，否则写 `value` | 不登记 | — |
| `unknown` | `任务书未规定` | `kind=unknown` | `PHRASE_UNKNOWN` |
| `conflict` | `任务书存在冲突，待确认` | `kind=conflict` | `PHRASE_CONFLICT` |
| `absent`（键不存在） | `任务书未涉及` | `kind=absent` | `PHRASE_UNSPECIFIED` |
| 结果项（实测/结论） | `-` | `kind=result` | `PHRASE_RESULT` |
| 空值占位（非缺口） | `—` | 不登记 | `PHRASE_ABSENT` |

`contract.GapRegistry.phrase_for(fact, location, field, impact, suggestion)` 是唯一入口：登记缺口并返回该写入文档的短语；`_value()`（`assemble.py`）在事实缺失但调用方给了缺省值时用缺省值，否则用短语。

`status` 非标准值（例如字段不是信封而是裸对象）在 `fact_of` 中按 `unknown` 处理并记 `reason="字段不是 FEIP 事实信封"`——不要依赖它取数。

## 4. 动作与退出码

| 动作 | 需要参数 | 是否写盘 | 成功标志 | 说明 |
|---|---|---|---|---|
| `doctor` | 无 | 否 | `FEIP_SKILL_OK:doctor` | 输出 Python/实现/平台/模板字节数/规则文件存在性 |
| `self-test` | 无 | 临时目录 | `FEIP_SKILL_OK:self-test` | 17 项确定性回归（实测 17/17 通过） |
| `inspect` | `--source`、`--spec` | 否 | `FEIP_SKILL_OK:inspect` | 只读预检：profile、synthetic、需求数、用例数、三项 readiness、校验结果、覆盖 counts/metrics |
| `plan` | `--source`、`--spec`、`--out` | 是 | `FEIP_SKILL_OK:plan` | 只出计划 |
| `report` | 同上（可加 `--plan-docx`） | 是 | `FEIP_SKILL_OK:report` | 只出报告 |
| `both` | 同上 | 是 | `FEIP_SKILL_OK:both` | 一次出两份 |

退出码只有两类确定含义：`0` 成功（stdout 必须先打印一行结果 JSON，再打印 `FEIP_SKILL_OK:<action>`）；`2` skill 异常（stderr 打印 `FEIP_SKILL_ERROR: <message>` 与一行 `{"code","message","details"}` JSON）。其它非零值只会来自宿主或参数解析（`argparse` 自身出错也是 `2`，但不打印 `FEIP_SKILL_ERROR`，用 stderr 的 usage 区分）。

`--dry-run` 对 `plan`/`report`/`both` 有效，返回 `{action,dry_run,product,version,items,projects,gaps}`，不创建输出目录、不写任何文件。

## 5. 产物

同一目录一次发布会写出以下文件（`package.json.artifacts[]` 逐项记 `role/path/media_type/sha256/size_bytes`）：

| role | 文件名 | 内容 | 实测（try14） |
|---|---|---|---|
| `document` | `FPGA确认测试计划_<产品>_<版本>.docx` | 计划正件 | 111280 字节，`34d194bb…cb87f8` |
| `document` | `FPGA确认测试报告_<产品>_<版本>.docx` | 报告正件 | 106769 字节，`4d74bd51…c9c58dd` |
| `markdown` | `确认测试计划.md` | 计划全文（含表） | 144756 字节 |
| `markdown` | `确认测试报告.md` | 报告全文（含表） | 155047 字节 |
| `fill-map` | `fill-map-plan.json` / `fill-map-report.json` | 每个槽位的 `{slot,source,status,value}` | 12341 / 9919 字节 |
| `gap-list` | `缺口清单.md` | `# \| 类型 \| 位置 \| 字段 \| 原因 \| 影响 \| 建议` | 2569 字节（13 项） |
| `conformance` | `产保要素自检表.md` | 计划附录E 3 项 + 报告附录F 27 项判定与依据 | 5306 字节 |
| `check-report` | `生成检查报告.md` | 输入、规模、八道校验门、产保自检统计、模板缺陷提示、产物清单 | 1546 字节 |

文件名净化：`contract._safe()` 去掉 `\ / : * ? " < > |` 与空格，空串回落 `FPGA`；无版本时省略 `_<版本>` 后缀。

`package.json` 顶层字段：`protocol_version="1.0.0"`、`skill="test-spec-gen"`、`status="complete"`、`profile`、`synthetic`、`package_uid`、`product`、`version`、`artifacts[]`、`inputs{}`（仅四个文件型输入的真实 sha256；目录型 `--source` 不计入）、`template_sha256{plan,report}`、`specification_sha256`（规范化）、`counts{requirements,projects,items,test_cases,evidence_procedures}`、`gaps{}`（按 kind 计数）。

本样本关键数字：需求 119、测试项目 10、条目 121（用例 63 + 证据程序 58）、缺口 `unknown 3 / absent 9 / missing 1`。

## 6. 输出目录与写盘规则

| 规则 | 行为 | 错误码 |
|---|---|---|
| 输出目录已存在 | 直接失败，不覆盖、不合并 | `OUTPUT_EXISTS` |
| 输出目录等于或位于输入目录内 | 失败 | `OUTPUT_INSIDE_SOURCE` |
| 单文件写 | 同目录 `.tmp-<16hex>` → `fsync` → `os.replace` 原子替换（`base.atomic_write_text`） | — |
| 生成失败 | `--out` 目录可能已创建（`ensure_directory` 在生成前执行），但**不写出任何产物**，也不写 `FAILED.json`（实现没有该产物） | 由错误码定位 |
| 输入只读 | 生成前后对输入做文件 sha256，前后不一致即失败 | `INPUT_MUTATED` |
| 输出可重开 | 每份 docx 保存后重新 `zipfile` 打开并 `ET.fromstring(word/document.xml)` | `DOCX_UNREADABLE` |

## 7. 与设计方案的偏差（必须知悉）

| 设计条目 | 实现现状 |
|---|---|
| G9 确定性门（同输入两次生成完全一致） | 未实现为独立的门（代码里没有确定性断言），但实测成立：`_build/verify/idem-a`、`idem-b` 与 `_build/try14` 三份计划 docx 的 sha256 均为 `34d194bb5ae48cc7fb438cec2bd860f7e03fe00d0bae973d0b690dd872cb87f8`、均 111280 字节，`word/document.xml` 逐字节相同。可用“重跑后 sha256 相等”做回归，但门本身仍需人工执行 |
| G10 自检完备门（每条判定必须有值且 `不符合` 进缺口） | 未实现为独立门；判定值由 `conformance.apply_to_table` 写入，`不符合` 项进入检查报告“不符合项”节，`缺口清单.md` 只收 `GapRegistry` 登记的缺口 |
| `docProps.title` 改写为实际文件名 | 未实现：只重写 `word/document.xml`，`docProps/core.xml` 逐字节保留，产物仍带模板标题 `XX-X卫星天线分系统方案报告` |
| 增量模式反读计划并交叉核对 | 未实现 `importplan.py`；`--plan-docx` 只作为计划侧判定对象，详见 [incremental.md](incremental.md) |
