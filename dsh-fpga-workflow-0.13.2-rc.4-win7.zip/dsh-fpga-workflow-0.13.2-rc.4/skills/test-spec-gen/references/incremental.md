# 增量模式：以已发布计划为输入（1.0.0）

## 1. 动机

报告必须与**已发布**的计划逐项一致（用例集合、项目标识、用例统计、追溯矩阵、测试要点）。若报告另起一份 `test_specification.json` 重算，一旦上游又改过一轮，就会出现“计划里 `TC-041` 在 A 组、报告里在 B 组”的对不上。所以允许 `report` 直接吃计划正件，用它作为计划侧内容的判定对象。

## 2. 用法

```powershell
# 只出报告，计划侧判定以“已发布计划”为准
scripts\run.ps1 report `
  --source    D:\feip-package `
  --spec      D:\out\test_specification.json `
  --plan-docx D:\published\FPGA确认测试计划_遥测下行与合路FPGA_V1.1.docx `
  --out       D:\out\report-v1

# 全量：计划与报告同批生成（报告的计划侧判定用内存里新生成的计划）
scripts\run.ps1 both --source D:\feip-package --spec D:\out\test_specification.json --out D:\out\both-v1
```

| 参数 | 行为 |
|---|---|
| `--plan-docx <文件>` | 只在 `report` 动作生效（`both`/`plan` 会先走“生成本批计划”分支，忽略该参数） |
| 路径不存在 | `INPUT_NOT_FOUND`，`details.path` 给绝对路径 |
| 不传 `--plan-docx` | `assemble.publish` 走兜底：用 `--spec` 在**内存里**构建一份计划（不落盘、不进产物清单），专供附录F 的计划侧判定 |
| `--plan-docx` 传入非 docx | `DOCX_NOT_WORD` 或 `DOCX_MALFORMED`（打不开包/没有 `word/document.xml`） |

实测样本：`_build/verify/incr-report2/`（报告 106769 字节，sha256 `4d74bd5197ecfaa21f059dda822109ff942483aa6b26b94c178b50352c9c58dd`）。该文件与全量轮次 `_build/try14` 的报告 docx **逐字节相同**——因为两次的计划侧判定对象内容一致，除计划来源外没有任何差异。更早的 `_build/verify/incr-report/`（106565 字节，`<w:sectPr>`=3）是分节符修复前的产物，仅作历史对照，不要当验收基线。

## 3. 当前实现到底拿计划做什么

| 用途 | 是否使用 | 位置 |
|---|---|---|
| 作为附录F 中 `doc_target: "plan"` 规则的判定目标文档 | **是** | `conformance.evaluate(..., ctx)`：`target_doc = ctx["plan_doc"]` |
| 作为用例表、统计表、追溯表的取数来源 | **否** | 这些一律来自 `--spec`/`--plan`/`--coverage`/`--rtm` |
| 回写、重排、补号、改属性 | **否** | 只用 `Docx(path)` 打开读 `document.xml`，从不 `save()` |

`doc_target` 为计划的 4 条规则（`rules/conformance_rules.json`）：

| 规则 | 检查项 | 断言 |
|---|---|---|
| `F-01` | 新状态识别与控制 | 计划“新状态识别表”有效数据行 ≥1 |
| `F-07` | 测试环境差异性分析与控制 | 计划“测试环境差异性分析表”有效数据行 ≥1 |
| `F-09` | 同上（文档审查） | 同表、`require_column: 3`（分析结果列）有实文本 |
| `F-10` | 同上（补充测试时机与闭环） | 同表、`require_column: 3` |

另外 23 条判定目标是报告自身（`doc=report`），3 条来自计划附录E。实测：报告附录F 27 项 = 19 符合 / 1 不符合（`F-01`）/ 5 不适用 / 2 待实测；计划附录E 3 项 = 2 符合 / 1 不适用。

### 3.1 拿不到计划时的错误码

`conformance.evaluate` 在 `ctx["plan_doc"]` 为空时抛 `PLAN_REQUIRED_FOR_CONFORMANCE`（`details` 给规则 id 与目标文档），**绝不把“缺输入”判成 `不符合`**——那会把没输入误报成文档缺陷。

现状：`report` 动作无论是否给 `--plan-docx` 都能拿到计划（给了就加载，没给就内存构建），所以这条错误码在正常 CLI 路径上不会出现；只有直接调用 `conformance.evaluate` 且 `ctx` 里没有 `plan_doc` 时才触发。写规则或改编排时**不要**绕过这一点：缺计划必须报错，不能降级成 `不符合`。

## 4. 与设计方案的差距（必须知悉）

设计方案 §2.4 已**部分落地**：计划 docx 的统计表交叉核对、冲突报错与指纹登记均已实现（见下表状态列）；**逐项反读用例清单仍未实现**，报告正文数据仍来自 `--spec`。现状如下：

| 设计项 | 实现现状 | 影响 |
|---|---|---|
| 从计划 docx 反读用例清单与分组（附录A 用例表：项目标识/编号/测试项目/功能项/测试类型/健壮性/测试要点） | **未实现**（无 `importplan.py`） | 用例表仍来自 `--spec`；上游若改过，报告与已发布计划会不一致，需人工比对 |
| 反读用例总数与分组计数（计划 7.4 表7） | 未实现 | 报告表2 用 `--spec` 重算 |
| 反读需求→用例追溯（计划表6、表8） | 未实现 | 报告附录D 用 `RTM.csv` 重算 |
| 反读测试要点汇总（计划表9） | 未实现 | 报告表3 用 `test_points` + 用例索引重算 |
| 反读不可测试项（计划表12） | 未实现 | 报告表4 用 `status!=READY` 重算 |
| 反读产品标识（计划 1.1 七段） | 未实现 | 报告 1.1 仍取 FEIP `basic_info` |
| 与 `--spec` 交叉核对，冲突报 `PLAN_SPEC_CONFLICT` | **已实现**：`assemble._cross_check_plan` 读回计划“测试用例统计表”，逐行比对（项目名称/项目标识/用例数量）与“总计”，不一致即抛 `PLAN_SPEC_CONFLICT` 并列出 `missing_in_plan`/`extra_in_plan`/`plan_total`/`spec_total` | 同时给 `--plan-docx` 与 `--spec` 时能发现“细则在上游已改过”；一致时在检查报告 warnings 记 `PLAN_SPEC_CONSISTENT` |
| `package.json` 记计划 docx 指纹 | **已实现（键名不同）**：`package.json.inputs.plan_docx` 记录该 docx 的 sha256；FEIP 包目录按 `source_package/package.json`、`source_package/model.json` 两个文件哈希登记 | 可从产物反查当次用的是哪份计划 docx 与哪个 FEIP 包 |
| `fill-map` 的来源标注写成 `from: "plan-docx#<表号>/<行号>"` | **未实现**：仍是 `{slot,source,status,value}` | 槽位溯源仍指向 `source`（如 `derived`、`basic_info.*`） |
| 增量模式下 `coverage_report` 可缺省 | 部分成立：缺 `--coverage` 只记 `COVERAGE_MISSING` 警告，不阻断 | 5.1 的“细则追溯覆盖率”会写 `任务书未规定` |

因此本版本的正确用法是：**`--plan-docx` 只用来让附录F 的计划侧 4 项对着“已发布计划”判，而不是对着现场重算的计划判**。需要“报告与计划逐项一致”时，仍必须在生成前人工确认 `test_specification.json` 与已发布计划同源。

## 5. 只读保证

| 保证 | 证据 |
|---|---|
| 不修改计划 docx | 只 `Docx(path)` 打开，`doc.save()` 从不调用；`_input_digests` 也不含该文件 |
| 不改输入任何文件 | 生成前后对 `--source`/`--spec`/`--plan`/`--coverage`/`--rtm` 做文件 sha256 比对，变化即 `INPUT_MUTATED` |
| 产物只落在 `--out` | 目录必须不存在，且不得位于输入目录内（`OUTPUT_EXISTS`/`OUTPUT_INSIDE_SOURCE`） |

注意：因为 `plan_docx` 不在 `_input_digests` 里，**生成期间有人替换了计划 docx 不会触发 `INPUT_MUTATED`**。需要冻结时自行在交付记录里记 sha256（`Get-FileHash` 在 PS2.0 不可用，用 `certutil -hashfile <file> SHA256` 或 `cli.py doctor` 同环境的 Python 计算）。

## 6. 增量模式的产物差异（实测）

| 项 | 全量 `both`（try14） | 增量 `report --plan-docx`（verify/incr-report2） |
|---|---|---|
| docx | 计划 + 报告 | 仅报告（106769 字节，sha256 与全量的报告相同） |
| 表数 / `<w:sectPr>` | 报告 25 张表 / 4 个分节 | 报告 25 张表 / **4** 个分节（分节未丢） |
| Markdown | 计划 + 报告 | 仅报告 |
| `fill-map-*.json` | 2 个 | 1 个（`fill-map-report.json`） |
| 产物条目 | 9 项 | 6 项 |
| `产保要素自检表.md` | 计划附录E 3 项 + 报告附录F 27 项 | **仅报告附录F 27 项**（计划侧判定用了外部计划，`ctx["plan_verdicts"]` 为空） |
| `缺口清单.md` | 13 项（`unknown 3 / absent 9 / missing 1`） | 10 项（`unknown 2 / absent 8`）：计划侧缺口（工作量、新状态、`safety_critical`）不再登记 |
| `package.json.counts` | 119 / 10 / 121 / 63 / 58 | 相同（都来自 `--spec`） |

结论：增量模式省掉计划生成，但**计划侧的缺口信息也随之消失**。要完整缺口清单，用 `both`；只要报告且已有发布计划，用 `report --plan-docx`，并把计划侧缺口从上一轮的 `缺口清单.md` 合并进来。

## 7. 验收清单

1. `report --plan-docx` 产出的报告 docx 可被 `zipfile` 重开、`document.xml` 可被 `ET` 解析（失败即 `DOCX_UNREADABLE`）；
2. `<w:sectPr` 计数为 4（报告模板分节数）、`<w:tbl>` 为 25，横向附录 B–F 未丢（incr-report2 实测 4 / 25）；
3. 计划 docx 生成前后 sha256 不变（本次输入 `_build/try14` 计划 docx 仍为 `34d194bb…cb87f8`、111280 字节）；
4. `产保要素自检表.md` 含 27 条 F 规则判定且 `F-01/F-07/F-09/F-10` 的“说明”引用的是计划表内容（如“表格“测试环境差异性分析表”有效数据行 2 行”）；
5. 报告 5.3 表7 与附录F 汇总一致：19 满足 / 1 不满足（`F-01`）/ 5 不适用 / 2 待实测（`待实测` 计入“不满足”列）。
