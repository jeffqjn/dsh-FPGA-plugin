# 数据→槽位映射与缺口口径（1.0.0）

`test_specification.json` 不含章节、测试类型、测试项目、优先级；这些全部派生。派生口径集中在 `scripts/confdoc/derive.py`（词汇与分组）、`plan_content.py`/`report_content.py`（写入）、`contract.py`（缺口短语）。改口径只改这些文件，不要在模板里手改。

## 1. 需求类目 → 测试项目（10 组，顺序固定）

| 序 | `category` | 中文标签 | 类型码 | 实测条数（121 中） |
|---|---|---|---|---|
| 1 | `loading` | 加载要求 | `JZ` | 1 |
| 2 | `language` | 编程语言 | `YY` | 1 |
| 3 | `tool` | 开发工具和环境 | `GJ` | 1 |
| 4 | `ip` | IP 核使用 | `IP` | 1 |
| 5 | `function` | 功能需求 | `GN` | 29 |
| 6 | `performance` | 性能要求 | `XN` | 9 |
| 7 | `protocol` | 协议与数据格式 | `XY` | 36 |
| 8 | `interface` | FPGA 产品接口 | `JK` | 30 |
| 9 | `reliability` | 可靠性与安全性 | `KK` | 10 |
| 10 | `verification` | 测试验证要求 | `YZ` | 3 |

规则：条目的项目归属 = 其 `requirement_uids` 中**第一个**能在 FEIP 找到 `category` 的需求类目（`derive.project_of_item`）；一条都找不到时归 `verification`。项目按 `CATEGORY_ORDER` 排序后从 1 连续编号，序号决定 `项目标识` 的尾号。

实测产物：**10 个测试项目、121 项**（用例 63 + 证据程序 58），与表7/表2 的“总计 121”一致。

## 2. 方法 → 中文（测试类型列的基础值）

| `method` | 中文 | 归属 | 实测条数 |
|---|---|---|---|
| `board_test` | 板级测试 | `test_cases` | 55 |
| `system_test` | 系统测试 | `test_cases` | 8 |
| `inspection` | 检查 | `evidence_procedures` | 48 |
| `analysis` | 分析 | `evidence_procedures` | 7 |
| `timing_analysis` | 时序分析 | `evidence_procedures` | 2 |
| `review` | 评审 | `evidence_procedures` | 1 |

`derive.type_label` = 方法中文 + 该条目所有非 `normal` 场景中文（`、` 分隔）。例：`板级测试、边界`。

其它词汇：`level` → `板级`/`系统级`/`FPGA 级`；`scenario_type` → `正常`/`边界`/`异常`/`强度`/`恢复`。未在表中的值原样输出。

## 3. 场景 → 健壮性列

`coverage[].scenario_type ∈ {boundary, abnormal, stress, recovery}` 任一命中 → `■`；否则 `□`（`derive.robustness_mark` / `spec.is_robust`）。

- 字符用全角 `■`（U+25A0）与 `□`（U+25A1）——数据源里没有这两个字符，必须由程序生成。
- 场景实测分布（按 coverage 条目）：`normal` 120、`boundary` 22、`abnormal` 5、`stress` 0、`recovery` 0；命中健壮性的**条目**为 27 项（报告附录F 的 F-23 判定依据即此数）。
- 附录A.5/A.6/A.7 不建表，只写“本类用例共 N 项，已在所属测试项目表的“健壮性”列中标注为实心方框，编号：…”；`stress`/`recovery` 为 0 时写“本版本无此类测试用例。”。

## 4. 用例标识：项目标识 ≠ 用例编号

| 概念 | 形态 | 写在哪 | 来源 |
|---|---|---|---|
| 项目标识 | `QR-<类型码>-<3 位序号>`，如 `QR-XY-007` | 用例表 R0 的“项目标识”、表7/表2 的“测试项目标识”、4.4 正文 | `derive.Project.ident`；前缀 `QR`（`derive.STAGE_PREFIX`），序号为项目序号 |
| 用例编号 | **原样** `TC-033` / `EP-049` | 用例表数据行“编号”列、表6/表8/表11/附录B/D 的用例列 | `test_case_id` / `procedure_id`，**不改写** |

两者联合定位：项目标识定位分组，编号与 RTM、覆盖报告逐字一致。不要用 `QR-…` 去替换编号列，也不要把 `TC-…` 写进项目标识列。`1.3`/`7.2` 的命名规则说明段已固定写为“`QR-<测试类型码>-<序号>`，用例表中的“编号”列给出与追溯矩阵、覆盖报告一致的用例标识”。

## 5. 缺口四档短语

`contract.py` 的四个短语常量是唯一写法：

| 情形 | 文档写法 | 常量 | 缺口 `kind` |
|---|---|---|---|
| FEIP `status=unknown` | `任务书未规定` | `PHRASE_UNKNOWN` | `unknown` |
| FEIP 无该对象/字段（`absent`） | `任务书未涉及` | `PHRASE_UNSPECIFIED` | `absent` |
| FEIP `status=conflict` | `任务书存在冲突，待确认` | `PHRASE_CONFLICT` | `conflict` |
| 需要但上游未提供（人员、工作量、检查日期） | `待填` | `PHRASE_TODO` | `missing` |
| 结果项（实际结果/测试结论/未通过数量/符合情况） | `-` | `PHRASE_RESULT` | `result`（不登记） |
| 非缺口的空值占位 | `—` | `PHRASE_ABSENT` | 不登记 |

`GapRegistry` 按 `(kind, location, field, reason)` 去重，所以同一缺口在正文多处出现只记一次；`缺口清单.md` 的 `类型` 列直接输出 `kind`。

实测清单（try14，13 项）：`unknown 3 / absent 9 / missing 1`。逐条：

| # | kind | location | field | 原因摘要 |
|---|---|---|---|---|
| 1 | unknown | plan.1.2.1 | `system_overview.long_term_power_on` | 任务书未明确长期加电要求 |
| 2 | unknown | report.3.5.1 | `analysis.signals[].active_level` | 136/136 条信号有效电平为 unknown |
| 3–7 | absent | report.3.5.2 / 3.5 / 3 / 3.4 | `analysis.clocks`、`resets`、`constraints`、`power`、`dependability` | FEIP 无对应结构化对象 |
| 8 | absent | plan.3 | `verification.environments` | 无测试环境与设备清单，设备按 `setup` 派生 |
| 9 | missing | plan.5 | 工作量与人员安排 | 任务书与 FEIP 均未提供 |
| 10 | absent | plan.7.6.2 | 新状态识别 | FEIP 无新状态对象 |
| 11 | unknown | plan.7.6.3 | `safety_critical` | 全为 null，按类目 `reliability` 派生 |
| 12–13 | absent | report.3.3 / 5.2 | `requirements[UR-FREQ-16].semantic.statement` | 上游原文退化为表格片段 |

## 6. “不编造”清单（FEIP 实测为空，一律写缺口）

| 槽位/内容 | FEIP 实测 | 处理 |
|---|---|---|
| 时钟频率与占空比 | `analysis.clocks` 0 条 | `任务书未涉及` + 缺口；3.5.2.1 正文从需求原文还原 |
| 复位极性与时宽 | `analysis.resets` 0 条 | 同上 |
| 工程约束 | `analysis.constraints` 0 条 | 缺口 |
| 供电与功耗 | `analysis.power` 0 条 | 缺口（不填电压/电流/功耗数字） |
| 可靠性与安全性指标 | `analysis.dependability` 0 条 | 缺口 |
| 测试环境与仪器 | `verification.environments` 0 条 | 设备表按 `test_cases[].setup` 关键字派生，状态/数量写 `待填` |
| 信号有效电平 | `analysis.signals[].active_level` 136/136 为 `unknown` | 缺口；极性只在任务书表 4-3 备注列，需回归档表 `cells[]` |
| 温度、功耗、重量、尺寸、辐照 | 530 个归档元素中 0 命中 | 不填，全部写缺口 |
| 安全关键标记 | `semantic.safety_critical` 全为 null | 按需求类目 `reliability` 派生，记 `unknown` 缺口，需人工确认 |
| 新状态清单 | 无对应对象（需求属性 N 无字段） | 表10 写 `待填/任务书未规定/待填` + 缺口 |
| 人员、工作量、检查日期/地点/阶段 | 输入完全没有 | `待填` + `missing` 缺口 |
| 实测结果 | 本版本无执行记录 | 一律 `-` |

**禁止**：把模板示例值（`××FPGA`、`5.1`、`25`、`RST-001`、`XX-KeySafty-XX-001`）当真实值；用“按要求连接”式泛化文本充数。

## 7. 退化原文过滤

上游把表格单元格片段误当需求正文（形如 `col=3;row_span=2`）。`derive` 的判定规则：

```text
命中 r"col=\d+\s*;\s*row_span="  → 退化
或 r"col=\d+" 出现 ≥3 次          → 退化
```

`derive.clean_statement()` 对退化文本返回空串；`report_content._statement()` 见到空串则写 `任务书未规定` 并登记 `absent` 缺口（`requirements[<需求编号>].semantic.statement`，影响列“正文描述缺失”，建议“回归档表 cells[] 重建该条需求原文”）。

实测：`UR-FREQ-16` 命中，在 `report.3.3` 与 `report.5.2` 各登记一次（位置不同，故不去重）。3.5.2 也走 `clean_statement`，但不登记缺口——以实现为准。

## 8. 结果项与统计口径

| 项 | 规则 | 实测 |
|---|---|---|
| 实际结果 / 测试结论（用例表） | 固定 `-` | 121 行全 `-` |
| 未通过数量（报告表2） | 固定 `-` | 10 行 `-` + 总计行 `-` |
| 符合情况（报告表6） | 固定 `-` | 29 行 `-` |
| 用例总数 | `len(test_cases)+len(evidence_procedures)` | 63 + 58 = 121 |
| 测试项目数 | 分组成员数 | 10 |
| 需求数 | `RTM.csv` 的 `requirement_uid` 去重（保序）；RTM 缺失时退 FEIP 需求 | 119 |
| 测试要点数 | `verification.source_test_points` 条数 | 20 |
| 覆盖率 | 需求覆盖 = 有 `linked_specification_ids` 的需求数 / 需求数 | 119/119 = 100% |
| 用例表“测试要点”列、表9“测试标识”、报告表3“测试要点编号” | 由条目的 `obligation_ids` → 义务的 `test_point_refs` 取 uid 尾段，得 `tblA-n`；统一走 `derive.test_point_ident` | **不用 `source_id`**：那只是任务书的 1…20 序号，会与表内自动编号的“序号”列撞成两列同样的数字 |

计划表7 的“总计”行写 `121`；报告表2 的“总计”行写 `121` 与 `-`（`未通过数量` 是结果项，写 `-`）。模板的“总计/合计”合并格结构保持不动。

## 标题清洗

上游 `requirements[].title` 常带 `——原子义务N` 后缀（如“系统时钟复位——原子义务1”），直接做 3.3.x 标题很难看。`derive.clean_title` 去掉该后缀，`derive.unique_titles` 只在同名重复时补 `（1）（2）…`：

| 原始标题 | 3.3.x 标题 |
|---|---|
| 系统时钟复位——原子义务1 | 系统时钟复位（1） |
| 系统时钟复位——原子义务2 | 系统时钟复位（2） |
| 加载要求——反熔丝器件无需程序存储器和加载控制芯片——原子义务1 | 加载要求——反熔丝器件无需程序存储器和加载控制芯片 |
| 下行遥测数据帧格式——原子义务2（板级测试） | 下行遥测数据帧格式（板级测试） |

`——原子义务N` 在**任意位置**都被清除（不只在行尾），后面跟着 `（板级测试）` 这类括号时保留括号。
3.3 功能概述改为单节平铺后不再用它做标题，仅用于用例表“测试目的”、不可测试项描述与追溯表需求项名称。该函数用于 3.3.x 标题、用例表“测试目的”列、不可测试项描述，以及**所有追溯表的需求项名称列**（表6、表8、表11、B.1/B.2、报告表5、D.1/D.2）。

追溯表用 `_title_map` 去重：同一需求名出现多次时补 `（1）（2）…`，例如表6 的三行显示为`系统时钟复位（1）`、`系统时钟复位（2）`、`系统时钟复位（3）`，避免同名无法区分。
