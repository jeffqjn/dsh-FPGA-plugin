# -*- coding: utf-8 -*-
"""Offline skill CLI; rejects every Python except 3.8.10."""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from confdoc.base import SkillError, check_runtime, runtime_report  # noqa: E402
from confdoc import contract  # noqa: E402

ACTIONS = ("doctor", "self-test", "inspect", "section", "plan", "report", "both")


def build_parser():
    parser = argparse.ArgumentParser(
        prog="confdoc", description="Generate FPGA confirmation test plan and report DOCX"
    )
    parser.add_argument("action", choices=ACTIONS)
    parser.add_argument("--source", help="FEIP package directory")
    parser.add_argument("--spec", help="path to test_specification.json")
    parser.add_argument("--plan", help="path to verification_plan.json")
    parser.add_argument("--coverage", help="path to coverage_report.json")
    parser.add_argument("--rtm", help="path to RTM.csv")
    parser.add_argument("--plan-docx", dest="plan_docx", help="published plan docx for incremental mode")
    parser.add_argument("--out", help="output directory (must not exist)")
    parser.add_argument("--no-markdown", dest="no_markdown", action="store_true")
    parser.add_argument("--case-table", dest="case_table", default="1", choices=("1", "2"))
    parser.add_argument("--dry-run", dest="dry_run", action="store_true")
    # read-only inspection of a produced document, for hosts with a reply cap
    parser.add_argument("--docx", help="document to inspect with the section action")
    parser.add_argument("--heading", help="section heading (number or text prefix)")
    parser.add_argument("--max-chars", dest="max_chars", type=int, default=4000,
                        help="character budget for the section action (default 4000)")
    parser.add_argument("--list", action="store_true", help="list section headings only")
    parser.add_argument("--result-max-chars", dest="result_max_chars", type=int, default=8000,
                        help="if the JSON result exceeds this, write it to a file and print a pointer")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        check_runtime()
        result = dispatch(args)
        text = json.dumps(result, ensure_ascii=False, allow_nan=False)
        limit = args.result_max_chars or 8000
        if len(text) > limit:
            from confdoc.base import write_json

            target = os.path.join(args.out or os.getcwd(), "result-%s.json" % (args.action,))
            write_json(target, result)
            text = json.dumps(
                {
                    "action": args.action,
                    "ok": True,
                    "inline_truncated": True,
                    "chars": len(text),
                    "result_file": target,
                },
                ensure_ascii=False,
            )
        print(text)
        print("FEIP_SKILL_OK:" + args.action)
        return 0
    except SkillError as exc:
        print("FEIP_SKILL_ERROR: " + exc.message, file=sys.stderr)
        print(json.dumps(exc.as_dict(), ensure_ascii=False), file=sys.stderr)
        return 2
    except Exception as exc:  # noqa: BLE001 - CLI boundary
        print("FEIP_SKILL_ERROR: " + str(exc), file=sys.stderr)
        return 2


def dispatch(args):
    if args.action == "doctor":
        return doctor()
    if args.action == "self-test":
        from confdoc import selftest

        return selftest.run_all()
    if args.action == "section":
        return inspect_section(args)
    options = contract.Options(vars(args))
    from confdoc import assemble

    if args.action == "inspect":
        return inspect_inputs(options)
    ctx = assemble.build_context(options)
    kinds = {DOCS["plan"], DOCS["report"]} if args.action == "both" else {DOCS[args.action]}
    if args.dry_run:
        return {
            "action": args.action,
            "dry_run": True,
            "product": ctx["product"],
            "version": ctx["version"],
            "items": ctx["stats"]["total"],
            "projects": len(ctx["projects"]),
            "gaps": ctx["gaps"].by_kind(),
        }
    manifest = assemble.publish(ctx, options, kinds)
    return {
        "action": args.action,
        "out": options.out,
        "artifacts": [entry["path"] for entry in manifest["artifacts"]],
        "counts": manifest["counts"],
        "gaps": manifest["gaps"],
    }


def inspect_section(args):
    """Print one chapter of a produced document, with a hard character budget."""
    from confdoc import inspectdoc

    if not args.docx:
        raise SkillError("OPTION_REQUIRED", "the section action needs --docx", {})
    if args.list:
        outline = inspectdoc.headings(args.docx)
        return {"action": "section", "outline": [entry["text"] for entry in outline]}
    if not args.heading:
        raise SkillError("OPTION_REQUIRED", "the section action needs --heading (or --list)", {})
    result = inspectdoc.section(args.docx, args.heading, max_chars=args.max_chars or 4000)
    result["action"] = "section"
    return result


DOCS = {"plan": contract.DOC_PLAN, "report": contract.DOC_REPORT, "both": contract.DOC_PLAN}


def doctor():
    report = runtime_report(os.environ.get("FPGA_PYTHON38"))
    report["templates"] = {}
    for kind in (contract.DOC_PLAN, contract.DOC_REPORT):
        path = contract.template_path(kind)
        report["templates"][os.path.basename(path)] = os.path.getsize(path)
    report["rules_present"] = os.path.isfile(os.path.join(contract.RULES_DIR, "conformance_rules.json"))
    return report


def inspect_inputs(options):
    from confdoc.feip import FeipPackage
    from confdoc.spec import Specification

    feip = FeipPackage(options.require("source"))
    spec = Specification(
        options.require("spec"),
        plan_path=contract.input_path(options.spec, "plan", options.plan),
        coverage_path=contract.input_path(options.spec, "coverage", options.coverage),
        rtm_path=contract.input_path(options.spec, "rtm", options.rtm),
    )
    validation = spec.validate()
    return {
        "action": "inspect",
        "feip": {
            "profile": feip.profile,
            "synthetic": feip.synthetic,
            "status": feip.status,
            "model": os.path.basename(feip.model_path),
            "requirements": len(feip.requirement_uids()),
            "readiness": {
                view: feip.readiness(view)[0] for view in ("confirmation", "simulation", "architecture")
            },
        },
        "specification": {
            "test_cases": len(spec.cases),
            "evidence_procedures": len(spec.procedures),
            "schema_version": spec.schema_version,
            "design_status": spec.design_status(),
            "execution_status": spec.execution_status(),
        },
        "validation": validation,
        "counts": spec.coverage_counts(),
        "metrics": spec.coverage_metrics(),
    }


if __name__ == "__main__":
    sys.exit(main())
