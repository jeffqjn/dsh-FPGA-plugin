# -*- coding: utf-8 -*-
"""test-spec-gen: generate FPGA confirmation test plan and report DOCX.

Consumes the ``test-specification`` family outputs plus a FEIP package and
performs template surgery on the two mandated Word templates.
"""

__all__ = ["base", "docxlib"]
