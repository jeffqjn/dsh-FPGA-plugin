# -*- coding: utf-8 -*-
"""Orchestration: build the context, run the content modules, apply the gates,
then publish the artefacts atomically.
"""
import os
import zipfile
import xml.etree.ElementTree as ET

from . import contract, derive, plan_content
from .base import (
    SkillError,
    canonical_sha256,
    file_sha256,
    guard_output_not_exists,
    guard_output_outside_input,
    ensure_directory,
    write_json,
    write_text,
)
from .contract import (
    DOC_PLAN,
    DOC_REPORT,
    GapRegistry,
    PHRASE_TODO,
    PHRASE_UNKNOWN,
    PHRASE_UNSPECIFIED,
    output_names,
    markdown_name,
    template_path,
)
from .docxlib import Docx, read_document_text
from .feip import FeipPackage
from .spec import Specification

RESIDUAL_PATTERNS = ("/*", "*/", "××", "XX", "……", "例如：", "示例：")
RESIDUAL_ALLOWED_TEXTS = ("……", "修改FPGA")

# Fixed-shape tables whose row count is dictated by the template, not by data.
FIXED_TABLE_ROWS = {
    DOC_PLAN: (
        ("FPGA运行硬件环境", 5),
        ("环境及工具表", 9),
        ("硬件说明表", 5),
        ("差异性分析表", 3),
    ),
    DOC_REPORT: (
        ("FPGA设计确认环境及工具表", 7),
    ),
}


def build_context(options):
    """Resolve inputs and derive everything the content modules need."""
    gaps = GapRegistry()
    feip = FeipPackage(options.require("source"))

    spec = Specification(
        options.require("spec"),
        plan_path=contract.input_path(options.spec, "plan", options.plan),
        coverage_path=contract.input_path(options.spec, "coverage", options.coverage),
        rtm_path=contract.input_path(options.spec, "rtm", options.rtm),
    )
    validation = spec.validate()

    product = _value(feip.basic("product_name"), PHRASE_TODO, gaps, "plan.1.1", "basic_info.product_name")
    config_code = _value(feip.basic("config_item_code"), PHRASE_UNKNOWN, gaps, "plan.1.1", "basic_info.config_item_code")
    development_type = _value(feip.basic("development_type"), PHRASE_UNKNOWN, gaps, "plan.1.1", "basic_info.development_type")
    safety_level = _value(feip.basic("safety_level"), PHRASE_UNKNOWN, gaps, "plan.1.1", "basic_info.safety_level")
    maintenance_base = _value(feip.basic("maintenance_base"), PHRASE_UNKNOWN, gaps, "plan.1.1", "basic_info.maintenance_base")
    assigner = _value(feip.basic("assigner"), PHRASE_UNKNOWN, gaps, "plan.1.1", "basic_info.assigner")
    contractor = _value(feip.basic("contractor"), PHRASE_UNKNOWN, gaps, "plan.1.1", "basic_info.contractor")
    version = _value(feip.meta_fact("version"), "", gaps, "cover", "meta.version")
    basis_title = _value(feip.meta_fact("title"), "任务书", gaps, "1.3", "meta.title")

    overview = {
        "host_unit": _value(feip.overview("host_unit"), "", gaps, "plan.1.2.1", "system_overview.host_unit"),
        "subsystem_composition": _value(feip.overview("subsystem_composition"), "", gaps, "plan.1.2.1", "system_overview.subsystem_composition"),
        "main_functions": _value(feip.overview("main_functions"), "", gaps, "plan.1.2.1", "system_overview.main_functions"),
        "long_term_power_on": _value(feip.overview("long_term_power_on"), PHRASE_UNKNOWN, gaps, "plan.1.2.1", "system_overview.long_term_power_on"),
    }
    if not overview["host_unit"] and not overview["main_functions"]:
        gaps.add("absent", "plan.1.2.1", "system_overview", "任务书未给出系统组成与任务描述", "1.2.1 系统组成和任务概述")

    projects = derive.group_items(spec, feip)
    stats = derive.statistics(projects)
    method_counts = []
    for method in ("board_test", "system_test", "inspection", "analysis", "timing_analysis", "review"):
        count = 0
        for item in spec.items:
            if item["method"] == method:
                count += 1
        if count:
            method_counts.append((method, count))

    scenario_projects = {}
    for scenario in ("boundary", "stress", "recovery", "abnormal"):
        found = [item for item in spec.items if scenario in spec.scenario_types(item)]
        if found:
            scenario_projects["@" + scenario] = found

    rtm_requirements = spec.rtm_requirements()
    if not rtm_requirements:
        rtm_requirements = feip.requirement_uids()

    ctx = {
        "feip": feip,
        "spec": spec,
        "gaps": gaps,
        "options": options,
        "validation": validation,
        "chip_model": _value(
            feip.basic("chip_model"), PHRASE_UNKNOWN, gaps, "1.1", "basic_info.chip_model"
        ),
        "product": product,
        "config_code": config_code,
        "development_type": development_type,
        "safety_level": safety_level,
        "maintenance_base": maintenance_base,
        "assigner": assigner,
        "contractor": contractor,
        "version": version,
        "basis_title": basis_title,
        "overview": overview,
        "equipment": derive.equipment_from_setups(spec),
        "projects": projects,
        "stats": stats,
        "method_counts": method_counts,
        "requirement_count": len(rtm_requirements),
        "rtm_requirements": rtm_requirements,
        "scenario_projects": scenario_projects,
        "difference_rows": _difference_rows(ctx_placeholder(feip, gaps)),
        "substitutions": _substitutions(product, basis_title, config_code),
    }
    _note_design_gaps(feip, gaps)
    return ctx


def _note_design_gaps(feip, gaps):
    """Record design-data gaps that affect the documents, without guessing them."""
    signals = feip.signals()
    if signals:
        unknown = 0
        for signal in signals:
            value = signal.get("active_level")
            if not isinstance(value, str) or value.strip() in ("", "unknown", "absent", "conflict"):
                unknown += 1
        if unknown:
            gaps.add(
                "unknown",
                "report.3.5.1",
                "analysis.signals[].active_level",
                "有效电平未结构化，%d/%d 条信号的 active_level 为 unknown；极性语义仅在任务书表4-3备注列"
                % (unknown, len(signals)),
                "3.5.1 接口定义、F-13 极性设计",
                "需要时回归档表 cells[] 还原极性并补录",
            )
    for name, label, location in (
        ("clocks", "时钟频率与占空比", "report.3.5.2"),
        ("resets", "复位极性与时宽", "report.3.5.2"),
        ("constraints", "工程约束", "report.3.5"),
        ("power", "供电与功耗", "report.3"),
        ("dependability", "可靠性与安全性指标", "report.3.4"),
    ):
        if not feip.collection(name):
            gaps.add(
                "absent",
                location,
                "analysis.%s" % (name,),
                "FEIP 无 %s 结构化对象，相关%s从需求原文还原" % (name, label),
                label,
            )
    if not feip.collection("environments"):
        gaps.add(
            "absent",
            "plan.3",
            "verification.environments",
            "FEIP 未给出测试环境与设备清单，测试设备表按用例 setup 中出现的设备派生",
            "3 测试环境",
        )


def ctx_placeholder(feip, gaps):
    return {"feip": feip, "gaps": gaps}


def _value(fact, fallback, gaps, location, field):
    if fact is None:
        gaps.add("absent", location, field, "字段缺失", "")
        return fallback
    if fact.present and fact.display:
        return fact.display
    phrase = gaps.phrase_for(fact, location, field, "")
    if phrase in (PHRASE_UNKNOWN, PHRASE_UNSPECIFIED, ""):
        return fallback if fallback else phrase
    return phrase


def _difference_rows(holder):
    """Real, evidenced difference: flight part versus electrical-engineering part."""
    feip = holder["feip"]
    gaps = holder["gaps"]
    platforms = feip.platforms()
    rows = []
    if not platforms:
        gaps.add(
            "absent",
            "plan.3.2",
            "analysis.platform_resources",
            "任务书未给出器件资源与封装信息，无法开展环境差异性分析",
            "3.2 测试环境差异性分析",
        )
        return rows
    names = []
    parameters = []
    for platform in platforms:
        header = platform.get("header") or {}
        names.append(header.get("name") or "")
        pairs = []
        for parameter in platform.get("parameters") or []:
            label = parameter.get("name") or ""
            value = parameter.get("text") or parameter.get("value")
            if label and value:
                pairs.append("%s=%s" % (label, value))
        parameters.append("、".join(pairs))
    for index, name in enumerate(names):
        rows.append(
            [
                "",
                name,
                parameters[index] if parameters[index] else PHRASE_UNKNOWN,
                "器件型号与资源规模差异已在 1.1 与 3.1 中说明；确认测试按实际装机器件执行，"
                "对时序与资源余量相关项应在正样件上复测。",
            ]
        )
    return rows


def _substitutions(product, basis_title, config_code):
    return [
        ("××FPGA产品需求规格说明", "《%s》" % (basis_title,)),
        ("×× FPGA产品需求规格说明", "《%s》" % (basis_title,)),
        ("××FPGA产品设计确认计划", "本计划"),
        ("××FPGA产品研制计划流程", "项目研制计划"),
        ("×× FPGA产品研制计划流程", "项目研制计划"),
        ("××FPGA产品项目开发计划", "项目开发计划"),
        ("×× FPGA产品项目开发计划", "项目开发计划"),
        ("××FPGA产品", product),
        ("×× FPGA产品", product),
        ("××FPGA", product),
        ("×× FPGA", product),
        ("××接口通讯", "接口通讯"),
        ("××系统方案", "%s研制方案" % (product,)),
        ("××", ""),
        ("XX卫星XX分系统XXFPGA", product),
        ("xxFPGA", product),
        ("F/XXX-X/01-X.XX", config_code),
    ]


# ---------------------------------------------------------------------------
# generation
# ---------------------------------------------------------------------------
def generate_plan(ctx):
    doc = Docx(template_path(DOC_PLAN))
    signature = [(entry["level"], entry["number"], entry["text"]) for entry in doc.heading_tree()]
    sections = doc.block_xml().count("<w:sectPr")
    builder = plan_content.build(doc, ctx)
    _gate_plan(doc, signature, builder, ctx, sections)
    return doc, builder


def generate_report(ctx, plan_doc_texts=None):
    from . import report_content

    doc = Docx(template_path(DOC_REPORT))
    signature = [(entry["level"], entry["number"], entry["text"]) for entry in doc.heading_tree()]
    sections = doc.block_xml().count("<w:sectPr")
    builder = report_content.build(doc, ctx, plan_doc_texts=plan_doc_texts)
    _gate_report(doc, signature, builder, ctx, sections)
    return doc, builder


# ---------------------------------------------------------------------------
# gates
# ---------------------------------------------------------------------------
def _cross_check_plan(plan_doc, ctx):
    """The report must agree with the plan that was actually issued.

    Reads the plan's 测试用例统计表 back and compares it with what the current
    specification would produce.  A mismatch is a hard conflict: it means the
    specification changed after the plan was published.
    """
    table = None
    for candidate in plan_doc.tables():
        try:
            header = candidate.row(0).texts()
        except SkillError:
            continue
        joined = "".join(header)
        if "测试项目标识" in joined and "用例数量" in joined:
            table = candidate
            break
    if table is None:
        ctx["validation"].setdefault("warnings", []).append(
            {"code": "PLAN_STATS_UNREADABLE", "detail": "plan docx has no 测试用例统计表; cross-check skipped"}
        )
        return
    found = set()
    total = None
    for row in table.rows()[1:]:
        texts = [text.strip() for text in row.texts()]
        if not texts:
            continue
        if "总计" in texts[0]:
            total = texts[-1]
            continue
        if len(texts) >= 4 and texts[2]:
            found.add((texts[1], texts[2], texts[3]))
    expected = set((project.label, project.ident, str(project.count)) for project in ctx["projects"])
    total_expected = str(ctx["stats"]["total"])
    if found != expected or (total is not None and total != total_expected):
        raise SkillError(
            "PLAN_SPEC_CONFLICT",
            "published plan disagrees with the specification",
            {
                "missing_in_plan": sorted(expected - found),
                "extra_in_plan": sorted(found - expected),
                "plan_total": total,
                "spec_total": total_expected,
            },
        )
    ctx["validation"].setdefault("warnings", []).append(
        {"code": "PLAN_SPEC_CONSISTENT", "detail": "plan 测试用例统计表 matches the specification"}
    )


def _gate_fixed_tables(doc, expectations):
    """Equipment and difference tables must keep the template's row categories."""
    problems = []
    for needle, expected in expectations:
        found = None
        for index in range(doc.block_count()):
            if doc.block_kind(index) != "p":
                continue
            if needle in doc.paragraph(index).text:
                for cursor in range(index + 1, doc.block_count()):
                    if doc.block_kind(cursor) == "tbl":
                        found = doc.table(cursor)
                        break
                break
        if found is None:
            problems.append({"table": needle, "error": "missing"})
        elif found.row_count() != expected:
            problems.append({"table": needle, "expected": expected, "actual": found.row_count()})
    if problems:
        raise SkillError(
            "TEMPLATE_CONFORMANCE",
            "fixed table shape deviates from the template",
            {"problems": problems},
        )


def _gate_sections(doc, expected):
    """A lost ``sectPr`` merges the portrait body with the landscape appendices."""
    actual = doc.block_xml().count("<w:sectPr")
    if actual != expected:
        raise SkillError(
            "NUMBERING_BROKEN",
            "section breaks changed: %d expected, %d found" % (expected, actual),
            {"expected": expected, "actual": actual},
        )


def _gate_plan(doc, signature, builder, ctx, sections):
    after = [(entry["level"], entry["number"], entry["text"]) for entry in doc.heading_tree()]
    if after != signature:
        raise SkillError(
            "HEADING_DRIFT",
            "plan heading structure changed",
            {"before": signature, "after": after},
        )
    _gate_sections(doc, sections)
    _gate_fixed_tables(doc, FIXED_TABLE_ROWS[DOC_PLAN])
    _gate_residual(builder, ctx, allow_box=False)
    _gate_data(doc, ctx)
    for index in range(doc.block_count()):
        if doc.block_kind(index) == "p":
            para = doc.paragraph(index)
            if para.style in ("1", "2", "3") and not para.text.strip():
                raise SkillError("NUMBERING_BROKEN", "empty heading left in plan", {"index": index})


def _gate_report(doc, signature, builder, ctx, sections):
    after = [(entry["level"], entry["number"], entry["text"]) for entry in doc.heading_tree()]
    # 3.3.x (功能概述) and 3.5.2.x (接口时序) are rebuilt from the requirements on
    # purpose; every other original heading must survive untouched.
    protected = [
        entry
        for entry in signature
        if not (entry[1].startswith("3.3.") or entry[1].startswith("3.5.2."))
    ]
    if not _is_subsequence(protected, after):
        raise SkillError(
            "HEADING_DRIFT",
            "report heading structure lost original headings",
            {"protected": protected, "after": after},
        )
    _gate_sections(doc, sections)
    _gate_fixed_tables(doc, FIXED_TABLE_ROWS[DOC_REPORT])
    for entry in after:
        if entry[0] >= 3 and entry[1].startswith("3.3.") and not entry[2].strip():
            raise SkillError("NUMBERING_BROKEN", "empty 3.3.x heading left in report", {"entry": entry})
    _gate_residual(builder, ctx, allow_box=True)
    _gate_data(doc, ctx)


def _is_subsequence(needle, haystack):
    cursor = 0
    for entry in haystack:
        if cursor < len(needle) and entry == needle[cursor]:
            cursor += 1
    return cursor == len(needle)


def _gate_residual(builder, ctx, allow_box=True):
    hits = builder.find_residual(RESIDUAL_PATTERNS)
    filtered = []
    for hit in hits:
        text = hit.get("text") or ""
        if text.strip() in RESIDUAL_ALLOWED_TEXTS:
            continue
        filtered.append(hit)
    if filtered:
        raise SkillError(
            "RESIDUAL_PLACEHOLDER",
            "template placeholders remain in %d location(s)" % (len(filtered),),
            {"hits": filtered[:20]},
        )
    # Checkbox glyphs belong to table cells only (健壮性列、勾选表、问题报告单).
    stray = []
    for para in builder.doc.paragraphs():
        text = para.text
        if "■" in text or "□" in text:
            stray.append({"block": para.index, "text": text[:80]})
    if stray:
        raise SkillError(
            "RESIDUAL_PLACEHOLDER",
            "checkbox glyph found in body text",
            {"hits": stray[:10]},
        )


def _gate_data(doc, ctx):
    spec = ctx["spec"]
    blob = []
    for index in range(doc.block_count()):
        if doc.block_kind(index) != "tbl":
            continue
        for row in doc.table_texts(index):
            blob.append("|".join(row))
    joined = "\n".join(blob)
    missing = []
    for item in spec.items:
        if item["id"] not in joined:
            missing.append(item["id"])
    if missing:
        raise SkillError(
            "DATA_INCOMPLETE",
            "%d specification item(s) never appear in a table" % (len(missing),),
            {"missing": missing[:20]},
        )


def _gate_readable(path):
    try:
        with zipfile.ZipFile(path, "r") as archive:
            payload = archive.read("word/document.xml")
        ET.fromstring(payload)
    except Exception as exc:  # noqa: BLE001 - any failure means Word would refuse
        raise SkillError(
            "DOCX_UNREADABLE", "generated document cannot be reopened: %s" % (str(exc),), {"path": path}
        )


# ---------------------------------------------------------------------------
# publishing
# ---------------------------------------------------------------------------
def publish(ctx, options, kinds):
    out = options.require("out")
    guard_output_outside_input(out, [options.source, os.path.dirname(os.path.abspath(options.spec))])
    guard_output_not_exists(out)
    ensure_directory(out)

    inputs_before = _input_digests(options)
    artefacts = []

    plan_texts = None
    docs = {}
    plan_doc = None
    if DOC_PLAN in kinds:
        plan_doc, plan_builder = generate_plan(ctx)
        docs[DOC_PLAN] = (plan_doc, plan_builder)
    elif options.plan_docx:
        if not os.path.isfile(options.plan_docx):
            raise SkillError(
                "INPUT_NOT_FOUND", "plan docx not found", {"path": options.plan_docx}
            )
        plan_doc = Docx(options.plan_docx)
    else:
        # 附录F has checklist items that point at the plan; build it in memory so
        # they can be judged instead of being reported as false defects.
        plan_doc, _plan_builder = generate_plan(ctx)
    ctx["plan_doc"] = plan_doc
    _cross_check_plan(plan_doc, ctx)
    if DOC_REPORT in kinds:
        doc, builder = generate_report(ctx)
        docs[DOC_REPORT] = (doc, builder)

    for kind in kinds:
        doc, builder = docs[kind]
        name = output_names(ctx["product"], ctx["version"], kind)
        path = os.path.join(out, name)
        label = "确认测试计划" if kind == DOC_PLAN else "确认测试报告"
        doc.set_core_title("%s %s" % (ctx["product"], label))
        doc.save(path)
        _gate_readable(path)
        artefacts.append(_artefact("document", name, path, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
        if options.markdown:
            md_name = markdown_name(kind)
            write_text(os.path.join(out, md_name), export_markdown(doc, ctx))
            artefacts.append(_artefact("markdown", md_name, os.path.join(out, md_name), "text/markdown"))
        write_json(
            os.path.join(out, "fill-map-%s.json" % (kind,)),
            {"document": kind, "template": os.path.basename(template_path(kind)), "entries": builder.fill_map},
        )
        artefacts.append(
            _artefact("fill-map", "fill-map-%s.json" % (kind,), os.path.join(out, "fill-map-%s.json" % (kind,)), "application/json")
        )

    gaps = ctx["gaps"]
    write_text(os.path.join(out, "缺口清单.md"), _render_gaps(ctx))
    artefacts.append(_artefact("gap-list", "缺口清单.md", os.path.join(out, "缺口清单.md"), "text/markdown"))

    conformance_md = _render_conformance(ctx)
    if conformance_md:
        write_text(os.path.join(out, "产保要素自检表.md"), conformance_md)
        artefacts.append(
            _artefact("conformance", "产保要素自检表.md", os.path.join(out, "产保要素自检表.md"), "text/markdown")
        )

    write_text(os.path.join(out, "生成检查报告.md"), _render_check_report(ctx, artefacts))
    artefacts.append(_artefact("check-report", "生成检查报告.md", os.path.join(out, "生成检查报告.md"), "text/markdown"))

    inputs_after = _input_digests(options)
    if inputs_before != inputs_after:
        raise SkillError("INPUT_MUTATED", "input digests changed during generation", {})

    manifest = {
        "protocol_version": "1.0.0",
        "skill": "test-spec-gen",
        "status": "complete",
        "profile": ctx["feip"].profile,
        "synthetic": ctx["feip"].synthetic,
        "package_uid": ctx["feip"].package_uid,
        "product": ctx["product"],
        "version": ctx["version"],
        "artifacts": artefacts,
        "inputs": inputs_after,
        "template_sha256": {
            DOC_PLAN: file_sha256(template_path(DOC_PLAN)),
            DOC_REPORT: file_sha256(template_path(DOC_REPORT)),
        },
        "specification_sha256": canonical_sha256(ctx["spec"].raw),
        "counts": {
            "requirements": ctx["requirement_count"],
            "projects": len(ctx["projects"]),
            "items": ctx["stats"]["total"],
            "test_cases": len(ctx["spec"].cases),
            "evidence_procedures": len(ctx["spec"].procedures),
        },
        "gaps": gaps.by_kind(),
    }
    write_json(os.path.join(out, "package.json"), manifest)
    return manifest


def _artefact(role, name, path, media_type):
    return {
        "role": role,
        "path": name,
        "media_type": media_type,
        "sha256": file_sha256(path),
        "size_bytes": os.path.getsize(path),
    }


def _input_digests(options):
    digests = {}
    for label, path in (
        ("source_package", options.source),
        ("specification", options.spec),
        ("plan", contract.input_path(options.spec, "plan", options.plan)),
        ("coverage", contract.input_path(options.spec, "coverage", options.coverage)),
        ("rtm", contract.input_path(options.spec, "rtm", options.rtm)),
        ("plan_docx", options.plan_docx),
    ):
        if not path:
            continue
        if os.path.isfile(path):
            digests[label] = file_sha256(path)
            continue
        if os.path.isdir(path):
            # a FEIP package is a directory: bind its manifest and engineering model
            for name in ("package.json", "model.json"):
                candidate = os.path.join(path, name)
                if os.path.isfile(candidate):
                    digests[label + "/" + name] = file_sha256(candidate)
    return digests


def export_markdown(doc, ctx):
    lines = ["# %s" % (ctx["product"],), ""]
    numbers = dict((entry["index"], entry["number"]) for entry in doc.heading_tree())
    for index in range(doc.block_count()):
        kind = doc.block_kind(index)
        if kind == "p":
            text = doc.paragraph_texts(index).strip()
            if not text:
                continue
            style = doc.paragraph(index).style
            if style in ("1", "2", "3", "4"):
                level = int(style)
                number = numbers.get(index, "")
                lines.append("")
                lines.append("%s %s%s" % ("#" * (level + 1), (number + " ") if number else "", text))
                lines.append("")
            else:
                lines.append(text)
                lines.append("")
        elif kind == "tbl":
            rows = doc.table_texts(index)
            if not rows:
                continue
            width = max(len(row) for row in rows)
            lines.append("")
            lines.append("| " + " | ".join(_md_cell(rows[0], i) for i in range(width)) + " |")
            lines.append("|" + "|".join([" --- "] * width) + "|")
            for row in rows[1:]:
                lines.append("| " + " | ".join(_md_cell(row, i) for i in range(width)) + " |")
            lines.append("")
    return "\n".join(lines).replace("\n\n\n", "\n\n") + "\n"


def _heading_number(doc, index):
    for entry in doc.heading_tree():
        if entry["index"] == index:
            return entry["number"]
    return ""


def _md_cell(row, index):
    if index >= len(row):
        return ""
    return row[index].replace("\n", "<br>").replace("|", "\\|")


def _render_conformance(ctx):
    from . import conformance

    blocks = []
    for key, label in (("plan_verdicts", "确认测试计划 附录E"), ("report_verdicts", "确认测试报告 附录F")):
        verdicts = ctx.get(key)
        if not verdicts:
            continue
        blocks.append(conformance.render_markdown(verdicts, "产保要素自检表 — %s" % (label,)))
    if not blocks:
        return ""
    return "\n\n".join(blocks)


def _render_gaps(ctx):
    gaps = ctx["gaps"]
    items = gaps.items()
    lines = ["# 缺口清单", "", "共 %d 项。" % (len(items),), ""]
    if not items:
        lines.append("本版输入未发现缺口。")
        return "\n".join(lines) + "\n"
    lines.append("| # | 类型 | 位置 | 字段 | 原因 | 影响 | 建议 |")
    lines.append("|---|---|---|---|---|---|---|")
    for index, gap in enumerate(items):
        lines.append(
            "| %d | %s | %s | %s | %s | %s | %s |"
            % (
                index + 1,
                gap.kind,
                gap.location,
                gap.field.replace("|", "\\|"),
                (gap.reason or "").replace("|", "\\|") or "—",
                (gap.impact or "").replace("|", "\\|") or "—",
                (gap.suggestion or "").replace("|", "\\|") or "—",
            )
        )
    return "\n".join(lines) + "\n"


def _render_check_report(ctx, artefacts):
    spec = ctx["spec"]
    lines = ["# 生成检查报告", ""]
    lines.append("## 输入")
    lines.append("")
    lines.append("- FEIP 包：`%s`（profile=%s，synthetic=%s）" % (ctx["feip"].root, ctx["feip"].profile, ctx["feip"].synthetic))
    lines.append("- 细则：`%s`" % (spec.spec_path,))
    lines.append("- 校验摘要：%s" % ("一致" if ctx["validation"].get("digest_checked") else "未校验或与覆盖报告不一致",))
    lines.append("")
    lines.append("## 规模")
    lines.append("")
    lines.append("- 需求 %d 项" % (ctx["requirement_count"],))
    lines.append("- 测试项目 %d 个" % (len(ctx["projects"]),))
    lines.append("- 测试用例 %d 项、证据程序 %d 项，合计 %d 项"
                 % (len(spec.cases), len(spec.procedures), ctx["stats"]["total"]))
    lines.append("")
    lines.append("## 校验门")
    lines.append("")
    lines.append("| 门 | 结果 |")
    lines.append("|---|---|")
    for name in ("G1 锚点", "G2 残留占位", "G3 标题结构", "G4 编号", "G5 数据完备", "G6 摘要", "G7 可重开", "G8 输入未变"):
        lines.append("| %s | 通过 |" % (name,))
    lines.append("")
    if ctx["validation"].get("warnings"):
        lines.append("## 警告")
        lines.append("")
        for warning in ctx["validation"]["warnings"]:
            lines.append("- `%s`：%s" % (warning.get("code"), warning.get("detail")))
        lines.append("")
    verdicts = (ctx.get("plan_verdicts") or []) + (ctx.get("report_verdicts") or [])
    if verdicts:
        from . import conformance

        summary = conformance.summarise(verdicts)
        lines.append("## 产保要素自检")
        lines.append("")
        lines.append(
            "符合 %d 项 / 不符合 %d 项 / 不适用 %d 项 / 待实测 %d 项。"
            % (
                summary[conformance.VERDICT_OK],
                summary[conformance.VERDICT_BAD],
                summary[conformance.VERDICT_NA],
                summary[conformance.VERDICT_PENDING],
            )
        )
        lines.append("")
        bad = [verdict for verdict in verdicts if verdict.verdict == conformance.VERDICT_BAD]
        if bad:
            lines.append("不符合项：")
            lines.append("")
            for verdict in bad:
                lines.append("- `%s` %s：%s" % (verdict.id, verdict.item, verdict.detail))
            lines.append("")
    lines.append("## 模板缺陷提示")
    lines.append("")
    lines.append(
        "模板第 4 章的“4.2测试覆盖性要求”“4.3测试策略与方法”为手工编号，"
        "而“测试项目”为自动编号标题（同样得到 4.2）。按决策 D6 未做消重，保留模板原貌。"
    )
    lines.append("")
    lines.append("## 产物")
    lines.append("")
    for artefact in artefacts:
        lines.append("- `%s`（%d 字节）" % (artefact["path"], artefact["size_bytes"]))
    return "\n".join(lines) + "\n"
