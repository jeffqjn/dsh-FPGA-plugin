# -*- coding: utf-8 -*-
"""Input resolution, template lookup and the gap registry.

A gap is any value the documents need but the inputs do not provide.  Gaps are
never guessed: they are recorded here and rendered as one of the standard
phrases described in references/mapping-rules.md.
"""
import os

from .base import SkillError

SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TEMPLATE_DIR = os.path.join(SKILL_ROOT, "templates")
RULES_DIR = os.path.join(SKILL_ROOT, "rules")
REFERENCES_DIR = os.path.join(SKILL_ROOT, "references")

PHRASE_UNKNOWN = "任务书未规定"
PHRASE_UNSPECIFIED = "任务书未涉及"
PHRASE_CONFLICT = "任务书存在冲突，待确认"
PHRASE_TODO = "待填"
PHRASE_RESULT = "-"
PHRASE_ABSENT = "—"

DOC_PLAN = "plan"
DOC_REPORT = "report"

INPUT_FILE_NAMES = {
    "spec": "test_specification.json",
    "plan": "verification_plan.json",
    "coverage": "coverage_report.json",
    "rtm": "RTM.csv",
}

GAP_KIND_UNKNOWN = "unknown"
GAP_KIND_ABSENT = "absent"
GAP_KIND_CONFLICT = "conflict"
GAP_KIND_MISSING = "missing"
GAP_KIND_RESULT = "result"


class Gap(object):
    def __init__(self, kind, location, field, reason, impact, suggestion=""):
        self.kind = kind
        self.location = location
        self.field = field
        self.reason = reason
        self.impact = impact
        self.suggestion = suggestion

    def as_dict(self):
        return {
            "kind": self.kind,
            "location": self.location,
            "field": self.field,
            "reason": self.reason,
            "impact": self.impact,
            "suggestion": self.suggestion,
        }


class GapRegistry(object):
    def __init__(self):
        self._items = []
        self._seen = set()

    def add(self, kind, location, field, reason, impact="", suggestion=""):
        key = (kind, location, field, reason)
        if key in self._seen:
            return
        self._seen.add(key)
        self._items.append(Gap(kind, location, field, reason, impact, suggestion))

    def extend(self, gaps):
        for gap in gaps:
            self.add(
                gap.kind,
                gap.location,
                gap.field,
                gap.reason,
                gap.impact,
                gap.suggestion,
            )

    def items(self):
        return list(self._items)

    def count(self):
        return len(self._items)

    def by_kind(self):
        counts = {}
        for gap in self._items:
            counts[gap.kind] = counts.get(gap.kind, 0) + 1
        return counts

    def blocking_count(self):
        return 0

    def phrase_for(self, fact, location, field, impact="", suggestion=""):
        """Register a fact-driven gap and return the phrase to print."""
        from .feip import CONFLICT, PRESENT, UNKNOWN

        if fact is None or fact.status == PRESENT:
            return fact.display if fact is not None else ""
        if fact.status == CONFLICT:
            self.add(GAP_KIND_CONFLICT, location, field, fact.reason or "", impact, suggestion)
            return PHRASE_CONFLICT
        if fact.status == UNKNOWN:
            self.add(GAP_KIND_UNKNOWN, location, field, fact.reason or "", impact, suggestion)
            return PHRASE_UNKNOWN
        self.add(GAP_KIND_ABSENT, location, field, fact.reason or "", impact, suggestion)
        return PHRASE_UNSPECIFIED


def template_path(doc_kind):
    name = "plan.docx" if doc_kind == DOC_PLAN else "report.docx"
    path = os.path.join(TEMPLATE_DIR, name)
    if not os.path.isfile(path):
        raise SkillError(
            "TEMPLATE_MISSING", "template not found: %s" % (path,), {"path": path}
        )
    return path


def input_path(spec_path, kind, explicit=None):
    """Resolve an auxiliary input: explicit path, else a sibling of --spec."""
    if explicit:
        candidate = os.path.abspath(explicit)
        if not os.path.isfile(candidate):
            raise SkillError(
                "INPUT_NOT_FOUND", "%s not found" % (kind,), {"path": candidate}
            )
        return candidate
    if not spec_path:
        return None
    directory = os.path.dirname(os.path.abspath(spec_path))
    candidate = os.path.join(directory, INPUT_FILE_NAMES[kind])
    if os.path.isfile(candidate):
        return candidate
    return None


def output_names(product_name, version, doc_kind):
    safe_product = _safe(product_name or "FPGA")
    safe_version = _safe(version or "")
    suffix = ("_" + safe_version) if safe_version else ""
    if doc_kind == DOC_PLAN:
        return "FPGA确认测试计划_%s%s.docx" % (safe_product, suffix)
    return "FPGA确认测试报告_%s%s.docx" % (safe_product, suffix)


def markdown_name(doc_kind):
    return "确认测试计划.md" if doc_kind == DOC_PLAN else "确认测试报告.md"


def _safe(value):
    text = str(value)
    for ch in ('\\', "/", ":", "*", "?", '"', "<", ">", "|"):
        text = text.replace(ch, "")
    text = text.replace(" ", "")
    return text.strip() or "FPGA"


class Options(object):
    """Resolved command line options with documented defaults."""

    def __init__(self, values=None):
        values = values or {}
        self.source = values.get("source")
        self.spec = values.get("spec")
        self.plan = values.get("plan")
        self.coverage = values.get("coverage")
        self.rtm = values.get("rtm")
        self.plan_docx = values.get("plan_docx")
        self.out = values.get("out")
        self.markdown = not bool(values.get("no_markdown"))
        self.case_table = values.get("case_table") or "1"
        self.dry_run = bool(values.get("dry_run"))

    def require(self, name):
        value = getattr(self, name)
        if not value:
            raise SkillError(
                "OPTION_REQUIRED", "missing required option --%s" % (name.replace("_", "-"),), {}
            )
        return value
