# -*- coding: utf-8 -*-
"""Template surgery engine for WordprocessingML.

Design rules (see references/contract.md):
  * Only ``word/document.xml`` is rewritten; every other package part is copied
    byte for byte, preserving style ids, multilevel numbering, section layout,
    footers and media.
  * Nothing is re-serialised through ElementTree: the original markup of every
    untouched block is kept verbatim, so namespace declarations such as
    ``mc:Ignorable`` survive.
  * Block level edits are string splices on the body children captured at open
    time.  Paragraph and table edits rewrite only the targeted fragment.

Standard library only; Python 3.8.10 compatible (no f-strings, no annotations).
"""
import io
import re
import zipfile

from .base import SkillError

DOCUMENT_PART = "word/document.xml"
STYLES_PART = "word/styles.xml"
NUMBERING_PART = "word/numbering.xml"

_HEADING_STYLE_IDS = ("1", "2", "3", "4")

_ENTITY_RE = re.compile(r"&(#x[0-9a-fA-F]+|#\d+|amp|lt|gt|quot|apos);")
_ESCAPE_MAP = {"&": "&amp;", "<": "&lt;", ">": "&gt;"}


def escape_text(value):
    out = []
    for ch in value:
        out.append(_ESCAPE_MAP.get(ch, ch))
    return "".join(out)


def unescape_text(value):
    def _sub(match):
        token = match.group(1)
        if token == "amp":
            return "&"
        if token == "lt":
            return "<"
        if token == "gt":
            return ">"
        if token == "quot":
            return '"'
        if token == "apos":
            return "'"
        if token.startswith("#x") or token.startswith("#X"):
            return chr(int(token[2:], 16))
        return chr(int(token[1:]))

    return _ENTITY_RE.sub(_sub, value)


class Tag(object):
    __slots__ = ("start", "end", "kind", "name", "local", "closing", "selfclose")

    def __init__(self, start, end, kind, name, closing, selfclose):
        self.start = start
        self.end = end
        self.kind = kind
        self.name = name
        self.local = name.split(":")[-1] if name else ""
        self.closing = closing
        self.selfclose = selfclose


def iter_tags(xml, lo=0, hi=None):
    """Yield tags, comments, CDATA and processing instructions in ``xml``."""
    if hi is None:
        hi = len(xml)
    pos = lo
    while True:
        lt = xml.find("<", pos, hi)
        if lt < 0:
            return
        if xml.startswith("<!--", lt):
            gt = xml.find("-->", lt, hi)
            if gt < 0:
                return
            yield Tag(lt, gt + 3, "comment", "", False, True)
            pos = gt + 3
            continue
        if xml.startswith("<![CDATA[", lt):
            gt = xml.find("]]>", lt, hi)
            if gt < 0:
                return
            yield Tag(lt, gt + 3, "cdata", "", False, True)
            pos = gt + 3
            continue
        if xml.startswith("<?", lt):
            gt = xml.find("?>", lt, hi)
            if gt < 0:
                return
            yield Tag(lt, gt + 2, "pi", "", False, True)
            pos = gt + 2
            continue
        j = lt + 1
        quote = None
        while j < hi:
            ch = xml[j]
            if quote is not None:
                if ch == quote:
                    quote = None
            elif ch == '"' or ch == "'":
                quote = ch
            elif ch == ">":
                break
            j += 1
        if j >= hi:
            return
        raw = xml[lt:j + 1]
        closing = raw.startswith("</")
        selfclose = raw.endswith("/>")
        name = ""
        if not closing:
            k = 1
            while k < len(raw) and not raw[k].isspace() and raw[k] not in "/>":
                k += 1
            name = raw[1:k]
        else:
            k = 2
            while k < len(raw) and not raw[k].isspace() and raw[k] != ">":
                k += 1
            name = raw[2:k]
        yield Tag(lt, j + 1, "tag", name, closing, selfclose)
        pos = j + 1


def child_spans(fragment, local_name):
    """Return [(start, end)] of the direct child elements named ``local_name``."""
    spans = []
    depth = 0
    pending = None
    for tag in iter_tags(fragment):
        if tag.kind != "tag":
            continue
        if tag.selfclose:
            if depth == 1 and pending is None and tag.local == local_name:
                spans.append((tag.start, tag.end))
            continue
        if not tag.closing:
            if depth == 1 and pending is None and tag.local == local_name:
                pending = tag.start
            depth += 1
        else:
            depth -= 1
            if depth == 1 and pending is not None and tag.local == local_name:
                spans.append((pending, tag.end))
                pending = None
    return spans


def element_open_tag_end(raw):
    gt = raw.find(">")
    if gt < 0:
        raise SkillError("DOCX_MALFORMED", "element open tag is not terminated", {})
    return gt + 1


def normalize_open_tag(raw):
    """Turn ``<w:p/>`` into ``<w:p>`` so content can be appended."""
    gt = raw.find(">")
    head = raw[:gt + 1]
    if head.endswith("/>"):
        return head[:-2].rstrip() + ">"
    return head


def split_ppr(inner):
    """Split a leading ``<w:pPr>`` (or ``<w:tcPr>`` family) off an inner string."""
    match = re.match(r"\s*(<w:pPr>.*?</w:pPr>|<w:pPr/>)", inner, re.S)
    if match:
        return match.group(1), inner[match.end():]
    return "", inner


def first_run_properties(inner):
    match = re.search(r"<w:r(?:\s[^>]*)?>\s*(<w:rPr>.*?</w:rPr>)", inner, re.S)
    if match:
        return match.group(1)
    return ""


def runs_xml(text, run_properties=""):
    """Build one run holding ``text`` with LF converted to ``<w:br/>``."""
    pieces = []
    for index, line in enumerate(text.split("\n")):
        if index:
            pieces.append("<w:br/>")
        pieces.append('<w:t xml:space="preserve">%s</w:t>' % escape_text(line))
    return "<w:r>%s%s</w:r>" % (run_properties, "".join(pieces))


_T_RE = re.compile(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>|<w:t(?:\s[^>]*)?/>", re.S)


_T_TEXT_RE = re.compile(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>|<w:cr/>", re.S)


def fragment_text(fragment):
    """Concatenate visible text; tabs and breaks become whitespace.

    A single regex pass replaces the general tag tokeniser here because this runs
    once per table cell and dominated the gate and markdown phases.
    Callers pass markup with ``pPr`` already stripped, so tab stops cannot leak in.
    """
    out = []
    for match in _T_TEXT_RE.finditer(fragment):
        value = match.group(1)
        if value is not None:
            if "&" in value:
                value = unescape_text(value)
            out.append(value)
        elif match.group(0).startswith("<w:tab"):
            out.append("\t")
        else:
            out.append("\n")
    return "".join(out)


def strip_bookmarks(fragment):
    fragment = re.sub(r"<w:bookmarkStart\b[^>]*/>", "", fragment)
    fragment = re.sub(r"<w:bookmarkEnd\b[^>]*/>", "", fragment)
    return fragment


def body_of_paragraph(raw):
    """Return a paragraph's inner markup without its leading ``<w:pPr>``."""
    inner = raw[element_open_tag_end(raw):]
    if inner.endswith("</w:p>"):
        inner = inner[:-len("</w:p>")]
    ppr, rest = split_ppr(inner)
    return rest


class Paragraph(object):
    def __init__(self, index, raw):
        self.index = index
        self.raw = raw

    @property
    def text(self):
        return fragment_text(body_of_paragraph(self.raw))

    @property
    def style(self):
        match = re.search(r'<w:pStyle\s+w:val="([^"]*)"', self.raw)
        return match.group(1) if match else ""

    @property
    def num_id(self):
        match = re.search(r'<w:numId\s+w:val="([^"]*)"', self.raw)
        return match.group(1) if match else ""

    @property
    def ilvl(self):
        match = re.search(r'<w:ilvl\s+w:val="([^"]*)"', self.raw)
        return match.group(1) if match else ""

    @property
    def is_empty(self):
        return not self.text.strip()

    def with_text(self, text):
        """Return the paragraph markup with ``text`` as its only run."""
        head = normalize_open_tag(self.raw)
        inner = self.raw[element_open_tag_end(self.raw):]
        if inner.endswith("</w:p>"):
            inner = inner[:-len("</w:p>")]
        ppr, rest = split_ppr(inner)
        run_properties = first_run_properties(rest)
        return head + ppr + runs_xml(text, run_properties) + "</w:p>"


class Cell(object):
    def __init__(self, span, raw):
        self.span = span
        self.raw = raw

    @property
    def text(self):
        paras = child_spans(self.raw, "p")
        if not paras:
            return fragment_text(self.raw)
        parts = []
        for start, end in paras:
            parts.append(fragment_text(body_of_paragraph(self.raw[start:end])))
        return "\n".join(parts)

    @property
    def grid_span(self):
        match = re.search(r'<w:gridSpan\s+w:val="(\d+)"', self.raw)
        return int(match.group(1)) if match else 1

    @property
    def vmerge(self):
        return re.search(r"<w:vMerge(\s+w:val=\"[^\"]*\")?\s*/>", self.raw) is not None

    def with_text(self, text):
        head = normalize_open_tag(self.raw)
        inner = self.raw[element_open_tag_end(self.raw):]
        if inner.endswith("</w:tc>"):
            inner = inner[:-len("</w:tc>")]
        match = re.match(r"\s*(<w:tcPr>.*?</w:tcPr>|<w:tcPr/>)", inner, re.S)
        tcpr = ""
        if match:
            tcpr = match.group(1)
            inner = inner[match.end():]
        run_properties = first_run_properties(inner)
        return head + tcpr + "<w:p>" + runs_xml(text, run_properties) + "</w:p></w:tc>"


class Table(object):
    def __init__(self, index, raw):
        self.index = index
        self.raw = raw

    def with_borders(self, size=4):
        """Give the table visible single borders.

        Some template tables (the 引用文件 tables) carry no ``tblBorders`` at all,
        which makes them render as loose text instead of a table.
        """
        if "<w:tblBorders>" in self.raw:
            return Table(self.index, self.raw)
        borders = (
            "<w:tblBorders>"
            '<w:top w:val="single" w:sz="%d" w:space="0" w:color="auto"/>'
            '<w:left w:val="single" w:sz="%d" w:space="0" w:color="auto"/>'
            '<w:bottom w:val="single" w:sz="%d" w:space="0" w:color="auto"/>'
            '<w:right w:val="single" w:sz="%d" w:space="0" w:color="auto"/>'
            '<w:insideH w:val="single" w:sz="%d" w:space="0" w:color="auto"/>'
            '<w:insideV w:val="single" w:sz="%d" w:space="0" w:color="auto"/>'
            "</w:tblBorders>" % (size, size, size, size, size, size)
        )
        raw = self.raw
        ppr_end = raw.find("</w:tblPr>")
        if ppr_end < 0:
            open_end = raw.find(">") + 1
            raw = raw[:open_end] + "<w:tblPr>" + borders + "</w:tblPr>" + raw[open_end:]
            return Table(self.index, raw)
        insert_at = ppr_end
        for follower in ("<w:shd", "<w:tblLayout", "<w:tblCellMar", "<w:tblLook"):
            position = raw.find(follower, 0, ppr_end)
            if position >= 0 and position < insert_at:
                insert_at = position
        return Table(self.index, raw[:insert_at] + borders + raw[insert_at:])

    def _row_spans(self):
        return child_spans(self.raw, "tr")

    def row_count(self):
        return len(self._row_spans())

    def rows(self):
        result = []
        for start, end in self._row_spans():
            result.append(Row(self.raw[start:end]))
        return result

    def row(self, index):
        spans = self._row_spans()
        if index < 0:
            index += len(spans)
        if index < 0 or index >= len(spans):
            raise SkillError(
                "DOCX_ROW_OUT_OF_RANGE",
                "row %d out of range (rows=%d)" % (index, len(spans)),
                {"table": self.index},
            )
        start, end = spans[index]
        return Row(self.raw[start:end])

    def with_rows(self, rows):
        spans = self._row_spans()
        if not spans:
            raise SkillError("DOCX_TABLE_EMPTY", "table has no rows", {"table": self.index})
        head = self.raw[:spans[0][0]]
        tail = self.raw[spans[-1][1]:]
        return head + "".join(rows) + tail

    def replace_row(self, index, row):
        rows = [r for r in self.rows()]
        rows[index] = row
        return self.with_rows([r.raw for r in rows])

    def delete_row(self, index):
        rows = [r for r in self.rows()]
        del rows[index]
        return self.with_rows([r.raw for r in rows])

    def insert_row_after(self, index, row_xml, count=1):
        rows = [r.raw for r in self.rows()]
        for offset in range(count):
            rows.insert(index + offset + 1, row_xml)
        return self.with_rows(rows)


class Row(object):
    def __init__(self, raw):
        self.raw = raw

    def _cell_spans(self):
        return child_spans(self.raw, "tc")

    def cell_count(self):
        return len(self._cell_spans())

    def cells(self):
        return [Cell(span, self.raw[span[0]:span[1]]) for span in self._cell_spans()]

    def cell(self, index):
        spans = self._cell_spans()
        if index < 0:
            index += len(spans)
        if index < 0 or index >= len(spans):
            raise SkillError(
                "DOCX_CELL_OUT_OF_RANGE",
                "cell %d out of range (cells=%d)" % (index, len(spans)),
                {},
            )
        span = spans[index]
        return Cell(span, self.raw[span[0]:span[1]])

    def texts(self):
        return [cell.text for cell in self.cells()]

    def with_cells(self, cells):
        spans = self._cell_spans()
        if not spans:
            raise SkillError("DOCX_ROW_EMPTY", "row has no cells", {})
        head = self.raw[:spans[0][0]]
        tail = self.raw[spans[-1][1]:]
        return Row(head + "".join(cells) + tail)

    def set_cell_text(self, index, text):
        cells = [cell.raw for cell in self.cells()]
        target = self.cell(index)
        cells[index] = target.with_text(text)
        return self.with_cells(cells)

    def set_cells(self, texts):
        cells = [cell for cell in self.cells()]
        out = []
        for index, cell in enumerate(cells):
            if index < len(texts) and texts[index] is not None:
                out.append(cell.with_text(texts[index]))
            else:
                out.append(cell.raw)
        return self.with_cells(out)


class Docx(object):
    """A .docx opened for surgical editing."""

    def __init__(self, path):
        self.path = path
        with zipfile.ZipFile(path, "r") as archive:
            self._infos = archive.infolist()
            self._parts = {}
            for info in self._infos:
                self._parts[info.filename] = archive.read(info.filename)
        if DOCUMENT_PART not in self._parts:
            raise SkillError("DOCX_NOT_WORD", "missing %s" % (DOCUMENT_PART,), {"path": path})
        self._xml = self._parts[DOCUMENT_PART].decode("utf-8")
        self._split_body()
        self._styles = None
        self._numbering = None
        self._heading_cache = None
        self._text_cache = {}

    # -- package ---------------------------------------------------------
    def _split_body(self):
        xml = self._xml
        body_open = re.search(r"<w:body\b[^>]*>", xml)
        if not body_open:
            raise SkillError("DOCX_MALFORMED", "no <w:body> element", {"path": self.path})
        body_close = xml.rfind("</w:body>")
        if body_close < 0:
            raise SkillError("DOCX_MALFORMED", "unterminated <w:body>", {"path": self.path})
        self._prefix = xml[:body_open.end()]
        self._suffix = xml[body_close:]
        self._blocks = []
        depth = 0
        start = None
        name = ""
        for tag in iter_tags(xml, body_open.end(), body_close):
            if tag.kind != "tag":
                continue
            if tag.selfclose:
                if depth == 0:
                    self._blocks.append(xml[tag.start:tag.end])
                continue
            if not tag.closing:
                if depth == 0:
                    start = tag.start
                    name = tag.local
                depth += 1
            else:
                depth -= 1
                if depth == 0 and start is not None:
                    self._blocks.append(xml[start:tag.end])
                    start = None
                    name = ""
        if depth != 0:
            raise SkillError("DOCX_MALFORMED", "unbalanced body markup", {"path": self.path})

    def block_xml(self):
        return self._prefix + "".join(self._blocks) + self._suffix

    def template_sha256_hint(self):
        return len(self._xml)

    # -- blocks ----------------------------------------------------------
    def block_count(self):
        return len(self._blocks)

    def block_kind(self, index):
        raw = self._blocks[index]
        if raw.startswith("<w:p") and (len(raw) > 5 and raw[4] in " />"):
            return "p"
        if raw.startswith("<w:tbl"):
            return "tbl"
        if raw.startswith("<w:sectPr"):
            return "sect"
        return "other"

    def paragraph(self, index):
        if self.block_kind(index) != "p":
            raise SkillError("DOCX_NOT_PARAGRAPH", "block is not a paragraph", {"index": index})
        return Paragraph(index, self._blocks[index])

    def table(self, index):
        if self.block_kind(index) != "tbl":
            raise SkillError("DOCX_NOT_TABLE", "block is not a table", {"index": index})
        return Table(index, self._blocks[index])

    def set_block(self, index, raw):
        self._blocks[index] = raw
        # drop only this block's cached text; the others stay valid, which keeps
        # repeated anchor lookups cheap during content build
        self._text_cache.pop(("p", index), None)
        self._text_cache.pop(index, None)
        self._heading_cache = None

    def delete_block(self, index):
        del self._blocks[index]
        self._invalidate()

    def delete_blocks(self, indexes):
        for index in sorted(set(indexes), reverse=True):
            del self._blocks[index]
        self._invalidate()

    def insert_after(self, index, raw_list):
        for offset, raw in enumerate(raw_list):
            self._blocks.insert(index + 1 + offset, raw)
        self._invalidate()

    def insert_before(self, index, raw_list):
        for offset, raw in enumerate(raw_list):
            self._blocks.insert(index + offset, raw)
        self._invalidate()

    def _invalidate(self):
        self._heading_cache = None
        self._text_cache = {}

    def table_texts(self, index):
        """Cached ``[[cell text]]`` for one table block.

        Text extraction re-tokenises every ``w:tc`` fragment, and the gates, the
        markdown export and the content modules each walk every table; caching by
        block index keeps that from happening four or five times per run.
        """
        cached = self._text_cache.get(index)
        if cached is not None:
            return cached
        table = self.table(index)
        rows = []
        for row in table.rows():
            rows.append([cell.text for cell in row.cells()])
        self._text_cache[index] = rows
        return rows

    def paragraphs(self):
        result = []
        for index in range(len(self._blocks)):
            if self.block_kind(index) == "p":
                result.append(Paragraph(index, self._blocks[index]))
        return result

    def tables(self):
        result = []
        for index in range(len(self._blocks)):
            if self.block_kind(index) == "tbl":
                result.append(Table(index, self._blocks[index]))
        return result

    def find_paragraph(self, text_prefix=None, style=None, exact=None, start=0):
        for index in range(start, len(self._blocks)):
            if self.block_kind(index) != "p":
                continue
            para = Paragraph(index, self._blocks[index])
            if style is not None and para.style != style:
                continue
            text = self.paragraph_texts(index)
            if exact is not None and text.strip() != exact:
                continue
            if text_prefix is not None and not text.strip().startswith(text_prefix):
                continue
            return para
        raise SkillError(
            "TEMPLATE_ANCHOR_MISSING",
            "cannot locate paragraph: style=%s prefix=%s exact=%s"
            % (style, text_prefix, exact),
            {"style": style, "prefix": text_prefix, "exact": exact},
        )

    def find_paragraphs(self, text_prefix=None, style=None):
        found = []
        for index in range(len(self._blocks)):
            if self.block_kind(index) != "p":
                continue
            para = Paragraph(index, self._blocks[index])
            if style is not None and para.style != style:
                continue
            if text_prefix is not None and not self.paragraph_texts(index).strip().startswith(text_prefix):
                continue
            found.append(para)
        return found

    def find_table_after(self, index):
        for cursor in range(index + 1, len(self._blocks)):
            if self.block_kind(cursor) == "tbl":
                return Table(cursor, self._blocks[cursor])
        raise SkillError(
            "TEMPLATE_ANCHOR_MISSING", "no table after block %d" % (index,), {"index": index}
        )

    def index_of(self, paragraph):
        return paragraph.index

    # -- package writing -------------------------------------------------
    def set_core_title(self, title):
        """Rewrite ``dc:title`` so the delivered file carries its own name."""
        data = self._parts.get("docProps/core.xml")
        if not data:
            return False
        text = data.decode("utf-8")
        replaced = re.sub(
            r"<dc:title>.*?</dc:title>",
            "<dc:title>%s</dc:title>" % escape_text(title),
            text,
            flags=re.S,
        )
        if replaced == text:
            return False
        self._parts["docProps/core.xml"] = replaced.encode("utf-8")
        return True

    def save(self, path):
        payload = self.block_xml().encode("utf-8")
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            for info in self._infos:
                data = self._parts[info.filename]
                if info.filename == DOCUMENT_PART:
                    data = payload
                clone = zipfile.ZipInfo(info.filename, date_time=info.date_time)
                clone.compress_type = info.compress_type
                clone.external_attr = info.external_attr
                clone.internal_attr = info.internal_attr
                clone.create_system = info.create_system
                archive.writestr(clone, data)

    # -- style and numbering model ---------------------------------------
    def styles(self):
        if self._styles is None:
            self._styles = _parse_styles(self._parts.get(STYLES_PART))
        return self._styles

    def numbering(self):
        if self._numbering is None:
            self._numbering = _parse_numbering(self._parts.get(NUMBERING_PART))
        return self._numbering

    def paragraph_texts(self, index):
        """Cached paragraph text for one block index."""
        key = ("p", index)
        cached = self._text_cache.get(key)
        if cached is None:
            cached = fragment_text(body_of_paragraph(self._blocks[index]))
            self._text_cache[key] = cached
        return cached

    def heading_tree(self):
        """Reconstruct the numbered heading tree without rendering the document."""
        if self._heading_cache is not None:
            return self._heading_cache
        styles = self.styles()
        numbering = self.numbering()
        counters = {}
        tree = []
        for index in range(len(self._blocks)):
            if self.block_kind(index) != "p":
                continue
            para = Paragraph(index, self._blocks[index])
            style_id = para.style
            if style_id not in _HEADING_STYLE_IDS:
                continue
            if para.num_id == "0":
                continue
            num_id, ilvl = _resolve_numbering(para, styles)
            if num_id is None:
                continue
            label = _advance(counters, numbering, num_id, ilvl)
            tree.append(
                {
                    "index": index,
                    "level": ilvl + 1,
                    "style": style_id,
                    "number": label,
                    "text": para.text.strip(),
                    "num_id": num_id,
                }
            )
        self._heading_cache = tree
        return tree


def _resolve_numbering(para, styles):
    num_id = para.num_id
    ilvl = para.ilvl
    if num_id:
        try:
            return num_id, int(ilvl or "0")
        except ValueError:
            return num_id, 0
    style = styles.get(para.style)
    if style and style.get("num_id"):
        return style["num_id"], style.get("ilvl", 0)
    return None, 0


def _parse_styles(data):
    styles = {}
    if not data:
        return styles
    xml = data.decode("utf-8")
    for match in re.finditer(r"<w:style\b[^>]*w:styleId=\"([^\"]+)\"[^>]*>(.*?)</w:style>", xml, re.S):
        style_id = match.group(1)
        body = match.group(2)
        num_id = None
        ilvl = 0
        num_match = re.search(r'<w:numId\s+w:val="(\d+)"', body)
        if num_match:
            num_id = num_match.group(1)
        ilvl_match = re.search(r'<w:ilvl\s+w:val="(\d+)"', body)
        if ilvl_match:
            ilvl = int(ilvl_match.group(1))
        name_match = re.search(r'<w:name\s+w:val="([^"]*)"', body)
        styles[style_id] = {
            "id": style_id,
            "name": name_match.group(1) if name_match else "",
            "num_id": num_id,
            "ilvl": ilvl,
        }
    return styles


def _parse_numbering(data):
    model = {"num_to_abstract": {}, "abstract": {}}
    if not data:
        return model
    xml = data.decode("utf-8")
    for match in re.finditer(r"<w:abstractNum\b[^>]*w:abstractNumId=\"(\d+)\"[^>]*>(.*?)</w:abstractNum>", xml, re.S):
        abstract_id = match.group(1)
        body = match.group(2)
        levels = {}
        for lvl_match in re.finditer(r"<w:lvl\b[^>]*w:ilvl=\"(\d+)\"[^>]*>(.*?)</w:lvl>", body, re.S):
            ilvl = int(lvl_match.group(1))
            lvl_body = lvl_match.group(2)
            text_match = re.search(r'<w:lvlText\s+w:val="([^"]*)"', lvl_body)
            fmt_match = re.search(r'<w:numFmt\s+w:val="([^"]*)"', lvl_body)
            start_match = re.search(r'<w:start\s+w:val="(\d+)"', lvl_body)
            levels[ilvl] = {
                "lvl_text": text_match.group(1) if text_match else "",
                "num_fmt": fmt_match.group(1) if fmt_match else "decimal",
                "start": int(start_match.group(1)) if start_match else 1,
            }
        model["abstract"][abstract_id] = levels
    for match in re.finditer(r"<w:num\b[^>]*w:numId=\"(\d+)\"[^>]*>(.*?)</w:num>", xml, re.S):
        num_id = match.group(1)
        body = match.group(2)
        abstract_match = re.search(r'<w:abstractNumId\s+w:val="(\d+)"', body)
        if abstract_match:
            model["num_to_abstract"][num_id] = abstract_match.group(1)
    return model


def _format_number(num_fmt, value):
    if num_fmt == "decimal":
        return str(value)
    if num_fmt == "lowerLetter":
        return chr(ord("a") + (value - 1) % 26)
    if num_fmt == "upperLetter":
        return chr(ord("A") + (value - 1) % 26)
    if num_fmt == "lowerRoman":
        return _roman(value).lower()
    if num_fmt == "upperRoman":
        return _roman(value)
    return str(value)


def _roman(value):
    table = (
        (1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
        (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I"),
    )
    out = []
    remaining = value
    for amount, glyph in table:
        while remaining >= amount:
            out.append(glyph)
            remaining -= amount
    return "".join(out)


def _advance(counters, numbering, num_id, ilvl):
    abstract_id = numbering["num_to_abstract"].get(num_id)
    levels = numbering["abstract"].get(abstract_id, {})
    key = abstract_id if abstract_id is not None else num_id
    state = counters.setdefault(key, {})
    start = levels.get(ilvl, {}).get("start", 1)
    state[ilvl] = state.get(ilvl, start - 1) + 1
    for deeper in [level for level in state if level > ilvl]:
        del state[deeper]
    template = levels.get(ilvl, {}).get("lvl_text", "")
    if "%" not in template:
        return ""
    rendered = template
    for position in range(1, 10):
        token = "%%%d" % (position,)
        if token not in rendered:
            continue
        level_index = position - 1
        fmt = levels.get(level_index, {}).get("num_fmt", "decimal")
        value = state.get(level_index, levels.get(level_index, {}).get("start", 1))
        rendered = rendered.replace(token, _format_number(fmt, value))
    return rendered


def read_document_text(path):
    """Return the ordered block texts of an existing .docx (validation helper)."""
    doc = Docx(path)
    items = []
    for index in range(doc.block_count()):
        kind = doc.block_kind(index)
        if kind == "p":
            para = doc.paragraph(index)
            items.append({"kind": "p", "style": para.style, "text": para.text})
        elif kind == "tbl":
            table = doc.table(index)
            rows = []
            for row in table.rows():
                rows.append(row.texts())
            items.append({"kind": "tbl", "rows": rows})
    return items
