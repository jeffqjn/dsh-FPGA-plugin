# -*- coding: utf-8 -*-
"""Read one section of a generated document without loading the whole thing.

Under a host that caps a single reply at 32,768 tokens the agent must never echo a
200 KB Markdown file or a whole document.  This module prints one chapter with a
hard character budget, so verification stays cheap.

Section identifiers accept either the auto number (``3.3``) or the heading text
(``功能概述``), because auto headings store only their text in the paragraph.
"""
import os
import re

from .base import SkillError
from .docxlib import Docx

MARK_RE = re.compile(r"^(\d+(\.\d+)*\s*[^\d\s]|附录[A-F]|[A-F]\.\d)")
MAX_OUTLINE = 60


def _is_marker(para):
    text = para.text.strip()
    if not text or len(text) > 48:
        return False
    if para.style in ("1", "2", "3", "4"):
        return True
    return bool(MARK_RE.match(text))


def _outline(doc):
    numbers = dict((entry["index"], entry["number"]) for entry in doc.heading_tree())
    items = []
    for index in range(doc.block_count()):
        if doc.block_kind(index) != "p":
            continue
        para = doc.paragraph(index)
        if not _is_marker(para):
            continue
        number = numbers.get(index, "")
        text = para.text.strip()
        label = (number + " " + text).strip() if number else text
        items.append({"index": index, "number": number, "text": text, "label": label})
    return items


def headings(docx_path):
    """Cheap outline: auto number plus heading text for every section marker."""
    if not os.path.isfile(docx_path):
        raise SkillError("INPUT_NOT_FOUND", "docx not found", {"path": docx_path})
    doc = Docx(docx_path)
    return [entry["label"] for entry in _outline(doc)]


def _locate(items, heading):
    heading = heading.strip()
    for entry in items:
        if entry["number"] and entry["number"] == heading:
            return entry
    for entry in items:
        if entry["number"] and entry["number"].startswith(heading + "."):
            return entry
    for entry in items:
        if entry["label"].startswith(heading):
            return entry
    for entry in items:
        if heading in entry["text"]:
            return entry
    return None


def section(docx_path, heading, max_chars=4000, cell_limit=160):
    """Return one section's text, truncated to ``max_chars`` characters."""
    if not os.path.isfile(docx_path):
        raise SkillError("INPUT_NOT_FOUND", "docx not found", {"path": docx_path})
    doc = Docx(docx_path)
    items = _outline(doc)
    index_of = dict((entry["index"], position) for position, entry in enumerate(items))

    target = _locate(items, heading)
    if target is None:
        return {
            "heading": heading,
            "found": False,
            "available_count": len(items),
            "available": [entry["label"] for entry in items[:MAX_OUTLINE]],
            "hint": "pass --list for the full outline, or use a number such as 3.3",
        }

    position = index_of[target["index"]]
    start = target["index"]
    end = items[position + 1]["index"] if position + 1 < len(items) else doc.block_count()

    parts = []
    used = 0
    truncated = False
    paragraphs = 0
    tables = 0
    for index in range(start, end):
        kind = doc.block_kind(index)
        if kind == "p":
            text = doc.paragraph_texts(index).strip()
            if not text:
                continue
            paragraphs += 1
            chunk = text
        elif kind == "tbl":
            tables += 1
            rows = doc.table_texts(index)
            lines = []
            for row in rows[:40]:
                lines.append(" | ".join(cell.replace("\n", " ")[:cell_limit] for cell in row))
            if len(rows) > 40:
                lines.append("… 共 %d 行" % (len(rows),))
            chunk = "\n".join(lines)
        else:
            continue
        if used + len(chunk) > max_chars:
            head = chunk[: max(0, max_chars - used)]
            parts.append(head)
            used += len(head)
            truncated = True
            break
        parts.append(chunk)
        used += len(chunk)

    return {
        "heading": target["label"],
        "found": True,
        "paragraphs": paragraphs,
        "tables": tables,
        "chars": used,
        "truncated": truncated,
        "text": "\n".join(parts),
    }
